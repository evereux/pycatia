#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class TreeVizManipSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | The Interface to retrieve and set the visual information on the
                | specification tree.

    """

    def __init__(self, catia):
        self.treevizmanipsettingatt = catia.TreeVizManipSettingAtt     

    @property
    def arc_selection_activation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArcSelectionActivation
                | o Property ArcSelectionActivation(    ) As boolean
                | 
                | Retrieves or Sets the arc-selection mode applied to the specification
                | tree.


                | Parameters:


        """
        return self.treevizmanipsettingatt.ArcSelectionActivation

    @property
    def auto_expand_activation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoExpandActivation
                | o Property AutoExpandActivation(    ) As boolean
                | 
                | Retrieves or Sets the automatic expand mode applied to the
                | specification tree.


                | Parameters:


        """
        return self.treevizmanipsettingatt.AutoExpandActivation

    @property
    def auto_scroll_activation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoScrollActivation
                | o Property AutoScrollActivation(    ) As boolean
                | 
                | Retrieves or Sets the automatic scrolling mode applied to the
                | specification tree.


                | Parameters:


        """
        return self.treevizmanipsettingatt.AutoScrollActivation

    @property
    def display_geom_on_scrolling(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayGeomOnScrolling
                | o Property DisplayGeomOnScrolling(    ) As boolean
                | 
                | Retrieves or Sets the "display geometry on scrolling" mode.


                | Parameters:


        """
        return self.treevizmanipsettingatt.DisplayGeomOnScrolling

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property Orientation(    ) As CatTreeOrientationEnum
                | 
                | Retrieves or Sets the orientation applied to the specification tree.


                | Parameters:


        """
        return self.treevizmanipsettingatt.Orientation

    @property
    def show_activation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShowActivation
                | o Property ShowActivation(    ) As boolean
                | 
                | Retrieves or Sets the visualization Show/NoShow's mode applied to the
                | specification tree.


                | Parameters:


        """
        return self.treevizmanipsettingatt.ShowActivation

    @property
    def size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Size
                | o Property Size(    ) As long
                | 
                | Retrieves or Sets the number of characters shown for the text of the
                | specification tree.


                | Parameters:


        """
        return self.treevizmanipsettingatt.Size

    @property
    def size_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SizeType
                | o Property SizeType(    ) As CatTreeSizeTypeEnum
                | 
                | Retrieves or Sets the type of size applied to the text of the
                | specification tree.


                | Parameters:


        """
        return self.treevizmanipsettingatt.SizeType

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CatTreeTypeEnum
                | 
                | Retrieves or Sets the type applied to the specification tree.


                | Parameters:


        """
        return self.treevizmanipsettingatt.Type

    def get_arc_selection_activation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetArcSelectionActivationInfo
                | o Func GetArcSelectionActivationInfo(    CATBSTR    ioAdminLevel,
                |                                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for arc-selection mode applied to
                | the specification tree. Role:Retrieves the state of arc-selection mode
                | applied to the specification tree  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.treevizmanipsettingatt.GetArcSelectionActivationInfo(io_admin_level, io_locked)

    def get_auto_expand_activation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoExpandActivationInfo
                | o Func GetAutoExpandActivationInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for automatic expand mode applied
                | to the specification tree. Role:Retrieves the state of automatic
                | expand mode applied to the specification tree  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.treevizmanipsettingatt.GetAutoExpandActivationInfo(io_admin_level, io_locked)

    def get_auto_scroll_activation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoScrollActivationInfo
                | o Func GetAutoScrollActivationInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for automatic scrolling mode
                | applied to the specification tree. Role:Retrieves the state of the
                | automatic scrolling mode applied to the specification tree  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.treevizmanipsettingatt.GetAutoScrollActivationInfo(io_admin_level, io_locked)

    def get_display_geom_on_scrolling_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayGeomOnScrollingInfo
                | o Func GetDisplayGeomOnScrollingInfo(    CATBSTR    ioAdminLevel,
                |                                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for "display geometry on scrolling"
                | mode. Role:Retrieves the state of "display geometry on scrolling" mode
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.treevizmanipsettingatt.GetDisplayGeomOnScrollingInfo(io_admin_level, io_locked)

    def get_orientation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrientationInfo
                | o Func GetOrientationInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the orientation applied to the
                | specification tree. Role:Retrieves the state of the orientation
                | applied to the specification tree  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.treevizmanipsettingatt.GetOrientationInfo(io_admin_level, io_locked)

    def get_show_activation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShowActivationInfo
                | o Func GetShowActivationInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the visualization Show/NoShow's
                | mode applied to the specification tree. Role:Retrieves the state of
                | the visualization Show/NoShow's mode applied to the specification tree
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.treevizmanipsettingatt.GetShowActivationInfo(io_admin_level, io_locked)

    def get_size_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSizeTypeInfo
                | o Func GetSizeTypeInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the type of size applied to the
                | text of the specification tree. Role:Retrieves the state of the type
                | of size applied to the text of the specification tree  in the current
                | environment.  Attributes "size" and "SizeType" are linked together by
                | the same  lock. So there is no function "GetSizeInfo".


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.treevizmanipsettingatt.GetSizeTypeInfo(io_admin_level, io_locked)

    def get_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTypeInfo
                | o Func GetTypeInfo(    CATBSTR    ioAdminLevel,
                |                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the type applied to the
                | specification tree. Role:Retrieves the state of the type applied to
                | the specification tree  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.treevizmanipsettingatt.GetTypeInfo(io_admin_level, io_locked)

    def set_arc_selection_activation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetArcSelectionActivationLock
                | o Sub SetArcSelectionActivationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the arc-selection mode applied to the specification
                | tree. Role:Locks or unlocks the arc-selection mode applied to the
                | specification tree if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.treevizmanipsettingatt.SetArcSelectionActivationLock(i_locked)

    def set_auto_expand_activation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoExpandActivationLock
                | o Sub SetAutoExpandActivationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the automatic expand mode applied to the
                | specification tree. Role:Locks or unlocks the automatic expand mode
                | applied to the specification tree if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.treevizmanipsettingatt.SetAutoExpandActivationLock(i_locked)

    def set_auto_scroll_activation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoScrollActivationLock
                | o Sub SetAutoScrollActivationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the automatic scrolling mode applied to the
                | specification tree. Role:Locks or unlocks the automatic scrolling mode
                | applied to the specification tree if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.treevizmanipsettingatt.SetAutoScrollActivationLock(i_locked)

    def set_display_geom_on_scrolling_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayGeomOnScrollingLock
                | o Sub SetDisplayGeomOnScrollingLock(    boolean    iLocked)
                | 
                | Locks or unlocks the "display geometry on scrolling" mode. Role:Locks
                | or unlocks "display geometry on scrolling" mode if it is possible in
                | the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.treevizmanipsettingatt.SetDisplayGeomOnScrollingLock(i_locked)

    def set_orientation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOrientationLock
                | o Sub SetOrientationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the orientation applied to the specification tree.
                | Role:Locks or unlocks the orientation applied to the specification
                | tree if it is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.treevizmanipsettingatt.SetOrientationLock(i_locked)

    def set_show_activation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShowActivationLock
                | o Sub SetShowActivationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the visualization Show/NoShow's mode applied to the
                | specification tree. Role:Locks or unlocks the visualization
                | Show/NoShow's mode applied to the specification tree if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.treevizmanipsettingatt.SetShowActivationLock(i_locked)

    def set_size_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSizeTypeLock
                | o Sub SetSizeTypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the type of size applied to the text of the
                | specification tree. Role:Locks or unlocks the type of size applied to
                | the text of the specification tree if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL. Attributs "size" and "SizeType" are linked together by the
                | same  lock. So there is no function "SetSizeTypeLock".


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.treevizmanipsettingatt.SetSizeTypeLock(i_locked)

    def set_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTypeLock
                | o Sub SetTypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the type of the specification tree. Role:Locks or
                | unlocks the type applied to the specification tree if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.treevizmanipsettingatt.SetTypeLock(i_locked)

