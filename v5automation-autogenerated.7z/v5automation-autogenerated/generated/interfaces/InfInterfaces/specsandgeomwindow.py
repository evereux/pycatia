#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SpecsAndGeomWindow:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a window featuring a specification viewer and a geometry
                | viewer.The specification viewer is located in the left part of the
                | window and displays the document's specification tree. The geometry
                | viewer is located in the right part of the window and displays the
                | document's geometry, and can thus be a Viewer2D or a Viewer3D,
                | according to the document type. Even if generally the two viewers are
                | simultaneously displayed, one viewer or the other can be hidden thanks
                | to the CatSpecsAndGeomWindowLayout enumeration.

    """

    def __init__(self, catia):
        self.specsandgeomwindow = catia.SpecsAndGeomWindow     

    @property
    def layout(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Layout
                | o Property Layout(    ) As CatSpecsAndGeomWindowLayout
                | 
                | Returns or sets the specification and geometry window layout. Example:
                | This example sets the specification and geometry window layout for the
                | MyCADWindow window to catWindowGeomOnly.  MyCADWindow.Layout =
                | catWindowGeomOnly


                | Parameters:


        """
        return self.specsandgeomwindow.Layout

    @property
    def specs_viewer(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpecsViewer
                | o Property SpecsViewer(    ) As SpecsViewer
                | 
                | Returns the specifications viewer. Example: This example retrieves the
                | specification viewer for the MyCADWindow window.  Dim MyViewer As
                | Viewer Set MyViewer = MyCADWindow.SpecsViewer


                | Parameters:


        """
        return self.specsandgeomwindow.SpecsViewer

