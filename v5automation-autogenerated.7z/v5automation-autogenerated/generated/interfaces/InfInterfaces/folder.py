#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Folder:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the folder object.It allows you to manipulate folders and
                | gives access to information about them.

    """

    def __init__(self, catia):
        self.folder = catia.Folder     

    @property
    def files(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Files
                | o Property Files(    ) As Files
                | 
                | Returns the file collection of the folder.  Example: This example
                | retrieves in TestFiles the file collection of the folder TestFolder.
                | Dim TestFiles As Files Set TestFiles = TestFolder.Files


                | Parameters:


        """
        return self.folder.Files

    @property
    def sub_folders(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SubFolders
                | o Property SubFolders(    ) As Folders
                | 
                | Returns the folder collection of the folder.  Example: This example
                | retrieves in TestSubFolders the folder colection of the folder
                | TestFolder.  Dim TestSubFolders As CATIAFolders Set TestSubFolders =
                | TestFolder.SubFolders


                | Parameters:


        """
        return self.folder.SubFolders

