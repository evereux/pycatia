#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class PageSetup:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the page setup.The page setup is the object that stores
                | data which defines how yourdocuments and images are actually printed
                | on paper.This data includes namely the paper size, the orientation,the
                | bottom, top, right, and left margins, the zoom factor, the banner,and
                | the printing quality.

    """

    def __init__(self, catia):
        self.pagesetup = catia.PageSetup     

    @property
    def banner(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Banner
                | o Property Banner(    ) As
           CATBSTR
                | 
                | Returns or sets the banner text.            The banner text is added
                | to the print and can include variables,            such as the user
                | who prints, the date and time of printing.            Available
                | variables are:            $USER                The user name
                | $HOST                The workstation name                $SCALE
                | The print scale                $TIME                The print time
                | $DATE                The print date                $DAY
                | The print day                $MONTH                The print month
                | $YEAR                The print year            The default banner is:
                | Printed by $USER on $DATE $TIME Example:                    This
                | example sets the banner text to the following:
                | Printed by $USER at scale $SCALE on $MONTH/$DAY/$YEAR
                | for the SetupForMyPrint page setup.
                | SetupForMyPrint.Banner = "Printed by $USER at scale $SCALE on
                | $MONTH/$DAY/$YEAR"


                | Parameters:


        """
        return self.pagesetup.Banner

    @property
    def banner_position(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BannerPosition
                | o Property BannerPosition(    ) As
             CatBannerPosition
                | 
                | Returns or sets the banner position.                The banner can be
                | located on the top, bottom, left, or right side                of the
                | page. catBannerPositionNone removes the banner.
                | Example:                        This example sets the banner on the
                | top side of the page                        for the SetupForMyPrint
                | page setup.                         SetupForMyPrint.BannerPosition =
                | CatBannerPositionTop


                | Parameters:


        """
        return self.pagesetup.BannerPosition

    @property
    def banner_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BannerSize
                | o Property BannerSize(    ) As
               float
                | 
                | Returns or sets Banner Size.                    Banner size could
                | range from 0.1 mm to 10.0 mm                    Default value is 2.4
                | mm                                        Example:
                | This example sets banner size                            for the
                | SetupForMyPrint page setup.
                | SetupForMyPrint.BannerSize = 1.1


                | Parameters:


        """
        return self.pagesetup.BannerSize

    @property
    def bottom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Bottom
                | o Property Bottom(    ) As
                 float
                | 
                | Returns or sets the lower left corner location with respect to the
                | bottom                        of the sheet of paper.
                | This is the distance of the document or the image to print
                | lower left corner to the paper lower left corner.
                | Example:                                This example sets the location
                | of the lower left corner of the document
                | or the image to print at 40 mm from the paper lower left corner
                | for the SetupForMyPrint page setup.
                | SetupForMyPrint.Bottom = 40


                | Parameters:


        """
        return self.pagesetup.Bottom

    @property
    def bottom_margin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BottomMargin
                | o Property BottomMargin(    ) As
                   float
                | 
                | Returns or sets the bottom margin.                            The
                | bottom margin is a strip in which nothing is printed, located
                | at the bottom of the page, which height is expressed in mm.
                | Example:                                    This example sets the
                | bottom margin for the SetupForMyPrint
                | page setup to 10 mm.
                | SetupForMyPrint.BottomMargin = 10


                | Parameters:


        """
        return self.pagesetup.BottomMargin

    @property
    def color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Color
                | o Property Color(    ) As
                     CatPrintColor
                | 
                | Returns or sets the color mode to use when printing.
                | Example:                                        This example sets the
                | color mode to GreyScale                                        for the
                | SetupForMyPrint page setup.
                | SetupForMyPrint.Color = catColorGreyScale


                | Parameters:


        """
        return self.pagesetup.Color

    @property
    def dpi(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Dpi
                | o Property Dpi(    ) As
                       float
                | 
                | Returns or sets the printing dpi.
                | Example:                                            This example sets
                | the printing dpi                                            for the
                | SetupForMyPrint page setup.
                | SetupForMyPrint.Dpi = 150.


                | Parameters:


        """
        return self.pagesetup.Dpi

    @property
    def gamma(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Gamma
                | o Property Gamma(    ) As
                         float
                | 
                | Returns or sets Gamma factor for print.
                | Gamma value could range from 0.1 to 5.0
                | Default value is 1.0
                | Example:                                                This example
                | sets Gamma factor                                                for
                | the SetupForMyPrint page setup.
                | SetupForMyPrint.Gamma = 1.2


                | Parameters:


        """
        return self.pagesetup.Gamma

    @property
    def left(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Left
                | o Property Left(    ) As
                           float
                | 
                | Returns or sets the lower left corner location with respect to the
                | left                                            of the sheet of paper.
                | This is the distance of the document or the image to print
                | lower left corner to the paper lower left corner.
                | Example:                                                    This
                | example sets the location of the lower left corner of the
                | document                                                    or the
                | image to print at 25 mm from the paper lower left corner
                | for the SetupForMyPrint page setup.
                | SetupForMyPrint.Left = 25


                | Parameters:


        """
        return self.pagesetup.Left

    @property
    def left_margin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LeftMargin
                | o Property LeftMargin(    ) As
                             float
                | 
                | Returns or sets the left margin.
                | The left margin is a strip in which nothing is printed, located
                | at the left of the page, which width is expressed in mm.
                | Example:                                                        This
                | example sets the left margin for the
                | SetupForMyPrint
                | page setup to 10 mm.
                | SetupForMyPrint.LeftMargin = 10


                | Parameters:


        """
        return self.pagesetup.LeftMargin

    @property
    def line_cap(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LineCap
                | o Property LineCap(    ) As
                               CatPrintLineCap
                | 
                | Returns or sets Line cap for print.
                | Refer to
                | activateLinkAnchor('CatPrintLineCap', '', 'CatPrintLineCap')
                | Default value is catPrintFlat
                | Example:
                | This example sets Line cap
                | for the SetupForMyPrint page setup.
                | SetupForMyPrint.LineCap = catPrintFlat


                | Parameters:


        """
        return self.pagesetup.LineCap

    @property
    def line_type_overlapping_check(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LineTypeOverlappingCheck
                | o Property LineTypeOverlappingCheck(    ) As
                                 boolean
                | 
                | Returns or sets text Line type overlap check option for
                | print.                                                        Default
                | value is FALSE
                | Example:
                | This example sets Line type overlapping check option
                | for the SetupForMyPrint page setup.
                | SetupForMyPrint.LineTypeOverlappingCheck = True


                | Parameters:


        """
        return self.pagesetup.LineTypeOverlappingCheck

    @property
    def line_type_specification(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LineTypeSpecification
                | o Property LineTypeSpecification(    ) As
                                   CatPrintLineSpecification
                | 
                | Returns or sets Line type specification for print.
                | Refer to
                | activateLinkAnchor('CatPrintLineSpecification', '',
                | 'CatPrintLineSpecification')
                | Default value is catPrintAbsolute
                | Example:
                | This example sets Line type specification
                | for the SetupForMyPrint page setup.
                | SetupForMyPrint.LineTypeSpecification = catPrintAbsolute


                | Parameters:


        """
        return self.pagesetup.LineTypeSpecification

    @property
    def line_width_specification(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LineWidthSpecification
                | o Property LineWidthSpecification(    ) As
                                     CatPrintLineSpecification
                | 
                | Returns or sets Line width specification for print.
                | Refer to
                | activateLinkAnchor('CatPrintLineSpecification', '',
                | 'CatPrintLineSpecification')
                | Default value is catPrintAbsolute
                | Example:
                | This example sets Line width specification
                | for the SetupForMyPrint page setup.
                | SetupForMyPrint.LineWidthSpecification = catPrintAbsolute


                | Parameters:


        """
        return self.pagesetup.LineWidthSpecification

    @property
    def logo(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Logo
                | o Property Logo(    ) As
                                       CATBSTR
                | 
                | Returns or sets the file containing the logo
                | image.
                | The logo is printed with the banner.
                | Example:
                | This example sets the logo file to the
                | following file:
                | e:\users\psr\Images\Logo.tif
                | for the SetupForMyPrint page
                | setup.
                | SetupForMyPrint.Logo = "e:\users\psr\Images\Logo.tif"


                | Parameters:


        """
        return self.pagesetup.Logo

    @property
    def logo_visibility(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LogoVisibility
                | o Property LogoVisibility(    ) As
                                         boolean
                | 
                | Returns or sets LogoVisibility option for
                | print.
                | Default value is FALSE
                | Example:
                | This example sets LogoVisibility
                | option
                | for the SetupForMyPrint
                | page setup.
                | SetupForMyPrint.LogoVisibility = True


                | Parameters:


        """
        return self.pagesetup.LogoVisibility

    @property
    def maximum_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaximumSize
                | o Property MaximumSize(    ) As
                                           boolean
                | 
                | Returns or sets whether the document or
                | the image should be printed
                | at the maximum size with respect to the
                | page size and margins.
                | True if the document or the image
                | is printed with the maximum
                | size.
                | This overrides the location properties,
                | that is Left and Bottom,
                | and the Zoom property values.
                | Example:
                | This example requests to print
                | the document or the image with
                | the
                | SetupForMyPrint page
                | setup at maximum size.
                | SetupForMyPrint.MaximumSize = True


                | Parameters:


        """
        return self.pagesetup.MaximumSize

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property
                                                                                        Orientation(    ) As
                                             CatPaperOrientation
                | 
                | Returns or sets the paper
                | orientation.
                | Example:
                | This example sets the paper
                | orientation for the SetupForMyPrint
                | page setup to catPaperLandscape.
                | SetupForMyPrint.Orientation = catPaperLandscape


                | Parameters:


        """
        return self.pagesetup.Orientation

    @property
    def paper_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperHeight
                | o Property
                                                                                            PaperHeight(    ) As
                                               float
                | 
                | Returns or sets the paper
                | height.
                | Example:
                | This example sets the
                | page height for the SetupForMyPrint
                | page setup to 297 mm..
                | SetupForMyPrint.PaperHeight = 297


                | Parameters:


        """
        return self.pagesetup.PaperHeight

    @property
    def paper_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperSize
                | o Property
                                                                                                PaperSize(    ) As
                                                 CatPaperSize
                | 
                | Returns or sets the paper
                | size.
                | Example:
                | This example sets
                | the page size for
                | the
                | SetupForMyPrint
                | page setup to catPaperA4.
                | SetupForMyPrint.PaperSize = catPaperA4


                | Parameters:


        """
        return self.pagesetup.PaperSize

    @property
    def paper_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperWidth
                | o Property PaperWidth(    ) As
                                                   float
                | 
                | Returns or sets the
                | paper width.
                | Example:
                | This example
                | sets the page
                | width for the
                | SetupForMyPrint
                | page setup to
                | 210 mm..
                | SetupForMyPrint.PaperWidth = 210


                | Parameters:


        """
        return self.pagesetup.PaperWidth

    @property
    def print_rendering_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintRenderingMode
                | o Property
                                                                                                        PrintRenderingMode(    ) As
                                                     CatPrintRenderingMode
                | 
                | Returns or sets the
                | printing rendering
                | mode.
                | Example:
                | This example
                | sets the
                | printing
                | rendering
                | mode
                | for the SetupForMyPrint
                | page setup.
                | SetupForMyPrint.PrintRenderingMode = CatPrintRenderingModeDefault


                | Parameters:


        """
        return self.pagesetup.PrintRenderingMode

    @property
    def quality(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Quality
                | o
                                                                                                            Property
                                                                                                            Quality(    ) As
                                                       CatPrintQuality
                | 
                | Returns or sets
                | the printing
                | quality.
                | Refer to
                | activateLinkAnchor('CatPrintQuality', '', 'CatPrintQuality') Example:
                | This
                | example
                | sets the
                | printing
                | quality
                | to draft
                | for the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.Quality = catPrintQualityDraft


                | Parameters:


        """
        return self.pagesetup.Quality

    @property
    def right_margin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RightMargin
                | o
                                                                                                                Property
                                                                                                                RightMargin(    ) As
                                                         float
                | 
                | Returns or
                | sets the
                | right
                | margin.
                | The right
                | margin is a
                | strip in
                | which
                | nothing is
                | printed,
                | located
                | at the right
                | of the page,
                | which width
                | is expressed
                | in mm.
                | Example:
                | This
                | example
                | sets
                | the
                | right
                | margin
                | for
                | the
                | SetupForMyPrint
                | page
                | setup
                | to
                | 12
                | mm.
                | SetupForMyPrint.RightMargin = 12


                | Parameters:


        """
        return self.pagesetup.RightMargin

    @property
    def rotation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Rotation
                | o
                                                                                                                    Property
                                                                                                                    Rotation(    )
                                                          As
                                                           CatImageRotation
                | 
                | Returns
                | or sets
                | the
                | rotation
                | of the
                | document
                | or the
                | image to
                | print.
                | Rotations
                | angles
                | can be
                | 0, 90,
                | 180, and
                | 270
                | degrees
                | counted
                | clockwise.
                | Example:
                | This
                | example
                | sets
                | the
                | rotation
                | to
                | 90
                | degrees
                | clockwise
                | for
                | the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.Rotation = catImageRotation90


                | Parameters:


        """
        return self.pagesetup.Rotation

    @property
    def scaling1_to1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Scaling1To1
                | o
                                                                                                                        Property
                                                                                                                        Scaling1To1(    )
                                                            As
                                                             boolean
                | 
                | Returns
                | or
                | sets
                | whether
                | the
                | document
                | or
                | the
                | image
                | should
                | be
                | printed
                | with
                | a
                | zoom
                | factor
                | equals
                | to 1
                | and
                | the
                | image
                | to
                | print
                | lower
                | left
                | corner
                | on
                | the
                | paper
                | lower
                | corner.
                | True
                | if
                | the
                | document
                | or
                | the
                | image
                | is
                | printed
                | with
                | the
                | zoom
                | factor
                | equals
                | to 1
                | and
                | the
                | image
                | to
                | print
                | lower
                | left
                | corner
                | on
                | the
                | paper
                | lower
                | corner.
                | This
                | overrides
                | the
                | location
                | properties,
                | that
                | is
                | Left
                | and
                | Bottom,
                | and
                | the
                | Zoom
                | property
                | values.
                | Example:
                | This
                | example
                | requests
                | to
                | print
                | the
                | document
                | or
                | the
                | image
                | with
                | the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.Scaling1To1 = True


                | Parameters:


        """
        return self.pagesetup.Scaling1To1

    @property
    def text_blanking(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextBlanking
                | o
                                                                                                                            Property
                                                                                                                            TextBlanking(    )
                                                              As
                                                               boolean
                | 
                | Returns
                | or
                | sets
                | the
                | text
                | blanking
                | option
                | in
                | print
                | Text
                | will
                | be
                | printed
                | in
                | blanking
                | rectangle
                | Default
                | value
                | is
                | FALSE
                | Example:
                | This
                | example
                | sets
                | the
                | text
                | blanking
                | option
                | for
                | the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.TextBlanking = True


                | Parameters:


        """
        return self.pagesetup.TextBlanking

    @property
    def text_scaling(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextScaling
                | o
                                                                                                                                Property
                                                                                                                                TextScaling(    )
                                                                As
                                                                 boolean
                | 
                | Returns
                | or
                | sets
                | text
                | scaling
                | option
                | for
                | print.
                | Default
                | value
                | is
                | TRUE
                | Example:
                | This
                | example
                | sets
                | text
                | scaling
                | option
                | for
                | the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.TextScaling = True


                | Parameters:


        """
        return self.pagesetup.TextScaling

    @property
    def top_margin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TopMargin
                | o
                                                                                                                                    Property
                                                                                                                                    TopMargin(    )
                                                                  As
                                                                   float
                | 
                | Returns
                | or
                | sets
                | the
                | top
                | margin.
                | The
                | top
                | margin
                | is
                | a
                | strip
                | in
                | which
                | nothing
                | is
                | printed,
                | located
                | at
                | the
                | top
                | of
                | the
                | page,
                | which
                | height
                | is
                | expressed
                | in
                | mm.
                | Example:
                | This
                | example
                | sets
                | the
                | top
                | margin
                | for
                | the
                | SetupForMyPrint
                | page
                | setup
                | to
                | 15
                | mm.
                | SetupForMyPrint.TopMargin = 15


                | Parameters:


        """
        return self.pagesetup.TopMargin

    @property
    def use_3d_accuracy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Use3DAccuracy
                | o
                                                                                                                                        Property
                                                                                                                                        Use3DAccuracy(    )
                                                                    As
                                                                     boolean
                | 
                | Returns
                | or
                | sets
                | Use3DAccuracy
                | option
                | for
                | print.
                | Default
                | value
                | is
                | FALSE
                | Example:
                | This
                | example
                | sets
                | Use3DAccuracy
                | option
                | for
                | the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.Use3DAccuracy = True


                | Parameters:


        """
        return self.pagesetup.Use3DAccuracy

    @property
    def use_image_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseImageSize
                | o
                                                                                                                                            Property
                                                                                                                                            UseImageSize(    )
                                                                      As
                                                                       boolean
                | 
                | Returns
                | or
                | sets
                | the
                | paper
                | size
                | to
                | the
                | image
                | size.
                | Example:
                | This
                | example
                | sets
                | the
                | paper
                | size
                | to
                | image
                | size
                | for
                | the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.UseImageSize = True


                | Parameters:


        """
        return self.pagesetup.UseImageSize

    @property
    def white_vectors_in_black(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WhiteVectorsInBlack
                | o
                                                                                                                                                Property
                                                                                                                                                WhiteVectorsInBlack(    )
                                                                        As
                                                                         boolean
                | 
                | Returns
                | or
                | sets
                | the
                | white
                | vectors
                | in
                | black
                | option.
                | white
                | vectors
                | will
                | be
                | printed
                | in
                | black
                | if
                | set
                | to
                | True
                | Default
                | value
                | is
                | TRUE
                | Example:
                | This
                | example
                | sets
                | the
                | Print
                | White
                | Vectors
                | In
                | Black
                | option
                | for
                | the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.WhiteVectorsInBlack = True


                | Parameters:


        """
        return self.pagesetup.WhiteVectorsInBlack

    @property
    def zoom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Zoom
                | o
                                                                                                                                                    Property
                                                                                                                                                    Zoom(    )
                                                                          As
                                                                           float
                | 
                | Returns
                | or
                | sets
                | the
                | zoom
                | factor
                | to
                | use
                | when
                | printing.
                | Example:
                | This
                | example
                | sets
                | the
                | zoom
                | factor
                | to
                | 1.5
                | for
                | the
                | SetupForMyPrint
                | page
                | setup.
                | SetupForMyPrint.Zoom = 1.5


                | Parameters:


        """
        return self.pagesetup.Zoom

