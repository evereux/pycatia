#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatFileSelectionMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Mode used when displaying a file selection box using
                | CATIA.FileSelectionBox.

    """

    def __init__(self, catia):
        self.catfileselectionmode = catia.CatFileSelectionMode     

