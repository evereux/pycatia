#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class References:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all the references aggregated in an object.

    """

    def __init__(self, catia):
        self.references = catia.References     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As Reference
                | 
                | Returns a reference using its index or its name from the References
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the reference to retrieve from
                |    the collection of references.
                |    As a numerics, this index is the rank of the reference
                |    in the collection.
                |    The index of the first reference in the collection is 1, and
                |    the index of the last reference is Count.
                |    As a string, it is the name you assigned to the reference using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved reference


                | Examples:
                | 
                | 
                | This example retrieves the last item in the RefList
                | reference collection by means of the Count property.
                | 
                | Dim LastRef As Reference
                | Set LastRef = RefList.Item(RefList.Count)
                | 
                | 
                | 
        """
        return self.references.Item(i_index)

