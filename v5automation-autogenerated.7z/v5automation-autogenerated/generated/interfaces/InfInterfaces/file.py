#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class File:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the file object.Role: The file object allows to manipulate
                | files with UNIX and Windows. Use it instead of the one of Visual Basic
                | to make portable macros.   Its gives access to information about the
                | file and can open a file as
                | aactivateLinkAnchor('TextStream','','TextStream')object.

    """

    def __init__(self, catia):
        self.file = catia.File     

    @property
    def size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Size
                | o Property Size(    ) As long
                | 
                | Returns the size of the file. Example: This example retrieves in
                | FileSize the size of the File TestFile.  Dim FileSize As Long FileSize
                | = TestFile.Size


                | Parameters:


        """
        return self.file.Size

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the type of the file. For instance, if the file has a .txt or
                | .doc extension, its type will be "Text Document". Example: This
                | example retrieves in FileType the type of the File TestFile.  Dim
                | FileType As String FileSize = TestFile.Size


                | Parameters:


        """
        return self.file.Type

    def open_as_text_stream(self, i_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | OpenAsTextStream
                | o Func OpenAsTextStream(    CATBSTR    iMode) As TextStream
                | 
                | Opens the file and retrieves it as a TextSteam object.  Paramater
                | iMode can have the value "ForReading", "ForWriting" or "ForAppending".
                | Example: This example opens the file TestFile for reading and
                | retrieves in the  text stream TextStr.  Dim TextStr As CATIATextSteam
                | Set TextStr = TestFile.OpenAsTextStream("ForReading")


                | Parameters:


        """
        return self.file.OpenAsTextStream(i_mode)

