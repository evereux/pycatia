#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatTreeOrientationEnum:
    """
        .. note::
            CAA V5 Visual Basic help

                | Orientations for the specification tree.Role: This enum is used in the
                | activateLinkAnchor('TreeVizManipSettingAtt','','TreeVizManipSettingAtt
                | ')interface.

    """

    def __init__(self, catia):
        self.cattreeorientationenum = catia.CatTreeOrientationEnum     

