#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatPrintQuality:
    """
        .. note::
            CAA V5 Visual Basic help

                | Print quality.It is used by
                | theactivateLinkAnchor('PageSetup','','PageSetup')object for document
                | printing. The print quality ranges
                | fromcatPrintQualityDrafttocatPrintQualityHighand applies to shaded
                | images.catPrintQualityDraftis the lowest quality and creates images
                | with the screen resolution (It is for example the Quality 0 for HP-
                | GL/2.)catPrintQualityHighprints images at the maximum printer
                | resolution. The other print qualities are somewhere in between.

    """

    def __init__(self, catia):
        self.catprintquality = catia.CatPrintQuality     

