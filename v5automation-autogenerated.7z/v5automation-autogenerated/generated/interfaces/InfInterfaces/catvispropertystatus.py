#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatVisPropertyStatus:
    """
        .. note::
            CAA V5 Visual Basic help

                | Types of result of a query on graphic properties for the current
                | selection.Role: This enum is used in
                | theactivateLinkAnchor('VisPropertySet','','VisPropertySet')interface.

    """

    def __init__(self, catia):
        self.catvispropertystatus = catia.CatVisPropertyStatus     

