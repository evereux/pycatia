#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SendToService:
    """
        .. note::
            CAA V5 Visual Basic help

                | This interface allows to use 'Send To' functionalities   through an
                | API.

    """

    def __init__(self, catia):
        self.sendtoservice = catia.SendToService     

    def add_file(self, i_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFile
                | o Sub AddFile(    CATBSTR    iPath)
                | 
                | Adds a file to the list of the files 'to be copied'.   This method
                | verifies that the given input file is valid (exists and is not a
                | directory), it recursively adds pointed files.


                | Parameters:
                | iPath
                |  : The path of the file to be added to the list of the 'to be copied' files.


                | Examples:
                | 
                | 
                | 
                | Send.AddFile(iPath)
                | 
                | 
                | 
                | 
        """
        return self.sendtoservice.AddFile(i_path)

    def get_last_send_to_method_error(self, o_error_param, o_error_code):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLastSendToMethodError
                | o Sub GetLastSendToMethodError(    CATBSTR    oErrorParam,
                |                                    long    oErrorCode)
                | 
                | Retreives the diagnosis related to the last call to SendToService
                | interface.


                | Parameters:
                | oErrorParam
                |  A parameter string given together with the error code. 
                |   oErrorCode
                |  The last executed method error code: 
                | 
                | code diagnosisoErrorParam value 
                |  0  action successfully performed :-) 
                |  1  PX1 license not granted  
                |  2  internal error  
                |  5  file already in the list  file name 
                |  6  file is not in the list   file name 
                |  7  empty file list  
                |  8  missing target directory  
                |  9  no common root directory  
                |  10  file does not exist   file name 
                |  11  input is a directory   directory name 
                |  12  directory check failed directory name 
                |  13  invalid file name given name 
                |  14  file has no read permission given name 
                |  36  allocation failed :-(


        """
        return self.sendtoservice.GetLastSendToMethodError(o_error_param, o_error_code)

    def get_list_of_dependant_file(self, o_dependant):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetListOfDependantFile
                | o Sub GetListOfDependantFile(    CATSafeArrayVariant    oDependant)
                | 
                | Retreives the complete list of the files recursively pointed by the
                | file given in argument to SetInitialFile method. Notice : in case
                | AddFile has also been invoked, the files recursively  pointed by the
                | added file also are retreived.


                | Parameters:
                | oDependant
                |  : The table of dependant files.


                | Examples:
                | 
                | 
                | 
                | Send.GetListOfDependantFile(oDependant)
                | 
                | 
                | 
                | 
        """
        return self.sendtoservice.GetListOfDependantFile(o_dependant)

    def get_list_of_to_be_copied_files(self, o_will_be_copied):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetListOfToBeCopiedFiles
                | o Sub GetListOfToBeCopiedFiles(    CATSafeArrayVariant    oWillBeCopied)
                | 
                | Retreives the complete list of the files that will be copied. This
                | list matches the list of dependant files, but without the files for
                | which RemoveFile has been invoked.


                | Parameters:
                | oWillBeCopied
                |  : The table of the files that will be copied.


                | Examples:
                | 
                | 
                | 
                | Send.GetListOfToBeCopiedFiles(oWillBeCopied)
                | 
                | 
                | 
                | 
        """
        return self.sendtoservice.GetListOfToBeCopiedFiles(o_will_be_copied)

    def keep_directory(self, i_keep):
        """
        .. note::
            CAA V5 Visual Basic help

                | KeepDirectory
                | o Sub KeepDirectory(    boolean    iKeep)
                | 
                | Controls the directory tree structure in the target directory.


                | Parameters:
                | iKeep
                | 	=1: to preserve the relative tree structure of the files. This option will be effective only if there is a common root directory for all files.
                |  
                |  iKeep
                |  =0: to copy the files directly in the destination directory


                | Examples:
                | 
                | 
                | 
                | Send.KeepDirectory(ikeep)
                | 
                | 
                | 
                | 
        """
        return self.sendtoservice.KeepDirectory(i_keep)

    def remove_file(self, i_file):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveFile
                | o Sub RemoveFile(    CATBSTR    iFile)
                | 
                | Removes a file from the list of the files that will be copied.


                | Parameters:
                | iFile
                |  : The File (With extension) to be removed from the list of the 'to be copied' files.


                | Examples:
                | 
                | 
                | 
                | Send.RemoveFile(iFile)
                | 
                | 
                | 
                | 
        """
        return self.sendtoservice.RemoveFile(i_file)

    def run(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Run
                | o Sub Run(    )
                | 
                | Executes the copy action, according to previously set files and
                | options.A "report.txt" report file is generated in the specified
                | destination directory.


                | Parameters:


        """
        return self.sendtoservice.Run()

    def set_directory_file(self, i_directory):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDirectoryFile
                | o Sub SetDirectoryFile(    CATBSTR    iDirectory)
                | 
                | Positions the destination directory.   This method verifies that the
                | given directory exists. Be careful, if SetDirectoryOneFile method has
                | been previously called,  its action is overriden by this
                | SetDirectoryFile call.


                | Parameters:
                | iDirectory
                |  : The destination directory where the files will be copied.


                | Examples:
                | 
                | 
                | 
                | Send.SetDirectoryFile(iDirectory)
                | 
                | 
                | 
                | 
        """
        return self.sendtoservice.SetDirectoryFile(i_directory)

    def set_directory_one_file(self, i_file, i_directory):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDirectoryOneFile
                | o Sub SetDirectoryOneFile(    CATBSTR    iFile,
                |                               CATBSTR    iDirectory)
                | 
                | Allows positioning the destination directory for one given file to be
                | copied.   The file will be copied in the specified target directory.
                | Be careful that using this method implies that   the 'KeepDirectory'
                | variable will be automatically set to 0.


                | Parameters:
                | iFile
                |  : The name (Name With extension) of the given file. 
                |  iDirectory
                |  : The directory where this file will be copied.


                | Examples:
                | 
                | 
                | 
                | Send.SetDirectoryOneFile(iFile, iDirectory)
                | 
                | 
                | 
                | 
        """
        return self.sendtoservice.SetDirectoryOneFile(i_file, i_directory)

    def set_initial_file(self, i_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInitialFile
                | o Sub SetInitialFile(    CATBSTR    iPath)
                | 
                | Sets the initial file to be copied. This method verifies that the
                | given input file is valid (exists and is not a directory)  It
                | generates a complete list of the recursively dependent files to be
                | copied.  Example: This example positions the file of path ipath in the
                | list  of 'to be copied' files. All its dependant files will  also be
                | added in the list of 'to be copied' files.


                | Parameters:
                | iPath
                |  : Full path of the file to be copied. 
                |  Send.SetInitialFile(iPath)


        """
        return self.sendtoservice.SetInitialFile(i_path)

    def set_rename_file(self, i_oldname, i_new_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRenameFile
                | o Sub SetRenameFile(    CATBSTR    iOldname,
                |                         CATBSTR    iNewName)
                | 
                | Renames one file to be copied. The new name may not have invalid
                | characters


                | Parameters:
                | iOldname
                |  : The old file name (With extension). 
                |   iNewName
                |  : The new file name (Without extension).


                | Examples:
                | 
                | 
                | 
                | Send.SetRenameFile(iOldname, iNewName)
                | 
                | 
                | 
        """
        return self.sendtoservice.SetRenameFile(i_oldname, i_new_name)

