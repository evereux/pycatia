#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatVisPropertyShow:
    """
        .. note::
            CAA V5 Visual Basic help

                | Types of Show/NoShow states.Role: This enum is used in
                | theactivateLinkAnchor('VisPropertySet','','VisPropertySet')interface.

    """

    def __init__(self, catia):
        self.catvispropertyshow = catia.CatVisPropertyShow     

