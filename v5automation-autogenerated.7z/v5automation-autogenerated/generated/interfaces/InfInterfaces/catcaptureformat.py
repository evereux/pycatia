#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatCaptureFormat:
    """
        .. note::
            CAA V5 Visual Basic help

                | File format in which the capture of a viewer can be saved.It is used
                | by theactivateLinkAnchor('Viewer','','Viewer')object.

    """

    def __init__(self, catia):
        self.catcaptureformat = catia.CatCaptureFormat     

