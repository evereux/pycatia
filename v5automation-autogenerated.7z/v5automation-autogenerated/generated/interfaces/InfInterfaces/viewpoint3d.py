#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Viewpoint3D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the 3D viewpoint.The 3D viewpoint is the object that stores
                | data which defines how your objects are seen to enable their display
                | by a 3D viewer. This data includes namely the eye location, also named
                | the origin, the distance from the eye to the target, that is to the
                | looked at point in the scene,  the sight, up, and right directions,
                | defining a 3D axis system with the eye location as origin, the
                | projection type chosen among perspective (conic) and parallel
                | (cylindric),  and the zoom factor. The right direction is not exposed
                | in a property, and is automatically computed from the sight and up
                | directions.

    """

    def __init__(self, catia):
        self.viewpoint3d = catia.Viewpoint3D     

    @property
    def field_of_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FieldOfView
                | o Property FieldOfView(    ) As double
                | 
                | Returns or sets the field of view associated with the viewpoint. The
                | field of view is half of the vertical angle of the viewpoint,
                | expressed in degrees. This property exists with the perspective
                | (conic) projection type only.  Example: This example retrieves in
                | HalfAngle the field of view associated with the NiceViewpoint
                | viewpoint.  HalfAngle = NiceViewpoint.FieldOfView


                | Parameters:


        """
        return self.viewpoint3d.FieldOfView

    @property
    def focus_distance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FocusDistance
                | o Property FocusDistance(    ) As double
                | 
                | Returns or sets the focus distance of the viewpoint. The focus
                | distance determines the target position, that is the point at which
                | the eye located at the origin and looking towards the sight direction
                | is looking at. It is expressed in model units.  Example: This example
                | sets the focus distance of the NiceViewpoint viewpoint to 10.
                | NiceViewpoint.FocusDistance = 10


                | Parameters:


        """
        return self.viewpoint3d.FocusDistance

    @property
    def projection_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProjectionMode
                | o Property ProjectionMode(    ) As CatProjectionMode
                | 
                | Returns or sets the projection mode.  Example: This example sets the
                | projection mode for the My3DViewer 3D viewer to catProjectionConic.
                | My3DViewer.Viewpoint3D.NavigationStyle = catProjectionConic


                | Parameters:


        """
        return self.viewpoint3d.ProjectionMode

    @property
    def zoom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Zoom
                | o Property Zoom(    ) As double
                | 
                | Returns or sets the zoom factor associated with the viewpoint. This
                | property exists with the parallel (cylindric) projection type only.
                | Example: This example retrieves in ZoomFactor the zoom factor
                | associated with the NiceViewpoint viewpoint, tests if it is greater
                | than 2, and if so, sets it to one and applies it.  ZoomFactor =
                | NiceViewpoint.Zoom If ZoomFactor > 2 Then  ZoomFactor = 1
                | NiceViewpoint.Zoom(ZoomFactor) End If


                | Parameters:


        """
        return self.viewpoint3d.Zoom

    def get_origin(self, origin):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrigin
                | o Sub GetOrigin(    CATSafeArrayVariant    origin)
                | 
                | Retrieves the coordinates of the origin of the viewpoint. These
                | coordinates are returned as an array of 3 Variants (double type).
                | Example: This example retrieves the origin of the NiceViewpoint
                | viewpoint in the origin variable.  Dim origin(2)
                | NiceViewpoint.GetOrigin origin


                | Parameters:


        """
        return self.viewpoint3d.GetOrigin(origin)

    def get_sight_direction(self, o_sight):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSightDirection
                | o Sub GetSightDirection(    CATSafeArrayVariant    oSight)
                | 
                | Gets the components of the sight direction of the viewpoint. The sight
                | direction is the line passes both by the origin of the viewpoint and
                | by the target.  Example: This example gets the sight direction of the
                | NiceViewpoint Dim sight(2) NiceViewpoint.GetSightDirection sight


                | Parameters:


        """
        return self.viewpoint3d.GetSightDirection(o_sight)

    def get_up_direction(self, o_up):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUpDirection
                | o Sub GetUpDirection(    CATSafeArrayVariant    oUp)
                | 
                | Gets the components of the up direction of the viewpoint.  Example:
                | This example gets the up direction of the NiceViewpoint.  Dim up(2)
                | NiceViewpoint.GetUpDirection up


                | Parameters:


        """
        return self.viewpoint3d.GetUpDirection(o_up)

    def put_origin(self, origin):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutOrigin
                | o Sub PutOrigin(    CATSafeArrayVariant    origin)
                | 
                | Sets the coordinates of the origin of the viewpoint. These coordinates
                | are set as an array of 3 Variants (double type).  Example: This
                | example sets the origin of the NiceViewpoint viewpoint. to the point
                | with coordinates (10, 25, 15).  NiceViewpoint.PutOrigin Array(10, 25,
                | 15)


                | Parameters:


        """
        return self.viewpoint3d.PutOrigin(origin)

    def put_sight_direction(self, o_sight):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutSightDirection
                | o Sub PutSightDirection(    CATSafeArrayVariant    oSight)
                | 
                | Sets the components of the sight direction of the viewpoint. The sight
                | direction is the line passes both by the origin of the viewpoint and
                | by the target.  Example: This example sets the sight direction of the
                | NiceViewpoint viewpoint to the direction with components (1.414,
                | 1.414, 0).  NiceViewpoint.PutSightDirection Array(1.414, 1.414, 0)


                | Parameters:


        """
        return self.viewpoint3d.PutSightDirection(o_sight)

    def put_up_direction(self, o_up):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutUpDirection
                | o Sub PutUpDirection(    CATSafeArrayVariant    oUp)
                | 
                | Sets the components of the up direction of the viewpoint.  Example:
                | This example sets the up direction of the NiceViewpoint viewpoint to
                | the direction with components (0, 0, 1).  NiceViewpoint.PutUpDirection
                | Array(0, 0, 1)


                | Parameters:


        """
        return self.viewpoint3d.PutUpDirection(o_up)

