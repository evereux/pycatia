#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatTreeSizeTypeEnum:
    """
        .. note::
            CAA V5 Visual Basic help

                | Types for the size of the text in the specification tree.Role: This
                | enum is used in theactivateLinkAnchor('TreeVizManipSettingAtt','','Tre
                | eVizManipSettingAtt')interface.

    """

    def __init__(self, catia):
        self.cattreesizetypeenum = catia.CatTreeSizeTypeEnum     

