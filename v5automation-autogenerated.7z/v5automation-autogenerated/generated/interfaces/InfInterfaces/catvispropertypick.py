#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatVisPropertyPick:
    """
        .. note::
            CAA V5 Visual Basic help

                | Types of Pick/NoPick states.Role: This enum is used in
                | theactivateLinkAnchor('VisPropertySet','','VisPropertySet')interface.

    """

    def __init__(self, catia):
        self.catvispropertypick = catia.CatVisPropertyPick     

