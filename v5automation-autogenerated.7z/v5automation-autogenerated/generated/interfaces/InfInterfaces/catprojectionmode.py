#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatProjectionMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Projection modes.They are used by
                | theactivateLinkAnchor('Viewpoint3D','','Viewpoint3D')object.

    """

    def __init__(self, catia):
        self.catprojectionmode = catia.CatProjectionMode     

