#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class TextStream:
    """
        .. note::
            CAA V5 Visual Basic help

                | The textstream object allows to manage input and output  for a text
                | stream.

    """

    def __init__(self, catia):
        self.textstream = catia.TextStream     

    @property
    def at_end_of_line(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AtEndOfLine
                | o Property AtEndOfLine(    ) As boolean
                | 
                | Returns a boolean value which specifies if the  index position in the
                | stream is at a end of line. Example: This example retrieves in EndLine
                | the end of line value for  the TextStream TestStream.  Dim EndLine As
                | Boolean EndLine = TestStream.AtEndOfLine


                | Parameters:


        """
        return self.textstream.AtEndOfLine

    @property
    def at_end_of_stream(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AtEndOfStream
                | o Property AtEndOfStream(    ) As boolean
                | 
                | Returns a boolean value which specifies if the  index position in the
                | stream is at a end of stream. Example: This example retrieves in
                | EndStream the end of stream value for  the TextStream TestStream.  Dim
                | EndStream As Boolean EndStream = TestStream.AtEndOfStream


                | Parameters:


        """
        return self.textstream.AtEndOfStream

    def close(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Close
                | o Sub Close(    )
                | 
                | Closes a text stream. Example: This example closes the TextStream
                | TestStream TestStream.Close


                | Parameters:


        """
        return self.textstream.Close()

    def read(self, i_num_of_char):
        """
        .. note::
            CAA V5 Visual Basic help

                | Read
                | o Func Read(    long    iNumOfChar) As CATBSTR
                | 
                | Returns a string which contains a given number of characters from the
                | current position in the stream.


                | Parameters:
                | iNumOfChar
                |    The number of characters to read.  
                |  
                | 
                |  Returns:
                |   oReadString	 The retrieved string.


                | Examples:
                | 
                | 
                | This example retrieves the next fifty characters
                | of the TextStream TestStream in the
                | stream ReadString.
                | 
                | Dim ReadString As String
                | Set ReadString = TestStream.Read(50)
                | 
                | 
                | 
                | 
        """
        return self.textstream.Read(i_num_of_char)

    def read_line(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReadLine
                | o Func ReadLine(    ) As CATBSTR
                | 
                | Returns a string which contains a line of charaters from the current
                | position in the stream.  Returns:  oReadLine        The retrieved read
                | line.   Example: This example retrieves the next line  of the
                | TextStream TestStream in the  stream ReadString.  Dim ReadString As
                | String Set ReadString = TestStream.ReadLine


                | Parameters:


        """
        return self.textstream.ReadLine()

    def write(self, i_written_string):
        """
        .. note::
            CAA V5 Visual Basic help

                | Write
                | o Sub Write(    CATBSTR    iWrittenString)
                | 
                | Writes a string  in the text stream.


                | Parameters:
                | iWrittenString
                |    The string to write in the stream.


                | Examples:
                | 
                | 
                | This example write a string in the
                | the TextStream TestStream.
                | 
                | TestStream.Write("This is a test")
                | 
                | 
                | 
                | 
                | 
        """
        return self.textstream.Write(i_written_string)

