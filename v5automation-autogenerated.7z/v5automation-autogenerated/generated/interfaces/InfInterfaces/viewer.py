#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Viewer:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the viewer.The viewer is the object that makes your objects
                | display on the screen.

    """

    def __init__(self, catia):
        self.viewer = catia.Viewer     

    @property
    def full_screen(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FullScreen
                | o Property FullScreen(    ) As boolean
                | 
                | Returns or sets the state of a viewer to occupy the whole screen. True
                | if the viewer occupies the whole screen.  Example: This example
                | retrieves in IsFullScreen whether the MyViewer viewer occupies the
                | whole screen.  IsFullScreen = MyViewer.FullScreen


                | Parameters:


        """
        return self.viewer.FullScreen

    @property
    def height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Height
                | o Property Height(    ) As long
                | 
                | Returns the viewer's height, in pixels.  Example: This example
                | retrieves the height of the MyViewer viewer.   h = MyViewer.Height


                | Parameters:


        """
        return self.viewer.Height

    @property
    def width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Width
                | o Property Width(    ) As long
                | 
                | Returns the viewer's width, in pixels.  Example: This example
                | retrieves the width of the MyViewer viewer.  w = MyViewer.Width


                | Parameters:


        """
        return self.viewer.Width

    def activate(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activate
                | o Sub Activate(    )
                | 
                | Activates the viewer in the window.  Example: This example activates
                | Viewers(1) in the window MyWindow.  MyWindow.Viewers(1).Activate()


                | Parameters:


        """
        return self.viewer.Activate()

    def capture_to_file(self, i_format, i_file):
        """
        .. note::
            CAA V5 Visual Basic help

                | CaptureToFile
                | o Sub CaptureToFile(    CatCaptureFormat    iFormat,
                |                         CATBSTR    iFile)
                | 
                | Captures the actually displayed scene by the viewer as an image, and
                | stores the image in a file. Clipped parts of the scene are also
                | clipped in the captured image. Images can be captured as CGM, EMF,
                | TIFF, TIFF Greyscale,  BMP, and JPEG images.


                | Parameters:
                | iFormat
                |    The format in which the image will be created
                |  
                |  iFile
                |    The full pathname of the file into which you want to store the
                |    captured image


                | Examples:
                | 
                | 
                | This example captures the displayed part of the
                | MyViewer viewer as a BMP image, and stores it in the
                | e:\MyImage.bmp file.
                | 
                | MyViewer.CaptureToFile catCaptureFormatBMP, "e:\MyImage.bmp"
                | 
                | 
                | 
                | 
        """
        return self.viewer.CaptureToFile(i_format, i_file)

    def get_background_color(self, color):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBackgroundColor
                | o Sub GetBackgroundColor(    CATSafeArrayVariant    color)
                | 
                | Gets the viewer's background color. The color is expressed in the RGB
                | color mode, as a triplet of coordinates ranging from 0 to 1 for the
                | red, green, and blue colors respectively.  Example: This example gets
                | the background color of the MyViewer viewer.  Dim color(2)
                | MyViewer.GetBackgroundColor color


                | Parameters:


        """
        return self.viewer.GetBackgroundColor(color)

    def new_camera(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NewCamera
                | o Func NewCamera(    ) As Camera
                | 
                | Creates a new camera from the viewpoint of the viewer.  Example: This
                | example creates the MyCamera new camera by using the current viewpoint
                | of the MyViewer viewer.  Dim MyCamera As Camera Set MyCamera =
                | MyViewer.NewCamera()


                | Parameters:


        """
        return self.viewer.NewCamera()

    def put_background_color(self, color):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutBackgroundColor
                | o Sub PutBackgroundColor(    CATSafeArrayVariant    color)
                | 
                | Sets the viewer's background color. The color is expressed in the RGB
                | color mode, as a triplet of coordinates ranging from 0 to 1 for the
                | red, green, and blue colors respectively.  Example: This example sets
                | the background color of the MyViewer viewer  to blue, that is the
                | color with (0.,0.,1.) coordinates  MyViewer.PutBackgroundColor
                | Array(0, 0, 1)


                | Parameters:


        """
        return self.viewer.PutBackgroundColor(color)

    def reframe(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Reframe
                | o Sub Reframe(    )
                | 
                | Reframes the viewer's contents (Fits all in). Reframing means that the
                | viewer's contents is zoomed in or out to enable every object of the
                | scene to be displayed in such a way that most of the space available
                | in the viewer is used, just leaving a thin empty strip around the
                | scene.  Example: This example reframes the contents of the MyViewer
                | viewer.  MyViewer.Reframe()


                | Parameters:


        """
        return self.viewer.Reframe()

    def update(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Update
                | o Sub Update(    )
                | 
                | Updates the viewer's contents. Since the viewer is not automatically
                | updated after a viewpoint  modification (for performance reasons), it
                | must be explicitely redrawn when needed.  Example: This example
                | updates the contents of the MyViewer viewer.  MyViewer.Update()


                | Parameters:


        """
        return self.viewer.Update()

    def zoom_in(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ZoomIn
                | o Sub ZoomIn(    )
                | 
                | Zooms in the viewer's contents.  Example: This example zooms in the
                | contents of the MyViewer viewer.  MyViewer.ZoomIn()


                | Parameters:


        """
        return self.viewer.ZoomIn()

    def zoom_out(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ZoomOut
                | o Sub ZoomOut(    )
                | 
                | Zooms out the viewer's contents.  Example: This example zooms out the
                | contents of the MyViewer viewer.  MyViewer.ZoomOut()


                | Parameters:


        """
        return self.viewer.ZoomOut()

