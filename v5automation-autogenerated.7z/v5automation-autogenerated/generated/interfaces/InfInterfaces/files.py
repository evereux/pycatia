#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Files:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all the file objects in a folder.It lists all the
                | files contained in the folder.  It allows to
                | retrieveactivateLinkAnchor('File','','File')objects.

    """

    def __init__(self, catia):
        self.files = catia.Files     

    def item(self, i_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    long    iNumber) As File
                | 
                | Returns a file using its index or its name from the file collection.


                | Parameters:
                | iIndex
                |    The index or the name of the file to retrieve from
                |    the collection of files.
                |    As a numerics, this index is the rank of the file
                |    in the collection.
                |    The index of the first file in the collection is 1, and
                |    the index of the last file is Count.
                |    As a string, it is the name you assigned to the file using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved file


                | Examples:
                | 
                | 
                | This example retrieves in ThisFile the third file,
                | and it ThatFile the file named MyFile.
                | in the TestFiles file collection.
                | 
                | Dim ThisFile As File
                | Set ThisFile = TestFiles.Item(3)
                | Dim ThatFile As File
                | Set ThatFile = TestFiles.Item("MyFile")
                | 
                | 
                | 
        """
        return self.files.Item(i_number)

