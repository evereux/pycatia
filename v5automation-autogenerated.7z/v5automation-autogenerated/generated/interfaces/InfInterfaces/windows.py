#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Windows:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all the Window objects currently managed by the
                | application.

    """

    def __init__(self, catia):
        self.windows = catia.Windows     

    def arrange(self, i_style):
        """
        .. note::
            CAA V5 Visual Basic help

                | Arrange
                | o Sub Arrange(    CatArrangeStyle    iStyle)
                | 
                | Arranges all the windows of the collection.


                | Parameters:
                | iStyle
                |    The arrangement style to take into account to arrange the windows


                | Examples:
                | 
                | 
                | The following example arranges all the windows in the Windows
                | collection, according to the catArrangeCascade style.
                | 
                | CATIA.Windows.Arrange(catArrangeCascade)
                | 
                | 
                | 
        """
        return self.windows.Arrange(i_style)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As Window
                | 
                | Returns a window using its index or its name from the Windows
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the window to retrieve from
                |    the collection of windows.
                |    As a numerics, this index is the rank of the window
                |    in the collection.
                |    The index of the first window in the collection is 1, and
                |    the index of the last window is Count.
                |    As a string, it is the name you assigned to the window using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved window


                | Examples:
                | 
                | 
                | This example returns in ThisWindow the third window
                | in the collection, and in ThatWindow the window named
                | MyWindow.
                | 
                | Dim ThisWindow As Window
                | Set ThisWindow = CATIA.Windows.Item(3)
                | Dim ThatWindow As Window
                | Set ThatWindow = CATIA.Windows.Item("MyWindow")
                | 
                | 
                | 
        """
        return self.windows.Item(i_index)

