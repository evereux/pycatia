#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Viewpoint2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the 2D viewpoint.The 2D viewpoint is the object that stores
                | data which defines how your objects are seen to enable their display
                | by a 2D viewer. This data includes namely the origin of the scene,
                | that is the center of the displayed area, and the zoom factor.

    """

    def __init__(self, catia):
        self.viewpoint2d = catia.Viewpoint2D     

    @property
    def zoom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Zoom
                | o Property Zoom(    ) As double
                | 
                | Returns or sets the zoom factor associated with the viewpoint.
                | Example: This example retrieves in ZoomFactor the zoom factor
                | associated with the NiceViewpoint viewpoint, tests if it is less than
                | 1, and if so, sets it to one and applies it to the viewpoint.
                | ZoomFactor = NiceViewpoint.Zoom If ZoomFactor < 1 Then  ZoomFactor = 1
                | NiceViewpoint.Zoom(ZoomFactor) End If


                | Parameters:


        """
        return self.viewpoint2d.Zoom

    def get_origin(self, o_origin):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrigin
                | o Sub GetOrigin(    CATSafeArrayVariant    oOrigin)
                | 
                | Gets the coordinates of the origin of the viewpoint.  Example: This
                | example Gets the origin of the NiceViewpoint viewpoint.  Dim origin(1)
                | NiceViewpoint.GetOrigin origin


                | Parameters:


        """
        return self.viewpoint2d.GetOrigin(o_origin)

    def put_origin(self, o_origin):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutOrigin
                | o Sub PutOrigin(    CATSafeArrayVariant    oOrigin)
                | 
                | Sets the coordinates of the origin of the viewpoint.  Example: This
                | example sets the origin of the NiceViewpoint viewpoint to the point
                | with coordinates (5, 8).  NiceViewpoint.PutOrigin Array(5, 8)


                | Parameters:


        """
        return self.viewpoint2d.PutOrigin(o_origin)

