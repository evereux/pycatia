#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DocumentationSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Setting controller for the Help property tab page.Role: This interface
                | is implemented by a component which represents the controller of the
                | documentation settings.

    """

    def __init__(self, catia):
        self.documentationsettingatt = catia.DocumentationSettingAtt     

    @property
    def companion_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CompanionPath
                | o Property CompanionPath(    ) As CATBSTR
                | 
                | Returns the User Companion location (path) parameter.


                | Parameters:


        """
        return self.documentationsettingatt.CompanionPath

    @property
    def doc_language(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DocLanguage
                | o Property DocLanguage(    ) As long
                | 
                | Returns the technical documentation language parameter.


                | Parameters:


        """
        return self.documentationsettingatt.DocLanguage

    @property
    def priority(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Priority
                | o Property Priority(    ) As CATDocContextualPriority
                | 
                | Returns the contextual priority parameter.


                | Parameters:


        """
        return self.documentationsettingatt.Priority

    @property
    def technical_documentation_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TechnicalDocumentationPath
                | o Property TechnicalDocumentationPath(    ) As CATBSTR
                | 
                | Returns the technical documentation location (path) parameter.


                | Parameters:


        """
        return self.documentationsettingatt.TechnicalDocumentationPath

    def get_companion_path_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCompanionPathInfo
                | o Func GetCompanionPathInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the User Companion location
                | parameter. Role:Retrieves the state of the User Companion location
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.documentationsettingatt.GetCompanionPathInfo(io_admin_level, io_locked)

    def get_doc_language_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDocLanguageInfo
                | o Func GetDocLanguageInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the technical documentation
                | language parameter. Role:Retrieves the state of the technical
                | documentation language parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.documentationsettingatt.GetDocLanguageInfo(io_admin_level, io_locked)

    def get_priority_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPriorityInfo
                | o Func GetPriorityInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the contextual priority
                | parameter. Role:Retrieves the state of the contextual priority
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.documentationsettingatt.GetPriorityInfo(io_admin_level, io_locked)

    def get_technical_documentation_path_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnicalDocumentationPathInfo
                | o Func GetTechnicalDocumentationPathInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the technical documentation
                | location parameter. Role:Retrieves the state of the technical
                | documentation location parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.documentationsettingatt.GetTechnicalDocumentationPathInfo(io_admin_level, io_locked)

    def set_companion_path_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCompanionPathLock
                | o Sub SetCompanionPathLock(    boolean    iLocked)
                | 
                | Locks or unlocks the User Companion location parameter. Role:Locks or
                | unlocks the User Companion location parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.documentationsettingatt.SetCompanionPathLock(i_locked)

    def set_doc_language_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDocLanguageLock
                | o Sub SetDocLanguageLock(    boolean    iLocked)
                | 
                | Locks or unlocks the technical documentation language parameter.
                | Role:Locks or unlocks the technical documentation language parameter
                | if it is possible in the current administrative context. In user mode
                | this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.documentationsettingatt.SetDocLanguageLock(i_locked)

    def set_priority_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPriorityLock
                | o Sub SetPriorityLock(    boolean    iLocked)
                | 
                | Locks or unlocks the contextual priority parameter. Role:Locks or
                | unlocks the contextual priority parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.documentationsettingatt.SetPriorityLock(i_locked)

    def set_technical_documentation_path_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTechnicalDocumentationPathLock
                | o Sub SetTechnicalDocumentationPathLock(    boolean    iLocked)
                | 
                | Locks or unlocks the technical documentation location parameter.
                | Role:Locks or unlocks the technical documentation location parameter
                | if it is possible in the current administrative context. In user mode
                | this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.documentationsettingatt.SetTechnicalDocumentationPathLock(i_locked)

