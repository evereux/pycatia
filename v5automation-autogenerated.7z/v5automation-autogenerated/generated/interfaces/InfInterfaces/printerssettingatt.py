#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class PrintersSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a setting controller for the printer settings.Role: This
                | interface is implemented by a component which represents the
                | controller of the printer settings.

    """

    def __init__(self, catia):
        self.printerssettingatt = catia.PrintersSettingAtt     

    def add_printer_directory(self, i_printer_dir, i_printer_dir_state):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPrinterDirectory
                | o Sub AddPrinterDirectory(    CATBSTR    iPrinterDir,
                |                               CatPrinterDirState    iPrinterDirState)
                | 
                | Add a printer file directory to printer directories list and define
                | its state.


                | Parameters:
                | iPrinterDir
                |   directory where some 3DPLM printers are defined.
                |   The printers defined in this directory will be available for each user. 
                |  
                |  iPrinterDirState
                |    printer directory state.
                |   Each directory can be protected to prevent user access to the printers it contains.
                |   The state could be protect or free.
                |   If the state is CatPrinterDirProtect, the parameters of each printer included in the directory 
                |   cannot be changed.
                |   If the state is CatPrinterDirFree, the parameters of each printer included in the directory 
                |   can be changed, and the printers can be removed.
                |       Legal values:
                |       CatPrinterDirProtect : the printers included in the directory are protected.
                |       CatPrinterDirFree : the printers included in the directory are free.


        """
        return self.printerssettingatt.AddPrinterDirectory(i_printer_dir, i_printer_dir_state)

    def add_printer_group(self, i_printer_group_name, i_printer_names):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPrinterGroup
                | o Sub AddPrinterGroup(    CATBSTR    iPrinterGroupName,
                |                           CATSafeArrayVariant    iPrinterNames)
                | 
                | Add a printer group and define the printers included in this group.


                | Parameters:
                | iPrinterGroupName
                |    printer group name
                |  
                |  iPrinterNames
                |   array of printers included in the group.


        """
        return self.printerssettingatt.AddPrinterGroup(i_printer_group_name, i_printer_names)

    def get_driver_configuration_path(self, o_driver_cfg_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDriverConfigurationPath
                | o Sub GetDriverConfigurationPath(    CATBSTR    oDriverCfgPath)
                | 
                | Returns the driver configuration file.


                | Parameters:
                | oDriverCfgPath
                |    path of the driver configuration file


        """
        return self.printerssettingatt.GetDriverConfigurationPath(o_driver_cfg_path)

    def get_driver_configuration_path_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDriverConfigurationPathInfo
                | o Func GetDriverConfigurationPathInfo(    CATBSTR    oAdminLevel,
                |                                           CATBSTR    oLocked) As boolean
                | 
                | Retrieves environment informations for the driver configuration file.
                | Role: Retrieves the state of the driver configuration file in the
                | current environment.


                | Parameters:
                | oAdminLevel
                |        If the parameter is locked, oAdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |        If the parameter is not locked, oAdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.printerssettingatt.GetDriverConfigurationPathInfo(o_admin_level, o_locked)

    def get_new_printer_directory(self, o_new_printer_dir):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNewPrinterDirectory
                | o Sub GetNewPrinterDirectory(    CATBSTR    oNewPrinterDir)
                | 
                | Returns the directory where new printers will be added.


                | Parameters:
                | oNewPrinterDir
                |    directory to add new printers
                |   Role: Each new printer created by an user is added in this directory.


        """
        return self.printerssettingatt.GetNewPrinterDirectory(o_new_printer_dir)

    def get_new_printer_directory_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNewPrinterDirectoryInfo
                | o Func GetNewPrinterDirectoryInfo(    CATBSTR    oAdminLevel,
                |                                       CATBSTR    oLocked) As boolean
                | 
                | Retrieves environment informations for the directory where printers
                | will be added. Role: Retrieves the state of the directory where
                | printers will be added in the current environment.


                | Parameters:
                | oAdminLevel
                |        If the parameter is locked, oAdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |        If the parameter is not locked, oAdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.printerssettingatt.GetNewPrinterDirectoryInfo(o_admin_level, o_locked)

    def get_printer_array_for_group(self, i_printer_group_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPrinterArrayForGroup
                | o Func GetPrinterArrayForGroup(    CATBSTR    iPrinterGroupName) As CATSafeArrayVariant
                | 
                | Returns the definition of the printer group.


                | Parameters:
                | iPrinterGroupName
                |    printer group name
                |  
                | 
                |  Returns:
                |    array of printers included in the group.


        """
        return self.printerssettingatt.GetPrinterArrayForGroup(i_printer_group_name)

    def get_printer_directories(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPrinterDirectories
                | o Func GetPrinterDirectories(    ) As CATSafeArrayVariant
                | 
                | Returns the directories of printer files.  Returns:   array of
                | directories where 3DPLM printers are defined.


                | Parameters:


        """
        return self.printerssettingatt.GetPrinterDirectories()

    def get_printer_directories_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPrinterDirectoriesInfo
                | o Func GetPrinterDirectoriesInfo(    CATBSTR    oAdminLevel,
                |                                      CATBSTR    oLocked) As boolean
                | 
                | Retrieves environment informations for the directories of printer
                | files and their states. Role: Retrieves the state of the directories
                | of printer files and their states in the current environment.


                | Parameters:
                | oAdminLevel
                |        If the parameter is locked, oAdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |        If the parameter is not locked, oAdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.printerssettingatt.GetPrinterDirectoriesInfo(o_admin_level, o_locked)

    def get_printer_directory_state(self, i_printer_dir):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPrinterDirectoryState
                | o Func GetPrinterDirectoryState(    CATBSTR    iPrinterDir) As CatPrinterDirState
                | 
                | Returns the state of the directory of printer files.


                | Parameters:
                | iPrinterDir
                |    directory where some 3DPLM printers are defined.
                |  
                | 
                |  Returns:
                |    printer directory state.
                |   Each directory can be protected to prevent user access to the printers it contains.
                |   The state could be protect or free.
                |   If the state is CatPrinterDirProtect, the parameters of each printer included in the directory 
                |   cannot be changed.
                |   If the state is CatPrinterDirFree, the parameters of each printer included in the directory 
                |   can be changed, and the printers can be removed.
                |       Legal values:
                |       CatPrinterDirProtect : the printers included in the directory are protected.
                |       CatPrinterDirFree : the printers included in the directory are free.


        """
        return self.printerssettingatt.GetPrinterDirectoryState(i_printer_dir)

    def get_printer_groups(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPrinterGroups
                | o Func GetPrinterGroups(    ) As CATSafeArrayVariant
                | 
                | Returns the printer groups.  Returns:   array of printer group names


                | Parameters:


        """
        return self.printerssettingatt.GetPrinterGroups()

    def get_printer_groups_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPrinterGroupsInfo
                | o Func GetPrinterGroupsInfo(    CATBSTR    oAdminLevel,
                |                                 CATBSTR    oLocked) As boolean
                | 
                | Retrieves environment informations for the definition of each printer
                | group. Role: Retrieves the state of the definition of each printer
                | group in the current environment.


                | Parameters:
                | oAdminLevel
                |        If the parameter is locked, oAdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |        If the parameter is not locked, oAdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.printerssettingatt.GetPrinterGroupsInfo(o_admin_level, o_locked)

    def modify_printer_array_for_group(self, i_printer_group_name, i_printer_names):
        """
        .. note::
            CAA V5 Visual Basic help

                | ModifyPrinterArrayForGroup
                | o Sub ModifyPrinterArrayForGroup(    CATBSTR    iPrinterGroupName,
                |                                      CATSafeArrayVariant    iPrinterNames)
                | 
                | Modify a printer group: redefine the array of printers included in
                | this group.


                | Parameters:
                | iPrinterGroupName
                |    printer group name
                |  
                |  iPrinterNames
                |   array of printers included in the group.


        """
        return self.printerssettingatt.ModifyPrinterArrayForGroup(i_printer_group_name, i_printer_names)

    def modify_printer_directory_state(self, i_printer_dir, i_printer_dir_state):
        """
        .. note::
            CAA V5 Visual Basic help

                | ModifyPrinterDirectoryState
                | o Sub ModifyPrinterDirectoryState(    CATBSTR    iPrinterDir,
                |                                       CatPrinterDirState    iPrinterDirState)
                | 
                | Modify a printer file directory state.


                | Parameters:
                | iPrinterDir
                |   directory where some 3DPLM printers are defined.
                |  
                |  iPrinterDirState
                |    printer directory state.
                |   Each directory can be protected to prevent user access to the printers it contains.
                |   The state could be protect or free.
                |   If the state is CatPrinterDirProtect, the parameters of each printer included in the directory 
                |   cannot be changed.
                |   If the state is CatPrinterDirFree, the parameters of each printer included in the directory 
                |   can be changed, and the printers can be removed.
                |       Legal values:
                |       CatPrinterDirProtect : the printers included in the directory are protected.
                |       CatPrinterDirFree : the printers included in the directory are free.


        """
        return self.printerssettingatt.ModifyPrinterDirectoryState(i_printer_dir, i_printer_dir_state)

    def remove_all_printer_directories(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAllPrinterDirectories
                | o Sub RemoveAllPrinterDirectories(    )
                | 
                | Remove all the directories including printer files.


                | Parameters:


        """
        return self.printerssettingatt.RemoveAllPrinterDirectories()

    def remove_all_printer_groups(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAllPrinterGroups
                | o Sub RemoveAllPrinterGroups(    )
                | 
                | Remove all the groups of printers.


                | Parameters:


        """
        return self.printerssettingatt.RemoveAllPrinterGroups()

    def remove_printer_directory(self, i_printer_dir):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePrinterDirectory
                | o Sub RemovePrinterDirectory(    CATBSTR    iPrinterDir)
                | 
                | Remove a directory of printer files from the directories list.


                | Parameters:
                | iPrinterDir
                |    directory where some 3DPLM printers are defined.


        """
        return self.printerssettingatt.RemovePrinterDirectory(i_printer_dir)

    def remove_printer_group(self, i_printer_group_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePrinterGroup
                | o Sub RemovePrinterGroup(    CATBSTR    iPrinterGroupName)
                | 
                | Remove a group of printers.


                | Parameters:
                | iPrinterGroupName
                |    name of the group to remove.


        """
        return self.printerssettingatt.RemovePrinterGroup(i_printer_group_name)

    def set_driver_configuration_path(self, i_driver_cfg_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDriverConfigurationPath
                | o Sub SetDriverConfigurationPath(    CATBSTR    iDriverCfgPath)
                | 
                | Sets the driver configuration file.


                | Parameters:
                | iDriverCfgPath
                |    path of the driver configuration file


        """
        return self.printerssettingatt.SetDriverConfigurationPath(i_driver_cfg_path)

    def set_driver_configuration_path_lock(self, i_lock):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDriverConfigurationPathLock
                | o Sub SetDriverConfigurationPathLock(    boolean    iLock)
                | 
                | Locks or unlocks the driver configuration file. Role: Locks or unlocks
                | the driver configuration file if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |       the locking operation to be performed
                |       Legal values:
                |       TRUE :   to lock the parameter.
                |       FALSE:   to unlock the parameter.


        """
        return self.printerssettingatt.SetDriverConfigurationPathLock(i_lock)

    def set_new_printer_directory(self, i_new_printer_dir):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNewPrinterDirectory
                | o Sub SetNewPrinterDirectory(    CATBSTR    iNewPrinterDir)
                | 
                | Sets the directory where new printers will be added.


                | Parameters:
                | iNewPrinterDir
                |    directory to add new printers
                |   Role: Each new printer created by an user is added in this directory.


        """
        return self.printerssettingatt.SetNewPrinterDirectory(i_new_printer_dir)

    def set_new_printer_directory_lock(self, i_lock):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNewPrinterDirectoryLock
                | o Sub SetNewPrinterDirectoryLock(    boolean    iLock)
                | 
                | Locks or unlocks the directory where printers will be added. Role:
                | Locks or unlocks the directory where printers will be added if it is
                | possible in the current administrative context. In user mode this
                | method will always return E_FAIL.


                | Parameters:
                | iLocked
                |       the locking operation to be performed
                |       Legal values:
                |       TRUE :   to lock the parameter.
                |       FALSE:   to unlock the parameter.


        """
        return self.printerssettingatt.SetNewPrinterDirectoryLock(i_lock)

    def set_printer_directories_lock(self, i_lock):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPrinterDirectoriesLock
                | o Sub SetPrinterDirectoriesLock(    boolean    iLock)
                | 
                | Locks or unlocks the directories of printer files and their states.
                | Role: Locks or unlocks the directories of printer files and their
                | states if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |       the locking operation to be performed
                |       Legal values:
                |       TRUE :   to lock the parameter.
                |       FALSE:   to unlock the parameter.


        """
        return self.printerssettingatt.SetPrinterDirectoriesLock(i_lock)

    def set_printer_groups_lock(self, i_lock):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPrinterGroupsLock
                | o Sub SetPrinterGroupsLock(    boolean    iLock)
                | 
                | Locks or unlocks the definition of each printer group. Role: Locks or
                | unlocks the definition of each printer group if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                |       the locking operation to be performed
                |       Legal values:
                |       TRUE :   to lock the parameter.
                |       FALSE:   to unlock the parameter.


        """
        return self.printerssettingatt.SetPrinterGroupsLock(i_lock)

