#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatImageRotation:
    """
        .. note::
            CAA V5 Visual Basic help

                | Image rotation.It is used by
                | theactivateLinkAnchor('PageSetup','','PageSetup')object for document
                | printing. The image rotation angle is counted clockwise.

    """

    def __init__(self, catia):
        self.catimagerotation = catia.CatImageRotation     

