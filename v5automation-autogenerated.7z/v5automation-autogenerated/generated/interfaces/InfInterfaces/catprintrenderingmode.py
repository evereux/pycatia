#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatPrintRenderingMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Print rendering mode.It is used by
                | theactivateLinkAnchor('PageSetup','','PageSetup')object for document
                | printing. The print rendering ranges
                | fromcatPrintRenderingModeDefaulttocatPrintRenderingModeOnScreen. The
                | print rendering mode are :

    """

    def __init__(self, catia):
        self.catprintrenderingmode = catia.CatPrintRenderingMode     

