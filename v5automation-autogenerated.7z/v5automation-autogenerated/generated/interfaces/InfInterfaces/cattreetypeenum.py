#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatTreeTypeEnum:
    """
        .. note::
            CAA V5 Visual Basic help

                | Types for the specification tree.Role: This enum is used in theactivat
                | eLinkAnchor('TreeVizManipSettingAtt','','TreeVizManipSettingAtt')inter
                | face.

    """

    def __init__(self, catia):
        self.cattreetypeenum = catia.CatTreeTypeEnum     

