#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class MacrosSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Setting controller for the Macros tab page.

    """

    def __init__(self, catia):
        self.macrossettingatt = catia.MacrosSettingAtt     

    def get_default_macro_libraries(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultMacroLibraries
                | o Func GetDefaultMacroLibraries(    ) As CATSafeArrayVariant
                | 
                | Returns the list of default macro libraries.


                | Parameters:


        """
        return self.macrossettingatt.GetDefaultMacroLibraries()

    def get_default_macro_libraries_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultMacroLibrariesInfo
                | o Func GetDefaultMacroLibrariesInfo(    CATBSTR    AdminLevel,
                |                                         CATBSTR    oLocked) As boolean
                | 
                | Retrieves environment informations for the default macro libraries
                | setting. Role:Retrieves the state of the parameter default macro
                | libraries setting  in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |       Indicates if the parameter has been locked.
                |  
                |  oModified
                |       Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.macrossettingatt.GetDefaultMacroLibrariesInfo(admin_level, o_locked)

    def get_external_references(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExternalReferences
                | o Func GetExternalReferences(    ) As CATSafeArrayVariant
                | 
                | Returns the list of external references.


                | Parameters:


        """
        return self.macrossettingatt.GetExternalReferences()

    def get_external_references_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExternalReferencesInfo
                | o Func GetExternalReferencesInfo(    CATBSTR    AdminLevel,
                |                                      CATBSTR    oLocked) As boolean
                | 
                | Retrieves environment informations for the external references
                | setting. Role:Retrieves the state of the parameter external references
                | setting  in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |       Indicates if the parameter has been locked.
                |  
                |  oModified
                |       Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.macrossettingatt.GetExternalReferencesInfo(admin_level, o_locked)

    def get_language_editor(self, i_language):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLanguageEditor
                | o Func GetLanguageEditor(    CATScriptLanguage    iLanguage) As CATBSTR
                | 
                | Returns the editor path for the specified language.


                | Parameters:


        """
        return self.macrossettingatt.GetLanguageEditor(i_language)

    def get_language_editor_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLanguageEditorInfo
                | o Func GetLanguageEditorInfo(    CATBSTR    AdminLevel,
                |                                  CATBSTR    oLocked) As boolean
                | 
                | Retrieves environment informations for the language editors setting.
                | Role:Retrieves the state of the parameter language editors setting  in
                | the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |       Indicates if the parameter has been locked.
                |  
                |  oModified
                |       Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.macrossettingatt.GetLanguageEditorInfo(admin_level, o_locked)

    def set_default_macro_libraries(self, i_libraries):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultMacroLibraries
                | o Sub SetDefaultMacroLibraries(    CATSafeArrayVariant    iLibraries)
                | 
                | Sets the list of default macro libraries.


                | Parameters:


        """
        return self.macrossettingatt.SetDefaultMacroLibraries(i_libraries)

    def set_default_macro_libraries_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultMacroLibrariesLock
                | o Sub SetDefaultMacroLibrariesLock(    boolean    iLocked)
                | 
                | Locks or unlocks the default macro libraries setting. Role:Locks or
                | unlocks the default macro libraries setting if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	True :   to lock the parameter.
                |  	False:   to unlock the parameter.


        """
        return self.macrossettingatt.SetDefaultMacroLibrariesLock(i_locked)

    def set_external_references(self, i_references):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExternalReferences
                | o Sub SetExternalReferences(    CATSafeArrayVariant    iReferences)
                | 
                | Sets the list of external references.


                | Parameters:


        """
        return self.macrossettingatt.SetExternalReferences(i_references)

    def set_external_references_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExternalReferencesLock
                | o Sub SetExternalReferencesLock(    boolean    iLocked)
                | 
                | Locks or unlocks the external references setting. Role:Locks or
                | unlocks the external references setting if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	True :   to lock the parameter.
                |  	False:   to unlock the parameter.


        """
        return self.macrossettingatt.SetExternalReferencesLock(i_locked)

    def set_language_editor(self, i_language, i_editor_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLanguageEditor
                | o Sub SetLanguageEditor(    CATScriptLanguage    iLanguage,
                |                             CATBSTR    iEditorPath)
                | 
                | Sets the editor path for the specified language.


                | Parameters:


        """
        return self.macrossettingatt.SetLanguageEditor(i_language, i_editor_path)

    def set_language_editor_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLanguageEditorLock
                | o Sub SetLanguageEditorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the language editors setting. Role:Locks or unlocks
                | the language editors setting if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	True :   to lock the parameter.
                |  	False:   to unlock the parameter.


        """
        return self.macrossettingatt.SetLanguageEditorLock(i_locked)

