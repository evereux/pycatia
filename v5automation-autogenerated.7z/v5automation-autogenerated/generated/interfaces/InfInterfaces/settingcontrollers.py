#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SettingControllers:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all the setting controllers objects currently managed
                | by the application.

    """

    def __init__(self, catia):
        self.settingcontrollers = catia.SettingControllers     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATBSTR    iIndex) As SettingController
                | 
                | Returns a setting controller using its name from the setting
                | controllers collection.


                | Parameters:
                | iIndex
                |    The name of the window to retrieve from
                |    the collection of setting controller.
                |    As a string.
                |  
                | 
                |  Returns:
                |   The retrieved setting controller.


        """
        return self.settingcontrollers.Item(i_index)

