#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Window:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the window.The window is the object that accommodates one
                | or several viewers to display your objects, and which makes the link
                | with the windowing system.

    """

    def __init__(self, catia):
        self.window = catia.Window     

    @property
    def active_viewer(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActiveViewer
                | o Property ActiveViewer(    ) As Viewer
                | 
                | Returns the active viewer in the window.  Example: This example
                | retrieves the active viewer in the CADWindow window in ViewerToWorkIn.
                | Dim ViewerToWorkIn As Viewer Set ViewerToWorkIn =
                | CADWindow.ActiveViewer


                | Parameters:


        """
        return self.window.ActiveViewer

    @property
    def caption(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Caption
                | o Property Caption(    ) As CATBSTR
                | 
                | Returns or sets the window caption. The window caption is displayed in
                | the title bar.  Example: This example sets the window caption for the
                | CADWindow window to: CAD 3D Window.  CADWindow.Caption = "CAD 3D
                | Window"


                | Parameters:


        """
        return self.window.Caption

    @property
    def height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Height
                | o Property Height(    ) As long
                | 
                | Returns or sets the window height. The window height is expressed in
                | pixels.  Example: This example sets the window height for the
                | CADWindow window to 300 pixels.  CADWindow.Width = 300


                | Parameters:


        """
        return self.window.Height

    @property
    def left(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Left
                | o Property Left(    ) As long
                | 
                | Returns or sets the distance of the window with respect to the inner
                | left side of the frame. This distance is expressed in pixels.
                | Example: This example sets the distance of the window with respect to
                | the inner left side of the frame for the CADWindow window to 150
                | pixels.  CADWindow.Left = 150


                | Parameters:


        """
        return self.window.Left

    @property
    def page_setup(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PageSetup
                | o Property PageSetup(    ) As PageSetup
                | 
                | Returns or sets the page setup of the window. The page setup includes
                | all parameters to print the window.  Example: This example sets the
                | page setup for the CADWindow window to an existing page setup for the
                | A4 paper size A4PageSetup.  CADWindow.PageSetup = A4PageSetup


                | Parameters:


        """
        return self.window.PageSetup

    @property
    def top(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Top
                | o Property Top(    ) As long
                | 
                | Returns or sets the distance of the window with respect to the inner
                | top side of the frame. This distance is expressed in pixels.  Example:
                | This example sets the distance of the window with respect to the inner
                | top side of the frame for the CADWindow window to 50 pixels.
                | CADWindow.Top = 50


                | Parameters:


        """
        return self.window.Top

    @property
    def viewers(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viewers
                | o Property Viewers(    ) As Viewers
                | 
                | Returns the collection of viewers attached to the window.  Example:
                | This example retrieves the collection of viewers attached to the
                | CADWindow window in ViewerCollection.  Dim ViewerCollection As Viewers
                | Set ViewerCollection = CADWindow.Viewers


                | Parameters:


        """
        return self.window.Viewers

    @property
    def width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Width
                | o Property Width(    ) As long
                | 
                | Returns or sets the window width. The window width is expressed in
                | pixels.  Example: This example sets the window width for the CADWindow
                | window to 450 pixels.  CADWindow.Width = 450


                | Parameters:


        """
        return self.window.Width

    @property
    def window_state(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WindowState
                | o Property WindowState(    ) As CatWindowState
                | 
                | Returns or sets the window state.  Example: This example sets the
                | window state for the CADWindow window to catWindowStateMaximized.
                | CADWindow.WindowState = catWindowStateMaximized


                | Parameters:


        """
        return self.window.WindowState

    def activate(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activate
                | o Sub Activate(    )
                | 
                | Activates a window. The active window is deactivated and the window to
                | which the method applies is activated instead.  Example: This example
                | activates the CADWindow window.  CADWindow.Activate()


                | Parameters:


        """
        return self.window.Activate()

    def activate_next(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActivateNext
                | o Sub ActivateNext(    )
                | 
                | Activates the window following the current active one in the window
                | collection.  Example: This example activates the window following the
                | current CADWindow  window in the window collection.
                | CADWindow.ActivateNext()


                | Parameters:


        """
        return self.window.ActivateNext()

    def activate_previous(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActivatePrevious
                | o Sub ActivatePrevious(    )
                | 
                | Activates the window preceding the current active one in the window
                | collection.  Example: This example activates the window preceding the
                | current CADWindow window in the window collection.
                | CADWindow.ActivatePrevious()


                | Parameters:


        """
        return self.window.ActivatePrevious()

    def close(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Close
                | o Sub Close(    )
                | 
                | Closes the window. This method displays the dialog box requesting
                | whether to save the file if the document was modified, except if the  
                | activateLinkAnchor('Application','DisplayFileAlerts','Application.Disp
                | layFileAlerts')  property was previously set to False.  Example: This
                | example closes the CADWindow window.  CADWindow.Close()


                | Parameters:


        """
        return self.window.Close()

    def new_window(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NewWindow
                | o Func NewWindow(    ) As Window
                | 
                | Creates a new window. The new window displays the same document with
                | the same viewers and viewpoints than the window to which the method
                | applies, and becomes the active one.  Example: This example creates a
                | new window named CADNewWindow from the CADWindow window.  Dim
                | CADNewWindow As Window Set CADNewWindow = CADWindow.NewWindow()


                | Parameters:


        """
        return self.window.NewWindow()

    def print_out(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintOut
                | o Sub PrintOut(    )
                | 
                | Prints the active viewer of the window according to the window's page
                | setup on the default printer.  Example: This example prints the
                | CADWindow window's active viewer on the default printer.
                | CADWindow.PrintOut()


                | Parameters:


        """
        return self.window.PrintOut()

    def print_to_file(self, file_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintToFile
                | o Sub PrintToFile(    CATBSTR    fileName)
                | 
                | Prints the active viewer of the window according to the window's page
                | setup in a file instead of being sent to a printer.


                | Parameters:
                | fileName
                |    The full pathname of the file receiving the data.


                | Examples:
                | 
                | 
                | This example prints the CADWindow window's active viewer
                | in a file.
                | 
                | CADWindow.PrintToFile("e:\temp\cadwin.prn")
                | 
                | 
                | 
        """
        return self.window.PrintToFile(file_name)

