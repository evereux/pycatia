#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SelectionSets:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to manage the Selection Sets in a document.

    """

    def __init__(self, catia):
        self.selectionsets = catia.SelectionSets     

    def add_cso_into_selection_set(self, i_sel_set_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddCSOIntoSelectionSet
                | o Sub AddCSOIntoSelectionSet(    CATBSTR    iSelSetName)
                | 
                | Adds CSO's content in a Selection Set.


                | Parameters:
                | iSelSetName
                |       The name of the Selection Set in wich the CSO has to be added.
                |    
                | 
                |  Returns:
                |        The error code of function :
                |   
                | S_OK if the content of the CSO is added
                | E_FAIL if the content of the CSO  is not added


        """
        return self.selectionsets.AddCSOIntoSelectionSet(i_sel_set_name)

    def create_selection_set(self, i_sel_set_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSelectionSet
                | o Sub CreateSelectionSet(    CATBSTR    iSelSetName)
                | 
                | Creates a new Selection Set. Role: This method creates a new Selection
                | Set.


                | Parameters:
                | iSelSetName
                |       The name of Selection Set to create.
                |    
                | 
                |  Returns:
                |        The error code of function :
                |    
                |  S_OK if the Selection Set is created 
                |  E_FAIL if a problem occurred


        """
        return self.selectionsets.CreateSelectionSet(i_sel_set_name)

    def delete_selection_set(self, i_sel_set_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | DeleteSelectionSet
                | o Sub DeleteSelectionSet(    CATBSTR    iSelSetName)
                | 
                | Deletes a Selection Set.   Role: This method removes a Selection Set
                | and all its content.


                | Parameters:
                | iSelSetName
                |       The Selection Set to delete. 
                |    
                | 
                |  Returns:
                |        The error code of function :
                |    
                |  S_OK if the method succeeded
                |  E_FAIL if a problem occurred


        """
        return self.selectionsets.DeleteSelectionSet(i_sel_set_name)

    def get_list_of_selection_set(self, o_list_of_selection_set):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetListOfSelectionSet
                | o Sub GetListOfSelectionSet(    CATSafeArrayVariant    oListOfSelectionSet)
                | 
                | Retrieves the list of Selection Sets in the document.


                | Parameters:
                | oListOfSelectionSet
                |       The list of Selection Sets in the document
                |    
                | 
                |  Returns:
                |        The error code of function :
                |   
                | S_OK if the method succeeded
                | E_FAIL if an error occurred


        """
        return self.selectionsets.GetListOfSelectionSet(o_list_of_selection_set)

    def put_selection_set_into_cso(self, i_sel_set_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutSelectionSetIntoCSO
                | o Sub PutSelectionSetIntoCSO(    CATBSTR    iSelSetName)
                | 
                | Puts Selection Set's content in the CSO.


                | Parameters:
                | iSelSetName
                |       The name of the Selection Set to put in the CSO.
                |    
                | 
                |  Returns:
                |        The error code of function :
                |   
                | S_OK if the content of the Selection Set is added in the CSO
                | E_FAIL if the content of the Selection Set is added in the CSO


        """
        return self.selectionsets.PutSelectionSetIntoCSO(i_sel_set_name)

    def rename_selection_set(self, i_old_sel_set_name, i_new_sel_set_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | RenameSelectionSet
                | o Sub RenameSelectionSet(    CATBSTR    iOldSelSetName,
                |                              CATBSTR    iNewSelSetName)
                | 
                | Renames a Selection Set.


                | Parameters:
                | iOldSelSetName
                |       The original name of the Selection Set.
                |    
                |  iNewSelSetName
                |       The new name of the Selection Set.
                |    
                | 
                |  Returns:
                |        The error code of function :
                |   
                | S_OK if the name is changed
                | E_FAIL if the name is not changed


        """
        return self.selectionsets.RenameSelectionSet(i_old_sel_set_name, i_new_sel_set_name)

