#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATDocContextualPriority:
    """
        .. note::
            CAA V5 Visual Basic help

                | The Contextual Priority setting attribute range of values.Role: This
                | enum is used in theactivateLinkAnchor('DocumentationSettingAtt','','Do
                | cumentationSettingAtt')interface.

    """

    def __init__(self, catia):
        self.catdoccontextualpriority = catia.CATDocContextualPriority     

