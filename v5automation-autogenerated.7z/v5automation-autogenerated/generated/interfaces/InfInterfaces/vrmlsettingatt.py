#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class VrmlSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAVrmlSettingAtt.This interface may be
                | used to read or modify in the
                | CATIA\Tools\Option\General\Compatibility.... the settings values of
                | the VRML sheet.

    """

    def __init__(self, catia):
        self.vrmlsettingatt = catia.VrmlSettingAtt     

    @property
    def export_edges(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportEdges
                | o Property ExportEdges(    ) As boolean
                | 
                | Returns or sets the ExportEdges parameter (exported Vrml files will or
                | will not contains edge informations).


                | Parameters:
                | oExportEdges
                |  - iExportEdges	Value of ExportEdges parameter.
                | 	Legal values:
                | 	TRUE  :   exported Vrml files will contain edge informations.
                |  	FALSE :   exported Vrml files will not contain edge informations.


        """
        return self.vrmlsettingatt.ExportEdges

    @property
    def export_normals(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportNormals
                | o Property ExportNormals(    ) As boolean
                | 
                | Returns or sets the ExportNormals parameter (exported Vrml files will
                | or will not contains normal informations).


                | Parameters:
                | oExportNormals
                |  - iExportNormals	Value of ExportNormals parameter.
                | 	Legal values:
                | 	TRUE  :   exported Vrml files will contain normal informations.
                |  	FALSE :   exported Vrml files will not contain normal informations.


        """
        return self.vrmlsettingatt.ExportNormals

    @property
    def export_texture(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportTexture
                | o Property ExportTexture(    ) As boolean
                | 
                | Returns or sets the ExportTexture parameter (exported Vrml files will
                | or will not contains texture informations).


                | Parameters:
                | oExportTexture
                |  - iExportTexture	Value of ExportTexture parameter.
                | 	Legal values:
                | 	TRUE  :   exported Vrml files will contain texture informations.
                |  	FALSE :   exported Vrml files will not contain texture informations.


        """
        return self.vrmlsettingatt.ExportTexture

    @property
    def export_texture_file(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportTextureFile
                | o Property ExportTextureFile(    ) As long
                | 
                | Returns or sets the ExportTextureFile parameter (Textures will be
                | exported in the vrml file containing the geometry or in external
                | files).


                | Parameters:
                | oExportTextureFile
                |  - iExportTextureFile	Value of ExportTextureFile parameter.
                | 	Legal values:
                | 	0 :   Textures are exported in the Vrml file containing the geometry.
                |  	1 :   Texture are exported in external files.


        """
        return self.vrmlsettingatt.ExportTextureFile

    @property
    def export_texture_format(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportTextureFormat
                | o Property ExportTextureFormat(    ) As long
                | 
                | Returns or sets the ExportTextureFormat parameter.


                | Parameters:
                | oExportTextureFormat
                |  - iExportTextureFormat Value of ExportTextureFormat parameter.
                |  Legal values:
                |   NOT APPLICABLE


        """
        return self.vrmlsettingatt.ExportTextureFormat

    @property
    def export_version(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportVersion
                | o Property ExportVersion(    ) As long
                | 
                | Returns or sets the ExportVersion parameter (version of exported Vrml
                | files).


                | Parameters:
                | oExportVersion
                |  - iExportVersion	Value of Import Unit parameter.
                | 	Legal values:
                | 	1 :   VRML 1.0.
                |  	2 :   VRML 97 (VRML 2.0).


        """
        return self.vrmlsettingatt.ExportVersion

    @property
    def import_crease_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImportCreaseAngle
                | o Property ImportCreaseAngle(    ) As double
                | 
                | Returns or sets the ImportCreaseAngle parameter. The crease angle
                | affects how DEFAULT normals are generated. If the angle between the
                | geometric normals of two adjacent faces is less than the crease angle,
                | normals will be calculated so that the faces are smooth-shaded  across
                | the edge. Otherwise, normals will be calculated so that a lighting
                | discontinuity across the edge is produce.


                | Parameters:
                | oImportCreaseAngle
                |  - iImportCreaseAngle	Value of ImportCreaseAngle parameter.
                | 	Legal values:
                | 	 [0,inf]


        """
        return self.vrmlsettingatt.ImportCreaseAngle

    @property
    def import_unit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImportUnit
                | o Property ImportUnit(    ) As long
                | 
                | Returns or sets the ImportUnit parameter (unit of imported Vrml
                | files).


                | Parameters:
                | oImportUnit
                |  - iImportUnit	Value of Import Unit parameter.
                | 	Legal values:
                | 	0 :   Millimeter.
                |  	1 :   Centimeter.
                |  	2 :   Meter.


        """
        return self.vrmlsettingatt.ImportUnit

    def get_export_background_color(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportBackgroundColor
                | o Sub GetExportBackgroundColor(    long    ioR,
                |                                    long    ioG,
                |                                    long    ioB)
                | 
                | Returns the ExportBackgroundColor parameter (Background color of
                | exported Vrml files). Value of ExportBackgroundColor parameter. Legal
                | values:   R [0,255] G [0,255] B [0,255]


                | Parameters:


        """
        return self.vrmlsettingatt.GetExportBackgroundColor(io_r, io_g, io_b)

    def get_export_background_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportBackgroundColorInfo
                | o Func GetExportBackgroundColorInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ExportBackgroundColor setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetExportBackgroundColorInfo(io_admin_level, io_locked)

    def get_export_edges_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportEdgesInfo
                | o Func GetExportEdgesInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ExportEdges setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetExportEdgesInfo(io_admin_level, io_locked)

    def get_export_normals_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportNormalsInfo
                | o Func GetExportNormalsInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ExportNormals setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetExportNormalsInfo(io_admin_level, io_locked)

    def get_export_texture_file_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportTextureFileInfo
                | o Func GetExportTextureFileInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ExportTextureFile setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetExportTextureFileInfo(io_admin_level, io_locked)

    def get_export_texture_format_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportTextureFormatInfo
                | o Func GetExportTextureFormatInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ExportTextureFormat setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetExportTextureFormatInfo(io_admin_level, io_locked)

    def get_export_texture_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportTextureInfo
                | o Func GetExportTextureInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ExportTexture setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetExportTextureInfo(io_admin_level, io_locked)

    def get_export_version_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportVersionInfo
                | o Func GetExportVersionInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ExportVersion setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetExportVersionInfo(io_admin_level, io_locked)

    def get_import_crease_angle_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetImportCreaseAngleInfo
                | o Func GetImportCreaseAngleInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ImportCreaseAngle setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetImportCreaseAngleInfo(io_admin_level, io_locked)

    def get_import_unit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetImportUnitInfo
                | o Func GetImportUnitInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ImportUnit setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.GetImportUnitInfo(io_admin_level, io_locked)

    def set_export_background_color(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportBackgroundColor
                | o Sub SetExportBackgroundColor(    long    iR,
                |                                    long    iG,
                |                                    long    iB)
                | 
                | Sets the ExportBackgroundColor parameter (Background color of exported
                | Vrml files). Value of ExportBackgroundColor parameter. Legal values:
                | R [0,255] G [0,255] B [0,255]


                | Parameters:


        """
        return self.vrmlsettingatt.SetExportBackgroundColor(i_r, i_g, i_b)

    def set_export_background_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportBackgroundColorLock
                | o Sub SetExportBackgroundColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ExportBackgroundColor setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetExportBackgroundColorLock(i_locked)

    def set_export_edges_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportEdgesLock
                | o Sub SetExportEdgesLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ExportEdges setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetExportEdgesLock(i_locked)

    def set_export_normals_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportNormalsLock
                | o Sub SetExportNormalsLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ExportNormals setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetExportNormalsLock(i_locked)

    def set_export_texture_file_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportTextureFileLock
                | o Sub SetExportTextureFileLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ExportTextureFile setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetExportTextureFileLock(i_locked)

    def set_export_texture_format_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportTextureFormatLock
                | o Sub SetExportTextureFormatLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ExportTextureFormat setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetExportTextureFormatLock(i_locked)

    def set_export_texture_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportTextureLock
                | o Sub SetExportTextureLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ExportTexture setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetExportTextureLock(i_locked)

    def set_export_version_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportVersionLock
                | o Sub SetExportVersionLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ExportVersion setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetExportVersionLock(i_locked)

    def set_import_crease_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetImportCreaseAngleLock
                | o Sub SetImportCreaseAngleLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ImportCreaseAngle setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetImportCreaseAngleLock(i_locked)

    def set_import_unit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetImportUnitLock
                | o Sub SetImportUnitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ImportLock setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.vrmlsettingatt.SetImportUnitLock(i_locked)

