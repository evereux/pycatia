#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATGenUIStyle:
    """
        .. note::
            CAA V5 Visual Basic help

                | The User Interface Style setting attribute range of values.Role: This
                | enum is used in theactivateLinkAnchor('GeneralSessionSettingAtt','','G
                | eneralSessionSettingAtt')interface.

    """

    def __init__(self, catia):
        self.catgenuistyle = catia.CATGenUIStyle     

