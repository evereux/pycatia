#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSpecsAndGeomWindowLayout:
    """
        .. note::
            CAA V5 Visual Basic help

                | Specification and geometry window layout.It is used by theactivateLink
                | Anchor('SpecsAndGeomWindow','','SpecsAndGeomWindow')object.

    """

    def __init__(self, catia):
        self.catspecsandgeomwindowlayout = catia.CatSpecsAndGeomWindowLayout     

