#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Printer:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a printer handled by the printing subsystem.This object is
                | read only and gives access to some properties of the printer.

    """

    def __init__(self, catia):
        self.printer = catia.Printer     

    @property
    def device_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DeviceName
                | o Property DeviceName(    ) As CATBSTR
                | 
                | Returns the printer device name.  Example: This example displays the
                | device name of the myPrinter printer.  MsgBox myPrinter.DeviceName


                | Parameters:


        """
        return self.printer.DeviceName

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property Orientation(    ) As CatPaperOrientation
                | 
                | Returns or sets the default paper orientation.  Example: This example
                | retrieves in DefaultPaperOrientation the default paper orientation of
                | the myPrinter printer.  Dim DefaultPaperOrientation As
                | CatPaperOrientation DefaultPaperOrientation = myPrinter.Orientation


                | Parameters:


        """
        return self.printer.Orientation

    @property
    def paper_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperHeight
                | o Property PaperHeight(    ) As float
                | 
                | Returns the default paper height.  Example: This example retrieves in
                | Height the default paper height of the myPrinter printer.  Dim Height
                | Height = myPrinter.PaperHeight


                | Parameters:


        """
        return self.printer.PaperHeight

    @property
    def paper_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperSize
                | o Property PaperSize(    ) As CatPaperSize
                | 
                | Returns the default paper size.  Example: This example retrieves in
                | DefaultPaperSize the default paper size of the myPrinter printer.  Dim
                | DefaultPaperSize As CatPaperSize DefaultPaperSize =
                | myPrinter.PaperSize


                | Parameters:


        """
        return self.printer.PaperSize

    @property
    def paper_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperWidth
                | o Property PaperWidth(    ) As float
                | 
                | Returns the default paper width.  Example: This example retrieves in
                | Witdh the default paper width of the myPrinter printer.  Dim Width As
                | float Width = myPrinter.PaperWidth


                | Parameters:


        """
        return self.printer.PaperWidth

