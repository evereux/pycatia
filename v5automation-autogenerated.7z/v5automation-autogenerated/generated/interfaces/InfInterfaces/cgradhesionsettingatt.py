#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CGRAdhesionSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the base object to handle the parameters of the cache.

    """

    def __init__(self, catia):
        self.cgradhesionsettingatt = catia.CGRAdhesionSettingAtt     

    @property
    def v4_v5_fdt(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | V4V5_FDT
                | o Property V4V5_FDT(    ) As boolean
                | 
                | Retrieves the V4V5_FDT container activation state.


                | Parameters:


        """
        return self.cgradhesionsettingatt.V4V5_FDT

    @property
    def v4__model__comment_page(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | V4_Model_CommentPage
                | o Property V4_Model_CommentPage(    ) As boolean
                | 
                | Retrieves the V4_Model_CommentPage container activation state.


                | Parameters:


        """
        return self.cgradhesionsettingatt.V4_Model_CommentPage

    @property
    def v4__model__ln_f(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | V4_Model_LnF
                | o Property V4_Model_LnF(    ) As boolean
                | 
                | Retrieves the V4_Model_LnF container activation state.


                | Parameters:


        """
        return self.cgradhesionsettingatt.V4_Model_LnF

    @property
    def v5_spa(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | V5_SPA
                | o Property V5_SPA(    ) As boolean
                | 
                | Retrieves the V5_SPA container activation state.


                | Parameters:


        """
        return self.cgradhesionsettingatt.V5_SPA

    @property
    def voxels(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Voxels
                | o Property Voxels(    ) As boolean
                | 
                | Retrieves the Voxels container activation state.


                | Parameters:


        """
        return self.cgradhesionsettingatt.Voxels

    def get_v4_v5_fdt_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetV4V5_FDTInfo
                | o Func GetV4V5_FDTInfo(    CATBSTR    AdminLevel,
                |                            CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the V4V5_FDT container activation state.
                | Refer to CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.GetV4V5_FDTInfo(admin_level, o_locked)

    def get_v4__model__comment_page_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetV4_Model_CommentPageInfo
                | o Func GetV4_Model_CommentPageInfo(    CATBSTR    AdminLevel,
                |                                        CATBSTR    oLocked) As boolean
                | 
                | Locks or unlocks the V4_Model_CommentPage container activation state.
                | Refer to CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.GetV4_Model_CommentPageInfo(admin_level, o_locked)

    def get_v4__model__ln_f_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetV4_Model_LnFInfo
                | o Func GetV4_Model_LnFInfo(    CATBSTR    AdminLevel,
                |                                CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the V4_Model_LnF container activation
                | state. Refer to CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.GetV4_Model_LnFInfo(admin_level, o_locked)

    def get_v5_spa_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetV5_SPAInfo
                | o Func GetV5_SPAInfo(    CATBSTR    AdminLevel,
                |                          CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the V5_SPA container activation state.
                | Refer to CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.GetV5_SPAInfo(admin_level, o_locked)

    def get_voxels_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetVoxelsInfo
                | o Func GetVoxelsInfo(    CATBSTR    AdminLevel,
                |                          CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the Voxels container activation state.
                | Refer to CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.GetVoxelsInfo(admin_level, o_locked)

    def set_v4_v5_fdt_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetV4V5_FDTLock
                | o Sub SetV4V5_FDTLock(    boolean    iLocked)
                | 
                | Locks or unlocks the V4V5_FDT container activation state. Refer to
                | CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.SetV4V5_FDTLock(i_locked)

    def set_v4__model__comment_page_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetV4_Model_CommentPageLock
                | o Sub SetV4_Model_CommentPageLock(    boolean    iLocked)
                | 
                | Retrieves information about the V4_Model_CommentPage container
                | activation state. Refer to CATSysSettingController for a detailed
                | description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.SetV4_Model_CommentPageLock(i_locked)

    def set_v4__model__ln_f_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetV4_Model_LnFLock
                | o Sub SetV4_Model_LnFLock(    boolean    iLocked)
                | 
                | Locks or unlocks the V4_Model_LnF container activation state. Refer to
                | CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.SetV4_Model_LnFLock(i_locked)

    def set_v5_spa_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetV5_SPALock
                | o Sub SetV5_SPALock(    boolean    iLocked)
                | 
                | Locks or unlocks the V5_SPA container activation state. Refer to
                | CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.SetV5_SPALock(i_locked)

    def set_voxels_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVoxelsLock
                | o Sub SetVoxelsLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Voxels container activation state. Refer to
                | CATSysSettingController for a detailed description.


                | Parameters:


        """
        return self.cgradhesionsettingatt.SetVoxelsLock(i_locked)

