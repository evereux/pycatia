#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatPrinterDirState:
    """
        .. note::
            CAA V5 Visual Basic help

                | Printer directory state.It is used by theactivateLinkAnchor('PrintersS
                | ettingAtt','','PrintersSettingAtt')object for modify the printers
                | setting. Each directory can be protected to prevent user access to the
                | printers it contains. The state could be "CATPrinterDirFree" or
                | "CATPrinterDirProtect"

    """

    def __init__(self, catia):
        self.catprinterdirstate = catia.CatPrinterDirState     

