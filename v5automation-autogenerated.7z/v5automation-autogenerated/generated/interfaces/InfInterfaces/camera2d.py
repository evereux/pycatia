#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Camera2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a 2D camera.The 2D camera stores a 2D viewpoint, that is
                | aactivateLinkAnchor('Viewpoint2D','','Viewpoint2D')object.

    """

    def __init__(self, catia):
        self.camera2d = catia.Camera2D     

    @property
    def viewpoint2_d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viewpoint2D
                | o Property Viewpoint2D(    ) As Viewpoint2D
                | 
                | Returns or sets the 2D viewpoint of a 2D camera.  Example: Assume the
                | active window is a
                | activateLinkAnchor('SpecsAndGeomWindow','','SpecsAndGeomWindow')
                | object. This example retrieves the
                | activateLinkAnchor('Viewpoint2D','','Viewpoint2D')  of the
                | activateLinkAnchor('SpecsViewer','','SpecsViewer')  and creates from
                | it a Camera2D you handle using the MyCamera variable. Then the camera
                | zoom is set to 2, and the camera's viewpoint is assigned to the
                | activateLinkAnchor('SpecsViewer','','SpecsViewer') .   Dim MyCamera As
                | Camera Set MyCamera = CATIA.ActiveWindow.SpecsViewer.NewCamera()
                | MyCamera.Viewpoint2D.Zoom = 2
                | CATIA.ActiveWindow.SpecsViewer.Viewpoint2D = MyCamera.Viewpoint2D


                | Parameters:


        """
        return self.camera2d.Viewpoint2D

