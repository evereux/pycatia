#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class VisualizationSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAVisualizationSettingAtt.

    """

    def __init__(self, catia):
        self.visualizationsettingatt = catia.VisualizationSettingAtt     

    @property
    def accurate_picking_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AccuratePickingMode
                | o Property AccuratePickingMode(    ) As boolean
                | 
                | Returns the AccuratePickingMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.AccuratePickingMode

    @property
    def accurate_picking_window_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AccuratePickingWindowSize
                | o Property AccuratePickingWindowSize(    ) As long
                | 
                | Returns the AccuratePickingWindowSize parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.AccuratePickingWindowSize

    @property
    def all_z_buffer_element_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AllZBufferElementMode
                | o Property AllZBufferElementMode(    ) As boolean
                | 
                | Returns the AllZBufferElementMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.AllZBufferElementMode

    @property
    def ambient_activation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AmbientActivation
                | o Property AmbientActivation(    ) As long
                | 
                | Returns the AmbientActivation parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.AmbientActivation

    @property
    def anti_aliasing_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AntiAliasingMode
                | o Property AntiAliasingMode(    ) As boolean
                | 
                | Returns the AntiAliasingMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.AntiAliasingMode

    @property
    def anti_aliasing_offset(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AntiAliasingOffset
                | o Property AntiAliasingOffset(    ) As double
                | 
                | Returns the AntiAliasingOffset parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.AntiAliasingOffset

    @property
    def auxiliary_drill_viewer(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AuxiliaryDrillViewer
                | o Property AuxiliaryDrillViewer(    ) As boolean
                | 
                | Returns the AuxiliaryDrillViewer parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.AuxiliaryDrillViewer

    @property
    def back_face_culling_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BackFaceCullingMode
                | o Property BackFaceCullingMode(    ) As boolean
                | 
                | Deprecated:  V5R16. Returns the BackFaceCullingMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.BackFaceCullingMode

    @property
    def border_edges_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BorderEdgesMode
                | o Property BorderEdgesMode(    ) As boolean
                | 
                | Returns the BorderEdgesMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.BorderEdgesMode

    @property
    def border_edges_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BorderEdgesThickness
                | o Property BorderEdgesThickness(    ) As long
                | 
                | Returns the BorderEdgesThickness parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.BorderEdgesThickness

    @property
    def bounding_box_selection_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BoundingBoxSelectionMode
                | o Property BoundingBoxSelectionMode(    ) As boolean
                | 
                | Returns the BoundingBoxSelectionMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.BoundingBoxSelectionMode

    @property
    def color_background_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ColorBackgroundMode
                | o Property ColorBackgroundMode(    ) As boolean
                | 
                | Returns the ColorBackgroundMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.ColorBackgroundMode

    @property
    def default_diffuse_ambient_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultDiffuseAmbientCoefficient
                | o Property DefaultDiffuseAmbientCoefficient(    ) As double
                | 
                | Returns the AmbientActivation parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.DefaultDiffuseAmbientCoefficient

    @property
    def default_shininess(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultShininess
                | o Property DefaultShininess(    ) As double
                | 
                | Returns the AmbientActivation parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.DefaultShininess

    @property
    def default_specular_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultSpecularCoefficient
                | o Property DefaultSpecularCoefficient(    ) As double
                | 
                | Returns the AmbientActivation parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.DefaultSpecularCoefficient

    @property
    def display_current_scale(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayCurrentScale
                | o Property DisplayCurrentScale(    ) As boolean
                | 
                | Returns the SetStereoModeLock parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.DisplayCurrentScale

    @property
    def display_drill_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayDrillList
                | o Property DisplayDrillList(    ) As boolean
                | 
                | Returns the DisplayDrillList parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.DisplayDrillList

    @property
    def display_immersive_drill_viewer(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayImmersiveDrillViewer
                | o Property DisplayImmersiveDrillViewer(    ) As boolean
                | 
                | Returns the DisplayImmersiveDrillViewer parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.DisplayImmersiveDrillViewer

    @property
    def dynamic_cull(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DynamicCull
                | o Property DynamicCull(    ) As long
                | 
                | Returns the DynamicCull parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.DynamicCull

    @property
    def dynamic_lod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DynamicLOD
                | o Property DynamicLOD(    ) As double
                | 
                | Returns the DynamicLOD parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.DynamicLOD

    @property
    def face_hl_drill(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FaceHLDrill
                | o Property FaceHLDrill(    ) As boolean
                | 
                | Returns the FaceHLDrill parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FaceHLDrill

    @property
    def fly_collision_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlyCollisionMode
                | o Property FlyCollisionMode(    ) As boolean
                | 
                | Returns the FlyCollisionMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FlyCollisionMode

    @property
    def fly_collision_sphere_radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlyCollisionSphereRadius
                | o Property FlyCollisionSphereRadius(    ) As double
                | 
                | Returns the FlyCollisionSphereRadius parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FlyCollisionSphereRadius

    @property
    def fly_collision_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlyCollisionType
                | o Property FlyCollisionType(    ) As long
                | 
                | Returns the FlyCollisionType parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FlyCollisionType

    @property
    def fly_sensitivity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlySensitivity
                | o Property FlySensitivity(    ) As long
                | 
                | Returns the FlySensitivity parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FlySensitivity

    @property
    def fly_speed(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlySpeed
                | o Property FlySpeed(    ) As long
                | 
                | Returns the FlySpeed parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FlySpeed

    @property
    def fly_speed_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlySpeedMode
                | o Property FlySpeedMode(    ) As long
                | 
                | Returns the FlySpeedMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FlySpeedMode

    @property
    def follow_ground_altitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FollowGroundAltitude
                | o Property FollowGroundAltitude(    ) As double
                | 
                | Returns the FollowGroundAltitude parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FollowGroundAltitude

    @property
    def follow_ground_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FollowGroundMode
                | o Property FollowGroundMode(    ) As boolean
                | 
                | Returns the FollowGroundMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FollowGroundMode

    @property
    def full_scene_anti_aliasing_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FullSceneAntiAliasingMode
                | o Property FullSceneAntiAliasingMode(    ) As CATFullSceneAntiAliasingMode
                | 
                | Returns the AntiAliasingMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.FullSceneAntiAliasingMode

    @property
    def gravity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Gravity
                | o Property Gravity(    ) As boolean
                | 
                | Returns the Gravity parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.Gravity

    @property
    def gravity_axis(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GravityAxis
                | o Property GravityAxis(    ) As long
                | 
                | Returns the GravityAxis parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GravityAxis

    @property
    def halo_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HaloMode
                | o Property HaloMode(    ) As boolean
                | 
                | Returns the HaloMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.HaloMode

    @property
    def isopar_generation_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsoparGenerationMode
                | o Property IsoparGenerationMode(    ) As boolean
                | 
                | Returns the IsoparGenerationMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.IsoparGenerationMode

    @property
    def keyboard_rotation_angle_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | KeyboardRotationAngleValue
                | o Property KeyboardRotationAngleValue(    ) As long
                | 
                | Retrieves the angle value for rotations operated through key
                | combinations.


                | Parameters:


        """
        return self.visualizationsettingatt.KeyboardRotationAngleValue

    @property
    def light_viewer_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LightViewerMode
                | o Property LightViewerMode(    ) As boolean
                | 
                | Returns the LightViewerMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.LightViewerMode

    @property
    def lineic_cgr_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LineicCgrMode
                | o Property LineicCgrMode(    ) As boolean
                | 
                | Returns the LineicCgrMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.LineicCgrMode

    @property
    def max_selection_move(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxSelectionMove
                | o Property MaxSelectionMove(    ) As long
                | 
                | Returns the MaxSelectionMove parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.MaxSelectionMove

    @property
    def minimum_fps_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MinimumFPSMode
                | o Property MinimumFPSMode(    ) As boolean
                | 
                | Returns the MinimumFPSMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.MinimumFPSMode

    @property
    def minimum_space_fps_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MinimumSpaceFPSMode
                | o Property MinimumSpaceFPSMode(    ) As boolean
                | 
                | Returns the MinimumSpaceFPSMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.MinimumSpaceFPSMode

    @property
    def mouse_double_clic_delay(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MouseDoubleClicDelay
                | o Property MouseDoubleClicDelay(    ) As long
                | 
                | Returns the MouseDoubleClicDelay parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.MouseDoubleClicDelay

    @property
    def mouse_speed_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MouseSpeedValue
                | o Property MouseSpeedValue(    ) As long
                | 
                | Returns the MouseSpeedValue parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.MouseSpeedValue

    @property
    def nb_isopars(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NbIsopars
                | o Property NbIsopars(    ) As long
                | 
                | Returns the NbIsopars parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.NbIsopars

    @property
    def no_z_buffer_selection_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NoZBufferSelectionMode
                | o Property NoZBufferSelectionMode(    ) As boolean
                | 
                | Returns the NoZBufferSelectionMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.NoZBufferSelectionMode

    @property
    def number_of_minimum_fps(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumberOfMinimumFPS
                | o Property NumberOfMinimumFPS(    ) As long
                | 
                | Returns the NumberOfMinimumFPS parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.NumberOfMinimumFPS

    @property
    def number_of_minimum_space_fps(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumberOfMinimumSpaceFPS
                | o Property NumberOfMinimumSpaceFPS(    ) As long
                | 
                | Returns the NumberOfMinimumSpaceFPS parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.NumberOfMinimumSpaceFPS

    @property
    def occlusion_culling_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OcclusionCullingMode
                | o Property OcclusionCullingMode(    ) As boolean
                | 
                | Returns the OcclusionCullingMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.OcclusionCullingMode

    @property
    def opaque_faces(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OpaqueFaces
                | o Property OpaqueFaces(    ) As boolean
                | 
                | Returns the SetStereoModeLock parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.OpaqueFaces

    @property
    def other_selection_timeout(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OtherSelectionTimeout
                | o Property OtherSelectionTimeout(    ) As double
                | 
                | Returns the OtherSelectionTimeout parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.OtherSelectionTimeout

    @property
    def other_selection_timeout_activity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OtherSelectionTimeoutActivity
                | o Property OtherSelectionTimeoutActivity(    ) As boolean
                | 
                | Returns the OtherSelectionTimeoutActivity parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.OtherSelectionTimeoutActivity

    @property
    def picking_window_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PickingWindowSize
                | o Property PickingWindowSize(    ) As long
                | 
                | Returns the PickingWindowSize parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.PickingWindowSize

    @property
    def pre_selection_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PreSelectionMode
                | o Property PreSelectionMode(    ) As boolean
                | 
                | Returns the PreSelectionMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.PreSelectionMode

    @property
    def preselected_element_linetype(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PreselectedElementLinetype
                | o Property PreselectedElementLinetype(    ) As long
                | 
                | Returns the PreselectedElementLinetype parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.PreselectedElementLinetype

    @property
    def rotation_sphere_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RotationSphereMode
                | o Property RotationSphereMode(    ) As boolean
                | 
                | Returns the RotationSphereMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.RotationSphereMode

    @property
    def shader_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShaderMode
                | o Property ShaderMode(    ) As boolean
                | 
                | Returns the ShaderMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.ShaderMode

    @property
    def static_cull(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StaticCull
                | o Property StaticCull(    ) As long
                | 
                | Returns the StaticCull parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.StaticCull

    @property
    def static_lod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StaticLOD
                | o Property StaticLOD(    ) As double
                | 
                | Returns the StaticLOD parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.StaticLOD

    @property
    def stereo_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StereoMode
                | o Property StereoMode(    ) As boolean
                | 
                | Returns the StereoMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.StereoMode

    @property
    def transparency_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TransparencyMode
                | o Property TransparencyMode(    ) As boolean
                | 
                | Returns the TransparencyMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.TransparencyMode

    @property
    def two_side_lighting_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TwoSideLightingMode
                | o Property TwoSideLightingMode(    ) As boolean
                | 
                | Returns the TwoSideLightingMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.TwoSideLightingMode

    @property
    def viewpoint_animation_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewpointAnimationMode
                | o Property ViewpointAnimationMode(    ) As boolean
                | 
                | Returns the ViewpointAnimationMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.ViewpointAnimationMode

    @property
    def viz2_d_accuracy_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viz2DAccuracyMode
                | o Property Viz2DAccuracyMode(    ) As boolean
                | 
                | Returns the 2DAccuracyMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.Viz2DAccuracyMode

    @property
    def viz2_d_fixed_accuracy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viz2DFixedAccuracy
                | o Property Viz2DFixedAccuracy(    ) As double
                | 
                | Returns the 2DFixedAccuracy parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.Viz2DFixedAccuracy

    @property
    def viz2_d_proportionnal_accuracy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viz2DProportionnalAccuracy
                | o Property Viz2DProportionnalAccuracy(    ) As double
                | 
                | Returns the 2DProportionnalAccuracy parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.Viz2DProportionnalAccuracy

    @property
    def viz_3d_accuracy_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viz3DAccuracyMode
                | o Property Viz3DAccuracyMode(    ) As boolean
                | 
                | Returns the Viz3DAccuracyMode parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.Viz3DAccuracyMode

    @property
    def viz_3d_curve_accuracy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viz3DCurveAccuracy
                | o Property Viz3DCurveAccuracy(    ) As double
                | 
                | Returns the 3DCurveAccuracy parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.Viz3DCurveAccuracy

    @property
    def viz_3d_fixed_accuracy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viz3DFixedAccuracy
                | o Property Viz3DFixedAccuracy(    ) As double
                | 
                | Returns the 3DFixedAccuracy parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.Viz3DFixedAccuracy

    @property
    def viz_3d_proportionnal_accuracy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viz3DProportionnalAccuracy
                | o Property Viz3DProportionnalAccuracy(    ) As double
                | 
                | Returns the Viz3DProportionnalAccuracy parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.Viz3DProportionnalAccuracy

    def get_accurate_picking_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAccuratePickingModeInfo
                | o Func GetAccuratePickingModeInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the AccuratePickingMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetAccuratePickingModeInfo(io_admin_level, io_locked)

    def get_accurate_picking_window_size_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAccuratePickingWindowSizeInfo
                | o Func GetAccuratePickingWindowSizeInfo(    CATBSTR    ioAdminLevel,
                |                                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the AccuratePickingWindowSize setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetAccuratePickingWindowSizeInfo(io_admin_level, io_locked)

    def get_all_z_buffer_element_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAllZBufferElementModeInfo
                | o Func GetAllZBufferElementModeInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the AllZBufferElementMode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetAllZBufferElementModeInfo(io_admin_level, io_locked)

    def get_ambient_activation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAmbientActivationInfo
                | o Func GetAmbientActivationInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the AmbientActivation setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetAmbientActivationInfo(io_admin_level, io_locked)

    def get_anti_aliasing_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAntiAliasingModeInfo
                | o Func GetAntiAliasingModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the AntiAliasingMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetAntiAliasingModeInfo(io_admin_level, io_locked)

    def get_anti_aliasing_offset_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAntiAliasingOffsetInfo
                | o Func GetAntiAliasingOffsetInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the AntiAliasingOffset setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetAntiAliasingOffsetInfo(io_admin_level, io_locked)

    def get_auxiliary_drill_viewer_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAuxiliaryDrillViewerInfo
                | o Func GetAuxiliaryDrillViewerInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the AuxiliaryDrillViewer setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetAuxiliaryDrillViewerInfo(io_admin_level, io_locked)

    def get_back_face_culling_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBackFaceCullingMode
                | o Func GetBackFaceCullingMode(    ) As CATBackFaceCullingMode
                | 
                | Retrieves the BackFaceCullingMode parameter.


                | Parameters:
                | oBackFaceCullingMode
                |    Value of the back face culling mode setting option. The retrieved value can be one of the four possible values
                | 	   defined by the 
                | 
                |  activateLinkAnchor('CATBackFaceCullingMode','','CATBackFaceCullingMode')  enumeration. 
                |    Returns:
                |     An HRESULT.
                |     Legal values:
                |     
                | S_OK
                |        if the operation succeeded.
                |       E_FAIL
                |        if the operation failed.


        """
        return self.visualizationsettingatt.GetBackFaceCullingMode()

    def get_back_face_culling_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBackFaceCullingModeInfo
                | o Func GetBackFaceCullingModeInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the BackFaceCullingMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetBackFaceCullingModeInfo(io_admin_level, io_locked)

    def get_background_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBackgroundRGB
                | o Sub GetBackgroundRGB(    long    ioR,
                |                            long    ioG,
                |                            long    ioB)
                | 
                | Returns the BackgroundRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GetBackgroundRGB(io_r, io_g, io_b)

    def get_background_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBackgroundRGBInfo
                | o Func GetBackgroundRGBInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the BackgroundRGB setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetBackgroundRGBInfo(io_admin_level, io_locked)

    def get_border_edges_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBorderEdgesModeInfo
                | o Func GetBorderEdgesModeInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the BorderEdgesMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetBorderEdgesModeInfo(io_admin_level, io_locked)

    def get_border_edges_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBorderEdgesRGB
                | o Sub GetBorderEdgesRGB(    long    ioR,
                |                             long    ioG,
                |                             long    ioB)
                | 
                | Returns the BorderEdgesRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GetBorderEdgesRGB(io_r, io_g, io_b)

    def get_border_edges_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBorderEdgesRGBInfo
                | o Func GetBorderEdgesRGBInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the BorderEdgesRGB setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetBorderEdgesRGBInfo(io_admin_level, io_locked)

    def get_border_edges_thickness_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBorderEdgesThicknessInfo
                | o Func GetBorderEdgesThicknessInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the BorderEdgesThickness setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetBorderEdgesThicknessInfo(io_admin_level, io_locked)

    def get_bounding_box_selection_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundingBoxSelectionModeInfo
                | o Func GetBoundingBoxSelectionModeInfo(    CATBSTR    ioAdminLevel,
                |                                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the BoundingBoxSelectionMode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetBoundingBoxSelectionModeInfo(io_admin_level, io_locked)

    def get_color_background_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetColorBackgroundModeInfo
                | o Func GetColorBackgroundModeInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ColorBackgroundMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetColorBackgroundModeInfo(io_admin_level, io_locked)

    def get_default_diffuse_ambient_coefficient_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultDiffuseAmbientCoefficientInfo
                | o Func GetDefaultDiffuseAmbientCoefficientInfo(    CATBSTR    ioAdminLevel,
                |                                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the DefaultDiffuseAmbientCoefficient
                | setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetDefaultDiffuseAmbientCoefficientInfo(io_admin_level, io_locked)

    def get_default_shininess_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultShininessInfo
                | o Func GetDefaultShininessInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the DefaultShininess setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetDefaultShininessInfo(io_admin_level, io_locked)

    def get_default_specular_coefficient_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultSpecularCoefficientInfo
                | o Func GetDefaultSpecularCoefficientInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the DefaultSpecularCoefficient setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetDefaultSpecularCoefficientInfo(io_admin_level, io_locked)

    def get_display_current_scale_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayCurrentScaleInfo
                | o Func GetDisplayCurrentScaleInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the SetStereoModeLock setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetDisplayCurrentScaleInfo(io_admin_level, io_locked)

    def get_display_drill_list_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayDrillListInfo
                | o Func GetDisplayDrillListInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the DisplayDrillList setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetDisplayDrillListInfo(io_admin_level, io_locked)

    def get_display_immersive_drill_viewer_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayImmersiveDrillViewerInfo
                | o Func GetDisplayImmersiveDrillViewerInfo(    CATBSTR    ioAdminLevel,
                |                                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the DisplayImmersiveDrillViewer setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetDisplayImmersiveDrillViewerInfo(io_admin_level, io_locked)

    def get_dynamic_cull_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDynamicCullInfo
                | o Func GetDynamicCullInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the DynamicCull setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetDynamicCullInfo(io_admin_level, io_locked)

    def get_dynamic_lod_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDynamicLODInfo
                | o Func GetDynamicLODInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the DynamicLOD setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetDynamicLODInfo(io_admin_level, io_locked)

    def get_face_hl_drill_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFaceHLDrillInfo
                | o Func GetFaceHLDrillInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FaceHLDrill setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFaceHLDrillInfo(io_admin_level, io_locked)

    def get_fly_collision_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFlyCollisionModeInfo
                | o Func GetFlyCollisionModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FlyCollisionMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFlyCollisionModeInfo(io_admin_level, io_locked)

    def get_fly_collision_sphere_radius_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFlyCollisionSphereRadiusInfo
                | o Func GetFlyCollisionSphereRadiusInfo(    CATBSTR    ioAdminLevel,
                |                                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FlyCollisionSphereRadius setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFlyCollisionSphereRadiusInfo(io_admin_level, io_locked)

    def get_fly_collision_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFlyCollisionTypeInfo
                | o Func GetFlyCollisionTypeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FlyCollisionType setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFlyCollisionTypeInfo(io_admin_level, io_locked)

    def get_fly_sensitivity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFlySensitivityInfo
                | o Func GetFlySensitivityInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FlySensitivity setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFlySensitivityInfo(io_admin_level, io_locked)

    def get_fly_speed_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFlySpeedInfo
                | o Func GetFlySpeedInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FlySpeed setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFlySpeedInfo(io_admin_level, io_locked)

    def get_fly_speed_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFlySpeedModeInfo
                | o Func GetFlySpeedModeInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FlySpeedMode setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFlySpeedModeInfo(io_admin_level, io_locked)

    def get_follow_ground_altitude_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFollowGroundAltitudeInfo
                | o Func GetFollowGroundAltitudeInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FollowGroundAltitude setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFollowGroundAltitudeInfo(io_admin_level, io_locked)

    def get_follow_ground_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFollowGroundModeInfo
                | o Func GetFollowGroundModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the FollowGroundMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFollowGroundModeInfo(io_admin_level, io_locked)

    def get_full_scene_anti_aliasing_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFullSceneAntiAliasingModeInfo
                | o Func GetFullSceneAntiAliasingModeInfo(    CATBSTR    ioAdminLevel,
                |                                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the AntiAliasingMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetFullSceneAntiAliasingModeInfo(io_admin_level, io_locked)

    def get_gravity_axis_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGravityAxisInfo
                | o Func GetGravityAxisInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the GravityAxis setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetGravityAxisInfo(io_admin_level, io_locked)

    def get_gravity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGravityInfo
                | o Func GetGravityInfo(    CATBSTR    ioAdminLevel,
                |                           CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Gravity setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetGravityInfo(io_admin_level, io_locked)

    def get_halo_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHaloModeInfo
                | o Func GetHaloModeInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the HaloMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetHaloModeInfo(io_admin_level, io_locked)

    def get_handles_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHandlesRGB
                | o Sub GetHandlesRGB(    long    ioR,
                |                         long    ioG,
                |                         long    ioB)
                | 
                | Returns the HandlesRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GetHandlesRGB(io_r, io_g, io_b)

    def get_handles_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHandlesRGBInfo
                | o Func GetHandlesRGBInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the HandlesRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetHandlesRGBInfo(io_admin_level, io_locked)

    def get_isopar_generation_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIsoparGenerationModeInfo
                | o Func GetIsoparGenerationModeInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the IsoparGenerationMode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetIsoparGenerationModeInfo(io_admin_level, io_locked)

    def get_keyboard_rotation_angle_value_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetKeyboardRotationAngleValueInfo
                | o Func GetKeyboardRotationAngleValueInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the KeyboardRotationAngleValue setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetKeyboardRotationAngleValueInfo(io_admin_level, io_locked)

    def get_light_viewer_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLightViewerModeInfo
                | o Func GetLightViewerModeInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the LightViewerMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetLightViewerModeInfo(io_admin_level, io_locked)

    def get_lineic_cgr_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLineicCgrModeInfo
                | o Func GetLineicCgrModeInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the LineicCgrMode setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetLineicCgrModeInfo(io_admin_level, io_locked)

    def get_max_selection_move_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMaxSelectionMoveInfo
                | o Func GetMaxSelectionMoveInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the MaxSelectionMove setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetMaxSelectionMoveInfo(io_admin_level, io_locked)

    def get_minimum_fps_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMinimumFPSModeInfo
                | o Func GetMinimumFPSModeInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the MinimumFPSMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetMinimumFPSModeInfo(io_admin_level, io_locked)

    def get_minimum_space_fps_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMinimumSpaceFPSModeInfo
                | o Func GetMinimumSpaceFPSModeInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the MinimumSpaceFPSMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetMinimumSpaceFPSModeInfo(io_admin_level, io_locked)

    def get_mouse_double_clic_delay_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMouseDoubleClicDelayInfo
                | o Func GetMouseDoubleClicDelayInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the MouseDoubleClicDelay setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetMouseDoubleClicDelayInfo(io_admin_level, io_locked)

    def get_mouse_speed_value_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMouseSpeedValueInfo
                | o Func GetMouseSpeedValueInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the MouseSpeedValue setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetMouseSpeedValueInfo(io_admin_level, io_locked)

    def get_nb_isopars_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNbIsoparsInfo
                | o Func GetNbIsoparsInfo(    CATBSTR    ioAdminLevel,
                |                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the NbIsopars setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetNbIsoparsInfo(io_admin_level, io_locked)

    def get_no_show_background_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNoShowBackgroundRGB
                | o Sub GetNoShowBackgroundRGB(    long    ioR,
                |                                  long    ioG,
                |                                  long    ioB)
                | 
                | Retrieves the No Show Background Color setting attribute value. Role:
                | The No Show Background Color setting attribute manages the backgraound
                | color of no show space


                | Parameters:
                | ioR,
                |  ioG, ioB [inout]   The Red, Green, Blue components of the No Show Background Color setting attribute value
                |  
                | 
                |  Returns:
                |     S_OK if the No Show Background Color setting attribute value
                |    is successfully retrieved, and E_FAIL otherwise


        """
        return self.visualizationsettingatt.GetNoShowBackgroundRGB(io_r, io_g, io_b)

    def get_no_show_background_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNoShowBackgroundRGBInfo
                | o Func GetNoShowBackgroundRGBInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves the No Show Background Color setting attribute information.


                | Parameters:
                | ioAdminLevel,
                |  ioLocked [inout] and oModified [out]   The No Show Background Color setting attribute information
                |  
                | 
                |  Returns:
                |      S_OK if the No Show Background Color setting attribute
                |    information is successfully retrieved, and E_FAIL otherwise   
                |  Refer to 
                |  activateLinkAnchor('SettingController','','SettingController')  for a detailed description.


        """
        return self.visualizationsettingatt.GetNoShowBackgroundRGBInfo(io_admin_level, io_locked)

    def get_no_z_buffer_selection_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNoZBufferSelectionModeInfo
                | o Func GetNoZBufferSelectionModeInfo(    CATBSTR    ioAdminLevel,
                |                                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the NoZBufferSelectionMode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetNoZBufferSelectionModeInfo(io_admin_level, io_locked)

    def get_number_of_minimum_fps_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNumberOfMinimumFPSInfo
                | o Func GetNumberOfMinimumFPSInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the NumberOfMinimumFPS setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetNumberOfMinimumFPSInfo(io_admin_level, io_locked)

    def get_number_of_minimum_space_fps_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNumberOfMinimumSpaceFPSInfo
                | o Func GetNumberOfMinimumSpaceFPSInfo(    CATBSTR    ioAdminLevel,
                |                                           CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the NumberOfMinimumSpaceFPS setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetNumberOfMinimumSpaceFPSInfo(io_admin_level, io_locked)

    def get_occlusion_culling_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOcclusionCullingModeInfo
                | o Func GetOcclusionCullingModeInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the OcclusionCullingMode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetOcclusionCullingModeInfo(io_admin_level, io_locked)

    def get_opaque_faces_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOpaqueFacesInfo
                | o Func GetOpaqueFacesInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the SetStereoModeLock setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetOpaqueFacesInfo(io_admin_level, io_locked)

    def get_other_selection_timeout_activity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOtherSelectionTimeoutActivityInfo
                | o Func GetOtherSelectionTimeoutActivityInfo(    CATBSTR    ioAdminLevel,
                |                                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the OtherSelectionTimeoutActivity setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetOtherSelectionTimeoutActivityInfo(io_admin_level, io_locked)

    def get_other_selection_timeout_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOtherSelectionTimeoutInfo
                | o Func GetOtherSelectionTimeoutInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the OtherSelectionTimeout setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetOtherSelectionTimeoutInfo(io_admin_level, io_locked)

    def get_picking_window_size_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPickingWindowSizeInfo
                | o Func GetPickingWindowSizeInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the PickingWindowSize setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetPickingWindowSizeInfo(io_admin_level, io_locked)

    def get_pre_selection_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPreSelectionModeInfo
                | o Func GetPreSelectionModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the PreSelectionMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetPreSelectionModeInfo(io_admin_level, io_locked)

    def get_preselected_element_linetype_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPreselectedElementLinetypeInfo
                | o Func GetPreselectedElementLinetypeInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the PreselectedElementLinetype setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetPreselectedElementLinetypeInfo(io_admin_level, io_locked)

    def get_preselected_element_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPreselectedElementRGB
                | o Sub GetPreselectedElementRGB(    long    ioR,
                |                                    long    ioG,
                |                                    long    ioB)
                | 
                | Returns the PreselectedElementRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GetPreselectedElementRGB(io_r, io_g, io_b)

    def get_preselected_element_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPreselectedElementRGBInfo
                | o Func GetPreselectedElementRGBInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the PreselectedElementRGB setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetPreselectedElementRGBInfo(io_admin_level, io_locked)

    def get_rotation_sphere_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRotationSphereModeInfo
                | o Func GetRotationSphereModeInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the RotationSphereMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetRotationSphereModeInfo(io_admin_level, io_locked)

    def get_selected_edge_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSelectedEdgeRGB
                | o Sub GetSelectedEdgeRGB(    long    ioR,
                |                              long    ioG,
                |                              long    ioB)
                | 
                | Returns the SelectedEdgeRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GetSelectedEdgeRGB(io_r, io_g, io_b)

    def get_selected_edge_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSelectedEdgeRGBInfo
                | o Func GetSelectedEdgeRGBInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the SelectedEdgeRGB setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetSelectedEdgeRGBInfo(io_admin_level, io_locked)

    def get_selected_element_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSelectedElementRGB
                | o Sub GetSelectedElementRGB(    long    ioR,
                |                                 long    ioG,
                |                                 long    ioB)
                | 
                | Returns the SelectedElementRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GetSelectedElementRGB(io_r, io_g, io_b)

    def get_selected_element_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSelectedElementRGBInfo
                | o Func GetSelectedElementRGBInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the SelectedElementRGB setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetSelectedElementRGBInfo(io_admin_level, io_locked)

    def get_shader_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShaderModeInfo
                | o Func GetShaderModeInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ShaderMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetShaderModeInfo(io_admin_level, io_locked)

    def get_static_cull_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStaticCullInfo
                | o Func GetStaticCullInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the StaticCull setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetStaticCullInfo(io_admin_level, io_locked)

    def get_static_lod_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStaticLODInfo
                | o Func GetStaticLODInfo(    CATBSTR    ioAdminLevel,
                |                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the StaticLOD setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetStaticLODInfo(io_admin_level, io_locked)

    def get_stereo_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStereoModeInfo
                | o Func GetStereoModeInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the StereoMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetStereoModeInfo(io_admin_level, io_locked)

    def get_transparency_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTransparencyModeInfo
                | o Func GetTransparencyModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the TransparencyMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetTransparencyModeInfo(io_admin_level, io_locked)

    def get_two_side_lighting_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTwoSideLightingModeInfo
                | o Func GetTwoSideLightingModeInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the TwoSideLightingMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetTwoSideLightingModeInfo(io_admin_level, io_locked)

    def get_under_intensified_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUnderIntensifiedRGB
                | o Sub GetUnderIntensifiedRGB(    long    ioR,
                |                                  long    ioG,
                |                                  long    ioB)
                | 
                | Returns the UnderIntensifiedRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GetUnderIntensifiedRGB(io_r, io_g, io_b)

    def get_under_intensified_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUnderIntensifiedRGBInfo
                | o Func GetUnderIntensifiedRGBInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the UnderIntensifiedRGB setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetUnderIntensifiedRGBInfo(io_admin_level, io_locked)

    def get_update_needed_rgb(self, io_r, io_g, io_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUpdateNeededRGB
                | o Sub GetUpdateNeededRGB(    long    ioR,
                |                              long    ioG,
                |                              long    ioB)
                | 
                | Returns the UpdateNeededRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.GetUpdateNeededRGB(io_r, io_g, io_b)

    def get_update_needed_rgb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUpdateNeededRGBInfo
                | o Func GetUpdateNeededRGBInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the UpdateNeededRGB setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetUpdateNeededRGBInfo(io_admin_level, io_locked)

    def get_viewpoint_animation_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewpointAnimationModeInfo
                | o Func GetViewpointAnimationModeInfo(    CATBSTR    ioAdminLevel,
                |                                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the ViewpointAnimationMode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetViewpointAnimationModeInfo(io_admin_level, io_locked)

    def get_viz2_d_accuracy_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViz2DAccuracyModeInfo
                | o Func GetViz2DAccuracyModeInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the 2DAccuracyMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetViz2DAccuracyModeInfo(io_admin_level, io_locked)

    def get_viz2_d_fixed_accuracy_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViz2DFixedAccuracyInfo
                | o Func GetViz2DFixedAccuracyInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the 2DFixedAccuracy setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetViz2DFixedAccuracyInfo(io_admin_level, io_locked)

    def get_viz2_d_proportionnal_accuracy_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViz2DProportionnalAccuracyInfo
                | o Func GetViz2DProportionnalAccuracyInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the 2DProportionnalAccuracy setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetViz2DProportionnalAccuracyInfo(io_admin_level, io_locked)

    def get_viz_3d_accuracy_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViz3DAccuracyModeInfo
                | o Func GetViz3DAccuracyModeInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Viz3DAccuracyMode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetViz3DAccuracyModeInfo(io_admin_level, io_locked)

    def get_viz_3d_curve_accuracy_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViz3DCurveAccuracyInfo
                | o Func GetViz3DCurveAccuracyInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the 3DCurveAccuracy setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetViz3DCurveAccuracyInfo(io_admin_level, io_locked)

    def get_viz_3d_fixed_accuracy_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViz3DFixedAccuracyInfo
                | o Func GetViz3DFixedAccuracyInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the 3DFixedAccuracy setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetViz3DFixedAccuracyInfo(io_admin_level, io_locked)

    def get_viz_3d_proportionnal_accuracy_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViz3DProportionnalAccuracyInfo
                | o Func GetViz3DProportionnalAccuracyInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Viz3DProportionnalAccuracy setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.GetViz3DProportionnalAccuracyInfo(io_admin_level, io_locked)

    def put_back_face_culling_mode(self, i_back_face_culling_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutBackFaceCullingMode
                | o Sub PutBackFaceCullingMode(    CATBackFaceCullingMode    iBackFaceCullingMode)
                | 
                | Sets the BackFaceCullingMode attribute.


                | Parameters:
                | iBackFaceCullingMode
                |    Value of the back face culling mode setting option. The value to set can be one of the four possible values
                | 	   defined by the 
                | 
                |  activateLinkAnchor('CATBackFaceCullingMode','','CATBackFaceCullingMode')  enumeration. 
                |    Returns:
                |     An HRESULT.
                |     Legal values:
                |     
                | S_OK
                |        if the operation succeeded.
                |       E_FAIL
                |        if the operation failed.


        """
        return self.visualizationsettingatt.PutBackFaceCullingMode(i_back_face_culling_mode)

    def set_accurate_picking_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAccuratePickingModeLock
                | o Sub SetAccuratePickingModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AccuratePickingMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetAccuratePickingModeLock(i_locked)

    def set_accurate_picking_window_size_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAccuratePickingWindowSizeLock
                | o Sub SetAccuratePickingWindowSizeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AccuratePickingWindowSize setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetAccuratePickingWindowSizeLock(i_locked)

    def set_all_z_buffer_element_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAllZBufferElementModeLock
                | o Sub SetAllZBufferElementModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AllZBufferElementMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetAllZBufferElementModeLock(i_locked)

    def set_ambient_activation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAmbientActivationLock
                | o Sub SetAmbientActivationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AmbientActivation setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetAmbientActivationLock(i_locked)

    def set_anti_aliasing_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAntiAliasingModeLock
                | o Sub SetAntiAliasingModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AntiAliasingMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetAntiAliasingModeLock(i_locked)

    def set_anti_aliasing_offset_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAntiAliasingOffsetLock
                | o Sub SetAntiAliasingOffsetLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AntiAliasingOffset setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetAntiAliasingOffsetLock(i_locked)

    def set_auxiliary_drill_viewer_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAuxiliaryDrillViewerLock
                | o Sub SetAuxiliaryDrillViewerLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AuxiliaryDrillViewer setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetAuxiliaryDrillViewerLock(i_locked)

    def set_back_face_culling_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBackFaceCullingModeLock
                | o Sub SetBackFaceCullingModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BackFaceCullingMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetBackFaceCullingModeLock(i_locked)

    def set_background_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBackgroundRGB
                | o Sub SetBackgroundRGB(    long    iR,
                |                            long    iG,
                |                            long    iB)
                | 
                | Sets the BackgroundRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.SetBackgroundRGB(i_r, i_g, i_b)

    def set_background_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBackgroundRGBLock
                | o Sub SetBackgroundRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BackgroundRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetBackgroundRGBLock(i_locked)

    def set_border_edges_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBorderEdgesModeLock
                | o Sub SetBorderEdgesModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BorderEdgesMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetBorderEdgesModeLock(i_locked)

    def set_border_edges_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBorderEdgesRGB
                | o Sub SetBorderEdgesRGB(    long    iR,
                |                             long    iG,
                |                             long    iB)
                | 
                | Sets the BorderEdgesRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.SetBorderEdgesRGB(i_r, i_g, i_b)

    def set_border_edges_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBorderEdgesRGBLock
                | o Sub SetBorderEdgesRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BorderEdgesRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetBorderEdgesRGBLock(i_locked)

    def set_border_edges_thickness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBorderEdgesThicknessLock
                | o Sub SetBorderEdgesThicknessLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BorderEdgesThickness setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetBorderEdgesThicknessLock(i_locked)

    def set_bounding_box_selection_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundingBoxSelectionModeLock
                | o Sub SetBoundingBoxSelectionModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BoundingBoxSelectionMode setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetBoundingBoxSelectionModeLock(i_locked)

    def set_color_background_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetColorBackgroundModeLock
                | o Sub SetColorBackgroundModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ColorBackgroundMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetColorBackgroundModeLock(i_locked)

    def set_default_diffuse_ambient_coefficient_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultDiffuseAmbientCoefficientLock
                | o Sub SetDefaultDiffuseAmbientCoefficientLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DefaultDiffuseAmbientCoefficient setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetDefaultDiffuseAmbientCoefficientLock(i_locked)

    def set_default_shininess_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultShininessLock
                | o Sub SetDefaultShininessLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DefaultShininess setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetDefaultShininessLock(i_locked)

    def set_default_specular_coefficient_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultSpecularCoefficientLock
                | o Sub SetDefaultSpecularCoefficientLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DefaultSpecularCoefficient setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetDefaultSpecularCoefficientLock(i_locked)

    def set_display_current_scale_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayCurrentScaleLock
                | o Sub SetDisplayCurrentScaleLock(    boolean    iLocked)
                | 
                | Locks or unlocks the SetStereoModeLock setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetDisplayCurrentScaleLock(i_locked)

    def set_display_drill_list_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayDrillListLock
                | o Sub SetDisplayDrillListLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DisplayDrillList setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetDisplayDrillListLock(i_locked)

    def set_display_immersive_drill_viewer_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayImmersiveDrillViewerLock
                | o Sub SetDisplayImmersiveDrillViewerLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DisplayImmersiveDrillViewer setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetDisplayImmersiveDrillViewerLock(i_locked)

    def set_dynamic_cull_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDynamicCullLock
                | o Sub SetDynamicCullLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DynamicCull setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetDynamicCullLock(i_locked)

    def set_dynamic_lod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDynamicLODLock
                | o Sub SetDynamicLODLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DynamicLOD setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetDynamicLODLock(i_locked)

    def set_face_hl_drill_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFaceHLDrillLock
                | o Sub SetFaceHLDrillLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FaceHLDrill setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFaceHLDrillLock(i_locked)

    def set_fly_collision_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFlyCollisionModeLock
                | o Sub SetFlyCollisionModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FlyCollisionMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFlyCollisionModeLock(i_locked)

    def set_fly_collision_sphere_radius_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFlyCollisionSphereRadiusLock
                | o Sub SetFlyCollisionSphereRadiusLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FlyCollisionSphereRadius setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFlyCollisionSphereRadiusLock(i_locked)

    def set_fly_collision_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFlyCollisionTypeLock
                | o Sub SetFlyCollisionTypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FlyCollisionType setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFlyCollisionTypeLock(i_locked)

    def set_fly_sensitivity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFlySensitivityLock
                | o Sub SetFlySensitivityLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FlySensitivity setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFlySensitivityLock(i_locked)

    def set_fly_speed_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFlySpeedLock
                | o Sub SetFlySpeedLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FlySpeed setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFlySpeedLock(i_locked)

    def set_fly_speed_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFlySpeedModeLock
                | o Sub SetFlySpeedModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FlySpeedMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFlySpeedModeLock(i_locked)

    def set_follow_ground_altitude_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFollowGroundAltitudeLock
                | o Sub SetFollowGroundAltitudeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FollowGroundAltitude setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFollowGroundAltitudeLock(i_locked)

    def set_follow_ground_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFollowGroundModeLock
                | o Sub SetFollowGroundModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FollowGroundMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFollowGroundModeLock(i_locked)

    def set_full_scene_anti_aliasing_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFullSceneAntiAliasingModeLock
                | o Sub SetFullSceneAntiAliasingModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AntiAliasingMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetFullSceneAntiAliasingModeLock(i_locked)

    def set_gravity_axis_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetGravityAxisLock
                | o Sub SetGravityAxisLock(    boolean    iLocked)
                | 
                | Locks or unlocks the GravityAxis setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetGravityAxisLock(i_locked)

    def set_gravity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetGravityLock
                | o Sub SetGravityLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Gravity setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetGravityLock(i_locked)

    def set_halo_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHaloModeLock
                | o Sub SetHaloModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the HaloMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetHaloModeLock(i_locked)

    def set_handles_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandlesRGB
                | o Sub SetHandlesRGB(    long    iR,
                |                         long    iG,
                |                         long    iB)
                | 
                | Sets the HandlesRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.SetHandlesRGB(i_r, i_g, i_b)

    def set_handles_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandlesRGBLock
                | o Sub SetHandlesRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the HandlesRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetHandlesRGBLock(i_locked)

    def set_isopar_generation_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIsoparGenerationModeLock
                | o Sub SetIsoparGenerationModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the IsoparGenerationMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetIsoparGenerationModeLock(i_locked)

    def set_keyboard_rotation_angle_value_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetKeyboardRotationAngleValueLock
                | o Sub SetKeyboardRotationAngleValueLock(    boolean    iLocked)
                | 
                | Locks or unlocks the KeyboardRotationAngleValue setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetKeyboardRotationAngleValueLock(i_locked)

    def set_light_viewer_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLightViewerModeLock
                | o Sub SetLightViewerModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the LightViewerMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetLightViewerModeLock(i_locked)

    def set_lineic_cgr_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLineicCgrModeLock
                | o Sub SetLineicCgrModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the v setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetLineicCgrModeLock(i_locked)

    def set_max_selection_move_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMaxSelectionMoveLock
                | o Sub SetMaxSelectionMoveLock(    boolean    iLocked)
                | 
                | Locks or unlocks the MaxSelectionMove setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetMaxSelectionMoveLock(i_locked)

    def set_minimum_fps_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMinimumFPSModeLock
                | o Sub SetMinimumFPSModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the MinimumFPSMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetMinimumFPSModeLock(i_locked)

    def set_minimum_space_fps_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMinimumSpaceFPSModeLock
                | o Sub SetMinimumSpaceFPSModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the MinimumSpaceFPSMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetMinimumSpaceFPSModeLock(i_locked)

    def set_mouse_double_clic_delay_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMouseDoubleClicDelayLock
                | o Sub SetMouseDoubleClicDelayLock(    boolean    iLocked)
                | 
                | Locks or unlocks the MouseDoubleClicDelay setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetMouseDoubleClicDelayLock(i_locked)

    def set_mouse_speed_value_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMouseSpeedValueLock
                | o Sub SetMouseSpeedValueLock(    boolean    iLocked)
                | 
                | Locks or unlocks the MouseSpeedValue setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetMouseSpeedValueLock(i_locked)

    def set_nb_isopars_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNbIsoparsLock
                | o Sub SetNbIsoparsLock(    boolean    iLocked)
                | 
                | Locks or unlocks the NbIsopars setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetNbIsoparsLock(i_locked)

    def set_no_show_background_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNoShowBackgroundRGB
                | o Sub SetNoShowBackgroundRGB(    long    iR,
                |                                  long    iG,
                |                                  long    iB)
                | 
                | Sets the No Show Background Color setting attribute value. Role: The
                | No Show Background Color setting attribute manages the backgraound
                | color of no show space


                | Parameters:
                | iR,
                |  iG, iB [in]   The Red, Green, Blue components of the No Show Background Color setting attribute value
                |    Legal values: between 0 and 255
                |  
                | 
                |  Returns:
                |     S_OK if the No Show Background Color setting attribute value
                |    is successfully set, and E_FAIL otherwise


        """
        return self.visualizationsettingatt.SetNoShowBackgroundRGB(i_r, i_g, i_b)

    def set_no_show_background_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNoShowBackgroundRGBLock
                | o Sub SetNoShowBackgroundRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the No Show Background Color setting attribute. Role:
                | Locks or unlocks the No Show Background Color setting attribute if the
                | operation is allowed in the current administrated environment.  In
                | user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |  [in]   A flag to indicate whether the No Show Background Color setting attribute should be locked.
                |    Legal values:
                |      TRUE to lock
                |      FALSE to unlock
                |  
                | 
                |  Returns:
                |     S_OK if the No Show Background Color setting attribute
                |    is successfully locked or unlocked, and E_FAIL otherwise   
                |  Refer to 
                |  activateLinkAnchor('SettingController','','SettingController')  for a detailed description.


        """
        return self.visualizationsettingatt.SetNoShowBackgroundRGBLock(i_locked)

    def set_no_z_buffer_selection_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNoZBufferSelectionModeLock
                | o Sub SetNoZBufferSelectionModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the NoZBufferSelectionMode setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetNoZBufferSelectionModeLock(i_locked)

    def set_number_of_minimum_fps_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNumberOfMinimumFPSLock
                | o Sub SetNumberOfMinimumFPSLock(    boolean    iLocked)
                | 
                | Locks or unlocks the NumberOfMinimumFPS setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetNumberOfMinimumFPSLock(i_locked)

    def set_number_of_minimum_space_fps_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNumberOfMinimumSpaceFPSLock
                | o Sub SetNumberOfMinimumSpaceFPSLock(    boolean    iLocked)
                | 
                | Locks or unlocks the NumberOfMinimumSpaceFPS setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetNumberOfMinimumSpaceFPSLock(i_locked)

    def set_occlusion_culling_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOcclusionCullingModeLock
                | o Sub SetOcclusionCullingModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the OcclusionCullingMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetOcclusionCullingModeLock(i_locked)

    def set_opaque_faces_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOpaqueFacesLock
                | o Sub SetOpaqueFacesLock(    boolean    iLocked)
                | 
                | Locks or unlocks the SetStereoModeLock setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetOpaqueFacesLock(i_locked)

    def set_other_selection_timeout_activity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOtherSelectionTimeoutActivityLock
                | o Sub SetOtherSelectionTimeoutActivityLock(    boolean    iLocked)
                | 
                | Locks or unlocks the OtherSelectionTimeoutActivity setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetOtherSelectionTimeoutActivityLock(i_locked)

    def set_other_selection_timeout_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOtherSelectionTimeoutLock
                | o Sub SetOtherSelectionTimeoutLock(    boolean    iLocked)
                | 
                | Locks or unlocks the OtherSelectionTimeout setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetOtherSelectionTimeoutLock(i_locked)

    def set_picking_window_size_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPickingWindowSizeLock
                | o Sub SetPickingWindowSizeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PickingWindowSize setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetPickingWindowSizeLock(i_locked)

    def set_pre_selection_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPreSelectionModeLock
                | o Sub SetPreSelectionModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PreSelectionMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetPreSelectionModeLock(i_locked)

    def set_preselected_element_linetype_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPreselectedElementLinetypeLock
                | o Sub SetPreselectedElementLinetypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PreselectedElementLinetype setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetPreselectedElementLinetypeLock(i_locked)

    def set_preselected_element_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPreselectedElementRGB
                | o Sub SetPreselectedElementRGB(    long    iR,
                |                                    long    iG,
                |                                    long    iB)
                | 
                | Sets the PreselectedElementRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.SetPreselectedElementRGB(i_r, i_g, i_b)

    def set_preselected_element_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPreselectedElementRGBLock
                | o Sub SetPreselectedElementRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PreselectedElementRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetPreselectedElementRGBLock(i_locked)

    def set_rotation_sphere_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRotationSphereModeLock
                | o Sub SetRotationSphereModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RotationSphereMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetRotationSphereModeLock(i_locked)

    def set_selected_edge_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSelectedEdgeRGB
                | o Sub SetSelectedEdgeRGB(    long    iR,
                |                              long    iG,
                |                              long    iB)
                | 
                | Sets the SelectedEdgeRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.SetSelectedEdgeRGB(i_r, i_g, i_b)

    def set_selected_edge_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSelectedEdgeRGBLock
                | o Sub SetSelectedEdgeRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the SelectedEdgeRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetSelectedEdgeRGBLock(i_locked)

    def set_selected_element_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSelectedElementRGB
                | o Sub SetSelectedElementRGB(    long    iR,
                |                                 long    iG,
                |                                 long    iB)
                | 
                | Sets the SelectedElementRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.SetSelectedElementRGB(i_r, i_g, i_b)

    def set_selected_element_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSelectedElementRGBLock
                | o Sub SetSelectedElementRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the SelectedElementRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetSelectedElementRGBLock(i_locked)

    def set_shader_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShaderModeLock
                | o Sub SetShaderModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ShaderMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetShaderModeLock(i_locked)

    def set_static_cull_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetStaticCullLock
                | o Sub SetStaticCullLock(    boolean    iLocked)
                | 
                | Locks or unlocks the StaticCull setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetStaticCullLock(i_locked)

    def set_static_lod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetStaticLODLock
                | o Sub SetStaticLODLock(    boolean    iLocked)
                | 
                | Locks or unlocks the StaticLOD setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetStaticLODLock(i_locked)

    def set_stereo_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetStereoModeLock
                | o Sub SetStereoModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the StereoMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetStereoModeLock(i_locked)

    def set_transparency_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTransparencyModeLock
                | o Sub SetTransparencyModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TransparencyMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetTransparencyModeLock(i_locked)

    def set_two_side_lighting_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTwoSideLightingModeLock
                | o Sub SetTwoSideLightingModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TwoSideLightingMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetTwoSideLightingModeLock(i_locked)

    def set_under_intensified_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUnderIntensifiedRGB
                | o Sub SetUnderIntensifiedRGB(    long    iR,
                |                                  long    iG,
                |                                  long    iB)
                | 
                | Sets the UnderIntensifiedRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.SetUnderIntensifiedRGB(i_r, i_g, i_b)

    def set_under_intensified_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUnderIntensifiedRGBLock
                | o Sub SetUnderIntensifiedRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the UnderIntensifiedRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetUnderIntensifiedRGBLock(i_locked)

    def set_update_needed_rgb(self, i_r, i_g, i_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUpdateNeededRGB
                | o Sub SetUpdateNeededRGB(    long    iR,
                |                              long    iG,
                |                              long    iB)
                | 
                | Sets the UpdateNeededRGB parameter.


                | Parameters:


        """
        return self.visualizationsettingatt.SetUpdateNeededRGB(i_r, i_g, i_b)

    def set_update_needed_rgb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUpdateNeededRGBLock
                | o Sub SetUpdateNeededRGBLock(    boolean    iLocked)
                | 
                | Locks or unlocks the UpdateNeededRGB setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetUpdateNeededRGBLock(i_locked)

    def set_viewpoint_animation_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewpointAnimationModeLock
                | o Sub SetViewpointAnimationModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ViewpointAnimationMode setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetViewpointAnimationModeLock(i_locked)

    def set_viz2_d_accuracy_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViz2DAccuracyModeLock
                | o Sub SetViz2DAccuracyModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the 2DAccuracyMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetViz2DAccuracyModeLock(i_locked)

    def set_viz2_d_fixed_accuracy_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViz2DFixedAccuracyLock
                | o Sub SetViz2DFixedAccuracyLock(    boolean    iLocked)
                | 
                | Locks or unlocks the 2DFixedAccuracy setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetViz2DFixedAccuracyLock(i_locked)

    def set_viz2_d_proportionnal_accuracy_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViz2DProportionnalAccuracyLock
                | o Sub SetViz2DProportionnalAccuracyLock(    boolean    iLocked)
                | 
                | Locks or unlocks the 2DProportionnalAccuracy setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetViz2DProportionnalAccuracyLock(i_locked)

    def set_viz_3d_accuracy_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViz3DAccuracyModeLock
                | o Sub SetViz3DAccuracyModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Viz3DAccuracyMode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetViz3DAccuracyModeLock(i_locked)

    def set_viz_3d_curve_accuracy_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViz3DCurveAccuracyLock
                | o Sub SetViz3DCurveAccuracyLock(    boolean    iLocked)
                | 
                | Locks or unlocks the 3DCurveAccuracy setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetViz3DCurveAccuracyLock(i_locked)

    def set_viz_3d_fixed_accuracy_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViz3DFixedAccuracyLock
                | o Sub SetViz3DFixedAccuracyLock(    boolean    iLocked)
                | 
                | Locks or unlocks the 3DFixedAccuracy setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetViz3DFixedAccuracyLock(i_locked)

    def set_viz_3d_proportionnal_accuracy_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViz3DProportionnalAccuracyLock
                | o Sub SetViz3DProportionnalAccuracyLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Viz3DProportionnalAccuracy setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.visualizationsettingatt.SetViz3DProportionnalAccuracyLock(i_locked)

