#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatLightingMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Lighting modes.They are used by
                | theactivateLinkAnchor('Viewer3D','','Viewer3D')object.

    """

    def __init__(self, catia):
        self.catlightingmode = catia.CatLightingMode     

