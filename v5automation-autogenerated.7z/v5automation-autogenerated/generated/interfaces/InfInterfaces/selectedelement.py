#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SelectedElement:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an element contained by a Selection object.This object is
                | an object contained by
                | aactivateLinkAnchor('Selection','','Selection')object.
                | TheactivateLinkAnchor('Selection','','Selection')object containsactiva
                | teLinkAnchor('SelectedElement','','SelectedElement')objects, which are
                | accessed through theactivateLinkAnchor('Selection','Count2','Selection
                | .Count2')andactivateLinkAnchor('Selection','Item2','Selection.Item2')m
                | ethods.

    """

    def __init__(self, catia):
        self.selectedelement = catia.SelectedElement     

    @property
    def document(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Document
                | o Property Document(    ) As Document
                | 
                | Returns the document to which the selected element belongs.


                | Parameters:


        """
        return self.selectedelement.Document

    @property
    def leaf_product(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LeafProduct
                | o Property LeafProduct(    ) As AnyObject
                | 
                | Returns the leaf product corresponding to the selection in the
                | specification tree. Role: Returns the leaf
                | activateLinkAnchor('Product','','Product')  (component, corresponding
                | for example to "Product1.1" in the specification tree). The
                | activateLinkAnchor('AnyObject','','AnyObject')  returned is a
                | activateLinkAnchor('Product','','Product')  if a product appears in
                | the specification tree, in the path corresponding to the current
                | selection, and a fake  activateLinkAnchor('AnyObject','','AnyObject')
                | whose  activateLinkAnchor('AnyObject','Name','AnyObject.Name')
                | property equals to "InvalidLeafProduct" otherwise. Cumulated with the
                | use of the
                | activateLinkAnchor('AnyObject','Parent','AnyObject.Parent')  property
                | (which enables to navigate into the object structure), the current
                | property enables the scripter to obtain the path, in the specification
                | tree, corresponding to the selection.  Example:    The following
                | example supposes a  activateLinkAnchor('Part','','Part')  or a
                | activateLinkAnchor('Product','','Product')  is opened. It asks the end
                | user to select a  activateLinkAnchor('Shape','','Shape')  in the
                | current window. It then sends message boxes containing the names of
                | the automation objects contained in the specification tree path
                | corresponding to the shape selected, and, regarding the  automation
                | objects which are products (only products which are components), a
                | message box containing the  abcissa of the translation of the product
                | compared to its reference product.  Dim
                | Status,Feature,LeafProduct,LeafProductProcessed,InputObjectType(0) Dim
                | Document,Selection,AutomationTreeNodeOrProduct,Position,AxisComponents
                | Array(11) Set Document = CATIA.ActiveDocument : Set Selection =
                | Document.Selection'We propose to the user that he select a feature
                | InputObjectType(0)="AnyObject"
                | Status=Selection.SelectElement2(InputObjectType,"Select a
                | feature",true) if (Status = "Cancel") then Exit Sub Set Feature =
                | Selection.Item(1).Value Set LeafProduct =
                | Selection.Item(1).LeafProduct LeafProductProcessed = true if
                | (LeafProduct.Name<>"InvalidLeafProduct") then LeafProductProcessed =
                | false Set AutomationTreeNodeOrProduct = Feature do while
                | (TypeName(AutomationTreeNodeOrProduct)<>"Application")'  We send a
                | message box, if AutomationTreeNodeOrProduct is not nor a Shapes object
                | neither a PartDocument object     if
                | ((TypeName(AutomationTreeNodeOrProduct)<>"Shapes") And _
                | (TypeName(AutomationTreeNodeOrProduct)<>"Bodies") And _
                | (TypeName(AutomationTreeNodeOrProduct)<>"PartDocument") And _
                | (TypeName(AutomationTreeNodeOrProduct)<>"Products") And _
                | (TypeName(AutomationTreeNodeOrProduct)<>"ProductDocument")) then
                | msgbox AutomationTreeNodeOrProduct.Name         if
                | (TypeName(AutomationTreeNodeOrProduct)="Product") then'          We
                | display a message box containing the abcissa of the translation,
                | except in the case of the'          root product             if
                | (TypeName(AutomationTreeNodeOrProduct.Parent.Parent)<>"Application")
                | then                 Set Position =
                | AutomationTreeNodeOrProduct.Position                 Call
                | Position.GetComponents(AxisComponentsArray)                 msgbox
                | AxisComponentsArray(9)             end if         end if     end if'
                | We determine the next automation tree node or product     Set
                | AutomationTreeNodeOrProduct = AutomationTreeNodeOrProduct.Parent
                | if ((TypeName(AutomationTreeNodeOrProduct)="Application") And (Not
                | LeafProductProcessed)) then'      The specification tree path
                | corresponding to the selection contains at least one product, which
                | the current'      loop as not yet processed. It means that the parent
                | in the specification tree of the feature corresponding'      to the
                | last message box sent is LeafProduct         Set
                | AutomationTreeNodeOrProduct = LeafProduct         LeafProductProcessed
                | = true     end if loop If you run the preceeding piece of script, the
                | current document beeing a product with the following specification
                | tree:       +--------+      !Product3!     +----+---+          !
                | +- Product2 (Product2.1)             'translation value: 10          !
                | !          !     +- Product1 (Product1.1)       'translation value: 20
                | !           !          !           +- Part1 (Part1.1)
                | !                !          !                +- Part1          !
                | !          !                     +- PartBody          !
                | !          !                           +- Pad.1          +- Part2
                | (Part2.1) and you select Pad.1, the message boxes displayed will be:
                | Pad.1     PartBody     Part1     Part1.1     Product1.1     20
                | Product2.1     10     Product3


                | Parameters:


        """
        return self.selectedelement.LeafProduct

    @property
    def reference(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Reference
                | o Property Reference(    ) As Reference
                | 
                | Returns a Reference version of the Value property. Role: Returns a
                | activateLinkAnchor('Reference','','Reference')  version of
                | activateLinkAnchor('','Value','Value')  .


                | Parameters:


        """
        return self.selectedelement.Reference

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the string constant which describes the selected element
                | Automation type. This type is returned by the
                | activateLinkAnchor('','Value','Value')  property, and may be, for
                | instance "Pad" or "Line2D". Caution: This property gives the leaf
                | automation type of the object, in the inheritance hierarchy.
                | Nevertheless, after a call to  activateLinkAnchor('Selection','SelectE
                | lement2','Selection.SelectElement2')  ,  activateLinkAnchor('Selection
                | ','SelectElement3','Selection.SelectElement3')  ,  activateLinkAnchor(
                | 'Selection','SelectElement4','Selection.SelectElement4')  ,  activateL
                | inkAnchor('Selection','IndicateOrSelectElement2D','Selection.IndicateO
                | rSelectElement2D')  or  activateLinkAnchor('Selection','IndicateOrSele
                | ctElement3D','Selection.IndicateOrSelectElement3D')  ,  this property
                | gives the input filter string constant relative to the effective
                | selection (more precisely  the first filter string constant delivered
                | through the iFilterType parameter, for which the current automation
                | object fullfills the string constant). This string constant may be an
                | automation object name corresponding to the iFilterType parameter with
                | which  activateLinkAnchor('Selection','SelectElement2','Selection.Sele
                | ctElement2')  has previously been called, or even a
                | activateLinkAnchor('CATSelectionFilter','','CATSelectionFilter')
                | value name.   Example:    Suppose you run the following piece of
                | script:   Set Selection = CATIA.ActiveDocument.Selection'  We propose
                | to the user that he select a Prism or a Hole ReDim InputObjectType(1)
                | : InputObjectType(0)="Prism" : InputObjectType(1)="Hole"
                | Status=Selection.SelectElement2(InputObjectType,"Select a prism or a
                | hole",true) if (Status = "Cancel") then Exit Sub AutomationType =
                | Selection.Item(1).Type If the user selects a Pad, the script
                | AutomationType variable will contain "Prism" and not "Pad".
                | Consequently, in most cases, use the VBScript TypeName function
                | instead of this property.


                | Parameters:


        """
        return self.selectedelement.Type

    @property
    def value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Value
                | o Property Value(    ) As CATBaseDispatch
                | 
                | Returns the actual selected automation object.


                | Parameters:


        """
        return self.selectedelement.Value

    def get_coordinates(self, io_point):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCoordinates
                | o Sub GetCoordinates(    CATSafeArrayVariant    ioPoint)
                | 
                | Returns the coordinates of the pick point.


                | Parameters:
                | oPoint
                |  The coordinates of the pick point, i.e. the hit between the geometric object and the cursor. 
                |  The length of this parameter will be 3, except if the document is a 
                | 
                |  activateLinkAnchor('DrawingDocument','','DrawingDocument')


                | Examples:
                | 
                | This example retrieves the coordinates of the pick point in the
                | array myArray:
                | 
                | Dim oSelElem As SelectedElement
                | Set oSelElem = CATIA.ActiveDocument.Selection.Item(1)
                | ReDim myArray(2)
                | oSelElem.GetCoordinates myArray
                | 
                | 
                | 
        """
        return self.selectedelement.GetCoordinates(io_point)

