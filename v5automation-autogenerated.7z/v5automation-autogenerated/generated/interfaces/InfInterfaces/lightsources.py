#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class LightSources:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all the LightSource objects.This collection is
                | currently managed by
                | aactivateLinkAnchor('Viewer3D','','Viewer3D')object.

    """

    def __init__(self, catia):
        self.lightsources = catia.LightSources     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As LightSource
                | 
                | Adds a new light source to the LightSources collection.


                | Parameters:


        """
        return self.lightsources.Add()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    long    iIndex) As LightSource
                | 
                | Returns a light source from its index in the LightSources collection.


                | Parameters:
                | iIndex
                |    The index of the light source to retrieve in the collection of
                |    light sources.
                |    Compared with other collections, you cannot use the name of the
                |    light source as argument.
                |  
                | 
                |  Returns:
                |   The retrieved light source


                | Examples:
                | 
                | 
                | The following example returns in MyLightSource the sixth
                | light source in the collection.
                | 
                | Dim MyLightSource As LightSource
                | Set MyLightSource = LightSources.Item(6)
                | 
                | 
        """
        return self.lightsources.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    long    iIndex)
                | 
                | Removes a light source from the LightSources collection.


                | Parameters:
                | iIndex
                |    The index of the light source to remove.
                |    Compared with other collections, you cannot use the name of the
                |    light source as argument.


                | Examples:
                | 
                | 
                | The following example removes the second light source
                | in the collection attached to the active viewer.
                | This viewer must be a
                | 
                | activateLinkAnchor('Viewer3D','','Viewer3D')  object.
                | Dim MyViewer As Viewer
                | Set MyViewer = CATIA.ActiveWindow.ActiveViewer
                | MyViewer.LightSources.Remove(2)
                | 
                | 
        """
        return self.lightsources.Remove(i_index)

