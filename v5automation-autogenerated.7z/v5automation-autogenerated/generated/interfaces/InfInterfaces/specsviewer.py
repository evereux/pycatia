#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SpecsViewer:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the specification tree viewer.This viewer displays the
                | document's specification tree according to the chosen layout, and can
                | only be included in a SpecsAndGeomWindow object.

    """

    def __init__(self, catia):
        self.specsviewer = catia.SpecsViewer     

    @property
    def layout(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Layout
                | o Property Layout(    ) As CatSpecsLayout
                | 
                | Returns or sets the specification tree layout.  Example: This example
                | sets the specification tree layout for the SpecsTreeViewer
                | specification tree viewer to catSpecsViewerHorizontalCentered.
                | SpecsTreeViewer.Layout = catSpecsViewerHorizontalCentered


                | Parameters:


        """
        return self.specsviewer.Layout

