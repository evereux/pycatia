#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATGenConferencing:
    """
        .. note::
            CAA V5 Visual Basic help

                | The Conference Driver setting attribute range of values.This property
                | isnot available on UNIXRole: This enum is used in theactivateLinkAncho
                | r('GeneralSessionSettingAtt','','GeneralSessionSettingAtt')interface.

    """

    def __init__(self, catia):
        self.catgenconferencing = catia.CATGenConferencing     

