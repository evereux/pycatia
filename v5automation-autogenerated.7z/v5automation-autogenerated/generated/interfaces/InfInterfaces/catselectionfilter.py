#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATSelectionFilter:
    """
        .. note::
            CAA V5 Visual Basic help

                | Values to use as selection filter.Role: Values which can be given as
                | filter toactivateLinkAnchor('Selection','SelectElement2','Selection.Se
                | lectElement2'),activateLinkAnchor('Selection','SelectElement3','Select
                | ion.SelectElement3'),activateLinkAnchor('Selection','IndicateOrSelectE
                | lement2D','Selection.IndicateOrSelectElement2D')oractivateLinkAnchor('
                | Selection','IndicateOrSelectElement3D','Selection.IndicateOrSelectElem
                | ent3D'), beside the automation object names.

    """

    def __init__(self, catia):
        self.catselectionfilter = catia.CATSelectionFilter     

