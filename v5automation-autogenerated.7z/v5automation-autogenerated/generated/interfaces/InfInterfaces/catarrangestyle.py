#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatArrangeStyle:
    """
        .. note::
            CAA V5 Visual Basic help

                | Window arrangement style.

    """

    def __init__(self, catia):
        self.catarrangestyle = catia.CatArrangeStyle     

