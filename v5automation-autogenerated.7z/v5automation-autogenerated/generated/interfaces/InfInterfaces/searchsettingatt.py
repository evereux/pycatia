#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SearchSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the setting controller for the Search property tab
                | page.Role: The setting controller is the object that enables to get
                | and set setting parameters.

    """

    def __init__(self, catia):
        self.searchsettingatt = catia.SearchSettingAtt     

    @property
    def deep_search_activation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DeepSearchActivation
                | o Property DeepSearchActivation(    ) As boolean
                | 
                | Returns or sets the Deep Search Activation attribute. Role: The Deep
                | Search Activation attribute manages the Deep Search option  available
                | in the Search dialog box used to determine whether documents in
                | visualization  mode must be transiently loaded during a search query


                | Parameters:


        """
        return self.searchsettingatt.DeepSearchActivation

    @property
    def default_power_input_context_priority(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultPowerInputContextPriority
                | o Property DefaultPowerInputContextPriority(    ) As boolean
                | 
                | Returns or sets the Default Power Input Context Priority attribute.
                | Role: The Default Power Input Context Priority attribute manages
                | whether the default  context scope must override the context scope
                | stored in a favorite query


                | Parameters:


        """
        return self.searchsettingatt.DefaultPowerInputContextPriority

    @property
    def default_power_input_context_scope(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultPowerInputContextScope
                | o Property DefaultPowerInputContextScope(    ) As CATSearchContextScope
                | 
                | Returns or sets the Default Power Input Context Scope attribute. Role:
                | The Default Power Input Context Scope attribute manages the default
                | context scope  to be used when none is typed in the Power Input field


                | Parameters:


        """
        return self.searchsettingatt.DefaultPowerInputContextScope

    @property
    def default_power_input_prefix(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultPowerInputPrefix
                | o Property DefaultPowerInputPrefix(    ) As CATBSTR
                | 
                | Returns or sets the Default Power Input Prefix attribute. Role: The
                | Default Power Input Prefix attribute manages the default prefix  to be
                | used when none is typed in the Power Input field


                | Parameters:


        """
        return self.searchsettingatt.DefaultPowerInputPrefix

    @property
    def max_displayed_results(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxDisplayedResults
                | o Property MaxDisplayedResults(    ) As long
                | 
                | Returns or sets the Max Displayed Results attribute. Role: The Max
                | Displayed Results attribute indicates the maximum number of elements
                | that can be displayed in the Search results page. Displaying too many
                | lines can stick more  or less the results list so it is recommended to
                | limit this number.


                | Parameters:


        """
        return self.searchsettingatt.MaxDisplayedResults

    @property
    def max_pre_highlighted_elements(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxPreHighlightedElements
                | o Property MaxPreHighlightedElements(    ) As long
                | 
                | Returns or sets the Max Pre-Highlighted Elements attribute. Role: The
                | Max Pre-Highlighted Elements attribute indicates the maximum number of
                | elements  that can be displayed in the Search results page. Displaying
                | too many elements can stick the session  so it is strongly recommended
                | to limit this number.


                | Parameters:


        """
        return self.searchsettingatt.MaxPreHighlightedElements

    def get_deep_search_activation_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDeepSearchActivationInfo
                | o Func GetDeepSearchActivationInfo(    CATBSTR    oAdminLevel,
                |                                        CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the Deep Search Activation setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.GetDeepSearchActivationInfo(o_admin_level, o_locked)

    def get_default_power_input_context_priority_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultPowerInputContextPriorityInfo
                | o Func GetDefaultPowerInputContextPriorityInfo(    CATBSTR    oAdminLevel,
                |                                                    CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the Default Power Input Context Priority
                | setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.GetDefaultPowerInputContextPriorityInfo(o_admin_level, o_locked)

    def get_default_power_input_context_scope_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultPowerInputContextScopeInfo
                | o Func GetDefaultPowerInputContextScopeInfo(    CATBSTR    oAdminLevel,
                |                                                 CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the Default Power Input Context Scope
                | setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.GetDefaultPowerInputContextScopeInfo(o_admin_level, o_locked)

    def get_default_power_input_prefix_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultPowerInputPrefixInfo
                | o Func GetDefaultPowerInputPrefixInfo(    CATBSTR    oAdminLevel,
                |                                           CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the Default Power Input Prefix setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.GetDefaultPowerInputPrefixInfo(o_admin_level, o_locked)

    def get_max_displayed_results_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMaxDisplayedResultsInfo
                | o Func GetMaxDisplayedResultsInfo(    CATBSTR    oAdminLevel,
                |                                       CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the Max Displayed Results setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.GetMaxDisplayedResultsInfo(o_admin_level, o_locked)

    def get_max_pre_highlighted_elements_info(self, o_admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMaxPreHighlightedElementsInfo
                | o Func GetMaxPreHighlightedElementsInfo(    CATBSTR    oAdminLevel,
                |                                             CATBSTR    oLocked) As boolean
                | 
                | Retrieves information about the Max Displayed Results setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.GetMaxPreHighlightedElementsInfo(o_admin_level, o_locked)

    def set_deep_search_activation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDeepSearchActivationLock
                | o Sub SetDeepSearchActivationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Deep Search Activation setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.searchsettingatt.SetDeepSearchActivationLock(i_locked)

    def set_default_power_input_context_priority_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultPowerInputContextPriorityLock
                | o Sub SetDefaultPowerInputContextPriorityLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Default Power Input Context Priority setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.SetDefaultPowerInputContextPriorityLock(i_locked)

    def set_default_power_input_context_scope_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultPowerInputContextScopeLock
                | o Sub SetDefaultPowerInputContextScopeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Default Power Input Context Scope setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.SetDefaultPowerInputContextScopeLock(i_locked)

    def set_default_power_input_prefix_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultPowerInputPrefixLock
                | o Sub SetDefaultPowerInputPrefixLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Default Power Input Prefix setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.SetDefaultPowerInputPrefixLock(i_locked)

    def set_max_displayed_results_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMaxDisplayedResultsLock
                | o Sub SetMaxDisplayedResultsLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Max Displayed Results setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.SetMaxDisplayedResultsLock(i_locked)

    def set_max_pre_highlighted_elements_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMaxPreHighlightedElementsLock
                | o Sub SetMaxPreHighlightedElementsLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Max Displayed Results setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.searchsettingatt.SetMaxPreHighlightedElementsLock(i_locked)

