#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SystemConfiguration:
    """
        .. note::
            CAA V5 Visual Basic help

                | Provides abstractions to resources which depend on the platform or the
                | current configuration.

    """

    def __init__(self, catia):
        self.systemconfiguration = catia.SystemConfiguration     

    @property
    def operating_system(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OperatingSystem
                | o Property OperatingSystem(    ) As CATBSTR
                | 
                | Returns a string which identifies the operating system on which the
                | application is currently running. Examples of identifiers include:
                | intel_a, solaris_a, aix_a, win_a and hpux_a.


                | Parameters:
                | oOperatingSystem
                |  The operating system identifier.


        """
        return self.systemconfiguration.OperatingSystem

    @property
    def product_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProductCount
                | o Property ProductCount(    ) As long
                | 
                | Returns the number of product names names currently known to the
                | system.


                | Parameters:
                | oProductCount
                |  The number of product names currently known to the system.


        """
        return self.systemconfiguration.ProductCount

    @property
    def release(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Release
                | o Property Release(    ) As long
                | 
                | Returns the CATIA release number.


                | Parameters:
                | oVersion
                |  The CATIA release number.


        """
        return self.systemconfiguration.Release

    @property
    def service_pack(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ServicePack
                | o Property ServicePack(    ) As long
                | 
                | Returns the CATIA service pack number.


                | Parameters:
                | oServicePack
                |  The CATIA service pack number.


        """
        return self.systemconfiguration.ServicePack

    @property
    def version(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Version
                | o Property Version(    ) As long
                | 
                | Returns the CATIA version number (usually version 5).


                | Parameters:
                | oVersion
                |  The CATIA version.


        """
        return self.systemconfiguration.Version

    def get_product_names(self, io_product_names):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProductNames
                | o Sub GetProductNames(    CATSafeArrayVariant    ioProductNames)
                | 
                | Returns the product names of all the licenses currently known to the
                | system.


                | Parameters:
                | CATSafeArrayVariant
                |  An properly dimensioned array of strings in which the product names
                |  will be stored.


                | Examples:
                | 
                | 
                | This example determines if the first product in the list of
                | known product names is authorized.
                | 
                | Dim SystemConfiguration1 As SystemConfiguration
                | Set SystemConfiguration1 = CATIA.SystemConfiguration
                | ReDim NameArray(SystemConfiguration1.ProductNamesCount)
                | SystemConfiguration1.GetProductNames NameArray
                | MsgBox "IsProductAuthorized for product " & NameArray(0) & "  returns " & SystemConfiguration1.IsProductAuthorized(NameArray(0))
                | 
                | 
                | 
                | 
                | 
        """
        return self.systemconfiguration.GetProductNames(io_product_names)

    def is_product_authorized(self, i_product_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsProductAuthorized
                | o Func IsProductAuthorized(    CATBSTR    iProductName) As boolean
                | 
                | Returns True if the specified product is authorized, False otherwise.


                | Parameters:
                | iProductName
                |  The name of the product to check.
                |  
                |  oAuthorized
                |  A boolean which specifies if the product is authorized.


        """
        return self.systemconfiguration.IsProductAuthorized(i_product_name)

