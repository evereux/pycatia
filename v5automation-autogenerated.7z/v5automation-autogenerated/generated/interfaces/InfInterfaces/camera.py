#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Camera:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the camera.The camera is the object that stores a viewpoint
                | saved from a viewer at a given moment using
                | theactivateLinkAnchor('Viewer','NewCamera','Viewer.NewCamera')method
                | of theactivateLinkAnchor('Viewer','','Viewer')object. The viewpoint
                | stored in the camera can then be applied to another viewer to display
                | the document in this viewer according to this viewpoint.

    """

    def __init__(self, catia):
        self.camera = catia.Camera     

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CatCameraType
                | 
                | Returns the camera's type.  Example: This example retrieves in
                | MyCameraType the type of the MyCamera 3D camera and applies the
                | viewpoint stored in this camera to the active viewer.  MyCameraType =
                | MyCamera.Type CATIA.ActiveWindow.ActiveViewer.Viewpoint3D =
                | MyCamera.Viewpoint3D  The value returned by the Type property in
                | MyCameraType is catCamera3D


                | Parameters:


        """
        return self.camera.Type

