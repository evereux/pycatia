#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATSearchContextScope:
    """
        .. note::
            CAA V5 Visual Basic help

                | The Default Power Input Context Scope setting attribute range of
                | values.Role: This enum is used in theactivateLinkAnchor('SearchSetting
                | Att','','SearchSettingAtt')interface.

    """

    def __init__(self, catia):
        self.catsearchcontextscope = catia.CATSearchContextScope     

