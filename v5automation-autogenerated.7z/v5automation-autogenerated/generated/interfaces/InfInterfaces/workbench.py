#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Workbench:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a workbench on a document.Role:A workbench is a set of
                | commands that can be used to create, modify and edit the objects
                | making up the document.

    """

    def __init__(self, catia):
        self.workbench = catia.Workbench     

