#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Camera3D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a 3D camera.The 3D camera stores a 3D viewpoint, that is
                | aactivateLinkAnchor('Viewpoint3D','','Viewpoint3D')object.

    """

    def __init__(self, catia):
        self.camera3d = catia.Camera3D     

    @property
    def viewpoint_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viewpoint3D
                | o Property Viewpoint3D(    ) As Viewpoint3D
                | 
                | Returns or sets the 3D viewpoint of a 3D camera.  Example: Assume the
                | active window is a
                | activateLinkAnchor('SpecsAndGeomWindow','','SpecsAndGeomWindow')
                | object. This example retrieves the
                | activateLinkAnchor('Viewpoint3D','','Viewpoint3D')  of the active 3D
                | viewer and creates from it a Camera3D you handle using the MyCamera
                | variable. Then the camera zoom is set to 2, and the camera's viewpoint
                | is assigned to the active viewer.  Dim MyCamera As Camera3D Set
                | MyCamera = CATIA.ActiveWindow.ActiveViewer.NewCamera()
                | MyCamera.Viewpoint3D.Zoom = 2
                | CATIA.ActiveWindow.ActiveViewer.Viewpoint3D = MyCamera.Viewpoint3D


                | Parameters:


        """
        return self.camera3d.Viewpoint3D

