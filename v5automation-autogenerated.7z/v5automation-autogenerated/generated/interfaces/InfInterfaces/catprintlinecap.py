#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatPrintLineCap:
    """
        .. note::
            CAA V5 Visual Basic help

                | CatPrintLineCap.It used by
                | theactivateLinkAnchor('PageSetup','','PageSetup')object for document
                | printing.

    """

    def __init__(self, catia):
        self.catprintlinecap = catia.CatPrintLineCap     

