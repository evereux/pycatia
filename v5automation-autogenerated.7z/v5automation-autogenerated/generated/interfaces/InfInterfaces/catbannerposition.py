#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatBannerPosition:
    """
        .. note::
            CAA V5 Visual Basic help

                | Banner position.This banner is used by
                | theactivateLinkAnchor('PageSetup','','PageSetup')object for document
                | printing. It is composed of a customized text, and possibly a logo.

    """

    def __init__(self, catia):
        self.catbannerposition = catia.CatBannerPosition     

