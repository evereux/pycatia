#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Viewer3D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a 3D viewer.The 3D viewer aggregates a 3D viewpoint to
                | display a 3D scene. In addition, the Viewer3D object manages the
                | lighting, the depth effects, the navigation style, and the rendering
                | mode.

    """

    def __init__(self, catia):
        self.viewer3d = catia.Viewer3D     

    @property
    def clipping_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingMode
                | o Property ClippingMode(    ) As CatClippingMode
                | 
                | Returns or sets the clipping mode.  Example: This example sets the
                | depth effect for the My3DViewer 3D viewer to
                | catClippingModeNearAndFar.  My3DViewer.ClippingMode =
                | catClippingModeNearAndFar


                | Parameters:


        """
        return self.viewer3d.ClippingMode

    @property
    def far_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FarLimit
                | o Property FarLimit(    ) As double
                | 
                | Returns or sets the far limit for the far clipping plane. The distance
                | is measured from the eye location, that is the origin of the
                | viewpoint, and is expressed in model unit. The far clipping plane is
                | available with the catClippingModeFar and catClippingModeNearAndFar
                | values of the
                | activateLinkAnchor('CatClippingMode','','CatClippingMode')
                | enumeration only.  Example: This example sets the far limit for the
                | far clipping plane of the My3DViewer 3D viewer to 150 model units.
                | My3DViewer.FarLimit = 150


                | Parameters:


        """
        return self.viewer3d.FarLimit

    @property
    def foggy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Foggy
                | o Property Foggy(    ) As boolean
                | 
                | Returns or sets the fog mode. Useful when clipping is enabled.
                | Example: This example sets the fog on for the My3DViewer 3D viewer:
                | My3DViewer.Foggy = True


                | Parameters:


        """
        return self.viewer3d.Foggy

    @property
    def ground(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Ground
                | o Property Ground(    ) As boolean
                | 
                | Returns or sets the ground displaying mode.   Example: This example
                | makes the ground visible for the My3DViewer 3D viewer:
                | My3DViewer.Ground = True


                | Parameters:


        """
        return self.viewer3d.Ground

    @property
    def light_sources(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LightSources
                | o Property LightSources(    ) As LightSources
                | 
                | Returns the viewer's light source collection.  Example: This example
                | retrieves the light source collection for the My3DViewer 3D viewer in
                | VPLightSources.  Set VPLightSources = My3DViewer.LightSources


                | Parameters:


        """
        return self.viewer3d.LightSources

    @property
    def lighting_intensity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LightingIntensity
                | o Property LightingIntensity(    ) As double
                | 
                | Returns or sets the lighting intensity. The lighting intensity ranges
                | between 0 and 1.  Example: This example sets the lighting intensity
                | for the My3DViewer 3D viewer to 0.35.  My3DViewer.LightingIntensity =
                | 0.35


                | Parameters:


        """
        return self.viewer3d.LightingIntensity

    @property
    def lighting_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LightingMode
                | o Property LightingMode(    ) As CatLightingMode
                | 
                | Returns or sets the lighting mode.  Example: This example sets the
                | lighting mode for the My3DViewer 3D viewer to catInfiniteLightSource.
                | My3DViewer.LightingMode = catInfiniteLightSource


                | Parameters:


        """
        return self.viewer3d.LightingMode

    @property
    def navigation_style(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NavigationStyle
                | o Property NavigationStyle(    ) As CatNavigationStyle
                | 
                | Returns or sets the navigation style.  Example: This example sets the
                | navigation style for the My3DViewer 3D viewer to catNavigationWalk.
                | My3DViewer.NavigationStyle = catNavigationWalk


                | Parameters:


        """
        return self.viewer3d.NavigationStyle

    @property
    def near_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NearLimit
                | o Property NearLimit(    ) As double
                | 
                | Returns or sets the near limit for the near clipping plane. The
                | distance is measured from the eye location, that is the origin of the
                | viewpoint, and is expressed in model unit. The near clipping plane is
                | available with the catClippingModeNear and catClippingModeNearAndFar
                | values of the
                | activateLinkAnchor('CatClippingMode','','CatClippingMode')
                | enumeration only.  Example: This example sets the near limit for the
                | near clipping plane of the My3DViewer 3D viewer to 75 model units.
                | My3DViewer.NearLimit = 75


                | Parameters:


        """
        return self.viewer3d.NearLimit

    @property
    def rendering_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RenderingMode
                | o Property RenderingMode(    ) As CatRenderingMode
                | 
                | Returns or sets the rendering mode.  Example: This example sets the
                | rendering mode for the My3DViewer 3D viewer to
                | catRenderShadingWithEdges.  My3DViewer.RenderingMode =
                | catRenderShadingWithEdges


                | Parameters:


        """
        return self.viewer3d.RenderingMode

    @property
    def viewpoint_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viewpoint3D
                | o Property Viewpoint3D(    ) As Viewpoint3D
                | 
                | Returns or sets the 3D viewpoint of a 3D viewer.  Example: This
                | example retrieves the Nice3DViewpoint 3D viewpoint from the My3DViewer
                | 3D viewer.  Dim Nice3DViewpoint As Viewpoint3D Set Nice3DViewpoint =
                | My3DViewer.Viewpoint3D


                | Parameters:


        """
        return self.viewer3d.Viewpoint3D

    def rotate(self, i_axis, i_angle):
        """
        .. note::
            CAA V5 Visual Basic help

                | Rotate
                | o Sub Rotate(    CATSafeArrayVariant    iAxis,
                |                  double    iAngle)
                | 
                | Applies a rotation. The rotation of iAngle degrees is applied to the
                | viewer's contents around the axis iAxis (an array of 3 Variants), the
                | invariant  point being the target (ie: Origin +
                | FocusDistance*SightDirection).  Example: This applies a rotation of 10
                | degrees around the Up Direction to the contents of the MyViewer3D
                | viewer.  MyViewer3D.Rotate MyViewer3D.UpDirection, 10


                | Parameters:


        """
        return self.viewer3d.Rotate(i_axis, i_angle)

    def translate(self, i_vector):
        """
        .. note::
            CAA V5 Visual Basic help

                | Translate
                | o Sub Translate(    CATSafeArrayVariant    iVector)
                | 
                | Applies a translation. The translation vector is iVector (an array of
                | 3 Variants).  Example: This applies a translation along (1, 1, 1) to
                | the contents of the MyViewer3D viewer.  MyViewer3D.Translate Array(1,
                | 1, 1)


                | Parameters:


        """
        return self.viewer3d.Translate(i_vector)

