#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Cameras:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all the Camera objects currently attached to a
                | Document object.A camera can be created using
                | theactivateLinkAnchor('Viewer','NewCamera','Viewer.NewCamera')method
                | of theactivateLinkAnchor('Viewer','','Viewer')object. The first
                | seventh cameras of the collection
                | areactivateLinkAnchor('Camera3D','','Camera3D')objects and cannot be
                | modified or removed. They can just be retrieved and used "as is". They
                | store the following viewpoints whose sight direction is always toward
                | the 3D-axis system origin:The cameras of the Cameras collection are
                | available using the dialog box displayed by clicking the View->Defined
                | Views menu.

    """

    def __init__(self, catia):
        self.cameras = catia.Cameras     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As Camera
                | 
                | Returns a camera using its index or its name from the Cameras
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the camera to retrieve from
                |    the collection of cameras.
                |    As a numerics, this index is the rank of the camera
                |    in the collection.
                |    The index of the first camera in the collection is 1, and
                |    the index of the last camera is Count.
                |    As a string, it is the name you assigned to the camera using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved camera


                | Examples:
                | 
                | 
                | This example retrieves in ThisCamera the ninth camera,
                | and in ThatCamera the camera named
                | MyCamera in the camera collection of the active document.
                | 
                | Dim ThisCamera As Camera
                | Set ThisCamera = CATIA.ActiveDocument.Cameras.Item(9)
                | Dim ThatCamera As Camera
                | Set ThatCamera = CATIA.ActiveDocument.Cameras.Item("MyCamera")
                | 
                | 
                | 
        """
        return self.cameras.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes a camera from the Cameras collection.


                | Parameters:
                | iIndex
                |    The index or the name of the camera to remove from
                |    the collection of cameras.
                |    As a numerics, this index is the rank of the camera
                |    in the collection.
                |    The index of the first camera in the collection is 1, and
                |    the index of the last camera is Count.
                |    As a string, it is the name you assigned to the camera using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.   You cannot remove the first seventh cameras in the collection.


                | Examples:
                | 
                | 
                | The following example removes the tenth camera and the camera named
                | CameraToBeRemoved in the camera collection
                | of the active document.
                | 
                | CATIA.ActiveDocument.Cameras.Remove(10)
                | CATIA.ActiveDocument.Cameras.Remove("CameraToBeRemoved")
                | 
                | 
        """
        return self.cameras.Remove(i_index)

