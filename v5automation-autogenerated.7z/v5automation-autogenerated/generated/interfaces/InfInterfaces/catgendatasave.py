#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATGenDataSave:
    """
        .. note::
            CAA V5 Visual Basic help

                | The Data Save setting attribute range of values.Role: This enum is
                | used in theactivateLinkAnchor('GeneralSessionSettingAtt','','GeneralSe
                | ssionSettingAtt')interface.

    """

    def __init__(self, catia):
        self.catgendatasave = catia.CATGenDataSave     

