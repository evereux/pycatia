#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class LightSource:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the light source.The light source is the object that stores
                | lighting data used by a viewer to display a scene where a document is
                | presented. Two kinds of light sources are available: an infinite light
                | source and a neon lighting system simulating a set of parallel neon
                | tubes.

    """

    def __init__(self, catia):
        self.lightsource = catia.LightSource     

    def get_direction(self, o_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDirection
                | o Sub GetDirection(    CATSafeArrayVariant    oDirection)
                | 
                | Returns the lighting direction as an array of 3 variants. This value
                | is available with an infinite light source only.  Example: This
                | example gets the lighting direction of the LightSource light source to
                | the direction with components (5,8,-2).  Dim direction(2)
                | LightSource.GetDirection direction


                | Parameters:


        """
        return self.lightsource.GetDirection(o_direction)

    def put_direction(self, o_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutDirection
                | o Sub PutDirection(    CATSafeArrayVariant    oDirection)
                | 
                | Defines the lighting direction as an array of 3 variants. This value
                | can be set with an infinite light source only.  Example: This example
                | defines the lighting direction of the LightSource light source to the
                | direction with components (5,8,-2).  LightSource.PutDirection
                | Array(5,8,-2)


                | Parameters:


        """
        return self.lightsource.PutDirection(o_direction)

