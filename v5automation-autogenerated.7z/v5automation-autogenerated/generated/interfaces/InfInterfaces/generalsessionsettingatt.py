#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class GeneralSessionSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Setting controller for the General property tab page.Role: This
                | interface is implemented by a component which represents the
                | controller of the general settings.

    """

    def __init__(self, catia):
        self.generalsessionsettingatt = catia.GeneralSessionSettingAtt     

    @property
    def auto_save(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoSave
                | o Property AutoSave(    ) As CATGenDataSave
                | 
                | Returns the data save parameter.


                | Parameters:


        """
        return self.generalsessionsettingatt.AutoSave

    @property
    def conferencing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Conferencing
                | o Property Conferencing(    ) As CATGenConferencing
                | 
                | Returns the conference driver parameter.


                | Parameters:


        """
        return self.generalsessionsettingatt.Conferencing

    @property
    def drag_drop(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DragDrop
                | o Property DragDrop(    ) As boolean
                | 
                | Returns the drag & drop parameter.


                | Parameters:


        """
        return self.generalsessionsettingatt.DragDrop

    @property
    def ref_doc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RefDoc
                | o Property RefDoc(    ) As boolean
                | 
                | Returns the referenced documents parameter.


                | Parameters:


        """
        return self.generalsessionsettingatt.RefDoc

    @property
    def time_roll(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimeRoll
                | o Property TimeRoll(    ) As long
                | 
                | Returns the data save parameter (in milliseconds).


                | Parameters:


        """
        return self.generalsessionsettingatt.TimeRoll

    @property
    def ui_style(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UIStyle
                | o Property UIStyle(    ) As CATGenUIStyle
                | 
                | Returns the user interface style parameter.


                | Parameters:


        """
        return self.generalsessionsettingatt.UIStyle

    def get_auto_save_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoSaveInfo
                | o Func GetAutoSaveInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the data save parameter.
                | Role:Retrieves the state of the data save parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.generalsessionsettingatt.GetAutoSaveInfo(io_admin_level, io_locked)

    def get_conferencing_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetConferencingInfo
                | o Func GetConferencingInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the conference driver
                | parameter. Role:Retrieves the state of the conference driver parameter
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.generalsessionsettingatt.GetConferencingInfo(io_admin_level, io_locked)

    def get_drag_drop_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDragDropInfo
                | o Func GetDragDropInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the drag & drop parameter.
                | Role:Retrieves the state of the drag & drop parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.generalsessionsettingatt.GetDragDropInfo(io_admin_level, io_locked)

    def get_ref_doc_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRefDocInfo
                | o Func GetRefDocInfo(    CATBSTR    ioAdminLevel,
                |                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the referenced documents
                | parameter. Role:Retrieves the state of the referenced documents
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.generalsessionsettingatt.GetRefDocInfo(io_admin_level, io_locked)

    def get_ui_style_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUIStyleInfo
                | o Func GetUIStyleInfo(    CATBSTR    ioAdminLevel,
                |                           CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the user interface style
                | parameter. Role:Retrieves the state of the user interface style
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |       level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.generalsessionsettingatt.GetUIStyleInfo(io_admin_level, io_locked)

    def set_auto_save_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoSaveLock
                | o Sub SetAutoSaveLock(    boolean    iLocked)
                | 
                | Locks or unlocks the data save parameter. Role:Locks or unlocks the
                | data save parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.generalsessionsettingatt.SetAutoSaveLock(i_locked)

    def set_conferencing_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetConferencingLock
                | o Sub SetConferencingLock(    boolean    iLocked)
                | 
                | Locks or unlocks the conference driver parameter. Role:Locks or
                | unlocks the conference driver parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.generalsessionsettingatt.SetConferencingLock(i_locked)

    def set_drag_drop_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDragDropLock
                | o Sub SetDragDropLock(    boolean    iLocked)
                | 
                | Locks or unlocks the drag & drop parameter. Role:Locks or unlocks the
                | drag & drop parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.generalsessionsettingatt.SetDragDropLock(i_locked)

    def set_ref_doc_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRefDocLock
                | o Sub SetRefDocLock(    boolean    iLocked)
                | 
                | Locks or unlocks the referenced documents parameter. Role:Locks or
                | unlocks the referenced documents parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.generalsessionsettingatt.SetRefDocLock(i_locked)

    def set_ui_style_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUIStyleLock
                | o Sub SetUIStyleLock(    boolean    iLocked)
                | 
                | Locks or unlocks the user interface style parameter. Role:Locks or
                | unlocks the user interface style parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.generalsessionsettingatt.SetUIStyleLock(i_locked)

