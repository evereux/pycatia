#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Viewer2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a 2D viewer.The 2D viewer aggregates a 2D viewpoint to
                | display a 2D scene.

    """

    def __init__(self, catia):
        self.viewer2d = catia.Viewer2D     

    @property
    def viewpoint2_d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Viewpoint2D
                | o Property Viewpoint2D(    ) As Viewpoint2D
                | 
                | Returns or sets the 2D viewpoint of a 2D viewer.  Example: This
                | example retrieves the Nice2DViewpoint 2D viewpoint from the My2DViewer
                | 2D viewer.  Dim Nice2DViewpoint As Viewpoint2D Set Nice2DViewpoint =
                | My2DViewer.Viewpoint2D


                | Parameters:


        """
        return self.viewer2d.Viewpoint2D

