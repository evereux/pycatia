#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATMultiSelectionMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Types of multi-selection.Role: This enum is used by theactivateLinkAnc
                | hor('Selection','SelectElement3','Selection.SelectElement3')method.

    """

    def __init__(self, catia):
        self.catmultiselectionmode = catia.CATMultiSelectionMode     

