#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatViewFilterCreationMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | At creation of a view, this enum defines how the filter of this view
                | is configured.

    """

    def __init__(self, catia):
        self.catviewfiltercreationmode = catia.CatViewFilterCreationMode     

