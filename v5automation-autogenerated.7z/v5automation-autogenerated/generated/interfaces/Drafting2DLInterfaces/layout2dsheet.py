#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Layout2DSheet:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Layout2D Sheet.

    """

    def __init__(self, catia):
        self.layout2dsheet = catia.Layout2DSheet     

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property Orientation(    ) As CatPaperOrientation
                | 
                | Returns or sets the paper orientation. Example: This example sets the
                | paper orientation for the MySheet Layout2D sheet to catPaperLandscape.
                | MySheet.Orientation = catPaperLandscape


                | Parameters:


        """
        return self.layout2dsheet.Orientation

    @property
    def page_setup(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PageSetup
                | o Property PageSetup(    ) As DrawingPageSetup
                | 
                | Returns the page setup. Example: This example returns the page setup
                | for the MySheet Layout2D sheet.  Dim MySheetPageSetup As
                | DrawingPageSetup Set MySheetPageSetup = MySheet.PageSetup


                | Parameters:


        """
        return self.layout2dsheet.PageSetup

    @property
    def paper_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperHeight
                | o Property PaperHeight(    ) As double
                | 
                | Gets or Sets the paper width of the layout sheet.


                | Parameters:
                | oPaperHeight


                | Examples:
                | 
                | 
                | This example get the height of the Layout2DSheet1.
                | 
                | Layout2DSheet1.GetPaperHeight oPaperHeight
                | 
                | 
                | 
                | 
                | 
        """
        return self.layout2dsheet.PaperHeight

    @property
    def paper_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperName
                | o Property PaperName(    ) As CATBSTR
                | 
                | Returns or sets the paper format name. Example: This example sets the
                | paper format name for the MySheet Layout2D sheet to DSFormat1.
                | MySheet.PaperName = DSFormat1


                | Parameters:


        """
        return self.layout2dsheet.PaperName

    @property
    def paper_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperSize
                | o Property PaperSize(    ) As CatPaperSize
                | 
                | Returns or sets the paper size. Example: This example sets the page
                | size for the MySheet Layout2D sheet to catPaperA4.  MySheet.PaperSize
                | = catPaperA4


                | Parameters:


        """
        return self.layout2dsheet.PaperSize

    @property
    def paper_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperWidth
                | o Property PaperWidth(    ) As double
                | 
                | Gets or Sets the paper width of the layout sheet.


                | Parameters:
                | oPaperWidth


                | Examples:
                | 
                | 
                | This example get the width of the Sheet1.
                | 
                | Sheet1.GetPaperWidth oPaperWidth
                | 
                | 
                | 
                | 
                | 
        """
        return self.layout2dsheet.PaperWidth

    @property
    def print_area(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintArea
                | o Property PrintArea(    ) As PrintArea
                | 
                | Returns the print area definition object. Example: This example
                | returns the print area for the MySheet Layout2D sheet 2DL.  Dim
                | MyPrintArea As PrintArea Set MyPrintArea = MySheet.PrintArea


                | Parameters:


        """
        return self.layout2dsheet.PrintArea

    @property
    def projection_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProjectionMethod
                | o Property ProjectionMethod(    ) As CatSheetProjectionMethod
                | 
                | Returns or sets the sheet projection mode . Example: This example sets
                | the projection mode of the MySheet Layout2D sheet to catFirstAngle.
                | MySheet.ProjectionMethod = catFirstAngle


                | Parameters:


        """
        return self.layout2dsheet.ProjectionMethod

    @property
    def sheet_scale(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SheetScale
                | o Property SheetScale(    ) As double
                | 
                | Returns or sets the scale of the Layout2D sheet. Example: This example
                | sets the scale of the MySheet Layout2D sheet to 0.5.
                | MySheet.SheetScale = 0.5


                | Parameters:


        """
        return self.layout2dsheet.SheetScale

    @property
    def views(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Views
                | o Property Views(    ) As Layout2DViews
                | 
                | Returns the Layout2D view collection of the Layout2D sheet. Example:
                | This example retrieves in ViewCollection the collection of views 2DL
                | of the MySheet Layout2D sheet.  Dim ViewCollection As Layout2DViews
                | Set ViewCollection = MySheet.Views.


                | Parameters:


        """
        return self.layout2dsheet.Views

    @property
    def visu_in_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuIn3D
                | o Property VisuIn3D(    ) As CatVisuIn3DMode
                | 
                | Set/Get the 3D visualization mode of the sheet in the 3D Viewer ie in
                | the 3D windows and in the background of each view in every 2D context.
                | See also:  activateLinkAnchor('CatVisuIn3DMode','','CatVisuIn3DMode')


                | Parameters:


        """
        return self.layout2dsheet.VisuIn3D

    def activate(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activate
                | o Sub Activate(    )
                | 
                | Activates the Layout2D sheet. Activating a Layout2D sheet means that
                | this Layout2D sheet is the one on which the end user is now working.
                | The window in the application's window collection which contains this
                | Layout2D sheet becomes the active one. Example: This example activates
                | the MySheet layout2dsheet.  MySheet.Activate


                | Parameters:


        """
        return self.layout2dsheet.Activate()

    def is_detail(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsDetail
                | o Func IsDetail(    ) As boolean
                | 
                | Checks whether the sheet is a detail sheet. TRUE if the sheet is a
                | detail sheet. Example: This example checks whether MySheet is a detail
                | sheet.  IsDetail = MySheet.IsDetail


                | Parameters:


        """
        return self.layout2dsheet.IsDetail()

    def print_out(self, i_rendering_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintOut
                | o Sub PrintOut(    CatRenderingMode    iRenderingMode)
                | 
                | Prints the Layout2D sheet according to its page setup on the default
                | printer.


                | Parameters:
                | iRenderingMode
                |    The rendering mode to use for the backgrounds of the views in the sheet.


                | Examples:
                | 
                | 
                | This example prints the Layout2DSheet1
                | on the default printer.
                | 
                | Layout2DSheet1.PrintOut catRenderShadingWithEdges
                | 
                | 
                | 
                | 
                | 
        """
        return self.layout2dsheet.PrintOut(i_rendering_mode)

    def print_out2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintOut2
                | o Sub PrintOut2(    )
                | 
                | Prints the Layout2D sheet according to its page setup on the default
                | printer. If a rendering mode has been stored on the 2D Layout, it is
                | used during print process for the backgrounds. Otherwise, "Shading
                | with edges" rendering mode is used.  Example: This example prints the
                | Layout2DSheet1  on the default printer.  Layout2DSheet1.PrintOut2


                | Parameters:


        """
        return self.layout2dsheet.PrintOut2()

    def print_to_file(self, file_name, i_rendering_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintToFile
                | o Sub PrintToFile(    CATBSTR    fileName,
                |                       CatRenderingMode    iRenderingMode)
                | 
                | Prints the Layout2D sheet according its page setup  in a file instead
                | of being sent to a printer.


                | Parameters:
                | fileName
                |    The full pathname of the file receiving the data.
                |  
                |  iRenderingMode
                |    The rendering mode to use for the backgrounds of the views in the sheet.


                | Examples:
                | 
                | 
                | This example prints the Layout2DSheet1
                | in a file.
                | 
                | Layout2DSheet1.PrintToFile "e:\temp\sheet1.prn",catRenderShadingWithEdges
                | 
                | 
                | 
        """
        return self.layout2dsheet.PrintToFile(file_name, i_rendering_mode)

    def print_to_file2(self, file_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintToFile2
                | o Sub PrintToFile2(    CATBSTR    fileName)
                | 
                | Prints the Layout2D sheet according its page setup  in a file instead
                | of being sent to a printer. If a rendering mode has been stored on the
                | 2D Layout, it is used during print process for the backgrounds.
                | Otherwise, "Shading with edges" rendering mode is used.


                | Parameters:
                | fileName
                |  The full pathname of the file receiving the data.


                | Examples:
                | 
                | 
                | This example prints the Layout2DSheet1
                | in a file.
                | 
                | Layout2DSheet1.PrintToFile2 "e:\temp\sheet1.prn"
                | 
                | 
                | 
        """
        return self.layout2dsheet.PrintToFile2(file_name)

    def reorder__views(self, i_ordered_views):
        """
        .. note::
            CAA V5 Visual Basic help

                | reorder_Views
                | o Sub reorder_Views(    CATSafeArrayVariant    iOrderedViews)
                | 
                | Changes the positions of the views in this sheet according to the
                | given  ordered list. iOrderedViews is the result of a permutation
                | applied to  the list of all the views of this sheet with the following
                | constraint: the two first elements of the list must be  respectively
                | the sheet's mainview and background view. Example:  This example
                | modifies the  views order of a sheet made of  a mainview, a
                | backgroundview and two user-created views. (user-created views are
                | inverted).  Set drw =
                | CATIA.ActiveDocument.Part.GetItem("CATLayoutRoot") Set drwviewsorder =
                | drwsheetsorder.Sheets.ActiveSheet Set drwviews = drwviewsorder.Views
                | Set mainview = drwviews.item(1) Set backview = drwviews.item(2) Set
                | view1 = drwviews.item(3) Set view2 = drwviews.item(4) newvieworder =
                | Array(mainview, backview, view2, view1)
                | drwviewsorder.reorder_Views(newvieworder)


                | Parameters:


        """
        return self.layout2dsheet.reorder_Views(i_ordered_views)

