#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatClippingFrameReframeOnMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | At creation of a view the clipping frame is reframed on.

    """

    def __init__(self, catia):
        self.catclippingframereframeonmode = catia.CatClippingFrameReframeOnMode     

