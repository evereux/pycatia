#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Layout2DFactory:
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, catia):
        self.layout2dfactory = catia.Layout2DFactory     

    def create2_d_layout(self, i_standard_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create2DLayout
                | o Func Create2DLayout(    CATBSTR    iStandardName) As Layout2DRoot
                | 
                | Create the 2DLayout associated to the 3D mechanical feature tha
                | implement this interface. E.g. a Mechanical Part.


                | Parameters:
                | CATBSTR
                |  iStandardName The standard name to apply to the new layout.
                |  
                |  oLayout
                |  The created 2DLayout. This feature is unique for a given 3D context feature. Consequently
                |  requesting this interface on a 3D feature that is already associated to a 2DLayout
                |  feature will fail. You must first request for any existing 2DLayout via 
                |  
                | 
                |  activateLinkAnchor('AnyObject','GetItem','AnyObject.GetItem')  method using CATLayoutRoot key parameter to check for 2DLayout pre-existing feature as follow :
                | 
                |  Dim MyRoot As Layout2DRoot
                |  Set MyRoot = CATIA.ActiveDocument.Part.GetItem("CATLayoutRoot")
                |  if MyRoot Is Nothing then
                |    Dim MyRootFact As Layout2DFactory
                |    Set MyRootFact = CATIA.ActiveDocument.Part.GetItem("CATLayoutRootFactory")
                |    Set MyRoot = MyRootFact.Create2DLayout("ISO_3D")
                |  end if


        """
        return self.layout2dfactory.Create2DLayout(i_standard_name)

