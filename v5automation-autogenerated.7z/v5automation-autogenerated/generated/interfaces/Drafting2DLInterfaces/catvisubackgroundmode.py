#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatVisuBackgroundMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Background  Visu Mode.

    """

    def __init__(self, catia):
        self.catvisubackgroundmode = catia.CatVisuBackgroundMode     

