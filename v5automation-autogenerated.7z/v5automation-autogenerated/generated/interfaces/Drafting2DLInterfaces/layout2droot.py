#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Layout2DRoot:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to manage the 2D Layout root.

    """

    def __init__(self, catia):
        self.layout2droot = catia.Layout2DRoot     

    @property
    def active_sheet(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActiveSheet
                | o Property ActiveSheet(    ) As Layout2DSheet
                | 
                | Retrieves or sets the active sheet of the layout. Example: This
                | example retrieves the active sheet  currently managed by the layout
                | root of a part of the active document,  supposed to be a part
                | document.  Dim MyRoot As Layout2DRoot Set MyRoot =
                | CATIA.ActiveDocument.Part.GetItem("CATLayout2DRoot)" Dim MySheet =
                | MyRoot.GetActiveSheet


                | Parameters:


        """
        return self.layout2droot.ActiveSheet

    @property
    def parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Parameters
                | o Property Parameters(    ) As Parameters
                | 
                | Returns the collection of parameters of the layout.  Example:    This
                | example retrieves in layoutParameters the collection of parameters
                | currently managed by the layout root of a part of the active document,
                | supposed to be a part document.  Dim MyRoot As Layout2DRoot Set MyRoot
                | = CATIA.ActiveDocument.Part.GetItem("CATLayout2DRoot)" Dim
                | layoutParameters As Parameters Set layoutParameters =
                | MyRoot.Parameters


                | Parameters:


        """
        return self.layout2droot.Parameters

    @property
    def relations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Relations
                | o Property Relations(    ) As Relations
                | 
                | Returns the collection of relations of the part document.  Example:
                | This example retrieves in layoutRelations the collection of relations
                | currently managed by the layout root of a part of the active document,
                | supposed to be a part document.  Dim MyRoot As Layout2DRoot Set MyRoot
                | = CATIA.ActiveDocument.Part.GetItem("CATLayout2DRoot)" Dim
                | layoutRelations As Relations Set layoutRelations = MyRoot.Relations


                | Parameters:


        """
        return self.layout2droot.Relations

    @property
    def rendering_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RenderingMode
                | o Property RenderingMode(    ) As CatRenderingMode
                | 
                | Set/Get the rendering mode of Layout2D. get_RenderingMode method can
                | fail if rendering value stored on Layout is not a value defined in
                | CatRenderingMode enum.  Example: This example sets the rendering mode
                | to catRenderShadingWithEdges for the layout root of a part of the
                | active document.  Dim MyRoot As Layout2DRoot Set MyRoot =
                | CATIA.ActiveDocument.Part.GetItem("CATLayout2DRoot)" MyRoot.
                | RenderingMode  = catRenderShadingWithEdges


                | Parameters:


        """
        return self.layout2droot.RenderingMode

    @property
    def sheets(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Sheets
                | o Property Sheets(    ) As Layout2DSheets
                | 
                | Returns the collection of Layout2D sheets of the part document.
                | Example: This example retrieves in SheetCollection the collection of
                | sheets currently managed by the layout root of a part of the active
                | document,  supposed to be a part document.  Dim MyRoot As Layout2DRoot
                | Set MyRoot = CATIA.ActiveDocument.Part.GetItem("CATLayout2DRoot)" Dim
                | SheetCollection As Layout2DSheets Set SheetCollection = MyRoot.Sheets.


                | Parameters:


        """
        return self.layout2droot.Sheets

    @property
    def standard(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Standard
                | o Property Standard(    ) As CatDrawingStandard
                | 
                | Returns or sets the DrawingStandard of the part document. Example:
                | This example sets the drawing standard  currently managed by the
                | layout root of a part of the active document,  supposed to be a part
                | document, to ISO.  Dim MyRoot As Layout2DRoot Set MyRoot =
                | CATIA.ActiveDocument.Part.GetItem("CATLayout2DRoot)" MyRoot.Standard =
                | catISO


                | Parameters:


        """
        return self.layout2droot.Standard

    @property
    def visu_in_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuIn3D
                | o Property VisuIn3D(    ) As CatVisuIn3DMode
                | 
                | Set/Get the 3D visualization mode of the layout in the 3D Viewer ie in
                | the 3D windows and in the background of each view in every 2D context.
                | See also:  activateLinkAnchor('CatVisuIn3DMode','','CatVisuIn3DMode')


                | Parameters:


        """
        return self.layout2droot.VisuIn3D

    def reorder__sheets(self, i_ordered_sheets):
        """
        .. note::
            CAA V5 Visual Basic help

                | reorder_Sheets
                | o Sub reorder_Sheets(    CATSafeArrayVariant    iOrderedSheets)
                | 
                | Changes the positions of the sheets in this drawing according to the
                | given  ordered list. iOrderedSheets is the result of a permutation
                | applied to  the list of all the sheets of this drawing, with the
                | following  constraint: For every non-detail sheet, there is not any
                | detail sheet  appearing before in iOrderedSheets. Example: This
                | example inverts the sheet order of a drawing made of exactly two
                | regular sheets.  Set drwsheetsorder =
                | CATIA.ActiveDocument.Part.GetItem("CATLayoutRoot") Set drwsheets =
                | drwsheetsorder.Sheets Set sheet1 = drwsheets.item(1) Set sheet2 =
                | drwsheets.item(2) newsheetorder = Array(sheet2, sheet1)
                | drwsheetsorder.reorder_Sheets(newsheetorder)


                | Parameters:


        """
        return self.layout2droot.reorder_Sheets(i_ordered_sheets)

