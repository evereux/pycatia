#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatDedicatedFilterType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Specifies if the dedicated filter mask or not the background.

    """

    def __init__(self, catia):
        self.catdedicatedfiltertype = catia.CatDedicatedFilterType     

