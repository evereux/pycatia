#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Layout2DSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIA2DLSettingAtt.

    """

    def __init__(self, catia):
        self.layout2dsettingatt = catia.Layout2DSettingAtt     

    @property
    def activate2_d_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activate2DMode
                | o Property Activate2DMode(    ) As boolean
                | 
                | Returns the Activate2DMode parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.Activate2DMode

    @property
    def back_clipping_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BackClippingPlane
                | o Property BackClippingPlane(    ) As boolean
                | 
                | Returns the BackClippingPlane parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.BackClippingPlane

    @property
    def boundaries2_dl_display(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Boundaries2DLDisplay
                | o Property Boundaries2DLDisplay(    ) As boolean
                | 
                | Returns the Boundaries2DLDisplay parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.Boundaries2DLDisplay

    @property
    def boundaries2_dl_line_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Boundaries2DLLineType
                | o Property Boundaries2DLLineType(    ) As long
                | 
                | Returns the Boundaries2DLLineType parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.Boundaries2DLLineType

    @property
    def boundaries2_dl_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Boundaries2DLThickness
                | o Property Boundaries2DLThickness(    ) As long
                | 
                | Returns the Boundaries2DLThickness parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.Boundaries2DLThickness

    @property
    def callout_creation_dialog_box(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CalloutCreationDialogBox
                | o Property CalloutCreationDialogBox(    ) As boolean
                | 
                | Returns the CalloutCreationDialogBox parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.CalloutCreationDialogBox

    @property
    def callout_creation_in_active_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CalloutCreationInActiveView
                | o Property CalloutCreationInActiveView(    ) As boolean
                | 
                | Returns the CalloutCreationInActiveView parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.CalloutCreationInActiveView

    @property
    def clipping_frame(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingFrame
                | o Property ClippingFrame(    ) As boolean
                | 
                | Returns the ClippingFrame parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.ClippingFrame

    @property
    def clipping_frame_reframe_on_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingFrameReframeOnMode
                | o Property ClippingFrameReframeOnMode(    ) As CatClippingFrameReframeOnMode
                | 
                | Returns the ClippingFrameReframeOnMode parameter.  Deprecated:  V5R18


                | Parameters:


        """
        return self.layout2dsettingatt.ClippingFrameReframeOnMode

    @property
    def clipping_view_outline_linetype(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingViewOutlineLinetype
                | o Property ClippingViewOutlineLinetype(    ) As long
                | 
                | Returns the ClippingViewOutlineLinetype parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.ClippingViewOutlineLinetype

    @property
    def clipping_view_outline_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingViewOutlineThickness
                | o Property ClippingViewOutlineThickness(    ) As long
                | 
                | Returns the ClippingViewOutlineThickness parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.ClippingViewOutlineThickness

    @property
    def create_associative_use_edges(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateAssociativeUseEdges
                | o Property CreateAssociativeUseEdges(    ) As boolean
                | 
                | Returns the CreateAssociativeUseEdges parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.CreateAssociativeUseEdges

    @property
    def dedicated_filter_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DedicatedFilterType
                | o Property DedicatedFilterType(    ) As CatDedicatedFilterType
                | 
                | Returns the DedicatedFilterType parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.DedicatedFilterType

    @property
    def display_back_and_cutting_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayBackAndCuttingPlane
                | o Property DisplayBackAndCuttingPlane(    ) As boolean
                | 
                | Returns the DisplayBackAndCuttingPlane parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.DisplayBackAndCuttingPlane

    @property
    def display_clipping_outline(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayClippingOutline
                | o Property DisplayClippingOutline(    ) As boolean
                | 
                | Returns the DisplayClippingOutline parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.DisplayClippingOutline

    @property
    def edit_dedicated_filter_dialog_box(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EditDedicatedFilterDialogBox
                | o Property EditDedicatedFilterDialogBox(    ) As boolean
                | 
                | Returns the EditDedicatedFilterDialogBox parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.EditDedicatedFilterDialogBox

    @property
    def fit_all_in_sheet_format(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FitAllInSheetFormat
                | o Property FitAllInSheetFormat(    ) As boolean
                | 
                | Returns the FitAllInSheetFormat parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.FitAllInSheetFormat

    @property
    def hide_in_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HideIn3D
                | o Property HideIn3D(    ) As boolean
                | 
                | Returns the HideIn3D parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.HideIn3D

    @property
    def insure_filter_names_uniqueness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InsureFilterNamesUniqueness
                | o Property InsureFilterNamesUniqueness(    ) As boolean
                | 
                | Returns the InsureFilterNamesUniqueness attribute value to apply to a
                | Layout at its creation parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.InsureFilterNamesUniqueness

    @property
    def insure_sheet_names_uniqueness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InsureSheetNamesUniqueness
                | o Property InsureSheetNamesUniqueness(    ) As boolean
                | 
                | Returns the InsureSheetNamesUniqueness attribute value to apply to a
                | Layout at its creation parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.InsureSheetNamesUniqueness

    @property
    def insure_view_names_uniqueness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InsureViewNamesUniqueness
                | o Property InsureViewNamesUniqueness(    ) As boolean
                | 
                | Returns the InsureViewNamesUniqueness attribute value to apply to a
                | Layout at its creation parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.InsureViewNamesUniqueness

    @property
    def insure_view_names_uniqueness_scope(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InsureViewNamesUniquenessScope
                | o Property InsureViewNamesUniquenessScope(    ) As CatInsureViewNamesUniquenessScope
                | 
                | Returns the InsureViewNamesUniquenessScope parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.InsureViewNamesUniquenessScope

    @property
    def layout_default_render_style(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LayoutDefaultRenderStyle
                | o Property LayoutDefaultRenderStyle(    ) As long
                | 
                | Returns the default render style attribute value to apply to a Layout
                | at its creation parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.LayoutDefaultRenderStyle

    @property
    def propagate_highlight(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PropagateHighlight
                | o Property PropagateHighlight(    ) As boolean
                | 
                | Returns the PropagateHighlight parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.PropagateHighlight

    @property
    def tile_layout_window(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TileLayoutWindow
                | o Property TileLayoutWindow(    ) As boolean
                | 
                | Returns the tile of Layout window parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.TileLayoutWindow

    @property
    def view_background_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewBackgroundMode
                | o Property ViewBackgroundMode(    ) As CatViewBackgroundMode
                | 
                | Returns the ViewBackgroundMode parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.ViewBackgroundMode

    @property
    def view_filter_creation_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewFilterCreationMode
                | o Property ViewFilterCreationMode(    ) As CatViewFilterCreationMode
                | 
                | Returns the ViewFilterCreationMode parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.ViewFilterCreationMode

    def get_activate2_d_mode_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetActivate2DModeInfo
                | o Sub GetActivate2DModeInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked,
                |                                 boolean    oModified)
                | 
                | Retrieves environment informations for the Activate2DMode parameter.
                | Role:Retrieves the state of the Activate2DMode parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetActivate2DModeInfo(io_admin_level, io_locked, o_modified)

    def get_back_clipping_plane_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBackClippingPlaneInfo
                | o Sub GetBackClippingPlaneInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked,
                |                                    boolean    oModified)
                | 
                | Retrieves environment informations for the BackClippingPlane
                | parameter. Role:Retrieves the state of the BackClippingPlane parameter
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetBackClippingPlaneInfo(io_admin_level, io_locked, o_modified)

    def get_boundaries2_dl_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLColor
                | o Sub GetBoundaries2DLColor(    long    oValueR,
                |                                 long    oValueG,
                |                                 long    oValueB)
                | 
                | Returns the Boundaries2DLColor parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.GetBoundaries2DLColor(o_value_r, o_value_g, o_value_b)

    def get_boundaries2_dl_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLColorInfo
                | o Sub GetBoundaries2DLColorInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked,
                |                                     boolean    oModified)
                | 
                | Retrieves environment informations for the Boundaries2DLColor
                | parameter. Role:Retrieves the state of the Boundaries2DLColor
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetBoundaries2DLColorInfo(io_admin_level, io_locked, o_modified)

    def get_boundaries2_dl_display_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLDisplayInfo
                | o Sub GetBoundaries2DLDisplayInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked,
                |                                       boolean    oModified)
                | 
                | Retrieves environment informations for the Boundaries2DLDisplay
                | parameter. Role:Retrieves the state of the Boundaries2DLDisplay
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetBoundaries2DLDisplayInfo(io_admin_level, io_locked, o_modified)

    def get_boundaries2_dl_line_type_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLLineTypeInfo
                | o Sub GetBoundaries2DLLineTypeInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked,
                |                                        boolean    oModified)
                | 
                | Retrieves environment informations for the Boundaries2DLLineType
                | parameter. Role:Retrieves the state of the Boundaries2DLLineType
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetBoundaries2DLLineTypeInfo(io_admin_level, io_locked, o_modified)

    def get_boundaries2_dl_thickness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLThicknessInfo
                | o Sub GetBoundaries2DLThicknessInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked,
                |                                         boolean    oModified)
                | 
                | Retrieves environment informations for the Boundaries2DLThickness
                | parameter. Role:Retrieves the state of the Boundaries2DLThickness
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetBoundaries2DLThicknessInfo(io_admin_level, io_locked, o_modified)

    def get_callout_creation_dialog_box_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCalloutCreationDialogBoxInfo
                | o Sub GetCalloutCreationDialogBoxInfo(    CATBSTR    ioAdminLevel,
                |                                           CATBSTR    ioLocked,
                |                                           boolean    oModified)
                | 
                | Retrieves environment informations for the CalloutCreationDialogBox
                | parameter. Role:Retrieves the state of the CalloutCreationDialogBox
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetCalloutCreationDialogBoxInfo(io_admin_level, io_locked, o_modified)

    def get_callout_creation_in_active_view_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCalloutCreationInActiveViewInfo
                | o Sub GetCalloutCreationInActiveViewInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked,
                |                                              boolean    oModified)
                | 
                | Retrieves environment informations for the CalloutCreationInActiveView
                | parameter. Role:Retrieves the state of the CalloutCreationInActiveView
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetCalloutCreationInActiveViewInfo(io_admin_level, io_locked, o_modified)

    def get_clipping_frame_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingFrameInfo
                | o Sub GetClippingFrameInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked,
                |                                boolean    oModified)
                | 
                | Retrieves environment informations for the ClippingFrame parameter.
                | Role:Retrieves the state of the ClippingFrame parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetClippingFrameInfo(io_admin_level, io_locked, o_modified)

    def get_clipping_frame_reframe_on_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingFrameReframeOnModeInfo
                | o Func GetClippingFrameReframeOnModeInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Deprecated:  V5R18  Retrieves environment informations for the
                | ClippingFrameReframeOnMode parameter. Role:Retrieves the state of the
                | ClippingFrameReframeOnMode parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetClippingFrameReframeOnModeInfo(io_admin_level, io_locked)

    def get_clipping_view_outline_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingViewOutlineColor
                | o Sub GetClippingViewOutlineColor(    long    oValueR,
                |                                       long    oValueG,
                |                                       long    oValueB)
                | 
                | Returns the ClippingViewOutlineColor parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.GetClippingViewOutlineColor(o_value_r, o_value_g, o_value_b)

    def get_clipping_view_outline_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingViewOutlineColorInfo
                | o Sub GetClippingViewOutlineColorInfo(    CATBSTR    ioAdminLevel,
                |                                           CATBSTR    ioLocked,
                |                                           boolean    oModified)
                | 
                | Retrieves environment informations for the ClippingViewOutlineColor
                | parameter. Role:Retrieves the state of the ClippingViewOutlineColor
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetClippingViewOutlineColorInfo(io_admin_level, io_locked, o_modified)

    def get_clipping_view_outline_linetype_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingViewOutlineLinetypeInfo
                | o Sub GetClippingViewOutlineLinetypeInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked,
                |                                              boolean    oModified)
                | 
                | Retrieves environment informations for the ClippingViewOutlineLinetype
                | parameter. Role:Retrieves the state of the ClippingViewOutlineLinetype
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetClippingViewOutlineLinetypeInfo(io_admin_level, io_locked, o_modified)

    def get_clipping_view_outline_thickness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingViewOutlineThicknessInfo
                | o Sub GetClippingViewOutlineThicknessInfo(    CATBSTR    ioAdminLevel,
                |                                               CATBSTR    ioLocked,
                |                                               boolean    oModified)
                | 
                | Retrieves environment informations for the
                | ClippingViewOutlineThickness parameter. Role:Retrieves the state of
                | the ClippingViewOutlineThickness parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetClippingViewOutlineThicknessInfo(io_admin_level, io_locked, o_modified)

    def get_create_associative_use_edges_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCreateAssociativeUseEdgesInfo
                | o Sub GetCreateAssociativeUseEdgesInfo(    CATBSTR    ioAdminLevel,
                |                                            CATBSTR    ioLocked,
                |                                            boolean    oModified)
                | 
                | Retrieves environment informations for the CreateAssociativeUseEdges
                | parameter. Role:Retrieves the state of the CreateAssociativeUseEdges
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetCreateAssociativeUseEdgesInfo(io_admin_level, io_locked, o_modified)

    def get_dedicated_filter_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDedicatedFilterTypeInfo
                | o Func GetDedicatedFilterTypeInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the DedicatedFilterType
                | parameter. Role:Retrieves the state of the DedicatedFilterType
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetDedicatedFilterTypeInfo(io_admin_level, io_locked)

    def get_display_back_and_cutting_plane_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayBackAndCuttingPlaneInfo
                | o Sub GetDisplayBackAndCuttingPlaneInfo(    CATBSTR    ioAdminLevel,
                |                                             CATBSTR    ioLocked,
                |                                             boolean    oModified)
                | 
                | Retrieves environment informations for the DisplayBackAndCuttingPlane
                | parameter. Role:Retrieves the state of the DisplayBackAndCuttingPlane
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetDisplayBackAndCuttingPlaneInfo(io_admin_level, io_locked, o_modified)

    def get_display_clipping_outline_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayClippingOutlineInfo
                | o Sub GetDisplayClippingOutlineInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked,
                |                                         boolean    oModified)
                | 
                | Retrieves environment informations for the DisplayClippingOutline
                | parameter. Role:Retrieves the state of the DisplayClippingOutline
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetDisplayClippingOutlineInfo(io_admin_level, io_locked, o_modified)

    def get_edit_dedicated_filter_dialog_box_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetEditDedicatedFilterDialogBoxInfo
                | o Sub GetEditDedicatedFilterDialogBoxInfo(    CATBSTR    ioAdminLevel,
                |                                               CATBSTR    ioLocked,
                |                                               boolean    oModified)
                | 
                | Retrieves environment informations for the
                | EditDedicatedFilterDialogBox parameter. Role:Retrieves the state of
                | the EditDedicatedFilterDialogBox parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetEditDedicatedFilterDialogBoxInfo(io_admin_level, io_locked, o_modified)

    def get_fit_all_in_sheet_format_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFitAllInSheetFormatInfo
                | o Sub GetFitAllInSheetFormatInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked,
                |                                      boolean    oModified)
                | 
                | Retrieves environment informations for the FitAllInSheetFormat
                | parameter. Role:Retrieves the state of the FitAllInSheetFormat
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetFitAllInSheetFormatInfo(io_admin_level, io_locked, o_modified)

    def get_hide_in_3d_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHideIn3DInfo
                | o Sub GetHideIn3DInfo(    CATBSTR    ioAdminLevel,
                |                           CATBSTR    ioLocked,
                |                           boolean    oModified)
                | 
                | Retrieves environment informations for the HideIn3D parameter.
                | Role:Retrieves the state of the HideIn3D parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetHideIn3DInfo(io_admin_level, io_locked, o_modified)

    def get_insure_filter_names_uniqueness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetInsureFilterNamesUniquenessInfo
                | o Sub GetInsureFilterNamesUniquenessInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked,
                |                                              boolean    oModified)
                | 
                | Retrieves environment informations for the InsureFilterNamesUniqueness
                | parameter. Role:Retrieves the state of the InsureFilterNamesUniqueness
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetInsureFilterNamesUniquenessInfo(io_admin_level, io_locked, o_modified)

    def get_insure_sheet_names_uniqueness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetInsureSheetNamesUniquenessInfo
                | o Sub GetInsureSheetNamesUniquenessInfo(    CATBSTR    ioAdminLevel,
                |                                             CATBSTR    ioLocked,
                |                                             boolean    oModified)
                | 
                | Retrieves environment informations for the InsureSheetNamesUniqueness
                | parameter. Role:Retrieves the state of the InsureSheetNamesUniqueness
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetInsureSheetNamesUniquenessInfo(io_admin_level, io_locked, o_modified)

    def get_insure_view_names_uniqueness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetInsureViewNamesUniquenessInfo
                | o Sub GetInsureViewNamesUniquenessInfo(    CATBSTR    ioAdminLevel,
                |                                            CATBSTR    ioLocked,
                |                                            boolean    oModified)
                | 
                | Retrieves environment informations for the InsureViewNamesUniqueness
                | parameter. Role:Retrieves the state of the InsureViewNamesUniqueness
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetInsureViewNamesUniquenessInfo(io_admin_level, io_locked, o_modified)

    def get_insure_view_names_uniqueness_scope_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetInsureViewNamesUniquenessScopeInfo
                | o Func GetInsureViewNamesUniquenessScopeInfo(    CATBSTR    ioAdminLevel,
                |                                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the
                | InsureViewNamesUniquenessScope parameter. Role:Retrieves the state of
                | the InsureViewNamesUniquenessScope parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetInsureViewNamesUniquenessScopeInfo(io_admin_level, io_locked)

    def get_layout_default_render_style_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLayoutDefaultRenderStyleInfo
                | o Sub GetLayoutDefaultRenderStyleInfo(    CATBSTR    ioAdminLevel,
                |                                           CATBSTR    ioLocked,
                |                                           boolean    oModified)
                | 
                | Retrieves environment informations for the default render style
                | parameter. Role:Retrieves the state of the default render style
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetLayoutDefaultRenderStyleInfo(io_admin_level, io_locked, o_modified)

    def get_propagate_highlight_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPropagateHighlightInfo
                | o Sub GetPropagateHighlightInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked,
                |                                     boolean    oModified)
                | 
                | Retrieves environment informations for the PropagateHighlight
                | parameter. Role:Retrieves the state of the PropagateHighlight
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetPropagateHighlightInfo(io_admin_level, io_locked, o_modified)

    def get_protected_elements_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProtectedElementsColor
                | o Sub GetProtectedElementsColor(    long    oValueR,
                |                                     long    oValueG,
                |                                     long    oValueB)
                | 
                | Returns the ProtectedElementsColor parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.GetProtectedElementsColor(o_value_r, o_value_g, o_value_b)

    def get_protected_elements_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProtectedElementsColorInfo
                | o Sub GetProtectedElementsColorInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked,
                |                                         boolean    oModified)
                | 
                | Retrieves environment informations for the ProtectedElementsColor
                | parameter. Role:Retrieves the state of the ProtectedElementsColor
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetProtectedElementsColorInfo(io_admin_level, io_locked, o_modified)

    def get_tile_layout_window_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTileLayoutWindowInfo
                | o Sub GetTileLayoutWindowInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked,
                |                                   boolean    oModified)
                | 
                | Retrieves environment informations for the tile of Layout window
                | parameter. Role:Retrieves the state of the tile of Layout window
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetTileLayoutWindowInfo(io_admin_level, io_locked, o_modified)

    def get_view_background_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewBackgroundModeInfo
                | o Func GetViewBackgroundModeInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ViewBackgroundMode
                | parameter. Role:Retrieves the state of the ViewBackgroundMode
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetViewBackgroundModeInfo(io_admin_level, io_locked)

    def get_view_filter_creation_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewFilterCreationModeInfo
                | o Func GetViewFilterCreationModeInfo(    CATBSTR    ioAdminLevel,
                |                                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ViewFilterCreationMode
                | parameter. Role:Retrieves the state of the ViewFilterCreationMode
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.layout2dsettingatt.GetViewFilterCreationModeInfo(io_admin_level, io_locked)

    def set_activate2_d_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetActivate2DModeLock
                | o Sub SetActivate2DModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Activate2DMode parameter. Role:Locks or unlocks
                | the Activate2DMode parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetActivate2DModeLock(i_locked)

    def set_back_clipping_plane_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBackClippingPlaneLock
                | o Sub SetBackClippingPlaneLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BackClippingPlane parameter. Role:Locks or
                | unlocks the BackClippingPlane parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetBackClippingPlaneLock(i_locked)

    def set_boundaries2_dl_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLColor
                | o Sub SetBoundaries2DLColor(    long    iValueR,
                |                                 long    iValueG,
                |                                 long    iValueB)
                | 
                | Sets the Boundaries2DLColor parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.SetBoundaries2DLColor(i_value_r, i_value_g, i_value_b)

    def set_boundaries2_dl_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLColorLock
                | o Sub SetBoundaries2DLColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Boundaries2DLColor parameter. Role:Locks or
                | unlocks the Boundaries2DLColor parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetBoundaries2DLColorLock(i_locked)

    def set_boundaries2_dl_display_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLDisplayLock
                | o Sub SetBoundaries2DLDisplayLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Boundaries2DLDisplay parameter. Role:Locks or
                | unlocks the Boundaries2DLDisplay parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetBoundaries2DLDisplayLock(i_locked)

    def set_boundaries2_dl_line_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLLineTypeLock
                | o Sub SetBoundaries2DLLineTypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Boundaries2DLLineType parameter. Role:Locks or
                | unlocks the Boundaries2DLLineType parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetBoundaries2DLLineTypeLock(i_locked)

    def set_boundaries2_dl_thickness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLThicknessLock
                | o Sub SetBoundaries2DLThicknessLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Boundaries2DLThickness parameter. Role:Locks or
                | unlocks the Boundaries2DLThickness parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetBoundaries2DLThicknessLock(i_locked)

    def set_callout_creation_dialog_box_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCalloutCreationDialogBoxLock
                | o Sub SetCalloutCreationDialogBoxLock(    boolean    iLocked)
                | 
                | Locks or unlocks the CalloutCreationDialogBox parameter. Role:Locks or
                | unlocks the CalloutCreationDialogBox parameter if it is possible in
                | the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetCalloutCreationDialogBoxLock(i_locked)

    def set_callout_creation_in_active_view_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCalloutCreationInActiveViewLock
                | o Sub SetCalloutCreationInActiveViewLock(    boolean    iLocked)
                | 
                | Locks or unlocks the CalloutCreationInActiveView parameter. Role:Locks
                | or unlocks the CalloutCreationInActiveView parameter if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetCalloutCreationInActiveViewLock(i_locked)

    def set_clipping_frame_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingFrameLock
                | o Sub SetClippingFrameLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ClippingFrame parameter. Role:Locks or unlocks
                | the ClippingFrame parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetClippingFrameLock(i_locked)

    def set_clipping_frame_reframe_on_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingFrameReframeOnModeLock
                | o Sub SetClippingFrameReframeOnModeLock(    boolean    iLocked)
                | 
                | Deprecated:  V5R18  Locks or unlocks the ClippingFrameReframeOnMode
                | parameter. Role:Locks or unlocks the ClippingFrameReframeOnMode
                | parameter if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetClippingFrameReframeOnModeLock(i_locked)

    def set_clipping_view_outline_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingViewOutlineColor
                | o Sub SetClippingViewOutlineColor(    long    iValueR,
                |                                       long    iValueG,
                |                                       long    iValueB)
                | 
                | Sets the ClippingViewOutlineColor parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.SetClippingViewOutlineColor(i_value_r, i_value_g, i_value_b)

    def set_clipping_view_outline_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingViewOutlineColorLock
                | o Sub SetClippingViewOutlineColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ClippingViewOutlineColor parameter. Role:Locks or
                | unlocks the ClippingViewOutlineColor parameter if it is possible in
                | the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetClippingViewOutlineColorLock(i_locked)

    def set_clipping_view_outline_linetype_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingViewOutlineLinetypeLock
                | o Sub SetClippingViewOutlineLinetypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ClippingViewOutlineLinetype parameter. Role:Locks
                | or unlocks the ClippingViewOutlineLinetype parameter if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetClippingViewOutlineLinetypeLock(i_locked)

    def set_clipping_view_outline_thickness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingViewOutlineThicknessLock
                | o Sub SetClippingViewOutlineThicknessLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ClippingViewOutlineThickness parameter.
                | Role:Locks or unlocks the ClippingViewOutlineThickness parameter if it
                | is possible in the current administrative context. In user mode this
                | method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetClippingViewOutlineThicknessLock(i_locked)

    def set_create_associative_use_edges_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCreateAssociativeUseEdgesLock
                | o Sub SetCreateAssociativeUseEdgesLock(    boolean    iLocked)
                | 
                | Locks or unlocks the CreateAssociativeUseEdges parameter. Role:Locks
                | or unlocks the CreateAssociativeUseEdges parameter if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetCreateAssociativeUseEdgesLock(i_locked)

    def set_dedicated_filter_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDedicatedFilterTypeLock
                | o Sub SetDedicatedFilterTypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DedicatedFilterType parameter. Role:Locks or
                | unlocks the DedicatedFilterType parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetDedicatedFilterTypeLock(i_locked)

    def set_display_back_and_cutting_plane_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayBackAndCuttingPlaneLock
                | o Sub SetDisplayBackAndCuttingPlaneLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DisplayBackAndCuttingPlane parameter. Role:Locks
                | or unlocks the DisplayBackAndCuttingPlane parameter if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetDisplayBackAndCuttingPlaneLock(i_locked)

    def set_display_clipping_outline_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayClippingOutlineLock
                | o Sub SetDisplayClippingOutlineLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DisplayClippingOutline parameter. Role:Locks or
                | unlocks the DisplayClippingOutline parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetDisplayClippingOutlineLock(i_locked)

    def set_edit_dedicated_filter_dialog_box_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetEditDedicatedFilterDialogBoxLock
                | o Sub SetEditDedicatedFilterDialogBoxLock(    boolean    iLocked)
                | 
                | Locks or unlocks the EditDedicatedFilterDialogBox parameter.
                | Role:Locks or unlocks the EditDedicatedFilterDialogBox parameter if it
                | is possible in the current administrative context. In user mode this
                | method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetEditDedicatedFilterDialogBoxLock(i_locked)

    def set_fit_all_in_sheet_format_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFitAllInSheetFormatLock
                | o Sub SetFitAllInSheetFormatLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FitAllInSheetFormat parameter. Role:Locks or
                | unlocks the FitAllInSheetFormat parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetFitAllInSheetFormatLock(i_locked)

    def set_hide_in_3d_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHideIn3DLock
                | o Sub SetHideIn3DLock(    boolean    iLocked)
                | 
                | Locks or unlocks the HideIn3D parameter. Role:Locks or unlocks the
                | HideIn3D parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetHideIn3DLock(i_locked)

    def set_insure_filter_names_uniqueness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInsureFilterNamesUniquenessLock
                | o Sub SetInsureFilterNamesUniquenessLock(    boolean    iLocked)
                | 
                | Locks or unlocks the InsureFilterNamesUniqueness parameter. Role:Locks
                | or unlocks the InsureFilterNamesUniqueness if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetInsureFilterNamesUniquenessLock(i_locked)

    def set_insure_sheet_names_uniqueness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInsureSheetNamesUniquenessLock
                | o Sub SetInsureSheetNamesUniquenessLock(    boolean    iLocked)
                | 
                | Locks or unlocks the InsureSheetNamesUniqueness parameter. Role:Locks
                | or unlocks the InsureSheetNamesUniqueness parameter if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetInsureSheetNamesUniquenessLock(i_locked)

    def set_insure_view_names_uniqueness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInsureViewNamesUniquenessLock
                | o Sub SetInsureViewNamesUniquenessLock(    boolean    iLocked)
                | 
                | Locks or unlocks InsureViewNamesUniqueness parameter. Role:Locks or
                | unlocks the InsureViewNamesUniqueness parameter if it is possible in
                | the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetInsureViewNamesUniquenessLock(i_locked)

    def set_insure_view_names_uniqueness_scope_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInsureViewNamesUniquenessScopeLock
                | o Sub SetInsureViewNamesUniquenessScopeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the InsureViewNamesUniquenessScope parameter.
                | Role:Locks or unlocks the InsureViewNamesUniquenessScope parameter if
                | it is possible in the current administrative context. In user mode
                | this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetInsureViewNamesUniquenessScopeLock(i_locked)

    def set_layout_default_render_style_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLayoutDefaultRenderStyleLock
                | o Sub SetLayoutDefaultRenderStyleLock(    boolean    iLocked)
                | 
                | Locks or unlocks the default render style parameter. Role:Locks or
                | unlocks the default render style parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetLayoutDefaultRenderStyleLock(i_locked)

    def set_propagate_highlight_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPropagateHighlightLock
                | o Sub SetPropagateHighlightLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PropagateHighlight parameter. Role:Locks or
                | unlocks the PropagateHighlight parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetPropagateHighlightLock(i_locked)

    def set_protected_elements_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProtectedElementsColor
                | o Sub SetProtectedElementsColor(    long    iValueR,
                |                                     long    iValueG,
                |                                     long    iValueB)
                | 
                | Sets the ProtectedElementsColor parameter.


                | Parameters:


        """
        return self.layout2dsettingatt.SetProtectedElementsColor(i_value_r, i_value_g, i_value_b)

    def set_protected_elements_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProtectedElementsColorLock
                | o Sub SetProtectedElementsColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ProtectedElementsColor parameter. Role:Locks or
                | unlocks the ProtectedElementsColor parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetProtectedElementsColorLock(i_locked)

    def set_tile_layout_window_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTileLayoutWindowLock
                | o Sub SetTileLayoutWindowLock(    boolean    iLocked)
                | 
                | Locks or unlocks the tile of Layout window parameter. Role:Locks or
                | unlocks the tile of Layout window parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetTileLayoutWindowLock(i_locked)

    def set_view_background_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewBackgroundModeLock
                | o Sub SetViewBackgroundModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ViewBackgroundMode parameter. Role:Locks or
                | unlocks the ViewBackgroundMode parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetViewBackgroundModeLock(i_locked)

    def set_view_filter_creation_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewFilterCreationModeLock
                | o Sub SetViewFilterCreationModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ViewFilterCreationMode parameter. Role:Locks or
                | unlocks the ViewFilterCreationMode parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.layout2dsettingatt.SetViewFilterCreationModeLock(i_locked)

