#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatViewType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Type of a view.

    """

    def __init__(self, catia):
        self.catviewtype = catia.CatViewType     

