#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatViewSide:
    """
        .. note::
            CAA V5 Visual Basic help

                | CatViewSide is used in conjonction with a reference View2DL and a
                | ViewBox.It then determines precisely a View2DL type in the ViewBox.
                | example: with the default ViewBox:  - Front + TopSide  = Top.  - Right
                | + LeftSide = Front.  - Front + TRCorner = isometric on the corner near
                | Front, Right, Top.

    """

    def __init__(self, catia):
        self.catviewside = catia.CatViewSide     

