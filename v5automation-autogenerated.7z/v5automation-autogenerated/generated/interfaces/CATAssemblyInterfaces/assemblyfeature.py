#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AssemblyFeature:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the AssemblyFeature object.

    """

    def __init__(self, catia):
        self.assemblyfeature = catia.AssemblyFeature     

    def add_affected_component(self, i_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddAffectedComponent
                | o Sub AddAffectedComponent(    Product    iComponent)
                | 
                | Adds a component to the affected component list. An update of the
                | aggregating Product is necessary  to apply the Assembly Feature to
                | this component.


                | Parameters:
                | iComponent
                |    The component to affect


                | Examples:
                | 
                | The following example adds the component ProdToAffect to
                | the affected component list of the AssemblyFeature assemblyFeat.
                | 
                | assemblyFeat.AddAffectedComponent( ProdToAffect )
                | 
                | 
                | 
        """
        return self.assemblyfeature.AddAffectedComponent(i_component)

    def affected_components_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AffectedComponentsCount
                | o Func AffectedComponentsCount(    ) As long
                | 
                | Returns the affected component list count.  Example:The following
                | example retrieves the affected component list count of  the
                | AssemblyFeature assemblyFeat in affectedListSize.  affectedListSize =
                | assemblyFeat.AffectedComponentsCount


                | Parameters:


        """
        return self.assemblyfeature.AffectedComponentsCount()

    def list_affected_components(self, o_list_of_components):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListAffectedComponents
                | o Sub ListAffectedComponents(    CATSafeArrayVariant    oListOfComponents)
                | 
                | Retrieves the affected component list.


                | Parameters:
                | oListOfComponents
                |    The retrieved list.
                |    
                |    The array must be previously initialized
                |    using the 
                | 
                |  activateLinkAnchor('','AffectedComponentsCount','AffectedComponentsCount')  method.


                | Examples:
                | 
                | The following example retrieves the affected component list of
                | the AssemblyFeature assemblyFeat in affectedList.
                | 
                | affectedListSize = assemblyFeat.AffectedComponentsCount
                | Dim affectedList(affectedListSize-1)
                | assemblyFeat.ListAffectedComponents(affectedList)
                | 
                | 
        """
        return self.assemblyfeature.ListAffectedComponents(o_list_of_components)

    def remove_affected_component(self, i_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAffectedComponent
                | o Sub RemoveAffectedComponent(    Product    iComponent)
                | 
                | Removes a component from the affected component list. An update of the
                | aggregating Product is necessary to remove the generated feature from
                | this component.


                | Parameters:
                | iComponent
                |    The affected component to remove


                | Examples:
                | 
                | The following example removes the component ProdToRemove from
                | the affected component list of the AssemblyFeature assemblyFeat.
                | 
                | assemblyFeat.RemoveAffectedComponent( ProdToRemove )
                | 
                | 
                | 
        """
        return self.assemblyfeature.RemoveAffectedComponent(i_component)

