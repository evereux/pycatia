#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AssemblyBoolean:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the AssemblyBoolean object.

    """

    def __init__(self, catia):
        self.assemblyboolean = catia.AssemblyBoolean     

    @property
    def body(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Body
                | o Property Body(    ) As Body
                | 
                | Returns the operating body.  Example:The following example retrieves
                | in opBody the operating body of the assembly boolean assemblyBool.
                | Dim opBody As Body Set opBody = assemblyBool.Body


                | Parameters:


        """
        return self.assemblyboolean.Body

    @property
    def body_component(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BodyComponent
                | o Property BodyComponent(    ) As Product
                | 
                | Returns the component containing the operating body.  Example:The
                | following example retrieves in opBodyComp the component that contains
                | the operating body of the assembly boolean assemblyBool.  Dim
                | opBodyComp As Product Set opBodyComp = assemblyBool.BodyComponent


                | Parameters:


        """
        return self.assemblyboolean.BodyComponent

