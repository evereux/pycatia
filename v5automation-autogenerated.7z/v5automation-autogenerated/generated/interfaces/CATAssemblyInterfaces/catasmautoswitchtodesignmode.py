#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatAsmAutoSwitchToDesignMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Option managing the implicit switch from visualization mode to design
                | mode.

    """

    def __init__(self, catia):
        self.catasmautoswitchtodesignmode = catia.CatAsmAutoSwitchToDesignMode     

