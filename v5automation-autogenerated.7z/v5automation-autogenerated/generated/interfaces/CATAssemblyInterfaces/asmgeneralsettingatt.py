#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AsmGeneralSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Assembly General setting controller object.Role: the
                | Assembly General setting controller object  deals with the setting
                | parameters displayed in the Assembly General property page. To access
                | this property page:

    """

    def __init__(self, catia):
        self.asmgeneralsettingatt = catia.AsmGeneralSettingAtt     

    @property
    def auto_switch_to_design_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoSwitchToDesignMode
                | o Property AutoSwitchToDesignMode(    ) As CatAsmAutoSwitchToDesignMode
                | 
                | Returns or sets the implicit switch from visualization mode to design
                | mode setting parameter . Role: The implicit switch from visualization
                | mode to design mode setting parameter manages the loading of necessayr
                | data whenever they are needed. Note that this option is useful only
                | when the Cache option is activated       Legal values:
                | catAutoSwitchUnavailable Automatic switch to design mode
                | unavailablecatAutoSwitchAvailable Automatic switch to design mode
                | availableExample: The following example retrieves the implicit switch
                | setting parameter of AsmGeneralSettingAtt1 in SwitchMode and enables
                | the switch  Set SwitchMode =
                | AsmGeneralSettingAtt1.AutoSwitchToDesignMode
                | AsmGeneralSettingAtt1.AutoSwitchToDesignMode = catAutoSwitchAvailable


                | Parameters:


        """
        return self.asmgeneralsettingatt.AutoSwitchToDesignMode

    @property
    def auto_update_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoUpdateMode
                | o Property AutoUpdateMode(    ) As CatAsmUpdateMode
                | 
                | Returns or sets the automatic update setting parameter. Role: The
                | automatic update setting parameter manages the automatic launching of
                | the Update command.     Legal values: catManualUpdate Manual update
                | modecatAutomaticUpdate Automatic update modeExample: The following
                | example retrieves the automatic update setting parameter of
                | AsmGeneralSettingAtt1 in UpdateMode and sets the mode to manual
                | update.  Set UpdateMode = AsmGeneralSettingAtt1.AutoUpdateMode
                | AsmGeneralSettingAtt1.AutoUpdateMode = catManualUpdate


                | Parameters:


        """
        return self.asmgeneralsettingatt.AutoUpdateMode

    @property
    def move_with_fix_t_extend_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MoveWithFixTExtendMode
                | o Property MoveWithFixTExtendMode(    ) As CatAsmExtendMoveToFixT
                | 
                | Returns or sets the setting parameter managing the extension of a move
                | to the components involved in a FixTogether. Role: This setting
                | parameter manages whether the components involved in a FixTogether
                | will be moved or not.        Legal values: catNeverExtendMoveToFixT
                | Never extend move to all component involved in a
                | FixTogethercatAskIfExtendMoveToFixT Ask question to extend move to all
                | component involved in a FixTogethercatAlwaysExtendMoveToFixT Always
                | extend move to all component involved in a FixTogetherExample: The
                | following example retrieves the move setting parameter of
                | AsmGeneralSettingAtt1 in MoveMode and sets it to Always  Set MoveMode
                | = AsmGeneralSettingAtt1.MoveWithFixTExtendMode
                | AsmGeneralSettingAtt1.MoveWithFixTExtendMode =
                | catAlwaysExtendMoveToFixT


                | Parameters:


        """
        return self.asmgeneralsettingatt.MoveWithFixTExtendMode

    @property
    def update_status_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpdateStatusMode
                | o Property UpdateStatusMode(    ) As CatAsmUpdateStatusComputeMode
                | 
                | Returns or sets the update status computation setting parameter. Role:
                | The update status computation setting parameter manages the loading at
                | open of the data necessary to the exact update status computation.
                | Note that this option is useful only when the Cache option is
                | activated        Legal values: catManualCompute At open the update
                | status is unknowncatAutomaticCompute Additional data are being loaded
                | at open      to compute an exact Update statusExample: The following
                | example retrieves the update status computation setting parameter of
                | AsmGeneralSettingAtt1 in StatusMode and sets the mode to automatic
                | computation.  Set StatusMode = AsmGeneralSettingAtt1.UpdateStatusMode
                | AsmGeneralSettingAtt1.UpdateStatusMode = catAutomaticCompute


                | Parameters:


        """
        return self.asmgeneralsettingatt.UpdateStatusMode

    def get_auto_switch_to_design_mode_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoSwitchToDesignModeInfo
                | o Func GetAutoSwitchToDesignModeInfo(    CATBSTR    AdminLevel,
                |                                          CATBSTR    oLocked) As boolean
                | 
                | Retrieves the state of the implicit switch from visualization mode to
                | design mode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmgeneralsettingatt.GetAutoSwitchToDesignModeInfo(admin_level, o_locked)

    def get_auto_update_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoUpdateModeInfo
                | o Func GetAutoUpdateModeInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves informations about the automatic update setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmgeneralsettingatt.GetAutoUpdateModeInfo(io_admin_level, io_locked)

    def get_move_with_fix_t_extend_mode_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMoveWithFixTExtendModeInfo
                | o Func GetMoveWithFixTExtendModeInfo(    CATBSTR    AdminLevel,
                |                                          CATBSTR    oLocked) As boolean
                | 
                | Retrieves the state of the setting parameter managing the extension of
                | a move  to the components involved in a FixTogether. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmgeneralsettingatt.GetMoveWithFixTExtendModeInfo(admin_level, o_locked)

    def get_update_status_mode_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUpdateStatusModeInfo
                | o Func GetUpdateStatusModeInfo(    CATBSTR    AdminLevel,
                |                                    CATBSTR    oLocked) As boolean
                | 
                | Retrieves informations about the update status computation setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmgeneralsettingatt.GetUpdateStatusModeInfo(admin_level, o_locked)

    def set_auto_switch_to_design_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoSwitchToDesignModeLock
                | o Sub SetAutoSwitchToDesignModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the implicit switch from visualization mode to design
                | mode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmgeneralsettingatt.SetAutoSwitchToDesignModeLock(i_locked)

    def set_auto_update_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoUpdateModeLock
                | o Sub SetAutoUpdateModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the automatic update setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmgeneralsettingatt.SetAutoUpdateModeLock(i_locked)

    def set_move_with_fix_t_extend_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMoveWithFixTExtendModeLock
                | o Sub SetMoveWithFixTExtendModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the setting parameter managing the extension of a
                | move  to the components involved in a FixTogether. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmgeneralsettingatt.SetMoveWithFixTExtendModeLock(i_locked)

    def set_update_status_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUpdateStatusModeLock
                | o Sub SetUpdateStatusModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the update status computation setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmgeneralsettingatt.SetUpdateStatusModeLock(i_locked)

