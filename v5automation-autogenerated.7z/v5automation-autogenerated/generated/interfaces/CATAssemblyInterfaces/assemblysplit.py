#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AssemblySplit:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the AssemblySplit object.

    """

    def __init__(self, catia):
        self.assemblysplit = catia.AssemblySplit     

    @property
    def splitting_component(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SplittingComponent
                | o Property SplittingComponent(    ) As Product
                | 
                | Returns the component containing the splitting element.  Example:The
                | following example retrieves in sptComponent the splitting component
                | containing the splitting element of the assembly split assemblySplit:
                | Dim sptComponent As Product Set sptComponent =
                | assemblySplit.SplittingComponent


                | Parameters:


        """
        return self.assemblysplit.SplittingComponent

    @property
    def splitting_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SplittingElement
                | o Property SplittingElement(    ) As Reference
                | 
                | Returns the splitting element.  Example:The following example
                | retrieves in sptElement the splitting element of the assembly split
                | assemblySplit:  Dim sptElement As Reference Set sptElement =
                | assemblySplit.SplittingElement


                | Parameters:


        """
        return self.assemblysplit.SplittingElement

    @property
    def splitting_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SplittingSide
                | o Property SplittingSide(    ) As CatSplitSide
                | 
                | Returns or sets the splitting side. The splitting side is the side of
                | the split object kept after the split, with respect to the splitting
                | element. A positive side refers to the split object side shown by the
                | splitting element normal vector.  Example:The following example
                | returns in sptSide the splitting side of the assembly split
                | assemblySplit, and then sets it to catPositiveSide:  Set sptSide =
                | assemblySplit.SplittingSide assemblySplit.SplittingSide =
                | catPositiveSide


                | Parameters:


        """
        return self.assemblysplit.SplittingSide

    def modify_splitting_element(self, i_splitting_element, i_splitting_elem_comp):
        """
        .. note::
            CAA V5 Visual Basic help

                | ModifySplittingElement
                | o Sub ModifySplittingElement(    Reference    iSplittingElement,
                |                                  Product    iSplittingElemComp)
                | 
                | Replaces the splitting element by a new one.


                | Parameters:
                | iSplittingElement
                |    The new face or plane that will split the current body
                |  
                |  iSplittingElemComp
                |    The component that contains the new splitting element


                | Examples:
                | 
                | The following example replaces the existing splitting element of the
                | assembly split assemblySplit by sptElem contained in
                | the sptComponent splitting component
                | 
                | assemblySplit.ModifySplittingElement(sptElem, _
                | sptComponent)
                | 
                | 
                | 
        """
        return self.assemblysplit.ModifySplittingElement(i_splitting_element, i_splitting_elem_comp)

