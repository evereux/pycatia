#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatAsmExtendMoveToFixT:
    """
        .. note::
            CAA V5 Visual Basic help

                | Option managing the extension of a move  to the components involved in
                | a FixTogether.

    """

    def __init__(self, catia):
        self.catasmextendmovetofixt = catia.CatAsmExtendMoveToFixT     

