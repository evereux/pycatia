#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AssemblyHole:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the AssemblyHole object.

    """

    def __init__(self, catia):
        self.assemblyhole = catia.AssemblyHole     

    @property
    def anchor_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnchorMode
                | o Property AnchorMode(    ) As CatHoleAnchorMode
                | 
                | Returns or sets the hole anchor mode.  This property is valid when the
                | hole type is Counterbored or Counterdrilled. Example:The following
                | example saves in holeAnchorMode the anchor mode of the hole
                | assemblyHole and sets it so that the anchor mode will now be set to
                | the middle of its head.  Dim holeAnchorMode Set holeAnchorMode =
                | assemblyHole.AnchorMode assemblyHole.AnchorMode =
                | catMiddlePointHoleAnchor


                | Parameters:


        """
        return self.assemblyhole.AnchorMode

    @property
    def bottom_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BottomAngle
                | o Property BottomAngle(    ) As Angle
                | 
                | Returns the hole bottom angle.  This property is valid when the hole
                | bottom type is VBottom. The hole bottom angle is returned as a
                | activateLinkAnchor('Angle','','Angle')  object. Example:The following
                | example retrieves in holeBottomAngle the bottom angle of the hole
                | assemblyHole.  Dim holeBottomAngle As Angle Set holeBottomAngle =
                | assemblyHole.BottomAngle


                | Parameters:


        """
        return self.assemblyhole.BottomAngle

    @property
    def bottom_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BottomLimit
                | o Property BottomLimit(    ) As Limit
                | 
                | Returns the hole bottom limit.  This limit manages the way the hole is
                | ended. It is returned as a  activateLinkAnchor('Limit','','Limit')
                | object. Example:The following example retrieves in limit the bottom
                | limit of the hole assemblyHole.  Dim limit As Limit Set limit =
                | assemblyHole.BottomLimit


                | Parameters:


        """
        return self.assemblyhole.BottomLimit

    @property
    def bottom_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BottomType
                | o Property BottomType(    ) As CatHoleBottomType
                | 
                | Returns or sets the hole bottom type. Example:The following example
                | saves in holeBottomType the bottom type of the hole assemblyHole and
                | sets it so that the bottom will now be a V-like one.  Dim
                | holeBottomType Set holeBottomType = assemblyHole.BottomType
                | assemblyHole.BottomType = catVHoleBottom


                | Parameters:


        """
        return self.assemblyhole.BottomType

    @property
    def diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Diameter
                | o Property Diameter(    ) As Length
                | 
                | Returns the hole diameter.  It is returned as a
                | activateLinkAnchor('Length','','Length')  object. Example:The
                | following example retrieves in holeDiam the diameter of the hole
                | assemblyHole.  Dim holeDiam As Length Set holeDiam =
                | assemblyHole.Diameter


                | Parameters:


        """
        return self.assemblyhole.Diameter

    @property
    def head_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HeadAngle
                | o Property HeadAngle(    ) As Angle
                | 
                | Returns the hole head angle.  This property is valid when the hole
                | type is Tapered, Counterdrilled or Countersunk. The hole head angle is
                | returned as a  activateLinkAnchor('Angle','','Angle')  object.
                | Example:The following example retrieves in holeHeadAngle the head
                | angle of the hole assemblyHole.  Dim holeHeadAngle As Angle Set
                | holeHeadAngle = assemblyHole.HeadAngle


                | Parameters:


        """
        return self.assemblyhole.HeadAngle

    @property
    def head_depth(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HeadDepth
                | o Property HeadDepth(    ) As Length
                | 
                | Returns the hole head depth.  This property is valid when the hole
                | type is Counterbored, Counterdrilled or Countersunk. The hole head
                | depth is returned as a  activateLinkAnchor('Length','','Length')
                | object. Example:The following example retrieves in holeHeadDepth the
                | head depth of the hole assemblyHole.  Dim holeHeadDepth As Length Set
                | holeHeadDepth = assemblyHole.HeadDepth


                | Parameters:


        """
        return self.assemblyhole.HeadDepth

    @property
    def head_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HeadDiameter
                | o Property HeadDiameter(    ) As Length
                | 
                | Returns the hole head diameter.  This property is valid when the hole
                | type is Counterbored or Counterdrilled. The hole head diameter is
                | returned as a  activateLinkAnchor('Length','','Length')  object.
                | Example:The following example retrieves in holeHeadDiam the head
                | diameter of the hole assemblyHole.  Dim holeHeadDiam As Length Set
                | holeHeadDiam = assemblyHole.HeadDiameter


                | Parameters:


        """
        return self.assemblyhole.HeadDiameter

    @property
    def sketch(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Sketch
                | o Property Sketch(    ) As Sketch
                | 
                | Returns the hole positioning sketch. Example:The following example
                | retrieves in sketch the positioning sketch of the hole assemblyHole.
                | Dim sketch As Sketch Set sketch = assemblyHole.Sketch o Property
                | SketchComponent() As  activateLink('Product','Product')  (Read Only)
                | Returns the component containing the hole positioning sketch.
                | Example:The following example retrieves in skComp the component  that
                | contains the positioning sketch of the hole assemblyHole.  Dim skComp
                | As Product Set skComp = assemblyHole.SketchComponent o Property Type()
                | As  activateLink('CatHoleType','CatHoleType')  Returns or sets the
                | hole type. Example:The following example saves in holeType the type of
                | the hole assemblyHole, and then sets it so that it will now be  a
                | tapered hole.  Set holeType = assemblyHole.Type assemblyHole.Type =
                | catTaperedHole  Methods o Sub GetDirection(
                | activateLink('CATSafeArrayVariant','CATSafeArrayVariant') ioDirection)
                | Retrieves the hole direction vector components.  These components are
                | expressed in millimeter according to the absolute coordinate system.


                | Parameters:
                | ioDirection
                |    The direction vector components, as a  safe array made up of three doubles: X, Y, Z
                |  
                |    The array must be previously initialized.


                | Examples:
                | 
                | The following example returns in dirArray the direction vector
                | components of the hole assemblyHole.
                | 
                | Dim dirArray(2)
                | Call assemblyHole.GetDirection(dirArray)
                | Set x = dirArray[0]
                | Set y = dirArray[1]
                | Set z = dirArray[2]
                | 
                | 
                | 
                | 
        """
        return self.assemblyhole.Sketch

    @property
    def sketch_component(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SketchComponent
                | o Property SketchComponent(    ) As Product
                | 
                | Returns the component containing the hole positioning sketch.
                | Example:The following example retrieves in skComp the component  that
                | contains the positioning sketch of the hole assemblyHole.  Dim skComp
                | As Product Set skComp = assemblyHole.SketchComponent


                | Parameters:


        """
        return self.assemblyhole.SketchComponent

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CatHoleType
                | 
                | Returns or sets the hole type. Example:The following example saves in
                | holeType the type of the hole assemblyHole, and then sets it so that
                | it will now be  a tapered hole.  Set holeType = assemblyHole.Type
                | assemblyHole.Type = catTaperedHole


                | Parameters:


        """
        return self.assemblyhole.Type

    def get_direction(self, io_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDirection
                | o Sub GetDirection(    CATSafeArrayVariant    ioDirection)
                | 
                | Retrieves the hole direction vector components.  These components are
                | expressed in millimeter according to the absolute coordinate system.


                | Parameters:
                | ioDirection
                |    The direction vector components, as a  safe array made up of three doubles: X, Y, Z
                |  
                |    The array must be previously initialized.


                | Examples:
                | 
                | The following example returns in dirArray the direction vector
                | components of the hole assemblyHole.
                | 
                | Dim dirArray(2)
                | Call assemblyHole.GetDirection(dirArray)
                | Set x = dirArray[0]
                | Set y = dirArray[1]
                | Set z = dirArray[2]
                | 
                | 
                | 
        """
        return self.assemblyhole.GetDirection(io_direction)

    def get_origin(self, io_origin):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrigin
                | o Sub GetOrigin(    CATSafeArrayVariant    ioOrigin)
                | 
                | Retrieves the origin point to which the hole is anchored.  This point
                | belongs to a plane tangent to the hole. The coordinates are expressed
                | in millimeter according to the absolute coordinate system.


                | Parameters:
                | ioOrigin
                |    The hole origin point coordinates, as a  safe array made up of three doubles: X, Y, Z
                |  
                |    The array must be previously initialized.


                | Examples:
                | 
                | The following example returns in coordArray the coordinates of
                | the hole assemblyHole.
                | 
                | Dim coordArray(2)
                | Call assemblyHole.GetOrigin coordArray
                | Set x = coordArray[0]
                | Set y = coordArray[1]
                | Set z = coordArray[2]
                | 
                | 
                | 
        """
        return self.assemblyhole.GetOrigin(io_origin)

    def set_direction(self, i_line, i_line_comp):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDirection
                | o Sub SetDirection(    Reference    iLine,
                |                        Product    iLineComp)
                | 
                | Sets the hole axis direction.


                | Parameters:
                | iLine
                |    The hole axis direction, as a reference to a line or an edge.
                |  
                |  iLineComp
                |    The component containing the axis direction


                | Examples:
                | 
                | The following example sets the axis direction of
                | the hole assemblyHole with the dirRef line
                | of the component dirComp.
                | 
                | assemblyHole.SetDirection dirRef, dirComp
                | 
                | 
                | 
        """
        return self.assemblyhole.SetDirection(i_line, i_line_comp)

