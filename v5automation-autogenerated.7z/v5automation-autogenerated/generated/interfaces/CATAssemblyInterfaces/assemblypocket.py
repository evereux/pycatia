#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AssemblyPocket:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the AssemblyPocket object.

    """

    def __init__(self, catia):
        self.assemblypocket = catia.AssemblyPocket     

    @property
    def direction_orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DirectionOrientation
                | o Property DirectionOrientation(    ) As CatPrismOrientation
                | 
                | Returns or sets the pocket direction orientation. Example:The
                | following example saves in dirOrientation the direction orientation of
                | the pocket assemblyPocket, and then sets it so that the direction will
                | be now inversed.  Dim dirOrientation Set dirOrientation =
                | assemblyPocket.DirectionOrientation
                | assemblyPocket.DirectionOrientation = catInverseOrientation


                | Parameters:


        """
        return self.assemblypocket.DirectionOrientation

    @property
    def direction_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DirectionType
                | o Property DirectionType(    ) As CatPrismExtrusionDirection
                | 
                | Returns or sets the pocket direction type. Example:The following
                | example saves in dirType the direction type of the pocket
                | assemblyPocket, and then sets it so that the direction will be now
                | normal to the sketch.  Dim dirType Set dirType =
                | assemblyPocket.DirectionType assemblyPocket.DirectionType =
                | catNormalToSketchDirection


                | Parameters:


        """
        return self.assemblypocket.DirectionType

    @property
    def first_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstLimit
                | o Property FirstLimit(    ) As Limit
                | 
                | Returns the first pocket limit.  A pocket has two limits that manage
                | the way the pocket is ended. Example:The following example returns in
                | firstLimit the first limit of the pocket assemblyPocket.  Dim
                | firstLimit As Limit Set firstLimit = assemblyPocket.FirstLimit


                | Parameters:


        """
        return self.assemblypocket.FirstLimit

    @property
    def is_symmetric(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsSymmetric
                | o Property IsSymmetric(    ) As boolean
                | 
                | Returns or sets the pocket symmetry flag. TRUE if the pocket is
                | symmetric with respect to the base sketch, and FALSE otherwise.
                | Example:The following example saves in symFlag the symmetry flag of
                | the pocket assemblyPocket, and then sets it so that it will be now
                | symmetric with respect to the base sketch.  Dim symFlag As boolean Set
                | symFlag = assemblyPocket.IsSymmetric assemblyPocket.IsSymmetric = TRUE


                | Parameters:


        """
        return self.assemblypocket.IsSymmetric

    @property
    def second_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondLimit
                | o Property SecondLimit(    ) As Limit
                | 
                | Returns the second pocket limit.  A pocket has two limits that manage
                | the way the pocket is ended. Example:The following example returns in
                | secondLimit the second limit of the pocket assemblyPocket.  Dim
                | secondLimit As Limit Set secondLimit = assemblyPocket.SecondLimit


                | Parameters:


        """
        return self.assemblypocket.SecondLimit

    @property
    def sketch(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Sketch
                | o Property Sketch(    ) As Sketch
                | 
                | Returns the pocket sketch. Example:The following example retrieves in
                | sketch the sketch on which the pocket assemblyPocket is built.  Dim
                | sketch As Sketch Set sketch = assemblyPocket.Sketch


                | Parameters:


        """
        return self.assemblypocket.Sketch

    @property
    def sketch_component(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SketchComponent
                | o Property SketchComponent(    ) As Product
                | 
                | Returns the component containing the pocket sketch. Example:The
                | following example retrieves in skComp the component  that contains the
                | sketch of the pocket assemblyPocket is built.  Dim skComp As Product
                | Set skComp = assemblyPocket.SketchComponent


                | Parameters:


        """
        return self.assemblypocket.SketchComponent

    def get_direction(self, io_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDirection
                | o Sub GetDirection(    CATSafeArrayVariant    ioDirection)
                | 
                | Retrieves the pocket direction vector components.  These components
                | are expressed in millimeter according to the absolute coordinate
                | system.


                | Parameters:
                | ioDirection
                |    The pocket direction vector components, as a  safe array made up of three doubles: X, Y, Z
                |  
                |    The array must be previously initialized.


                | Examples:
                | 
                | The following example retrieves in dirArray the direction vector
                | components of the pocket assemblyPocket.
                | 
                | Dim dirArray(2)
                | Call assemblyPocket.GetDirection(dirArray)
                | Set x = dirArray[0]
                | Set y = dirArray[1]
                | Set z = dirArray[2]
                | 
                | 
                | 
        """
        return self.assemblypocket.GetDirection(io_direction)

    def reverse_inner_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReverseInnerSide
                | o Sub ReverseInnerSide(    )
                | 
                | Reverses the pocket inner side when the profile is open.  This is
                | useful for finding the shape to reach.  Example:The following example
                | reverses the current inner side of the pocket assemblyPocket.
                | assemblyPocket.ReverseInnerSide


                | Parameters:


        """
        return self.assemblypocket.ReverseInnerSide()

    def set_direction(self, i_line, i_line_comp):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDirection
                | o Sub SetDirection(    Reference    iLine,
                |                        Product    iLineComp)
                | 
                | Sets the pocket associated direction.


                | Parameters:
                | iLine
                |   The pocket associated direction, as a reference to a line or an edge.
                |  
                |  iLineComp
                |   The component containing the associated direction reference


                | Examples:
                | 
                | The following example sets the associated direction of
                | the pocket assemblyPocket using the dirRef line
                | of the component dirComp.
                | 
                | assemblyPocket.SetDirection dirRef, dirComp
                | 
                | 
                | 
                | 
                | 
        """
        return self.assemblypocket.SetDirection(i_line, i_line_comp)

