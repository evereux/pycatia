#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatAsmQuickConstraintMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Quick constraint mode.

    """

    def __init__(self, catia):
        self.catasmquickconstraintmode = catia.CatAsmQuickConstraintMode     

