#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AsmConstraintSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Assembly Constraints setting controller object.Role:
                | the Assembly Constraints setting controller object  deals with the
                | setting parameters displayed in the Assembly Constraints property
                | page. To access this property page:

    """

    def __init__(self, catia):
        self.asmconstraintsettingatt = catia.AsmConstraintSettingAtt     

    @property
    def constraint_creation_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConstraintCreationMode
                | o Property ConstraintCreationMode(    ) As CatAsmConstraintCreationMode
                | 
                | Returns or sets the constraint creation setting parameter. Role: The
                | constraint creation setting parameter manages the determination of the
                | kind of elements to constraint.     Legal values: catUseAnyGeometry
                | The constraint can be created on any kind of
                | geometrycatUsePublishedGeometryChildLevel The constraint can only be
                | created on geometry published on the direct child
                | levelcatUsePublishedGeometryAnyLevel The constraint can only be
                | created on geometry published on any assembly levelExample: The
                | following example retrieves the constraint creation setting parameter
                | of AsmConstraintSettingAtt1 in CreationMode and sets the mode to
                | catUsePublishedGeometryAnyLevel.  Set CreationMode =
                | AsmConstraintSettingAtt1.ConstraintCreationMode
                | AsmConstraintSettingAtt1.ConstraintCreationMode =
                | catUsePublishedGeometryAnyLevel


                | Parameters:


        """
        return self.asmconstraintsettingatt.ConstraintCreationMode

    @property
    def paste_component_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PasteComponentMode
                | o Property PasteComponentMode(    ) As CatAsmPasteComponentMode
                | 
                | Returns or sets the component paste setting parameter. Role: The
                | component paste setting parameter manages the keeping of the
                | contraints of a component after a Copy/Paste or a Cut/Paste.
                | Legal values: catPasteWithoutCsts The component's constraints will not
                | be recreatedcatPasteWithCstOnCopy The component's constraints will
                | only be recreated after a CopycatPasteWithCstOnCut The component's
                | constraints will only be recreated after a
                | CutcatPasteWithCstOnCopyAndCut The component's constraints will be
                | recreated after a Copy or a CutExample: The following example
                | retrieves the component paste setting parameter of
                | AsmConstraintSettingAtt1 in PasteMode and sets the mode to With Cut
                | Only.  Set PasteMode = AsmConstraintSettingAtt1.PasteComponentMode
                | AsmConstraintSettingAtt1.PasteComponentMode = catPasteWithCstOnCut


                | Parameters:


        """
        return self.asmconstraintsettingatt.PasteComponentMode

    @property
    def quick_constraint_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | QuickConstraintMode
                | o Property QuickConstraintMode(    ) As CatAsmQuickConstraintMode
                | 
                | Returns or sets the quick constraint setting parameter. Role: The
                | quick constraint setting parameter manages the type of contraint that
                | will be created by tue Quick Constraint command.        Legal values:
                | catSpecifiedOrder Use the specified ordercatVerifiedConstraintFirst
                | Create verified constraint firstExample: The following example
                | retrieves the quick constraint setting parameter of
                | AsmConstraintSettingAtt1 in QuickMode and sets the mode to
                | catSpecifiedOrder.  Set QuickMode =
                | AsmConstraintSettingAtt1.QuickConstraintMode
                | AsmConstraintSettingAtt1.QuickConstraintMode = catSpecifiedOrder


                | Parameters:


        """
        return self.asmconstraintsettingatt.QuickConstraintMode

    @property
    def redundancy_mode(self, i_redundancy_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | RedundancyMode
                | o Property RedundancyMode(    CatAsmRedundancyMode    iRedundancyMode)
                | 
                | Sets redundancy check option for constraint creation. Role: The
                | Redundancy of the constraint is decided to be checked or not to be
                | checked, for constraint creation.    Legal values: catUnChecked
                | Redundancy of constraint will be checked while constraint
                | creation.catChecked Redundancy of constraint will not be checked while
                | constraint creation.


                | Parameters:


        """
        return self.asmconstraintsettingatt.RedundancyMode

    def get_constraint_creation_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetConstraintCreationModeInfo
                | o Func GetConstraintCreationModeInfo(    CATBSTR    ioAdminLevel,
                |                                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves informations about the constraint creation setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmconstraintsettingatt.GetConstraintCreationModeInfo(io_admin_level, io_locked)

    def get_paste_component_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPasteComponentModeInfo
                | o Func GetPasteComponentModeInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves informations about the component paste setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmconstraintsettingatt.GetPasteComponentModeInfo(io_admin_level, io_locked)

    def get_quick_constraint_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetQuickConstraintModeInfo
                | o Func GetQuickConstraintModeInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves informations about the quick constraint setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmconstraintsettingatt.GetQuickConstraintModeInfo(io_admin_level, io_locked)

    def get_quick_constraint_ordered_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetQuickConstraintOrderedList
                | o Func GetQuickConstraintOrderedList(    ) As CATSafeArrayVariant
                | 
                | Returns the quick constraint ordered list setting parameter. Role: The
                | quick constraint ordered list setting parameter manages the
                | determination of the kind of elements to constraint.


                | Parameters:
                | ioList
                |       The ordered list of constraints type
                |       The constraints types must be precise strings


                | Examples:
                | 
                | 
                | The following example retrieves the quick constraint ordered list of
                | AsmConstraintSettingAtt1 in QuickList
                | 
                | Dim QuickList
                | QuickList = AsmConstraintSettingAtt1.GetQuickConstraintOrderedList()
                | 
                | 
                | 
        """
        return self.asmconstraintsettingatt.GetQuickConstraintOrderedList()

    def set_constraint_creation_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetConstraintCreationModeLock
                | o Sub SetConstraintCreationModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the constraint creation setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmconstraintsettingatt.SetConstraintCreationModeLock(i_locked)

    def set_paste_component_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPasteComponentModeLock
                | o Sub SetPasteComponentModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the component paste setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmconstraintsettingatt.SetPasteComponentModeLock(i_locked)

    def set_quick_constraint_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetQuickConstraintModeLock
                | o Sub SetQuickConstraintModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the quick constraint setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.asmconstraintsettingatt.SetQuickConstraintModeLock(i_locked)

    def set_quick_constraint_ordered_list(self, i_list):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetQuickConstraintOrderedList
                | o Sub SetQuickConstraintOrderedList(    CATSafeArrayVariant    iList)
                | 
                | Sets the quick constraint ordered list setting parameter. Role: The
                | quick constraint ordered list setting parameter manages the
                | determination of the kind of elements to constraint.


                | Parameters:
                | iList
                |       The ordered list of constraints type
                |       The constraints types must be precise strings


                | Examples:
                | 
                | 
                | The following example sets the quick constraint ordered list of
                | AsmConstraintSettingAtt1
                | 
                | Dim QuickList(5)
                | QuickList(0) = "CATAsmCoincidenceType"
                | QuickList(1) = "CATAsmSurfContactType"
                | QuickList(2) = "CATAsmAngleType"
                | QuickList(3) = "CATAsmDistanceType"
                | QuickList(4) = "CATAsmPerpendType"
                | QuickList(5) = "CATAsmParallelType"
                | AsmConstraintSettingAtt1.SetQuickConstraintOrderedListQuickList
                | 
                | 
                | 
        """
        return self.asmconstraintsettingatt.SetQuickConstraintOrderedList(i_list)

