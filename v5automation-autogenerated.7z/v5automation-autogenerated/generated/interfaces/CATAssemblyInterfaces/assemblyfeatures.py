#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AssemblyFeatures:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all the AssemblyFeature objects of a product.

    """

    def __init__(self, catia):
        self.assemblyfeatures = catia.AssemblyFeatures     

    def add_assembly_add(self, i_body, i_body_comp, i_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddAssemblyAdd
                | o Func AddAssemblyAdd(    Body    iBody,
                |                           Product    iBodyComp,
                |                           Product    iComponent) As AssemblyFeature
                | 
                | Creates a new AssemblyBoolean object by adding a body to the assembly.


                | Parameters:
                | iBody
                |    The body to add
                |  
                |  iBodyComp
                |    The component that contains the body to add
                |  
                |  iComponent
                |    The component with respect to which the AssemblyBoolean object to create
                |    will be positioned
                |  
                | 
                |  Returns:
                |   The created 
                |  activateLinkAnchor('AssemblyBoolean','','AssemblyBoolean')  object


                | Examples:
                | 
                | 
                | This example creates the addBody AssemblyBoolean object in the
                | assemblyFeats collection using a body referenced as
                | bodyToAdd contained in the bodyToAddComp
                | component,
                | and positioned with respect to the positioningComp component.
                | 
                | Dim addBody As AssemblyBoolean
                | Set addBody = assemblyFeats.AddAssemblyAdd(bodyToAdd,     _
                | bodyToAddComp, _
                | positioningComp)
                | 
                | 
                | 
        """
        return self.assemblyfeatures.AddAssemblyAdd(i_body, i_body_comp, i_component)

    def add_assembly_hole(self, i_sketch, i_sketch_comp, i_depth, i_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddAssemblyHole
                | o Func AddAssemblyHole(    Sketch    iSketch,
                |                            Product    iSketchComp,
                |                            double    iDepth,
                |                            Product    iComponent) As AssemblyFeature
                | 
                | Creates a new AssemblyHole object.


                | Parameters:
                | iSketch
                |    The sketch defining the hole reference plane and anchor point.
                |    
                |    This sketch must contain a single point that defines the hole axis: 
                |    the hole axis in 3D passes through that point and is normal to the 
                |    sketch plane.
                |  
                |  iSketchComp
                |    The component that contains the sketch
                |  
                |  iDepth
                |    The hole depth
                |  
                |  iComponent
                |    The component with respect to which the AssemblyHole object to create
                |    will be positioned
                |  
                | 
                |  Returns:
                |   The created 
                |  activateLinkAnchor('AssemblyHole','','AssemblyHole')  object


                | Examples:
                | 
                | 
                | This example creates the hole AssemblyHole object in the
                | assemblyFeats collection using a sketch referenced as
                | holeSketch contained in the holeSketchComp
                | component, with a depth of 60mm,
                | and positioned with respect to the positioningComp component.
                | 
                | Dim hole As AssemblyHole
                | Set hole = assemblyFeats.AddAssemblyHole(holeSketch,     _
                | holeSketchComp, _
                | 60,             _
                | positioningComp)
                | 
                | 
                | 
        """
        return self.assemblyfeatures.AddAssemblyHole(i_sketch, i_sketch_comp, i_depth, i_component)

    def add_assembly_pocket(self, i_sketch, i_sketch_comp, i_depth, i_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddAssemblyPocket
                | o Func AddAssemblyPocket(    Sketch    iSketch,
                |                              Product    iSketchComp,
                |                              double    iDepth,
                |                              Product    iComponent) As AssemblyFeature
                | 
                | Creates a new AssemblyPocket object.


                | Parameters:
                | iSketch
                |    The sketch defining the pocket base
                |  
                |  iSketchComp
                |    The component that contains the sketch
                |  
                |  iDepth
                |    The pocket depth
                |  
                |  iComponent
                |    The component with respect to which the AssemblyPocket object to create
                |    will be positioned
                |  
                | 
                |  Returns:
                |   The created 
                |  activateLinkAnchor('AssemblyPocket','','AssemblyPocket')  object


                | Examples:
                | 
                | 
                | This example creates the pocket AssemblyPocket object in the
                | assemblyFeats collection using a sketch referenced as
                | pocketSketch contained in the pocketSketchComp
                | component, with a depth of 20mm,
                | and positioned with respect to the positioningComp component.
                | 
                | Dim pocket As AssemblyPocket
                | Set pocket = assemblyFeats.AddAssemblyPocket(pocketSketch,     _
                | pocketSketchComp, _
                | 20,               _
                | positioningComp)
                | 
                | 
                | 
        """
        return self.assemblyfeatures.AddAssemblyPocket(i_sketch, i_sketch_comp, i_depth, i_component)

    def add_assembly_remove(self, i_body, i_body_comp, i_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddAssemblyRemove
                | o Func AddAssemblyRemove(    Body    iBody,
                |                              Product    iBodyComp,
                |                              Product    iComponent) As AssemblyFeature
                | 
                | Creates a new AssemblyBoolean object by removing a body from the
                | assembly.


                | Parameters:
                | iBody
                |    The body to remove
                |  
                |  iBodyComp
                |    The component that contains the body to remove
                |  
                |  iComponent
                |    The component with respect to which the AssemblyBoolean object to create
                |    will be positioned
                |  
                | 
                |  Returns:
                |   The created 
                |  activateLinkAnchor('AssemblyBoolean','','AssemblyBoolean')  object


                | Examples:
                | 
                | 
                | This example creates the removeBody AssemblyBoolean object in the
                | assemblyFeats collection using a body referenced as
                | bodyToRemove contained in the bodyToRemoveComp
                | component,
                | and positioned with respect to the positioningComp component.
                | 
                | Dim removeBody As AssemblyBoolean
                | Set removeBody = assemblyFeats.AddAssemblyRemove(bodyToRemove,     _
                | bodyToRemoveComp, _
                | positioningComp)
                | 
                | 
                | 
        """
        return self.assemblyfeatures.AddAssemblyRemove(i_body, i_body_comp, i_component)

    def add_assembly_split(self, i_splitting_element, i_splitting_elem_comp, i_split_side, i_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddAssemblySplit
                | o Func AddAssemblySplit(    Reference    iSplittingElement,
                |                             Product    iSplittingElemComp,
                |                             CatSplitSide    iSplitSide,
                |                             Product    iComponent) As AssemblyFeature
                | 
                | Creates a new AssemblySplit object.


                | Parameters:
                | iSplittingElement
                |    The face or plane that will split the current body
                |  
                |  iSplittingElemComp
                |    The component that contains the splitting element
                |  
                |  iSplitSide
                |    The specification for which side of the current body should be kept
                |    at the end of the split operation
                |  
                |  iComponent
                |    The component with respect to which the AssemblySplit object to create
                |    will be positioned
                |  
                | 
                |  Returns:
                |   The created 
                |  activateLinkAnchor('AssemblySplit','','AssemblySplit')  object


                | Examples:
                | 
                | 
                | This example creates the splitByPlane AssemblySplit object in the
                | assemblyFeats collection using a plane referenced as
                | splittingPlane contained in the splittingComp
                | component, in such a way that the material to remove be
                | the one located in the direction of the splittingPlane normal vector,
                | and positioned with respect to the positioningComp component.
                | 
                | Dim splitByPlane As AssemblySplit
                | Set splitByPlane = assemblyFeats.AddAssemblySplit(splittingPlane,  _
                | splittingComp,   _
                | catPositiveSide, _
                | positioningComp)
                | 
                | 
                | 
        """
        return self.assemblyfeatures.AddAssemblySplit(i_splitting_element, i_splitting_elem_comp, i_split_side, i_component)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As AssemblyFeature
                | 
                | Returns an AssemblyFeature object using its index or its name from the
                | AssemblyFeatures collection.


                | Parameters:
                | iIndex
                |    The index or the name of the AssemblyFeature object to retrieve from
                |    the AssemblyFeatures collection.
                |    As a numerics, this index is the rank of the AssemblyFeature object
                |    in the collection.
                |    The index of the first AssemblyFeature object in the collection is 1, and
                |    the index of the last AssemblyFeature object is Count.
                |    As a string, it is the name you assigned to the AssemblyFeature object using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved AssemblyFeature object


                | Examples:
                | 
                | 
                | This example retrieves the last item in the assemblyFeats collection.
                | 
                | Dim lastAssemblyFeat As AssemblyFeature
                | Set lastAssemblyFeat = assemblyFeats.Item(assemblyFeats.Count)
                | 
                | 
                | 
        """
        return self.assemblyfeatures.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes an AssemblyFeature object from the AssemblyFeatures
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the AssemblyFeature object to remove from the AssemblyFeatures
                |    collection.
                |    As a numerics, this index is the rank of the AssemblyFeature object
                |    in the collection.
                |    The index of the first AssemblyFeature object in the collection is 1, and
                |    the index of the last AssemblyFeature object is Count.
                |    As a string, it is the name you assigned to the AssemblyFeature object using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


                | Examples:
                | 
                | 
                | This example removes the last AssemblyFeature object in the assemblyFeats
                | collection.
                | 
                | assemblyFeats.Remove(assemblyFeats.Count)
                | 
                | 
                | 
        """
        return self.assemblyfeatures.Remove(i_index)

