#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class MechanismCommands:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all MechanismCommand entities currently managed by the
                | application.

    """

    def __init__(self, catia):
        self.mechanismcommands = catia.MechanismCommands     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As MechanismCommand
                | 
                | Creates a new MechanismCommand and adds it to the MechanismCommands
                | collection.  Returns:     The created MechanismCommand     Example:
                | This example creates a new MechanismCommand    in the TheCommands
                | collection.        Dim NewCommand As MechanismCommand    Set
                | NewCommand = TheCommands.Add()


                | Parameters:


        """
        return self.mechanismcommands.Add()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As MechanismCommand
                | 
                | Returns a MechanismCommand using its index or its name from the
                | Commands collection.


                | Parameters:
                | iIndex
                |    The index or the name of the MechanismCommand to retrieve from
                |    the collection of Commands.
                |    As a numerics, this index is the rank of the MechanismCommand
                |    in the collection.
                |    The index of the first MechanismCommand in the collection is 1, and
                |    the index of the last MechanismCommand is Count.
                |    As a string, it is the name you assigned to the MechanismCommand using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved MechanismCommand


                | Examples:
                | 
                | 
                | This example returns in ThisCommand the third MechanismCommand
                | in the collection, and in ThatCommand the MechanismCommand named
                | MyCommand.
                | 
                | Dim ThisCommand As MechanismCommand
                | Set ThisCommand = TheCommands.Item(3)
                | Dim ThatCommand As MechanismCommand
                | Set ThatCommand = CATIA.MechanismCommands.Item("MyCommand")
                | 
                | 
                | 
        """
        return self.mechanismcommands.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Remove a MechanismCommand from the MechanismCommands collection.


                | Parameters:
                | iIndex
                |     The index or the name of the MechanismCommand to retrieve from the collection of MechanismCommands.
                |     As a numerics, this index is the rank of the MechanismCommand in the collection.
                |     The index of the first MechanismCommand in the collection is 1, and
                |     the index of the last MechanismCommand is Count.
                |     As a string, it is the name you assigned to the MechanismCommand.
                |  
                | 
                |  Returns:
                |      Nothing


                | Examples:
                | 
                | 
                | The following example removes the tenth MechanismCommand and the MechanismCommand named
                | CommandTwo from the TheCommands collection.
                | 
                | TheCommands.Remove(10)
                | TheCommands.Remove("CommandTwo")
                | 
                | 
                | 
        """
        return self.mechanismcommands.Remove(i_index)

