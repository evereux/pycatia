#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class KinematicsWorkbench:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access all Kinematics entities.

    """

    def __init__(self, catia):
        self.kinematicsworkbench = catia.KinematicsWorkbench     

    @property
    def mechanisms(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Mechanisms
                | o Property Mechanisms(    ) As Mechanisms
                | 
                | Returns the Mechanisms collection.  Returns:    The Mechanisms
                | collection     Example:    This example retrieves the Mechanisms
                | collection of the active document.        Dim TheKinWorkbench As
                | Workbench    Set TheKinWorkbench = CATIA.ActiveDocument.GetWorkbench (
                | "KinematicsWorkbench" )    Dim TheMechanismsList As Mechanisms    Set
                | TheMechanismsList = TheKinWorkbench.Mechanisms


                | Parameters:


        """
        return self.kinematicsworkbench.Mechanisms

