#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Dressup:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access the Dressup object.

    """

    def __init__(self, catia):
        self.dressup = catia.Dressup     

    @property
    def context(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Context
                | o Property Context(    ) As Product
                | 
                | Returns the context product on which the mechanism is defined. This
                | property is read only.  Returns:     The dressup mechanism's context
                | Example:    This example sets in MecaContext the context product of
                | MyDressup.        Dim MecaContext As Product    Set MecaContext =
                | MyDressup.Context


                | Parameters:


        """
        return self.dressup.Context

    @property
    def mechanism(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Mechanism
                | o Property Mechanism(    ) As Mechanism
                | 
                | Returns the mechanism on which a dressup is applied. This property is
                | read only.  Returns:     The dressup's mechanism   Example:  This
                | example sets in Meca the mechanism of MyDressup.    Dim Meca As
                | Mechanism  Set Meca = MyDressup.Mechanism


                | Parameters:


        """
        return self.dressup.Mechanism

    def attach(self, i_link, i_attached_prod):
        """
        .. note::
            CAA V5 Visual Basic help

                | Attach
                | o Sub Attach(    Product    iLink,
                |                  Product    iAttachedProd)
                | 
                | Attaches a given product to a link of the mechanism pointed by the
                | dressup.


                | Parameters:
                | iLink
                |     The link (Product) on which the attachment should be done. 
                |     It should be a product that belongs to the mechanism pointed by the dressup, 
                |     otherwise the method will fail.
                |  
                |  iAttachedProd
                |     The Product that will be attached to the link. This product should not be a product  
                |     that is already attached by another link, otherwise the method will fail.
                |  
                | 
                |  Returns:
                |      Nothing


                | Examples:
                | 
                | 
                | This example attaches inside MyDressup, Link1 as mechanism's part to Product1.
                | 
                | Dim Link1 As Product
                | Dim Product1 As Product
                | ...
                | MyDressup.Attach(Link1,Product1)
                | 
                | 
                | 
        """
        return self.dressup.Attach(i_link, i_attached_prod)

    def detach(self, i_attached_prod):
        """
        .. note::
            CAA V5 Visual Basic help

                | Detach
                | o Sub Detach(    Product    iAttachedProd)
                | 
                | Detaches an attached product from its link.


                | Parameters:
                | iAttachedProd
                |     The Product that will be detached. It should be a product that is currently 
                |     attached in the dressup, otherwise the method will fail.
                |  
                | 
                |  Returns:
                |      Nothing


                | Examples:
                | 
                | 
                | This example detaches Product1 previously attached to a mechanism's part
                | inside MyDressup.
                | 
                | Dim Product1 As Product
                | ...
                | MyDressup.Detach(Product1)
                | 
                | 
                | 
        """
        return self.dressup.Detach(i_attached_prod)

    def list_attached(self, i_link):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListAttached
                | o Func ListAttached(    Product    iLink) As CATSafeArrayVariant
                | 
                | Returns the list of products attached to a given link.


                | Parameters:
                | iLink
                |  The Product on which the returned product list is attached to.
                |  
                | 
                |  Returns:
                |      The Product list that is attached to iLink.


                | Examples:
                | 
                | 
                | The following example loops for all the products attached to Link1.
                | 
                | Dim ListAttached1 as Product
                | ListAttached1 = MyDressup.ListAttached(Link1)
                | Dim Maxi as Integer
                | Set Maxi = ubound(ListAttached1)
                | Dim Prod_i as Product
                | For i = 0  To  Maxi
                | Set Prod_i = ListAttached1(i)
                | ..
                | Next
                | 
                | 
                | 
        """
        return self.dressup.ListAttached(i_link)

