#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Mechanism:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access the Mechanism object.

    """

    def __init__(self, catia):
        self.mechanism = catia.Mechanism     

    @property
    def commands(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Commands
                | o Property Commands(    ) As MechanismCommands
                | 
                | Returns the collection of commands in the mechanism.


                | Parameters:
                | oCommands
                |     The collection of commands.
                |  This property is read only because because list is aggregated in the Mechanism


        """
        return self.mechanism.Commands

    @property
    def fixed_part(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FixedPart
                | o Property FixedPart(    ) As Product
                | 
                | Returns or sets the fixed part of the mechanism.


                | Parameters:
                | oFixedPart
                |     The fixed part.


        """
        return self.mechanism.FixedPart

    @property
    def joints(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Joints
                | o Property Joints(    ) As Joints
                | 
                | Returns the collection of joints in the mechanism.


                | Parameters:
                | oJoints
                |     The collection of joints.
                |  This property is read only because because list is aggregated in the Mechanism


        """
        return self.mechanism.Joints

    @property
    def nb_commands(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NbCommands
                | o Property NbCommands(    ) As long
                | 
                | Returns the number of commands in the mechanism.


                | Parameters:
                | oNbCommands
                |     The number of commands.
                |  This property is read only because number depends on commands creation/destruction


        """
        return self.mechanism.NbCommands

    @property
    def nb_dof(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NbDof
                | o Property NbDof(    ) As long
                | 
                | Returns the degree of freedom of the mechanism.


                | Parameters:
                | oNbDof
                |     The degree of freedom.
                |  This property is read only because because it depends on joints and commands


        """
        return self.mechanism.NbDof

    @property
    def nb_joints(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NbJoints
                | o Property NbJoints(    ) As long
                | 
                | Returns the number of joints in the mechanism.


                | Parameters:
                | oNbJoints
                |     The number of joints.
                |  This property is read only because number depends on joints creation/destruction


        """
        return self.mechanism.NbJoints

    @property
    def nb_products(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NbProducts
                | o Property NbProducts(    ) As long
                | 
                | Returns the number of products (i.e. bodies) involved in the
                | mechanism.


                | Parameters:
                | oNbProducts
                |     The number of products.
                |  This property is read only because number depends on joints creation/destruction


        """
        return self.mechanism.NbProducts

    def add_command(self, i_cmd_type, i_joint):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddCommand
                | o Func AddCommand(    CATBSTR    iCmdType,
                |                       Joint    iJoint) As MechanismCommand
                | 
                | Adds a command in the mechanism, on a joint.


                | Parameters:
                | iCmdType
                |     The command type.
                |  
                |  iJoint
                |     The joint to be driven.
                |  
                |  oNewCommand
                |     The newly created command.


        """
        return self.mechanism.AddCommand(i_cmd_type, i_joint)

    def add_joint(self, i_joint_type, i_list_elem):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddJoint
                | o Func AddJoint(    CATBSTR    iJointType,
                |                     CATSafeArrayVariant    iListElem) As Joint
                | 
                | Adds a joint in the mechanism.


                | Parameters:
                | iJointType
                |     The joint type.
                |  
                |  iListElem
                |     The list of elements expected to locate the joint, depending on the type.
                |  
                |  oNewJoint
                |     The newly created joint.


        """
        return self.mechanism.AddJoint(i_joint_type, i_list_elem)

    def get_command_values(self, io_cmd_values):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCommandValues
                | o Sub GetCommandValues(    CATSafeArrayVariant    ioCmdValues)
                | 
                | Allows to retrieve current state of the mechanism.


                | Parameters:
                | ioCmdValues
                |     current command values


        """
        return self.mechanism.GetCommandValues(io_cmd_values)

    def get_product(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProduct
                | o Func GetProduct(    long    iIndex) As Product
                | 
                | Returns an item from the list of the products involved in the
                | mechanism.


                | Parameters:
                | iIndex
                |     The index for the product.
                |  
                |  oProduct
                |     The product at that index.
                |  
                | 
                |  Returns:
                |      HRESULT


        """
        return self.mechanism.GetProduct(i_index)

    def get_product_motion(self, i_product, io_motion):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProductMotion
                | o Sub GetProductMotion(    Product    iProduct,
                |                            CATSafeArrayVariant    ioMotion)
                | 
                | Retrieves motion from initial state to current state for a part of the
                | mechanism.


                | Parameters:
                | iProduct
                |        The moving product
                |     
                |  ioMotion
                |        The motion matrix (12 real values, compatible with the Move object)
                |     
                | 
                |  See also:
                |   activateLinkAnchor('Move','','Move')


        """
        return self.mechanism.GetProductMotion(i_product, io_motion)

    def put_command_values(self, i_cmd_values):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutCommandValues
                | o Sub PutCommandValues(    CATSafeArrayVariant    iCmdValues)
                | 
                | Triggers immediate mechanism solving (motion is NOT applied to the
                | model).


                | Parameters:
                | iCmdValues
                |     command values to be solved for


        """
        return self.mechanism.PutCommandValues(i_cmd_values)

    def put_command_values_with_multi_steps(self, i_cmd_values, i_nb_steps, o_step_reached):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutCommandValuesWithMultiSteps
                | o Sub PutCommandValuesWithMultiSteps(    CATSafeArrayVariant    iCmdValues,
                |                                          long    iNbSteps,
                |                                          long    oStepReached)
                | 
                | Puts command values in given number of steps. Visualization is updated
                | after every step.


                | Parameters:
                | iCmdValues
                |     Array of target command values (position to achieve)
                |  
                |  inbSteps
                |     Number of steps in witch the target command value is to be reached.  
                |  Legal values 
                |   inbSteps greater than 0   Number of step must be greater than zero.
                |  
                |  oStepReached
                |     Number of steps reached successfully.
                | 
                | 
                | 
                | 
                | o Sub ResetCmdValueToZero( activateLink('MechanismCommand','MechanismCommand') iCommand)
                | 
                | 
                |  Sets the command value to zero for the given command without disturbing part positions.


        """
        return self.mechanism.PutCommandValuesWithMultiSteps(i_cmd_values, i_nb_steps, o_step_reached)

    def reset_cmd_value_to_zero(self, i_command):
        """
        .. note::
            CAA V5 Visual Basic help

                | ResetCmdValueToZero
                | o Sub ResetCmdValueToZero(    MechanismCommand    iCommand)
                | 
                | Sets the command value to zero for the given command without
                | disturbing part positions.


                | Parameters:
                | iCommand
                |     The command to reset to zero


        """
        return self.mechanism.ResetCmdValueToZero(i_command)

    def update(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Update
                | o Sub Update(    )
                | 
                | Reassembles the mechanism after dimension changes in the parts.


                | Parameters:


        """
        return self.mechanism.Update()

