#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Joint:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to manage the Joint object.Depending on their type, joints
                | have parameters or not, representing length or angle:Each parameter
                | can have a lower and/or an upper limit.Methods are provided to set,
                | unset and return the limits for each parameter.

    """

    def __init__(self, catia):
        self.joint = catia.Joint     

    @property
    def current_value1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentValue1
                | o Property CurrentValue1(    ) As double
                | 
                | Gets the joint current value for first parameter.


                | Parameters:
                | oCurrentValue
                |  This property is read only because current value modification is done by solver


        """
        return self.joint.CurrentValue1

    @property
    def current_value2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentValue2
                | o Property CurrentValue2(    ) As double
                | 
                | Gets the joint current value for second parameter.


                | Parameters:
                | oCurrentValue
                |  This property is read only because current value modification is done by solver


        """
        return self.joint.CurrentValue2

    @property
    def lower_limit1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LowerLimit1
                | o Property LowerLimit1(    ) As double
                | 
                | Gets or returns the lower limit of the joint, for the first parameter.


                | Parameters:
                | iLimitValue
                |      The value for the limit
                |  When reading, an error is returned if the joint type has no such parameter, or if the limit is unset.


        """
        return self.joint.LowerLimit1

    @property
    def lower_limit2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LowerLimit2
                | o Property LowerLimit2(    ) As double
                | 
                | Gets or returns the lower limit of the joint, for the second
                | parameter.


                | Parameters:
                | iLimitValue
                |      The value for the limit
                |  When reading, an error is returned if the joint type has no such parameter, or if the limit is unset.


        """
        return self.joint.LowerLimit2

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the joint type.


                | Parameters:
                | oType
                |      The type of the joint
                |  This property is read only because the construction of the object depends on the type.


        """
        return self.joint.Type

    @property
    def upper_limit1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpperLimit1
                | o Property UpperLimit1(    ) As double
                | 
                | Gets or returns the upper limit of the joint, for the first parameter.


                | Parameters:
                | iLimitValue
                |      The value for the limit
                |  When reading, an error is returned if the joint type has no such parameter, or if the limit is unset.


        """
        return self.joint.UpperLimit1

    @property
    def upper_limit2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpperLimit2
                | o Property UpperLimit2(    ) As double
                | 
                | Gets or returns the upper limit of the joint, for the second
                | parameter.


                | Parameters:
                | iLimitValue
                |      The value for the limit
                |  When reading, an error is returned if the joint type has no such parameter, or if the limit is unset.


        """
        return self.joint.UpperLimit2

    def unset_lower_limit1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetLowerLimit1
                | o Sub UnsetLowerLimit1(    )
                | 
                | Unsets the lower limit of the joint, for the first parameter.


                | Parameters:
                | iLimitValue
                |      The value for the limit
                |  When reading, an error is returned if the joint type has no such parameter, or if the limit is unset.


        """
        return self.joint.UnsetLowerLimit1()

    def unset_lower_limit2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetLowerLimit2
                | o Sub UnsetLowerLimit2(    )
                | 
                | Unsets the lower limit of the joint, for the second parameter.


                | Parameters:
                | iLimitValue
                |      The value for the limit


        """
        return self.joint.UnsetLowerLimit2()

    def unset_upper_limit1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetUpperLimit1
                | o Sub UnsetUpperLimit1(    )
                | 
                | Unsets the upper limit of the joint, for the first parameter.


                | Parameters:
                | iLimitValue
                |      The value for the limit


        """
        return self.joint.UnsetUpperLimit1()

    def unset_upper_limit2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetUpperLimit2
                | o Sub UnsetUpperLimit2(    )
                | 
                | Unsets the upper limit of the joint, for the second parameter.


                | Parameters:
                | iLimitValue
                |      The value for the limit


        """
        return self.joint.UnsetUpperLimit2()

