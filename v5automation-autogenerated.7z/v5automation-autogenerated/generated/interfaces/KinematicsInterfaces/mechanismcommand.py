#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class MechanismCommand:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access the Command object (in Kinematics context).

    """

    def __init__(self, catia):
        self.mechanismcommand = catia.MechanismCommand     

    @property
    def current_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentValue
                | o Property CurrentValue(    ) As double
                | 
                | Returns the current value for a command.


                | Parameters:
                | oCurrentValue
                |     The current value
                |   This property is read only because current value modification is done by solver


        """
        return self.mechanismcommand.CurrentValue

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property Orientation(    ) As short
                | 
                | Deprecated:  V5R18  Not implemented - will be deprecated Returns or
                | sets the command orientation.


                | Parameters:
                | oOrientation
                |     The orientation of the command; only the sign is important (+: same as relying joint/-: opposite)


        """
        return self.mechanismcommand.Orientation

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the command type.


                | Parameters:
                | oType
                |      The type of the command
                |  
                | 
                |  See also:
                |   activateLinkAnchor('Mechanism','','Mechanism')


        """
        return self.mechanismcommand.Type

