#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisSensor:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the  analysis sensor.

    """

    def __init__(self, catia):
        self.analysissensor = catia.AnalysisSensor     

    @property
    def out_put_parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OutPutParameters
                | o Property OutPutParameters(    ) As Parameters
                | 
                | Returns the collection object containing the sensor parameters.
                | Example:The following example returns in params the parameters
                | computed by the sensor:  Dim AnalysisSensor1 As AnalysisSensor Dim
                | params As CATIAParameters Set params =
                | AnalysisSensor1.OutPutParameters


                | Parameters:


        """
        return self.analysissensor.OutPutParameters

    def update(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Update
                | o Sub Update(    )
                | 
                | Update the sensor. Computation of OutPutParameters if needed.
                | Example:The following example computes the sensor:  Dim
                | AnalysisSensor1 As AnalysisSensor AnalysisSensor1.Update


                | Parameters:


        """
        return self.analysissensor.Update()

