#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisSupports:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of analysis case making an Analysis.

    """

    def __init__(self, catia):
        self.analysissupports = catia.AnalysisSupports     

    def item(self, i_index, o_positionning, o_pointed):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Sub Item(    long    iIndex,
                |                AnyObject    oPositionning,
                |                AnyObject    oPointed)
                | 
                | Returns analysis support object information using its index in the
                | collection.


                | Parameters:
                | iIndex
                |    The numeric index is the rank in the collection.
                |  The index of the first case in the collection is 1, and the index of the last is Count.
                |  
                |  oPositionning
                |  The positionning feature is exists.  
                |  oPointed
                |  The pointed object.


        """
        return self.analysissupports.Item(i_index, o_positionning, o_pointed)

