#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisReportingSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to handle the Analysis & Simulation "ReportingSetting".

    """

    def __init__(self, catia):
        self.analysisreportingsettingatt = catia.AnalysisReportingSettingAtt     

    @property
    def background_image_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BackgroundImageMode
                | o Property BackgroundImageMode(    ) As boolean
                | 
                | Returns or sets the BackgroundImageMode parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysisreportingsettingatt.BackgroundImageMode

    @property
    def custom_background_image(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CustomBackgroundImage
                | o Property CustomBackgroundImage(    ) As CATBSTR
                | 
                | Returns or sets the CustomBackgroundImage parameter.  Ensure
                | consistency with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysisreportingsettingatt.CustomBackgroundImage

    @property
    def custom_image_format(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CustomImageFormat
                | o Property CustomImageFormat(    ) As CATBSTR
                | 
                | Returns or sets the CustomImageFormat parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysisreportingsettingatt.CustomImageFormat

    @property
    def custom_image_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CustomImageHeight
                | o Property CustomImageHeight(    ) As long
                | 
                | Returns or sets the CustomImageHeight parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysisreportingsettingatt.CustomImageHeight

    @property
    def custom_image_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CustomImageWidth
                | o Property CustomImageWidth(    ) As long
                | 
                | Returns or sets the CustomImageWidth parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysisreportingsettingatt.CustomImageWidth

    @property
    def image_quality_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImageQualityMode
                | o Property ImageQualityMode(    ) As boolean
                | 
                | Returns or sets the ImageQualityMode parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysisreportingsettingatt.ImageQualityMode

    @property
    def temp_output_directory(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TempOutputDirectory
                | o Property TempOutputDirectory(    ) As CATBSTR
                | 
                | Returns or sets the TempOutputDirectory parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysisreportingsettingatt.TempOutputDirectory

    def get_background_image_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBackgroundImageModeInfo
                | o Func GetBackgroundImageModeInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the BackgroundImageMode
                | parameter. Role:Retrieves the state of the BackgroundImageMode
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.analysisreportingsettingatt.GetBackgroundImageModeInfo(io_admin_level, io_locked)

    def get_custom_background_image_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCustomBackgroundImageInfo
                | o Func GetCustomBackgroundImageInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the CustomBackgroundImage
                | parameter. Role:Retrieves the state of the CustomBackgroundImage
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.analysisreportingsettingatt.GetCustomBackgroundImageInfo(io_admin_level, io_locked)

    def get_custom_image_format_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCustomImageFormatInfo
                | o Func GetCustomImageFormatInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the CustomImageFormat
                | parameter. Role:Retrieves the state of the CustomImageFormat parameter
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.analysisreportingsettingatt.GetCustomImageFormatInfo(io_admin_level, io_locked)

    def get_custom_image_height_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCustomImageHeightInfo
                | o Func GetCustomImageHeightInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the CustomImageHeight
                | parameter. Role:Retrieves the state of the CustomImageHeight parameter
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.analysisreportingsettingatt.GetCustomImageHeightInfo(io_admin_level, io_locked)

    def get_custom_image_width_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCustomImageWidthInfo
                | o Func GetCustomImageWidthInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the CustomImageWidth parameter.
                | Role:Retrieves the state of the CustomImageWidth parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.analysisreportingsettingatt.GetCustomImageWidthInfo(io_admin_level, io_locked)

    def get_image_quality_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetImageQualityModeInfo
                | o Func GetImageQualityModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ImageQualityMode parameter.
                | Role:Retrieves the state of the ImageQualityMode parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.analysisreportingsettingatt.GetImageQualityModeInfo(io_admin_level, io_locked)

    def get_temp_output_directory_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTempOutputDirectoryInfo
                | o Func GetTempOutputDirectoryInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TempOutputDirectory
                | parameter. Role:Retrieves the state of the TempOutputDirectory
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.analysisreportingsettingatt.GetTempOutputDirectoryInfo(io_admin_level, io_locked)

    def set_background_image_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBackgroundImageModeLock
                | o Sub SetBackgroundImageModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BackgroundImageMode parameter. Role:Locks or
                | unlocks the BackgroundImageMode parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.analysisreportingsettingatt.SetBackgroundImageModeLock(i_locked)

    def set_custom_background_image_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCustomBackgroundImageLock
                | o Sub SetCustomBackgroundImageLock(    boolean    iLocked)
                | 
                | Locks or unlocks the CustomBackgroundImage parameter. Role:Locks or
                | unlocks the CustomBackgroundImage parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.analysisreportingsettingatt.SetCustomBackgroundImageLock(i_locked)

    def set_custom_image_format_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCustomImageFormatLock
                | o Sub SetCustomImageFormatLock(    boolean    iLocked)
                | 
                | Locks or unlocks the CustomImageFormat parameter. Role:Locks or
                | unlocks the CustomImageFormat parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.analysisreportingsettingatt.SetCustomImageFormatLock(i_locked)

    def set_custom_image_height_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCustomImageHeightLock
                | o Sub SetCustomImageHeightLock(    boolean    iLocked)
                | 
                | Locks or unlocks the CustomImageHeight parameter. Role:Locks or
                | unlocks the ImageHeight parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.analysisreportingsettingatt.SetCustomImageHeightLock(i_locked)

    def set_custom_image_width_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCustomImageWidthLock
                | o Sub SetCustomImageWidthLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ImageWidth parameter. Role:Locks or unlocks the
                | ImageWidth parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.analysisreportingsettingatt.SetCustomImageWidthLock(i_locked)

    def set_image_quality_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetImageQualityModeLock
                | o Sub SetImageQualityModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ImageQualityMode parameter. Role:Locks or unlocks
                | the DefaultImageQuality parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.analysisreportingsettingatt.SetImageQualityModeLock(i_locked)

    def set_temp_output_directory_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTempOutputDirectoryLock
                | o Sub SetTempOutputDirectoryLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TempOutputDirectory parameter. Role:Locks or
                | unlocks the TempOutputDirectory parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.analysisreportingsettingatt.SetTempOutputDirectoryLock(i_locked)

