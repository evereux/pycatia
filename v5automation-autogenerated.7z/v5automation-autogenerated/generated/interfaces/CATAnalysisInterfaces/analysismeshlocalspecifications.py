#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisMeshLocalSpecifications:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a AnalysisMeshLocalSpecifications.

    """

    def __init__(self, catia):
        self.analysismeshlocalspecifications = catia.AnalysisMeshLocalSpecifications     

    def add(self, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    CATBSTR    iType) As AnalysisMeshLocalSpecification
                | 
                | Creates a new local specification  and adds it to the local
                | specification  collection. The local specification  will be created
                | linked to the AnalysisMeshManager object.


                | Parameters:
                | iType
                |  The type of mesh part to create.
                |  
                | 
                |  Returns:
                |   The created local specification


        """
        return self.analysismeshlocalspecifications.Add(i_type)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes a local specification  using its index or its name from the
                | local specification  collection.


                | Parameters:
                | iIndex
                |    The index or the name of the local specification  to retrieve from
                |    the collection of local specification .
                |    As a numeric, this index is the rank of the local specification 
                |    in the collection. The index of the first local specification  in the collection is 1,
                |    and the index of the last local specification  is Count.
                |    As a string, it is the name you assigned to the local specification using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


        """
        return self.analysismeshlocalspecifications.Remove(i_index)

