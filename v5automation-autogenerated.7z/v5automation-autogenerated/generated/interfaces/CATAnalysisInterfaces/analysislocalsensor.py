#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisLocalSensor:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the  analysis local sensor.This object is a kind of
                | AnalysisSensor based on analysis feature resultsbased on a finite
                | element selection. This sensor definition is based on an XML
                | filestored in the CATIARuntimeView.

    """

    def __init__(self, catia):
        self.analysislocalsensor = catia.AnalysisLocalSensor     

    @property
    def xml_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | XMLName
                | o Property XMLName(    ) As CATBSTR
                | 
                | Returns or sets the Identifier of the sensor as defined in the XML
                | file.  Example: This example retrieves in MyXMLName the identifier of
                | the AnalysisSensor1 object.  MyObjectName = AnalysisSensor1.XMLName


                | Parameters:


        """
        return self.analysislocalsensor.XMLName

