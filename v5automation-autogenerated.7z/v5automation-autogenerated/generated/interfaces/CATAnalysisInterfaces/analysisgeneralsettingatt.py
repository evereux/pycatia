#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisGeneralSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to handle the Analysis & Simulation "GeneralSetting".

    """

    def __init__(self, catia):
        self.analysisgeneralsettingatt = catia.AnalysisGeneralSettingAtt     

    @property
    def analysis_cache_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisCacheMode
                | o Property AnalysisCacheMode(    ) As long
                | 
                | Tells if Product Structure Cache Mode will be handled.


                | Parameters:


        """
        return self.analysisgeneralsettingatt.AnalysisCacheMode

    @property
    def analysis_load_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisLoadMode
                | o Property AnalysisLoadMode(    ) As long
                | 
                | Retrieves if pointed document will be loaded.


                | Parameters:


        """
        return self.analysisgeneralsettingatt.AnalysisLoadMode

    @property
    def analysis_naming_auto(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisNamingAuto
                | o Property AnalysisNamingAuto(    ) As long
                | 
                | Tells if Automatic naming will be activated.


                | Parameters:


        """
        return self.analysisgeneralsettingatt.AnalysisNamingAuto

    @property
    def default_analysis_flag(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultAnalysisFlag
                | o Property DefaultAnalysisFlag(    ) As long
                | 
                | Retrieves if a default analysis Case will be created.


                | Parameters:


        """
        return self.analysisgeneralsettingatt.DefaultAnalysisFlag

    @property
    def default_analysis_template(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultAnalysisTemplate
                | o Property DefaultAnalysisTemplate(    ) As CATBSTR
                | 
                | Retrieves the name of the default analysis Case that will be created.


                | Parameters:


        """
        return self.analysisgeneralsettingatt.DefaultAnalysisTemplate

    @property
    def view_analysis_parameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewAnalysisParameter
                | o Property ViewAnalysisParameter(    ) As long
                | 
                | Retrieves if the Parameter set is visible in the feature tree of the
                | analysis document.


                | Parameters:


        """
        return self.analysisgeneralsettingatt.ViewAnalysisParameter

    @property
    def view_analysis_relation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewAnalysisRelation
                | o Property ViewAnalysisRelation(    ) As long
                | 
                | Retrieves if the Relation set is visible in the feature tree of the
                | analysis document.


                | Parameters:


        """
        return self.analysisgeneralsettingatt.ViewAnalysisRelation

    def get_analysis_cache_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnalysisCacheModeInfo
                | o Func GetAnalysisCacheModeInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the parameter. Role:Retrieves
                | the state of the parameter in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.GetAnalysisCacheModeInfo(io_admin_level, io_locked)

    def get_analysis_load_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnalysisLoadModeInfo
                | o Func GetAnalysisLoadModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the parameter. Role:Retrieves
                | the state of the parameter in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.GetAnalysisLoadModeInfo(io_admin_level, io_locked)

    def get_analysis_naming_auto_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnalysisNamingAutoInfo
                | o Func GetAnalysisNamingAutoInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the parameter. Role:Retrieves
                | the state of the parameter in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.GetAnalysisNamingAutoInfo(io_admin_level, io_locked)

    def get_default_analysis_flag_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultAnalysisFlagInfo
                | o Func GetDefaultAnalysisFlagInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the default flag.
                | Role:Retrieves the state of the default flag in the current
                | environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.GetDefaultAnalysisFlagInfo(io_admin_level, io_locked)

    def get_default_analysis_template_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultAnalysisTemplateInfo
                | o Func GetDefaultAnalysisTemplateInfo(    CATBSTR    ioAdminLevel,
                |                                           CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the default template.
                | Role:Retrieves the state of the default template in the current
                | environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.GetDefaultAnalysisTemplateInfo(io_admin_level, io_locked)

    def get_view_analysis_parameter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewAnalysisParameterInfo
                | o Func GetViewAnalysisParameterInfo(    CATBSTR    ioAdminLevel,
                |                                         CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the parameter. Role:Retrieves
                | the state of the parameter in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.GetViewAnalysisParameterInfo(io_admin_level, io_locked)

    def get_view_analysis_relation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewAnalysisRelationInfo
                | o Func GetViewAnalysisRelationInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the parameter. Role:Retrieves
                | the state of the parameter in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.GetViewAnalysisRelationInfo(io_admin_level, io_locked)

    def set_analysis_cache_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnalysisCacheModeLock
                | o Sub SetAnalysisCacheModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.SetAnalysisCacheModeLock(i_locked)

    def set_analysis_load_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnalysisLoadModeLock
                | o Sub SetAnalysisLoadModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.SetAnalysisLoadModeLock(i_locked)

    def set_analysis_naming_auto_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnalysisNamingAutoLock
                | o Sub SetAnalysisNamingAutoLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.SetAnalysisNamingAutoLock(i_locked)

    def set_default_analysis_flag_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultAnalysisFlagLock
                | o Sub SetDefaultAnalysisFlagLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.SetDefaultAnalysisFlagLock(i_locked)

    def set_default_analysis_template_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultAnalysisTemplateLock
                | o Sub SetDefaultAnalysisTemplateLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.SetDefaultAnalysisTemplateLock(i_locked)

    def set_view_analysis_parameter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewAnalysisParameterLock
                | o Sub SetViewAnalysisParameterLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.SetViewAnalysisParameterLock(i_locked)

    def set_view_analysis_relation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewAnalysisRelationLock
                | o Sub SetViewAnalysisRelationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.analysisgeneralsettingatt.SetViewAnalysisRelationLock(i_locked)

