#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisManager:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the root object inside an analysis document.It aggregates
                | all the objects making up an analysis document.

    """

    def __init__(self, catia):
        self.analysismanager = catia.AnalysisManager     

    @property
    def analysis_models(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisModels
                | o Property AnalysisModels(    ) As AnalysisModels
                | 
                | Returns the analysis model collection from the current analysis
                | manager.  Example:The following example returns from RootAnalysis the
                | root analysis object of the active document, assumed to be an Analysis
                | document, the  collection of analysis models.  Dim AnalysisDocument As
                | Document Set AnalysisDocument = CATIA.ActiveDocument Dim RootAnalysis
                | As AnalysisManager Set RootAnalysis = AnalysisDocument.Analysis Dim
                | analysisModels As AnalysisModels Set analysisModels =
                | RootAnalysis.AnalysisModels


                | Parameters:


        """
        return self.analysismanager.AnalysisModels

    @property
    def analysis_sets(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisSets
                | o Property AnalysisSets(    ) As AnalysisSets
                | 
                | Returns the analysis sets collection associated with an analysis
                | manager. This collection allows to access the Analysis Connection
                | Manager that aggregates the Analysis Connection features.  Returns:  a
                | collection of  CATIAAnalysisSets.


                | Parameters:


        """
        return self.analysismanager.AnalysisSets

    @property
    def linked_documents(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LinkedDocuments
                | o Property LinkedDocuments(    ) As AnalysisLinkedDocuments
                | 
                | Returns the collection containing the documents linked to analysis
                | document. All the CATIA documents that are linked to the different
                | objects (like AnalysisMeshPart of Analysis Entity) might be accessed
                | thru that collection.  Example:The following example returns in
                | documents the linked documents of the AnalysisDocument :  Dim
                | AnalysisDocument As Document Set AnalysisDocument =
                | CATIA.ActiveDocument Dim RootAnalysis As AnalysisManager Set
                | RootAnalysis = AnalysisDocument.Analysis Dim Documents As
                | AnalysisLinkedDocuments Set Documents = RootAnalysis.LinkedDocuments


                | Parameters:


        """
        return self.analysismanager.LinkedDocuments

    @property
    def parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Parameters
                | o Property Parameters(    ) As Parameters
                | 
                | Returns the collection object containing the analysis parameters. All
                | the parameters that are defined in analysis objects might be accessed
                | thru that collection.  Example:The following example returns in params
                | the parameters of the RootAnalysis from the AnalysisDocument document:
                | Dim AnalysisDocument As Document Set AnalysisDocument =
                | CATIA.ActiveDocument Dim RootAnalysis As AnalysisManager Set
                | RootAnalysis = AnalysisDocument.Analysis Dim params As CATIAParameters
                | Set params = RootAnalysis.Parameters


                | Parameters:


        """
        return self.analysismanager.Parameters

    @property
    def relations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Relations
                | o Property Relations(    ) As Relations
                | 
                | Returns the collection object containing the analysis relations. All
                | the relations that are defined in analysis objects might be accessed
                | thru that collection.  Example:The following example returns in
                | relation the relations of the RootAnalysis from the AnalysisDocument
                | document:  Dim AnalysisDocument As Document Set AnalysisDocument =
                | CATIA.ActiveDocument Dim RootAnalysis As AnalysisManager Set
                | RootAnalysis = AnalysisDocument.Analysis Dim relation As
                | CATIARelations Set relation = RootAnalysis.Relations


                | Parameters:


        """
        return self.analysismanager.Relations

    def create_reference_from_geometry(self, i_product, i_geometry):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateReferenceFromGeometry
                | o Func CreateReferenceFromGeometry(    Product    iProduct,
                |                                        Reference    iGeometry) As Reference
                | 
                | Creates a reference from a geometry.  This geometry must in defined in
                | a document rerecened in the CATIAAnalysisLinkedDocuments collection.


                | Parameters:
                | iProduct
                |  The product of the geometry to be referenced that defines the instance of the geometry. 
                |  iGeometry
                |  The geometry to be referenced. As a reference, it can be an CATIABoundary object of a mechanical feature. 
                | 
                |  Returns:
                |   a reference of the couple (iProduct, iGeometry).


        """
        return self.analysismanager.CreateReferenceFromGeometry(i_product, i_geometry)

    def create_reference_from_object(self, i_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateReferenceFromObject
                | o Func CreateReferenceFromObject(    AnyObject    iObject) As Reference
                | 
                | Creates a reference from an analysis object. Use of reference allows a
                | uniform handling of anay objects.


                | Parameters:
                | iObject
                |    The analysis object to be referenced.
                |    It can be an AnalysisEntity or an AnalysisSet
                | 
                | 
                |  Returns:
                |   The reference to the object.


        """
        return self.analysismanager.CreateReferenceFromObject(i_object)

    def import(self, i_document_to_import):
        """
        .. note::
            CAA V5 Visual Basic help

                | Import
                | o Sub Import(    Document    iDocumentToImport)
                | 
                | Import an existing document in an analysis document . This document
                | can of any type that implement the CATIADocument interface. This is
                | implemented for internal document formats. (like Part or Product
                | documents).  Example:The following example imports an opened CATPart
                | document   Dim AnalysisDocument As Document Dim PartDocument As
                | Document Set AnalysisDocument = CATIA.ActiveDocument Dim RootAnalysis
                | As AnalysisManager Set RootAnalysis = AnalysisDocument.Analysis
                | RootAnalysis.Import(PartDocument)


                | Parameters:


        """
        return self.analysismanager.Import(i_document_to_import)

    def import_define_file(self, i_document_path, i_type_late, i_values):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImportDefineFile
                | o Sub ImportDefineFile(    CATBSTR    iDocumentPath,
                |                            CATBSTR    iTypeLate,
                |                            CATSafeArrayVariant    iValues)
                | 
                | Import an existing document in an analysis document. This document can
                | of any type that is managed by the CATISamImportDefine interface.
                | Example:The following example imports an CATPart document stored as
                | FileToOpen file. This example is also use the CATAnalysisImport
                | Object. This object allow to import Part, Product or Analysis
                | documents. As of today no parameters are mandatory for this object.
                | Dim arrayOfVariant(0) FileToOpen =
                | "e:\users\Parts\ThisIsANicePart.CATPart" ObjectForImport =
                | "CATAnalysisImport" Dim AnalysisDocument As Document Set
                | AnalysisDocument = CATIA.ActiveDocument Dim RootAnalysis As
                | AnalysisManager Set RootAnalysis = AnalysisDocument.Analysis RootAnaly
                | sis.ImportDefineFile(FileToOpen,CATAnalysisImport,arrayOfVariant)


                | Parameters:


        """
        return self.analysismanager.ImportDefineFile(i_document_path, i_type_late, i_values)

    def import_file(self, i_document_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImportFile
                | o Sub ImportFile(    CATBSTR    iDocumentPath)
                | 
                | Import an existing document in an analysis document.  Deprecated:
                | V5R15 use ImportDefineFile instead. This document can of any type that
                | implement the CATISamImportDefine interface.  Example:The following
                | example imports an CATPart document stored as FileToOpen file.
                | FileToOpen = "e:\users\Parts\ThisIsANicePart.CATPart" Dim
                | AnalysisDocument As Document Set AnalysisDocument =
                | CATIA.ActiveDocument Dim RootAnalysis As AnalysisManager Set
                | RootAnalysis = AnalysisDocument.Analysis
                | RootAnalysis.ImportFile(FileToOpen)


                | Parameters:


        """
        return self.analysismanager.ImportFile(i_document_path)

