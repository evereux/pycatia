#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisImport:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAAnalysisExport

    """

    def __init__(self, catia):
        self.analysisimport = catia.AnalysisImport     

    def add_support(self, i_manager, i_product_support, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupport
                | o Sub AddSupport(    AnalysisManager    iManager,
                |                      Product    iProductSupport,
                |                      AnyObject    iSupport)
                | 
                | AddSupport for loads import if needed.)


                | Parameters:
                | iManager
                |           The Analysis manager.) 
                |  iProductSupport
                |    Product of the geometrical support.) 
                |  iSupports
                |          Geometrical support.)


        """
        return self.analysisimport.AddSupport(i_manager, i_product_support, i_support)

    def import_disp(self, i_father_case, i_full_path, i_manager, i_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImportDisp
                | o Sub ImportDisp(    AnalysisCase    iFatherCase,
                |                      CATBSTR    iFullPath,
                |                      AnalysisManager    iManager,
                |                      AnyObject    iAxis)
                | 
                | Import displacements from a CATAnalysisExport file.)


                | Parameters:
                | iFatherCase
                |    case where Displacements will be exported.) 
                |  iFullPath
                |      The full path of the file.) 
                |  iManager
                |       analysis manager where the disp is exported.) 
                |  iAxis
                |          The user axis system to be taken into account.)


        """
        return self.analysisimport.ImportDisp(i_father_case, i_full_path, i_manager, i_axis)

    def import_force(self, i_father_case, i_full_path, i_manager, i_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImportForce
                | o Sub ImportForce(    AnalysisCase    iFatherCase,
                |                       CATBSTR    iFullPath,
                |                       AnalysisManager    iManager,
                |                       AnyObject    iAxis)
                | 
                | Import loads from a CATAnalysisExport file.)


                | Parameters:
                | iFatherCase
                |    case where loads will be exported.) 
                |  iFullPath
                |      The full path of the file.) 
                |  iManager
                |       analysis manager where the disp is exported.) 
                |  iAxis
                |          The user axis system to be taken into account.)


        """
        return self.analysisimport.ImportForce(i_father_case, i_full_path, i_manager, i_axis)

