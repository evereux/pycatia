#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisMeshLocalSpecification:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAAnalysisMeshLocalSpecification.

    """

    def __init__(self, catia):
        self.analysismeshlocalspecification = catia.AnalysisMeshLocalSpecification     

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the type of the local specification.  Returns:  The string
                | that represent the type of local specification.


                | Parameters:


        """
        return self.analysismeshlocalspecification.Type

    def add_support_from_publication(self, i_name, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(    CATBSTR    iName,
                |                                     Product    iProduct,
                |                                     Publication    iSupport)
                | 
                | Defines the support of the local specification.


                | Parameters:
                | iName
                |   The identifier of the attribute. 
                |  iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iPublication
                |   the CATIA Publication that represent the geometry. 
                | 
                |  See also:
                |   activateLinkAnchor('Publication','','Publication') ,  activateLinkAnchor('Product','','Product')


        """
        return self.analysismeshlocalspecification.AddSupportFromPublication(i_name, i_product, i_support)

    def add_support_from_reference(self, i_name, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(    CATBSTR    iName,
                |                                   Product    iProduct,
                |                                   Reference    iSupport)
                | 
                | Defines the support of the local specification.


                | Parameters:
                | iName
                |   The identifier of the attribute. 
                |  iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iSupport
                |   the CATIA Reference that represent the geometry. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference') ,  activateLinkAnchor('Product','','Product')


        """
        return self.analysismeshlocalspecification.AddSupportFromReference(i_name, i_product, i_support)

    def set_attribute(self, i_name, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAttribute
                | o Sub SetAttribute(    CATBSTR    iName,
                |                        CATVariant    iValue)
                | 
                | Sets the value corresponding to the given local specification.


                | Parameters:
                | iName
                |   The identifier of the attribute. 
                |  iValue
                |   The value of the local specification.


        """
        return self.analysismeshlocalspecification.SetAttribute(i_name, i_value)

