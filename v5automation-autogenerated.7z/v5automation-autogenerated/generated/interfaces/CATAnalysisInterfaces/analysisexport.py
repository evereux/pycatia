#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisExport:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAAnalysisExport

    """

    def __init__(self, catia):
        self.analysisexport = catia.AnalysisExport     

    def export(self, i_full_path, i_type, i_occurrences, i_manager):
        """
        .. note::
            CAA V5 Visual Basic help

                | Export
                | o Sub Export(    CATBSTR    iFullPath,
                |                  CATBSTR    iType,
                |                  CATSafeArrayVariant    iOccurrences,
                |                  AnalysisManager    iManager)
                | 
                | Export computed loads/displacements as a CATAnalysisExport file.


                | Parameters:
                | iFullPath
                |      The full path of the file.                      (


                | Examples:
                | E:\tmp\ExportedLoads/CATAnalysisExport).
                | 
                | iType
                | The type of data to be exported: "ComputedLoads" or "Displacements".
                | iOccurrences
                | The list of occurrences to be exported.
                | 
                | iManager
                | The analysis model for which the data will be exported.                      (Only revelant for assembly of analysis.)
                | 
                | 
                | 
        """
        return self.analysisexport.Export(i_full_path, i_type, i_occurrences, i_manager)

