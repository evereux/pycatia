#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisCases:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of analysis case making an Analysis.

    """

    def __init__(self, catia):
        self.analysiscases = catia.AnalysisCases     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As AnalysisCase
                | 
                | Creates a new case and adds it to the case collection. This case will
                | be plugged under the analysis model.  Returns:  The created case
                | Example: The following example creates a case NewCase  in the case
                | collection of the ModelAnalysis Analysis model .  Dim ModelAnalysis As
                | AnalysisModel Dim NewCase As AnalysisCase Set NewCase =
                | ModelAnalysis.AnalysisCases.Add()


                | Parameters:


        """
        return self.analysiscases.Add()

    def add_existing_case(self, i_case):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddExistingCase
                | o Sub AddExistingCase(    AnalysisCase    iCase)
                | 
                | Adds an existing analysis case to the analysis cases collection.


                | Parameters:
                | iCase
                |  The Existing Analysis Case.


                | Examples:
                | 
                | 
                | This example adds ThisAnalysisCase in the analysisCases analysis cases collection.
                | 
                | Dim ThisAnalysisCase As AnalysisCase
                | Dim analysisCases As AnalysisCases
                | ...
                | analysisCases.AddExistingCase(ThisAnalysisCase)
                | 
                | 
                | 
                | 
        """
        return self.analysiscases.AddExistingCase(i_case)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As AnalysisCase
                | 
                | Returns a case using its index or its name from the case collection.


                | Parameters:
                | iIndex
                |    The index or the name of the case to retrieve from
                |    the collection of cases.
                |    As a numeric, this index is the rank of the case
                |    in the collection. The index of the first case in the collection is 1,
                |    and the index of the last case is Count.
                |    As a string, it is the name you assigned to the case using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved case.


                | Examples:
                | 
                | 
                | This example retrieves in  ThisCase the fifth case
                | in the collection and in  ThatCase the case
                | named "MyCase in the case collection of the AnalysisModel Analysis model.
                | 
                | Set CaseColl = AnalysisModel.AnalysisCases
                | Set ThisCase = CaseColl.Item(5)
                | Set ThatCase = CaseColl.Item("MyCase")
                | 
                | 
                | 
        """
        return self.analysiscases.Item(i_index)

    def new_case(self, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | NewCase
                | o Func NewCase(    CATBSTR    iType) As AnalysisCase
                | 
                | Creates a new case and adds it to the case collection. This case will
                | be plugged under the analysis model.  Returns:  The created case
                | Example: The following example creates a case NewCase  in the case
                | collection of the ModelAnalysis Analysis model .  Dim ModelAnalysis As
                | AnalysisModel Dim NewCase As AnalysisCase Set NewCase =
                | ModelAnalysis.AnalysisCases.NewCase("AnalysisPreproCase")()


                | Parameters:


        """
        return self.analysiscases.NewCase(i_type)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes a case using its index or its name from the case collection.


                | Parameters:
                | iIndex
                |    The index or the name of the case to retrieve from
                |    the collection of cases.
                |    As a numeric, this index is the rank of the case
                |    in the collection. The index of the first case in the collection is 1,
                |    and the index of the last case is Count.
                |    As a string, it is the name you assigned to the case using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


                | Examples:
                | 
                | 
                | This example removes the fifth case in the collection.
                | 
                | AnalysisModel.AnalysisCases.Remove (5)
                | 
                | 
                | 
        """
        return self.analysiscases.Remove(i_index)

