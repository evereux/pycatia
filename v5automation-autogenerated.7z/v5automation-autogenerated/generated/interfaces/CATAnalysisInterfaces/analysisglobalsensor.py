#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisGlobalSensor:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the  analysis global sensor.This object is a kind of
                | AnalysisSensor based on analysis feature global results. For example,
                | extract the Energy value of a solution.

    """

    def __init__(self, catia):
        self.analysisglobalsensor = catia.AnalysisGlobalSensor     

    def get_identifier(self, o_type_bstr, o_sub_type_bstr):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdentifier
                | o Sub GetIdentifier(    CATBSTR    oTypeBSTR,
                |                         CATBSTR    oSubTypeBSTR)
                | 
                | Retreives the Physical type  and sub physical type that will be
                | computed by the sensor.


                | Parameters:
                | oTypeBSTR
                |  The physical type identifier. 
                |  oSubTypeBSTR
                |  The "sub" physical type identifier.


        """
        return self.analysisglobalsensor.GetIdentifier(o_type_bstr, o_sub_type_bstr)

    def set_identifier(self, i_type_bstr, i_sub_type_bstr):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdentifier
                | o Sub SetIdentifier(    CATBSTR    iTypeBSTR,
                |                         CATBSTR    iSubTypeBSTR)
                | 
                | Sets the Physical type  and sub physical type that will be computed by
                | the sensor.


                | Parameters:
                | iTypeBSTR
                |  The physical type identifier. 
                |  iSubTypeBSTR
                |  The "sub" physical type identifier.


        """
        return self.analysisglobalsensor.SetIdentifier(i_type_bstr, i_sub_type_bstr)

