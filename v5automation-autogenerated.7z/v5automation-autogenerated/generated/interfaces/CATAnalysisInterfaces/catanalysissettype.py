#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATAnalysisSetType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Update type for analysis sets.Role:CATAnalysisSetType defines the
                | Category for Set behavior  for update.

    """

    def __init__(self, catia):
        self.catanalysissettype = catia.CATAnalysisSetType     

