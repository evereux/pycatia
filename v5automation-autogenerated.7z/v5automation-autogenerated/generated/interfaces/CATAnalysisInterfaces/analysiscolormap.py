#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisColorMap:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Color Map Object of the post-processing Image Object.

    """

    def __init__(self, catia):
        self.analysiscolormap = catia.AnalysisColorMap     

    @property
    def discrete_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DiscreteMode
                | o Property DiscreteMode(    ) As CATVariant
                | 
                | Gets the Discrete mode for the Color Map


                | Parameters:
                | oDiscreteMode
                |  Output Boolean for the Discrete Mode
                | 
                |  True	: indicates that Discrete mode is enabled for the color map.
                |  False: indicates that Discrete mode is disabled for the color map.
                | 
                |  This Method Returns E_FAIL if the Parent Image is not uptodate.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object oDiscreteMode = analysisColorMap.DiscreteMode
                | In this example, oDiscreteMode is the output Discrete Mode for analysisColorMap.
                | 
                | 
        """
        return self.analysiscolormap.DiscreteMode

    @property
    def distribution_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DistributionMode
                | o Property DistributionMode(    ) As SPMDistributionMode
                | 
                | Gets the Distribution Mode for the Color Map


                | Parameters:
                | oDistMode
                |  Returns the Distribution Mode (ColorMap type)
                |  SPM_LINEAR		: For Linear Distribution Mode
                |  SPM_HISTOGRAM	: For Histogram Distribution Mode
                |  SPM_LOG			: For Logarithmic Distribution Mode
                | 
                |  This Method Returns E_FAIL if the Parent Image is not uptodate.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object oDistMode = analysisColorMap.DistributionMode
                | In this example, oDistMode is the output distribution mode for analysisColorMap.
                | 
                | 
        """
        return self.analysiscolormap.DistributionMode

    @property
    def imposed_max_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImposedMaxValue
                | o Property ImposedMaxValue(    ) As double
                | 
                | Gets the Imposed Maximum value for the Color Map


                | Parameters:
                | oMaxValue
                |  Returns Imposed Maximum value
                |  Returned value will be in CATIA Units.
                | 
                |  This Method Returns E_FAIL if the Parent Image is not uptodate.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object oMaxValue = analysisColorMap.ImposedMaxValue
                | In this example, oMaxValue is the output Imposed Maximum value for analysisColorMap.
                | 
                | 
        """
        return self.analysiscolormap.ImposedMaxValue

    @property
    def imposed_min_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImposedMinValue
                | o Property ImposedMinValue(    ) As double
                | 
                | Gets the Imposed Minimum value for the Color Map


                | Parameters:
                | oMinValue
                |  Returns imposed minimum value
                |  Returned value will be in CATIA Units.
                | 
                |  This Method Returns E_FAIL if the Parent Image is not uptodate.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object oMinValue = analysisColorMap.ImposedMinValue
                | In this example, oMinValue is the output Imposed Minimum value for analysisColorMap.
                | 
                | 
        """
        return self.analysiscolormap.ImposedMinValue

    @property
    def inverse_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InverseMode
                | o Property InverseMode(    ) As CATVariant
                | 
                | Gets the Inverse mode for the Color Map


                | Parameters:
                | oInverseMode
                |  Output Boolean for the Inverse Mode
                | 
                |  True	: indicates that Inverse mode is enabled for the color map.
                |  False: indicates that Inverse mode is disabled for the color map.
                | 
                |  This Method Returns E_FAIL if the Parent Image is not uptodate.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object oInverseMode = analysisColorMap.InverseMode
                | In this example, oInverseMode is the output Inverse Mode for analysisColorMap.
                | 
                | 
        """
        return self.analysiscolormap.InverseMode

    @property
    def nb_colors(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NbColors
                | o Property NbColors(    ) As long
                | 
                | Gets the Number of colors for the Color Map


                | Parameters:
                | oNbColors
                |  returns number of colors as output from the color map.
                | 
                |  This Method Returns E_FAIL if the Parent Image is not uptodate.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object oNbColors = analysisColorMap.NbColors
                | In this example, oNbColors is the output Number of colors for analysisColorMap.
                | 
                | 
        """
        return self.analysiscolormap.NbColors

    @property
    def smooth_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SmoothMode
                | o Property SmoothMode(    ) As CATVariant
                | 
                | Gets the Smooth mode for the Color Map


                | Parameters:
                | oSmoothMode
                |  Output Boolean for the Smooth Mode
                | 
                |  True	: indicates that Smooth mode is enabled for the color map.
                |  False: indicates that Smooth mode is disabled for the color map.
                | 
                |  This Method Returns E_FAIL if the Parent Image is not uptodate.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object oSmoothMode = analysisColorMap.SmoothMode
                | In this example, oSmoothMode is the output Smooth Mode for analysisColorMap.
                | 
                | 
        """
        return self.analysiscolormap.SmoothMode

    def get_distribution_value(self, index_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDistributionValue
                | o Func GetDistributionValue(    long    indexValue) As double
                | 
                | Gets the Value for the Distribution of Color Map


                | Parameters:
                | indexValue
                |  The index whose Value we get.
                |  This integer should be greater than 0 and less than NbColors.
                |  Else Method Fails.
                | 
                |  
                |  oModeValue
                |  Returns the value @param indexValue
                |  Returned value will be in CATIA Units.
                | 
                |  This Method Returns E_FAIL if the Parent Image is not uptodate.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object Set oModeValue = analysisColorMap.GetDistributionValue (3)
                | In this example, oModeValue is the output value of the Distribution list at Index 3.
                | 
                | 
        """
        return self.analysiscolormap.GetDistributionValue(index_value)

    def set_distribution_value(self, index_value, i_mode_value, i_smoothening_flag):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDistributionValue
                | o Sub SetDistributionValue(    long    indexValue,
                |                                double    iModeValue,
                |                                CATVariant    iSmootheningFlag)
                | 
                | Sets the Value for the Distribution of Color Map


                | Parameters:
                | indexValue
                |  The index whose Value will be set.
                |  This integer should be greater than 0 and less than NbColors.
                |  Else Method Fails.
                | 
                |  
                |  iModeValue
                |  The Value to be set.
                |  This value should be in between Computed/Imposed Min/Max values. Else Method Fails.
                |  In addition if @param iSmootheningFlag is False, this value should be in between the immediate lower and upper values.
                |  Else Method Fails.
                |  Value has to be provided in CATIA Units.
                | 
                |  
                |  iSmootheningFlag
                |  if True: Does either upper or lower smoothening of values.
                |  if False: Does not smoothen values. But sets only the given index value.
                | 
                |  This Method Returns E_FAIL if Color Map is Discrete.


                | Examples:
                | 
                | : analysisColorMap is the ColorMap Object  Example 1:
                | 
                | Call analysisColorMap.SetDistributionValue(3, 3e+09, True)
                | 
                | This sets the value 3e+09 at 3rd Index of the list. It will smoothen the distribution values
                | for the color-map object analysisColorMap.
                | Should be in between Computed/Imposed Min/Max values.
                | 
                | Example 2:
                | 
                | Call analysisColorMap.SetDistributionValue(3, 10e+09, False)
                | 
                | This sets the value 10e+09 at 3rd Index of the list. It will not smoothen the distribution
                | for the color-map object analysisColorMap.
                | 10e+09 should be greater than Index 2 value and lesser than Index 4 value.
                | Should be in between Computed/Imposed Min/Max values.
                | 
                | 
        """
        return self.analysiscolormap.SetDistributionValue(index_value, i_mode_value, i_smoothening_flag)

    def update(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Update
                | o Sub Update(    )
                | 
                | Updates the visualization of the color map. This method should be
                | called after one or all previous PUT methods are called on Color Map.


                | Parameters:


        """
        return self.analysiscolormap.Update()

