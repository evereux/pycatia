#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisModels:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of analysis models making an analysis document.As of
                | today this collection is made of a single analysis model.

    """

    def __init__(self, catia):
        self.analysismodels = catia.AnalysisModels     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As AnalysisModel
                | 
                | Returns an analysis model using its index or its name from the
                | analysis model collection.


                | Parameters:
                | iIndex
                |    The index or the name of the analysis model to retrieve from
                |    the collection of analysis model.
                |    As a numerics, this index is the rank of the analysis model
                |    in the collection.
                |    The index of the first analysis model in the collection is 1, and
                |    the index of the last analysis model is Count.
                |    As a string, it is the name you assigned to the analysis model using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved analysis model


                | Examples:
                | 
                | 
                | The following example retrieves the first analysis model in
                | the analysis model collection of the  AnalysisManager object.
                | 
                | Dim AnalysisDocument As Document
                | Set AnalysisDocument = CATIA.ActiveDocument
                | Dim RootAnalysis As AnalysisManager
                | Set RootAnalysis = AnalysisDocument.Analysis
                | Dim analysisModels As AnalysisModels
                | Set analysisModels = RootAnalysis.AnalysisModels
                | Dim analysisModel As AnalysisModel
                | Set AnalysisModel = analysisModel.Item(1)
                | 
                | 
                | 
        """
        return self.analysismodels.Item(i_index)

