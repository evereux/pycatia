#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisCase:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the analysis case object.Role:Interface designed to
                | manageAnalysis Case behavior.In the Analysis document, anAnalysis
                | Caseis the object   dedicated to define and manage the environment
                | data necessary to run  a computation. This environment is made of
                | sets.

    """

    def __init__(self, catia):
        self.analysiscase = catia.AnalysisCase     

    @property
    def analysis_sets(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisSets
                | o Property AnalysisSets(    ) As AnalysisSets
                | 
                | Returns the analysis sets collection associated to the analysis case.
                | Returns:  The collection of analysis sets.  Example: The following
                | example retrieves the analysis sets collection  ListSets Dim MyCase As
                | AnalysisCase Dim ListSets As AnalysisSets Set ListSets =
                | MyCase.AnalysisSets


                | Parameters:


        """
        return self.analysiscase.AnalysisSets

    def add_solution(self, i_solution_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSolution
                | o Func AddSolution(    CATBSTR    iSolutionType) As AnalysisSet
                | 
                | Creates a Solution set defined by its type in the Case.


                | Parameters:
                | iSolutionType
                |  The feature type of the solution set.  This is a user defined type corresponding to the kind of computation.
                |  For example "StaticSet"
                |  
                | 
                |  Returns:
                |   oSolution The analysis set created.


                | Examples:
                | 
                | 
                | The following example create a solution set   ListSets
                | 
                | Dim MyCase As AnalysisCase
                | Dim Newsol As AnalysisSet
                | Set Newsol = MyCase.AddSolution("StaticSet")
                | 
                | 
                | 
        """
        return self.analysiscase.AddSolution(i_solution_type)

    def compute(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Compute
                | o Sub Compute(    )
                | 
                | Launch the computation (Update) of an analysis case. This step
                | corresponds to the "Case Solution" option of the interactive command.
                | Example: The following example launches the update of  MyCase Dim
                | MyCase As AnalysisCase MyCase.Compute


                | Parameters:


        """
        return self.analysiscase.Compute()

    def compute_mesh_only(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ComputeMeshOnly
                | o Sub ComputeMeshOnly(    )
                | 
                | Launch the computation (Update) of an analysis case. This method
                | corresponds to the "Mesh Only" option of the interactive command.
                | Example: The following example launches the update of  MyCase Dim
                | MyCase As AnalysisCase MyCase.ComputeMeshOnly


                | Parameters:


        """
        return self.analysiscase.ComputeMeshOnly()

