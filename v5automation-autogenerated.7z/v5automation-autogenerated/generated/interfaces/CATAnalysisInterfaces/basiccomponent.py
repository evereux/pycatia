#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class BasicComponent:
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, catia):
        self.basiccomponent = catia.BasicComponent     

    @property
    def analysis_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisSupports
                | o Property AnalysisSupports(    ) As AnalysisSupports
                | 
                | Returns the list of Analysis Supports. The support defines the area on
                | which the analysis is applied on.


                | Parameters:


        """
        return self.basiccomponent.AnalysisSupports

    @property
    def basic_components(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BasicComponents
                | o Property BasicComponents(    ) As BasicComponents
                | 
                | Returns the collection of Basic Components agregated by the basic
                | component.  It can be (scalar value, vector, tensor,...). Depending on
                | the type of the Basic component, the collection can be empty.
                | Example:    This example retrieves Basic components collection   Dim
                | MyBasicComp As BasicComponent Dim myBasicComponents As BasicComponents
                | Set myBasicComponents = MyBasicComp.BasicComponents


                | Parameters:


        """
        return self.basiccomponent.BasicComponents

    @property
    def entities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Entities
                | o Property Entities(    ) As AnalysisEntities
                | 
                | Returns the collection of Entities agregated by the basic component.
                | Depending on the type of the Basic component,the collection can be
                | empty.  Example:    This example retrieves Basic components collection
                | Dim MyBasicComp As BasicComponent Dim myEntities AnalysisEntities Set
                | myEntities = MyBasicComp.AnalysisEntities


                | Parameters:


        """
        return self.basiccomponent.Entities

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the type of the Basic Component.  Returns:  The string that
                | represent the Basic Component type.


                | Parameters:


        """
        return self.basiccomponent.Type

    def add_support_from_product(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromProduct
                | o Sub AddSupportFromProduct(    Product    iProduct,
                |                                 Reference    iSupport)
                | 
                | Creates a new support and add it to the description of the basic
                | component.


                | Parameters:
                | iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iSupport
                |   the CATIA Reference that represent the object to linked. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference') ,  activateLinkAnchor('Product','','Product')


        """
        return self.basiccomponent.AddSupportFromProduct(i_product, i_support)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(    Product    iProduct,
                |                                     Publication    iPublication)
                | 
                | Creates a new support and add it to the description of the Basic
                | Component.


                | Parameters:
                | iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iPublication
                |   the CATIA Publication that represent the object to linked. 
                | 
                |  See also:
                |   activateLinkAnchor('Publication','','Publication') ,  activateLinkAnchor('Product','','Product')


        """
        return self.basiccomponent.AddSupportFromPublication(i_product, i_publication)

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(    Reference    iReference,
                |                                   Reference    iSupport)
                | 
                | Creates a new support and add it to the description of the basic
                | component.


                | Parameters:
                | iReference
                |  the CATIA Reference that represent the object to linked. 
                |  iSupport
                |   the CATIA Reference that represent the object to linked. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference') ,  activateLinkAnchor('Product','','Product')


        """
        return self.basiccomponent.AddSupportFromReference(i_reference, i_support)

    def get_columns_number(self, i_label):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetColumnsNumber
                | o Func GetColumnsNumber(    CATBSTR    iLabel) As long
                | 
                | Return one of the dimensions information of the Basic Component
                | structure.


                | Parameters:
                | oColumnsNumber
                |  = Number of Columns.


        """
        return self.basiccomponent.GetColumnsNumber(i_label)

    def get_layers_number(self, i_label):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLayersNumber
                | o Func GetLayersNumber(    CATBSTR    iLabel) As long
                | 
                | Return one of the dimensions information of the Basic Component
                | structure.


                | Parameters:
                | oLayersNumber
                |  = Number of Layers.


        """
        return self.basiccomponent.GetLayersNumber(i_label)

    def get_lines_number(self, i_label):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLinesNumber
                | o Func GetLinesNumber(    CATBSTR    iLabel) As long
                | 
                | Return one of the dimensions information of the Basic Component
                | structure.


                | Parameters:
                | oLinesNumber
                |  = Number of lines.


        """
        return self.basiccomponent.GetLinesNumber(i_label)

    def get_value(self, i_label, i_line_index, i_column_index, i_layer_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetValue
                | o Func GetValue(    CATBSTR    iLabel,
                |                     long    iLineIndex,
                |                     long    iColumnIndex,
                |                     long    iLayerIndex) As CATVariant
                | 
                | Return the value corresponding to the given coordinates.


                | Parameters:
                | iLabel
                |  = Label of the block containing the value. 
                |  iLineIndex
                |  = line index of the value. 
                |  iColumnIndex
                |  = column index of the value. 
                |  iLayerIndex
                |  = layer index of the value. If the the component has a single value, set these 3 parameters
                |  to 0.


        """
        return self.basiccomponent.GetValue(i_label, i_line_index, i_column_index, i_layer_index)

    def set_dimensions(self, i_line_count, i_column_count, i_layer_count):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimensions
                | o Sub SetDimensions(    long    iLineCount,
                |                         long    iColumnCount,
                |                         long    iLayerCount)
                | 
                | Sets the dimensions of the basic component.


                | Parameters:
                | iLineCount
                |   Number of lines. 
                |  iColumnCount
                |   Number of columns. 
                |  iLayerCount
                |   Number of layers.


        """
        return self.basiccomponent.SetDimensions(i_line_count, i_column_count, i_layer_count)

    def set_reference(self, i_label, i_line_index, i_column_index, i_layer_index, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetReference
                | o Sub SetReference(    CATBSTR    iLabel,
                |                        long    iLineIndex,
                |                        long    iColumnIndex,
                |                        long    iLayerIndex,
                |                        Reference    iValue)
                | 
                | Sets the reference corresponding to the given component.


                | Parameters:
                | iLabel
                |   The label of the block containing the value. 
                |  iLineIndex
                |   The line index of the value. 
                |  iColumnIndex
                |   The column index of the value. 
                |  iLayerIndex
                |   The layer index of the value. If the the component has a single value, assign 0 to the 3 parameters.


        """
        return self.basiccomponent.SetReference(i_label, i_line_index, i_column_index, i_layer_index, i_value)

    def set_value(self, i_label, i_line_index, i_column_index, i_layer_index, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetValue
                | o Sub SetValue(    CATBSTR    iLabel,
                |                    long    iLineIndex,
                |                    long    iColumnIndex,
                |                    long    iLayerIndex,
                |                    CATVariant    iValue)
                | 
                | Set the value corresponding to the given coordinates.


                | Parameters:
                | iLabel
                |  = Label of the block containing the value. 
                |  iLineIndex
                |  = line index of the value. 
                |  iColumnIndex
                |  = column index of the value. 
                |  iLayerIndex
                |  = layer index of the value. If the the component has a single value, set these 3 parameters
                |  to 0.


        """
        return self.basiccomponent.SetValue(i_label, i_line_index, i_column_index, i_layer_index, i_value)

