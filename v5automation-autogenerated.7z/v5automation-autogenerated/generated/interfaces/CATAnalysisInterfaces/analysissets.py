#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisSets:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of analysis sets.

    """

    def __init__(self, catia):
        self.analysissets = catia.AnalysisSets     

    def add(self, i_type, i_set_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    CATBSTR    iType,
                |                CATAnalysisSetType    iSetType) As AnalysisSet
                | 
                | Creates a new analysis set and adds it to the analysis sets
                | collection. The analysis set will be aggregated on the Analysis Model


                | Parameters:
                | iType
                |  The type of the set to create.
                |  
                |  iSetType
                |  The category of the set for update.
                |  
                | 
                |  Returns:
                |   The created Analysis Set


                | Examples:
                | 
                | This example create ThisAnalysisSet in the analysisSetsanalysis
                | sets collection. The set to create is supposed to be a load set defined as an input of
                | the case for the update.
                | 
                | Dim ThisAnalysisSet As AnalysisSet
                | Set ThisAnalysisSet = analysisSets.Add("LoadSet", 0)
                | 
                | 
                | 
        """
        return self.analysissets.Add(i_type, i_set_type)

    def add_existing_set(self, i_set, i_set_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddExistingSet
                | o Sub AddExistingSet(    AnalysisSet    iSet,
                |                          CATAnalysisSetType    iSetType)
                | 
                | Adds an existing analysis set to the analysis sets collection.


                | Parameters:
                | iSet
                |  The Existing Analysis Set.
                |  
                |  iSetType
                |  The category of the set for update.


                | Examples:
                | 
                | This example adds ThisAnalysisSet in the analysisSetsanalysis
                | sets collection. The set to add is supposed to be a restrain set defined as an input of
                | the case for the update.
                | 
                | Dim ThisAnalysisSet As AnalysisSet
                | ...
                | analysisSets.AddExistingSet(ThisAnalysisSet, 0)
                | 
                | 
                | 
        """
        return self.analysissets.AddExistingSet(i_set, i_set_type)

    def item(self, i_index, i_serach_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex,
                |                 CATAnalysisSetSearchType    iSerachType) As AnalysisSet
                | 
                | Returns an analysis set using its index or its name from the analysis
                | sets collection.


                | Parameters:
                | iIndex
                |    The index or the name of the analysis set to retrieve from
                |    the collection of analysis sets.
                |    As a numerics, this index is the rank of the analysis set
                |    in the collection.
                |    The index of the first analysis set in the collection is 1, and
                |    the index of the last analysis set is Count.
                |    As a string, it is the name you assigned to the analysis set using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property or when creating it using   the 
                |  activateLinkAnchor('','Add','Add')  method. 
                |      iSerachType
                |    The criterion of searching the set. 
                |  activateLinkAnchor('CATAnalysisSetType','CATAnalysisSetSearchType','CATAnalysisSetType.CATAnalysisSetSearchType') 
                |  Returns:
                |   The retrieved analysis set


                | Examples:
                | 
                | This example retrieves in ThisAnalysisSet the third analysis set,
                | and in ThatAnalysisSet the analysis set named
                | MySet in the analysis set collection of an Analysis Case of analysis model.
                | 
                | Dim ThisAnalysisSet As AnalysisSet
                | Set ThisAnalysisSet = analysisCase.AnalysisSets.Item(3,1)
                | Dim ThatAnalysisSet As AnalysisSet
                | Set ThatAnalysisSet = analysisCase.AnalysisSets.Item("MySet")
                | 
                | 
                | 
        """
        return self.analysissets.Item(i_index, i_serach_type)

    def item_by_type(self, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | ItemByType
                | o Func ItemByType(    CATBSTR    iType) As AnalysisSet
                | 
                | Returns an analysis set using its type from the analysis sets
                | collection.


                | Parameters:
                | iType
                |    The type of the set required for the search
                |  
                | 
                |  Returns:
                |   The retrieved analysis set


                | Examples:
                | 
                | This example retrieves in ThisAnalysisSet the "LoadSet" analysis set
                | in the analysis set collection.
                | 
                | Dim ThisAnalysisSet As AnalysisSet
                | Set ThisAnalysisSet = analysisCase.AnalysisSets.ItemByType("LoadSet")
                | 
                | 
                | 
        """
        return self.analysissets.ItemByType(i_type)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes a set using its index or its name from the set collection.


                | Parameters:
                | iIndex
                |    The index or the name of the set to retrieve from
                |    the collection of sets.
                |    As a numeric, this index is the rank of the set
                |    in the collection. The index of the first set in the collection is 1,
                |    and the index of the last set is Count.
                |    As a string, it is the name you assigned to the set using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


        """
        return self.analysissets.Remove(i_index)

