#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATAnalysisSetSearchType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Search type for analysis sets.Role:CATAnalysisSetSearchType defines
                | the criterion for searching sets.

    """

    def __init__(self, catia):
        self.catanalysissetsearchtype = catia.CATAnalysisSetSearchType     

