#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisPostManager:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to define the Post Processing Manager.Role: In the analysis
                | document, an Post Processing is dedicated to Visualization and
                | reporting.

    """

    def __init__(self, catia):
        self.analysispostmanager = catia.AnalysisPostManager     

    def add_existing_case_for_report(self, i_case):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddExistingCaseForReport
                | o Sub AddExistingCaseForReport(    AnalysisCase    iCase)
                | 
                | Adds an existing analysis case to manager. To declare Case which will
                | be taken into account for the HTML report.


                | Parameters:
                | iCase
                |  The Existing Analysis Case.


        """
        return self.analysispostmanager.AddExistingCaseForReport(i_case)

    def build_report(self, i_folder, i_title, i_add_created_images):
        """
        .. note::
            CAA V5 Visual Basic help

                | BuildReport
                | o Sub BuildReport(    Folder    iFolder,
                |                       CATBSTR    iTitle,
                |                       CATVariant    iAddCreatedImages)
                | 
                | Extract the HTML Report. The Report is defined related to Analysis
                | cases, using AddExistingCaseForReport  and will be stored in a CATIA
                | Folder.


                | Parameters:
                | iFolder
                |   Folder to store the HTML file. 
                |  iTitle
                |    Title of the report. 
                |  iAddCreatedImages
                |  To add created images under analysis case in the report.


        """
        return self.analysispostmanager.BuildReport(i_folder, i_title, i_add_created_images)

    def extract_html_report(self, i_folder, i_title):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExtractHTMLReport
                | o Sub ExtractHTMLReport(    Folder    iFolder,
                |                             CATBSTR    iTitle)
                | 
                | Deprecated:  V5R14 use BuildReport instead. Extract the HTML Report.
                | The Report is defined related to Analysis cases, using
                | AddExistingCaseForReport  and will be stored in a CATIA Folder.


                | Parameters:
                | iFolder
                |   Folder to store the HTML file. 
                |  iTitle
                |    Title of the report.


        """
        return self.analysispostmanager.ExtractHTMLReport(i_folder, i_title)

