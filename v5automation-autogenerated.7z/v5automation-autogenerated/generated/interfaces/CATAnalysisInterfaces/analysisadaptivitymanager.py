#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisAdaptivityManager:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAAnalysisAdaptivityManager.

    """

    def __init__(self, catia):
        self.analysisadaptivitymanager = catia.AnalysisAdaptivityManager     

    def run(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Run
                | o Sub Run(    )
                | 
                | Run the adaptivity process.


                | Parameters:


        """
        return self.analysisadaptivitymanager.Run()

