#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisSet:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the analysis set object.In the Analysis Model, anAnalysis
                | Setis the data  dedicated to manage theAnalysis Entitiesfor specific
                | preprocessing data.For example, LoadSet will manage loading
                | conditions...

    """

    def __init__(self, catia):
        self.analysisset = catia.AnalysisSet     

    @property
    def analysis_entities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisEntities
                | o Property AnalysisEntities(    ) As AnalysisEntities
                | 
                | Returns the analysis entities collection associated to a set. The
                | corresponding entities are default preprocessing objects.  Example
                | :This example retrieves analysis entities collection . Dim MySet As
                | AnalysisSet Dim analysisEntities As AnalysisEntities Set
                | analysisEntities = MySet.AnalysisEntities


                | Parameters:


        """
        return self.analysisset.AnalysisEntities

    @property
    def analysis_images(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisImages
                | o Property AnalysisImages(    ) As AnalysisImages
                | 
                | Returns the analysis images collection associated with an analysis
                | set.  Example:This example retrieves analysisimages collection . Dim
                | MySet As AnalysisSet Dim analysisimages As AnalysisImages Set
                | analysisimages = MySet.AnalysisImages


                | Parameters:


        """
        return self.analysisset.AnalysisImages

    @property
    def analysis_output_entities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisOutputEntities
                | o Property AnalysisOutputEntities(    ) As AnalysisOutputEntities
                | 
                | Returns the analysis entities collection associated to a set. The
                | corresponding entities are not preprocessing features but can be used,
                | for example to manage error features.  Example:This example retrieves
                | analysisEntities collection . Dim MySet As AnalysisSet Dim
                | analysisEntities As AnalysisOutputEntities Set analysisEntities =
                | MySet.AnalysisOutputEntities


                | Parameters:


        """
        return self.analysisset.AnalysisOutputEntities

    @property
    def analysis_sets(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisSets
                | o Property AnalysisSets(    ) As AnalysisSets
                | 
                | Returns the analysis sets collection associated with an analysis set.
                | This method will return a collection only if the set is made of other
                | sets.  Example:This example retrieves analysisSets collection . Dim
                | MySet As AnalysisSet Dim analysisSets As AnalysisSets Set analysisSets
                | = MySet.AnalysisSets


                | Parameters:


        """
        return self.analysisset.AnalysisSets

    @property
    def basic_components(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BasicComponents
                | o Property BasicComponents(    ) As BasicComponents
                | 
                | Returns the basic components collection associated with an analysis
                | set.  Example:This example retrieves  basiccomponents collection . Dim
                | MySet As AnalysisSet Dim basiccomponents As BasicComponents  Set
                | basiccomponents = MySet.BasicComponents


                | Parameters:


        """
        return self.analysisset.BasicComponents

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the type of the analysis Set.  Example:The following example
                | returns TypeofSet of MySet.  Dim MySet As AnalysisSet Dim TypeofSet As
                | CATBSTR Set TypeofSet = MySet.Type


                | Parameters:


        """
        return self.analysisset.Type

    def update(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Update
                | o Sub Update(    )
                | 
                | Launch the update (computation if needed) of an AnalysisSet.


                | Parameters:


        """
        return self.analysisset.Update()

