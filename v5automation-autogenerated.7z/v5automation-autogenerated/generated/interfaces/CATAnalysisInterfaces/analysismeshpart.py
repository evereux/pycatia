#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisMeshPart:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAAnalysisMeshPart.

    """

    def __init__(self, catia):
        self.analysismeshpart = catia.AnalysisMeshPart     

    @property
    def activity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activity
                | o Property Activity(    ) As boolean
                | 
                | Returns the activity of an meshpart.


                | Parameters:
                | oActivity
                |  Legal values:
                |  FALSEMesh Part is not active.
                |  TRUEMesh Part is active.


        """
        return self.analysismeshpart.Activity

    @property
    def analysis_mesh_local_specifications(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisMeshLocalSpecifications
                | o Property AnalysisMeshLocalSpecifications(    ) As AnalysisMeshLocalSpecifications
                | 
                | Returns the local specification collection from the meshpart analysis.


                | Parameters:


        """
        return self.analysismeshpart.AnalysisMeshLocalSpecifications

    def add_support_from_publication(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(    Product    iProduct,
                |                                     Publication    iSupport)
                | 
                | Creates a new support and add it to the support description of the
                | mesh part.


                | Parameters:
                | iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iPublication
                |   the CATIA Publication that represent the the geometry to meshed. 
                | 
                |  See also:
                |   activateLinkAnchor('Publication','','Publication') ,  activateLinkAnchor('Product','','Product')


        """
        return self.analysismeshpart.AddSupportFromPublication(i_product, i_support)

    def add_support_from_reference(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(    Product    iProduct,
                |                                   Reference    iSupport)
                | 
                | Creates a new support and add it to the support description of the
                | mesh part.


                | Parameters:
                | iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iSupport
                |   the CATIA Reference that represent the geometry to meshed. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference') ,  activateLinkAnchor('Product','','Product')


        """
        return self.analysismeshpart.AddSupportFromReference(i_product, i_support)

    def set_global_specification(self, i_name, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetGlobalSpecification
                | o Sub SetGlobalSpecification(    CATBSTR    iName,
                |                                  CATVariant    iValue)
                | 
                | Sets the value corresponding to the given global specification.


                | Parameters:
                | iName
                |   The identifier if the global specification. 
                |  iValue
                |   The value of the global specification.


        """
        return self.analysismeshpart.SetGlobalSpecification(i_name, i_value)

    def set_mesh_parts_to_capture(self, i_mesh_parts):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMeshPartsToCapture
                | o Sub SetMeshPartsToCapture(    CATSafeArrayVariant    iMeshParts)
                | 
                | Set the list of candidate Mesh Parts for capture.


                | Parameters:
                | iMeshParts
                |    Safe array of mesh parts.  
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    S_OKOperation successfull.
                |    E_FAILOperation failed.


        """
        return self.analysismeshpart.SetMeshPartsToCapture(i_mesh_parts)

    def set_specification_from_publication(self, i_name, i_product, i_support, i_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSpecificationFromPublication
                | o Sub SetSpecificationFromPublication(    CATBSTR    iName,
                |                                           Product    iProduct,
                |                                           Publication    iSupport,
                |                                           long    iMode)
                | 
                | Adds the geometric value corresponding to the given global
                | specification.


                | Parameters:
                | iName
                |   The identifier if the global specification. 
                |  iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iPublication
                |   the CATIA Publication that represent the the geometry to meshed. 
                | 
                |  See also:
                |   activateLinkAnchor('Publication','','Publication') ,  activateLinkAnchor('Product','','Product') 
                |  iMode
                |    The mode used to valuate the publication global specification.
                |    Legal values: 
                |    0the global specification is defined as a single reference.
                |    1the global specification is added to exising references.


        """
        return self.analysismeshpart.SetSpecificationFromPublication(i_name, i_product, i_support, i_mode)

    def set_specification_from_reference(self, i_name, i_product, i_support, i_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSpecificationFromReference
                | o Sub SetSpecificationFromReference(    CATBSTR    iName,
                |                                         Product    iProduct,
                |                                         Reference    iSupport,
                |                                         long    iMode)
                | 
                | Set the geometric value corresponding to the given global
                | specification.


                | Parameters:
                | iName
                |   The identifier if the global specification. 
                |  iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iSupport
                |   the CATIA Reference that represent the geometry to meshed. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference') ,  activateLinkAnchor('Product','','Product') 
                |  iMode
                |    The mode used to valuate the reference global specification.
                |    Legal values: 
                |    0the global specification is defined as a single reference.
                |    1the global specification is added to exising references.


        """
        return self.analysismeshpart.SetSpecificationFromReference(i_name, i_product, i_support, i_mode)

