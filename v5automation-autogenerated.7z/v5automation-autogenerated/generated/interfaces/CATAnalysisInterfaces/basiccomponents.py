#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class BasicComponents:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of Basic Components defining and analysis object.These
                | components are agregated by another basic component, an entity or a
                | set.

    """

    def __init__(self, catia):
        self.basiccomponents = catia.BasicComponents     

    def item(self, i_variant):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iVariant) As BasicComponent
                | 
                | Returns an Basic Component using its index or its name from the Basic
                | Components collection.


                | Parameters:
                | iIndex
                |    The index or the name of the Basic Component to retrieve from
                |    the collection of Basic Component.
                |    As a numerics, this index is the rank of the Basic Component.
                |    in the collection.
                |    The index of the first Basic Component in the collection is 1, and
                |    the index of the last Basic Component is Count.
                |    As a string, it is the name you assigned to the Basic Component using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved Basic Component


        """
        return self.basiccomponents.Item(i_variant)

