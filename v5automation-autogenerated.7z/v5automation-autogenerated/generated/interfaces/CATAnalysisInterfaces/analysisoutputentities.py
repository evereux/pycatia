#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisOutputEntities:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of analysis entities results of a set.This collection
                | is implemented only for analysis sets. with analysis entities as
                | Output (regarding to the update mechanism).

    """

    def __init__(self, catia):
        self.analysisoutputentities = catia.AnalysisOutputEntities     

    def add(self, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    CATBSTR    iType) As AnalysisEntity
                | 
                | Creates a new analysis entity and adds it to the analysis entities
                | collection. This collection may be extracted from an analysis set.The
                | Analysis entity will be created on the Analysis Model.


                | Parameters:
                | iType
                |  The type of the entity to create.
                |  
                | 
                |  Returns:
                |   The created analysis entity


                | Examples:
                | 
                | This example create ThisAnalysisEntity in the AnalysisOutputEntities collection
                | 
                | Dim AnalysisOutputEntities As CATIAAnalysisOutputEntities
                | Dim ThisAnalysisEntity As AnalysisEntity
                | Set ThisAnalysisEntity = AnalysisOutputEntities.Add("MyEntity")
                | 
                | 
                | 
        """
        return self.analysisoutputentities.Add(i_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As AnalysisEntity
                | 
                | Returns an analysis entity using its index or its name from the
                | analysis entities collection.


                | Parameters:
                | iIndex
                |    The index or the name of the analysis entity to retrieve from
                |    the collection of analysis entities.
                |    As a numerics, this index is the rank of the analysis entity
                |    in the collection.
                |    The index of the first analysis entity in the collection is 1, and
                |    the index of the last analysis entity is Count.
                |    As a string, it is the name you assigned to the analysis entity using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property or when creating it using   the 
                |  activateLinkAnchor('','Add','Add')  method. 
                |    Returns:
                |   The retrieved analysis entity


        """
        return self.analysisoutputentities.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes a entity using its index or its name from the entity
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the entity to retrieve from
                |    the collection of entities.
                |    As a numeric, this index is the rank of the entity
                |    in the collection. The index of the first entity in the collection is 1,
                |    and the index of the last entity is Count.
                |    As a string, it is the name you assigned to the entity using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


        """
        return self.analysisoutputentities.Remove(i_index)

