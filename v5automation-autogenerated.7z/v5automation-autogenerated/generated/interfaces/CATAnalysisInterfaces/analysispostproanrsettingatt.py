#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisPostProANRSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to handle the Analysis & Simulation "PostProcessingSetting".

    """

    def __init__(self, catia):
        self.analysispostproanrsettingatt = catia.AnalysisPostProANRSettingAtt     

    @property
    def dmu_player_deformation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DMUPlayerDeformation
                | o Property DMUPlayerDeformation(    ) As long
                | 
                | Returns or sets the DMUPlayerDeformation parameter.


                | Parameters:
                | iDMUPlayerDeformation
                |  Legal values:
                |  1 : Deformation is real
                |  2 : Deformation is amplified
                |  Ensure consistency with the C++ interface to which the work is delegated.


        """
        return self.analysispostproanrsettingatt.DMUPlayerDeformation

    @property
    def dmu_player_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DMUPlayerMode
                | o Property DMUPlayerMode(    ) As long
                | 
                | Returns or sets the DMUPlayerMode parameter.


                | Parameters:
                | iDMUPlayerMode
                |  Legal values:
                |  1 : Mode is One Occurrence
                |  2 : Mode is All Occurrences
                |  Ensure consistency with the C++ interface to which the work is delegated.


        """
        return self.analysispostproanrsettingatt.DMUPlayerMode

    @property
    def dmu_player_steps_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DMUPlayerStepsNumber
                | o Property DMUPlayerStepsNumber(    ) As long
                | 
                | Returns or sets the DMUPlayerStepsNumber parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysispostproanrsettingatt.DMUPlayerStepsNumber

    def get_dmu_player_deformation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDMUPlayerDeformationInfo
                | o Func GetDMUPlayerDeformationInfo(    CATBSTR    ioAdminLevel,
                |                                        CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the DMUPlayerDeformation
                | parameter. Role:Retrieves the state of the DMUPlayerDeformation
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |  level that imposes the value of the parameter.
                |  If the parameter is not locked, AdminLevel gives the administration
                |  level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |  Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |    Indicates if the parameter has been explicitly modified or remain
                |  to the administrated value.


        """
        return self.analysispostproanrsettingatt.GetDMUPlayerDeformationInfo(io_admin_level, io_locked)

    def get_dmu_player_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDMUPlayerModeInfo
                | o Func GetDMUPlayerModeInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the DMUPlayerMode parameter.
                | Role:Retrieves the state of the DMUPlayerMode parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |  level that imposes the value of the parameter.
                |  If the parameter is not locked, AdminLevel gives the administration
                |  level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |  Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |    Indicates if the parameter has been explicitly modified or remain
                |  to the administrated value.


        """
        return self.analysispostproanrsettingatt.GetDMUPlayerModeInfo(io_admin_level, io_locked)

    def set_dmu_player_deformation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDMUPlayerDeformationLock
                | o Sub SetDMUPlayerDeformationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DMUPlayerDeformation parameter. Role:Locks or
                | unlocks the DMUPlayerDeformation parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  FALSE:   to unlock the parameter.


        """
        return self.analysispostproanrsettingatt.SetDMUPlayerDeformationLock(i_locked)

    def set_dmu_player_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDMUPlayerModeLock
                | o Sub SetDMUPlayerModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DMUPlayerMode parameter. Role:Locks or unlocks
                | the DMUPlayerMode parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  FALSE:   to unlock the parameter.


        """
        return self.analysispostproanrsettingatt.SetDMUPlayerModeLock(i_locked)

