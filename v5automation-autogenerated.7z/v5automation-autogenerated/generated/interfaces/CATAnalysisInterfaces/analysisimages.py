#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisImages:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of analysis images.

    """

    def __init__(self, catia):
        self.analysisimages = catia.AnalysisImages     

    def add(self, i_image_name, i_hide_existing_images, i_show_mesh, i_duplicate):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    CATBSTR    iImageName,
                |                CATVariant    iHideExistingImages,
                |                CATVariant    iShowMesh,
                |                CATVariant    iDuplicate) As AnalysisImage
                | 
                | Creates a new image and adds it to the analysis image collection.


                | Parameters:
                | iImageName
                |  The name of the image to create.
                |  
                |  iHideExistingImages
                |  To deactivate or not all the activated images before create the new image.
                |  
                |  iShowMesh
                |  To show or not the mesh image.
                |  
                |  iDuplicate
                |  To duplicate or not the new image, if same image already exists in collection of images.
                |  
                | 
                |  Returns:
                |   The created Analysis Image


                | Examples:
                | 
                | This example create ThisAnalysisImage in the analysisImagesanalysis
                | images collection. The image to create is supposed to be a mesh deformed image.
                | 
                | Dim ThisAnalysisImage As AnalysisImage
                | Set ThisAnalysisImage = analysisImages.Add("Mesh_Deformed", True, False, False)
                | 
                | 
                | 
        """
        return self.analysisimages.Add(i_image_name, i_hide_existing_images, i_show_mesh, i_duplicate)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As AnalysisImage
                | 
                | Returns an analysis image using its index or its name from the
                | analysis images collection.


                | Parameters:
                | iIndex
                |    The index or the name of the analysis image to retrieve from
                |    the collection of analysis images.
                |    This index is the rank of the analysis image in the collection.
                |    The index of the first analysis image in the collection is 1, and
                |    the index of the last analysis image is Count.
                |  
                | 
                |  Returns:
                |   The retrieved analysis image


                | Examples:
                | 
                | This example retrieves in ThisAnalysisImage the third analysis image.
                | 
                | Dim ThisAnalysisImage As AnalysisImage
                | Set ThisAnalysisImage = analysisImages.Item(3)
                | 
                | 
                | 
        """
        return self.analysisimages.Item(i_index)

    def remove_image(self, i_image_identifier):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveImage
                | o Sub RemoveImage(    CATVariant    iImageIdentifier)
                | 
                | Deletes the Analysis Image from the analysis images collection of the
                | Analysis Set.


                | Parameters:
                | iImageIdentifier
                |    The index or the name of the analysis image to delete from the Analysis Set.
                |    Note: The index given is the position of the image in the Analysis Set.
                |    Note: The name given is the string got from analysisImage.Name
                | 	  If the index or the name specified is not present in the Analysis Set, this method FAILS.
                |    The index of the first analysis image in the collection is 1, and
                |    the index of the last analysis image is Count.


                | Examples:
                | 
                | Example 1
                | In this example analysisImages1 is the Analysis Set and analysisImage1 is the image present in it.
                | imageName = analysisImage1.Name
                | analysisImages1.RemoveImage(imageName)
                | 
                | Example 2
                | analysisImages1.RemoveImage(4)
                | In this example 4 is the index of the Image to be deleted in Analysis Set: analysisImages1
                | 
                | 
        """
        return self.analysisimages.RemoveImage(i_image_identifier)

