#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisV4Services:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAAnalysisV4Services.This service
                | provides tools to extract analysis information stored in V4 model and
                | session.Note:  The implementation of this API requires specific
                | Licensing:V4Aproduct needs to be installed.To get access to this
                | service:

    """

    def __init__(self, catia):
        self.analysisv4services = catia.AnalysisV4Services     

    def get_storage_info(self, i_model_path, o_prefix):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStorageInfo
                | o Func GetStorageInfo(    CATBSTR    iModelPath,
                |                           CATBSTR    oPrefix) As CATBSTR
                | 
                | Gets V4 External Storage information stored in a model.


                | Parameters:
                | iModelPath:
                |  Path of model file. 
                |  oExternal:
                |  Storage Path. 
                |  oPrefix:
                |  Directory prefix: Something like "D1998124T083802".


                | Examples:
                | 
                | This example return external storage information for a model path
                | 
                | Dim SAMV4Service As AnalysisV4Services
                | Set SAMV4Service = CATIA.GetItem("SAMV4Service")
                | Dim Prefix As String
                | Prefix = ""
                | Dim PathStorage As String
                | Dim sDocPath As String
                | sDocPath = "E:\mymodel.model"
                | PathStorage = SAMV4Service.GetStorageInfo(sDocPath,Prefix)
                | CATIA.SystemService.Print "GetStorageInfo for Model: " & sDocPath
                | CATIA.SystemService.Print "GetStorageInfo PathStorage: " & PathStorage & " Prefix " & Prefix
                | 
                | 
                | 
        """
        return self.analysisv4services.GetStorageInfo(i_model_path, o_prefix)

    def print_assembled_sets_info(self, i_session_path, i_print_path, i_submesh):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintAssembledSetsInfo
                | o Sub PrintAssembledSetsInfo(    CATBSTR    iSessionPath,
                |                                  CATBSTR    iPrintPath,
                |                                  long    iSubmesh)
                | 
                | Gets sets list for a model included in a V4 Session. The generated
                | file contains names of load, restraint, non structural mass and
                | displacement sets for a given submesh number.


                | Parameters:
                | iSessionPath:
                |  Path of session file. 
                |  iPrintPath:
                |  Path where to create the dump file. 
                |  iSubmesh:
                |  Submesh Number of the modelo. Note that if the file already exists it will be replaced.


                | Examples:
                | 
                | This example extract assembled sets information.
                | 
                | Dim SAMV4Service As AnalysisV4Services
                | Set SAMV4Service = CATIA.GetItem("SAMV4Service")
                | Dim sSession As String
                | sSession = "E:\MYSESSION.session"
                | Dim sSumpFile As String
                | sSumpFile = "E:\MyFile.txt"
                | SAMV4Service.PrintAssembledSetsInfo sSession,sSumpFile,120
                | 
                | 
                | 
        """
        return self.analysisv4services.PrintAssembledSetsInfo(i_session_path, i_print_path, i_submesh)

    def print_coupling_analysis_info(self, i_session_path, i_print_path, i_submesh):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintCouplingAnalysisInfo
                | o Sub PrintCouplingAnalysisInfo(    CATBSTR    iSessionPath,
                |                                     CATBSTR    iPrintPath,
                |                                     long    iSubmesh)
                | 
                | Gets V4 Coupling analysis information.


                | Parameters:
                | iSessionPath:
                |  Path of the model file. 
                |  iPrintPath:
                |  Path where to create the dump file. 
                |  iSubmesh:
                |  Sub mesh number, the file will dump at the level of this submesh. Note that if file already exists it will be replaced.


                | Examples:
                | 
                | This example extracts sets information.
                | 
                | Dim SAMV4Service As AnalysisV4Services
                | Set SAMV4Service = CATIA.GetItem("SAMV4Service")
                | Dim sSession As String
                | sSession = "E:\MYSESSION.session"
                | Dim sSumpFile As String
                | sSumpFile = "E:\MyCouplingAnalysisFile.txt"
                | SAMV4Service.PrintCouplingAnalysisInfo sSession,sSumpFile, 120
                | 
                | 
                | 
        """
        return self.analysisv4services.PrintCouplingAnalysisInfo(i_session_path, i_print_path, i_submesh)

    def print_session_info(self, i_session_path, i_print_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintSessionInfo
                | o Sub PrintSessionInfo(    CATBSTR    iSessionPath,
                |                            CATBSTR    iPrintPath)
                | 
                | Gets V4 Session information. The file is made of submesh & model name
                | identification.


                | Parameters:
                | iSessionPath:
                |  Path of session file. 
                |  iPrintPath:
                |  Path where to create the dump file. Note that if the file already exists it will be replaced.


                | Examples:
                | 
                | This example extract session information.
                | 
                | Dim SAMV4Service As AnalysisV4Services
                | Set SAMV4Service = CATIA.GetItem("SAMV4Service")
                | Dim sSession As String
                | sSession = "E:\MYSESSION.session"
                | Dim sSumpFile As String
                | sSumpFile = "E:\MyFile.txt"
                | SAMV4Service.PrintSessionInfo sSession,sSumpFile
                | 
                | 
                | 
        """
        return self.analysisv4services.PrintSessionInfo(i_session_path, i_print_path)

