#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisPostProSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to handle the Analysis & Simulation "PostProcessingSetting".

    """

    def __init__(self, catia):
        self.analysispostprosettingatt = catia.AnalysisPostProSettingAtt     

    @property
    def auto_preview_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoPreviewMode
                | o Property AutoPreviewMode(    ) As boolean
                | 
                | Returns or sets the AutoPreviewMode parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysispostprosettingatt.AutoPreviewMode

    @property
    def image_text_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImageTextSize
                | o Property ImageTextSize(    ) As float
                | 
                | Returns or sets the ImageTextSize parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysispostprosettingatt.ImageTextSize

    @property
    def image_text_stacking(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImageTextStacking
                | o Property ImageTextStacking(    ) As long
                | 
                | Returns or sets the ImageTextStacking parameter.


                | Parameters:
                | iImageTextStacking
                |  Legal values:
                |  0 : Text stacking is Horizontal
                |  1 : Text stacking is Vertical
                |  Ensure consistency with the C++ interface to which the work is delegated.


        """
        return self.analysispostprosettingatt.ImageTextStacking

    @property
    def mode_image_text_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ModeImageTextSize
                | o Property ModeImageTextSize(    ) As boolean
                | 
                | Returns or sets the ModeImageTextSize parameter.


                | Parameters:
                | iModeImageTextSize
                |  Legal values:
                |  TRUE : Enables the setting of image text size
                |  FALSE: Disables the setting of image text size  
                |  Ensure consistency with the C++ interface to which the work is delegated.


        """
        return self.analysispostprosettingatt.ModeImageTextSize

    @property
    def save_as_new_template_directory(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveAsNewTemplateDirectory
                | o Property SaveAsNewTemplateDirectory(    ) As CATBSTR
                | 
                | Returns or sets the SaveAsNewTemplateDirectory parameter.  Ensure
                | consistency with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysispostprosettingatt.SaveAsNewTemplateDirectory

    def get_auto_preview_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoPreviewModeInfo
                | o Func GetAutoPreviewModeInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AutoPreviewMode parameter.
                | Role:Retrieves the state of the AutoPreviewMode parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.analysispostprosettingatt.GetAutoPreviewModeInfo(io_admin_level, io_locked)

    def get_image_text_size_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetImageTextSizeInfo
                | o Func GetImageTextSizeInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ImageTextSize parameter.
                | Role:Retrieves the state of the ImageTextSize parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |  level that imposes the value of the parameter.
                |  If the parameter is not locked, AdminLevel gives the administration
                |  level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |  Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |    Indicates if the parameter has been explicitly modified or remain
                |  to the administrated value.


        """
        return self.analysispostprosettingatt.GetImageTextSizeInfo(io_admin_level, io_locked)

    def get_image_text_stacking_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetImageTextStackingInfo
                | o Func GetImageTextStackingInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ImageTextStacking
                | parameter. Role:Retrieves the state of the ImageTextStacking parameter
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |  level that imposes the value of the parameter.
                |  If the parameter is not locked, AdminLevel gives the administration
                |  level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |  Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |    Indicates if the parameter has been explicitly modified or remain
                |  to the administrated value.


        """
        return self.analysispostprosettingatt.GetImageTextStackingInfo(io_admin_level, io_locked)

    def get_mode_image_text_size_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetModeImageTextSizeInfo
                | o Func GetModeImageTextSizeInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ModeImageTextSize
                | parameter. Role:Retrieves the state of the ModeImageTextSize parameter
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |  level that imposes the value of the parameter.
                |  If the parameter is not locked, AdminLevel gives the administration
                |  level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |  Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |    Indicates if the parameter has been explicitly modified or remain
                |  to the administrated value.


        """
        return self.analysispostprosettingatt.GetModeImageTextSizeInfo(io_admin_level, io_locked)

    def get_save_as_new_template_directory_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSaveAsNewTemplateDirectoryInfo
                | o Func GetSaveAsNewTemplateDirectoryInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the SaveAsNewTemplateDirectory
                | parameter. Role:Retrieves the state of the SaveAsNewTemplateDirectory
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |  level that imposes the value of the parameter.
                |  If the parameter is not locked, AdminLevel gives the administration
                |  level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |  Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |    Indicates if the parameter has been explicitly modified or remain
                |  to the administrated value.


        """
        return self.analysispostprosettingatt.GetSaveAsNewTemplateDirectoryInfo(io_admin_level, io_locked)

    def set_auto_preview_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoPreviewModeLock
                | o Sub SetAutoPreviewModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AutoPreviewMode parameter. Role:Locks or unlocks
                | the AutoPreviewMode parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.analysispostprosettingatt.SetAutoPreviewModeLock(i_locked)

    def set_image_text_size_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetImageTextSizeLock
                | o Sub SetImageTextSizeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ImageTextSize parameter. Role:Locks or unlocks
                | the ImageTextSize parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                | 	FALSE:   to unlock the parameter.


        """
        return self.analysispostprosettingatt.SetImageTextSizeLock(i_locked)

    def set_image_text_stacking_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetImageTextStackingLock
                | o Sub SetImageTextStackingLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ImageTextStacking parameter. Role:Locks or
                | unlocks the ImageTextStacking parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  FALSE:   to unlock the parameter.


        """
        return self.analysispostprosettingatt.SetImageTextStackingLock(i_locked)

    def set_mode_image_text_size_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetModeImageTextSizeLock
                | o Sub SetModeImageTextSizeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ModeImageTextSize parameter. Role:Locks or
                | unlocks the ModeImageTextSize parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                |  the locking operation to be performed
                |  Legal values:
                |  TRUE :   to lock the parameter.
                |  FALSE:   to unlock the parameter.


        """
        return self.analysispostprosettingatt.SetModeImageTextSizeLock(i_locked)

    def set_save_as_new_template_directory_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSaveAsNewTemplateDirectoryLock
                | o Sub SetSaveAsNewTemplateDirectoryLock(    boolean    iLocked)
                | 
                | Locks or unlocks the SaveAsNewTemplateDirectory parameter. Role:Locks
                | or unlocks the Xxx parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |  the locking operation to be performed
                |  Legal values:
                |  TRUE :   to lock the parameter.
                |  FALSE:   to unlock the parameter.


        """
        return self.analysispostprosettingatt.SetSaveAsNewTemplateDirectoryLock(i_locked)

