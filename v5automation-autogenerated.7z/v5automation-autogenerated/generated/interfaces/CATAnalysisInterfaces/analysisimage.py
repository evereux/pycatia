#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisImage:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the analysis image object.

    """

    def __init__(self, catia):
        self.analysisimage = catia.AnalysisImage     

    @property
    def analysis_color_map(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisColorMap
                | o Property AnalysisColorMap(    ) As AnalysisColorMap
                | 
                | Returns the color map object associated with an analysis image.


                | Parameters:


        """
        return self.analysisimage.AnalysisColorMap

    @property
    def analysis_images(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisImages
                | o Property AnalysisImages(    ) As AnalysisImages
                | 
                | Returns the analysis images collection associated with an analysis
                | image.


                | Parameters:


        """
        return self.analysisimage.AnalysisImages

    def export_data(self, i_folder, i_file_name, i_extension_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportData
                | o Sub ExportData(    Folder    iFolder,
                |                      CATBSTR    iFileName,
                |                      CATBSTR    iExtensionType)
                | 
                | Extracts image results. The export is done related to an existing
                | image  and will be stored in a CATIA Folder as a Text file or as an
                | Excel file. Limitations: The allowed output positions are: node,
                | element, center of element, and node of elementThe allowed values are:
                | integer, real or doubleThe allowed value types are: average or
                | discontinuous iso, symbol, fringe or textTo export data with mesh-part
                | identification use  activateLinkAnchor('','ExportDataWithMeshPartId','
                | ExportDataWithMeshPartId')


                | Parameters:
                | iFolder
                |   The folder to store the file to create 
                |  iFileName
                |  The name of the file to create 
                |  iExtensionType
                |     The extension of the file
                |  Legal values:
                |  
                | "xls" for a Microsoft Excel workbook
                | "txt" for a text file.


        """
        return self.analysisimage.ExportData(i_folder, i_file_name, i_extension_type)

    def export_data_in_any_user_axis(self, i_folder, i_file_name, i_extension_type, i_axis_system, i_product, i_axis_orientation_type, i_export_mesh_part_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportDataInAnyUserAxis
                | o Sub ExportDataInAnyUserAxis(    Folder    iFolder,
                |                                   CATBSTR    iFileName,
                |                                   CATBSTR    iExtensionType,
                |                                   AnyObject    iAxisSystem,
                |                                   Product    iProduct,
                |                                   CATAxisOrientationType    iAxisOrientationType,
                |                                   boolean    iExportMeshPartID)
                | 
                | Extracts image results. The export is done related to an existing
                | image  and will be stored in a CATIA Folder as a Text file or as an
                | Excel file. If User has not implemented CATIAAxisSystem interface for
                | axis system, but  has CATIABase interface implementation. Limitations:
                | The allowed output positions are: node, element, center of element,
                | and node of elementThe allowed values are: integer, real or doubleThe
                | allowed value types are: average or discontinuous iso, symbol, fringe
                | or textTo export data with mesh-part identification use  activateLinkA
                | nchor('','ExportDataWithMeshPartId','ExportDataWithMeshPartId')


                | Parameters:
                | iFolder
                |   The folder to store the file to create 
                |  iFileName
                |  The name of the file to create 
                |  iExtensionType
                |     The extension of the file
                |  Legal values:
                |  
                | "xls" for a Microsoft Excel workbook
                | "txt" for a text file.
                | 
                | 
                |  iAxisSystem
                |  Reference to the axis system to be used for location transformation. 
                |  iProduct
                |  Reference to the product, where the above axis system is defined.   
                |  iAxisOrientationType
                |  Coordinate system type of location axis system 
                |  iExportMeshPartID
                |  Flag for exporting with meshpartid or not


        """
        return self.analysisimage.ExportDataInAnyUserAxis(i_folder, i_file_name, i_extension_type, i_axis_system, i_product, i_axis_orientation_type, i_export_mesh_part_id)

    def export_data_in_global_axis(self, i_folder, i_file_name, i_extension_type, i_axis_orientation_type, i_export_mesh_part_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportDataInGlobalAxis
                | o Sub ExportDataInGlobalAxis(    Folder    iFolder,
                |                                  CATBSTR    iFileName,
                |                                  CATBSTR    iExtensionType,
                |                                  CATAxisOrientationType    iAxisOrientationType,
                |                                  boolean    iExportMeshPartID)
                | 
                | Extracts image results. The export is done related to an existing
                | image  and will be stored in a CATIA Folder as a Text file or as an
                | Excel file. Limitations: The allowed output positions are: node,
                | element, center of element, and node of elementThe allowed values are:
                | integer, real or doubleThe allowed value types are: average or
                | discontinuous iso, symbol, fringe or text


                | Parameters:
                | iFolder
                |   The folder to store the file to create 
                |  iFileName
                |  The name of the file to create 
                |  iExtensionType
                |     The extension of the file
                |  Legal values:
                |  
                | "xls" for a Microsoft Excel workbook
                | "txt" for a text file.
                | 
                | 
                |  iAxisOrientationType
                |  Coordinate system type of location axis system 
                |  iExportMeshPartID
                |  Flag for exporting with meshpartid or not


        """
        return self.analysisimage.ExportDataInGlobalAxis(i_folder, i_file_name, i_extension_type, i_axis_orientation_type, i_export_mesh_part_id)

    def export_data_in_manual_axis(self, i_folder, i_file_name, i_extension_type, i_origin, i_x_direction, i_y_direction, i_z_direction, i_axis_orientation_type, i_export_mesh_part_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportDataInManualAxis
                | o Sub ExportDataInManualAxis(    Folder    iFolder,
                |                                  CATBSTR    iFileName,
                |                                  CATBSTR    iExtensionType,
                |                                  CATSafeArrayVariant    iOrigin,
                |                                  CATSafeArrayVariant    iXDirection,
                |                                  CATSafeArrayVariant    iYDirection,
                |                                  CATSafeArrayVariant    iZDirection,
                |                                  CATAxisOrientationType    iAxisOrientationType,
                |                                  boolean    iExportMeshPartID)
                | 
                | Extracts image results. The export is done related to an existing
                | image  and will be stored in a CATIA Folder as a Text file or as an
                | Excel file. Limitations: The allowed output positions are: node,
                | element, center of element, and node of elementThe allowed values are:
                | integer, real or doubleThe allowed value types are: average or
                | discontinuous iso, symbol, fringe or text


                | Parameters:
                | iFolder
                |   The folder to store the file to create 
                |  iFileName
                |  The name of the file to create 
                |  iExtensionType
                |     The extension of the file
                |  Legal values:
                |  
                | "xls" for a Microsoft Excel workbook
                | "txt" for a text file.
                | 
                | 
                |  iOrigin
                |  Origin of Location axis system 
                |  iXDirection
                |  co-ordinates of a point on X- axis of Location axis system 
                |  iYDirection
                |  co-ordinates of a point on Y- axis of Location axis system 
                |  iZDirection
                |  co-ordinates of a point on Z- axis of Location axis system 
                |  iAxisOrientationType
                |  Coordinate system type of location axis system 
                |  iExportMeshPartID
                |  Flag for exporting with meshpartid or not


        """
        return self.analysisimage.ExportDataInManualAxis(i_folder, i_file_name, i_extension_type, i_origin, i_x_direction, i_y_direction, i_z_direction, i_axis_orientation_type, i_export_mesh_part_id)

    def export_data_in_user_axis(self, i_folder, i_file_name, i_extension_type, i_axis_system, i_product, i_axis_orientation_type, i_export_mesh_part_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportDataInUserAxis
                | o Sub ExportDataInUserAxis(    Folder    iFolder,
                |                                CATBSTR    iFileName,
                |                                CATBSTR    iExtensionType,
                |                                AxisSystem    iAxisSystem,
                |                                Product    iProduct,
                |                                CATAxisOrientationType    iAxisOrientationType,
                |                                boolean    iExportMeshPartID)
                | 
                | Extracts image results. The export is done related to an existing
                | image  and will be stored in a CATIA Folder as a Text file or as an
                | Excel file. Limitations: The allowed output positions are: node,
                | element, center of element, and node of elementThe allowed values are:
                | integer, real or doubleThe allowed value types are: average or
                | discontinuous iso, symbol, fringe or textTo export data with mesh-part
                | identification use  activateLinkAnchor('','ExportDataWithMeshPartId','
                | ExportDataWithMeshPartId')


                | Parameters:
                | iFolder
                |   The folder to store the file to create 
                |  iFileName
                |  The name of the file to create 
                |  iExtensionType
                |     The extension of the file
                |  Legal values:
                |  
                | "xls" for a Microsoft Excel workbook
                | "txt" for a text file.
                | 
                | 
                |  iAxisSystem
                |  Reference to the axis system to be used for location transformation. 
                |  iProduct
                |  Reference to the product, where the above axis system is defined.   
                |  iAxisOrientationType
                |  Coordinate system type of location axis system 
                |  iExportMeshPartID
                |  Flag for exporting with meshpartid or not


        """
        return self.analysisimage.ExportDataInUserAxis(i_folder, i_file_name, i_extension_type, i_axis_system, i_product, i_axis_orientation_type, i_export_mesh_part_id)

    def export_data_with_mesh_part_id(self, i_folder, i_file_name, i_extension_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportDataWithMeshPartId
                | o Sub ExportDataWithMeshPartId(    Folder    iFolder,
                |                                    CATBSTR    iFileName,
                |                                    CATBSTR    iExtensionType)
                | 
                | Extracts image results and location with mesh part name (as
                | identifier). The export is done related to an existing image  and will
                | be stored in a CATIA Folder as a Text file or as an Excel file.
                | Limitations: The allowed output positions are: element, center of
                | element, and node of elementThe allowed values are: integer, real or
                | doubleThe allowed value types are: average or discontinuous iso,
                | symbol, fringe or textTo export data with mesh-part identification use
                | activateLinkAnchor('','ExportData','ExportData')


                | Parameters:
                | iFolder
                |   The folder to store the file to create 
                |  iFileName
                |  The name of the file to create 
                |  iExtensionType
                |     The extension of the file
                |  Legal values:
                |  
                | "xls" for a Microsoft Excel workbook
                | "txt" for a text file.


        """
        return self.analysisimage.ExportDataWithMeshPartId(i_folder, i_file_name, i_extension_type)

    def reset_selection(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ResetSelection
                | o Sub ResetSelection(    )
                | 
                | Resets all selections in an image. This is done related to an existing
                | image


                | Parameters:


        """
        return self.analysisimage.ResetSelection()

    def set_activation_status(self, i_activation_status):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetActivationStatus
                | o Sub SetActivationStatus(    CATVariant    iActivationStatus)
                | 
                | Activates oe deactivates an image. This is done related to an existing
                | image


                | Parameters:
                | iActivationStatus
                |   To activate or not the current image.


        """
        return self.analysisimage.SetActivationStatus(i_activation_status)

    def set_current_occurrence(self, i_occurrence_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCurrentOccurrence
                | o Sub SetCurrentOccurrence(    CATVariant    iOccurrenceNumber)
                | 
                | Sets occurrence number for an image. This is done related to an
                | existing image


                | Parameters:
                | iOccurrenceNumber
                |   The number to select Legal value: 1 ≤ iOccurrenceNumber ≤ nbOccurrence


        """
        return self.analysisimage.SetCurrentOccurrence(i_occurrence_number)

    def set_selection(self, i_reference, i_replace_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSelection
                | o Sub SetSelection(    Reference    iReference,
                |                        CATVariant    iReplaceMode)
                | 
                | Adds a selection to an image. This is done related to an existing
                | image


                | Parameters:
                | iReference
                |   The selectionGroup to add 
                |  iReplaceMode
                |  To replace or not the current selections.


        """
        return self.analysisimage.SetSelection(i_reference, i_replace_mode)

    def update(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Update
                | o Sub Update(    )
                | 
                | Updates an image.  This is done related to an existing image


                | Parameters:


        """
        return self.analysisimage.Update()

