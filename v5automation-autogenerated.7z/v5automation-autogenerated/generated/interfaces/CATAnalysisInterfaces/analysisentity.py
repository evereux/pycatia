#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisEntity:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the  analysis entity object.This class provides services to
                | describe a analysis entity.  It represents some preprocessing
                | activities.It agregates descriptive sub-entities named  Basic
                | Components, and Analysis Supports.The basic component represent the
                | physical data and the support the localisation.

    """

    def __init__(self, catia):
        self.analysisentity = catia.AnalysisEntity     

    @property
    def analysis_images(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisImages
                | o Property AnalysisImages(    ) As AnalysisImages
                | 
                | Returns the analysis images collection associated with an analysis
                | entity.  Example:This example retrieves analysisimages collection .
                | Dim MyEntity As AnalysisEntity Dim analysisimages As AnalysisImages
                | Set analysisimages = MyEntity.AnalysisImages


                | Parameters:


        """
        return self.analysisentity.AnalysisImages

    @property
    def analysis_local_entities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisLocalEntities
                | o Property AnalysisLocalEntities(    ) As AnalysisLocalEntities
                | 
                | Returns the analysis local entity collection associated with an
                | analysis entity.  Example:This example retrieves analysislocalEntity
                | collection . Dim MyEntity As AnalysisEntity Dim analysislocalEntity As
                | AnalysisLocalEntities Set analysislocalEntity =
                | MyEntity.AnalysisLocalEntities


                | Parameters:


        """
        return self.analysisentity.AnalysisLocalEntities

    @property
    def analysis_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisSupports
                | o Property AnalysisSupports(    ) As AnalysisSupports
                | 
                | Returns the list of Analysis Supports. The support defines the area on
                | which the analysis is applied on.


                | Parameters:


        """
        return self.analysisentity.AnalysisSupports

    @property
    def basic_components(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BasicComponents
                | o Property BasicComponents(    ) As BasicComponents
                | 
                | Returns the basic components collection associated with an analysis
                | entity.  Example:This example retrieves  basiccomponents collection .
                | Dim MyEntity As AnalysisEntity Dim basiccomponents As BasicComponents
                | Set basiccomponents = MyEntity.BasicComponents


                | Parameters:


        """
        return self.analysisentity.BasicComponents

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the type of the analysis entity.  Example:The following
                | example returns TypeofEntity of MyEntity.  Dim MyEntity As
                | AnalysisEntity Dim TypeofEntity As CATBSTR Set TypeofEntity =
                | MyEntity.Type


                | Parameters:


        """
        return self.analysisentity.Type

    def add_support_from_constraint(self, i_constraint_product, i_constraint):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromConstraint
                | o Sub AddSupportFromConstraint(    Product    iConstraintProduct,
                |                                    Constraint    iConstraint)
                | 
                | Creates a new support and add it to the description of the Analysis
                | Entity.


                | Parameters:
                | iConstraintProduct
                |   the CATIA Product of the Constraint. 
                |  iConstraint
                |  the CATIA Constraint that represent the object to linked. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference') ,  activateLinkAnchor('Part','','Part')


        """
        return self.analysisentity.AddSupportFromConstraint(i_constraint_product, i_constraint)

    def add_support_from_part(self, i_part_product, i_part):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPart
                | o Sub AddSupportFromPart(    Product    iPartProduct,
                |                              Part    iPart)
                | 
                | Creates a new support and add it to the description of the Analysis
                | Entity.


                | Parameters:
                | iPartProduct
                |   the CATIA Product of the part. 
                |  iPart
                |  the CATIA Part that represent the object to linked. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference') ,  activateLinkAnchor('Part','','Part')


        """
        return self.analysisentity.AddSupportFromPart(i_part_product, i_part)

    def add_support_from_product(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromProduct
                | o Sub AddSupportFromProduct(    Product    iProduct,
                |                                 Reference    iSupport)
                | 
                | Creates a new support and add it to the description of the Analysis
                | Entity.


                | Parameters:
                | iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iSupport
                |   the CATIA Reference that represent the object to linked. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference') ,  activateLinkAnchor('Product','','Product')


        """
        return self.analysisentity.AddSupportFromProduct(i_product, i_support)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(    Product    iProduct,
                |                                     Publication    iPublication)
                | 
                | Creates a new support and add it to the description of the Analysis
                | Entity.


                | Parameters:
                | iProduct
                |   the CATIA Product that represent the object to linked. 
                |  iPublication
                |   the CATIA Publication that represent the object to linked. 
                | 
                |  See also:
                |   activateLinkAnchor('Publication','','Publication') ,  activateLinkAnchor('Product','','Product')


        """
        return self.analysisentity.AddSupportFromPublication(i_product, i_publication)

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(    Reference    iReference,
                |                                   Reference    iSupport)
                | 
                | Creates a new support and add it to the description of the Analysis
                | Entity.


                | Parameters:
                | iReference
                |   the CATIA Reference that represent the object to linked. This identification,  may locate the instance of the object
                | 
                |  iSupport
                |   the CATIA Reference that represent the object to linked. 
                | 
                |  See also:
                |   activateLinkAnchor('Reference','','Reference')


        """
        return self.analysisentity.AddSupportFromReference(i_reference, i_support)

    def get_reference(self, i_component, i_label, i_line_index, i_column_index, i_layer_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetReference
                | o Func GetReference(    CATBSTR    iComponent,
                |                         CATBSTR    iLabel,
                |                         long    iLineIndex,
                |                         long    iColumnIndex,
                |                         long    iLayerIndex) As Reference
                | 
                | Returns the reference corresponding to the given component.


                | Parameters:
                | iComponent
                |   The identifier if the basic component. 
                |  iLabel
                |   The label of the block containing the value. 
                |  iLineIndex
                |   The line index of the value. 
                |  iColumnIndex
                |   The column index of the value. 
                |  iLayerIndex
                |   The layer index of the value.


        """
        return self.analysisentity.GetReference(i_component, i_label, i_line_index, i_column_index, i_layer_index)

    def get_value(self, i_component, i_label, i_line_index, i_column_index, i_layer_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetValue
                | o Func GetValue(    CATBSTR    iComponent,
                |                     CATBSTR    iLabel,
                |                     long    iLineIndex,
                |                     long    iColumnIndex,
                |                     long    iLayerIndex) As CATVariant
                | 
                | Returns the value corresponding to the given component.


                | Parameters:
                | iComponent
                |   The identifier if the basic component. 
                |  iLabel
                |   The label of the block containing the value. 
                |  iLineIndex
                |   The line index of the value. 
                |  iColumnIndex
                |   The column index of the value. 
                |  iLayerIndex
                |   The layer index of the value.


        """
        return self.analysisentity.GetValue(i_component, i_label, i_line_index, i_column_index, i_layer_index)

    def set_reference(self, i_component, i_label, i_line_index, i_column_index, i_layer_index, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetReference
                | o Sub SetReference(    CATBSTR    iComponent,
                |                        CATBSTR    iLabel,
                |                        long    iLineIndex,
                |                        long    iColumnIndex,
                |                        long    iLayerIndex,
                |                        Reference    iValue)
                | 
                | Sets the reference corresponding to the given component.


                | Parameters:
                | iComponent
                |   The identifier if the basic component. 
                |  iLabel
                |   The label of the block containing the value. 
                |  iLineIndex
                |   The line index of the value. 
                |  iColumnIndex
                |   The column index of the value. 
                |  iLayerIndex
                |   The layer index of the value. If the the component has a single value, assign 0 to the 3 parameters.


        """
        return self.analysisentity.SetReference(i_component, i_label, i_line_index, i_column_index, i_layer_index, i_value)

    def set_value(self, i_component, i_label, i_line_index, i_column_index, i_layer_index, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetValue
                | o Sub SetValue(    CATBSTR    iComponent,
                |                    CATBSTR    iLabel,
                |                    long    iLineIndex,
                |                    long    iColumnIndex,
                |                    long    iLayerIndex,
                |                    CATVariant    iValue)
                | 
                | Sets the value corresponding to the given component.


                | Parameters:
                | iComponent
                |   The identifier if the basic component. 
                |  iLabel
                |   The label of the block containing the value. 
                |  iLineIndex
                |   The line index of the value. 
                |  iColumnIndex
                |   The column index of the value. 
                |  iLayerIndex
                |   The layer index of the value. If the the component has a single value, assign 0 to the 3 parameters.
                | 
                |  
                |  This example create ThisAnalysisEntity in the analysisEntities collection 
                |  The entity to create is supposed to be a pressure defined in a load set. We
                |  will valuate the basic component that contain the pressure data "SAMPressureMag".
                |  
                |  Dim analysisEntities As CATIAAnalysisEntities
                |  Dim ThisAnalysisEntity As AnalysisEntity
                |  Set ThisAnalysisEntity = analysisEntities.Add("SAMPressure")
                |  ThisAnalysisEntity.SetValue("SAMPressureMag"," ",0,0,0,100)


        """
        return self.analysisentity.SetValue(i_component, i_label, i_line_index, i_column_index, i_layer_index, i_value)

