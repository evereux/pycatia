#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisModel:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the  analysis model object.Role: In the analysis document,
                | an analysis model is the object dedicated to set and manage all the
                | required data for the discretization  and idealization of a Finite
                | Element model.This object gives access to:

    """

    def __init__(self, catia):
        self.analysismodel = catia.AnalysisModel     

    @property
    def adaptivity_manager(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AdaptivityManager
                | o Property AdaptivityManager(    ) As AnalysisAdaptivityManager
                | 
                | Returns the AdaptivityManager defined on the analysis model.  Returns:
                | a CATIAAnalysisAdaptivityManager.


                | Parameters:


        """
        return self.analysismodel.AdaptivityManager

    @property
    def analysis_cases(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisCases
                | o Property AnalysisCases(    ) As AnalysisCases
                | 
                | Returns the collection of analysis cases defined on the analysis
                | model.  Returns:  oAnalysisCases Collection of cases.


                | Parameters:


        """
        return self.analysismodel.AnalysisCases

    @property
    def analysis_sets(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisSets
                | o Property AnalysisSets(    ) As AnalysisSets
                | 
                | Returns the analysis sets collection associated with a analysis model.
                | Returns:  a collection of  CATIAAnalysisSets.


                | Parameters:


        """
        return self.analysismodel.AnalysisSets

    @property
    def mesh_manager(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MeshManager
                | o Property MeshManager(    ) As AnalysisMeshManager
                | 
                | Returns the MeshManager defined on the analysis model.  Returns:  a
                | CATIAAnalysisMeshManager.


                | Parameters:


        """
        return self.analysismodel.MeshManager

    @property
    def post_manager(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PostManager
                | o Property PostManager(    ) As AnalysisPostManager
                | 
                | Returns the Postprocessing  manager defined on the analysis model.
                | Returns:  oPostManager the AnalysisPostManager Object.


                | Parameters:


        """
        return self.analysismodel.PostManager

    def run_transition(self, i_transition_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunTransition
                | o Sub RunTransition(    CATBSTR    iTransitionName)
                | 
                | Apply a transition to the analysis model.


                | Parameters:
                | Transition
                |  name.


        """
        return self.analysismodel.RunTransition(i_transition_name)

