#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisDocument:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the document object for analysis.This objects is used for
                | all CAE applications to defines specifications and managed associated
                | results.The document for analysis data is typed as ".CATAnalysis".When
                | an analysis document object is created, an analysis manager is also
                | created.This analysis manager is the root object at the top of the
                | structure of the Analysis document.

    """

    def __init__(self, catia):
        self.analysisdocument = catia.AnalysisDocument     

    @property
    def analysis(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Analysis
                | o Property Analysis(    ) As AnalysisManager
                | 
                | Returns the root analysis object from the current analysis document.
                | Example:The following example returns in RootAnalysis the root
                | analysis object of the active document, assumed to be an analysis
                | document:  Dim AnalysisDocument As Document Set AnalysisDocument =
                | CATIA.ActiveDocument Dim RootAnalysis As AnalysisManager Set
                | RootAnalysis = AnalysisDocument.Analysis


                | Parameters:


        """
        return self.analysisdocument.Analysis

