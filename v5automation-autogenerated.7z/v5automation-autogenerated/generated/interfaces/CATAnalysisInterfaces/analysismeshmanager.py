#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisMeshManager:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAAnalysisMeshManager.

    """

    def __init__(self, catia):
        self.analysismeshmanager = catia.AnalysisMeshManager     

    @property
    def analysis_mesh_parts(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisMeshParts
                | o Property AnalysisMeshParts(    ) As AnalysisMeshParts
                | 
                | Returns the meshpart collection from the current analysis mesh
                | manager.


                | Parameters:


        """
        return self.analysismeshmanager.AnalysisMeshParts

