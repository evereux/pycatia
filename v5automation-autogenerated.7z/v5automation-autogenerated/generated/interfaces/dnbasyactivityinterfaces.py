#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DNBAsyActivityInterfaces:
    """
        .. note::
            CAA V5 Visual Basic help

                | Object Index

    """

    def __init__(self, catia):
        self.dnbasyactivityinterfaces = catia.DNBAsyActivityInterfaces     

