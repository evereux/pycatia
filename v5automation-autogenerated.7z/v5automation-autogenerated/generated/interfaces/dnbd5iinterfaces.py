#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DNBD5IInterfaces:
    """
        .. note::
            CAA V5 Visual Basic help

                | Object IndexEnumerated Index

    """

    def __init__(self, catia):
        self.dnbd5iinterfaces = catia.DNBD5IInterfaces     

