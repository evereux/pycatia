#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Point2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Class defining a point in 2D Space.

    """

    def __init__(self, catia):
        self.point2d = catia.Point2D     

    def get_coordinates(self, o_point):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCoordinates
                | o Sub GetCoordinates(    CATSafeArrayVariant    oPoint)
                | 
                | Returns the coordinates of the point


                | Parameters:
                | oPoint[0]
                |               The X Coordinate of the point
                |        
                |  oPoint[1]
                |               The Y Coordinate of the point


        """
        return self.point2d.GetCoordinates(o_point)

    def set_data(self, i_x, i_y):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetData
                | o Sub SetData(    double    iX,
                |                   double    iY)
                | 
                | Modifies the coordinates of the point


                | Parameters:
                | iX
                |                      The X Coordinate of the point
                |        
                |  iY
                |                      The Y Coordinate of the point


        """
        return self.point2d.SetData(i_x, i_y)

