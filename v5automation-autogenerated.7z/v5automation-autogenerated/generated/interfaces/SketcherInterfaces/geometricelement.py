#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class GeometricElement:
    """
        .. note::
            CAA V5 Visual Basic help

                | 2D or 3D wireframe geometric element.

    """

    def __init__(self, catia):
        self.geometricelement = catia.GeometricElement     

    @property
    def geometric_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GeometricType
                | o Property GeometricType(    ) As CatGeometricType
                | 
                | Returns the type of the underlying geometrical element


                | Parameters:
                | oType
                |        Specific type of the geometric interface


        """
        return self.geometricelement.GeometricType

