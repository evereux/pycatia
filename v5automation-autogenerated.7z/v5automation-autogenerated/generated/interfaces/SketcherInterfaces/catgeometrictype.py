#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatGeometricType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Enumeration for all types of possible geometrical elements.

    """

    def __init__(self, catia):
        self.catgeometrictype = catia.CatGeometricType     

