#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ControlPoint2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Class defining a spline control point in 2D Space.

    """

    def __init__(self, catia):
        self.controlpoint2d = catia.ControlPoint2D     

    @property
    def curvature(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Curvature
                | o Property Curvature(    ) As double
                | 
                | Returns the curvature properties of the spline control point


                | Parameters:
                | oCurvature
                |        The curvature of the tangent determined at the control point


        """
        return self.controlpoint2d.Curvature

    def get_tangent(self, o_tangent):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTangent
                | o Sub GetTangent(    CATSafeArrayVariant    oTangent)
                | 
                | Returns the tangent properties of the spline control point


                | Parameters:
                | oTangent[0]
                |        The X Coordinate of the tangent determined at the control point
                |        
                |  oTangent[1]
                |        The Y Coordinate of the tangent determined at the control point


        """
        return self.controlpoint2d.GetTangent(o_tangent)

    def set_tangent(self, i_tangent_x, i_tangent_y):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTangent
                | o Sub SetTangent(    double    iTangentX,
                |                      double    iTangentY)
                | 
                | Imposes the tangent properties of the spline control point


                | Parameters:
                | iTangentX
                |        The X Coordinate of the tangent determined at the control point
                |        
                |  iTangentY
                |        The Y Coordinate of the tangent determined at the control point


        """
        return self.controlpoint2d.SetTangent(i_tangent_x, i_tangent_y)

    def unset_curvature(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetCurvature
                | o Sub UnsetCurvature(    )
                | 
                | Unsets the curvature properties of the spline control point


                | Parameters:


        """
        return self.controlpoint2d.UnsetCurvature()

    def unset_tangent(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetTangent
                | o Sub UnsetTangent(    )
                | 
                | Unsets the tangent properties of the spline control point


                | Parameters:


        """
        return self.controlpoint2d.UnsetTangent()

