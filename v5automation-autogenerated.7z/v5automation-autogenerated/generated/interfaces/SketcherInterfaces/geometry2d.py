#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Geometry2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | 2D wireframe geometric element.

    """

    def __init__(self, catia):
        self.geometry2d = catia.Geometry2D     

    @property
    def construction(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Construction
                | o Property Construction(    ) As boolean
                | 
                | Returns the construction mode of the 2D geometry


                | Parameters:


        """
        return self.geometry2d.Construction

    @property
    def report_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReportName
                | o Property ReportName(    ) As long
                | 
                | Returns the report name of the 2D geometry


                | Parameters:
                | oReportName
                |        The integer value of the report name


        """
        return self.geometry2d.ReportName

