#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Parabola2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Class defining an parabola in 2D Space.

    """

    def __init__(self, catia):
        self.parabola2d = catia.Parabola2D     

    @property
    def focal_distance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FocalDistance
                | o Property FocalDistance(    ) As double
                | 
                | Returns the focal distance of the parabola in 2D space


                | Parameters:
                | oFocal
                |        The focal distance of the parabola


        """
        return self.parabola2d.FocalDistance

    def get_axis(self, o_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAxis
                | o Sub GetAxis(    CATSafeArrayVariant    oAxis)
                | 
                | Returns the axis vector direction of the parabola in 2D space


                | Parameters:
                | oAxis[0]
                |        The X coordinate of the axis vector direction
                |        
                |  oAxis[1]
                |        The Y coordinate of the axis vector direction


        """
        return self.parabola2d.GetAxis(o_axis)

    def get_center(self, o_center):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCenter
                | o Sub GetCenter(    CATSafeArrayVariant    oCenter)
                | 
                | Returns the center of the parabola in 2D space


                | Parameters:
                | oCenter[0]
                |        The X Coordinate of the center point of the parabola
                |        
                |  oCenter[1]
                |        The Y Coordinate of the center point of the parabola


        """
        return self.parabola2d.GetCenter(o_center)

    def set_data(self, i_center_x, i_center_y, i_axis_x, i_axis_y, i_focal_distance):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetData
                | o Sub SetData(    double    iCenterX,
                |                   double    iCenterY,
                |                   double    iAxisX,
                |                   double    iAxisY,
                |                   double    iFocalDistance)
                | 
                | Modifies the caracteristics of the parabola


                | Parameters:
                | iCenterX
                |        The X Coordinate of the parabola center
                |        
                |  iCenterY
                |        The Y Coordinate of the parabola center
                |        
                |  iAxisX
                |        The X coordinate of the axis vector direction
                |        
                |  iAxisY
                |        The Y coordinate of the axis vector direction
                |        
                |  iFocalDistance
                |        The focal distance of the parabola


        """
        return self.parabola2d.SetData(i_center_x, i_center_y, i_axis_x, i_axis_y, i_focal_distance)

