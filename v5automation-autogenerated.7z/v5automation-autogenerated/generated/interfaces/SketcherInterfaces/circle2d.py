#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Circle2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Class defining a circle in 2D Space.

    """

    def __init__(self, catia):
        self.circle2d = catia.Circle2D     

    @property
    def center_point(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CenterPoint
                | o Property CenterPoint(    ) As Point2D
                | 
                | Returns the center point of the circle.


                | Parameters:
                | oCenterPoint
                |           The center point of the circle


        """
        return self.circle2d.CenterPoint

    @property
    def radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Radius
                | o Property Radius(    ) As double
                | 
                | Returns the radius of the circle


                | Parameters:
                | oRadius
                |        The radius of the circle


        """
        return self.circle2d.Radius

    def get_center(self, o_data):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCenter
                | o Sub GetCenter(    CATSafeArrayVariant    oData)
                | 
                | Returns the center of the circle


                | Parameters:
                | oData[0]
                |        The X Coordinate of the circle center point
                |        
                |  oData[1]
                |        The Y Coordinate of the circle center point


                | Examples:
                | 
                | The following example reads the coordinates of the center
                | of the circle myCircle:
                | double center(1)
                | myCircle.GetCenter center
                | 
                | 
                | 
                | 
        """
        return self.circle2d.GetCenter(o_data)

    def set_data(self, i_center_x, i_center_y, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetData
                | o Sub SetData(    double    iCenterX,
                |                   double    iCenterY,
                |                   double    iRadius)
                | 
                | Modifies the caracteristics of the circle


                | Parameters:
                | iCenterX
                |                      The X Coordinate of the circle center
                |        
                |  iCenterY
                |        The Y Coordinate of the circle center
                |        
                |  iRadius
                |        The radius of the circle


        """
        return self.circle2d.SetData(i_center_x, i_center_y, i_radius)

