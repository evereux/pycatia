#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Axis2D:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface defining a coordinate system in the 2D Space.

    """

    def __init__(self, catia):
        self.axis2d = catia.Axis2D     

    @property
    def horizontal_reference(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HorizontalReference
                | o Property HorizontalReference(    ) As Line2D
                | 
                | Returns the 2D coordinate system horizontal axis.


                | Parameters:


        """
        return self.axis2d.HorizontalReference

    @property
    def origin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Origin
                | o Property Origin(    ) As Point2D
                | 
                | Returns the 2D coordinate system origin.


                | Parameters:


        """
        return self.axis2d.Origin

    @property
    def vertical_reference(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VerticalReference
                | o Property VerticalReference(    ) As Line2D
                | 
                | Returns the 2D coordinate system vertical axis.


                | Parameters:


        """
        return self.axis2d.VerticalReference

