#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5TemplateType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Template Type.Properties on the object helps the users to
                | get various templates and there possible ENOVIA Types.

    """

    def __init__(self, catia):
        self.cd5templatetype = catia.CD5TemplateType     

    @property
    def possible_types(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PossibleTypes
                | o Property PossibleTypes(    ) As CATSafeArrayVariant
                | 
                | Returns (gets) the possible Types from a Template type.  Example:
                | The following example gets Possible ENOVIA Types from a Template type.
                | Dim oPossibleTypes As Array oPossibleTypes =
                | oTemplateType.PossibleTypes


                | Parameters:


        """
        return self.cd5templatetype.PossibleTypes

    @property
    def template_type_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TemplateTypeName
                | o Property TemplateTypeName(    ) As CATBSTR
                | 
                | Returns (gets) the name of the Template Type.  Example:    The
                | following example gets the name of the Template Type.  Dim oName As
                | CATBSTR oName = oTemplateType.TemplateTypeName


                | Parameters:


        """
        return self.cd5templatetype.TemplateTypeName

    @property
    def templates(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Templates
                | o Property Templates(    ) As CD5Templates
                | 
                | Returns (gets) the list of Templates from a Template type.  Example:
                | The following example gets Templates.  Dim oTemplates As
                | ENOIACD5Templates Set oTemplates = oTemplateType.Templates


                | Parameters:


        """
        return self.cd5templatetype.Templates

