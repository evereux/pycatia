#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5Properties:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a collection of all the properties of an ENOVIA V6
                | object.Role: It represents all the properties of a given
                | object/document already saved into ENOVIA. The purpose of this
                | interface is to get a collection of an ENOVIA V6 object properties.
                | The properties are accessible through Edit/Properties menu item after
                | user has clicked the More button It is managed
                | byactivateLinkAnchor('CD5Engine','','CD5Engine').

    """

    def __init__(self, catia):
        self.cd5properties = catia.CD5Properties     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As CD5Property
                | 
                | Returns ENOVIA V6 object property specified by 1 based index. That is,
                | 1th index is the first property ergo last property is (Total Count)th
                | Index  Throws: -1641847650 : Connection to ENOVIA V6 is necessary to
                | intialize this option. Example:    The following example shows how to
                | retrieve a single property from the collection of all properties.  Dim
                | objCD5Property As CD5Property Set objCD5Property =
                | objCD5Properties.Item(1)


                | Parameters:


        """
        return self.cd5properties.Item(i_index)

