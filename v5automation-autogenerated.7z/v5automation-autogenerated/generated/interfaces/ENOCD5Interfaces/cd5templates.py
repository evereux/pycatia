#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5Templates:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a List of all Templates from a Template type.

    """

    def __init__(self, catia):
        self.cd5templates = catia.CD5Templates     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As CD5Template
                | 
                | Returns (gets) an item from the list of items.  Example:    The
                | following example gets a Template at index 1.  Dim oTemplate As
                | ENOIACD5Template Set oTemplate = oTemplates.Item(1)


                | Parameters:


        """
        return self.cd5templates.Item(i_index)

