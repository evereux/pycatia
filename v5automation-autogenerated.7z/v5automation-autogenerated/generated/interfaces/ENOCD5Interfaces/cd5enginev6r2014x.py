#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5EngineV6R2014x:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the ENOVIA V6 Integration Engine, that is to say the entry
                | point to the CATIA/ENOVIA V6 Integration.It allows end user to realize
                | ENOVIA V6 Integration operations such as Connection, Disconnection,
                | Open, Save...Note that all operations performed from this interface
                | are the same as operations available in the   ENOVIA V6 menu in CATIA,
                | unless most of them are executed without panel.

    """

    def __init__(self, catia):
        self.cd5enginev6r2014x = catia.CD5EngineV6R2014x     

    def create_save_operation(self, i_scope):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSaveOperation
                | o Func CreateSaveOperation(    CD5SaveOperation_Scope    iScope) As CD5SaveOperation
                | 
                | Creates the basic Save Operation object. It requires ENOVIA V6
                | connection.


                | Parameters:
                | iScope
                |  The scope of the Save Operation.
                |  
                | 
                |  Returns:
                |   The created Save Operation.
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.


                | Examples:
                | 
                | The following example creates a Save Operation with the whole session as scope on CD5Engine oCD5Engine:
                | 
                | Dim SaveOperation As CD5SaveOperation
                | Set SaveOperation = oCD5Engine.CreateSaveOperation(CD5SaveOperation_Session)
                | 
                | 
                | 
        """
        return self.cd5enginev6r2014x.CreateSaveOperation(i_scope)

    def generate_autoname(self, i_autoname_series, i_count):
        """
        .. note::
            CAA V5 Visual Basic help

                | GenerateAutoname
                | o Func GenerateAutoname(    CATBSTR    iAutonameSeries,
                |                             short    iCount) As CATSafeArrayVariant
                | 
                | Generates and gets the Autonames for the given series. It requires
                | ENOVIA V6 connection.


                | Parameters:
                | iAutonameSeries
                |  The Autoname Series for which we want to generate Autonames.
                |  
                |  iCount
                |  The number of Autonames to be generated.
                |  
                | 
                |  Returns:
                |   The array of generated Autonames.
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.


                | Examples:
                | 
                | The following example generates and gets 1 Autoname for series "A Size":
                | 
                | Dim Autoname As CATBSTR
                | Autoname = oCD5Engine.GenerateAutoname("A Size", 1)(0)
                | 
                | 
                | 
        """
        return self.cd5enginev6r2014x.GenerateAutoname(i_autoname_series, i_count)

    def get_autoname_series(self, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutonameSeries
                | o Func GetAutonameSeries(    CATBSTR    iType) As CATSafeArrayVariant
                | 
                | Gets the Autoname Series for an input type. It requires ENOVIA V6
                | connection.


                | Parameters:
                | iType
                |  The ENOVIA type of the Object ("CATIA Embedded Component"...).
                |  
                | 
                |  Returns:
                |   The array of Autoname Series.
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.


                | Examples:
                | 
                | The following example gets autoname series for CATIA Embedded Component:
                | 
                | Dim AutonameSeries As CATSafeArrayVariant
                | AutonameSeries = oCD5Engine.GetAutonameSeries("CATIA Embedded Component")
                | 
                | 
                | 
        """
        return self.cd5enginev6r2014x.GetAutonameSeries(i_type)

