#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5SaveItem:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a save object which user is trying to save.Various
                | properties on the object help the end-user to customize each object
                | individually.

    """

    def __init__(self, catia):
        self.cd5saveitem = catia.CD5SaveItem     

    @property
    def cd5_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CD5ID
                | o Property CD5ID(    ) As CD5ID
                | 
                | Returns (gets) the CD5ID for a save item.  Example:    The following
                | example gets CD5ID from a save item.  Dim myID As CD5ID Set myID =
                | oSaveItem.CD5ID


                | Parameters:


        """
        return self.cd5saveitem.CD5ID

    @property
    def derived_outputs(self, derived_outputs):
        """
        .. note::
            CAA V5 Visual Basic help

                | DerivedOutputs
                | o Property DerivedOutputs(    CATSafeArrayVariant    DerivedOutputs)
                | 
                | Returns (gets) or sets the Derived Outputs for a save item.  Example:
                | The following example sets Derived Outputs from a save item.  Dim
                | iDerivedOutputs(1) As CATBSTR iDerivedOutputs(0) = "cgrOutput"
                | oSaveItem.DerivedOutputs = iDerivedOutputs


                | Parameters:


        """
        return self.cd5saveitem.DerivedOutputs

    @property
    def included(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Included
                | o Property Included(    ) As boolean
                | 
                | Returns (gets) or sets whether item should be included in the Save
                | Operation. The default value is determined by the status of the item.
                | Objects with status "Exists" are not selected by default.  Example:
                | The following example includes the item for the Save operation.
                | oSaveItem.Included = True


                | Parameters:


        """
        return self.cd5saveitem.Included

    @property
    def next_revision(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NextRevision
                | o Property NextRevision(    ) As CATBSTR
                | 
                | Returns the next combined revision and version string for this
                | CD5SaveItem. If next revision of the item is to be created, then
                | CD5SaveItem.Revision may be set to this value.  Example:    The
                | following example gets the NextRevision of the item.
                | CD5SaveItem.Revision = CD5SaveItem.NextRevision


                | Parameters:


        """
        return self.cd5saveitem.NextRevision

    @property
    def object_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ObjectName
                | o Property ObjectName(    ) As CATBSTR
                | 
                | Returns (gets) or sets the value of the ENOVIA Object Name.  Example:
                | The following example sets the Object Name.  oSaveItem.ObjectName =
                | "MyPart"


                | Parameters:


        """
        return self.cd5saveitem.ObjectName

    @property
    def possible_derived_outputs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PossibleDerivedOutputs
                | o Property PossibleDerivedOutputs(    ) As CATSafeArrayVariant
                | 
                | Returns (gets) the possible Derived Outputs for a save item.  Example:
                | The following example gets Possible DerivedOutputs from a save item.
                | Dim oPossibleDerivedOutputs As CATSafeArrayVariant
                | oPossibleDerivedOutputs = oSaveItem.PossibleDerivedOutputs


                | Parameters:


        """
        return self.cd5saveitem.PossibleDerivedOutputs

    @property
    def possible_types(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PossibleTypes
                | o Property PossibleTypes(    ) As CATSafeArrayVariant
                | 
                | Returns (gets) the possible Types for a save item.  Example:    The
                | following example gets PossibleTypes from a save item.  Dim
                | oPossibleTypes As CATSafeArrayVariant oPossibleTypes =
                | oSaveItem.PossibleTypes


                | Parameters:


        """
        return self.cd5saveitem.PossibleTypes

    @property
    def revision(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Revision
                | o Property Revision(    ) As CATBSTR
                | 
                | Returns or sets the target revision of the CD5SaveItem for the Save
                | Operation. Default value is current CD5SaveItem target revision. Get:
                | will return string combining revision and version (ex: B.3). Set:
                | will keep the revision string only (e.g. "A", "BB"), even if combining
                | revision and version is passed. Note: As revision part of the string
                | cannot contain . character, given string may be truncated up to the
                | first  . character before being appended with appropriate version
                | number. (ex: MyItem.Revision = AA.BB => property is set to AA.0)
                | It is advised to read the Revision property after it has been set as
                | the current value may not match what has been set.  Changing the
                | CD5SaveOperation.CreateVersion value may affect the version part of
                | this property.  Example:    The following example gets the targeted
                | Revision for the item.  Dim oRevision As CATBSTR oRevision =
                | CD5SaveItem.Revision o Property Status() As
                | activateLink('CD5SaveItem_Status','CD5SaveItem_Status')  (Read Only)
                | Returns (gets) the Save status of the item.  Example:    The following
                | example gets item Status.  Dim itemStatus As CD5SaveItem_Status
                | itemStatus = oSaveItem.Status  o Property Type() As
                | activateLink('CATBSTR','CATBSTR')  Returns (gets) or sets the Type of
                | the item. The default value is picked from the GCO. To set a type user
                | can get the list of Possible Types from PossibleTypes property
                | Example:    The following example gets the type of the item.  Dim
                | oType As CATBSTR oType = oSaveItem.Type Copyright © 1999-2011,
                | Dassault Systèmes. All rights reserved.


                | Parameters:


        """
        return self.cd5saveitem.Revision

    @property
    def status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Status
                | o Property Status(    ) As CD5SaveItem_Status
                | 
                | Returns (gets) the Save status of the item.  Example:    The following
                | example gets item Status.  Dim itemStatus As CD5SaveItem_Status
                | itemStatus = oSaveItem.Status


                | Parameters:


        """
        return self.cd5saveitem.Status

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns (gets) or sets the Type of the item. The default value is
                | picked from the GCO. To set a type user can get the list of Possible
                | Types from PossibleTypes property  Example:    The following example
                | gets the type of the item.  Dim oType As CATBSTR oType =
                | oSaveItem.Type


                | Parameters:


        """
        return self.cd5saveitem.Type

