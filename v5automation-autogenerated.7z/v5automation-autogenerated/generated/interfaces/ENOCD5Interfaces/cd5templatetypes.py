#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5TemplateTypes:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a List of all Template types.

    """

    def __init__(self, catia):
        self.cd5templatetypes = catia.CD5TemplateTypes     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As CD5TemplateType
                | 
                | Returns (gets) an item from the list of items.  Example:    The
                | following example gets a Template Type at index 1.  Dim oTemplateType
                | As ENOIACD5TemplateType Set oTemplateType = oTemplateTypes.Item(1)


                | Parameters:


        """
        return self.cd5templatetypes.Item(i_index)

