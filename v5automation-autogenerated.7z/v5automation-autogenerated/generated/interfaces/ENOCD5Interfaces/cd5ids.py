#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5IDs:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a list of ENOVIA V6 Integration identifier(CD5ID).

    """

    def __init__(self, catia):
        self.cd5ids = catia.CD5IDs     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As CD5ID
                | 
                | Returns (gets) CD5ID from the list of ids.  Example:    The following
                | example gets a CD5ID at index 1.  Dim oID As ENOIACD5ID Set oID =
                | CD5IDs.Item(1)


                | Parameters:


        """
        return self.cd5ids.Item(i_index)

