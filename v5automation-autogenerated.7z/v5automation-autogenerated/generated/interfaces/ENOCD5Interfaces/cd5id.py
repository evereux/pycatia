#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5ID:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the ENOVIA V6 Integration identifier.Role: It identifies an
                | ENOVIA V6 Object thanks to its Type/Name/Revision(/Version). It is
                | managed byactivateLinkAnchor('CD5Engine','','CD5Engine').

    """

    def __init__(self, catia):
        self.cd5id = catia.CD5ID     

    def get_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetID
                | o Func GetID(    ) As CATBSTR
                | 
                | Returns the Identifier of the ENOVIA V6 Object associated to the
                | CD5ID.  Returns:   The identifier String of the ENOIACD5ID.
                | Example:    The following example returns in oID the identifier
                | corresponding to the CD5ID oCD5ID.  Dim oCD5Engine As CD5Engine Set
                | oCD5Engine = CATIA.GetItem("CD5Engine") Dim oCD5ID As CD5ID Set oCD5ID
                | = oCD5Engine.GetIDFromTNR("CATProduct For Team", "MyProduct", "---")
                | Dim oID As CATBSTR oID = oCD5ID.GetID


                | Parameters:


        """
        return self.cd5id.GetID()

