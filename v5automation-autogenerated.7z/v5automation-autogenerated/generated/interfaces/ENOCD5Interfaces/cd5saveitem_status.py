#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5SaveItem_Status:
    """
        .. note::
            CAA V5 Visual Basic help

                | Status of the Object.It represents the status of the object in ENOVIA.

    """

    def __init__(self, catia):
        self.cd5saveitem_status = catia.CD5SaveItem_Status     

