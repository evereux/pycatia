#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5Property:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a single property of an ENOVIA V6 object.Role: It
                | represents a single property tuple of a given object/document already
                | saved into ENOVIA. The purpose of this interface is to get the
                | information of a given property of an ENOVIA V6 object. The properties
                | are accessible through Edit/Properties menu item after user has
                | clicked the More button

    """

    def __init__(self, catia):
        self.cd5property = catia.CD5Property     

    @property
    def property_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PropertyName
                | o Property PropertyName(    ) As CATBSTR
                | 
                | Returns (gets) the name of the ENOVIA V6 object property. This is a
                | readonly property.  Throws: -1641847650 : Connection to ENOVIA V6 is
                | necessary to intialize this option. Example:    The following example
                | retrieves Property Name  oCD5Property.PropertyName


                | Parameters:


        """
        return self.cd5property.PropertyName

    @property
    def property_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PropertyValue
                | o Property PropertyValue(    ) As CATBSTR
                | 
                | Returns (gets) the value of the ENOVIA V6 object property. This is a
                | readonly property.  Throws: -1641847650 : Connection to ENOVIA V6 is
                | necessary to intialize this option. Example:    The following example
                | retrieves Property Value  oCD5Property.PropertyValue


                | Parameters:


        """
        return self.cd5property.PropertyValue

