#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5Structure:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the structure of an ENOVIA V6 object.Role: It represents
                | the structure of an ENOVIA V6 root object on which it is possible to
                | include some sub components. Its final purpose is to perform a Partial
                | Open on it, showing only the root and the sub components that were
                | previously included.  It is managed
                | byactivateLinkAnchor('CD5Engine','','CD5Engine').

    """

    def __init__(self, catia):
        self.cd5structure = catia.CD5Structure     

    def get_root(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRoot
                | o Func GetRoot(    ) As CD5ID
                | 
                | Returns the root ENOVIA V6 Identifier of the CD5Structure.  Returns:
                | The CD5ID.    Example:    The following example creates a Structure
                | from "RootProduct" and gets its root identifier.  Dim oCD5Engine As
                | CD5Engine Set oCD5Engine = CATIA.GetItem("CD5Engine") Dim iRootCD5ID,
                | oDummyCD5ID As CD5ID Set iRootCD5ID =
                | oCD5Engine.GetIDFromTNR("CATProduct For Team", "RootProduct", "---")
                | Dim oCD5Structure As CD5Structure Set oCD5Structure =
                | oCD5Engine.GetStructure(iRootCD5ID) Set oDummyCD5ID =
                | oCD5Structure.GetRoot()


                | Parameters:


        """
        return self.cd5structure.GetRoot()

    def include(self, i_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | Include
                | o Sub Include(    CD5ID    iID)
                | 
                | Includes an sub component (identified by its ENOVIA V6 Identifier) for
                | a future Partial Open operation.


                | Parameters:
                | iID
                |  The ENOIACD5ID of the sub component to include.


                | Examples:
                | 
                | The following example creates a Structure from "RootProduct" and includes the object "IncludedPart".
                | 
                | Dim oCD5Engine As CD5Engine
                | Set oCD5Engine = CATIA.GetItem("CD5Engine")
                | Dim iRootCD5ID, iIncludedCD5ID As CD5ID
                | Set iRootCD5ID = oCD5Engine.GetIDFromTNR("CATProduct For Team", "RootProduct", "---")
                | Set iIncludedCD5ID = oCD5Engine.GetIDFromTNR("CATProduct For Team", "IncludedPart", "---")
                | Dim oCD5Structure As CD5Structure
                | Set oCD5Structure = oCD5Engine.GetStructure(iRootCD5ID)
                | oCD5Structure.Include(iIncludedCD5ID)
                | 
                | 
                | 
        """
        return self.cd5structure.Include(i_id)

