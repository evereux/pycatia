#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5SaveItems:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Collection of items which user is trying to save.

    """

    def __init__(self, catia):
        self.cd5saveitems = catia.CD5SaveItems     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As CD5SaveItem
                | 
                | Returns (gets) an item from the list of items in the current save
                | scope. First item is at index 1.  Example:    The following example
                | gets a SaveItem at index 1.  Dim oSaveItem As CD5SaveItem Set
                | oSaveItem = oSaveItems.Item(1)


                | Parameters:


        """
        return self.cd5saveitems.Item(i_index)

