#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CD5SaveOperation_Scope:
    """
        .. note::
            CAA V5 Visual Basic help

                | Scope of the Save Operation.It is used by the CreateSaveOperation
                | function.

    """

    def __init__(self, catia):
        self.cd5saveoperation_scope = catia.CD5SaveOperation_Scope     

