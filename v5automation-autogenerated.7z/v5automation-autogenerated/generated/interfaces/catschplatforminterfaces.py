#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATSchPlatformInterfaces:
    """
        .. note::
            CAA V5 Visual Basic help

                | Object IndexEnumerated Index

    """

    def __init__(self, catia):
        self.catschplatforminterfaces = catia.CATSchPlatformInterfaces     

