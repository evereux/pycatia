#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Publication:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAPublication.

    """

    def __init__(self, catia):
        self.publication = catia.Publication     

    @property
    def relay(self, i_pub):
        """
        .. note::
            CAA V5 Visual Basic help

                | Relay
                | o Property Relay(    Publication    iPub) (Write Only)
                | 
                | Valuates a publication object with another publication object.  Role:
                | This method allows to valuate a publication with an intermediate one.


                | Parameters:
                | iPub
                |       The intermediate publication object


                | Examples:
                | 
                | The following example valuates the publication object Pub1
                | with the publication object Pub2
                | 
                | Pub1.Relay(Pub2)
                | 
                | 
                | 
                | 
                | 
        """
        return self.publication.Relay

    @property
    def valuation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Valuation
                | o Property Valuation(    ) As CATBaseDispatch
                | 
                | Returns published object.  Role:  This method gives access to the
                | finally published object.


                | Parameters:
                | oRef
                |       The final reference of the publication object.


                | Examples:
                | 
                | This example returns the final reference Ref
                | of the publication object Pub1.
                | 
                | Dim Ref As Reference
                | Ref = Pub1.Valuation
                | 
                | 
                | 
                | 
                | 
        """
        return self.publication.Valuation

