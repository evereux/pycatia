#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ProductDocument:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Document object for product structures.When a
                | ProductDocument is created, a root product is created whose parent is
                | the ProductDocument object. Its default name is RootProduct, which can
                | be overwritten thanks to the
                | theactivateLinkAnchor('AnyObject','Name','AnyObject.Name')property.
                | This root product is at the top of the product tree structure
                | contained in the document. It has no difference with the other
                | contained products, except it has no father product in the product
                | tree structure within the document.

    """

    def __init__(self, catia):
        self.productdocument = catia.ProductDocument     

    @property
    def product(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Product
                | o Property Product(    ) As Product
                | 
                | Returns the root product.  Example:    This example retrieves the root
                | product of the MyProductDoc ProductDocument in RootProduct.  Dim
                | RootProduct As Product Set RootProduct = MyProductDoc.Product


                | Parameters:


        """
        return self.productdocument.Product

