#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AssemblyConvertor:
    """
        .. note::
            CAA V5 Visual Basic help

                | Product conversion object.The AssemblyConvertor is the object that
                | allows saving an assembly  to a specified format. Two objects exist
                | from now on :BillOfMaterial, which creates a bill of material (every
                | sub-assembly is represented, with all the one level depth components),
                | andListingReport, which creates a listing report (shows the product
                | structure as it appears in the graph)

    """

    def __init__(self, catia):
        self.assemblyconvertor = catia.AssemblyConvertor     

    def print(self, i_file_type, i_file, i_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | Print
                | o Sub Print(    CATBSTR    iFileType,
                |                 CATBSTR    iFile,
                |                 Product    iProduct)
                | 
                | Extracts the product's contents as a specified format. Saves it in a
                | txt, html or xls file (depends of the object).


                | Parameters:
                | iFileType
                |     Type of the resulting file : TXT (for text file),
                |     HTML (for html file), XLS (for xls file)
                |     or MOTIF (do not use).
                |  
                |  iFile
                |     Path of the resulting file 
                |  
                |  iProduct
                |     Product that will be converted


        """
        return self.assemblyconvertor.Print(i_file_type, i_file, i_product)

    def set_current_format(self, ilist_props):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCurrentFormat
                | o Sub SetCurrentFormat(    CATSafeArrayVariant    ilistProps)
                | 
                | Defines the properties that will be used in the print method.


                | Parameters:
                | ilistProps
                |    list of properties to display


        """
        return self.assemblyconvertor.SetCurrentFormat(ilist_props)

    def set_secondary_format(self, ilist_props):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSecondaryFormat
                | o Sub SetSecondaryFormat(    CATSafeArrayVariant    ilistProps)
                | 
                | Defines the secondary properties that will be used in the print
                | method.


                | Parameters:
                | ilistProps
                |    secondary list of properties to display


        """
        return self.assemblyconvertor.SetSecondaryFormat(ilist_props)

