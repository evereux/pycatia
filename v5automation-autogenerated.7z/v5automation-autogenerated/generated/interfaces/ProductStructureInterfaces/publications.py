#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Publications:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of the Product publications.A Product object can
                | aggregate one or zero Publications collection.

    """

    def __init__(self, catia):
        self.publications = catia.Publications     

    def add(self, i_public_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    CATBSTR    iPublicName) As Publication
                | 
                | Adds a publication object to the product and returns a pointer to the
                | publication object.


                | Parameters:
                | iPublicName
                |        The name of the publication
                |  
                |  oPub
                |        The publication object


                | Examples:
                | 
                | The following example adds a new publication object with the name "PubName"
                | to the product and returns the publication object Pub1.
                | 
                | Dim Prod1 As Product
                | Set Pub1 = Prod1.Add(PubName)
                | 
                | 
                | 
                | 
                | 
        """
        return self.publications.Add(i_public_name)

    def item(self, i_identifier):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIdentifier) As Publication
                | 
                | Returns the publication object corresponding to the given publication
                | name.


                | Parameters:
                | iIdentifier
                |        The name of the publication
                |  
                |  oPub
                |        The publication object


                | Examples:
                | 
                | The following example returns Pub1 publication object from
                | the product referencing the published name PubId.
                | 
                | Dim Prod1 As Product
                | Set Pub1 = Prod1.Item(PubId)
                | 
                | 
                | 
                | 
                | 
        """
        return self.publications.Item(i_identifier)

    def remove(self, i_identifier):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATBSTR    iIdentifier)
                | 
                | Removes a publication from the product.


                | Parameters:
                | iIdentifier
                |        The name of the publication


                | Examples:
                | 
                | The following example removes the publication object corresponding to the name
                | PubId.
                | 
                | Dim Prod1 As Product
                | Prod1.Remove(PubId)
                | 
                | 
                | 
                | 
                | 
        """
        return self.publications.Remove(i_identifier)

    def set_direct(self, i_identifier, i_pointed):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDirect
                | o Sub SetDirect(    CATVariant    iIdentifier,
                |                     Reference    iPointed)
                | 
                | Valuates a publication object directly with the object it publishes.


                | Parameters:
                | iIdentifier
                |        The name of the publication
                |  
                |  iPointed
                |        The published object
                |        The following 
                | 
                |  activateLinkAnchor('Boundary','','Boundary')  objects is supported: 
                |  activateLinkAnchor('Boundary','','Boundary')


                | Examples:
                | 
                | The following example valuates the publication object of product Prod1
                | having the name PubId with the reference object RefObject.
                | 
                | Dim Prod1 As Product
                | Prod1.SetDirect(PubId,RefObject)
                | 
                | 
                | 
                | 
        """
        return self.publications.SetDirect(i_identifier, i_pointed)

    def set_relay(self, i_identifier, i_relayer, i_name_in_relay):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRelay
                | o Sub SetRelay(    CATVariant    iIdentifier,
                |                    Publications    iRelayer,
                |                    CATVariant    iNameInRelay)
                | 
                | Valuates a publication object with another publication object.


                | Parameters:
                | iIdentifier
                |        The name of the publication to be valuated
                |  
                |  iRelayer
                |        The product aggregating the valuating intermediate publication object
                |  
                |  iNameInRelay
                |        The name of the valuating publication object


                | Examples:
                | 
                | The following example valuates the publication object of product Prod1
                | having the name PubId1 with the publication object of product Prod2
                | having the name PubId2.
                | 
                | Dim Prod1 As Product
                | Prod1.SetRelay(PubId1,Prod2,PubId2)
                | 
                | 
                | 
                | 
                | 
        """
        return self.publications.SetRelay(i_identifier, i_relayer, i_name_in_relay)

