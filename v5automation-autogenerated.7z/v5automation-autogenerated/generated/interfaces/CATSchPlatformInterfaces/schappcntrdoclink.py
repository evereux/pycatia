#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppCntrDocLink:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a schematic connector.

    """

    def __init__(self, catia):
        self.schappcntrdoclink = catia.SchAppCntrDocLink     

    def app_get_link(self, o_l_cntrs, o_l_document_names, o_publication_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppGetLink
                | o Sub AppGetLink(    SchListOfObjects    oLCntrs,
                |                      SchListOfBSTRs    oLDocumentNames,
                |                      CATBSTR    oPublicationName)
                | 
                | Deprecated:  V5R18  Use  activateLinkAnchor('SchAppCntrDocLink','AppGe
                | tLinkedDocs','SchAppCntrDocLink.AppGetLinkedDocs')  instead. Get a
                | list of linked connector(s) and its document names or publication
                | name.


                | Parameters:
                | oLCntrs
                |    A list of connectors that are linked to this connector.
                |  
                |  oLDocumentNames
                |    A list of document names containing the linked connector.
                |  
                |  oPublicationName
                |    The publication name of the connector(s) linked to this connector.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrDocLink
                | Dim objArg1 As SchListOfObjects
                | Dim objArg2 As SchListOfBSTRs
                | Dim strVar3 As String
                | ...
                | objThisIntf.AppGetLinkobjArg1,objArg2,strVar3
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdoclink.AppGetLink(o_l_cntrs, o_l_document_names, o_publication_name)

    def app_get_linked_docs(self, o_publication_name, o_l_document_name, o_l_document_uuid, o_l_open_status, o_l_cntr):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppGetLinkedDocs
                | o Sub AppGetLinkedDocs(    CATBSTR    oPublicationName,
                |                            SchListOfBSTRs    oLDocumentName,
                |                            SchListOfBSTRs    oLDocumentUuid,
                |                            SchListOfLongs    oLOpenStatus,
                |                            SchListOfObjects    oLCntr)
                | 
                | Get a list of linked connectors, their documents' names, uuids, and
                | 'open in session' statuses, and a publication name of the connectors.


                | Parameters:
                | oPublicationName
                |    The publication name of the connector(s) linked to this connector.
                |  
                |  oLDocumentName
                |    A list of document names of the documents containing the linked connector(s).
                |  
                |  oLDocumentUuid
                |    A list of document UUIDs of the documents containing the linked connector(s).
                |  
                |  oLOpenStatus
                |    A list of integer flags specifying whether a linked document is open 
                |    in the session or not (1 - yes; 0 - no).
                |  
                |  oLCntr
                |    A list of connectors that are linked to this connector.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrDocLink
                | Dim strVar1 As String
                | Dim objArg2 As SchListOfBSTRs
                | Dim objArg3 As SchListOfBSTRs
                | Dim objArg4 As SchListOfLongs
                | Dim objArg5 As SchListOfObjects
                | ...
                | objThisIntf.AppGetLinkedDocsstrVar1,objArg2,objArg3,objArg4,objArg5
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdoclink.AppGetLinkedDocs(o_publication_name, o_l_document_name, o_l_document_uuid, o_l_open_status, o_l_cntr)

    def app_is_linkable(self, i_sch_connector, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppIsLinkable
                | o Sub AppIsLinkable(    SchAppConnector    iSchConnector,
                |                         boolean    oBYes)
                | 
                | Query whether this connector and input connector can be linked.


                | Parameters:
                | iSchConnector
                |    The connector to link to.
                |  
                |  oBYes
                |    If TRUE, connectors can be linked.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrDocLink
                | Dim objArg1 As SchAppConnector
                | Dim bVar2 As boolean
                | ...
                | objThisIntf.AppIsLinkableobjArg1,bVar2
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdoclink.AppIsLinkable(i_sch_connector, o_b_yes)

    def app_link(self, i_sch_connector):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppLink
                | o Sub AppLink(    SchAppConnector    iSchConnector)
                | 
                | Create an external link to another connector.


                | Parameters:
                | iSchConnector
                |    The connector to link to.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrDocLink
                | Dim objArg1 As SchAppConnector
                | ...
                | objThisIntf.AppLinkobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdoclink.AppLink(i_sch_connector)

    def app_link_init(self, i_publication_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppLinkInit
                | o Sub AppLinkInit(    CATBSTR    iPublicationName)
                | 
                | Publish this connector to make it available for linking.


                | Parameters:
                | iPublicationName
                |    The publication name of connector.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrDocLink
                | Dim strVar1 As String
                | ...
                | objThisIntf.AppLinkInitstrVar1
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdoclink.AppLinkInit(i_publication_name)

    def app_open_linked_doc(self, i_document_name, i_document_uuid, o_document):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppOpenLinkedDoc
                | o Sub AppOpenLinkedDoc(    CATBSTR    iDocumentName,
                |                            CATBSTR    iDocumentUuid,
                |                            Document    oDocument)
                | 
                | Open a linked document.


                | Parameters:
                | iDocumentName
                |    Name of the document (from oLDocumentName list in AppGetLinkedDocs).
                |  
                |  iDocumentUuid
                |    Uuid of the document (from oLDocumentUuid list in AppGetLinkedDocs).
                |  
                |  oDocument
                |    Pointer to the document.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrDocLink
                | Dim strVar1 As String
                | Dim strVar2 As String
                | Dim objArg3 As Document
                | ...
                | objThisIntf.AppOpenLinkedDocstrVar1,strVar2,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdoclink.AppOpenLinkedDoc(i_document_name, i_document_uuid, o_document)

    def app_un_link(self, i_unpublish):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppUnLink
                | o Sub AppUnLink(    long    iUnpublish)
                | 
                | Remove external link to another connector.


                | Parameters:
                | iUnpublish
                |    iUnpublish = 0, do not delete publication connector (default)
                |    iUnpublish > 0, delete publication connector


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrDocLink
                | Dim intVar1 As Integer
                | ...
                | objThisIntf.AppUnLinkintVar1
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdoclink.AppUnLink(i_unpublish)

