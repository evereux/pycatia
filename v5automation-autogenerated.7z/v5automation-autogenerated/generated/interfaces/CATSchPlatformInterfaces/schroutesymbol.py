#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchRouteSymbol:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a symbol placed on a route.

    """

    def __init__(self, catia):
        self.schroutesymbol = catia.SchRouteSymbol     

    def flip_over_line(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlipOverLine
                | o Sub FlipOverLine(    )
                | 
                | Mirror the symbol over the route segment line on which the symbol is
                | positioned.  Example:     Dim objThisIntf As SchRouteSymbol  ...
                | objThisIntf.FlipOverLine


                | Parameters:


        """
        return self.schroutesymbol.FlipOverLine()

    def flip_over_orthogonal_line(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlipOverOrthogonalLine
                | o Sub FlipOverOrthogonalLine(    )
                | 
                | Mirror the symbol over the line orthogonal to the route segment line
                | on which the symbol is positioned and going through the symbol's
                | position point on that segment line.  Example:     Dim objThisIntf As
                | SchRouteSymbol  ... objThisIntf.FlipOverOrthogonalLine


                | Parameters:


        """
        return self.schroutesymbol.FlipOverOrthogonalLine()

    def get_grr_route(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGRRRoute
                | o Func GetGRRRoute(    ) As SchGRRRoute
                | 
                | Get the graphical representation of a schematic route that owns this
                | symbol.


                | Parameters:
                | oGRRRoute
                |    The graphical representation that owns this symbol.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRouteSymbol
                | Dim objArg1 As SchGRRRoute
                | ...
                | Set objArg1 = objThisIntf.GetGRRRoute
                | 
                | 
                | 
                | 
        """
        return self.schroutesymbol.GetGRRRoute()

    def get_position(self, o_seg_num, o_seg_parm):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPosition
                | o Sub GetPosition(    long    oSegNum,
                |                       double    oSegParm)
                | 
                | Get the symbol's position on the route that own it.


                | Parameters:
                | oSegNum
                |    The route segment number.
                |  
                |  oSegParm
                |    The parameter along the segment.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRouteSymbol
                | Dim intVar1 As Integer
                | Dim dbVar2 As Double
                | ...
                | objThisIntf.GetPositionintVar1,dbVar2
                | 
                | 
                | 
                | 
        """
        return self.schroutesymbol.GetPosition(o_seg_num, o_seg_parm)

    def scale(self, i_db_scale_factor):
        """
        .. note::
            CAA V5 Visual Basic help

                | Scale
                | o Sub Scale(    double    iDbScaleFactor)
                | 
                | Scale the symbol.


                | Parameters:
                | iDbScaleFactor
                |    The scale factor to scale the symbol by.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRouteSymbol
                | Dim dbVar1 As Double
                | ...
                | objThisIntf.ScaledbVar1
                | 
                | 
                | 
                | 
        """
        return self.schroutesymbol.Scale(i_db_scale_factor)

    def set_position(self, i_seg_num, i_seg_parm):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPosition
                | o Sub SetPosition(    long    iSegNum,
                |                       double    iSegParm)
                | 
                | Set the symbol's position on the route that own it.


                | Parameters:
                | iSegNum
                |    The route segment number (<= number of segments in the route).
                |  
                |  iSegParm
                |    The parameter along the segment (0.<=iSegParm<=1.).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRouteSymbol
                | Dim intVar1 As Integer
                | Dim dbVar2 As Double
                | ...
                | objThisIntf.SetPositionintVar1,dbVar2
                | 
                | 
                | 
                | 
        """
        return self.schroutesymbol.SetPosition(i_seg_num, i_seg_parm)

