#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppZone:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a schematic zone.

    """

    def __init__(self, catia):
        self.schappzone = catia.SchAppZone     

    def app_add_zone_member(self, i_app_cntbl_to_add):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppAddZoneMember
                | o Sub AppAddZoneMember(    SchAppConnectable    iAppCntblToAdd)
                | 
                | Add an application connectable object to the zone as member.


                | Parameters:
                | iAppCntblToAdd
                |    The application connectable object to be added to the zone.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppZone
                | Dim objArg1 As SchAppConnectable
                | ...
                | objThisIntf.AppAddZoneMemberobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schappzone.AppAddZoneMember(i_app_cntbl_to_add)

    def app_list_zone_members(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppListZoneMembers
                | o Func AppListZoneMembers(    ) As SchListOfObjects
                | 
                | List all members of an application zone.


                | Parameters:
                | oLAppCntbl
                |    A list of zone members (application connectables).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppZone
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.AppListZoneMembers
                | 
                | 
                | 
                | 
        """
        return self.schappzone.AppListZoneMembers()

    def app_remove_zone_member(self, i_app_cntbl_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppRemoveZoneMember
                | o Sub AppRemoveZoneMember(    SchAppConnectable    iAppCntblToRemove)
                | 
                | Remove an application connectable object to the zone as member.


                | Parameters:
                | iAppCntblToRemove
                |    The application connectable object to be removed to the zone.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppZone
                | Dim objArg1 As SchAppConnectable
                | ...
                | objThisIntf.AppRemoveZoneMemberobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schappzone.AppRemoveZoneMember(i_app_cntbl_to_remove)

