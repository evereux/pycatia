#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchCompatible:
    """
        .. note::
            CAA V5 Visual Basic help

                | Provides connecting rule to schematic objects.

    """

    def __init__(self, catia):
        self.schcompatible = catia.SchCompatible     

    def get_best_cntr_for_route(self, i_db_2__placement_p, i_grr, i_lok_cntrs, o_db_2__cntr_p, o_best_cntr):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBestCntrForRoute
                | o Sub GetBestCntrForRoute(    CATSafeArrayVariant    iDb2PlacementPt,
                |                               SchGRR    iGRR,
                |                               SchListOfObjects    iLOKCntrs,
                |                               SchListOfDoubles    oDb2CntrPt,
                |                               SchAppConnector    oBestCntr)
                | 
                | Find the best-fit connector to be used to connect a route to.


                | Parameters:
                | iDb2PlacementPt
                |    X-Y coordinates of the target (component or route) graphic selection point.
                |  
                |  iGRR
                |    Pointer to the graphical image of a component or 
                |    to the primitive of a route   
                |  
                |  iLOKCntrs
                |    A list of compatible and available connectors on the component. 
                |    Members are CATISchAppConnector interface pointers. 
                |    This is an Output of IsTargetOKForRoute
                |  
                |  oDb2CntrPt
                |    X-Y coordinates of the best-fit connector point.
                |  
                |  oBestCntr
                |    Best-fit connector


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompatible
                | Dim dbVar1(2) As CATSafeArrayVariant
                | Dim objArg2 As SchGRR
                | Dim objArg3 As SchListOfObjects
                | Dim objArg4 As SchListOfDoubles
                | Dim objArg5 As SchAppConnector
                | ...
                | objThisIntf.GetBestCntrForRoutedbVar1,objArg2,objArg3,objArg4,objArg5
                | 
                | 
                | 
                | 
        """
        return self.schcompatible.GetBestCntrForRoute(i_db_2__placement_p, i_grr, i_lok_cntrs, o_db_2__cntr_p, o_best_cntr)

    def get_best_fit_insert_info(self, i_db_2__placement_p, i_insert_compat_info, io_insert_info, i_b_yes_cycle_all_solns):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBestFitInsertInfo
                | o Sub GetBestFitInsertInfo(    CATSafeArrayVariant    iDb2PlacementPt,
                |                                AnyObject    iInsertCompatInfo,
                |                                AnyObject    ioInsertInfo,
                |                                boolean    iBYesCycleAllSolns)
                | 
                | Find the best-fit connector(s) to be used for inserting a component
                | into a route.


                | Parameters:
                | iDb2PlacementPt
                |    X-Y coordinates of the target component
                |    graphical selection point.
                |  
                |  iInsertCompatInfo
                |    Pointer to an internal class which contains structured information
                |    This is an output of IsTargetOKForInsert
                |  
                |  ioInsertInfo
                |    Pointer to an internal class which contains structured information
                |    for how to inesrt a component into a route. 
                |    Caller must initialize this pointer to NULL when calling this
                |    code the first time. 
                |    This is used as an input
                |    to CATISchComponent::InsertIntoRouteWithInfo   
                |  
                |  iBYesCycleAllSolns
                |    default is FALSE, and ioInsertInfo is an output for the best fit 
                |    solution. When there are more than one internal flows that can
                |    be used for insertion, this routine will choose the best solution in
                |    the following order:
                |    
                |  linear internal flow parallel to x-axis 
                |  linear internal flow parallel to y-axis 
                |  corner internal flow 
                |  others 
                | 
                |    If iBYesCycleAllSolns =TRUE, then the implementation 
                |    will calculate all possible solutions
                |    and allow the caller to recall this code with the
                |    same ioInsertInfo.
                |     if and only if current input iDB2PlacementPt is the
                |    the same as the previous one . Otherwise, the insertion position
                |    of the component on the route is different and the previously
                |    calculated solutions are all invalid for the current call.
                |       
                |    If the iDB2PlacementPt is the same as the previous one
                |    and iBYesCycleAllSolns is TRUE, this code will set the 
                |    internal data ioInsertInfo accordingly, so that when used in
                |    InsertIntoRouteWithInfo, the next solution will be used.
                |    For example, say there are 3 possible solutions and we call them
                |    solution1, solution2 and solution3. Call this code the first
                |    time and InsertIntoComponentWithInfo will use solution1. Call this
                |    code the second time (provided that CntrTgt remains the same)
                |    and solution2 will be used. The third time, solution3. The 
                |    fourth time, solution1 and so one.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompatible
                | Dim dbVar1(2) As CATSafeArrayVariant
                | Dim objArg2 As AnyObject
                | Dim objArg3 As AnyObject
                | Dim bVar4 As boolean
                | ...
                | objThisIntf.GetBestFitInsertInfodbVar1,objArg2,objArg3,bVar4
                | 
                | 
                | 
                | 
        """
        return self.schcompatible.GetBestFitInsertInfo(i_db_2__placement_p, i_insert_compat_info, io_insert_info, i_b_yes_cycle_all_solns)

    def get_best_fit_place_info(self, i_db_2__placement_p, i_place_compat_info, io_place_info, i_b_yes_cycle_all_solns):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBestFitPlaceInfo
                | o Sub GetBestFitPlaceInfo(    CATSafeArrayVariant    iDb2PlacementPt,
                |                               AnyObject    iPlaceCompatInfo,
                |                               AnyObject    ioPlaceInfo,
                |                               boolean    iBYesCycleAllSolns)
                | 
                | Find the best-fit connector(s) to be used for placing a component and
                | connecting it to another.


                | Parameters:
                | iDb2PlacementPt
                |    X-Y coordinates of the target component
                |    graphical selection point.
                |  
                |  iPlaceCompatInfo
                |    Pointer to an internal class which contains structured information
                |    This is an output of IsTargetOKForPlace 
                |  
                |  ioPlaceInfo
                |    Pointer to an internal class which contains structured information
                |    for how to place a component.   
                |    Caller must initialize this pointer to NULL when calling this
                |    code the first time. 
                |    This is used as an input
                |    to CATISchComponent::PlaceOnComponentWithInfo   
                |  
                |  iBYesCycleAllSolns
                |    default is FALSE, and ioPlaceInfo is an output for the best fit 
                |    solution. This solution will connect the compatible Target
                |    connector closest to the iDb2PlacementPt (call this CntrTgt)
                |    and the source connector that is closest to the origin
                |    (in position relative to ditto axis).
                |    If iBYesCycleAllSolns =TRUE, then the implementation 
                |    will calculate all possible solutions
                |    and allow the caller to recall this code with the
                |    same ioPlaceInfo, 
                |     if and only if the compatible Target connector
                |    closest to the iDb2PlacementPt is the same as the previous 
                |    one . 
                |    By doing this, this code will set the 
                |    internal data ioPlaceInfo accordingly, so that when used in
                |    PlaceOnComponentWithInfo, the next solution will be used.
                |    For example, say there are 3 possible solutions and we call them
                |    solution1, solution2 and solution3. Call this code the first
                |    time and PlaceOnComponentWithInfo will use solution1. Call this
                |    code the second time (provided that CntrTgt remains the same)
                |    and solution2 will be used. The third time, solution3. The 
                |    fourth time, solution1 and so one.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompatible
                | Dim dbVar1(2) As CATSafeArrayVariant
                | Dim objArg2 As AnyObject
                | Dim objArg3 As AnyObject
                | Dim bVar4 As boolean
                | ...
                | objThisIntf.GetBestFitPlaceInfodbVar1,objArg2,objArg3,bVar4
                | 
                | 
                | 
                | 
        """
        return self.schcompatible.GetBestFitPlaceInfo(i_db_2__placement_p, i_place_compat_info, io_place_info, i_b_yes_cycle_all_solns)

    def is_target_ok_for_insert(self, i_comp_info, o_insert_compat_info, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsTargetOKForInsert
                | o Sub IsTargetOKForInsert(    AnyObject    iCompInfo,
                |                               AnyObject    oInsertCompatInfo,
                |                               boolean    oBYes)
                | 
                | Query whether an object is compatible to be inserted into a route This
                | method is used when placing a component.


                | Parameters:
                | iCompInfo
                |    Pointer to an internal class which contains structured information
                |    of "this" component for placement. This is an output of  
                |    CATISchComponent::QueryPlaceAbility
                |  
                |  oInsertCompatInfo
                |    Pointer to an internal class which contains structured information
                |    for "this" component and target route (the one in question)
                |    This is used as an input to GetBestFitInsertInfo
                |  
                |  oBYes
                |    If TRUE, the component is OK to be connected to a route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompatible
                | Dim objArg1 As AnyObject
                | Dim objArg2 As AnyObject
                | Dim bVar3 As boolean
                | ...
                | objThisIntf.IsTargetOKForInsertobjArg1,objArg2,bVar3
                | 
                | 
                | 
                | 
        """
        return self.schcompatible.IsTargetOKForInsert(i_comp_info, o_insert_compat_info, o_b_yes)

    def is_target_ok_for_place(self, i_grr_target, i_comp_info, o_place_compat_info, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsTargetOKForPlace
                | o Sub IsTargetOKForPlace(    SchGRRComp    iGRRTarget,
                |                              AnyObject    iCompInfo,
                |                              AnyObject    oPlaceCompatInfo,
                |                              boolean    oBYes)
                | 
                | Query whether an object is compatible to be connected to another
                | component This method is used when placing a component.


                | Parameters:
                | iGRRTarget
                |    Pointer to the graphical image of the component in question (the
                |    target component to be connected to)
                |  
                |  iCompInfo
                |    Pointer to an internal class which contains structured information
                |    of "this" component for placement. This is an output of  
                |    CATISchComponent::QueryPlaceAbility
                |  
                |  oPlaceCompatInfo
                |    Pointer to an internal class which contains structured information
                |    for "this" component and target component (the one in question) 
                |    This is used as an input to GetBestFitPlaceInfo
                |  
                |  oBYes
                |    If TRUE, the component is OK to be connected to a route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompatible
                | Dim objArg1 As SchGRRComp
                | Dim objArg2 As AnyObject
                | Dim objArg3 As AnyObject
                | Dim bVar4 As boolean
                | ...
                | objThisIntf.IsTargetOKForPlaceobjArg1,objArg2,objArg3,bVar4
                | 
                | 
                | 
                | 
        """
        return self.schcompatible.IsTargetOKForPlace(i_grr_target, i_comp_info, o_place_compat_info, o_b_yes)

    def is_target_ok_for_route(self, i_route_cntr_class_type, i_grr_target, o_lok_cntrs, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsTargetOKForRoute
                | o Sub IsTargetOKForRoute(    CATBSTR    iRouteCntrClassType,
                |                              SchGRR    iGRRTarget,
                |                              SchListOfObjects    oLOKCntrs,
                |                              boolean    oBYes)
                | 
                | Query whether an object is compatible to be connected to a route. This
                | method is used when routing a route.


                | Parameters:
                | iRouteCntrClassType
                |    Class type of a schematic route connector.
                |  
                |  iGRRTarget
                |    Pointer to the graphical image of a target component or 
                |    to the primitive of a target route   
                |  
                |  oLOKCntrs
                |    A list of compatible and available connectors on the component or route 
                |    (members are CATISchAppConnector interface pointers)
                |    This is used as an input to GetBestCntrForRoute
                |  
                |  oBYes
                |    If TRUE, the component is OK to be connected to a route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompatible
                | Dim strVar1 As String
                | Dim objArg2 As SchGRR
                | Dim objArg3 As SchListOfObjects
                | Dim bVar4 As boolean
                | ...
                | objThisIntf.IsTargetOKForRoutestrVar1,objArg2,objArg3,bVar4
                | 
                | 
                | 
                | 
        """
        return self.schcompatible.IsTargetOKForRoute(i_route_cntr_class_type, i_grr_target, o_lok_cntrs, o_b_yes)

