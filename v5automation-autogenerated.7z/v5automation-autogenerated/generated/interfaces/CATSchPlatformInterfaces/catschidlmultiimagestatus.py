#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSchIDLMultiImageStatus:
    """
        .. note::
            CAA V5 Visual Basic help

                | Status of the image in MIO.Role: In Multi-Image-Object concept, to
                | specify the status  of the image.

    """

    def __init__(self, catia):
        self.catschidlmultiimagestatus = catia.CatSchIDLMultiImageStatus     

