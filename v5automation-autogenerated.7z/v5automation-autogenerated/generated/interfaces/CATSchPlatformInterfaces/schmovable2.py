#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchMovable2:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage rotation of a schematic object.

    """

    def __init__(self, catia):
        self.schmovable2 = catia.SchMovable2     

    def rotate_at_point(self, i_db_1__rotation_angle_in_radia, i_db_2__center_poin):
        """
        .. note::
            CAA V5 Visual Basic help

                | RotateAtPoint
                | o Sub RotateAtPoint(    double    iDb1RotationAngleInRadian,
                |                         CATSafeArrayVariant    iDb2CenterPoint)
                | 
                | Rotate a schematic object with an angle in radian at a point.


                | Parameters:
                | iDb1RotationAngleInRadian
                |    Rotation angle (from x-axis) in radian.
                |  
                |  iDb2CenterPoint
                |    X-Y components of a center point of rotation.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchMovable2
                | 
                | Dim dbVar2(2) As CATSafeArrayVariant
                | ...
                | objThisIntf.RotateAtPoint,dbVar2
                | 
                | 
                | 
                | 
        """
        return self.schmovable2.RotateAtPoint(i_db_1__rotation_angle_in_radia, i_db_2__center_poin)

