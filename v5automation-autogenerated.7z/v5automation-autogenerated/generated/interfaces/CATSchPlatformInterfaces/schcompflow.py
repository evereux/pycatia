#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchCompFlow:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the internal flow of a schematic component.

    """

    def __init__(self, catia):
        self.schcompflow = catia.SchCompFlow     

    def add_internal_flow(self, i_l_flow_cntrs):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddInternalFlow
                | o Func AddInternalFlow(    SchListOfObjects    iLFlowCntrs) As SchInternalFlow
                | 
                | Add an internal flow to a component.


                | Parameters:
                | iLFlowCntrs
                |    List of connectors (2) to be connected by the flow.
                |    (members should be CATISchAppConnector interface pointer)
                |  
                |  oInternalFlowAdded
                |    Internal flow object added/created
                |    (CATISchInternalFlow interface pointer).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompFlow
                | Dim objArg1 As SchListOfObjects
                | Dim objArg2 As SchInternalFlow
                | ...
                | Set objArg2 = objThisIntf.AddInternalFlow(objArg1)
                | 
                | 
                | 
                | 
        """
        return self.schcompflow.AddInternalFlow(i_l_flow_cntrs)

    def add_internal_flow_specify_grr(self, i_l_flow_cntrs, i_l_owner_grr):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddInternalFlowSpecifyGRR
                | o Func AddInternalFlowSpecifyGRR(    SchListOfObjects    iLFlowCntrs,
                |                                      SchListOfObjects    iLOwnerGRR) As SchInternalFlow
                | 
                | Add an internal flow to a component. Specifying which graphical images
                | the connector graphics are on.


                | Parameters:
                | iLFlowCntrs
                |    List of connectors (2) to be connected by the flow.
                |    (members should be CATISchAppConnector interface pointer)
                |  
                |  iLOwnerImages
                |    List of CATISchGRRComp interface pointers
                |  
                |  oInternalFlowAdded
                |    Internal flow object added/created
                |    (CATISchInternalFlow interface pointer).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompFlow
                | Dim objArg1 As SchListOfObjects
                | Dim objArg2 As SchListOfObjects
                | Dim objArg3 As SchInternalFlow
                | ...
                | Set objArg3 = objThisIntf.AddInternalFlowSpecifyGRR(objArg1,objArg2)
                | 
                | 
                | 
                | 
        """
        return self.schcompflow.AddInternalFlowSpecifyGRR(i_l_flow_cntrs, i_l_owner_grr)

    def list_internal_flows(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListInternalFlows
                | o Func ListInternalFlows(    ) As SchListOfObjects
                | 
                | List all internal flow objects of a component.


                | Parameters:
                | oLInternalFlow
                |    A list of internal flow objects 
                |    (members are CATISchInternalFlow interface pointers).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompFlow
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListInternalFlows
                | 
                | 
                | 
                | 
        """
        return self.schcompflow.ListInternalFlows()

    def remove_internal_flow(self, i_internal_flow_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveInternalFlow
                | o Sub RemoveInternalFlow(    SchInternalFlow    iInternalFlowToRemove)
                | 
                | Remove an internal flow from a component.


                | Parameters:
                | iInternalFlowToRemove
                |    Internal flow object to be removed.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompFlow
                | Dim objArg1 As SchInternalFlow
                | ...
                | objThisIntf.RemoveInternalFlowobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schcompflow.RemoveInternalFlow(i_internal_flow_to_remove)

