#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchObsoleteModel:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage obsolete model elements.

    """

    def __init__(self, catia):
        self.schobsoletemodel = catia.SchObsoleteModel     

    def find_obsolete_classes(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FindObsoleteClasses
                | o Func FindObsoleteClasses(    ) As SchListOfObjects
                | 
                | Find obsolete base classes. This method will internally call
                | CATISchAppObsoleteClass to ask the application for the names of the
                | obsolete classes.


                | Parameters:
                | oListObsoleteObj
                |    A list of objects with obsoleted base class types.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchObsoleteModel
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.FindObsoleteClasses
                | 
                | 
                | 
                | 
        """
        return self.schobsoletemodel.FindObsoleteClasses()

    def has_obsolete_class(self, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasObsoleteClass
                | o Sub HasObsoleteClass(    boolean    oBYes)
                | 
                | Is there any obsolete class in the application model.


                | Parameters:
                | oBYes
                |    If yes, then there is.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchObsoleteModel
                | Dim bVar1 As boolean
                | ...
                | objThisIntf.HasObsoleteClassbVar1
                | 
                | 
                | 
                | 
        """
        return self.schobsoletemodel.HasObsoleteClass(o_b_yes)

