#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchRoute:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a schematic route data.

    """

    def __init__(self, catia):
        self.schroute = catia.SchRoute     

    def add_points(self, i_grr, i_l_db_2__pt_path_to_ad, i_after_which_pt_num):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPoints
                | o Sub AddPoints(    SchGRRRoute    iGRR,
                |                     CATSafeArrayVariant    iLDb2PtPathToAdd,
                |                     long    iAfterWhichPtNum)
                | 
                | Add a list of point to a route.  Modify the route according to the
                | route mode


                | Parameters:
                | iGRR
                |    graphical primitive of the route to add points to
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  iLDbPtPathToAdd
                |    A list of X-Y coordinates of points to be added. 2 doubles per point.
                |  
                |  iAfterWhichPtNum
                |    The point number to add the points after. Use 0 to indicate adding
                |    before the first point.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim dbVar2(x) As CATSafeArrayVariant
                | Dim intVar4 As Integer
                | ...
                | objThisIntf.AddPointsobjArg1,dbVar2,intVar4
                | 
                | 
                | 
                | 
        """
        return self.schroute.AddPoints(i_grr, i_l_db_2__pt_path_to_ad, i_after_which_pt_num)

    def branch(self, i_grr_main, i_sch_branch_route, i_sch_branch_route_cntr, o_branch_cntn, o_new_branch_cntr):
        """
        .. note::
            CAA V5 Visual Basic help

                | Branch
                | o Sub Branch(    SchGRRRoute    iGRRMain,
                |                  SchRoute    iSchBranchRoute,
                |                  SchAppConnector    iSchBranchRouteCntr,
                |                  SchAppConnection    oBranchCntn,
                |                  SchAppConnector    oNewBranchCntr)
                | 
                | Create a branch from this route.


                | Parameters:
                | iGRRMain
                |    graphical primitive of the "this" route to branch from
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  iSchBranchRoute
                |    The route to create a branch connection to (from this route)
                |  
                |  iSchBranchRouteCntr
                |    The extremity connector of the branch
                |  
                |  oBranchCntn
                |    The branch connection created
                |  
                |  oNewBranchCntr
                |    The new branch connector created on "this" route


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim objArg2 As SchRoute
                | Dim objArg3 As SchAppConnector
                | Dim objArg4 As SchAppConnection
                | Dim objArg5 As SchAppConnector
                | ...
                | objThisIntf.BranchobjArg1,objArg2,objArg3,objArg4,objArg5
                | 
                | 
                | 
                | 
        """
        return self.schroute.Branch(i_grr_main, i_sch_branch_route, i_sch_branch_route_cntr, o_branch_cntn, o_new_branch_cntr)

    def break(self, i_grr, i_db_2__pt_1, i_db_2__pt_2, o_new_sch_route):
        """
        .. note::
            CAA V5 Visual Basic help

                | Break
                | o Sub Break(    SchGRRRoute    iGRR,
                |                 CATSafeArrayVariant    iDb2Pt1,
                |                 CATSafeArrayVariant    iDb2Pt2,
                |                 SchRoute    oNewSchRoute)
                | 
                | Break a route into 2 pieces. The old route is shortened and a new
                | route is created.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to be broken
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  iDb2Pt1
                |    X-Y coordinates of point 1 to break the route at (this point is
                |    mandatory).
                |  
                |  iDb2Pt2
                |    X-Y coordinates of point 2 to break the route at (this point is
                |    optional). If provided the points in between point 1 and this
                |    point will be eliminated. Point 1 is the last point of the shortened
                |    old route and point 2 is the first point of the new route. If this point
                |    is not provided (sends in a NULL). point 1 and point 2 are the same.
                |  
                |  oNewSchRoute
                |    The new Schematic route object


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim dbVar2(2) As CATSafeArrayVariant
                | Dim dbVar3(2) As CATSafeArrayVariant
                | Dim objArg4 As SchRoute
                | ...
                | objThisIntf.BreakobjArg1,dbVar2,dbVar3,objArg4
                | 
                | 
                | 
                | 
        """
        return self.schroute.Break(i_grr, i_db_2__pt_1, i_db_2__pt_2, o_new_sch_route)

    def compress(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Compress
                | o Sub Compress(    )
                | 
                | Compress a the defining points of a route, removing coincident points.
                | Example:     Dim objThisIntf As SchRoute  ... objThisIntf.Compress


                | Parameters:


        """
        return self.schroute.Compress()

    def concatenate(self, i_sch_route_1__cnt, i_sch_route_2, i_sch_route_2__cnt):
        """
        .. note::
            CAA V5 Visual Basic help

                | Concatenate
                | o Sub Concatenate(    SchAppConnector    iSchRoute1Cntr,
                |                       SchRoute    iSchRoute2,
                |                       SchAppConnector    iSchRoute2Cntr)
                | 
                | Concatenate 2 routes into one. Only works for those that have only one
                | line graphic object. The first route is elongated and is modified. The
                | second route is deleted.


                | Parameters:
                | iSchRoute1Cntr
                |    Connector of this route
                |    to concatenate with the second route.
                |  
                |  iSchRoute2
                |    Second route to be concatenate to the first. iSchRoute2 will be deleted.
                |  
                |  iSchRoute2Cntr
                |    Connector of second route to concatenate with the first route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchAppConnector
                | Dim objArg2 As SchRoute
                | Dim objArg3 As SchAppConnector
                | ...
                | objThisIntf.ConcatenateobjArg1,objArg2,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schroute.Concatenate(i_sch_route_1__cnt, i_sch_route_2, i_sch_route_2__cnt)

    def concatenate_keep_route2(self, i_sch_route_1__cnt, i_sch_route_2, i_sch_route_2__cnt):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConcatenateKeepRoute2
                | o Sub ConcatenateKeepRoute2(    SchAppConnector    iSchRoute1Cntr,
                |                                 SchRoute    iSchRoute2,
                |                                 SchAppConnector    iSchRoute2Cntr)
                | 
                | Concatenate 2 routes into one. Only works for those that have only one
                | line graphic object. The first route is elongated and is modified. The
                | second route is unchanged.


                | Parameters:
                | iSchRoute1Cntr
                |    Connector of this route
                |    to concatenate with the second route.
                |  
                |  iSchRoute2
                |    Second route to be concatenate to the first. iSchRoute2 will be unchanged.
                |  
                |  iSchRoute2Cntr
                |    Connector of second route to concatenate with the first route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchAppConnector
                | Dim objArg2 As SchRoute
                | Dim objArg3 As SchAppConnector
                | ...
                | objThisIntf.ConcatenateKeepRoute2objArg1,objArg2,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schroute.ConcatenateKeepRoute2(i_sch_route_1__cnt, i_sch_route_2, i_sch_route_2__cnt)

    def get_extremity_cntrs(self, i_grr, o_route_cntr_1, o_route_cntr_2):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExtremityCntrs
                | o Sub GetExtremityCntrs(    SchGRRRoute    iGRR,
                |                             SchAppConnector    oRouteCntr1,
                |                             SchAppConnector    oRouteCntr2)
                | 
                | Get extremity connectors of the route.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to query.
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  oRouteCntr1
                |    Route connector at first extremity
                |  
                |  oRouteCntr2
                |    Route connector at second extremity


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim objArg2 As SchAppConnector
                | Dim objArg3 As SchAppConnector
                | ...
                | objThisIntf.GetExtremityCntrsobjArg1,objArg2,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schroute.GetExtremityCntrs(i_grr, o_route_cntr_1, o_route_cntr_2)

    def get_path(self, i_grr, o_l_db_2__pt_pat):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPath
                | o Sub GetPath(    SchGRRRoute    iGRR,
                |                   SchListOfDoubles    oLDb2PtPath)
                | 
                | Get the defining points of a route.


                | Parameters:
                | iGRR
                |    graphical primitive of the route get the path from
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  oLDbPtPath
                |    A list of X-Y coordinates of points. 2 doubles per point.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim objArg2 As SchListOfDoubles
                | ...
                | objThisIntf.GetPathobjArg1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schroute.GetPath(i_grr, o_l_db_2__pt_pat)

    def ok_to_branch(self, i_grr, i_branch_class_type, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | OKToBranch
                | o Sub OKToBranch(    SchGRRRoute    iGRR,
                |                      CATBSTR    iBranchClassType,
                |                      boolean    oBYes)
                | 
                | Query whether it is OK to create a branch.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to query.
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  iBranchClassType
                |    Class type of the branch to create.
                |  
                |  oBYes
                |    If TRUE, then it is OK to create a branch from a route


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim strVar2 As String
                | Dim bVar3 As boolean
                | ...
                | objThisIntf.OKToBranchobjArg1,strVar2,bVar3
                | 
                | 
                | 
                | 
        """
        return self.schroute.OKToBranch(i_grr, i_branch_class_type, o_b_yes)

    def ok_to_break(self, i_grr, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | OKToBreak
                | o Sub OKToBreak(    SchGRRRoute    iGRR,
                |                     boolean    oBYes)
                | 
                | Query whether it is OK to break.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to query.
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  oBYes
                |    If TRUE, then it is OK to break the route


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim bVar2 As boolean
                | ...
                | objThisIntf.OKToBreakobjArg1,bVar2
                | 
                | 
                | 
                | 
        """
        return self.schroute.OKToBreak(i_grr, o_b_yes)

    def ok_to_concatenate(self, i_grr, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | OKToConcatenate
                | o Sub OKToConcatenate(    SchGRRRoute    iGRR,
                |                           boolean    oBYes)
                | 
                | Query whether it is OK to concatenate.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to query.
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  oBYes
                |    If TRUE, then it is OK to concatenate the route with another


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim bVar2 As boolean
                | ...
                | objThisIntf.OKToConcatenateobjArg1,bVar2
                | 
                | 
                | 
                | 
        """
        return self.schroute.OKToConcatenate(i_grr, o_b_yes)

    def ok_to_modify_points(self, i_grr, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | OKToModifyPoints
                | o Sub OKToModifyPoints(    SchGRRRoute    iGRR,
                |                            boolean    oBYes)
                | 
                | Query whether it is OK to modify (add or remove) the points.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to query.
                |    (if NULL, assume there is only one graphical primitive).
                |  
                |  oBYes
                |    If TRUE, then it is OK to add or remove the points from the route


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim bVar2 As boolean
                | ...
                | objThisIntf.OKToModifyPointsobjArg1,bVar2
                | 
                | 
                | 
                | 
        """
        return self.schroute.OKToModifyPoints(i_grr, o_b_yes)

    def remove_points(self, i_grr, i_num_of_pts_to_remove, i_after_which_pt_num):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePoints
                | o Sub RemovePoints(    SchGRRRoute    iGRR,
                |                        long    iNumOfPtsToRemove,
                |                        long    iAfterWhichPtNum)
                | 
                | Remove points from route.  Modify the route according to the route
                | mode.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to remove the points from
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  iNumOfPtsToRemove
                |    The number of points to be removed
                |  
                |  iAfterWhichPtNum
                |    The point number at which to start removing the point.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim intVar2 As Integer
                | Dim intVar3 As Integer
                | ...
                | objThisIntf.RemovePointsobjArg1,intVar2,intVar3
                | 
                | 
                | 
                | 
        """
        return self.schroute.RemovePoints(i_grr, i_num_of_pts_to_remove, i_after_which_pt_num)

    def reshape_extremity(self, i_grr, i_route_cntr, i_db_2__delta_x):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReshapeExtremity
                | o Sub ReshapeExtremity(    SchGRRRoute    iGRR,
                |                            SchAppConnector    iRouteCntr,
                |                            CATSafeArrayVariant    iDb2DeltaXY)
                | 
                | Change the position of the extremity of the route.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to reshape
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  iRouteCntr
                |    Route connector whose position is to be modified (CATISchAppConnector
                |    interface pointer).
                |  
                |  iDb2DeltaXY
                |    Delta X-Y coordinates of the extremity move


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim objArg2 As SchAppConnector
                | Dim dbVar3(2) As CATSafeArrayVariant
                | ...
                | objThisIntf.ReshapeExtremityobjArg1,objArg2,dbVar3
                | 
                | 
                | 
                | 
        """
        return self.schroute.ReshapeExtremity(i_grr, i_route_cntr, i_db_2__delta_x)

    def reshape_extremity2(self, i_e_route_mode, i_grr, i_route_cntr, i_db_2__pt_to_move_cntr_t):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReshapeExtremity2
                | o Sub ReshapeExtremity2(    CatSchIDLRouteMode    iERouteMode,
                |                             SchGRRRoute    iGRR,
                |                             SchAppConnector    iRouteCntr,
                |                             CATSafeArrayVariant    iDb2PtToMoveCntrTo)
                | 
                | Change the position of the extremity of the route.  Modify the route
                | according to the route mode.


                | Parameters:
                | iERouteMode
                |    Routing mode.
                |  
                |  iGRR
                |    graphical primitive of the route to reshape
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  iRouteCntr
                |    Route connector whose position is to be modified (CATISchConnector
                |    interface pointer).
                |  
                |  iDb2PtToMoveCntrTo
                |    X-Y coordinates of the point to move the connector to.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | 
                | Dim objArg2 As SchGRRRoute
                | Dim objArg3 As SchAppConnector
                | Dim dbVar4(2) As CATSafeArrayVariant
                | ...
                | objThisIntf.ReshapeExtremity2CatSchIDLRouteMode_Enum,objArg2,objArg3,dbVar4
                | 
                | 
                | 
                | 
        """
        return self.schroute.ReshapeExtremity2(i_e_route_mode, i_grr, i_route_cntr, i_db_2__pt_to_move_cntr_t)

    def set_path(self, i_grr, i_l_db_2__pt_pat):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPath
                | o Sub SetPath(    SchGRRRoute    iGRR,
                |                   CATSafeArrayVariant    iLDb2PtPath)
                | 
                | Set the defining points of a route.


                | Parameters:
                | iGRR
                |    graphical primitive of the route to set the path on
                |    (if NULL, assume there is only one graphical primitive)
                |  
                |  iLDbPtPath
                |    A list of X-Y coordinates of points to be set. 2 doubles per point.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRoute
                | Dim objArg1 As SchGRRRoute
                | Dim dbVar2(x) As CATSafeArrayVariant
                | ...
                | objThisIntf.SetPathobjArg1,dbVar2
                | 
                | 
                | 
                | 
        """
        return self.schroute.SetPath(i_grr, i_l_db_2__pt_pat)

