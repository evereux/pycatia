#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchRouteAlternateGraphic:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage alternative graphical primitives of a schematic route.

    """

    def __init__(self, catia):
        self.schroutealternategraphic = catia.SchRouteAlternateGraphic     

    def add_alternate_graphic(self, i_initial_xy_position, o_added_grr):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddAlternateGraphic
                | o Sub AddAlternateGraphic(    CATSafeArrayVariant    iInitialXYPosition,
                |                               SchGRR    oAddedGRR)
                | 
                | Add an alternate graphical primitive to a route. The alternate
                | graphical style is determined by the application. on the Schematic
                | component in order to specify the graphic style. on the Schematic
                | component in order to identify the component as an assembly.


                | Parameters:
                | iInitialXYPosition
                |    The initial position for calculating the display of the graphic.
                |    If NULL, the start point will be calculated based on the route
                |    graphic path of the first assembly member to this Schematic component.
                |  
                |  oAddedGRR
                |    The route alternate graphical primitive that is added to the route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRouteAlternateGraphic
                | Dim dbVar1(x) As CATSafeArrayVariant
                | Dim objArg2 As SchGRR
                | ...
                | objThisIntf.AddAlternateGraphicdbVar1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schroutealternategraphic.AddAlternateGraphic(i_initial_xy_position, o_added_grr)

    def list_alternate_graphics(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListAlternateGraphics
                | o Func ListAlternateGraphics(    ) As SchListOfObjects
                | 
                | Lists the alternate graphics of a route.  The list contains all
                | objects of the same alternate graphic style.  The style is determined
                | must be implemented on the Schematic component in order to specify the
                | graphic style.


                | Parameters:
                | oLGRR
                |    A list of the alternate graphic objects.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRouteAlternateGraphic
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListAlternateGraphics
                | 
                | 
                | 
                | 
        """
        return self.schroutealternategraphic.ListAlternateGraphics()

    def remove_all_alternate_graphics(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAllAlternateGraphics
                | o Sub RemoveAllAlternateGraphics(    )
                | 
                | Removes all alternate graphical primitives.      Example:     Dim
                | objThisIntf As SchRouteAlternateGraphic  ...
                | objThisIntf.RemoveAllAlternateGraphics


                | Parameters:


        """
        return self.schroutealternategraphic.RemoveAllAlternateGraphics()

    def remove_all_alternate_graphics_of_style(self, i_style):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAllAlternateGraphicsOfStyle
                | o Sub RemoveAllAlternateGraphicsOfStyle(    CatSchIDLRouteAlternateGraphicStyle    iStyle)
                | 
                | Removes all alternate graphical primitives of the given style.


                | Parameters:
                | iStyle
                |    An enum of the style of alternate graphic to remove.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRouteAlternateGraphic
                | 
                | ...
                | objThisIntf.RemoveAllAlternateGraphicsOfStyleCatSchIDLRouteAlternateGraphicStyle_Enum
                | 
                | 
                | 
                | 
        """
        return self.schroutealternategraphic.RemoveAllAlternateGraphicsOfStyle(i_style)

    def remove_alternate_graphic(self, i_grr_to_be_removed):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAlternateGraphic
                | o Sub RemoveAlternateGraphic(    SchGRR    iGRRToBeRemoved)
                | 
                | Remove an alternate graphical primitive from a route.


                | Parameters:
                | iGRRToBeRemoved
                |    The route alternate graphic to be removed from the route.  The input
                |    graphic will be removed as long as there are at least two alternate
                |    graphics of that style on the route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchRouteAlternateGraphic
                | Dim objArg1 As SchGRR
                | ...
                | objThisIntf.RemoveAlternateGraphicobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schroutealternategraphic.RemoveAlternateGraphic(i_grr_to_be_removed)

