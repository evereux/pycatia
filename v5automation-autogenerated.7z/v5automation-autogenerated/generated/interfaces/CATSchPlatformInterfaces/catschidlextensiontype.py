#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSchIDLExtensionType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Schematic extension types.Role: For creation and modification of
                | schematic base objects.

    """

    def __init__(self, catia):
        self.catschidlextensiontype = catia.CatSchIDLExtensionType     

