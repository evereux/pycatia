#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchArrowDisplay:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the graphical representation of a schematic route.

    """

    def __init__(self, catia):
        self.scharrowdisplay = catia.SchArrowDisplay     

    def is_arrow_shown(self, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsArrowShown
                | o Sub IsArrowShown(    boolean    oBYes)
                | 
                | Query whether flow arrows are shown (arrow attributes exist).


                | Parameters:
                | oBYes
                |    If TRUE,  then Flow arrows are shown     (arrow attributes exist).
                |    If FALSE, then Flow arrows are not shown (arrow attributes do not exist).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchArrowDisplay
                | Dim bVar1 As boolean
                | ...
                | objThisIntf.IsArrowShownbVar1
                | 
                | 
                | 
                | 
        """
        return self.scharrowdisplay.IsArrowShown(o_b_yes)

    def set_arrow(self, i_grr, i_seg_num):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetArrow
                | o Sub SetArrow(    SchGRRRoute    iGRR,
                |                    long    iSegNum)
                | 
                | Add arrow display attributes on the route.


                | Parameters:
                | iGRR
                |    iGRR means apply only to segments of iGRR.
                |    (if iGRR = NULL, apply to segments of all GRR's of the route,
                |     and ignore iSegNum)
                |  
                |  iSegNum
                |    iSegNum = 0 means apply to all segments of iGRR.
                |    iSegnum > 0 means apply to only to segment number iSegNum iGRR.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchArrowDisplay
                | Dim objArg1 As SchGRRRoute
                | Dim intVar2 As Integer
                | ...
                | objThisIntf.SetArrowobjArg1,intVar2
                | 
                | 
                | 
                | 
        """
        return self.scharrowdisplay.SetArrow(i_grr, i_seg_num)

    def unset_arrow(self, i_grr, i_seg_num):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetArrow
                | o Sub UnsetArrow(    SchGRRRoute    iGRR,
                |                      long    iSegNum)
                | 
                | Remove arrow display attributes on the route.


                | Parameters:
                | iGRR
                |    iGRR means apply only to segments of iGRR.
                |    (if iGRR = NULL, apply to segments of all GRR's of the route,
                |     and ignore iSegNum)
                |  
                |  iSegNum
                |    iSegNum = 0 means apply to all segments of iGRR.
                |    iSegnum > 0 means apply to only to segment number iSegNum iGRR.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchArrowDisplay
                | Dim objArg1 As SchGRRRoute
                | Dim intVar2 As Integer
                | ...
                | objThisIntf.UnsetArrowobjArg1,intVar2
                | 
                | 
                | 
                | 
        """
        return self.scharrowdisplay.UnsetArrow(i_grr, i_seg_num)

