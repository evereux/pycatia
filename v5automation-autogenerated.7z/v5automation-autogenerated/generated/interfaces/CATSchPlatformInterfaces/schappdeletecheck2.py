#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppDeleteCheck2:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the deletion of a schematic object.

    """

    def __init__(self, catia):
        self.schappdeletecheck2 = catia.SchAppDeleteCheck2     

    def app_ok_to_delete(self, o_ok):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppOkToDelete
                | o Sub AppOkToDelete(    boolean    oOk)
                | 
                | Reports if an application object can be deleted.


                | Parameters:
                | oOK
                |    Pointer to the CATBoolean to receive the ok.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppDeleteCheck2
                | Dim bVar1 As boolean
                | ...
                | objThisIntf.AppOkToDeletebVar1
                | 
                | 
                | 
                | 
        """
        return self.schappdeletecheck2.AppOkToDelete(o_ok)

