#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppCntrColor:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage graphical representation of schematic connector.

    """

    def __init__(self, catia):
        self.schappcntrcolor = catia.SchAppCntrColor     

    def app_get_connector_color_by_type(self, o_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppGetConnectorColorByType
                | o Sub AppGetConnectorColorByType(    long    oColor)
                | 
                | Specify the connector color of this connector type.


                | Parameters:
                | oColor
                |    Application connector color for "this" connector type.
                |    Please refer to CATColorName.h of Visualization FW.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrColor
                | Dim intVar1 As Integer
                | ...
                | objThisIntf.AppGetConnectorColorByTypeintVar1
                | 
                | 
                | 
                | 
        """
        return self.schappcntrcolor.AppGetConnectorColorByType(o_color)

