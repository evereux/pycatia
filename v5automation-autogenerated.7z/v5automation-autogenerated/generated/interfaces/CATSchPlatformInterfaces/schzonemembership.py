#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchZoneMembership:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage zone memberships.

    """

    def __init__(self, catia):
        self.schzonemembership = catia.SchZoneMembership     

    def update_zone_membership(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpdateZoneMembership
                | o Sub UpdateZoneMembership(    )
                | 
                | Check all zones geometric boundaries and put this element into the
                | correct zone membership lists.      Example:     Dim objThisIntf As
                | SchZoneMembership  ... objThisIntf.UpdateZoneMembership


                | Parameters:


        """
        return self.schzonemembership.UpdateZoneMembership()

