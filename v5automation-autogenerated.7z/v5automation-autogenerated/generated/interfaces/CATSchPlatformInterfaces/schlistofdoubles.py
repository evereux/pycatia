#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchListOfDoubles:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a list of DOUBLEs to be used with Schematic IDLs.

    """

    def __init__(self, catia):
        self.schlistofdoubles = catia.SchListOfDoubles     

    @property
    def count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Count
                | o Property Count(    ) As long
                | 
                | Returns the number of doubles in the list.  Example: This example
                | retrieves in  NumberOfdoubles the number of doubles currently gathered
                | in MyList.  NumberOfdoubles = MyList.Count


                | Parameters:


        """
        return self.schlistofdoubles.Count

    def append(self, i_double):
        """
        .. note::
            CAA V5 Visual Basic help

                | Append
                | o Sub Append(    double    iDouble)
                | 
                | Adds a double to the end of the list.


                | Parameters:
                | iDouble
                |    The double to be added to the list.


                | Examples:
                | 
                | The following example appends an object to the list.
                | 
                | Dim MyDouble As Double
                | MyDouble = 0.6789
                | Dim MyList As SchListOfDoubles
                | MyList.Append(MyDouble)
                | 
                | 
                | 
        """
        return self.schlistofdoubles.Append(i_double)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    long    iIndex) As double
                | 
                | Returns a double from its index in the list.


                | Parameters:
                | iIndex
                |    The index of the first double in the collection is 1, and
                |    the index of the last double is Count.
                |  
                | 
                |  Returns:
                |   the retrieved double.


                | Examples:
                | 
                | The following example returns in the third double in the list.
                | 
                | Dim MyDouble As double
                | Dim MyList As SchListOfDoubles
                | Set MyDouble = SchListOfDoubles.Item(2)
                | 
                | 
                | 
        """
        return self.schlistofdoubles.Item(i_index)

    def remove_by_index(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveByIndex
                | o Sub RemoveByIndex(    long    iIndex)
                | 
                | Remove a double from the list by specifying its position in the list.


                | Parameters:
                | iIndex
                |    The position of the double to be removed in the list.


                | Examples:
                | 
                | The following example removes the second entry in the list. Please note that the
                | list index starts with 1.
                | 
                | Dim MyList As SchListOfDoubles
                | MyList.Remove(1)
                | 
                | 
                | 
        """
        return self.schlistofdoubles.RemoveByIndex(i_index)

