#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchGRRRoute:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the graphical representations of a schematic route.

    """

    def __init__(self, catia):
        self.schgrrroute = catia.SchGRRRoute     

    def add_points(self, i_l_db_2__pt_path_to_ad, i_after_which_pt_num):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPoints
                | o Sub AddPoints(    CATSafeArrayVariant    iLDb2PtPathToAdd,
                |                     long    iAfterWhichPtNum)
                | 
                | Add a list of point to a route.


                | Parameters:
                | iLDbPtPathToAdd
                |    A list of X-Y coordinates of the points to be added. 
                |    2 doubles per point.
                |  
                |  iAfterWhichPtNum
                |    The point number to add the points after. Use 0 to indicate adding
                |    before the first point.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim dbVar1(x) As CATSafeArrayVariant
                | Dim intVar3 As Integer
                | ...
                | objThisIntf.AddPointsdbVar1,intVar3
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.AddPoints(i_l_db_2__pt_path_to_ad, i_after_which_pt_num)

    def break(self, i_db_2__pt_1, i_db_2__pt_2, o_new_grr_route):
        """
        .. note::
            CAA V5 Visual Basic help

                | Break
                | o Sub Break(    CATSafeArrayVariant    iDb2Pt1,
                |                 CATSafeArrayVariant    iDb2Pt2,
                |                 SchGRRRoute    oNewGRRRoute)
                | 
                | Break a route graphic into 2 pieces. The old graphic is shortened and
                | a new graphic is created.


                | Parameters:
                | iDb2Pt1
                |    X-Y coordinates of point 1 to break the route at (this point is
                |    mandatory).
                |  
                |  iDb2Pt2
                |    X-Y coordinates of point 2 to break the route at (this point is
                |    optional). If provided the points in between point 1 and this
                |    point will be eliminated. Point 1 is the last point of the shortened
                |    old route and point 2 is the first point of the new route. If this point
                |    is not provided (i.e. sends in a NULL). point 1 and point 2 are the same.
                |  
                |  oNewGRRRoute
                |    The new line string graphic created (CATISchGRRRoute interface pointer)


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim dbVar1(2) As CATSafeArrayVariant
                | Dim dbVar2(2) As CATSafeArrayVariant
                | Dim objArg3 As SchGRRRoute
                | ...
                | objThisIntf.BreakdbVar1,dbVar2,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.Break(i_db_2__pt_1, i_db_2__pt_2, o_new_grr_route)

    def compress(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Compress
                | o Sub Compress(    )
                | 
                | Compress a the defining points of a route graphic, removing coincident
                | points.      Example:     Dim objThisIntf As SchGRRRoute  ...
                | objThisIntf.Compress


                | Parameters:


        """
        return self.schgrrroute.Compress()

    def compress2(self, i_unset_gaps):
        """
        .. note::
            CAA V5 Visual Basic help

                | Compress2
                | o Sub Compress2(    CatSchIDLRouteUnsetGapsMode    iUnsetGaps)
                | 
                | Compress the defining points of a route graphic, removing coincident
                | points.


                | Parameters:
                | iUnsetGaps
                |    Whether to unset gaps (in all the effected routes: this route and
                |    other routes intersecting it) or not
                |         = SchUnsetGapsOn   : unset gaps
                |         = SchUnsetGapsOff  : don't unset gaps


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | 
                | ...
                | objThisIntf.Compress2CatSchIDLRouteUnsetGapsMode_Enum
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.Compress2(i_unset_gaps)

    def concatenate(self, i_which_end_1, i_grr_route_2, i_which_end_2):
        """
        .. note::
            CAA V5 Visual Basic help

                | Concatenate
                | o Sub Concatenate(    long    iWhichEnd1,
                |                       SchGRRRoute    iGRRRoute2,
                |                       long    iWhichEnd2)
                | 
                | Concatenate 2 route graphic objects into one.  The first route graphic
                | is elongated and the second object is deleted.


                | Parameters:
                | iWhichEnd1
                |    =1 at start point; =2 at end point
                |  
                |  iGRRRoute2
                |    Second route graphic object (CATISchGRRRoute interface pointer)
                |    to be concatenated to the first. This route graphic will be deleted.
                |  
                |  iWhichEnd2
                |    =1 at start point; =2 at end point


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim intVar1 As Integer
                | Dim objArg2 As SchGRRRoute
                | Dim intVar3 As Integer
                | ...
                | objThisIntf.ConcatenateintVar1,objArg2,intVar3
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.Concatenate(i_which_end_1, i_grr_route_2, i_which_end_2)

    def concatenate_keep_grr2(self, i_which_end_1, i_grr_route_2, i_which_end_2):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConcatenateKeepGRR2
                | o Sub ConcatenateKeepGRR2(    long    iWhichEnd1,
                |                               SchGRRRoute    iGRRRoute2,
                |                               long    iWhichEnd2)
                | 
                | Concatenate 2 route graphic objects into one.  The first route graphic
                | is elongated and the second object is unchanged.


                | Parameters:
                | iWhichEnd1
                |    =1 at start point; =2 at end point
                |  
                |  iGRRRoute2
                |    Second route graphic object (CATISchGRRRoute interface pointer)
                |    to be concatenated to the first. This route graphic will be unchanged.
                |  
                |  iWhichEnd2
                |    =1 at start point; =2 at end point


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim intVar1 As Integer
                | Dim objArg2 As SchGRRRoute
                | Dim intVar3 As Integer
                | ...
                | objThisIntf.ConcatenateKeepGRR2intVar1,objArg2,intVar3
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.ConcatenateKeepGRR2(i_which_end_1, i_grr_route_2, i_which_end_2)

    def create_route_symbol(self, i_seg_num, i_seg_parm, i_grr_symbol, o_route_symbol):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateRouteSymbol
                | o Sub CreateRouteSymbol(    long    iSegNum,
                |                             double    iSegParm,
                |                             SchGRR    iGRRSymbol,
                |                             SchRouteSymbol    oRouteSymbol)
                | 
                | Place a symbol on the route.


                | Parameters:
                | iSegNum
                |    The route segment number to place the symbol on.
                |  
                |  iSegParm
                |    The parameter along the segment used to place the symbol on (0.<=iSegParm<=1.).
                |  
                |  iGRRSymbol
                |    The graphical primitive (detail) to be used for the symbol.
                |  
                |  oRouteSymbol
                |    The created route symbol (ditto).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim intVar1 As Integer
                | Dim dbVar2 As Double;
                | Dim objArg3 As SchGRR
                | Dim objArg4 As SchRouteSymbol
                | ...
                | objThisIntf.CreateRouteSymbolintVar1,dbVar2,objArg3,objArg4
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.CreateRouteSymbol(i_seg_num, i_seg_parm, i_grr_symbol, o_route_symbol)

    def get_end_point(self, o_db_2__end_p):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetEndPoint
                | o Sub GetEndPoint(    SchListOfDoubles    oDb2EndPt)
                | 
                | Get the end point of the route graphic.


                | Parameters:
                | oDb2EndPt
                |    X-Y coordinates of the end point of the route graphic object.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim objArg1 As SchListOfDoubles
                | ...
                | objThisIntf.GetEndPointobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.GetEndPoint(o_db_2__end_p)

    def get_path(self, o_l_db_2__pt_pat):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPath
                | o Sub GetPath(    SchListOfDoubles    oLDb2PtPath)
                | 
                | Get the defining points of a route graphic.


                | Parameters:
                | oLDbPtPath
                |    A list of X-Y coordinates of the points. 2 doubles per point.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim objArg1 As SchListOfDoubles
                | Dim intVar2 As Integer
                | ...
                | objThisIntf.GetPathobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.GetPath(o_l_db_2__pt_pat)

    def get_start_point(self, o_db_2__start_p):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStartPoint
                | o Sub GetStartPoint(    SchListOfDoubles    oDb2StartPt)
                | 
                | Get the start point of the route graphic.


                | Parameters:
                | oDb2StartPt
                |    X-Y coordinates of the start point of the route graphic object.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim objArg1 As SchListOfDoubles
                | ...
                | objThisIntf.GetStartPointobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.GetStartPoint(o_db_2__start_p)

    def list_route_symbols(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListRouteSymbols
                | o Func ListRouteSymbols(    ) As SchListOfObjects
                | 
                | List route symbols on the route.


                | Parameters:
                | oLRouteSymbol
                |    A list of route symbols.
                |    (members are CATIASchRouteSymbol objects).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListRouteSymbols
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.ListRouteSymbols()

    def remove_points(self, i_num_of_pts_to_remove, i_after_which_pt_num):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePoints
                | o Sub RemovePoints(    long    iNumOfPtsToRemove,
                |                        long    iAfterWhichPtNum)
                | 
                | Remove points from route graphic.


                | Parameters:
                | iNumOfPtsToRemove
                |    The number of points to be removed
                |  
                |  iAfterWhichPtNum
                |    The point number at which to start removing the point.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim intVar1 As Integer
                | Dim intVar2 As Integer
                | ...
                | objThisIntf.RemovePointsintVar1,intVar2
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.RemovePoints(i_num_of_pts_to_remove, i_after_which_pt_num)

    def set_end_point(self, i_db_2__end_p):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetEndPoint
                | o Sub SetEndPoint(    CATSafeArrayVariant    iDb2EndPt)
                | 
                | Set the end point of the route graphic.


                | Parameters:
                | iDb2EndPt
                |    X-Y coordinates of the end point of the route graphic object to be set.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim dbVar1(2) As CATSafeArrayVariant
                | ...
                | objThisIntf.SetEndPointdbVar1
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.SetEndPoint(i_db_2__end_p)

    def set_path(self, i_l_db_2__pt_pat, i_compress):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPath
                | o Sub SetPath(    CATSafeArrayVariant    iLDb2PtPath,
                |                   CatSchIDLRouteCompressMode    iCompress)
                | 
                | Set the defining points of a route graphic.


                | Parameters:
                | iLDbPtPath
                |    A list of X-Y coordinates of the points to be set. 2 doubles per point.
                |  
                |  iCompress
                |     Whether to compress the route (i.e., remove duplicate pts, colinear
                |    segments, etc.) or not
                |         = SchCompressOn   : compress
                |         = SchCompressOff  : don't compress


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim dbVar1(x) As CATSafeArrayVariant
                | 
                | ...
                | objThisIntf.SetPathdbVar1,CatSchIDLRouteCompressMode_Enum
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.SetPath(i_l_db_2__pt_pat, i_compress)

    def set_path2(self, i_l_db_2__pt_pat, i_compress, i_unset_gaps):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPath2
                | o Sub SetPath2(    CATSafeArrayVariant    iLDb2PtPath,
                |                    CatSchIDLRouteCompressMode    iCompress,
                |                    CatSchIDLRouteUnsetGapsMode    iUnsetGaps)
                | 
                | Set the defining points of a route graphic.


                | Parameters:
                | iLDbPtPath
                |    A list of X-Y coordinates of the points to be set. 2 doubles per point.
                |  
                |  iCompress
                |     Whether to compress the route (i.e., remove duplicate pts, colinear
                |    segments, etc.) or not
                |         = SchCompressOn   : compress
                |         = SchCompressOff  : don't compress
                |  
                |  iUnsetGaps
                |    Whether to unset gaps (in all the effected routes: this route and
                |    other routes intersecting it) or not
                |         = SchUnsetGapsOn   : unset gaps
                |         = SchUnsetGapsOff  : don't unset gaps


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim dbVar1(x) As CATSafeArrayVariant
                | 
                | ...
                | objThisIntf.SetPath2dbVar1,CatSchIDLRouteCompressMode_Enum,CatSchIDLRouteUnsetGapsMode_Enum
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.SetPath2(i_l_db_2__pt_pat, i_compress, i_unset_gaps)

    def set_path3(self, i_l_db_2__pt_pat, i_compress, i_unset_gaps, i_route_update_symbols):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPath3
                | o Sub SetPath3(    CATSafeArrayVariant    iLDb2PtPath,
                |                    CatSchIDLRouteCompressMode    iCompress,
                |                    CatSchIDLRouteUnsetGapsMode    iUnsetGaps,
                |                    CatSchIDLRouteSymbolUpdateMode    iRouteUpdateSymbols)
                | 
                | Set the defining points of a route graphic.


                | Parameters:
                | iLDb2PtPath
                |    A list of X-Y coordinates of the points to be set. 2 doubles per point.
                |  
                |  iCompress
                |     Whether to compress the route (i.e., remove duplicate pts, colinear
                |    segments, etc.) or not
                |         = catSchIDLCompressOn   : compress
                |         = catSchIDLCompressOff  : don't compress
                |  
                |  iUnsetGaps
                |    Whether to unset gaps (in all the effected routes: this route and
                |    other routes intersecting it) or not
                |         = catSchIDLUnsetGapsOn   : unset gaps
                |         = catSchIDLUnsetGapsOff  : don't unset gaps
                |  
                |  iRouteSymbolUpdate
                |    Whether to update route symbols' positions
                |         = catSchIDLSymbolUpdateOff  : don't update route symbols
                |         = catSchIDLSymbolUpdateOn   : update route symbols


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim dbVar1(x) As CATSafeArrayVariant
                | 
                | ...
                | objThisIntf.SetPath3dbVar1,CatSchIDLRouteCompressMode_Enum,CatSchIDLRouteUnsetGapsMode_Enum,CatSchIDLRouteSymbolUpdateMode_Enum
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.SetPath3(i_l_db_2__pt_pat, i_compress, i_unset_gaps, i_route_update_symbols)

    def set_start_point(self, i_db_2__start_p):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetStartPoint
                | o Sub SetStartPoint(    CATSafeArrayVariant    iDb2StartPt)
                | 
                | Set the start point of the route graphic.


                | Parameters:
                | iDb2StartPt
                |    X-Y coordinates of the start point of the route graphic object to be set.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRRoute
                | Dim dbVar1(2) As CATSafeArrayVariant
                | ...
                | objThisIntf.SetStartPointdbVar1
                | 
                | 
                | 
                | 
        """
        return self.schgrrroute.SetStartPoint(i_db_2__start_p)

