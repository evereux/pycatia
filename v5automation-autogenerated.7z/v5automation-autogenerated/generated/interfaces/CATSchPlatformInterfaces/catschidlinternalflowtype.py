#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSchIDLInternalFlowType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Schematic internal flow types.Role: For inserting a component into a
                | route.

    """

    def __init__(self, catia):
        self.catschidlinternalflowtype = catia.CatSchIDLInternalFlowType     

