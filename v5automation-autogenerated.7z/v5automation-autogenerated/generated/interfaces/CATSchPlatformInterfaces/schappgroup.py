#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppGroup:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage application group.

    """

    def __init__(self, catia):
        self.schappgroup = catia.SchAppGroup     

    def list_zones(self, i_class_type, o_l_zones):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListZones
                | o Sub ListZones(    CATBSTR    iClassType,
                |                     SchListOfObjects    oLZones)
                | 
                | List application zone objects.


                | Parameters:
                | iClassType
                |    Class type filter. If null, no filtering will be applied.
                |  
                |  oLZones
                |   (members are CATISchAppZone interfaces pointers)
                |    A list of zones


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppGroup
                | Dim strVar1 As String
                | Dim objArg2 As SchListOfObjects
                | ...
                | objThisIntf.ListZonesstrVar1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schappgroup.ListZones(i_class_type, o_l_zones)

