#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppConnectable:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an application object that can be connected to others.

    """

    def __init__(self, catia):
        self.schappconnectable = catia.SchAppConnectable     

    def app_add_connector(self, i_class_type, o_new_app_cntr):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppAddConnector
                | o Sub AppAddConnector(    CATBSTR    iClassType,
                |                           SchAppConnector    oNewAppCntr)
                | 
                | Add a connector.


                | Parameters:
                | iClassType
                |     Class type of the connector to be added.
                |  
                |  oNewAppCntr
                |    The new Application Connector object created.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnectable
                | Dim strVar1 As String
                | Dim objArg2 As SchAppConnector
                | ...
                | objThisIntf.AppAddConnectorstrVar1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schappconnectable.AppAddConnector(i_class_type, o_new_app_cntr)

    def app_get_reference_name(self, o_reference_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppGetReferenceName
                | o Sub AppGetReferenceName(    CATBSTR    oReferenceName)
                | 
                | Get the reference name of a connectable. It will be displayed in
                | catalogs.


                | Parameters:
                | oReferenceName
                |    The name of the reference


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnectable
                | Dim strVar1 As String
                | ...
                | objThisIntf.AppGetReferenceNamestrVar1
                | 
                | 
                | 
                | 
        """
        return self.schappconnectable.AppGetReferenceName(o_reference_name)

    def app_list_connectables(self, i_l_cntble_class_filter, o_l_cntbles, o_l_cntrs_on_this_obj, o_l_cntrs_on_connected):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppListConnectables
                | o Sub AppListConnectables(    SchListOfBSTRs    iLCntbleClassFilter,
                |                               SchListOfObjects    oLCntbles,
                |                               SchListOfObjects    oLCntrsOnThisObj,
                |                               SchListOfObjects    oLCntrsOnConnected)
                | 
                | Find all the application objects connected to this object through
                | their connectors.


                | Parameters:
                | oLCntrClassFilter
                |    A list of all the class types for filtering the output application
                |    objects list.
                |  
                |  oLCntbles
                |    A list of application objects connected to this object.
                |    (members are CATISchAppConnectable interface pointers). 
                |  
                |  oLCntrsOnThisObj
                |    A list of connectors on this object through which 
                |    the connection is made.
                |    (members are CATISchAppConnector interface pointers).
                |  
                |  oLCntrsOnConnected
                |    A list of connectors on the connected objects through which 
                |    the connection is made.
                |    (members are CATISchAppConnector interface pointers).
                |    Members in this list corresponds to those in oLCntrsOnThisObj in
                |    making the corresponding connections.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnectable
                | Dim objArg1 As SchListOfBSTRs
                | Dim objArg2 As SchListOfObjects
                | Dim objArg3 As SchListOfObjects
                | Dim objArg4 As SchListOfObjects
                | ...
                | objThisIntf.AppListConnectablesobjArg1,objArg2,objArg3,objArg4
                | 
                | 
                | 
                | 
        """
        return self.schappconnectable.AppListConnectables(i_l_cntble_class_filter, o_l_cntbles, o_l_cntrs_on_this_obj, o_l_cntrs_on_connected)

    def app_list_connectors(self, i_l_cntr_class_filter):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppListConnectors
                | o Func AppListConnectors(    SchListOfBSTRs    iLCntrClassFilter) As SchListOfObjects
                | 
                | Find all the connectors of this application object.


                | Parameters:
                | oLCntrClassFilter
                |    A list of all the class types for filtering the output connector
                |    list.
                |  
                |  oLCntrs
                |    A list of connectors included in this connection.
                |    (members are CATISchAppConnector interface pointers).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnectable
                | Dim objArg1 As SchListOfBSTRs
                | Dim objArg2 As SchListOfObjects
                | ...
                | Set objArg2 = objThisIntf.AppListConnectors(objArg1)
                | 
                | 
                | 
                | 
        """
        return self.schappconnectable.AppListConnectors(i_l_cntr_class_filter)

    def app_list_valid_cntr_types(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppListValidCntrTypes
                | o Func AppListValidCntrTypes(    ) As SchListOfBSTRs
                | 
                | List the valid application connector types allowed to be created.


                | Parameters:
                | oLValidCntrTypes
                |    A list of connector class types allowed.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnectable
                | Dim objArg1 As SchListOfBSTRs
                | ...
                | Set objArg1 = objThisIntf.AppListValidCntrTypes
                | 
                | 
                | 
                | 
        """
        return self.schappconnectable.AppListValidCntrTypes()

    def app_remove_connector(self, i_cntr_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppRemoveConnector
                | o Sub AppRemoveConnector(    SchAppConnector    iCntrToRemove)
                | 
                | Remove a connector.


                | Parameters:
                | iCntrToRemove
                |     The application connector object to be removed


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnectable
                | Dim objArg1 As SchAppConnector
                | ...
                | objThisIntf.AppRemoveConnectorobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schappconnectable.AppRemoveConnector(i_cntr_to_remove)

    def app_set_reference_name(self, i_reference_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppSetReferenceName
                | o Sub AppSetReferenceName(    CATBSTR    iReferenceName)
                | 
                | Set the reference name of a connectable. It will be displayed in
                | catalogs.


                | Parameters:
                | iReferenceName
                |    The name of the reference


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnectable
                | Dim strVar1 As String
                | ...
                | objThisIntf.AppSetReferenceNamestrVar1
                | 
                | 
                | 
                | 
        """
        return self.schappconnectable.AppSetReferenceName(i_reference_name)

