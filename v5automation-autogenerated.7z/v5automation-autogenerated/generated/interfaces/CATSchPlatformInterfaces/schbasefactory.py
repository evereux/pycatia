#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchBaseFactory:
    """
        .. note::
            CAA V5 Visual Basic help

                | Factory to create basic schematic objects.

    """

    def __init__(self, catia):
        self.schbasefactory = catia.SchBaseFactory     

    def create_network(self, i_l_cntbls, i_lgr_rs):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateNetwork
                | o Func CreateNetwork(    SchListOfObjects    iLCntbls,
                |                          SchListOfObjects    iLGRRs) As SchListOfObjects
                | 
                | Create schematic networks for query. These are volatile objects and
                | will not be saved in the model.


                | Parameters:
                | iLCntbl
                |    A list of related objects that belong to the network (CATISchAppConnectable pointers). 
                |    These objects do not need to be connected.
                |    This method will do the analysis and returns the network(s) containing these objects.
                |  
                |  iLCntbl
                |    A list of graphical images interface (CATISchGRR) pointers. Each member corresponds
                |    to the members in iLCntbl.
                |  
                |  oNetwork
                |  [out, IUnknown#Release]   Pointer to the network analysis interface pointers.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBaseFactory
                | Dim objArg1 As SchListOfObjects
                | Dim objArg2 As SchListOfObjects
                | Dim objArg3 As SchListOfObjects
                | ...
                | Set objArg3 = objThisIntf.CreateNetwork(objArg1,objArg2)
                | 
                | 
                | 
                | 
        """
        return self.schbasefactory.CreateNetwork(i_l_cntbls, i_lgr_rs)

    def create_route_and_connect_to_objects(self, i_app_route, i_cntr_comp_from, i_cntr_comp_to, i_grr_comp_from, i_grr_comp_to, i_l_db_2__pt_pat, i_e_route_mode, o_sch_route):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateRouteAndConnectToObjects
                | o Sub CreateRouteAndConnectToObjects(    AnyObject    iAppRoute,
                |                                          SchAppConnector    iCntrCompFrom,
                |                                          SchAppConnector    iCntrCompTo,
                |                                          SchGRRComp    iGRRCompFrom,
                |                                          SchGRRComp    iGRRCompTo,
                |                                          CATSafeArrayVariant    iLDb2PtPath,
                |                                          CatSchIDLRouteMode    iERouteMode,
                |                                          SchRoute    oSchRoute)
                | 
                | Create a route and connect its extremity connectors to input objects.


                | Parameters:
                | iAppRoute
                |    Application route (at least a feature)
                |  
                |  iCntrCompFrom
                |    Pointer to component connector to connect starting end of the route to
                |    If NULL, no connection is made at this end.
                |  
                |  iCntrCompTo
                |    Pointer to component connector to connect end of the route to
                |    If NULL, no connection is made at this end.
                |  
                |  iGRRCompFrom
                |    Pointer to first component graphical image, if NULL, the PRIMARY image 
                |    associated with component will be used
                |  
                |  iGRRCompTo
                |    Pointer to second component graphical image, if NULL, the PRIMARY image 
                |    associated with component will be used
                |  
                |  iLDb2PtPath
                |    A list of X-Y coordinates of points to be used for the route image. 
                |    2 doubles per point. Not used if iERouteMode=SchRouteMode_AroundObject
                |    input a NULL for this case
                |  
                |  iERouteMode
                |    Route mode to use. Only used when iLDb2PtPath is NULL.
                |  
                |  oSchRoute
                |    Pointer to the new route


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBaseFactory
                | Dim objArg1 As AnyObject
                | Dim objArg2 As SchAppConnector
                | Dim objArg3 As SchAppConnector
                | Dim objArg4 As SchGRRComp
                | Dim objArg5 As SchGRRComp
                | Dim dbVar6(x) As CATSafeArrayVariant
                | 
                | Dim objArg9 As SchRoute
                | ...
                | objThisIntf.CreateRouteAndConnectToObjectsobjArg1,objArg2,objArg3,objArg4,objArg5,dbVar6,CatSchIDLRouteMode_Enum,objArg9
                | 
                | 
                | 
                | 
        """
        return self.schbasefactory.CreateRouteAndConnectToObjects(i_app_route, i_cntr_comp_from, i_cntr_comp_to, i_grr_comp_from, i_grr_comp_to, i_l_db_2__pt_pat, i_e_route_mode, o_sch_route)

    def create_sch_comp_group(self, i_app_group, i_lgrr, i_l_member):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSchCompGroup
                | o Func CreateSchCompGroup(    AnyObject    iAppGroup,
                |                               SchListOfObjects    iLGRR,
                |                               SchListOfObjects    iLMember) As SchCompGroupExt
                | 
                | Create a Schematic Component Group object.


                | Parameters:
                | iAppGroup
                |    Application group object (at least a feature)
                |    Optional, it could be NULL. If NULL, one will be created by the platform
                |  
                |  iLGRR
                |    A list of graphical representation. Optional, it could be NULL.
                |  
                |  iLMembers
                |    A list of initial members. Optional, it could be NULL.
                |  
                |  oSchGroup
                |    Pointer to the new group.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBaseFactory
                | Dim objArg1 As AnyObject
                | Dim objArg2 As SchListOfObjects
                | Dim objArg3 As SchListOfObjects
                | Dim objArg4 As SchCompGroupExt
                | ...
                | Set objArg4 = objThisIntf.CreateSchCompGroup(objArg1,objArg2,objArg3)
                | 
                | 
                | 
                | 
        """
        return self.schbasefactory.CreateSchCompGroup(i_app_group, i_lgrr, i_l_member)

    def create_sch_component(self, i_app_component_ref, i_lgrr):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSchComponent
                | o Func CreateSchComponent(    AnyObject    iAppComponentRef,
                |                               SchListOfObjects    iLGRR) As SchComponent
                | 
                | Create a Schematic Component reference.


                | Parameters:
                | iAppComponentRef
                |    Application component reference (at least a feature)
                |  
                |  iLGRR
                |    A list of graphical representations.
                |  
                |  oSchComp
                |    Pointer to the new component.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBaseFactory
                | Dim objArg1 As AnyObject
                | Dim objArg2 As SchListOfObjects
                | Dim objArg3 As SchComponent
                | ...
                | Set objArg3 = objThisIntf.CreateSchComponent(objArg1,objArg2)
                | 
                | 
                | 
                | 
        """
        return self.schbasefactory.CreateSchComponent(i_app_component_ref, i_lgrr)

    def create_sch_route_by_points(self, i_app_route, i_l_db_pt, o_sch_route):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSchRouteByPoints
                | o Sub CreateSchRouteByPoints(    AnyObject    iAppRoute,
                |                                  CATSafeArrayVariant    iLDbPt,
                |                                  SchRoute    oSchRoute)
                | 
                | Create a Schematic Route object with a list of points.


                | Parameters:
                | iAppRoute
                |    Application route (at least a feature)
                |  
                |  iLDbPt
                |    A list of X-Y coordinates of points. 2 doubles per point.
                |  
                |  oSchRoute
                |    Pointer to the new route


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBaseFactory
                | Dim objArg1 As AnyObject
                | Dim dbVar2(x) As CATSafeArrayVariant
                | Dim objArg4 As SchRoute
                | ...
                | objThisIntf.CreateSchRouteByPointsobjArg1,dbVar2,objArg4
                | 
                | 
                | 
                | 
        """
        return self.schbasefactory.CreateSchRouteByPoints(i_app_route, i_l_db_pt, o_sch_route)

    def create_sch_route_by_prim(self, i_app_route, i_lgrr):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSchRouteByPrim
                | o Func CreateSchRouteByPrim(    AnyObject    iAppRoute,
                |                                 SchListOfObjects    iLGRR) As SchRoute
                | 
                | Create a Schematic Route object with primitives.


                | Parameters:
                | iAppRoute
                |    Application route (at least a feature)
                |  
                |  iLGRR
                |    A list of graphical primitives.
                |    pointer).
                |  
                |  oSchRoute
                |    Pointer to the new route


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBaseFactory
                | Dim objArg1 As AnyObject
                | Dim objArg2 As SchListOfObjects
                | Dim objArg3 As SchRoute
                | ...
                | Set objArg3 = objThisIntf.CreateSchRouteByPrim(objArg1,objArg2)
                | 
                | 
                | 
                | 
        """
        return self.schbasefactory.CreateSchRouteByPrim(i_app_route, i_lgrr)

    def create_sch_zone(self, i_app_zone, i_lgrr):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSchZone
                | o Func CreateSchZone(    AnyObject    iAppZone,
                |                          SchListOfObjects    iLGRR) As SchZone
                | 
                | Create a Schematic Zone object.


                | Parameters:
                | iAppZone
                |    Application zone object (at least a feature)
                |  
                |  iLGRR
                |    A list of graphical representation.
                |  
                |  oSchZone
                |    Pointer to the new zone.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBaseFactory
                | Dim objArg1 As AnyObject
                | Dim objArg2 As SchListOfObjects
                | Dim objArg3 As SchZone
                | ...
                | Set objArg3 = objThisIntf.CreateSchZone(objArg1,objArg2)
                | 
                | 
                | 
                | 
        """
        return self.schbasefactory.CreateSchZone(i_app_zone, i_lgrr)

    def delete_object(self, i_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | DeleteObject
                | o Sub DeleteObject(    AnyObject    iObject)
                | 
                | Delete a schematic object.


                | Parameters:
                | iObject
                |    interface pointer to the object to be deleted


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBaseFactory
                | Dim objArg1 As AnyObject
                | ...
                | objThisIntf.DeleteObjectobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schbasefactory.DeleteObject(i_object)

