#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchGRRFactory:
    """
        .. note::
            CAA V5 Visual Basic help

                | Factory to create graphical representations of schematic objects.

    """

    def __init__(self, catia):
        self.schgrrfactory = catia.SchGRRFactory     

    def create_grr_cntr(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateGRRCntr
                | o Func CreateGRRCntr(    ) As SchGRRCntr
                | 
                | Create the graphical representation of a Schematic Connector.


                | Parameters:
                | oGRRCntr
                |    The graphical representation of the connector


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRFactory
                | Dim objArg1 As SchGRRCntr
                | ...
                | Set objArg1 = objThisIntf.CreateGRRCntr
                | 
                | 
                | 
                | 
        """
        return self.schgrrfactory.CreateGRRCntr()

    def create_grr_group(self, i_l_primitive):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateGRRGroup
                | o Func CreateGRRGroup(    SchListOfObjects    iLPrimitive) As AnyObject
                | 
                | Create the graphical representation of a Schematic Group.


                | Parameters:
                | iLPrimitives
                |    A list of 2D drafting detail pointers 
                |    Members are CATI2DDetail interface poiners.
                |  
                |  oGRRGroup
                |    The graphical representation of the Group


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRFactory
                | Dim objArg1 As SchListOfObjects
                | Dim objArg2 As AnyObject
                | ...
                | Set objArg2 = objThisIntf.CreateGRRGroup(objArg1)
                | 
                | 
                | 
                | 
        """
        return self.schgrrfactory.CreateGRRGroup(i_l_primitive)

    def create_grr_route(self, i_l_db_line_path, o_grr_route):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateGRRRoute
                | o Sub CreateGRRRoute(    CATSafeArrayVariant    iLDbLinePath,
                |                          SchGRRRoute    oGRRRoute)
                | 
                | Create the graphical representation of a Schematic Route.


                | Parameters:
                | iLDbPtPath
                |    A list of X-Y coordinates of points defining the Route. 
                |    2 doubles per point.
                |  
                |  oGRRRoute
                |    The graphical representation of the Route


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRFactory
                | Dim dbVar1(x) As CATSafeArrayVariant
                | Dim objArg3 As SchGRRRoute
                | ...
                | objThisIntf.CreateGRRRoutedbVar1,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schgrrfactory.CreateGRRRoute(i_l_db_line_path, o_grr_route)

    def create_grr_route_ellipse(self, i_db_xy_seed_pt, o_grr_route_ellipse):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateGRRRouteEllipse
                | o Sub CreateGRRRouteEllipse(    CATSafeArrayVariant    iDbXYSeedPt,
                |                                 SchGRRRouteEllipse    oGRRRouteEllipse)
                | 
                | Create the graphical representation of a Schematic Route Ellipse.


                | Parameters:
                | iDbXYSeedPt
                |    X-Y coordinate of the seed point for the ellipse.  If NULL,
                |    the seed point will not be set.
                |  
                |  oGRRRouteEllipse
                |    The graphical representation of the Route Ellipse


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRFactory
                | Dim dbVar1(X) As CATSafeArrayVariant
                | Dim objArg2 As SchGRRRouteEllipse
                | ...
                | objThisIntf.CreateGRRRouteEllipsedbVar1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schgrrfactory.CreateGRRRouteEllipse(i_db_xy_seed_pt, o_grr_route_ellipse)

    def create_grr_zone(self, i_l_primitive):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateGRRZone
                | o Func CreateGRRZone(    SchListOfObjects    iLPrimitive) As SchGRRZone
                | 
                | Create the graphical representation of a Schematic Zone.


                | Parameters:
                | iLPrimitives
                |    A list of 2D drafting object pointers defining the zone boundaries.
                |  
                |  oGRRZone
                |    The graphical representation of the Zone


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRFactory
                | Dim objArg1 As SchListOfObjects
                | Dim objArg2 As SchGRRZone
                | ...
                | Set objArg2 = objThisIntf.CreateGRRZone(objArg1)
                | 
                | 
                | 
                | 
        """
        return self.schgrrfactory.CreateGRRZone(i_l_primitive)

