#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchZone:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage zone boundaries.

    """

    def __init__(self, catia):
        self.schzone = catia.SchZone     

    def update_bounded_elements(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpdateBoundedElements
                | o Sub UpdateBoundedElements(    )
                | 
                | Update the zone members based on the current zone boundaries.


                | Parameters:
                | iGRRToAdd
                |    The graphical representation to be added to the zone.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchZone
                | ...
                | objThisIntf.UpdateBoundedElements
                | 
                | 
                | 
                | 
        """
        return self.schzone.UpdateBoundedElements()

