#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchApp2DZoneFrom3DZone:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a 2D zone that is dropped off from 3D counterpart.

    """

    def __init__(self, catia):
        self.schapp2dzonefrom3dzone = catia.SchApp2DZoneFrom3DZone     

    def create2_d_app_zone(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create2DAppZone
                | o Func Create2DAppZone(    ) As AnyObject
                | 
                | Create an Application Zone.


                | Parameters:
                | i3DZone
                |    The Bounded Zone (3D) object
                |  
                |  oAppZone
                |    The new Application zone object created (CATISchAppZone
                |    interface pointer).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchApp2DZoneFrom3DZone
                | Dim objArg1 As AnyObject
                | ...
                | Set objArg1 = objThisIntf.Create2DAppZone
                | 
                | 
                | 
                | 
        """
        return self.schapp2dzonefrom3dzone.Create2DAppZone()

