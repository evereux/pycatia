#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppRoute2:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a schematic route.

    """

    def __init__(self, catia):
        self.schapproute2 = catia.SchAppRoute2     

    def app_post_route_process(self, i_cntbl_connected_to):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppPostRouteProcess
                | o Sub AppPostRouteProcess(    SchAppConnectable    iCntblConnectedTo)
                | 
                | Post process after creating a route instance.


                | Parameters:
                | iCntbleConnectedTo
                |    The connectable that the route is connected to this route
                |    It is optional


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppRoute2
                | Dim objArg1 As SchAppConnectable
                | ...
                | objThisIntf.AppPostRouteProcessobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schapproute2.AppPostRouteProcess(i_cntbl_connected_to)

