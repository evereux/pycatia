#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppEnvironment:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the application environment in a schematic session.

    """

    def __init__(self, catia):
        self.schappenvironment = catia.SchAppEnvironment     

    def app_clean_up_when_application_ends(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppCleanUpWhenApplicationEnds
                | o Sub AppCleanUpWhenApplicationEnds(    )
                | 
                | Initialize environment when schematic application ends.      Example:
                | Dim objThisIntf As SchAppEnvironment  ...
                | objThisIntf.AppCleanUpWhenApplicationEnds


                | Parameters:


        """
        return self.schappenvironment.AppCleanUpWhenApplicationEnds()

    def app_init_when_application_starts(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppInitWhenApplicationStarts
                | o Sub AppInitWhenApplicationStarts(    )
                | 
                | Initialize environment when schematic application starts.
                | Example:     Dim objThisIntf As SchAppEnvironment  ...
                | objThisIntf.AppInitWhenApplicationStarts


                | Parameters:


        """
        return self.schappenvironment.AppInitWhenApplicationStarts()

    def app_load_feat_files(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppLoadFeatFiles
                | o Sub AppLoadFeatFiles(    )
                | 
                | Load all the necessary feat files.      Example:     Dim objThisIntf
                | As SchAppEnvironment  ... objThisIntf.AppLoadFeatFiles


                | Parameters:


        """
        return self.schappenvironment.AppLoadFeatFiles()

