#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchematicExtension:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage schematic extensions.

    """

    def __init__(self, catia):
        self.schematicextension = catia.SchematicExtension     

    def add_extension(self, i_app_obj_to_be_extended, i_extension_type, i_lgrr):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddExtension
                | o Sub AddExtension(    AnyObject    iAppObjToBeExtended,
                |                        CatSchIDLExtensionType    iExtensionType,
                |                        SchListOfObjects    iLGRR)
                | 
                | Adds a Schematic extension to an application object.


                | Parameters:
                | iAppObjToBeExtended
                |    The application object to be extended.
                |  
                |  iExtensionType
                |    The extension type.
                |  
                |  iLGRR
                |    If iLGRR is not NULL, then its members will be linked to the extension as graphics


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchematicExtension
                | Dim objArg1 As AnyObject
                | 
                | Dim objArg3 As SchListOfObjects
                | ...
                | objThisIntf.AddExtensionobjArg1,CatSchIDLExtensionType_Enum,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schematicextension.AddExtension(i_app_obj_to_be_extended, i_extension_type, i_lgrr)

    def remove_extension(self, i_app_extended_obj, i_extension_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveExtension
                | o Sub RemoveExtension(    AnyObject    iAppExtendedObj,
                |                           CatSchIDLExtensionType    iExtensionType)
                | 
                | Removes a Schematic extension to an application object.


                | Parameters:
                | iAppExtendedObj
                |    The application object to be have its extension removed.
                |  
                |  iExtensionType
                |    The extension type.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchematicExtension
                | Dim objArg1 As AnyObject
                | 
                | ...
                | objThisIntf.RemoveExtensionobjArg1,CatSchIDLExtensionType_Enum
                | 
                | 
                | 
                | 
        """
        return self.schematicextension.RemoveExtension(i_app_extended_obj, i_extension_type)

