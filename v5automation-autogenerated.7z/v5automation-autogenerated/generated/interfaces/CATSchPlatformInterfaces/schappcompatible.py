#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppCompatible:
    """
        .. note::
            CAA V5 Visual Basic help

                | Provide application rules of how to connect objects.

    """

    def __init__(self, catia):
        self.schappcompatible = catia.SchAppCompatible     

    def app_is_target_ok_for_insert(self, i_l_comp_source_cntrs, o_l_source_cntrs, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppIsTargetOKForInsert
                | o Sub AppIsTargetOKForInsert(    SchListOfObjects    iLCompSourceCntrs,
                |                                  SchListOfObjects    oLSourceCntrs,
                |                                  boolean    oBYes)
                | 
                | Query whether a component (source) is compatible to be inserted into
                | this route. This method is used when inserting a component into a
                | route. This mehtod should only be implemented on a route object. For a
                | component object, the method should simply returns oBYes=FALSE.


                | Parameters:
                | iLCompSourceCntrs
                |    A list of connectors on the source component. The target (to be connected)
                |    is "this" route.
                |  
                |  oLSourceCntrs
                |    A list of compatible and available connectors on the source component (the input)
                |    that can be connected to the target ("this" route)
                |    (members are CATISchAppConnector interface pointers)
                |  
                |  oBYes
                |    If TRUE, the object is OK to be connected to a route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCompatible
                | Dim objArg1 As SchListOfObjects
                | Dim objArg2 As SchListOfObjects
                | Dim bVar3 As boolean
                | ...
                | objThisIntf.AppIsTargetOKForInsertobjArg1,objArg2,bVar3
                | 
                | 
                | 
                | 
        """
        return self.schappcompatible.AppIsTargetOKForInsert(i_l_comp_source_cntrs, o_l_source_cntrs, o_b_yes)

    def app_is_target_ok_for_place(self, i_l_comp_source_cntrs, o_l_target_cntrs, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppIsTargetOKForPlace
                | o Sub AppIsTargetOKForPlace(    SchListOfObjects    iLCompSourceCntrs,
                |                                 SchListOfObjects    oLTargetCntrs,
                |                                 boolean    oBYes)
                | 
                | Query whether a component (source) is compatible to be connected to
                | "this" object  (the target, which can be a route or a component). This
                | method is used when placing a component to be connected to another
                | object.


                | Parameters:
                | iLCompSourceCntrs
                |    A list of connectors on the source component. The target (to be connected)
                |    is "this" component.
                |  
                |  oLOKCntrs
                |    A list of compatible and available connectors on "this" component (the target)
                |    to be connected to the source component (the input source).
                |    (members are CATISchAppConnector interface pointers)
                |  
                |  oBYes
                |    If TRUE, the object is OK to be connected to a route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCompatible
                | Dim objArg1 As SchListOfObjects
                | Dim objArg2 As SchListOfObjects
                | Dim bVar3 As boolean
                | ...
                | objThisIntf.AppIsTargetOKForPlaceobjArg1,objArg2,bVar3
                | 
                | 
                | 
                | 
        """
        return self.schappcompatible.AppIsTargetOKForPlace(i_l_comp_source_cntrs, o_l_target_cntrs, o_b_yes)

    def app_is_target_ok_for_route(self, i_route_cntr_class_type, o_lok_cntrs, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppIsTargetOKForRoute
                | o Sub AppIsTargetOKForRoute(    CATBSTR    iRouteCntrClassType,
                |                                 SchListOfObjects    oLOKCntrs,
                |                                 boolean    oBYes)
                | 
                | Query whether a route of the input class type can be connected to
                | "this" object (the target, which can be a route or a component). This
                | method is used when routing a route.


                | Parameters:
                | iRouteCntrClassType
                |    Class type of a schematic route connector.
                |  
                |  oLOKCntrs
                |    A list of compatible and available connectors on this object. 
                |    (members are CATISchAppConnector interface pointers)
                |  
                |  oBYes
                |    If TRUE, the object is OK to be connected to a route.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCompatible
                | Dim strVar1 As String
                | Dim objArg2 As SchListOfObjects
                | Dim bVar3 As boolean
                | ...
                | objThisIntf.AppIsTargetOKForRoutestrVar1,objArg2,bVar3
                | 
                | 
                | 
                | 
        """
        return self.schappcompatible.AppIsTargetOKForRoute(i_route_cntr_class_type, o_lok_cntrs, o_b_yes)

