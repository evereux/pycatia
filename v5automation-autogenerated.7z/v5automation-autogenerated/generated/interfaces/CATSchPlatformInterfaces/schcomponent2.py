#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchComponent2:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a schematic component.

    """

    def __init__(self, catia):
        self.schcomponent2 = catia.SchComponent2     

    def place_in_space(self, i_grr, i_db_6__axi, i_doc, o_new_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | PlaceInSpace
                | o Sub PlaceInSpace(    SchGRRComp    iGRR,
                |                        CATSafeArrayVariant    iDb6Axis,
                |                        Document    iDoc,
                |                        SchComponent    oNewComponent)
                | 
                | Place a component in space, unconnected to other objects. It will
                | create local reference (from a catalog referenced document) if
                | necessary.


                | Parameters:
                | iGRR
                |    Pointer to the component graphical representation.
                |    if NULL the "Primary" graphical representation will be used.
                |  
                |  iDb6Axis[6]
                |    X-axis of the local axis of the new instance
                |    Y-axis of the local axis of the new instance
                |    X-Y coordinates of the orgin of the new instance.
                |    This axis defines the orientation and location of the new instance
                |    in space.
                |  
                |  iDoc
                |    Pointer to a document to create the object in. If NULL, the
                |    document associated with the current Editor will be used.
                |  
                |  oNewComponent
                |    Interface pointer to the new component instance placed.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchComponent2
                | Dim objArg1 As SchGRRComp
                | Dim dbVar2(6) As CATSafeArrayVariant
                | Dim objArg3 As Document
                | Dim objArg4 As SchComponent
                | ...
                | objThisIntf.PlaceInSpaceobjArg1,dbVar2,objArg3,objArg4
                | 
                | 
                | 
                | 
        """
        return self.schcomponent2.PlaceInSpace(i_grr, i_db_6__axi, i_doc, o_new_component)

    def place_on_object(self, i_grr, i_db_6__axi, i_object_to_connect, i_doc, o_new_component):
        """
        .. note::
            CAA V5 Visual Basic help

                | PlaceOnObject
                | o Sub PlaceOnObject(    SchGRRComp    iGRR,
                |                         CATSafeArrayVariant    iDb6Axis,
                |                         SchAppConnectable    iObjectToConnect,
                |                         Document    iDoc,
                |                         SchComponent    oNewComponent)
                | 
                | Place a component connected to another component or insert into a
                | route.


                | Parameters:
                | iGRR
                |    Pointer to the component graphical representation.
                |    if NULL the "Primary" graphical representation will be used.
                |  
                |  iDb6Axis[6]
                |    X-axis of the local axis of the new instance
                |    Y-axis of the local axis of the new instance
                |    X-Y coordinates of the orgin of the new instance.
                |    This axis defines the orientation and location of the new instance
                |    in space.
                |  
                |  iObjectToConnect
                |    Pointer to a component to connect the new instance to or a route object
                |    to insert new component into.
                |  
                |  iDoc
                |    Pointer to a document to create the object in. If NULL, the
                |    document associated with the current Editor will be used.
                |  
                |  oNewComponent
                |    Interface pointer to the new component instance placed.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchComponent2
                | Dim objArg1 As SchGRRComp
                | Dim dbVar2(6) As CATSafeArrayVariant
                | Dim objArg3 As SchAppConnectable
                | Dim objArg4 As Document
                | Dim objArg5 As SchComponent
                | ...
                | objThisIntf.PlaceOnObjectobjArg1,dbVar2,objArg3,objArg4,objArg5
                | 
                | 
                | 
                | 
        """
        return self.schcomponent2.PlaceOnObject(i_grr, i_db_6__axi, i_object_to_connect, i_doc, o_new_component)

