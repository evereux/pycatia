#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchBoundaryElem:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a boundary element of a schematic zone.

    """

    def __init__(self, catia):
        self.schboundaryelem = catia.SchBoundaryElem     

    def get_boundary_points(self, o_l_db_pts):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaryPoints
                | o Sub GetBoundaryPoints(    SchListOfDoubles    oLDbPts)
                | 
                | Get the definition points (segments end points) of one side of the
                | boundary. If the side is a curve, these points are the end points  of
                | the chords approximating the curve.


                | Parameters:
                | oLDbPts
                |    A list of X-Y coordinates of the points. 2 doubles per point.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBoundaryElem
                | Dim objArg1 As SchListOfDoubles
                | ...
                | objThisIntf.GetBoundaryPointsobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schboundaryelem.GetBoundaryPoints(o_l_db_pts)

    def get_end_points(self, o_l_db_4__pt):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetEndPoints
                | o Sub GetEndPoints(    SchListOfDoubles    oLDb4Pts)
                | 
                | Get the end points (segments end points) of one side of the boundary.


                | Parameters:
                | oLDb4Pts
                |    An array of 4 doubles.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBoundaryElem
                | Dim objArg1 As SchListOfDoubles
                | ...
                | objThisIntf.GetEndPointsobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schboundaryelem.GetEndPoints(o_l_db_4__pt)

    def list_grr_zone_owners(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListGRRZoneOwners
                | o Func ListGRRZoneOwners(    ) As SchListOfObjects
                | 
                | Get the list of owners of this zone.


                | Parameters:
                | oLGRRZoneOwners
                |    A list of GRRZone which has included this boundary element.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchBoundaryElem
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListGRRZoneOwners
                | 
                | 
                | 
                | 
        """
        return self.schboundaryelem.ListGRRZoneOwners()

