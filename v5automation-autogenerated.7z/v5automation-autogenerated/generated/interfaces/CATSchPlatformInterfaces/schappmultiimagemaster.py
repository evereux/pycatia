#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppMultiImageMaster:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to manage the master object in the Multi-Image-Object
                | concept.

    """

    def __init__(self, catia):
        self.schappmultiimagemaster = catia.SchAppMultiImageMaster     

    def app_add_image(self, i_image):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppAddImage
                | o Sub AppAddImage(    SchAppConnectable    iImage)
                | 
                | Add an image for this master object.


                | Parameters:
                | iImage
                |    Pointer to the image to link this master to.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppMultiImageMaster
                | Dim objImage As SchAppConnectable
                | ...
                | objThisIntf.AppAddImage objImage
                | 
                | 
                | 
                | 
        """
        return self.schappmultiimagemaster.AppAddImage(i_image)

    def app_is_ok_to_create_image(self, i_image_doc, o_b_yes, o_nls_file_name, o_nls_file_key_to_message):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppIsOKToCreateImage
                | o Sub AppIsOKToCreateImage(    Document    iImageDoc,
                |                                boolean    oBYes,
                |                                CATBSTR    oNLSFileName,
                |                                CATBSTR    oNLSFileKeyToMessage)
                | 
                | Check if OK to create an image of this master object.


                | Parameters:
                | iImageDoc
                |    Pointer to the document the image is in.
                |  
                |  oBYes
                |    TRUE if this object is valid to be the master of a MIO relationship. 
                |  
                |  oNLSFileName
                |    File name for the NLS messages.
                |  
                |  oNLSFileKeyToMessage
                |    Message key to the application specific diagnostics.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppMultiImageMaster
                | Dim objImageDoc As Document
                | Dim bYes As boolean
                | Dim strFileName As String
                | Dim strFileKeyToMsg As String
                | ...
                | objThisIntf.AppIsOKToCreateImage objImageDoc,bYes,strFileName,strFileKeyToMsg
                | 
                | 
                | 
                | 
        """
        return self.schappmultiimagemaster.AppIsOKToCreateImage(i_image_doc, o_b_yes, o_nls_file_name, o_nls_file_key_to_message)

    def app_list_images(self, i_l_filter, o_l_images):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppListImages
                | o Sub AppListImages(    SchListOfBSTRs    iLFilter,
                |                         SchListOfObjects    oLImages)
                | 
                | List the images of this master object.


                | Parameters:
                | iLFilter
                |    A list of image class names for filtering (can be NULL).
                |  
                |  oLUKImages
                |    A list of image pointers (a list of CATIASchAppMultiImage pointers).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppMultiImageMaster
                | Dim objLFilter As SchListOfBSTRs
                | Dim objLImages As SchListOfObjects
                | ...
                | objThisIntf.AppListImages objLFilter,objLImages
                | 
                | 
                | 
                | 
        """
        return self.schappmultiimagemaster.AppListImages(i_l_filter, o_l_images)

