#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSchIDLArrowFrequency:
    """
        .. note::
            CAA V5 Visual Basic help

                | Schematic route arrow frequency.Role: Indicates which route segments
                | get a flow arrow display.

    """

    def __init__(self, catia):
        self.catschidlarrowfrequency = catia.CatSchIDLArrowFrequency     

