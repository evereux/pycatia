#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchTempListFactory:
    """
        .. note::
            CAA V5 Visual Basic help

                | Create temporary (non-persistent) lists to be used in VB environment.

    """

    def __init__(self, catia):
        self.schtemplistfactory = catia.SchTempListFactory     

    def create_list_of_bst_rs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateListOfBSTRs
                | o Func CreateListOfBSTRs(    ) As SchListOfBSTRs
                | 
                | This method returns a new empty list of strings.   Returns:  a empty
                | list of strings.    Example:    This example illustrates how to create
                | a new empty list of strings.  Dim SchListFact As SchTempListFactory
                | Dim NewList As SchListOfBSTRs Set NewList =
                | SchListFact.CreateListOfBSTRs


                | Parameters:


        """
        return self.schtemplistfactory.CreateListOfBSTRs()

    def create_list_of_doubles(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateListOfDoubles
                | o Func CreateListOfDoubles(    ) As SchListOfDoubles
                | 
                | This method returns a new empty list of doubles.   Returns:  a empty
                | list of doubles.    Example:    This example illustrates how to create
                | a new empty list of doubles.  Dim SchListFact As SchTempListFactory
                | Dim NewList As SchListOfDoubles Set NewList =
                | SchListFact.CreateListOfDoubles


                | Parameters:


        """
        return self.schtemplistfactory.CreateListOfDoubles()

    def create_list_of_longs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateListOfLongs
                | o Func CreateListOfLongs(    ) As SchListOfLongs
                | 
                | This method returns a new empty list of long integers.   Returns:  a
                | empty list of long integers.    Example:    This example illustrates
                | how to create a new empty list of long integers.  Dim SchListFact As
                | SchTempListFactory Dim NewList As SchListOfLongs Set NewList =
                | SchListFact.CreateListOfLongs


                | Parameters:


        """
        return self.schtemplistfactory.CreateListOfLongs()

    def create_list_of_objects(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateListOfObjects
                | o Func CreateListOfObjects(    ) As SchListOfObjects
                | 
                | This method returns a new empty list of objects.   Returns:  a empty
                | list of objects.    Example:    This example illustrates how to create
                | a new empty list of objects.  Dim SchListFact As SchTempListFactory
                | Dim NewList As SchListOfObjects Set NewList =
                | SchListFact.CreateListOfObjects


                | Parameters:


        """
        return self.schtemplistfactory.CreateListOfObjects()

