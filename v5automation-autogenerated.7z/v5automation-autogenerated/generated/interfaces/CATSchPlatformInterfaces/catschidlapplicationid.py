#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSchIDLApplicationID:
    """
        .. note::
            CAA V5 Visual Basic help

                | DS supported schematic application ID.Role: Schematic application ID.

    """

    def __init__(self, catia):
        self.catschidlapplicationid = catia.CatSchIDLApplicationID     

