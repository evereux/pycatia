#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchReplace:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage existing schematic component instances.

    """

    def __init__(self, catia):
        self.schreplace = catia.SchReplace     

    def replace(self, i_grr_to_be_placed, i_sch_comp_to_be_removed):
        """
        .. note::
            CAA V5 Visual Basic help

                | Replace
                | o Func Replace(    SchGRRComp    iGRRToBePlaced,
                |                    SchComponent    iSchCompToBeRemoved) As SchComponent
                | 
                | Replace an existing component with this component.


                | Parameters:
                | iGRRToBePlaced
                |    Pointer to the component graphical representation of this component to be placed.
                |    if NULL the first representation found will be used.
                |  
                |  iSchCompToBeRemoved
                |    Pointer to the existing component to be replaced by this component.
                |  
                |  oNewComponent
                |    Interface pointer to the new component instance placed.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchReplace
                | Dim objArg1 As SchGRRComp
                | Dim objArg2 As SchComponent
                | Dim objArg3 As SchComponent
                | ...
                | Set objArg3 = objThisIntf.Replace(objArg1,objArg2)
                | 
                | 
                | 
                | 
        """
        return self.schreplace.Replace(i_grr_to_be_placed, i_sch_comp_to_be_removed)

