#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAnnotationBreak:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage an annotation break operations.

    """

    def __init__(self, catia):
        self.schannotationbreak = catia.SchAnnotationBreak     

    def flip_over_line(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlipOverLine
                | o Sub FlipOverLine(    )
                | 
                | Mirror the symbol over the route segment line that ends in the
                | connector on which the symbol is placed.  Example:     Dim objThisIntf
                | As SchAnnotationBreak  ... objThisIntf.FlipOverLine


                | Parameters:


        """
        return self.schannotationbreak.FlipOverLine()

    def flip_over_orthogonal_line(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlipOverOrthogonalLine
                | o Sub FlipOverOrthogonalLine(    )
                | 
                | Mirror the symbol over the line orthogonal to the route segment line
                | that ends in the connector on which the symbol is placed and going
                | through the connector's position.  Example:     Dim objThisIntf As
                | SchAnnotationBreak  ... objThisIntf.FlipOverOrthogonalLine


                | Parameters:


        """
        return self.schannotationbreak.FlipOverOrthogonalLine()

    def scale(self, i_db_scale_factor):
        """
        .. note::
            CAA V5 Visual Basic help

                | Scale
                | o Sub Scale(    double    iDbScaleFactor)
                | 
                | Scale the symbol.


                | Parameters:
                | iDbScaleFactor
                |    The scale factor to scale the symbol by.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAnnotationBreak
                | Dim dbVar1 As Double
                | ...
                | objThisIntf.ScaledbVar1
                | 
                | 
                | 
                | 
        """
        return self.schannotationbreak.Scale(i_db_scale_factor)

