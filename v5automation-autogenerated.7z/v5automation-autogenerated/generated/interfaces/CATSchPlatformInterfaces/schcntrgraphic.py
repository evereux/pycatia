#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchCntrGraphic:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the graphical representation of a schematic connector.

    """

    def __init__(self, catia):
        self.schcntrgraphic = catia.SchCntrGraphic     

    def add_graphical_primitive(self, i_grr_to_add, i_grr):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddGraphicalPrimitive
                | o Sub AddGraphicalPrimitive(    SchGRR    iGRRToAdd,
                |                                 SchGRR    iGRR)
                | 
                | Add a graphical primitive to a connector.


                | Parameters:
                | iGRRToAdd
                |    The connector graphical primitive to be added to the connector.
                |  
                |  iGRR
                |    The component or route graphical representation that points to 
                |    the connector graphical primitive.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrGraphic
                | Dim objArg1 As SchGRR
                | Dim objArg2 As SchGRR
                | ...
                | objThisIntf.AddGraphicalPrimitiveobjArg1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schcntrgraphic.AddGraphicalPrimitive(i_grr_to_add, i_grr)

    def list_graphical_primitives(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListGraphicalPrimitives
                | o Func ListGraphicalPrimitives(    ) As SchListOfObjects
                | 
                | List all graphical primitives of a connector.


                | Parameters:
                | oLGRR
                |    A list of graphical primitives
                |    (members are CATISchGRR interface pointers).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrGraphic
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListGraphicalPrimitives
                | 
                | 
                | 
                | 
        """
        return self.schcntrgraphic.ListGraphicalPrimitives()

    def remove_graphical_primitive(self, i_grr_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveGraphicalPrimitive
                | o Sub RemoveGraphicalPrimitive(    SchGRR    iGRRToRemove)
                | 
                | Remove a graphical primitive from a connector.


                | Parameters:
                | iGRRToRemove
                |    The connector graphical primitive to be removed from the connector.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrGraphic
                | Dim objArg1 As SchGRR
                | ...
                | objThisIntf.RemoveGraphicalPrimitiveobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schcntrgraphic.RemoveGraphicalPrimitive(i_grr_to_remove)

