#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchCntrLocation:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the location of a schematic connector.

    """

    def __init__(self, catia):
        self.schcntrlocation = catia.SchCntrLocation     

    def get_align_vector(self, i_grr, o_db_2__align_vecto):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAlignVector
                | o Sub GetAlignVector(    SchGRR    iGRR,
                |                          SchListOfDoubles    oDb2AlignVector)
                | 
                | Get the current alignment vector of the connector.


                | Parameters:
                | iGRR
                |    Pointer to the graphical primitive or the graphical image or the
                |    graphical primitives of the owner of the connector.
                |  
                |  oDb2AlignVector
                |    X-Y component of the current alignment vector of
                |    the connector.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrLocation
                | Dim objArg1 As SchGRR
                | Dim objArg2 As SchListOfDoubles
                | ...
                | objThisIntf.GetAlignVectorobjArg1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schcntrlocation.GetAlignVector(i_grr, o_db_2__align_vecto)

    def get_position(self, i_grr, o_db_2__positio):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPosition
                | o Sub GetPosition(    SchGRR    iGRR,
                |                       SchListOfDoubles    oDb2Position)
                | 
                | Get the current position of the connector in  absolute coordinates.


                | Parameters:
                | iGRR
                |    Pointer to the graphical primitive or the graphical image or the
                |    graphical primitives of the owner of the connector.
                |  
                |  oDb2Position
                |    Absolute X-Y coordinates of the current position of 
                |    the connector.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrLocation
                | Dim objArg1 As SchGRR
                | Dim objArg2 As SchListOfDoubles
                | ...
                | objThisIntf.GetPositionobjArg1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schcntrlocation.GetPosition(i_grr, o_db_2__positio)

    def get_relative_position(self, o_db_2__relative_positio):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRelativePosition
                | o Sub GetRelativePosition(    SchListOfDoubles    oDb2RelativePosition)
                | 
                | Get the current position of the connector in  relative coordinates.


                | Parameters:
                | oDb2RelativePosition
                |    relative X-Y coordinates of the current position of 
                |    the connector.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrLocation
                | Dim objArg1 As SchListOfDoubles
                | ...
                | objThisIntf.GetRelativePositionobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schcntrlocation.GetRelativePosition(o_db_2__relative_positio)

    def set_align_vector(self, i_grr, i_db_2__align_vecto):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAlignVector
                | o Sub SetAlignVector(    SchGRR    iGRR,
                |                          CATSafeArrayVariant    iDb2AlignVector)
                | 
                | Set the current alignment vector of the connector.


                | Parameters:
                | iGRR
                |    Pointer to the graphical primitive or the graphical image or the
                |    graphical primitives of the owner of the connector.
                |  
                |  iDb2AlignVector
                |    X-Y component of the current alignment vector of
                |    the connector to be set.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrLocation
                | Dim objArg1 As SchGRR
                | Dim dbVar2(2) As CATSafeArrayVariant
                | ...
                | objThisIntf.SetAlignVectorobjArg1,dbVar2
                | 
                | 
                | 
                | 
        """
        return self.schcntrlocation.SetAlignVector(i_grr, i_db_2__align_vecto)

    def set_position(self, i_grr, i_db_2__positio):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPosition
                | o Sub SetPosition(    SchGRR    iGRR,
                |                       CATSafeArrayVariant    iDb2Position)
                | 
                | Set the current position of the connector in  absolute coordinates.
                | All connectors on multi-images are affected because the relative
                | position on connect will be changed accordingly.


                | Parameters:
                | iGRR
                |    Pointer to the graphical primitive or the graphical image or the
                |    graphical primitives of the owner of the connector.. 
                |  
                |  iDb2Position
                |    absolute X-Y coordinates of the current position of 
                |    the connector to be set.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrLocation
                | Dim objArg1 As SchGRR
                | Dim dbVar2(2) As CATSafeArrayVariant
                | ...
                | objThisIntf.SetPositionobjArg1,dbVar2
                | 
                | 
                | 
                | 
        """
        return self.schcntrlocation.SetPosition(i_grr, i_db_2__positio)

    def set_relative_position(self, i_db_2__relative_positio):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRelativePosition
                | o Sub SetRelativePosition(    CATSafeArrayVariant    iDb2RelativePosition)
                | 
                | Set the current position of the connector in absolute coordinates.


                | Parameters:
                | iDb2RelativePosition
                |    relative X-Y coordinates of the current position of 
                |    the connector to be set.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCntrLocation
                | Dim dbVar1(2) As CATSafeArrayVariant
                | ...
                | objThisIntf.SetRelativePositiondbVar1
                | 
                | 
                | 
                | 
        """
        return self.schcntrlocation.SetRelativePosition(i_db_2__relative_positio)

