#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchGRR:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the graphical representation of a schematic object.

    """

    def __init__(self, catia):
        self.schgrr = catia.SchGRR     

    def get_grr_name(self, o_grr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGRRName
                | o Sub GetGRRName(    CATBSTR    oGRRName)
                | 
                | Get current name of the GRR.


                | Parameters:
                | oGRRName
                |    The name of this GRR. A component can be associated with more than one GRRs.
                |    Each GRR is identified by a specific name. Valid names are specified 
                |    by the application when building the component. Every component should have
                |    a GRR named "Primary". The GRR by this name is used in the catalog.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRR
                | Dim strVar1 As String
                | ...
                | objThisIntf.GetGRRNamestrVar1
                | 
                | 
                | 
                | 
        """
        return self.schgrr.GetGRRName(o_grr_name)

    def get_sch_cntr_owners(self, o_cntr_owner, o_grr_owner):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSchCntrOwners
                | o Sub GetSchCntrOwners(    SchAppConnector    oCntrOwner,
                |                            SchGRR    oGRROwner)
                | 
                | Get the schematic objects that own this connector graphic
                | representation.


                | Parameters:
                | oCntrOwner.
                |    A schematic connector that owns this connector graphic representation.
                |  
                |  oGRROwner
                |    A component or route graphic representation that owns this
                |    connector graphic representation.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRR
                | Dim objArg1 As SchAppConnector
                | Dim objArg2 As SchGRR
                | ...
                | objThisIntf.GetSchCntrOwnersobjArg1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schgrr.GetSchCntrOwners(o_cntr_owner, o_grr_owner)

    def get_sch_obj_owner(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSchObjOwner
                | o Func GetSchObjOwner(    ) As SchAppConnectable
                | 
                | Get the schematic object that owns this graphic representation.


                | Parameters:
                | oGRROwner
                |    A schematic object that owns this graphic representation.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRR
                | Dim objArg1 As SchAppConnectable
                | ...
                | Set objArg1 = objThisIntf.GetSchObjOwner
                | 
                | 
                | 
                | 
        """
        return self.schgrr.GetSchObjOwner()

    def list_connected_gr_rs(self, i_grr_owner, i_l_cntble_class_filter, o_l_cntble_gr_rs, o_l_cntbles, o_l_cntrs_on_this_obj, o_l_cntrs_on_connected):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListConnectedGRRs
                | o Sub ListConnectedGRRs(    SchAppConnectable    iGRROwner,
                |                             SchListOfBSTRs    iLCntbleClassFilter,
                |                             SchListOfObjects    oLCntbleGRRs,
                |                             SchListOfObjects    oLCntbles,
                |                             SchListOfObjects    oLCntrsOnThisObj,
                |                             SchListOfObjects    oLCntrsOnConnected)
                | 
                | Get a list of graphical objects that connects to this graphic
                | representation.


                | Parameters:
                | iGRROwner
                |    A CATISchAppConnectable that owns this graphic representation. In
                |    the case of GRRCntr (this object), iGRROwner is the owner
                |    of the owner of this graphic.
                |  
                |  oLCntrClassFilter
                |    A list of all the class types for filtering the output application
                |    objects list.
                |  
                |  oLCntbleGRRs
                |    A list of GRRs connected to this GRR.
                |    (members are CATISchGRR interface pointers). 
                |  
                |  oLCntbles
                |    A list of application objects connected to this object.
                |    (members are CATISchAppConnectable interface pointers). 
                |  
                |  oLCntrsOnThisObj
                |    A list of connectors on this object through which 
                |    the connection is made.
                |    (members are CATISchAppConnector interface pointers).
                |  
                |  oLCntrsOnConnected
                |    A list of connectors on the connected objects through which 
                |    the connection is made.
                |    (members are CATISchAppConnector interface pointers).
                |    Members in this list corresponds to those in oLCntrsOnThisObj in
                |    making the corresponding connections.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRR
                | Dim objArg1 As SchAppConnectable
                | Dim objArg2 As SchListOfBSTRs
                | Dim objArg3 As SchListOfObjects
                | Dim objArg4 As SchListOfObjects
                | Dim objArg5 As SchListOfObjects
                | Dim objArg6 As SchListOfObjects
                | ...
                | objThisIntf.ListConnectedGRRsobjArg1,objArg2,objArg3,objArg4,objArg5,objArg6
                | 
                | 
                | 
                | 
        """
        return self.schgrr.ListConnectedGRRs(i_grr_owner, i_l_cntble_class_filter, o_l_cntble_gr_rs, o_l_cntbles, o_l_cntrs_on_this_obj, o_l_cntrs_on_connected)

    def set_grr_name(self, i_grr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetGRRName
                | o Sub SetGRRName(    CATBSTR    iGRRName)
                | 
                | Set current name of the GRR.


                | Parameters:
                | iGRRName
                |    The name of this GRR to be set.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRR
                | Dim strVar1 As String
                | ...
                | objThisIntf.SetGRRNamestrVar1
                | 
                | 
                | 
                | 
        """
        return self.schgrr.SetGRRName(i_grr_name)

