#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSchIDLGapPriority:
    """
        .. note::
            CAA V5 Visual Basic help

                | Schematic route gap priority.Role: Indicates which route to gap when 2
                | routes intersect.

    """

    def __init__(self, catia):
        self.catschidlgappriority = catia.CatSchIDLGapPriority     

