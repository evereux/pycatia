#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppMultiImage:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to manage the image object in the Multi-Image-Object
                | concept.

    """

    def __init__(self, catia):
        self.schappmultiimage = catia.SchAppMultiImage     

    def app_get_master_document(self, o_document, o_document_name, o_symbolic_link_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppGetMasterDocument
                | o Sub AppGetMasterDocument(    Document    oDocument,
                |                                CATBSTR    oDocumentName,
                |                                CATBSTR    oSymbolicLinkName)
                | 
                | Get the document where the master of this image object resides.


                | Parameters:
                | oDocument
                |    Pointer to the document.
                |  
                |  oDocumentName
                |    Name of the document containing the master.
                | 	
                |  oSymbolicLinkName
                |    Name of the symbolic link.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppMultiImage
                | Dim objDoc As Document
                | Dim strDocName As String
                | Dim strLinkName As String
                | ...
                | objThisIntf.AppGetMasterDocument objDoc,strDocName,strLinkName
                | 
                | 
                | 
                | 
        """
        return self.schappmultiimage.AppGetMasterDocument(o_document, o_document_name, o_symbolic_link_name)

    def app_get_master_object(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppGetMasterObject
                | o Func AppGetMasterObject(    ) As SchAppMultiImageMaster
                | 
                | Get the master object of this image.


                | Parameters:
                | oMasterImage
                |    Pointer to the master object.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppMultiImage
                | Dim objMaster As SchMultiImageMaster
                | ...
                | Set objMaster = objThisIntf.AppGetMasterObject
                | 
                | 
                | 
                | 
        """
        return self.schappmultiimage.AppGetMasterObject()

    def app_is_up_to_date(self, o_status):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppIsUpToDate
                | o Sub AppIsUpToDate(    CatSchIDLMultiImageStatus    oStatus)
                | 
                | Check if the image object is up-to-date.


                | Parameters:
                | oStatus
                |    Status of the image object.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppMultiImage
                | ...
                | objThisIntf.AppIsUpToDate CatSchIDLMultiImageStatus_Enum
                | 
                | 
                | 
                | 
        """
        return self.schappmultiimage.AppIsUpToDate(o_status)

    def app_update(self, i_master_image, o_image):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppUpdate
                | o Sub AppUpdate(    SchAppMultiImageMaster    iMasterImage,
                |                     SchAppMultiImage    oImage)
                | 
                | Update the image object.


                | Parameters:
                | iMasterImage
                |    This is an optional input. 
                |    Not NULL - the application has a handle on the master to update 
                |    this image (for example in DSA application, the application will 
                |    make sure the ID of this image is the same as the input master).
                |    NULL - the application will find the master based on the specific way
                |    it models the MIO concept.
                |  Sample case: the application will make sure the ID of this image is the same as the input master.
                |  
                |  oImage
                |    Pointer to a new image object created if existing image object has to be
                |    replaced during the update process.
                |    This pointer is NULL if the image object is not replaced.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppMultiImage
                | Dim objMaster As SchAppMultiImageMaster
                | Dim objNewImage As SchAppMultiImage
                | ...
                | objThisIntf.AppUpdate objMaster,objNewImage
                | 
                | 
                | 
                | 
        """
        return self.schappmultiimage.AppUpdate(i_master_image, o_image)

