#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppCntrData:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a schematic connector data.

    """

    def __init__(self, catia):
        self.schappcntrdata = catia.SchAppCntrData     

    def app_get_application_data(self, i_l_app_data, i_l_app_nls_data):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppGetApplicationData
                | o Sub AppGetApplicationData(    SchListOfBSTRs    iLAppData,
                |                                 SchListOfBSTRs    iLAppNlsData)
                | 
                | Get application data.


                | Parameters:
                | iLAppData
                |     A list of character string data.
                |  
                |  iLAppNlsData
                |     A list of character string data.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrData
                | Dim objArg1 As SchListOfBSTRs
                | Dim objArg2 As SchListOfBSTRs
                | ...
                | objThisIntf.AppGetApplicationDataobjArg1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdata.AppGetApplicationData(i_l_app_data, i_l_app_nls_data)

    def app_list_potential_data(self, i_l_app_data, i_l_app_nls_data):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppListPotentialData
                | o Sub AppListPotentialData(    SchListOfBSTRs    iLAppData,
                |                                SchListOfBSTRs    iLAppNlsData)
                | 
                | Get a list valid potential application data that can be set.


                | Parameters:
                | iLAppData
                |     A list of character string data.
                |  
                |  iLAppNlsData
                |     A list of character string data.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrData
                | Dim objArg1 As SchListOfBSTRs
                | Dim objArg2 As SchListOfBSTRs
                | ...
                | objThisIntf.AppListPotentialDataobjArg1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdata.AppListPotentialData(i_l_app_data, i_l_app_nls_data)

    def app_set_application_data(self, i_l_app_data):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppSetApplicationData
                | o Sub AppSetApplicationData(    SchListOfBSTRs    iLAppData)
                | 
                | Set application data.


                | Parameters:
                | iLAppData
                |     A list of character string data.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrData
                | Dim objArg1 As SchListOfBSTRs
                | ...
                | objThisIntf.AppSetApplicationDataobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schappcntrdata.AppSetApplicationData(i_l_app_data)

