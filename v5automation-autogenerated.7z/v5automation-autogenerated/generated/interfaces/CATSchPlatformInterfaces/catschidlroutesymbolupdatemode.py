#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSchIDLRouteSymbolUpdateMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Flag for whether or not to update location of route symbols when
                | setting a route's path.Role: Indicate whether or not to update
                | location of the route symbols.

    """

    def __init__(self, catia):
        self.catschidlroutesymbolupdatemode = catia.CatSchIDLRouteSymbolUpdateMode     

