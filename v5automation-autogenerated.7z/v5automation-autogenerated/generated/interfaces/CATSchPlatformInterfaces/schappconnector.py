#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppConnector:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage a schematic connector.

    """

    def __init__(self, catia):
        self.schappconnector = catia.SchAppConnector     

    def app_connect(self, i_cntr_to_connect):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppConnect
                | o Func AppConnect(    SchAppConnector    iCntrToConnect) As SchAppConnection
                | 
                | Connect to an input connector.


                | Parameters:
                | iCntrToConnect
                |    A schematic connector object to connect to
                |  
                |  oConnection
                |    Connection created


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnector
                | Dim objArg1 As SchAppConnector
                | Dim objArg2 As SchAppConnection
                | ...
                | Set objArg2 = objThisIntf.AppConnect(objArg1)
                | 
                | 
                | 
                | 
        """
        return self.schappconnector.AppConnect(i_cntr_to_connect)

    def app_connect_branch(self, i_cntr_to_connect):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppConnectBranch
                | o Func AppConnectBranch(    SchAppConnector    iCntrToConnect) As SchAppConnection
                | 
                | Connect to an input connector for Branch.


                | Parameters:
                | iCntrToConnect
                |    A schematic connector object to connect to
                |  
                |  oConnection
                |    Connection created


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnector
                | Dim objArg1 As SchAppConnector
                | Dim objArg2 As SchAppConnection
                | ...
                | Set objArg2 = objThisIntf.AppConnectBranch(objArg1)
                | 
                | 
                | 
                | 
        """
        return self.schappconnector.AppConnectBranch(i_cntr_to_connect)

    def app_disconnect(self, i_cntr_to_dis_connect):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppDisconnect
                | o Sub AppDisconnect(    SchAppConnector    iCntrToDisConnect)
                | 
                | Disconnect from an input connector.


                | Parameters:
                | iCntrToDisconnect
                |    A schematic connector object to disconnect from


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnector
                | Dim objArg1 As SchAppConnector
                | ...
                | objThisIntf.AppDisconnectobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schappconnector.AppDisconnect(i_cntr_to_dis_connect)

    def app_get_associated_connectable(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppGetAssociatedConnectable
                | o Func AppGetAssociatedConnectable(    ) As SchAppConnectable
                | 
                | Find the application object that owns this connector.


                | Parameters:
                | oConnectable
                |    An application object that the connector belongs to.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnector
                | Dim objArg1 As SchAppConnectable
                | ...
                | Set objArg1 = objThisIntf.AppGetAssociatedConnectable
                | 
                | 
                | 
                | 
        """
        return self.schappconnector.AppGetAssociatedConnectable()

    def app_is_cntr_connected(self, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppIsCntrConnected
                | o Sub AppIsCntrConnected(    boolean    oBYes)
                | 
                | Query whether the connector has been connected.


                | Parameters:
                | oBYes
                |    If TRUE, then it is connected


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnector
                | Dim bVar1 As boolean
                | ...
                | objThisIntf.AppIsCntrConnectedbVar1
                | 
                | 
                | 
                | 
        """
        return self.schappconnector.AppIsCntrConnected(o_b_yes)

    def app_list_compatible_types(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppListCompatibleTypes
                | o Func AppListCompatibleTypes(    ) As SchListOfBSTRs
                | 
                | Find all the class types of connector that are compatible with this
                | connector for connections.


                | Parameters:
                | oLCntrCompatClassTypes
                |    A list of all the class types of connectors that are compatible
                |    with this connector for connections.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnector
                | Dim objArg1 As SchListOfBSTRs
                | ...
                | Set objArg1 = objThisIntf.AppListCompatibleTypes
                | 
                | 
                | 
                | 
        """
        return self.schappconnector.AppListCompatibleTypes()

    def app_list_connections(self, i_l_cntn_class_filter):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppListConnections
                | o Func AppListConnections(    SchListOfBSTRs    iLCntnClassFilter) As SchListOfObjects
                | 
                | Find all the connections that include this connector.


                | Parameters:
                | oLCntnClassFilter
                |    A list of all the class types for filtering the output connection
                |    list.
                |  
                |  oLConnections
                |    A list of connections that include this connector
                |    (members are CATISchAppConnection interface pointers).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnector
                | Dim objArg1 As SchListOfBSTRs
                | Dim objArg2 As SchListOfObjects
                | ...
                | Set objArg2 = objThisIntf.AppListConnections(objArg1)
                | 
                | 
                | 
                | 
        """
        return self.schappconnector.AppListConnections(i_l_cntn_class_filter)

    def app_ok_to_no_show_connected_cntr(self, o_b_yes):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppOKToNoShowConnectedCntr
                | o Sub AppOKToNoShowConnectedCntr(    boolean    oBYes)
                | 
                | Query whether it is OK to no show the connector after it is connected.


                | Parameters:
                | oBYes
                |    If TRUE, then it is OK to no show.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppConnector
                | Dim bVar1 As boolean
                | ...
                | objThisIntf.AppOKToNoShowConnectedCntrbVar1
                | 
                | 
                | 
                | 
        """
        return self.schappconnector.AppOKToNoShowConnectedCntr(o_b_yes)

