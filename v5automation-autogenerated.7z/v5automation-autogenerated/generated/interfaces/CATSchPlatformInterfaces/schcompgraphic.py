#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchCompGraphic:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the graphical representation of a schematic component.

    """

    def __init__(self, catia):
        self.schcompgraphic = catia.SchCompGraphic     

    def activate(self, i_grr_name, i_db_2__where_a, o_grr):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activate
                | o Sub Activate(    CATBSTR    iGRRName,
                |                    CATSafeArrayVariant    iDb2WhereAt,
                |                    SchGRRComp    oGRR)
                | 
                | To add a new image to an existing object. This new image is an
                | instance of graphical representation with the input name.


                | Parameters:
                | iGRRName
                |    The name of the graphic representation
                |  
                |  iDb2WhereAt
                |    The x-y coordinates of the image position. If NULL, the image
                |    will be positioned at the origin.
                |  
                |  oGRR
                |    Pointer to the new graphical image of the component.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompGraphic
                | Dim strVar1 As String
                | Dim dbVar2(2) As CATSafeArrayVariant
                | Dim objArg3 As SchGRRComp
                | ...
                | objThisIntf.ActivatestrVar1,dbVar2,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schcompgraphic.Activate(i_grr_name, i_db_2__where_a, o_grr)

    def add_graphical_representation(self, i_grr_to_add):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddGraphicalRepresentation
                | o Sub AddGraphicalRepresentation(    SchGRRComp    iGRRToAdd)
                | 
                | Add a graphical representation to a component.


                | Parameters:
                | iGRRToAdd
                |    The graphical representation to be added to the component.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompGraphic
                | Dim objArg1 As SchGRRComp
                | ...
                | objThisIntf.AddGraphicalRepresentationobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schcompgraphic.AddGraphicalRepresentation(i_grr_to_add)

    def deactivate(self, i_grr):
        """
        .. note::
            CAA V5 Visual Basic help

                | Deactivate
                | o Sub Deactivate(    SchGRRComp    iGRR)
                | 
                | To remove an image to an existing object.


                | Parameters:
                | iGRR
                |    The graphical image to be removed from the component. 
                |  
                |  iDb2WhereAt
                |    The x-y coordinates of the image position. If NULL, the image
                |    will be positioned at the origin.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompGraphic
                | Dim objArg1 As SchGRRComp
                | ...
                | objThisIntf.DeactivateobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schcompgraphic.Deactivate(i_grr)

    def list_graphical_images(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListGraphicalImages
                | o Func ListGraphicalImages(    ) As SchListOfObjects
                | 
                | List all graphical images (instances of the rep) of a component.


                | Parameters:
                | oLGRR
                |    A list of graphical images
                |    (members are CATISchGRRComp interface pointers).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompGraphic
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListGraphicalImages
                | 
                | 
                | 
                | 
        """
        return self.schcompgraphic.ListGraphicalImages()

    def list_graphical_representations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListGraphicalRepresentations
                | o Func ListGraphicalRepresentations(    ) As SchListOfObjects
                | 
                | List all graphical representation of a component.


                | Parameters:
                | oLGRR
                |    A list of graphical representations
                |    (members are CATISchGRRComp interface pointers).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompGraphic
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListGraphicalRepresentations
                | 
                | 
                | 
                | 
        """
        return self.schcompgraphic.ListGraphicalRepresentations()

    def remove_graphical_representation(self, i_grr_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveGraphicalRepresentation
                | o Sub RemoveGraphicalRepresentation(    SchGRRComp    iGRRToRemove)
                | 
                | Remove a graphical representation from a component.


                | Parameters:
                | iGRRToRemove
                |    The graphical representation to be removed from the component.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompGraphic
                | Dim objArg1 As SchGRRComp
                | ...
                | objThisIntf.RemoveGraphicalRepresentationobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schcompgraphic.RemoveGraphicalRepresentation(i_grr_to_remove)

    def switch(self, i_grr, i_grr_name, o_grr):
        """
        .. note::
            CAA V5 Visual Basic help

                | Switch
                | o Sub Switch(    SchGRRComp    iGRR,
                |                  CATBSTR    iGRRName,
                |                  SchGRRComp    oGRR)
                | 
                | Replace the input image object with an image of the graphical
                | representation with the input name.


                | Parameters:
                | iGRR
                |    Pointer to the component graphical image to be switched.
                |  
                |  oGRR
                |    Pointer to the new graphical image of the component.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompGraphic
                | Dim objArg1 As SchGRRComp
                | Dim strVar2 As String
                | Dim objArg3 As SchGRRComp
                | ...
                | objThisIntf.SwitchobjArg1,strVar2,objArg3
                | 
                | 
                | 
                | 
        """
        return self.schcompgraphic.Switch(i_grr, i_grr_name, o_grr)

    def switch_all(self, i_grr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | SwitchAll
                | o Sub SwitchAll(    CATBSTR    iGRRName)
                | 
                | Replace all occurances of the images of this component with those of
                | the graphical representation with the input name.


                | Parameters:
                | iGRRName
                |    The name of the graphical representation


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchCompGraphic
                | Dim strVar1 As String
                | ...
                | objThisIntf.SwitchAllstrVar1
                | 
                | 
                | 
                | 
        """
        return self.schcompgraphic.SwitchAll(i_grr_name)

