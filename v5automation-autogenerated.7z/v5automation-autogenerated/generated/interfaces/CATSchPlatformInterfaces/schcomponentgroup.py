#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchComponentGroup:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a temporary group of schematic objects for component
                | placement.

    """

    def __init__(self, catia):
        self.schcomponentgroup = catia.SchComponentGroup     

    def add_member(self, i_cntbl_to_add):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddMember
                | o Sub AddMember(    SchAppConnectable    iCntblToAdd)
                | 
                | Add a member to the component group.


                | Parameters:
                | iCntblToAdd
                |    The application connectable to be added to the group


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchComponentGroup
                | Dim objArg1 As SchAppConnectable
                | ...
                | objThisIntf.AddMemberobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schcomponentgroup.AddMember(i_cntbl_to_add)

    def list_members(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListMembers
                | o Func ListMembers(    ) As SchListOfObjects
                | 
                | List all connectable members in the group.


                | Parameters:
                | oLGRR
                |    A list of connectables.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchComponentGroup
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListMembers
                | 
                | 
                | 
                | 
        """
        return self.schcomponentgroup.ListMembers()

    def remove_member(self, i_cntbl_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveMember
                | o Sub RemoveMember(    SchAppConnectable    iCntblToRemove)
                | 
                | Remove a member to the component group.


                | Parameters:
                | iCntbleToRemove
                |    The application connectable to be removed from the group


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchComponentGroup
                | Dim objArg1 As SchAppConnectable
                | ...
                | objThisIntf.RemoveMemberobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schcomponentgroup.RemoveMember(i_cntbl_to_remove)

