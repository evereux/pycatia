#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchGRRCntr:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the graphical representation of a schematic connector.

    """

    def __init__(self, catia):
        self.schgrrcntr = catia.SchGRRCntr     

    def get_symbol(self, o_grr, o_e_symbol_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSymbol
                | o Sub GetSymbol(    SchGRR    oGRR,
                |                     CatSchIDLCntrSymbolType    oESymbolType)
                | 
                | Get the graphical primitive of a connector.


                | Parameters:
                | oGRR
                |    The graphical primitive (ditto) used to represent a connector.
                |  
                |  oESymbolType
                |    Connector symbol type such as: point, point/vector,
                |    OnOffSheet, LineBoundary.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRCntr
                | Dim objArg1 As SchGRR
                | 
                | ...
                | objThisIntf.GetSymbolobjArg1,CatSchIDLCntrSymbolType_Enum
                | 
                | 
                | 
                | 
        """
        return self.schgrrcntr.GetSymbol(o_grr, o_e_symbol_type)

    def remove_symbol(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveSymbol
                | o Sub RemoveSymbol(    )
                | 
                | Remove the graphical primitive used as the connector's symbol. The
                | default connector's symbol type will be set to point.      Example:
                | Dim objThisIntf As SchGRRCntr  ... objThisIntf.RemoveSymbol


                | Parameters:


        """
        return self.schgrrcntr.RemoveSymbol()

    def set_symbol(self, i_grr_symbol, i_e_symbol_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSymbol
                | o Sub SetSymbol(    SchGRR    iGRRSymbol,
                |                     CatSchIDLCntrSymbolType    iESymbolType)
                | 
                | Set the symbol or graphics used to represent a connector.


                | Parameters:
                | iGRRSymbol
                |    The graphical primitive (detail) to be used as the connector's symbol.
                |    iGRRSymbol can be NULL if iESymbolType is a point or point/vector.
                |  
                |  iESymbolType
                |    Connector symbol type such as: point, point/vector,
                |    OnOffSheet, LineBoundary.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRCntr
                | Dim objArg1 As SchGRR
                | 
                | ...
                | objThisIntf.SetSymbolobjArg1,CatSchIDLCntrSymbolType_Enum
                | 
                | 
                | 
                | 
        """
        return self.schgrrcntr.SetSymbol(i_grr_symbol, i_e_symbol_type)

