#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppObjectFactory:
    """
        .. note::
            CAA V5 Visual Basic help

                | Application factory to create application objects.

    """

    def __init__(self, catia):
        self.schappobjectfactory = catia.SchAppObjectFactory     

    def app_create_comp_ref(self, i_app_comp_class_type, o_app_comp):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppCreateCompRef
                | o Sub AppCreateCompRef(    CATBSTR    iAppCompClassType,
                |                            AnyObject    oAppComp)
                | 
                | Create an Application Component reference.


                | Parameters:
                | iAppCompClassType
                |    Class type of the Application Component reference.
                |  
                |  oAppComp
                |    The new Application Component object created (CATISchAppComponent
                |    interface pointer).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppObjectFactory
                | Dim strVar1 As String
                | Dim objArg2 As AnyObject
                | ...
                | objThisIntf.AppCreateCompRefstrVar1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schappobjectfactory.AppCreateCompRef(i_app_comp_class_type, o_app_comp)

    def app_create_connection(self, i_app_cntn_class_type, o_app_connection):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppCreateConnection
                | o Sub AppCreateConnection(    CATBSTR    iAppCntnClassType,
                |                               AnyObject    oAppConnection)
                | 
                | Create an Application Connection object.


                | Parameters:
                | iAppCntnClassType
                |    Class type of the Application Connection object.
                |  
                |  oAppConnection
                |    The new Application Connection object created (CATISchAppConnection
                |    interface pointer).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppObjectFactory
                | Dim strVar1 As String
                | Dim objArg2 As AnyObject
                | ...
                | objThisIntf.AppCreateConnectionstrVar1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schappobjectfactory.AppCreateConnection(i_app_cntn_class_type, o_app_connection)

    def app_create_group(self, i_app_group_class_type, o_app_group):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppCreateGroup
                | o Sub AppCreateGroup(    CATBSTR    iAppGroupClassType,
                |                          AnyObject    oAppGroup)
                | 
                | Create an Application Group object.


                | Parameters:
                | iAppGroupClassType
                |    Class type of the Application Group object.
                |  
                |  oAppGroup
                |    The new Application Group object created (CATISchAppGroup
                |    interface pointer).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppObjectFactory
                | Dim strVar1 As String
                | Dim objArg2 As AnyObject
                | ...
                | objThisIntf.AppCreateGroupstrVar1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schappobjectfactory.AppCreateGroup(i_app_group_class_type, o_app_group)

    def app_create_route(self, i_app_route_class_type, o_app_route, i_log_line_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppCreateRoute
                | o Sub AppCreateRoute(    CATBSTR    iAppRouteClassType,
                |                          AnyObject    oAppRoute,
                |                          CATBSTR    iLogLineID)
                | 
                | Create an Application Route object.


                | Parameters:
                | iAppRouteClassType
                |    Class type of the Application Route object.
                |  
                |  oAppRoute
                |    The new Application Route object created (CATISchAppRoute
                |    interface pointer).
                |  
                |  iLogLineID
                |    The logical line ID that will contain the new route.
                |    This is an optional input.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppObjectFactory
                | Dim strVar1 As String
                | Dim objArg2 As AnyObject
                | Dim strVar3 As String
                | ...
                | objThisIntf.AppCreateRoutestrVar1,objArg2,strVar3
                | 
                | 
                | 
                | 
        """
        return self.schappobjectfactory.AppCreateRoute(i_app_route_class_type, o_app_route, i_log_line_id)

    def app_create_route_from_ref(self, i_route_reference, o_app_route, i_log_line_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppCreateRouteFromRef
                | o Sub AppCreateRouteFromRef(    SchAppRoute    iRouteReference,
                |                                 AnyObject    oAppRoute,
                |                                 CATBSTR    iLogLineID)
                | 
                | Create an Application Route object with a specific reference.


                | Parameters:
                | iAppRouteRef
                |    Route reference to creaet the output route from
                |  
                |  oAppRoute
                |    The new Application Route object created (CATISchAppRoute
                |    interface pointer).
                |  
                |  iLogLineID
                |    The logical line ID that will contain the new route.
                |    This is an optional input.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppObjectFactory
                | Dim objArg1 As SchAppRoute
                | Dim objArg2 As AnyObject
                | Dim strVar3 As String
                | ...
                | objThisIntf.AppCreateRouteFromRefobjArg1,objArg2,strVar3
                | 
                | 
                | 
                | 
        """
        return self.schappobjectfactory.AppCreateRouteFromRef(i_route_reference, o_app_route, i_log_line_id)

    def app_create_zone(self, i_app_zone_class_type, o_app_zone):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppCreateZone
                | o Sub AppCreateZone(    CATBSTR    iAppZoneClassType,
                |                         AnyObject    oAppZone)
                | 
                | Create an Application Zone object.


                | Parameters:
                | iAppZoneClassType
                |    Class type of the Application Zone object.
                |  
                |  oAppZone
                |    The new Application Zone object created (CATISchAppZone
                |    interface pointer).


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppObjectFactory
                | Dim strVar1 As String
                | Dim objArg2 As AnyObject
                | ...
                | objThisIntf.AppCreateZonestrVar1,objArg2
                | 
                | 
                | 
                | 
        """
        return self.schappobjectfactory.AppCreateZone(i_app_zone_class_type, o_app_zone)

