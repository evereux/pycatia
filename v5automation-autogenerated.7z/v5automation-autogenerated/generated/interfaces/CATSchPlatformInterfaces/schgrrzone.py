#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchGRRZone:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage the graphical representation of a schematic zone.

    """

    def __init__(self, catia):
        self.schgrrzone = catia.SchGRRZone     

    def add_boundary_element(self, i_zone_bndy_to_add):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddBoundaryElement
                | o Sub AddBoundaryElement(    SchBoundaryElem    iZoneBndyToAdd)
                | 
                | Add a boundary element to the zone.


                | Parameters:
                | iZoneBndy
                |    The geometric boundary elements to be added.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRZone
                | Dim objArg1 As SchBoundaryElem
                | ...
                | objThisIntf.AddBoundaryElementobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schgrrzone.AddBoundaryElement(i_zone_bndy_to_add)

    def is_boundary_valid(self, b_is_valid):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsBoundaryValid
                | o Sub IsBoundaryValid(    boolean    BIsValid)
                | 
                | Check whether the boundary of this zone graphical representation is
                | valid.


                | Parameters:
                | oLZoneBndy
                |    Set to TRUE if the boundary is a closed polygon


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRZone
                | Dim bVar1 As boolean
                | ...
                | objThisIntf.IsBoundaryValidbVar1
                | 
                | 
                | 
                | 
        """
        return self.schgrrzone.IsBoundaryValid(b_is_valid)

    def list_boundary_elements(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListBoundaryElements
                | o Func ListBoundaryElements(    ) As SchListOfObjects
                | 
                | List all boundary elements of this zone graphical representation.


                | Parameters:
                | oLZoneBndy
                |    List of geometric boundaries of this zone graphical representation


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRZone
                | Dim objArg1 As SchListOfObjects
                | ...
                | Set objArg1 = objThisIntf.ListBoundaryElements
                | 
                | 
                | 
                | 
        """
        return self.schgrrzone.ListBoundaryElements()

    def remove_boundary_element(self, i_zone_bndy_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveBoundaryElement
                | o Sub RemoveBoundaryElement(    SchBoundaryElem    iZoneBndyToRemove)
                | 
                | Remove a boundary element to the zone.


                | Parameters:
                | iZoneBndy
                |    The geometric boundary elements to be added.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchGRRZone
                | Dim objArg1 As SchBoundaryElem
                | ...
                | objThisIntf.RemoveBoundaryElementobjArg1
                | 
                | 
                | 
                | 
        """
        return self.schgrrzone.RemoveBoundaryElement(i_zone_bndy_to_remove)

