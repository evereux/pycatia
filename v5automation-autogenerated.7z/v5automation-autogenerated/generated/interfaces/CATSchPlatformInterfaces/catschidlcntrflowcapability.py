#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatSchIDLCntrFlowCapability:
    """
        .. note::
            CAA V5 Visual Basic help

                | Schematic connector flow directions.Role: Possible flow directions of
                | a connector.

    """

    def __init__(self, catia):
        self.catschidlcntrflowcapability = catia.CatSchIDLCntrFlowCapability     

