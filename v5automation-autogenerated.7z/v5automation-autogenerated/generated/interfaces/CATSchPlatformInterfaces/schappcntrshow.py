#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SchAppCntrShow:
    """
        .. note::
            CAA V5 Visual Basic help

                | Manage graphical representation of schematic connector.

    """

    def __init__(self, catia):
        self.schappcntrshow = catia.SchAppCntrShow     

    def app_show_cntr(self, o_b_show):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppShowCntr
                | o Sub AppShowCntr(    boolean    oBShow)
                | 
                | Defines show status of the applicaton connector.


                | Parameters:
                | oBShow
                |    True if the connector show status is Show.
                |    False if the connector show status is NoShow.


                | Examples:
                | 
                | 
                | Dim objThisIntf As SchAppCntrShow
                | Dim bVar1 As boolean
                | ...
                | objThisIntf.AppShowCntrbVar1
                | 
                | 
                | 
                | 
        """
        return self.schappcntrshow.AppShowCntr(o_b_show)

