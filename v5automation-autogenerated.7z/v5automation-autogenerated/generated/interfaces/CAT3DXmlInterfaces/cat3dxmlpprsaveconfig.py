#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Cat3DXmlPPRSaveConfig:
    """
        .. note::
            CAA V5 Visual Basic help

                | The PPR save config  setting  attribute range  of  values.

    """

    def __init__(self, catia):
        self.cat3dxmlpprsaveconfig = catia.Cat3DXmlPPRSaveConfig     

