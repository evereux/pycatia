#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Export3DXmlSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents  a  setting  controller  for  the  3D XML  export
                | settings.Role:  This  interface  is  implemented  by  a  component
                | which    represents  the  controller  of  the  3D XML  export
                | settings.

    """

    def __init__(self, catia):
        self.export3dxmlsettingatt = catia.Export3DXmlSettingAtt     

    @property
    def alternate_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AlternateView
                | o Property AlternateView(    ) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','get_DesignReview','Export3DXmlSettingAtt.get_D
                | esignReview')  Returns or sets the alternate view activation flag.
                | Example:    This  example  activates  the  alternate  view  export.
                | export3DXmlSettingAtt.AlternateView = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.AlternateView

    @property
    def animation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Animation
                | o Property Animation(    ) As boolean
                | 
                | Returns or sets the animation activation flag.     Example:    This
                | example  activates  the  animation  export.
                | export3DXmlSettingAtt.Animation = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.Animation

    @property
    def annotated_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnnotatedView
                | o Property AnnotatedView(    ) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','get_DesignReview','Export3DXmlSettingAtt.get_D
                | esignReview')   Returns or sets the annotated view activation flag.
                | Example:    This  example  activates  the  annotated  view  export.
                | export3DXmlSettingAtt.AnnotatedView = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.AnnotatedView

    @property
    def annotation_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Annotation3D
                | o Property Annotation3D(    ) As boolean
                | 
                | Returns or sets the 3D annotation activation flag.     Example:
                | This  example  activates  the  3D annotation  export.
                | export3DXmlSettingAtt.Annotation3D = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.Annotation3D

    @property
    def design_review(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DesignReview
                | o Property DesignReview(    ) As boolean
                | 
                | Returns or sets the Design Review activation flag.     Example:
                | This  example  activates  the  Design Review  export.
                | export3DXmlSettingAtt.DesignReview = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.DesignReview

    @property
    def geometry_representation_format(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GeometryRepresentationFormat
                | o Property GeometryRepresentationFormat(    ) As Cat3DXmlGeomRepresentationType
                | 
                | Returns or sets the format of geometry representation.     Example:
                | This  example  sets  the  representation  format  to  the  exact
                | mode.      export3DXmlSettingAtt.GeometryRepresentationFormat =
                | cat3DXmlExact


                | Parameters:


        """
        return self.export3dxmlsettingatt.GeometryRepresentationFormat

    @property
    def measure(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Measure
                | o Property Measure(    ) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','get_DesignReview','Export3DXmlSettingAtt.get_D
                | esignReview')  Returns or sets the measure activation flag.
                | Example:    This  example  activates  the  measure  export.
                | export3DXmlSettingAtt.Measure = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.Measure

    @property
    def ppr_save_config(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PPRSaveConfig
                | o Property PPRSaveConfig(    ) As Cat3DXmlPPRSaveConfig
                | 
                | Returns or sets the PPR config.     Example:    This  example  sets
                | the  PPR config. Product  And  resources    export  is  acivated.
                | export3DXmlSettingAtt.PPRSaveConfig = cat3DXmlProductAndResourceList


                | Parameters:


        """
        return self.export3dxmlsettingatt.PPRSaveConfig

    @property
    def presentation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Presentation
                | o Property Presentation(    ) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','get_DesignReview','Export3DXmlSettingAtt.get_D
                | esignReview')  Returns or sets the presentation activation flag.
                | Example:    This  example  activates  the  presentation  export.
                | export3DXmlSettingAtt.Presentation = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.Presentation

    @property
    def section(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Section
                | o Property Section(    ) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','get_DesignReview','Export3DXmlSettingAtt.get_D
                | esignReview')  Returns or sets the section activation flag.
                | Example:    This  example  activates  the  section  export.
                | export3DXmlSettingAtt.Section = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.Section

    @property
    def surface_accuracy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SurfaceAccuracy
                | o Property SurfaceAccuracy(    ) As float
                | 
                | Returns or sets the surface accuracy.     Example:    This  example
                | sets  the  surface accuracy  used  by  the  exact  mode.
                | export3DXmlSettingAtt.SurfaceAccuracy = 0.01


                | Parameters:


        """
        return self.export3dxmlsettingatt.SurfaceAccuracy

    @property
    def work_instructions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WorkInstructions
                | o Property WorkInstructions(    ) As boolean
                | 
                | Returns or sets the Work Instructions activation flag.     Example:
                | This  example  activates  the  Work Instructions  export.
                | export3DXmlSettingAtt.DesignReview = True


                | Parameters:


        """
        return self.export3dxmlsettingatt.WorkInstructions

    def get_alternate_view_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAlternateViewInfo
                | o Func GetAlternateViewInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','GetDesignReviewInfo','Export3DXmlSettingAtt.Ge
                | tDesignReviewInfo')   Retrieves environment informations for the
                | alternate view setting. Role:Retrieves the state of the alternate view
                | setting in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetAlternateViewInfo(io_admin_level, io_locked)

    def get_animation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnimationInfo
                | o Func GetAnimationInfo(    CATBSTR    ioAdminLevel,
                |                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the animation setting.
                | Role:Retrieves the state of the animation setting in the current
                | environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetAnimationInfo(io_admin_level, io_locked)

    def get_annotated_view_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotatedViewInfo
                | o Func GetAnnotatedViewInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','GetDesignReviewInfo','Export3DXmlSettingAtt.Ge
                | tDesignReviewInfo')   Retrieves environment informations for the
                | annotated view setting. Role:Retrieves the state of the annotated view
                | setting in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetAnnotatedViewInfo(io_admin_level, io_locked)

    def get_annotation_3d_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotation3DInfo
                | o Func GetAnnotation3DInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the 3D annotation setting.
                | Role:Retrieves the state of the 3D annotation setting in the current
                | environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetAnnotation3DInfo(io_admin_level, io_locked)

    def get_design_review_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDesignReviewInfo
                | o Func GetDesignReviewInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the Design Review setting.
                | Role:Retrieves the state of the Design Review setting in the current
                | environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetDesignReviewInfo(io_admin_level, io_locked)

    def get_geometry_representation_format_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGeometryRepresentationFormatInfo
                | o Func GetGeometryRepresentationFormatInfo(    CATBSTR    ioAdminLevel,
                |                                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the geometry representation
                | format setting. Role:Retrieves the state of the parameter geometry
                | representation format setting in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetGeometryRepresentationFormatInfo(io_admin_level, io_locked)

    def get_measure_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMeasureInfo
                | o Func GetMeasureInfo(    CATBSTR    ioAdminLevel,
                |                           CATBSTR    ioLocked) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','GetDesignReviewInfo','Export3DXmlSettingAtt.Ge
                | tDesignReviewInfo')  Retrieves environment informations for the
                | measure setting. Role:Retrieves the state of the measure setting in
                | the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetMeasureInfo(io_admin_level, io_locked)

    def get_ppr_save_config_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPPRSaveConfigInfo
                | o Func GetPPRSaveConfigInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the PPRSaveConfig setting.
                | Role:Retrieves the state of the PPRSaveConfig setting in the current
                | environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetPPRSaveConfigInfo(io_admin_level, io_locked)

    def get_presentation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPresentationInfo
                | o Func GetPresentationInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','GetDesignReviewInfo','Export3DXmlSettingAtt.Ge
                | tDesignReviewInfo')   Retrieves environment informations for the
                | presentation setting. Role:Retrieves the state of the presentation
                | setting in the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetPresentationInfo(io_admin_level, io_locked)

    def get_section_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSectionInfo
                | o Func GetSectionInfo(    CATBSTR    ioAdminLevel,
                |                           CATBSTR    ioLocked) As boolean
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','GetDesignReviewInfo','Export3DXmlSettingAtt.Ge
                | tDesignReviewInfo')   Retrieves environment informations for the
                | section setting. Role:Retrieves the state of the section setting in
                | the current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetSectionInfo(io_admin_level, io_locked)

    def get_surface_accuracy_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSurfaceAccuracyInfo
                | o Func GetSurfaceAccuracyInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the surface accuracy setting.
                | Role:Retrieves the state of the surface accuracy setting in the
                | current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetSurfaceAccuracyInfo(io_admin_level, io_locked)

    def get_work_instructions_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetWorkInstructionsInfo
                | o Func GetWorkInstructionsInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the Work Instructions setting.
                | Role:Retrieves the state of the Work Instructions setting in the
                | current environment.


                | Parameters:
                | AdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  oLocked
                |    Indicates if the parameter has been locked. 
                |  oModified
                |  Indicates if the parameter has been explicitly modified or remain      to the administrated value.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.GetWorkInstructionsInfo(io_admin_level, io_locked)

    def set_alternate_view_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAlternateViewLock
                | o Sub SetAlternateViewLock(    boolean    iLocked)
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','SetDesignReviewLock','Export3DXmlSettingAtt.Se
                | tDesignReviewLock')  Locks or unlocks the flag. Role:Locks or unlocks
                | the parameter if it is  possible in the current administrated. In user
                | mode this method  will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetAlternateViewLock(i_locked)

    def set_animation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnimationLock
                | o Sub SetAnimationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetAnimationLock(i_locked)

    def set_annotated_view_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotatedViewLock
                | o Sub SetAnnotatedViewLock(    boolean    iLocked)
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','SetDesignReviewLock','Export3DXmlSettingAtt.Se
                | tDesignReviewLock')  Locks or unlocks the flag. Role:Locks or unlocks
                | the parameter if it is  possible in the current administrated. In user
                | mode this method  will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetAnnotatedViewLock(i_locked)

    def set_annotation_3d_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotation3DLock
                | o Sub SetAnnotation3DLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetAnnotation3DLock(i_locked)

    def set_design_review_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDesignReviewLock
                | o Sub SetDesignReviewLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetDesignReviewLock(i_locked)

    def set_geometry_representation_format_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetGeometryRepresentationFormatLock
                | o Sub SetGeometryRepresentationFormatLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetGeometryRepresentationFormatLock(i_locked)

    def set_measure_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMeasureLock
                | o Sub SetMeasureLock(    boolean    iLocked)
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','SetDesignReviewLock','Export3DXmlSettingAtt.Se
                | tDesignReviewLock')  Locks or unlocks the flag. Role:Locks or unlocks
                | the parameter if it is  possible in the current administrated. In user
                | mode this method  will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetMeasureLock(i_locked)

    def set_ppr_save_config_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPPRSaveConfigLock
                | o Sub SetPPRSaveConfigLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetPPRSaveConfigLock(i_locked)

    def set_presentation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPresentationLock
                | o Sub SetPresentationLock(    boolean    iLocked)
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','SetDesignReviewLock','Export3DXmlSettingAtt.Se
                | tDesignReviewLock')  Locks or unlocks the flag. Role:Locks or unlocks
                | the parameter if it is  possible in the current administrated. In user
                | mode this method  will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetPresentationLock(i_locked)

    def set_section_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSectionLock
                | o Sub SetSectionLock(    boolean    iLocked)
                | 
                | Deprecated:  R19 This method will be replaced by  activateLinkAnchor('
                | Export3DXmlSettingAtt','SetDesignReviewLock','Export3DXmlSettingAtt.Se
                | tDesignReviewLock')  Locks or unlocks the flag. Role:Locks or unlocks
                | the parameter if it is  possible in the current administrated. In user
                | mode this method  will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetSectionLock(i_locked)

    def set_surface_accuracy_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSurfaceAccuracyLock
                | o Sub SetSurfaceAccuracyLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetSurfaceAccuracyLock(i_locked)

    def set_work_instructions_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetWorkInstructionsLock
                | o Sub SetWorkInstructionsLock(    boolean    iLocked)
                | 
                | Locks or unlocks the flag. Role:Locks or unlocks the parameter if it
                | is  possible in the current administrated. In user mode this method
                | will always return E_FAIL.


                | Parameters:
                | iLocked
                |  The locking operation to be performed	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.export3dxmlsettingatt.SetWorkInstructionsLock(i_locked)

