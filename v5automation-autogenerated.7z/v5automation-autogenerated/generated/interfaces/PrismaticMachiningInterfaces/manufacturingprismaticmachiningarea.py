#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ManufacturingPrismaticMachiningArea:
    """
        .. note::
            CAA V5 Visual Basic help

                | ManufacturingPrismaticMachiningArea defines a set of properties and
                | methods.

    """

    def __init__(self, catia):
        self.manufacturingprismaticmachiningarea = catia.ManufacturingPrismaticMachiningArea     

    @property
    def bottom_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BottomType
                | o Property BottomType(    ) As CATBSTR
                | 
                | Returns or sets the Hardness Mode on Bottom of a Manufacturing
                | Prismatic Machining Area.Examples:The following example returns the
                | hardness mode on bottom ThisBottomType of the manufacturing prismatic
                | machining area CurrentPMA Dim ThisBottomType As CATBSTR ThisBottomType
                | = CurrentPMA.BottomType The next example sets the hardness mode on
                | bottom of the manufacturing prismatic machining area CurrentPMA
                | CurrentPMA.BottomType = "MfgHard" To be allowed to change BottomType
                | into MfgSoft, Islands geometries must be removed first. Legal values:
                | BottomType can be   MfgHardMfgSoft


                | Parameters:


        """
        return self.manufacturingprismaticmachiningarea.BottomType

    @property
    def contours_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContoursCount
                | o Property ContoursCount(    ) As long
                | 
                | Retreives the number of Contour of a Manufacturing Prismatic Machining
                | Area.Example:The following example returns the number of Contour
                | NumberOfContour of the manufacturing prismatic machining area
                | CurrentPMA Dim NumberOfContour As Long NumberOfContour =
                | CurrentPMA.ContoursCount


                | Parameters:


        """
        return self.manufacturingprismaticmachiningarea.ContoursCount

    @property
    def islands_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IslandsCount
                | o Property IslandsCount(    ) As long
                | 
                | Retreives the number of Island of a Manufacturing Prismatic Machining
                | Area.Example:The following example returns the number of Island
                | NumberOfIsland of the manufacturing prismatic machining area
                | CurrentPMA Dim NumberOfIsland As Long NumberOfIsland =
                | CurrentPMA.IslandsCount


                | Parameters:


        """
        return self.manufacturingprismaticmachiningarea.IslandsCount

    @property
    def top_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TopType
                | o Property TopType(    ) As CATBSTR
                | 
                | Returns or sets the Hardness Mode on top of a Manufacturing Prismatic
                | Machining Area.Examples:The following example returns the hardness
                | mode on top ThisTopType of the manufacturing prismatic machining area
                | CurrentPMA Dim ThisTopType As CATBSTR ThisTopType = CurrentPMA.TopType
                | The next example sets the hardness mode on top of the manufacturing
                | prismatic machining area CurrentPMA CurrentPMA.TopType = "MfgHard"
                | Legal values: TopType can be   MfgHardMfgSoft


                | Parameters:


        """
        return self.manufacturingprismaticmachiningarea.TopType

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns or sets the Type of a Manufacturing Prismatic Machining
                | Area.Examples:The following example returns the feature type ThisType
                | of the manufacturing prismatic machining area CurrentPMA Dim ThisType
                | As CATBSTR ThisType = CurrentPMA.Type The next example sets the
                | feature type of the manufacturing prismatic machining area CurrentPMA
                | CurrentPMA.Type = "MfgPocketType" To be allowed to change Type into
                | MfgPocketType or into MfgContouringType, Contours and Islands
                | geometries must be removed first. Legal values: Type can be
                | MfgPocketTypeMfgContouringType


                | Parameters:


        """
        return self.manufacturingprismaticmachiningarea.Type

    def get_contour_side(self, i_contour_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetContourSide
                | o Func GetContourSide(    long    iContourNumber) As short
                | 
                | Gets the side of one contour of a Manufacturing Prismatic Machining
                | Area.


                | Parameters:
                | iContourNumber
                |    The geometry index inside the collection.
                |    
                | Must be between 1 and ContoursCount (see Properties).


                | Examples:
                | 
                | The following example gets the side of the contour number iContourNumber of the manufacturing prismatic machining area CurrentPMA
                | 
                | Dim iContourNumber As Long
                | iContourNumber = 3
                | 
                | Dim oContourSide As short
                | oContourSide = CurrentPMA.GetContourSide(iContourNumber)
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.GetContourSide(i_contour_number)

    def get_geometries_aquisition_mode(self, i_geometry_type, i_geometry_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGeometriesAquisitionMode
                | o Func GetGeometriesAquisitionMode(    CATBSTR    iGeometryType,
                |                                        long    iGeometryNumber) As short
                | 
                | Gets the aquisition mode of one geometry of a Manufacturing Prismatic
                | Machining Area.


                | Parameters:
                | iGeometryType
                |  Legal values: iGeometryType can be
                |    
                | Contours  to get the aquisition mode of a guiding element
                |      Islands  to get the aquisition mode of an island(not allowed if Type == "MfgContouringType" or  if BottomType == "MfgSoft") (see Properties).
                |    
                | 
                |  iGeometryNumber
                |    The geometry index inside the collection.
                |    
                | Must be 1 if Type == "MfgPocketType" (see Properties) and iGeometryType == "Contours".
                |      Must be between 1 and IslandsCount + 1 (or ContoursCount + 1) (see Properties).


                | Examples:
                | 
                | The following example gets the aquisition mode of the contour number iGeometryNumber of the manufacturing prismatic machining area CurrentPMA
                | 
                | Dim iGeometryNumber As Long
                | iGeometryNumber = 3
                | 
                | Dim oMode As Short
                | oMode = CurrentPMA.GetGeometriesAquisitionMode("Contours",iGeometryNumber)
                | 
                | Legal values: GetGeometriesAquisitionMode value can be
                | 
                | 0  by Edges
                | 1  by Belt of Faces
                | 2  by Boundary of Faces (Islands only)
                | 5  by Boundary of Faces (Contours only)
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.GetGeometriesAquisitionMode(i_geometry_type, i_geometry_number)

    def is_contour_closed(self, i_contour_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsContourClosed
                | o Func IsContourClosed(    long    iContourNumber) As short
                | 
                | Return the status of one contour of a Manufacturing Prismatic
                | Machining Area : closed or open.


                | Parameters:
                | iContourNumber
                |    The geometry index inside the collection.
                |    
                | Must be between 1 and ContoursCount (see Properties).


                | Examples:
                | 
                | The following example returns the status of the contour number iContourNumber of the manufacturing prismatic machining area CurrentPMA
                | 
                | Dim iContourNumber As Long
                | iContourNumber = 3
                | 
                | Dim oIsClosed As short
                | oIsClosed = CurrentPMA.IsContourClosed(iContourNumber)
                | 
                | Legal values: IsContourClosed value can be
                | 
                | 0 (means open contour)
                | 1 (means closed contour)
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.IsContourClosed(i_contour_number)

    def remove_all_geometry(self, i_geometry_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAllGeometry
                | o Sub RemoveAllGeometry(    CATBSTR    iGeometryType)
                | 
                | Removes all the geometry of a specified type linked to a Manufacturing
                | Prismatic Machining Area.


                | Parameters:
                | iGeometryType
                |  Legal values: iGeometryType can be
                |    
                | RelimitingPlane  to remove the top plane   
                |      Parts  to remove the bottom
                |      Checks  to remove the check elements
                |      Contours  to remove the guiding elements
                |      Islands  to remove the islands


                | Examples:
                | 
                | The following example removes the bottom of the manufacturing prismatic machining area CurrentPMA
                | 
                | Call CurrentPMA.RemoveAllGeometry("Parts")
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.RemoveAllGeometry(i_geometry_type)

    def set_closed_contour_side(self, i_contour_number, i_side):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClosedContourSide
                | o Sub SetClosedContourSide(    long    iContourNumber,
                |                                CATBSTR    iSide)
                | 
                | Sets the side of one closed contour of a Manufacturing Prismatic
                | Machining Area.


                | Parameters:
                | iContourNumber
                |    The geometry index inside the collection.
                |    
                | Must be between 1 and ContoursCount (see Properties).
                |    
                | 
                |  iSide
                |  Legal values: iSide can be
                |    
                | Inside
                | Outside


                | Examples:
                | 
                | The following example sets the side of the closed contour number iContourNumber of the manufacturing prismatic machining area CurrentPMA
                | 
                | Dim iContourNumber As Long
                | iContourNumber = 3
                | 
                | Dim iContourSide As CATBSTR
                | iContourSide = "Inside"
                | Call CurrentPMA.SetClosedContourSide(iContourNumber,iContourSide)
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.SetClosedContourSide(i_contour_number, i_side)

    def set_contour_side(self, i_contour_number, i_side):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetContourSide
                | o Sub SetContourSide(    long    iContourNumber,
                |                          short    iSide)
                | 
                | Sets the side of one contour of a Manufacturing Prismatic Machining
                | Area.


                | Parameters:
                | iContourNumber
                |    The geometry index inside the collection.
                |    
                | Must be between 1 and ContoursCount (see Properties).
                |    
                | 
                |  iSide
                |  Legal values: iSide can be
                |    
                | 1
                | 2


                | Examples:
                | 
                | The following example sets the side of the contour number iContourNumber of the manufacturing prismatic machining area CurrentPMA
                | 
                | Dim iContourNumber As Long
                | iContourNumber = 3
                | 
                | Dim iContourSide As Short
                | iContourSide = 2
                | Call CurrentPMA.SetContourSide(iContourNumber,iContourSide)
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.SetContourSide(i_contour_number, i_side)

    def set_geometries(self, i_geometry_type, i_mode, i_geometry_number, i_reference, i_product, i_position):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetGeometries
                | o Sub SetGeometries(    CATBSTR    iGeometryType,
                |                         short    iMode,
                |                         long    iGeometryNumber,
                |                         AnyObject    iReference,
                |                         AnyObject    iProduct,
                |                         short    iPosition)
                | 
                | Sets or adds geometry in a collection of a specified type to a
                | Manufacturing Prismatic Machining Area.


                | Parameters:
                | iGeometryType
                |  Legal values: iGeometryType can be
                |    
                | Contours  to set or to add a guiding element
                |      Islands  to set or to add an island(not allowed if Type == "MfgContouringType" or  if BottomType == "MfgSoft") (see Properties).
                |    
                | 
                |  iMode
                |  Legal values: iMode can be
                |    
                | 0  by Edges
                |    
                | 
                |  iGeometryNumber
                |    The geometry index inside the collection.
                |    
                | Must be 1 if Type == "MfgPocketType" (see Properties) and iGeometryType == "Contours".
                |      Must be between 1 and IslandsCount + 1 (or ContoursCount + 1) (see Properties).
                |    
                | 
                |  iReference
                |    The geometry to be set.
                |  
                |  iProduct
                |    The product containing the geometry to be set. 
                |  
                |  iPosition
                |    0


                | Examples:
                | 
                | The following example sets 3 Islands, linked to 2 circles and 3 lines, to the manufacturing prismatic machining area CurrentPMA
                | 
                | Dim iGeometryNumber As Long
                | iGeometryNumber = 0
                | ...
                | 'Get number of Island of CurrentPMA and add 1 to create a new island (Island number 1)
                | iGeometryNumber = CurrentPMA.IslandsCount + 1
                | Call CurrentPMA.SetGeometries("Islands",0,iGeometryNumber,Circle1,PartMachined,0)
                | 
                | 'Get number of Island of CurrentPMA and add 1 to create a new island  (Island number 2)
                | iGeometryNumber = CurrentPMA.IslandsCount + 1
                | Call CurrentPMA.SetGeometries("Islands",0,iGeometryNumber,Circle2,PartMachined,0)
                | 
                | 'Get number of Island of CurrentPMA and add 1 to create a new island  (Island number 3)
                | iGeometryNumber = CurrentPMA.IslandsCount + 1
                | Call CurrentPMA.SetGeometries("Islands",0,iGeometryNumber,Line5,PartMachined,0)
                | 
                | 'Adding Line6 to Island number 3
                | Call CurrentPMA.SetGeometries("Islands",0,iGeometryNumber,Line6,PartMachined,0)
                | 
                | 'Adding Line7 to Island number 3
                | Call CurrentPMA.SetGeometries("Islands",0,iGeometryNumber,Line7,PartMachined,0)
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.SetGeometries(i_geometry_type, i_mode, i_geometry_number, i_reference, i_product, i_position)

    def set_geometry(self, i_geometry_type, i_reference, i_product, i_position):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetGeometry
                | o Sub SetGeometry(    CATBSTR    iGeometryType,
                |                       AnyObject    iReference,
                |                       AnyObject    iProduct,
                |                       short    iPosition)
                | 
                | Sets a geometry of a specified type to a Manufacturing Prismatic
                | Machining Area.


                | Parameters:
                | iGeometryType
                |  Legal values: iGeometryType can be
                |    
                | RelimitingPlane  to set the top plane   
                |      Parts  to set the bottom
                |      Checks  to set a check element
                |    
                | 
                |  iReference
                |    The geometry to be set.
                |  
                |  iProduct
                |    The product containing the geometry to be set. 
                |  
                |  iPosition
                |    0


                | Examples:
                | 
                | The following example sets the top plane Plane2 to the manufacturing prismatic machining area CurrentPMA
                | 
                | Call CurrentPMA.SetGeometry("RelimitingPlane",Plane2,PartMachined,0)
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.SetGeometry(i_geometry_type, i_reference, i_product, i_position)

    def set_open_contour_side(self, i_contour_number, i_point):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOpenContourSide
                | o Sub SetOpenContourSide(    long    iContourNumber,
                |                              AnyObject    iPoint)
                | 
                | Sets the side of one  open contour of a Manufacturing Prismatic
                | Machining Area.


                | Parameters:
                | iContourNumber
                |    The geometry index inside the collection.
                |    
                | Must be between 1 and ContoursCount (see Properties).
                |    
                | 
                |  iPoint
                |    A point near one of both limits of the contour.
                |    
                | From this limit to the other one, the side of the contour is on the left.


                | Examples:
                | 
                | The following example sets the side of the open contour number iContourNumber of the manufacturing prismatic machining area CurrentPMA
                | 
                | Dim iContourNumber As Long
                | iContourNumber = 3
                | 
                | Dim Point1 As CATIABase
                | ...
                | Set Point1 = hybridShapes1.Item("Point.1")
                | ...
                | 
                | Call CurrentPMA.SetOpenContourSide(iContourNumber,Point1)
                | 
                | 
                | 
                | 
        """
        return self.manufacturingprismaticmachiningarea.SetOpenContourSide(i_contour_number, i_point)

