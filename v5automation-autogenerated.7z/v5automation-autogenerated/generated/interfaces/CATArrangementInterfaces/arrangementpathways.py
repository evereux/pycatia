#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementPathways:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection object for ArrangementPathway objects.Role:Use this
                | collection object to manage (create, retrieve and remmove)
                | ArrangementPathway objects.

    """

    def __init__(self, catia):
        self.arrangementpathways = catia.ArrangementPathways     

    def add_pathway(self, i_rel_axis, i_listof_math_points, i_math_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPathway
                | o Func AddPathway(    Move    iRelAxis,
                |                       CATSafeArrayVariant    iListofMathPoints,
                |                       CATSafeArrayVariant    iMathDirection) As ArrangementPathway
                | 
                | Creates an ArrangementItemReservation and adds it to the collection.


                | Parameters:
                | iRelAxis
                |    Relative Axis to be considered.
                |  
                |  iListofMathPoints
                |    List of points through which to route.
                |  
                |  iMathDirection
                |    Starting routing direction.
                |  
                | 
                |  Returns:
                |     Returns the newly created ArrangementPathway object and adds it to the collection.


        """
        return self.arrangementpathways.AddPathway(i_rel_axis, i_listof_math_points, i_math_direction)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As ArrangementPathway
                | 
                | Returns the specified ArrangementPathway item of the collection
                | object.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementPathway to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementPathway in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementPathway by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |      The retrieved ArrangementPathway object.


        """
        return self.arrangementpathways.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes the specified ArrangementPathway object from the collection.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementPathway to remove from this collection.
                |    
                |  To remove a specific object by number, use the rank of the ArrangementPathway in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To remove a specific ArrangementPathway by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


        """
        return self.arrangementpathways.Remove(i_index)

