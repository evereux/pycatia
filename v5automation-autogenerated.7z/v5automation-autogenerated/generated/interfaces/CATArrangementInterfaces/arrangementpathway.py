#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementPathway:
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object to access properties and methods of an
                | ArrangementPathway object.Role:Use this interface to control the
                | visualization mode, section parameters, nodes that define the
                | ArrangementPathway object.

    """

    def __init__(self, catia):
        self.arrangementpathway = catia.ArrangementPathway     

    @property
    def arrangement_nodes(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementNodes
                | o Property ArrangementNodes(    ) As ArrangementNodes
                | 
                | Returns the ArrangementNodes that make up the ArrangementPathway.
                | Example: This example gets the ArrangementNodes for the objPathway1
                | object.  Dim objArrNodes   As ArrangementNodes Set objArrNodes =
                | objPathway1.ArrangementNodes


                | Parameters:


        """
        return self.arrangementpathway.ArrangementNodes

    @property
    def length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Length
                | o Property Length(    ) As double
                | 
                | Returns the length of the ArrangementPathway object.  Example: This
                | example retrieves the Length of the objPathway1 object.  Dim dblLength
                | As Double dblLength  = objPathway1.Length


                | Parameters:


        """
        return self.arrangementpathway.Length

    @property
    def section_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionDiameter
                | o Property SectionDiameter(    ) As double
                | 
                | Returns or sets the SectionDiameter for an ArrangementPathway object.
                | Example: This example retrieves the SectionDiameter for the
                | objPathway1 object.  Dim dblSectionDia   As Double dblSectionDia =
                | objPathway1.SectionDiameter


                | Parameters:


        """
        return self.arrangementpathway.SectionDiameter

    @property
    def section_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionHeight
                | o Property SectionHeight(    ) As double
                | 
                | Returns or sets the SectionHeight for an ArrangementPathway object.
                | Example: This example gets the SectionHeight for the objPathway1
                | object.  Dim dblSectionHeight   As Double dblSectionHeight =
                | objPathway1.SectionHeight


                | Parameters:


        """
        return self.arrangementpathway.SectionHeight

    @property
    def section_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionType
                | o Property SectionType(    ) As CATArrangementRouteSection
                | 
                | Returns or sets the Section for an ArrangementPathway object.
                | Example: This example sets the SectionType for the objPathway1 object
                | to CatArrangementRouteSectionRectangular.  objPathway1.SectionType =
                | CatArrangementRouteSectionRectangular


                | Parameters:


        """
        return self.arrangementpathway.SectionType

    @property
    def section_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionWidth
                | o Property SectionWidth(    ) As double
                | 
                | Returns or sets the SectionWidth for an ArrangementPathway object.
                | Example: This example gets the SectionWidth for the objPathway1
                | object.  Dim dblSectionWidth   As Double dblSectionWidth =
                | objPathway1.SectionWidth


                | Parameters:


        """
        return self.arrangementpathway.SectionWidth

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As CATArrangementRouteVisuMode
                | 
                | Returns or sets the Visualization Mode for an ArrangementPathway
                | object.  Example: This example sets the Visualization Mode for the
                | objPathway1 object to CatArrangementRouteVisuModeSolid.
                | objPathway1.VisuMode = CatArrangementRouteVisuModeSolid


                | Parameters:


        """
        return self.arrangementpathway.VisuMode

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(    CATBSTR    iApplicationType) As CATBaseDispatch
                | 
                | Returns the applicative data which type is the given parameter.


                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.


                | Examples:
                | 
                | 
                | This example retrieves the desired applicative object from the objPathway1 object.
                | 
                | Dim objProd   As Product
                | objProd  = objPathway1.GetTechnologicalObject("Product")
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementpathway.GetTechnologicalObject(i_application_type)

