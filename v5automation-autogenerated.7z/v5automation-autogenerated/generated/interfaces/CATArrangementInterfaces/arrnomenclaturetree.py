#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrNomenclatureTree:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the root User Dictionary object.The user dictionary defines
                | a hierarchy of user object type names  used for dynamically
                | classifying objects. These type names are  defined by the user
                | organization according to the needs of  the disciplines represented in
                | the data. The user type of any  object may be changed as the data
                | becomes more precise.  The hierarchy of type names starts with base
                | names, defined by  the system, for each type of object. The user
                | organization may  define or change the hierarchy of type names under
                | each base name.

    """

    def __init__(self, catia):
        self.arrnomenclaturetree = catia.ArrNomenclatureTree     

    @property
    def base_nomenclatures(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BaseNomenclatures
                | o Property BaseNomenclatures(    ) As ArrNomenclatures
                | 
                | Returns the collection of BaseNomenclatures within  this
                | UserDictionary.


                | Parameters:


        """
        return self.arrnomenclaturetree.BaseNomenclatures

    def get_nomenclature(self, i_type_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNomenclature
                | o Func GetNomenclature(    CATBSTR    iTypeName) As ArrNomenclature
                | 
                | Finds a UserNomenclature by Name from this UserDictionary.


                | Parameters:


        """
        return self.arrnomenclaturetree.GetNomenclature(i_type_name)

