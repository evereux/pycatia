#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementItemReservations:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection object for ArrangementItemReservation objects.Role:Use
                | this collection object to manage (create, retrieve and remove)
                | ArrangementItemReservation objects.

    """

    def __init__(self, catia):
        self.arrangementitemreservations = catia.ArrangementItemReservations     

    def add_item_reservation(self, i_rel_axis, i_position, i_x_min, i_y_min, i_z_min, i_x_max, i_y_max, i_z_max):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddItemReservation
                | o Func AddItemReservation(    Move    iRelAxis,
                |                               CATSafeArrayVariant    iPosition,
                |                               double    iXMin,
                |                               double    iYMin,
                |                               double    iZMin,
                |                               double    iXMax,
                |                               double    iYMax,
                |                               double    iZMax) As ArrangementItemReservation
                | 
                | Creates an ArrangementItemReservation and adds it to the collection.


                | Parameters:
                | iRelAxis
                |    Relative Axis to be considered.
                |  
                |  iPosition
                |    Position information for the ItemReservation (rotation and location).
                |  
                |  iXMin
                |    Minium X Coordinate of the bounding box on the Item Reservation.
                |  
                |  iYMin
                |    Minium Y Coordinate of the bounding box on the Item Reservation.
                |  
                |  iZMin
                |    Minium Z Coordinate of the bounding box on the Item Reservation.
                |  
                |  iXMax
                |    Maximum X Coordinate of the bounding box on the Item Reservation.
                |  
                |  iYMax
                |    Maximum Y Coordinate of the bounding box on the Item Reservation.
                |  
                |  iZMax
                |    Maximum Z Coordinate of the bounding box on the Item Reservation.
                |  
                | 
                |  Returns:
                |     Returns the newly created ArrangementItemReservation object and adds it to the collection.


        """
        return self.arrangementitemreservations.AddItemReservation(i_rel_axis, i_position, i_x_min, i_y_min, i_z_min, i_x_max, i_y_max, i_z_max)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As ArrangementItemReservation
                | 
                | Returns the specified ArrangementItemReservation item of the
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementItemReservation to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementItemReservation in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementItemReservation by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |      The retrieved ArrangementItemReservation object.


        """
        return self.arrangementitemreservations.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes the specified ArrangementItemReservation object from the
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementItemReservation to remove from this collection.
                |    
                |  To remove a specific object by number, use the rank of the ArrangementItemReservation in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To remove a specific ArrangementItemReservation by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


        """
        return self.arrangementitemreservations.Remove(i_index)

