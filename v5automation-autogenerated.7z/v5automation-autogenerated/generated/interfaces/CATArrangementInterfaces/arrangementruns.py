#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementRuns:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection object of ArrangementRun objects.Role:Use this collection
                | object to manage ArrangementRun objects.

    """

    def __init__(self, catia):
        self.arrangementruns = catia.ArrangementRuns     

    def add_run(self, i_rel_axis, i_listof_math_points, i_math_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddRun
                | o Func AddRun(    Move    iRelAxis,
                |                   CATSafeArrayVariant    iListofMathPoints,
                |                   CATSafeArrayVariant    iMathDirection) As ArrangementRun
                | 
                | Creates an ArrangementRun and adds it to the collection.


                | Parameters:
                | iRelAxis
                |    Relative Axis to be considered.
                |  
                |  iListofMathPoints
                |    List of points through which to route.
                |  
                |  iMathDirection
                |    Starting routing direction.
                |  
                | 
                |  Returns:
                |     Returns the newly created ArrangementRun object and adds it to the collection.


        """
        return self.arrangementruns.AddRun(i_rel_axis, i_listof_math_points, i_math_direction)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As ArrangementRun
                | 
                | Returns the specified ArrangementRun item of the collection object.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementRun to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementRun in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementRun by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |      The retrieved ArrangementRun object.


        """
        return self.arrangementruns.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes the specified ArrangementRun object from the collection.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementRun to remove from this collection.
                |    
                |  To remove a specific object by number, use the rank of the ArrangementRun in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To remove a specific ArrangementRun by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


        """
        return self.arrangementruns.Remove(i_index)

