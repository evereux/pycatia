#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrSystemLineProduct:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAArrSystemLineProduct

    """

    def __init__(self, catia):
        self.arrsystemlineproduct = catia.ArrSystemLineProduct     

    def get_sub_item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSubItem
                | o Func GetSubItem(    long    iIndex) As AnyObject
                | 
                | Allows the user to get the item at a specific index location.


                | Parameters:


        """
        return self.arrsystemlineproduct.GetSubItem(i_index)

    def get_sub_products_count(self, i_intf_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSubProductsCount
                | o Func GetSubProductsCount(    CATBSTR    iIntfId) As long
                | 
                | Returns the count of the sub-products that make up the System-Line
                | Arrangement Product and that match a specifc interface id. If the
                | interface Id is NULL, then it searches for CATIAProduct objects by
                | default.


                | Parameters:


        """
        return self.arrsystemlineproduct.GetSubProductsCount(i_intf_id)

