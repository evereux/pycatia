#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrWorkbench:
    """
        .. note::
            CAA V5 Visual Basic help

                | Returns the Arrangement Workbench.Role:Use this interface to manage
                | the ArrNomenclatureTree object, create Arrangement objects (such as
                | ArrangementArea, ArrangementRun etc).

    """

    def __init__(self, catia):
        self.arrworkbench = catia.ArrWorkbench     

    @property
    def arr_nomenclature_tree(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrNomenclatureTree
                | o Property ArrNomenclatureTree(    ) As ArrNomenclatureTree
                | 
                | Returns the ArrNomenclatureTree.


                | Parameters:


        """
        return self.arrworkbench.ArrNomenclatureTree

    def add_nomenclature_tree(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNomenclatureTree
                | o Func AddNomenclatureTree(    ) As ArrNomenclatureTree
                | 
                | This method allows the user to add a nomenclature tree if the
                | get_ArrNomenclatureTree returns a Return code of E_FAIL. Basically,
                | the workbench could not locate the  startup instance to generate the
                | necessary NomenclatureTree information.


                | Parameters:


        """
        return self.arrworkbench.AddNomenclatureTree()

    def convert_arrangement_product_to_product(self, i_arr_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConvertArrangementProductToProduct
                | o Func ConvertArrangementProductToProduct(    ArrangementProduct    iArrProduct) As Product
                | 
                | This method converts an ArrangementProduct back to a Product.


                | Parameters:
                | iArrProduct
                |           Input ArrangementProduct to be converted.
                |  
                | 
                |  Returns:
                |    oProduct    As CATIAProduct          Converted Product.
                |  
                |    See also:
                |   activateLinkAnchor('Product','','Product')


        """
        return self.arrworkbench.ConvertArrangementProductToProduct(i_arr_product)

    def convert_product_to_arrangement_product(self, i_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConvertProductToArrangementProduct
                | o Func ConvertProductToArrangementProduct(    Product    iProduct) As ArrangementProduct
                | 
                | This method converts a Product to an ArrangementProduct.


                | Parameters:
                | iProduct
                |          Input Product to be converted.
                |  
                | 
                |  Returns:
                |   oArrProduct         Converted ArrangementProduct.
                |  
                |    See also:
                |   activateLinkAnchor('Product','','Product')


        """
        return self.arrworkbench.ConvertProductToArrangementProduct(i_product)

    def find_interface(self, i_interface_name, i_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | FindInterface
                | o Func FindInterface(    CATBSTR    iInterfaceName,
                |                          CATBaseDispatch    iObject) As CATBaseDispatch
                | 
                | This method returns a interface handle as specified by the input
                | interface name and the input interface handle.  Dim interfaceFound As
                | AnyObject Set interfaceFound = CATIAArrWorkbench.FindInterface("Interf
                | aceNameToFind",CATIAProduct_iObject)


                | Parameters:
                | iInterfaceName
                |    interface name to search for ("CATIAxxxx")
                |  
                |  iObject
                |    The object to search for the required interface.
                |  
                | 
                |  Returns:
                |   oInterfaceFound   interface handle found


        """
        return self.arrworkbench.FindInterface(i_interface_name, i_object)

