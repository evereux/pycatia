#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATArrangementAreaVisuMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementAreaVisuMode Styles.Role:The styles defined here can be
                | used to provide the  appropriate Visual Mode to the ArrangementArea.

    """

    def __init__(self, catia):
        self.catarrangementareavisumode = catia.CATArrangementAreaVisuMode     

