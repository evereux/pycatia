#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementBoundary:
    """
        .. note::
            CAA V5 Visual Basic help

                | Access properties and functions of an ArrangementBoundary
                | object.Role:Use this interface to control the visualization mode,
                | section parameters, nodes that define the ArrangementBoundary object.

    """

    def __init__(self, catia):
        self.arrangementboundary = catia.ArrangementBoundary     

    @property
    def arrangement_nodes(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementNodes
                | o Property ArrangementNodes(    ) As ArrangementNodes
                | 
                | Returns the collection of ArrangementNodes that make up the
                | ArrangementBoundary.  Example: This example gets the ArrangementNodes
                | for the objBoundary1 object.  Dim objArrNodes   As ArrangementNodes
                | Set objArrNodes = objBoundary1.ArrangementNodes


                | Parameters:


        """
        return self.arrangementboundary.ArrangementNodes

    @property
    def length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Length
                | o Property Length(    ) As double
                | 
                | Returns the length of the ArrangementBoundary object.  Example: This
                | example retrieves the Length of the objBoundary1 object.  Dim
                | dblBoundaryLength   As Double dblBoundaryLength  = objBoundary1.Length


                | Parameters:


        """
        return self.arrangementboundary.Length

    @property
    def section_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionHeight
                | o Property SectionHeight(    ) As double
                | 
                | Returns or sets the SectionHeight for an ArrangementBoundary object.
                | Example: This example gets the SectionHeight for the objBoundary1
                | object.  Dim dblSectionHeight   As Double dblSectionHeight =
                | objBoundary1.SectionHeight


                | Parameters:


        """
        return self.arrangementboundary.SectionHeight

    @property
    def section_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionType
                | o Property SectionType(    ) As CATArrangementRouteSection
                | 
                | Returns or sets the SectionType for an ArrangementBoundary object.
                | Legal values:   CatArrangementRouteSectionNoneCatArrangementRouteSecti
                | onRectangularExample: This example sets the SectionType for the
                | objBoundary1 object to CatArrangementRouteSectionRectangular.
                | objBoundary1.SectionType = CatArrangementRouteSectionRectangular


                | Parameters:


        """
        return self.arrangementboundary.SectionType

    @property
    def section_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionWidth
                | o Property SectionWidth(    ) As double
                | 
                | Returns or sets the SectionWidth for an ArrangementBoundary object.
                | Example: This example gets the SectionWidth for the objBoundary1
                | object.  Dim dblSectionWidth   As Double dblSectionWidth =
                | objBoundary1.SectionWidth


                | Parameters:


        """
        return self.arrangementboundary.SectionWidth

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As CATArrangementRouteVisuMode
                | 
                | Returns or sets the Visualization Mode for an ArrangementBoundary
                | object.  Example: This example sets the Visualization Mode for the
                | objBoundary1 object to CatArrangementRouteVisuModeSolid.
                | objBoundary1.VisuMode = CatArrangementRouteVisuModeSolid


                | Parameters:


        """
        return self.arrangementboundary.VisuMode

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(    CATBSTR    iApplicationType) As CATBaseDispatch
                | 
                | Returns the applicative data whose type is the given parameter.


                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.


                | Examples:
                | 
                | 
                | This example retrieves the desired applicative object from the objBoundary1 object.
                | 
                | Dim objProd   As Product
                | objProd  = objBoundary1.GetTechnologicalObject("Product")
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementboundary.GetTechnologicalObject(i_application_type)

