#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementProduct:
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object as a factory for Arrangement collection
                | objects.Role:Use this interface to get access to the Arrangement
                | collections (Areas, Rectangles, ItemReservations, Runs, Pathways,
                | Boundaries) aggregated a given Product.

    """

    def __init__(self, catia):
        self.arrangementproduct = catia.ArrangementProduct     

    @property
    def arrangement_areas(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementAreas
                | o Property ArrangementAreas(    ) As ArrangementAreas
                | 
                | Returns the collection of ArrangementAreas under the current
                | ArrangementProduct.  Example: This example retrieves the
                | ArrangementAreas collection, oArrAreas , for the objArrProd1
                | ArrangementProduct object.  Dim oArrAreas As ArrangementAreas Set
                | oArrAreas = objArrProd1.Areas


                | Parameters:


        """
        return self.arrangementproduct.ArrangementAreas

    @property
    def arrangement_boundaries(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementBoundaries
                | o Property ArrangementBoundaries(    ) As ArrangementBoundaries
                | 
                | Returns the collection of ArrangementBoundaries under the current
                | ArrangementProduct.  Example: This example retrieves the
                | ArrangementBoundaries collection, oArrBoundaries , for the objArrProd1
                | ArrangementProduct object.  Dim oArrBoundaries As
                | ArrangementBoundaries Set oArrBoundaries = objArrProd1.oArrObjType


                | Parameters:


        """
        return self.arrangementproduct.ArrangementBoundaries

    @property
    def arrangement_item_reservations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementItemReservations
                | o Property ArrangementItemReservations(    ) As ArrangementItemReservations
                | 
                | Returns the collection of ArrangementItemReservations under the
                | current ArrangementProduct.  Example: This example retrieves the
                | ArrangementItemReservations collection, oArrItemReservations , for the
                | objArrProd1 ArrangementProduct object.  Dim oArrItemReservations As
                | ArrangementItemReservations Set oArrItemReservations =
                | objArrProd1.ItemReservations


                | Parameters:


        """
        return self.arrangementproduct.ArrangementItemReservations

    @property
    def arrangement_pathways(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementPathways
                | o Property ArrangementPathways(    ) As ArrangementPathways
                | 
                | Returns the collection of ArrangementPathways under the current
                | ArrangementProduct.  Example: This example retrieves the
                | ArrangementPathways collection, oArrPathways , for the objArrProd1
                | ArrangementProduct object.  Dim oArrPathways As ArrangementPathways
                | Set oArrPathways = objArrProd1.Pathways


                | Parameters:


        """
        return self.arrangementproduct.ArrangementPathways

    @property
    def arrangement_rectangles(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementRectangles
                | o Property ArrangementRectangles(    ) As ArrangementRectangles
                | 
                | Returns the collection of ArrangementRectangles under the current
                | ArrangementProduct.  Example: This example retrieves the
                | ArrangementRectangles collection, oArrRectangles , for the objArrProd1
                | ArrangementProduct object.  Dim oArrRectangles As
                | ArrangementRectangles Set oArrRectangles = objArrProd1.Rectangles


                | Parameters:


        """
        return self.arrangementproduct.ArrangementRectangles

    @property
    def arrangement_runs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementRuns
                | o Property ArrangementRuns(    ) As ArrangementRuns
                | 
                | Returns the collection of ArrangementRuns under the current
                | ArrangementProduct.  Example: This example retrieves the
                | ArrangementRuns collection, oArrRuns , for the objArrProd1
                | ArrangementProduct object.  Dim oArrRuns As ArrangementRuns Set
                | oArrRuns = objArrProd1.Runs


                | Parameters:


        """
        return self.arrangementproduct.ArrangementRuns

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As CATBSTR
                | 
                | Returns the Type of the ArrangementProduct in the form of a String.
                | Example: This example retrieves the type information as a string for
                | the objArrProd1 ArrangementProduct object.  Dim oArrObjType  As String
                | oArrObjType  = objArrProd1.Type


                | Parameters:


        """
        return self.arrangementproduct.Type

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(    CATBSTR    iApplicationType) As CATBaseDispatch
                | 
                | Returns the product's applicative data which type is the given
                | parameter.


                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.


                | Examples:
                | 
                | 
                | This example retrieves the desired applicative object from the objArrProd1 object.
                | 
                | Dim objProd   As Product
                | objProd  = objArrProd1.GetTechnologicalObject("Product")
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementproduct.GetTechnologicalObject(i_application_type)

    def set_arrangement_nomenclature(self, i_nomenclature):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetArrangementNomenclature
                | o Sub SetArrangementNomenclature(    CATBSTR    iNomenclature)
                | 
                | Sets the nomenclature of the ArrangementProduct.  Returns:    An
                | HRESULT value.   Legal values:   S_OKoperation is
                | successfulE_FAILoperation failedExample: This example sets the
                | ArrangementNomenclature for objArrProd1 ArrangementProduct object.
                | objArrProd1.SetArrangementNomenclature = "Building"


                | Parameters:


        """
        return self.arrangementproduct.SetArrangementNomenclature(i_nomenclature)

    def set_auto_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoName
                | o Sub SetAutoName(    )
                | 
                | Causes the name of the ArrangementProduct automatically.  Returns:
                | An HRESULT value.   Legal values:   S_OKoperation is
                | successfulE_FAILoperation failedExample: This example shows how the
                | automatic naming of the objArrProd1 ArrangementProduct object can be
                | done.  objArrProd1.SetAutoName


                | Parameters:


        """
        return self.arrangementproduct.SetAutoName()

