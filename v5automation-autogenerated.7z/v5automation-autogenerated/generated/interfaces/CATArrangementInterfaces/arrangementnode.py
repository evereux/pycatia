#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementNode:
    """
        .. note::
            CAA V5 Visual Basic help

                | This interface provides access to a CATIAArrangementNode  object.Use
                | this object to fetch the properties of an ArrangementNode
                | object.Role:Use this object to retrieve the bend angle, bend radius
                | and location of an ArrangementNode object.

    """

    def __init__(self, catia):
        self.arrangementnode = catia.ArrangementNode     

    @property
    def bend_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BendAngle
                | o Property BendAngle(    ) As double
                | 
                | Returns the BendAngle of the current ArrangementNode.  Example: This
                | example retrieves the BendAngle of the objNode1 object.  Dim
                | dblBendAngle   As Double dblBendBendAngle  = objNode1.BendAngle


                | Parameters:


        """
        return self.arrangementnode.BendAngle

    @property
    def bend_radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BendRadius
                | o Property BendRadius(    ) As double
                | 
                | Returns or sets the BendRadius of the current ArrangementNode.
                | Example: This example retrieves the BendRadius of the objNode1 object.
                | Dim dblBendRadius   As Double dblBendRadius  = objNode1.BendRadius


                | Parameters:


        """
        return self.arrangementnode.BendRadius

    def get_point(self, i_rel_axis, io_node_location):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPoint
                | o Sub GetPoint(    Move    iRelAxis,
                |                    CATSafeArrayVariant    ioNodeLocation)
                | 
                | Returns the location of the current ArrangementNode.


                | Parameters:
                | iRelAxis
                |   The relative axis to be considered when calculating the coordinate.
                |  
                |  ioNodeLocation
                |   The location of the ArrangementNode.


                | Examples:
                | 
                | 
                | This example retrieves the location of the ArrangementNode object objNode1.
                | 
                | Dim dblCoords(3)   As Double
                | Dim iRelAxis       As Move
                | 'Fetch iRelAxis from the object containing the node
                | ...
                | objNode1.GetPoint(iRelAxis, dblCoords)
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementnode.GetPoint(i_rel_axis, io_node_location)

    def set_point(self, i_rel_axis, i_node_location):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPoint
                | o Sub SetPoint(    Move    iRelAxis,
                |                    CATSafeArrayVariant    iNodeLocation)
                | 
                | Sets the location of the current ArrangementNode.


                | Parameters:
                | iRelAxis
                |   The relative axis to be considered when calculating the coordinate.
                |  
                |  ioNodeLocation
                |   The location of the ArrangementNode.


                | Examples:
                | 
                | 
                | This example sets the location of the ArrangementNode object objNode1.
                | 
                | Dim dblCoords(3)   As Double
                | Dim iRelAxis       As Move
                | 'Fetch iRelAxis from the object containing the node
                | ...
                | dblCoords(0)       = 300.0 '//X
                | dblCoords(1)       = 500.0 '//Y
                | dblCoords(2)       = 300.0 '//Z
                | objNode1.SetPoint(iRelAxis, dblCoords)
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementnode.SetPoint(i_rel_axis, i_node_location)

