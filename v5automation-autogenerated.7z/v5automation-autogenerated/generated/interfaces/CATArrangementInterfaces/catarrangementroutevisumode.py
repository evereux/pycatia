#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATArrangementRouteVisuMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | The visualization mode for the ArrangementRun, ArrangementPathway,
                | ArrangementBoundary objects.

    """

    def __init__(self, catia):
        self.catarrangementroutevisumode = catia.CATArrangementRouteVisuMode     

