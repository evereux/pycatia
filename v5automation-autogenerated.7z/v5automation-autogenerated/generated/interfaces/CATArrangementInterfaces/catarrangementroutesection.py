#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATArrangementRouteSection:
    """
        .. note::
            CAA V5 Visual Basic help

                | Section Types for ArrangementRun, ArrangementPathway and
                | ArrangementBoundary objects.

    """

    def __init__(self, catia):
        self.catarrangementroutesection = catia.CATArrangementRouteSection     

