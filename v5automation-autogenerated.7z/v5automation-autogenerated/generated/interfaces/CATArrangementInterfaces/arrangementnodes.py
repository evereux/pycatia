#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementNodes:
    """
        .. note::
            CAA V5 Visual Basic help

                | A Collection object for ArrangementNode objects.Use this object to
                | access individual ArrangementNode objects of an ArrangementRun,
                | ArrangementPathway and ArrangementBoundary.

    """

    def __init__(self, catia):
        self.arrangementnodes = catia.ArrangementNodes     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As ArrangementNode
                | 
                | Returns the specified ArrangementNode item of the collection.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementNode to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementNode in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementNode by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |      The retrieved ArrangementNode object.


        """
        return self.arrangementnodes.Item(i_index)

