#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementItemReservation:
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object to access the ArrangementItemReservation properties
                | and methods.Role:Use this object to control the visualization mode,
                | dimensions of the ArrangementItemReservation.

    """

    def __init__(self, catia):
        self.arrangementitemreservation = catia.ArrangementItemReservation     

    @property
    def height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Height
                | o Property Height(    ) As double
                | 
                | Returns or sets the height of the ArrangementItemReservation.
                | Example: This example retrieves the Height of the objItemRes1 object.
                | Dim dblHeight   As Double dblHeight  = objItemRes1.Height


                | Parameters:


        """
        return self.arrangementitemreservation.Height

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As CATArrangementItemResVisuMode
                | 
                | Returns or set the Visualization Mode for the
                | ArrangementItemReservation.  Example: This example Sets the
                | Visualization Mode of the objItemRes1 object to
                | CatArrangementItemReservationVisuModeBox .  objItemRes1.VisuMode =
                | CatArrangementItemReservationVisuModeBox


                | Parameters:


        """
        return self.arrangementitemreservation.VisuMode

    @property
    def x_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | XLength
                | o Property XLength(    ) As double
                | 
                | Returns or sets the XLength of the ArrangementItemReservation.
                | Example: This example retrieves the XLength of the objItemRes1 object.
                | Dim dblXLength   As Double dblXLength  = objItemRes1.XLength


                | Parameters:


        """
        return self.arrangementitemreservation.XLength

    @property
    def y_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | YLength
                | o Property YLength(    ) As double
                | 
                | Returns or sets the YLength of the ArrangementItemReservation.
                | Example: This example retrieves the YLength of the objItemRes1 object.
                | Dim dblYLength   As Double dblYLength  = objItemRes1.YLength


                | Parameters:


        """
        return self.arrangementitemreservation.YLength

    def get_dimension(self, io_item_res_dimensions):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimension
                | o Sub GetDimension(    CATSafeArrayVariant    ioItemResDimensions)
                | 
                | Returns the Dimensions of the ArrangementItemReservation.


                | Parameters:
                | ioItemResDimensions
                |    The output array initialized with the dimensions that make up the ArrangementItemReservation.
                |    The first three components represent the Minimum XCoord, YCoord and Z Coord while the 
                |    remaining three components represent the Maximum XCoord, YCoord and Z Coord respectively.


                | Examples:
                | 
                | 
                | This example retrieves the coordinate dimensions of the objItemRes1
                | object.
                | 
                | Dim dblDimension(6)   As Double
                | objItemRes1.GetDimension(dblDimension)
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementitemreservation.GetDimension(io_item_res_dimensions)

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(    CATBSTR    iApplicationType) As CATBaseDispatch
                | 
                | Returns the applicative data whose type is the given parameter.


                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.


                | Examples:
                | 
                | 
                | This example retrieves the desired applicative object from the objItemRes1 object.
                | 
                | Dim objProd   As Product
                | objProd  = objItemRes1.GetTechnologicalObject("Product")
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementitemreservation.GetTechnologicalObject(i_application_type)

    def set_dimension(self, i_item_res_dimensions):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimension
                | o Sub SetDimension(    CATSafeArrayVariant    iItemResDimensions)
                | 
                | Sets the Dimensions of the ArrangementItemReservation.


                | Parameters:
                | iItemResDimensions
                |    The input array initialized with the dimensions that make up the ArrangementItemReservation.
                |    The first three components represent the Minimum XCoord, YCoord and Z Coord while the 
                |    remaining three components represent the Maximum XCoord, YCoord and Z Coord respectively.


                | Examples:
                | 
                | 
                | This example sets the coordinate dimensions of the objItemRes1
                | object.
                | 
                | Dim dblDimension(6)   As Double
                | dblDimension(0)       = 300.0 '//XMin
                | dblDimension(1)       = 500.0 '//YMin
                | dblDimension(2)       = 300.0 '//ZMin
                | dblDimension(3)       = 500.0 '//XMax
                | dblDimension(4)       = 0.0   '//YMax
                | dblDimension(5)       = 300.0 '//ZMax
                | objItemRes1.SetDimension(dblDimension)
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementitemreservation.SetDimension(i_item_res_dimensions)

