#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrNomenclatures:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of UserNomenclature objects.

    """

    def __init__(self, catia):
        self.arrnomenclatures = catia.ArrNomenclatures     

    def add_user_nomenclature(self, i_name, i_icon_name, i_class_type, i_super_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddUserNomenclature
                | o Func AddUserNomenclature(    CATBSTR    iName,
                |                                CATBSTR    iIconName,
                |                                CATBSTR    iClassType,
                |                                CATBSTR    iSuperType) As ArrNomenclature
                | 
                | Creates a new UserNomenclature and adds it to this collection. The
                | NomenclatureType of the new UserNomenclature will be "User". The base
                | objects in the UserDictionary are created when the  UserDictionary is
                | created.


                | Parameters:
                | iName
                |     The user nomenclature name.
                | 
                |  
                |  iIconName
                |     The icon name associated to this nomenclature name.
                | 
                |  
                | 
                |  Returns:
                |      The new UserNomenclature.


        """
        return self.arrnomenclatures.AddUserNomenclature(i_name, i_icon_name, i_class_type, i_super_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As ArrNomenclature
                | 
                | Returns the specified item of the collection


                | Parameters:
                | iItem
                |     The list index (long) or name (CATBSTR) of the member to retrieve.
                | 
                |  
                | 
                |  Returns:
                |      The retrieved member object.


        """
        return self.arrnomenclatures.Item(i_index)

