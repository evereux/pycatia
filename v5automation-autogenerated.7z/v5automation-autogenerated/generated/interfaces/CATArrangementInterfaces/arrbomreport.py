#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrBOMReport:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAArrBOMReport

    """

    def __init__(self, catia):
        self.arrbomreport = catia.ArrBOMReport     

    def generate_bom_report(self, i_document_to_extract_data, i_output_file_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GenerateBOMReport
                | o Sub GenerateBOMReport(    Document    iDocumentToExtractData,
                |                             CATBSTR    iOutputFileName)
                | 
                | This method generate a BOM report on the current piping document to an
                | output html file.


                | Parameters:


        """
        return self.arrbomreport.GenerateBOMReport(i_document_to_extract_data, i_output_file_name)

