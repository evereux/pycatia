#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementArea:
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object to access an ArrangementArea object's properties and
                | functions.Role:The ArrangementArea object is a type of Arrangement
                | Object defining an  area containing other objects.

    """

    def __init__(self, catia):
        self.arrangementarea = catia.ArrangementArea     

    @property
    def arrangement_contours(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementContours
                | o Property ArrangementContours(    ) As ArrangementContours
                | 
                | Returns the ArrangementContours collection object associated with an
                | ArrangementArea object.  Example: This example retrieves the
                | ArrangementContours collection object for the objArea1 object.  Dim
                | objArrContours   As ArrangementContours Set objArrContours  =
                | objArea1.ArrangementContours


                | Parameters:


        """
        return self.arrangementarea.ArrangementContours

    @property
    def height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Height
                | o Property Height(    ) As double
                | 
                | Returns or sets the Height of an ArrangementArea object.  Example:
                | This example retrieves the Height for the objArea1 object.  Dim
                | dblAreaHeight   As Double dblAreaHeight  = objArea1.Height


                | Parameters:


        """
        return self.arrangementarea.Height

    @property
    def size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Size
                | o Property Size(    ) As double
                | 
                | Returns the Size of the ArrangementArea.  Example: This example
                | retrieves the Size of the objArea1 object.  Dim dblAreaSize   As
                | Double dblAreaSize  = objArea1.Size


                | Parameters:


        """
        return self.arrangementarea.Size

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As CATArrangementAreaVisuMode
                | 
                | Returns or sets the Visualization Mode for an ArrangementArea object.
                | Example: This example sets the Visualization Mode for the objArea1
                | object to CatArrangementAreaVisuModeVolume.  objArea1.VisuMode =
                | CatArrangementAreaVisuModeVolume


                | Parameters:


        """
        return self.arrangementarea.VisuMode

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(    CATBSTR    iApplicationType) As CATBaseDispatch
                | 
                | Returns the applicative data whose type is the given parameter.


                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                | 
                |  Returns:
                |   oApplicativeObj   The matched applicative object.


                | Examples:
                | 
                | 
                | This example retrieves the desired applicative object from the objArea1 object.
                | 
                | Dim objProd   As Product
                | objProd  = objArea1.GetTechnologicalObject("Product")
                | 
                | 
                | 
                | 
        """
        return self.arrangementarea.GetTechnologicalObject(i_application_type)

