#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementRun:
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object to access the properties and methods of an
                | ArrangementRun object.Role:Use this interface to control the
                | visualization mode, section parameters, nodes that define the
                | ArrangementRun object.

    """

    def __init__(self, catia):
        self.arrangementrun = catia.ArrangementRun     

    @property
    def arrangement_nodes(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementNodes
                | o Property ArrangementNodes(    ) As ArrangementNodes
                | 
                | Returns the ArrangementNodes that make up the ArrangementRun.
                | Example: This example gets the ArrangementNodes for the objRun1
                | object.  Dim objArrNodes   As ArrangementNodes Set objArrNodes =
                | objRun1.ArrangementNodes


                | Parameters:


        """
        return self.arrangementrun.ArrangementNodes

    @property
    def length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Length
                | o Property Length(    ) As double
                | 
                | Returns the length of the ArrangementRun object.  Example: This
                | example retrieves the Length of the objRun1 object.  Dim dblLength
                | As Double dblLength  = objRun1.Length


                | Parameters:


        """
        return self.arrangementrun.Length

    @property
    def section_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionDiameter
                | o Property SectionDiameter(    ) As double
                | 
                | Returns or sets the SectionDiameter for an ArrangementRun object.
                | Example: This example retrieves the SectionDiameter for the objRun1
                | object.  Dim dblSectionDia   As Double dblSectionDia =
                | objRun1.SectionDiameter


                | Parameters:


        """
        return self.arrangementrun.SectionDiameter

    @property
    def section_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionHeight
                | o Property SectionHeight(    ) As double
                | 
                | Returns or sets the SectionHeight for an ArrangementRun object.
                | Example: This example gets the SectionHeight for the objRun1 object.
                | Dim dblSectionHeight   As Double dblSectionHeight =
                | objRun1.SectionHeight


                | Parameters:


        """
        return self.arrangementrun.SectionHeight

    @property
    def section_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionType
                | o Property SectionType(    ) As CATArrangementRouteSection
                | 
                | Returns or sets the SectionType for an ArrangementRun object.
                | Example: This example sets the SectionType for the objRun1 object to
                | CatArrangementRouteSectionRectangular.  objRun1.SectionType =
                | CatArrangementRouteSectionRectangular


                | Parameters:


        """
        return self.arrangementrun.SectionType

    @property
    def section_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionWidth
                | o Property SectionWidth(    ) As double
                | 
                | Returns or sets the SectionWidth for an ArrangementRun object.
                | Example: This example gets the SectionWidth for the objRun1 object.
                | Dim dblSectionWidth   As Double dblSectionWidth = objRun1.SectionWidth


                | Parameters:


        """
        return self.arrangementrun.SectionWidth

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As CATArrangementRouteVisuMode
                | 
                | Returns or sets the Visualization Mode for an ArrangementRun object.
                | Example: This example sets the Visualization Mode for the objRun1
                | object to CatArrangementRouteVisuModeSolid.  objRun1.VisuMode =
                | CatArrangementRouteVisuModeSolid


                | Parameters:


        """
        return self.arrangementrun.VisuMode

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(    CATBSTR    iApplicationType) As CATBaseDispatch
                | 
                | Returns the applicative data which type is the given parameter.


                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.


                | Examples:
                | 
                | 
                | This example retrieves the desired applicative object from the objRun1 object.
                | 
                | Dim objProd   As Product
                | objProd  = objRun1.GetTechnologicalObject("Product")
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementrun.GetTechnologicalObject(i_application_type)

