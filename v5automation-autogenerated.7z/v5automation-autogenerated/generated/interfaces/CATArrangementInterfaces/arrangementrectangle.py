#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementRectangle:
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object to access the properties and methods of an
                | ArrangementRectangle object.Role: The ArrangementRectangle object is a
                | geometric shape used for defining  Contours of Areas. The
                | ArrangementRectangle is defined by width and length and its Product
                | position (which is the min-x, min-y corner of the rectangle).

    """

    def __init__(self, catia):
        self.arrangementrectangle = catia.ArrangementRectangle     

    @property
    def x_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | XLength
                | o Property XLength(    ) As double
                | 
                | Returns or sets the XLength of the ArrangementRectangle.  Example:
                | This example retrieves the XLength for the objRectangle1 object.  Dim
                | dblXLength  As Double dblXLength = objRectangle1.XLength


                | Parameters:


        """
        return self.arrangementrectangle.XLength

    @property
    def y_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | YLength
                | o Property YLength(    ) As double
                | 
                | Returns or sets the YLength of the ArrangementRectangle.  Example:
                | This example retrieves the YLength for the objRectangle1 object.  Dim
                | dblYLength  As Double dblYLength = objRectangle1.YLength


                | Parameters:


        """
        return self.arrangementrectangle.YLength

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(    CATBSTR    iApplicationType) As CATBaseDispatch
                | 
                | Returns the applicative data which type is the given parameter.


                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.


                | Examples:
                | 
                | 
                | This example retrieves the desired applicative object from the objRectangle1 object.
                | 
                | Dim objProd   As Product
                | objProd  = objRectangle1.GetTechnologicalObject("Product")
                | 
                | 
                | 
                | 
                | 
        """
        return self.arrangementrectangle.GetTechnologicalObject(i_application_type)

