#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATArrangementItemResVisuMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Visualization mode for Item Reservation.

    """

    def __init__(self, catia):
        self.catarrangementitemresvisumode = catia.CATArrangementItemResVisuMode     

