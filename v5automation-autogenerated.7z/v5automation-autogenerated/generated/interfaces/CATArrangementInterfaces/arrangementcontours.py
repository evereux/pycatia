#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ArrangementContours:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection object for ArrangementContours of an Area.Role:Use this
                | to manage (create, retrieve and remove) ArrangementContours of an
                | ArrangementArea.

    """

    def __init__(self, catia):
        self.arrangementcontours = catia.ArrangementContours     

    def add_rectangular_contour(self, i_rectangle):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddRectangularContour
                | o Func AddRectangularContour(    ArrangementRectangle    iRectangle) As ArrangementContour
                | 
                | Creates a Rectangular Contour by adding a ArrangementRectangle to the
                | collection.


                | Parameters:
                | iRectangle
                |    ArrangementRectangle to create the contour from.
                |  
                | 
                |  Returns:
                |     Returns the newly created ArrangementContour object and adds it to the collection.


        """
        return self.arrangementcontours.AddRectangularContour(i_rectangle)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As ArrangementContour
                | 
                | Returns the specified ArrangementContour item of the collection.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementContour to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementContour in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementContour by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |      The retrieved ArrangementContour object.


        """
        return self.arrangementcontours.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes the specified ArrangementContour object from the collection.


                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementContour to remove from this collection.
                |    
                |  To remove a specific object by number, use the rank of the ArrangementContour in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To remove a specific ArrangementContour by name, use name that you assigned using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


        """
        return self.arrangementcontours.Remove(i_index)

