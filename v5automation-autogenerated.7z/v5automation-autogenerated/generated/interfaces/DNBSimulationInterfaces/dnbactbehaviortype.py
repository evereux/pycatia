#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DNBActBehaviorType:
    """
        .. note::
            CAA V5 Visual Basic help

                | The Behavior setting attribute range of values.

    """

    def __init__(self, catia):
        self.dnbactbehaviortype = catia.DNBActBehaviorType     

