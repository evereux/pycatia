#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SimTraceSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to handle parameters of Infrastructure-DELMIA
                | Infrastructure-Simulation Trace Tools Options Tab page.Role: This
                | interface is implemented by a component which  represents the
                | controller of Simulation Trace Tools Options parameter settings.Here
                | is the list of parameters to use and their meaning:

    """

    def __init__(self, catia):
        self.simtracesettingatt = catia.SimTraceSettingAtt     

    @property
    def trace_axis_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceAxisColor
                | o Property TraceAxisColor(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the TraceAxisColor parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceAxisColor

    @property
    def trace_axis_thick(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceAxisThick
                | o Property TraceAxisThick(    ) As long
                | 
                | Returns or sets the TraceAxisThick parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceAxisThick

    @property
    def trace_axis_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceAxisType
                | o Property TraceAxisType(    ) As long
                | 
                | Returns or sets the TraceAxisType parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceAxisType

    @property
    def trace_axis_visu(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceAxisVisu
                | o Property TraceAxisVisu(    ) As boolean
                | 
                | Returns or sets the TraceAxisVisu parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceAxisVisu

    @property
    def trace_delete_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceDeletePath
                | o Property TraceDeletePath(    ) As boolean
                | 
                | Returns or sets the TraceDeletePath parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceDeletePath

    @property
    def trace_legend(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceLegend
                | o Property TraceLegend(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the TraceLegend parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceLegend

    @property
    def trace_line_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceLineColor
                | o Property TraceLineColor(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the TraceLineColor parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceLineColor

    @property
    def trace_line_thick(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceLineThick
                | o Property TraceLineThick(    ) As long
                | 
                | Returns or sets the TraceLineThick parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceLineThick

    @property
    def trace_line_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceLineType
                | o Property TraceLineType(    ) As long
                | 
                | Returns or sets the TraceLineType parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceLineType

    @property
    def trace_line_visu(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TraceLineVisu
                | o Property TraceLineVisu(    ) As boolean
                | 
                | Returns or sets the TraceLineVisu parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TraceLineVisu

    @property
    def trace_point_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TracePointColor
                | o Property TracePointColor(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the TracePointColor parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TracePointColor

    @property
    def trace_point_symbol(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TracePointSymbol
                | o Property TracePointSymbol(    ) As long
                | 
                | Returns or sets the TracePointSymbol parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TracePointSymbol

    @property
    def trace_point_visu(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TracePointVisu
                | o Property TracePointVisu(    ) As boolean
                | 
                | Returns or sets the TracePointVisu parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.simtracesettingatt.TracePointVisu

    def get_trace_axis_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceAxisColorInfo
                | o Func GetTraceAxisColorInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceAxisColor parameter.
                | Role:Retrieves the state of the TraceAxisColor parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTraceAxisColorInfo(io_admin_level, io_locked)

    def get_trace_axis_thick_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceAxisThickInfo
                | o Func GetTraceAxisThickInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceAxisThick parameter.
                | Role:Retrieves the state of the TraceAxisThick parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTraceAxisThickInfo(io_admin_level, io_locked)

    def get_trace_axis_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceAxisTypeInfo
                | o Func GetTraceAxisTypeInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceAxisType parameter.
                | Role:Retrieves the state of the TraceAxisType parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTraceAxisTypeInfo(io_admin_level, io_locked)

    def get_trace_axis_visu_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceAxisVisuInfo
                | o Func GetTraceAxisVisuInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceAxisVisu parameter.
                | Role:Retrieves the state of the TraceAxisVisu parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simtracesettingatt.GetTraceAxisVisuInfo(io_admin_level, io_locked)

    def get_trace_delete_path_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceDeletePathInfo
                | o Func GetTraceDeletePathInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceDeletePath parameter.
                | Role:Retrieves the state of the TraceDeletePath parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simtracesettingatt.GetTraceDeletePathInfo(io_admin_level, io_locked)

    def get_trace_legend_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceLegendInfo
                | o Func GetTraceLegendInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceLegend parameter.
                | Role:Retrieves the state of the TraceLegend parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTraceLegendInfo(io_admin_level, io_locked)

    def get_trace_line_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceLineColorInfo
                | o Func GetTraceLineColorInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceLineColor parameter.
                | Role:Retrieves the state of the TraceLineColor parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTraceLineColorInfo(io_admin_level, io_locked)

    def get_trace_line_thick_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceLineThickInfo
                | o Func GetTraceLineThickInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceLineThick parameter.
                | Role:Retrieves the state of the TraceLineThick parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTraceLineThickInfo(io_admin_level, io_locked)

    def get_trace_line_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceLineTypeInfo
                | o Func GetTraceLineTypeInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceLineType parameter.
                | Role:Retrieves the state of the TraceLineType parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTraceLineTypeInfo(io_admin_level, io_locked)

    def get_trace_line_visu_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTraceLineVisuInfo
                | o Func GetTraceLineVisuInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TraceLineVisu parameter.
                | Role:Retrieves the state of the TraceLineVisu parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simtracesettingatt.GetTraceLineVisuInfo(io_admin_level, io_locked)

    def get_trace_point_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTracePointColorInfo
                | o Func GetTracePointColorInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TracePointColor parameter.
                | Role:Retrieves the state of the TracePointColor parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTracePointColorInfo(io_admin_level, io_locked)

    def get_trace_point_symbol_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTracePointSymbolInfo
                | o Func GetTracePointSymbolInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TracePointSymbol parameter.
                | Role:Retrieves the state of the TracePointSymbol parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.simtracesettingatt.GetTracePointSymbolInfo(io_admin_level, io_locked)

    def get_trace_point_visu_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTracePointVisuInfo
                | o Func GetTracePointVisuInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TracePointVisu parameter.
                | Role:Retrieves the state of the TracePointVisu parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simtracesettingatt.GetTracePointVisuInfo(io_admin_level, io_locked)

    def set_trace_axis_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceAxisColorLock
                | o Sub SetTraceAxisColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceAxisColor parameter. Role:Locks or unlocks
                | the TraceAxisColor parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceAxisColorLock(i_locked)

    def set_trace_axis_thick_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceAxisThickLock
                | o Sub SetTraceAxisThickLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceAxisThick parameter. Role:Locks or unlocks
                | the TraceAxisThick parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceAxisThickLock(i_locked)

    def set_trace_axis_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceAxisTypeLock
                | o Sub SetTraceAxisTypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceAxisType parameter. Role:Locks or unlocks
                | the TraceAxisType parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceAxisTypeLock(i_locked)

    def set_trace_axis_visu_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceAxisVisuLock
                | o Sub SetTraceAxisVisuLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceAxisVisu parameter. Role:Locks or unlocks
                | the TraceAxisVisu parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceAxisVisuLock(i_locked)

    def set_trace_delete_path_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceDeletePathLock
                | o Sub SetTraceDeletePathLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceDeletePath parameter. Role:Locks or unlocks
                | the TraceDeletePath parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceDeletePathLock(i_locked)

    def set_trace_legend_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceLegendLock
                | o Sub SetTraceLegendLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceLegend parameter. Role:Locks or unlocks the
                | TraceLegend parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceLegendLock(i_locked)

    def set_trace_line_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceLineColorLock
                | o Sub SetTraceLineColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceLineColor parameter. Role:Locks or unlocks
                | the TraceLineColor parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceLineColorLock(i_locked)

    def set_trace_line_thick_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceLineThickLock
                | o Sub SetTraceLineThickLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceLineThick parameter. Role:Locks or unlocks
                | the TraceLineThick parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceLineThickLock(i_locked)

    def set_trace_line_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceLineTypeLock
                | o Sub SetTraceLineTypeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceLineType parameter. Role:Locks or unlocks
                | the TraceLineType parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceLineTypeLock(i_locked)

    def set_trace_line_visu_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTraceLineVisuLock
                | o Sub SetTraceLineVisuLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TraceLineVisu parameter. Role:Locks or unlocks
                | the TraceLineVisu parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTraceLineVisuLock(i_locked)

    def set_trace_point_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTracePointColorLock
                | o Sub SetTracePointColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TracePointColor parameter. Role:Locks or unlocks
                | the TracePointColor parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTracePointColorLock(i_locked)

    def set_trace_point_symbol_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTracePointSymbolLock
                | o Sub SetTracePointSymbolLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TracePointSymbol parameter. Role:Locks or unlocks
                | the TracePointSymbol parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTracePointSymbolLock(i_locked)

    def set_trace_point_visu_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTracePointVisuLock
                | o Sub SetTracePointVisuLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TracePointVisu parameter. Role:Locks or unlocks
                | the TracePointVisu parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simtracesettingatt.SetTracePointVisuLock(i_locked)

