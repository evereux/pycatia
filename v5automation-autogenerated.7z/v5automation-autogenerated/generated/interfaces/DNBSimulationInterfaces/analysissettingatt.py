#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AnalysisSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, catia):
        self.analysissettingatt = catia.AnalysisSettingAtt     

    @property
    def analysis_level(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisLevel
                | o Property AnalysisLevel(    ) As DNBAnalysisLevel
                | 
                | Returns or sets the AnalysisLevel parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnalysisLevel

    @property
    def anl_accel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlAccelLimit
                | o Property AnlAccelLimit(    ) As boolean
                | 
                | Returns or sets the AnlAccelLimit parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlAccelLimit

    @property
    def anl_caution_zone(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlCautionZone
                | o Property AnlCautionZone(    ) As boolean
                | 
                | Returns or sets the AnlCautionZone parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlCautionZone

    @property
    def anl_io_analysis(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlIOAnalysis
                | o Property AnlIOAnalysis(    ) As boolean
                | 
                | Returns or sets the AnlIOAnalysis parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlIOAnalysis

    @property
    def anl_int_dist(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlIntDist
                | o Property AnlIntDist(    ) As boolean
                | 
                | Returns or sets the AnlIntDist parameter.  Ensure consistency with the
                | C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlIntDist

    @property
    def anl_intf(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlIntf
                | o Property AnlIntf(    ) As boolean
                | 
                | Returns or sets the AnlIntf parameter.  Ensure consistency with the
                | C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlIntf

    @property
    def anl_lin_accel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlLinAccelLimit
                | o Property AnlLinAccelLimit(    ) As boolean
                | 
                | Returns or sets the AnlLinAccelLimit parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlLinAccelLimit

    @property
    def anl_lin_speed_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlLinSpeedLimit
                | o Property AnlLinSpeedLimit(    ) As boolean
                | 
                | Returns or sets the AnlLinSpeedLimit parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlLinSpeedLimit

    @property
    def anl_measure(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlMeasure
                | o Property AnlMeasure(    ) As boolean
                | 
                | Returns or sets the AnlMeasure parameter.  Ensure consistency with the
                | C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlMeasure

    @property
    def anl_rot_accel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlRotAccelLimit
                | o Property AnlRotAccelLimit(    ) As boolean
                | 
                | Returns or sets the AnlRotAccelLimit parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlRotAccelLimit

    @property
    def anl_rot_speed_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlRotSpeedLimit
                | o Property AnlRotSpeedLimit(    ) As boolean
                | 
                | Returns or sets the AnlRotSpeedLimit parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlRotSpeedLimit

    @property
    def anl_travel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlTravelLimit
                | o Property AnlTravelLimit(    ) As boolean
                | 
                | Returns or sets the AnlTravelLimit parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlTravelLimit

    @property
    def anl_velocity_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnlVelocityLimit
                | o Property AnlVelocityLimit(    ) As boolean
                | 
                | Returns or sets the AnlVelocityLimit parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AnlVelocityLimit

    @property
    def ask_anl_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AskAnlMode
                | o Property AskAnlMode(    ) As boolean
                | 
                | Returns or sets the AskAnlMode parameter.  Ensure consistency with the
                | C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.AskAnlMode

    @property
    def beep_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BeepMode
                | o Property BeepMode(    ) As boolean
                | 
                | Returns or sets the BeepMode parameter.  Ensure consistency with the
                | C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.BeepMode

    @property
    def display_anl_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayAnlStatus
                | o Property DisplayAnlStatus(    ) As boolean
                | 
                | Returns or sets the DisplayAnlStatus parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.DisplayAnlStatus

    @property
    def enable_anl_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EnableAnlMode
                | o Property EnableAnlMode(    ) As boolean
                | 
                | Returns or sets the EnableAnlMode parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.EnableAnlMode

    @property
    def sync_anl_specs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SyncAnlSpecs
                | o Property SyncAnlSpecs(    ) As boolean
                | 
                | Returns or sets the SyncAnlSpecs parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.SyncAnlSpecs

    @property
    def visualization_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisualizationMode
                | o Property VisualizationMode(    ) As DNBVisualizationMode
                | 
                | Returns or sets the VisualizationMode parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.VisualizationMode

    @property
    def voxel_static_anl(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VoxelStaticAnl
                | o Property VoxelStaticAnl(    ) As boolean
                | 
                | Returns or sets the VoxelStaticAnl parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.analysissettingatt.VoxelStaticAnl

    def get_analysis_level_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnalysisLevelInfo
                | o Func GetAnalysisLevelInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnalysisLevel parameter.
                | Role:Retrieves the state of the AnalysisLevel parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnalysisLevelInfo(io_admin_level, io_locked)

    def get_anl_accel_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlAccelLimitInfo
                | o Func GetAnlAccelLimitInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlAccelLimit parameter.
                | Role:Retrieves the state of the AnlAccelLimit parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlAccelLimitInfo(io_admin_level, io_locked)

    def get_anl_caution_zone_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlCautionZoneInfo
                | o Func GetAnlCautionZoneInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlCautionZone parameter.
                | Role:Retrieves the state of the AnlCautionZone parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlCautionZoneInfo(io_admin_level, io_locked)

    def get_anl_io_analysis_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlIOAnalysisInfo
                | o Func GetAnlIOAnalysisInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlIOAnalysis parameter.
                | Role:Retrieves the state of the AnlIOAnalysis parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlIOAnalysisInfo(io_admin_level, io_locked)

    def get_anl_int_dist_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlIntDistInfo
                | o Func GetAnlIntDistInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlIntDist parameter.
                | Role:Retrieves the state of the AnlIntDist parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlIntDistInfo(io_admin_level, io_locked)

    def get_anl_intf_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlIntfInfo
                | o Func GetAnlIntfInfo(    CATBSTR    ioAdminLevel,
                |                           CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlIntf parameter.
                | Role:Retrieves the state of the AnlIntf parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlIntfInfo(io_admin_level, io_locked)

    def get_anl_lin_accel_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlLinAccelLimitInfo
                | o Func GetAnlLinAccelLimitInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlLinAccelLimit parameter.
                | Role:Retrieves the state of the AnlLinAccelLimit parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlLinAccelLimitInfo(io_admin_level, io_locked)

    def get_anl_lin_speed_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlLinSpeedLimitInfo
                | o Func GetAnlLinSpeedLimitInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlLinSpeedLimit parameter.
                | Role:Retrieves the state of the AnlLinSpeedLimit parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlLinSpeedLimitInfo(io_admin_level, io_locked)

    def get_anl_measure_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlMeasureInfo
                | o Func GetAnlMeasureInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlMeasure parameter.
                | Role:Retrieves the state of the AnlMeasure parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlMeasureInfo(io_admin_level, io_locked)

    def get_anl_rot_accel_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlRotAccelLimitInfo
                | o Func GetAnlRotAccelLimitInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlRotAccelLimit parameter.
                | Role:Retrieves the state of the AnlRotAccelLimit parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlRotAccelLimitInfo(io_admin_level, io_locked)

    def get_anl_rot_speed_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlRotSpeedLimitInfo
                | o Func GetAnlRotSpeedLimitInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlRotSpeedLimit parameter.
                | Role:Retrieves the state of the AnlRotSpeedLimit parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlRotSpeedLimitInfo(io_admin_level, io_locked)

    def get_anl_travel_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlTravelLimitInfo
                | o Func GetAnlTravelLimitInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlTravelLimit parameter.
                | Role:Retrieves the state of the AnlTravelLimit parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlTravelLimitInfo(io_admin_level, io_locked)

    def get_anl_velocity_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnlVelocityLimitInfo
                | o Func GetAnlVelocityLimitInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AnlVelocityLimit parameter.
                | Role:Retrieves the state of the AnlVelocityLimit parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAnlVelocityLimitInfo(io_admin_level, io_locked)

    def get_ask_anl_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAskAnlModeInfo
                | o Func GetAskAnlModeInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AskAnlMode parameter.
                | Role:Retrieves the state of the AskAnlMode parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetAskAnlModeInfo(io_admin_level, io_locked)

    def get_beep_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBeepModeInfo
                | o Func GetBeepModeInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the BeepMode parameter.
                | Role:Retrieves the state of the BeepMode parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetBeepModeInfo(io_admin_level, io_locked)

    def get_display_anl_status_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayAnlStatusInfo
                | o Func GetDisplayAnlStatusInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the DisplayAnlStatus parameter.
                | Role:Retrieves the state of the DisplayAnlStatus parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetDisplayAnlStatusInfo(io_admin_level, io_locked)

    def get_enable_anl_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetEnableAnlModeInfo
                | o Func GetEnableAnlModeInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the EnableAnlMode parameter.
                | Role:Retrieves the state of the EnableAnlMode parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetEnableAnlModeInfo(io_admin_level, io_locked)

    def get_sync_anl_specs_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSyncAnlSpecsInfo
                | o Func GetSyncAnlSpecsInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the SyncAnlSpecs parameter.
                | Role:Retrieves the state of the SyncAnlSpecs parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetSyncAnlSpecsInfo(io_admin_level, io_locked)

    def get_visualization_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetVisualizationModeInfo
                | o Func GetVisualizationModeInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the VisualizationMode
                | parameter. Role:Retrieves the state of the VisualizationMode parameter
                | in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetVisualizationModeInfo(io_admin_level, io_locked)

    def get_voxel_static_anl_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetVoxelStaticAnlInfo
                | o Func GetVoxelStaticAnlInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the VoxelStaticAnl parameter.
                | Role:Retrieves the state of the VoxelStaticAnl parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.analysissettingatt.GetVoxelStaticAnlInfo(io_admin_level, io_locked)

    def set_analysis_level_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnalysisLevelLock
                | o Sub SetAnalysisLevelLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnalysisLevel parameter. Role:Locks or unlocks
                | the AnalysisLevel parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnalysisLevelLock(i_locked)

    def set_anl_accel_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlAccelLimitLock
                | o Sub SetAnlAccelLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlAccelLimit parameter. Role:Locks or unlocks
                | the AnlAccelLimit parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlAccelLimitLock(i_locked)

    def set_anl_caution_zone_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlCautionZoneLock
                | o Sub SetAnlCautionZoneLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlCautionZone parameter. Role:Locks or unlocks
                | the AnlCautionZone parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlCautionZoneLock(i_locked)

    def set_anl_io_analysis_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlIOAnalysisLock
                | o Sub SetAnlIOAnalysisLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlIOAnalysis parameter. Role:Locks or unlocks
                | the AnlIOAnalysis parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlIOAnalysisLock(i_locked)

    def set_anl_int_dist_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlIntDistLock
                | o Sub SetAnlIntDistLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlIntDist parameter. Role:Locks or unlocks the
                | AnlIntDist parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlIntDistLock(i_locked)

    def set_anl_intf_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlIntfLock
                | o Sub SetAnlIntfLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlIntf parameter. Role:Locks or unlocks the
                | AnlIntf parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlIntfLock(i_locked)

    def set_anl_lin_accel_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlLinAccelLimitLock
                | o Sub SetAnlLinAccelLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlLinAccelLimit parameter. Role:Locks or unlocks
                | the AnlLinAccelLimit parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlLinAccelLimitLock(i_locked)

    def set_anl_lin_speed_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlLinSpeedLimitLock
                | o Sub SetAnlLinSpeedLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlLinSpeedLimit parameter. Role:Locks or unlocks
                | the AnlLinSpeedLimit parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlLinSpeedLimitLock(i_locked)

    def set_anl_measure_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlMeasureLock
                | o Sub SetAnlMeasureLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlMeasure parameter. Role:Locks or unlocks the
                | AnlMeasure parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlMeasureLock(i_locked)

    def set_anl_rot_accel_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlRotAccelLimitLock
                | o Sub SetAnlRotAccelLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlRotAccelLimit parameter. Role:Locks or unlocks
                | the AnlRotAccelLimit parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlRotAccelLimitLock(i_locked)

    def set_anl_rot_speed_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlRotSpeedLimitLock
                | o Sub SetAnlRotSpeedLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlRotSpeedLimit parameter. Role:Locks or unlocks
                | the AnlRotSpeedLimit parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlRotSpeedLimitLock(i_locked)

    def set_anl_travel_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlTravelLimitLock
                | o Sub SetAnlTravelLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlTravelLimit parameter. Role:Locks or unlocks
                | the AnlTravelLimit parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlTravelLimitLock(i_locked)

    def set_anl_velocity_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnlVelocityLimitLock
                | o Sub SetAnlVelocityLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AnlVelocityLimit parameter. Role:Locks or unlocks
                | the AnlVelocityLimit parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAnlVelocityLimitLock(i_locked)

    def set_ask_anl_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAskAnlModeLock
                | o Sub SetAskAnlModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AskAnlMode parameter. Role:Locks or unlocks the
                | AskAnlMode parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetAskAnlModeLock(i_locked)

    def set_beep_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBeepModeLock
                | o Sub SetBeepModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the BeepMode parameter. Role:Locks or unlocks the
                | BeepMode parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetBeepModeLock(i_locked)

    def set_display_anl_status_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayAnlStatusLock
                | o Sub SetDisplayAnlStatusLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DisplayAnlStatus parameter. Role:Locks or unlocks
                | the DisplayAnlStatus parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetDisplayAnlStatusLock(i_locked)

    def set_enable_anl_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetEnableAnlModeLock
                | o Sub SetEnableAnlModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the EnableAnlMode parameter. Role:Locks or unlocks
                | the EnableAnlMode parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetEnableAnlModeLock(i_locked)

    def set_sync_anl_specs_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSyncAnlSpecsLock
                | o Sub SetSyncAnlSpecsLock(    boolean    iLocked)
                | 
                | Locks or unlocks the SyncAnlSpecs parameter. Role:Locks or unlocks the
                | SyncAnlSpecs parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetSyncAnlSpecsLock(i_locked)

    def set_visualization_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVisualizationModeLock
                | o Sub SetVisualizationModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the VisualizationMode parameter. Role:Locks or
                | unlocks the VisualizationMode parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetVisualizationModeLock(i_locked)

    def set_voxel_static_anl_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVoxelStaticAnlLock
                | o Sub SetVoxelStaticAnlLock(    boolean    iLocked)
                | 
                | Locks or unlocks the VoxelStaticAnl parameter. Role:Locks or unlocks
                | the VoxelStaticAnl parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.analysissettingatt.SetVoxelStaticAnlLock(i_locked)

