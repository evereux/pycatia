#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DNBVisualizationMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | The analysis Visualization Mode setting attribute range of values.

    """

    def __init__(self, catia):
        self.dnbvisualizationmode = catia.DNBVisualizationMode     

