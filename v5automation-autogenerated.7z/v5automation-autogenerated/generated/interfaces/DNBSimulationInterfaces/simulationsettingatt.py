#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SimulationSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, catia):
        self.simulationsettingatt = catia.SimulationSettingAtt     

    @property
    def as_navigation_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ASNavigationMode
                | o Property ASNavigationMode(    ) As DNBSimNavigationMode
                | 
                | Returns or sets the ASNavigationMode setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.ASNavigationMode

    @property
    def as_step_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ASStepSize
                | o Property ASStepSize(    ) As float
                | 
                | Returns or sets the ASStepSize setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.ASStepSize

    @property
    def ath_annotation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AthAnnotation
                | o Property AthAnnotation(    ) As boolean
                | 
                | Returns or sets the AthAnnotation setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.AthAnnotation

    @property
    def ath_disable_sim(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AthDisableSim
                | o Property AthDisableSim(    ) As boolean
                | 
                | Returns or sets the AthDisableSim setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.AthDisableSim

    @property
    def ath_end_condition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AthEndCondition
                | o Property AthEndCondition(    ) As boolean
                | 
                | Returns or sets the AthEndCondition setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.AthEndCondition

    @property
    def ath_hyperlink(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AthHyperlink
                | o Property AthHyperlink(    ) As boolean
                | 
                | Returns or sets the AthHyperlink setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.AthHyperlink

    @property
    def ath_sel_agent_dlg(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AthSelAgentDlg
                | o Property AthSelAgentDlg(    ) As boolean
                | 
                | Returns or sets the AthSelAgentDlg setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.AthSelAgentDlg

    @property
    def ath_state_mgt(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AthStateMgt
                | o Property AthStateMgt(    ) As boolean
                | 
                | Returns or sets the AthStateMgt setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.AthStateMgt

    @property
    def ath_text_msg(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AthTextMsg
                | o Property AthTextMsg(    ) As boolean
                | 
                | Returns or sets the AthTextMsg setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.AthTextMsg

    @property
    def ath_viewpoint(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AthViewpoint
                | o Property AthViewpoint(    ) As boolean
                | 
                | Returns or sets the AthViewpoint setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.AthViewpoint

    @property
    def ps_cycle_time(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PSCycleTime
                | o Property PSCycleTime(    ) As boolean
                | 
                | Returns or sets the PSCycleTime setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.PSCycleTime

    @property
    def ps_dyn_clash_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PSDynClashMode
                | o Property PSDynClashMode(    ) As DNBVisualizationMode
                | 
                | Returns or sets the PSDynClashMode setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.PSDynClashMode

    @property
    def ps_graphic_sim_step(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PSGraphicSimStep
                | o Property PSGraphicSimStep(    ) As long
                | 
                | Returns or sets the PSGraphicSimStep setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.PSGraphicSimStep

    @property
    def ps_graphic_update(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PSGraphicUpdate
                | o Property PSGraphicUpdate(    ) As DNBSimGraphUpdateMode
                | 
                | Returns or sets the PSGraphicUpdate setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.PSGraphicUpdate

    @property
    def pv_end_condition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PVEndCondition
                | o Property PVEndCondition(    ) As boolean
                | 
                | Returns or sets the PVEndCondition setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.PVEndCondition

    @property
    def pv_state_mgt(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PVStateMgt
                | o Property PVStateMgt(    ) As boolean
                | 
                | Returns or sets the PVStateMgt setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.PVStateMgt

    @property
    def run_annot_behavior(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunAnnotBehavior
                | o Property RunAnnotBehavior(    ) As DNBActBehaviorType
                | 
                | Returns or sets the RunAnnotBehavior setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunAnnotBehavior

    @property
    def run_annotation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunAnnotation
                | o Property RunAnnotation(    ) As boolean
                | 
                | Returns or sets the RunAnnotation setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunAnnotation

    @property
    def run_end_condition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunEndCondition
                | o Property RunEndCondition(    ) As boolean
                | 
                | Returns or sets the RunEndCondition setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunEndCondition

    @property
    def run_hlnk_behavior(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunHlnkBehavior
                | o Property RunHlnkBehavior(    ) As DNBHlnkBehaviorType
                | 
                | Returns or sets the RunHlnkBehavior setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunHlnkBehavior

    @property
    def run_hyperlink(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunHyperlink
                | o Property RunHyperlink(    ) As boolean
                | 
                | Returns or sets the RunHyperlink setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunHyperlink

    @property
    def run_pause(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunPause
                | o Property RunPause(    ) As boolean
                | 
                | Returns or sets the RunPause setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunPause

    @property
    def run_state_mgt(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunStateMgt
                | o Property RunStateMgt(    ) As boolean
                | 
                | Returns or sets the RunStateMgt setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunStateMgt

    @property
    def run_step_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunStepSize
                | o Property RunStepSize(    ) As float
                | 
                | Returns or sets the RunStepSize setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunStepSize

    @property
    def run_text_behavior(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunTextBehavior
                | o Property RunTextBehavior(    ) As DNBActBehaviorType
                | 
                | Returns or sets the RunTextBehavior setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunTextBehavior

    @property
    def run_text_msg(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunTextMsg
                | o Property RunTextMsg(    ) As boolean
                | 
                | Returns or sets the RunTextMsg setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunTextMsg

    @property
    def run_viewpoint(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunViewpoint
                | o Property RunViewpoint(    ) As boolean
                | 
                | Returns or sets the RunViewpoint setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunViewpoint

    @property
    def run_vis_behavior(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RunVisBehavior
                | o Property RunVisBehavior(    ) As DNBActBehaviorType
                | 
                | Returns or sets the RunVisBehavior setting attribute value.


                | Parameters:


        """
        return self.simulationsettingatt.RunVisBehavior

    def get_as_navigation_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetASNavigationModeInfo
                | o Func GetASNavigationModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ASNavigationMode parameter.
                | Role:Retrieves the state of the ASNavigationMode parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetASNavigationModeInfo(io_admin_level, io_locked)

    def get_as_step_size_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetASStepSizeInfo
                | o Func GetASStepSizeInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ASStepSize parameter.
                | Role:Retrieves the state of the ASStepSize parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetASStepSizeInfo(io_admin_level, io_locked)

    def get_ath_annotation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAthAnnotationInfo
                | o Func GetAthAnnotationInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AthAnnotation parameter.
                | Role:Retrieves the state of the AthAnnotation parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetAthAnnotationInfo(io_admin_level, io_locked)

    def get_ath_disable_sim_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAthDisableSimInfo
                | o Func GetAthDisableSimInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AthDisableSim parameter.
                | Role:Retrieves the state of the AthDisableSim parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetAthDisableSimInfo(io_admin_level, io_locked)

    def get_ath_end_condition_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAthEndConditionInfo
                | o Func GetAthEndConditionInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AthEndCondition parameter.
                | Role:Retrieves the state of the AthEndCondition parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetAthEndConditionInfo(io_admin_level, io_locked)

    def get_ath_hyperlink_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAthHyperlinkInfo
                | o Func GetAthHyperlinkInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AthHyperlink parameter.
                | Role:Retrieves the state of the AthHyperlink parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetAthHyperlinkInfo(io_admin_level, io_locked)

    def get_ath_sel_agent_dlg_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAthSelAgentDlgInfo
                | o Func GetAthSelAgentDlgInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AthSelAgentDlg parameter.
                | Role:Retrieves the state of the AthSelAgentDlg parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetAthSelAgentDlgInfo(io_admin_level, io_locked)

    def get_ath_state_mgt_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAthStateMgtInfo
                | o Func GetAthStateMgtInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AthStateMgt parameter.
                | Role:Retrieves the state of the AthStateMgt parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetAthStateMgtInfo(io_admin_level, io_locked)

    def get_ath_text_msg_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAthTextMsgInfo
                | o Func GetAthTextMsgInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AthTextMsg parameter.
                | Role:Retrieves the state of the AthTextMsg parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetAthTextMsgInfo(io_admin_level, io_locked)

    def get_ath_viewpoint_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAthViewpointInfo
                | o Func GetAthViewpointInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AthViewpoint parameter.
                | Role:Retrieves the state of the AthViewpoint parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetAthViewpointInfo(io_admin_level, io_locked)

    def get_ps_cycle_time_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPSCycleTimeInfo
                | o Func GetPSCycleTimeInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the PSCycleTime parameter.
                | Role:Retrieves the state of the PSCycleTime parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetPSCycleTimeInfo(io_admin_level, io_locked)

    def get_ps_dyn_clash_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPSDynClashModeInfo
                | o Func GetPSDynClashModeInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the PSDynClashMode parameter.
                | Role:Retrieves the state of the PSDynClashMode parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetPSDynClashModeInfo(io_admin_level, io_locked)

    def get_ps_graphic_sim_step_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPSGraphicSimStepInfo
                | o Func GetPSGraphicSimStepInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the PSGraphicSimStep parameter.
                | Role:Retrieves the state of the PSGraphicSimStep parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetPSGraphicSimStepInfo(io_admin_level, io_locked)

    def get_ps_graphic_update_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPSGraphicUpdateInfo
                | o Func GetPSGraphicUpdateInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the PSGraphicUpdate parameter.
                | Role:Retrieves the state of the PSGraphicUpdate parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetPSGraphicUpdateInfo(io_admin_level, io_locked)

    def get_pv_end_condition_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPVEndConditionInfo
                | o Func GetPVEndConditionInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the PVEndCondition parameter.
                | Role:Retrieves the state of the PVEndCondition parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetPVEndConditionInfo(io_admin_level, io_locked)

    def get_pv_state_mgt_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPVStateMgtInfo
                | o Func GetPVStateMgtInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the PVStateMgt parameter.
                | Role:Retrieves the state of the PVStateMgt parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetPVStateMgtInfo(io_admin_level, io_locked)

    def get_run_annot_behavior_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunAnnotBehaviorInfo
                | o Func GetRunAnnotBehaviorInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunAnnotBehavior parameter.
                | Role:Retrieves the state of the RunAnnotBehavior parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunAnnotBehaviorInfo(io_admin_level, io_locked)

    def get_run_annotation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunAnnotationInfo
                | o Func GetRunAnnotationInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunAnnotation parameter.
                | Role:Retrieves the state of the RunAnnotation parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunAnnotationInfo(io_admin_level, io_locked)

    def get_run_end_condition_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunEndConditionInfo
                | o Func GetRunEndConditionInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunEndCondition parameter.
                | Role:Retrieves the state of the RunEndCondition parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunEndConditionInfo(io_admin_level, io_locked)

    def get_run_hlnk_behavior_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunHlnkBehaviorInfo
                | o Func GetRunHlnkBehaviorInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunHlnkBehavior parameter.
                | Role:Retrieves the state of the RunHlnkBehavior parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunHlnkBehaviorInfo(io_admin_level, io_locked)

    def get_run_hyperlink_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunHyperlinkInfo
                | o Func GetRunHyperlinkInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunHyperlink parameter.
                | Role:Retrieves the state of the RunHyperlink parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunHyperlinkInfo(io_admin_level, io_locked)

    def get_run_pause_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunPauseInfo
                | o Func GetRunPauseInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunPause parameter.
                | Role:Retrieves the state of the RunPause parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunPauseInfo(io_admin_level, io_locked)

    def get_run_state_mgt_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunStateMgtInfo
                | o Func GetRunStateMgtInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunStateMgt parameter.
                | Role:Retrieves the state of the RunStateMgt parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunStateMgtInfo(io_admin_level, io_locked)

    def get_run_step_size_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunStepSizeInfo
                | o Func GetRunStepSizeInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunStepSize parameter.
                | Role:Retrieves the state of the RunStepSize parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunStepSizeInfo(io_admin_level, io_locked)

    def get_run_text_behavior_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunTextBehaviorInfo
                | o Func GetRunTextBehaviorInfo(    CATBSTR    ioAdminLevel,
                |                                   CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunTextBehavior parameter.
                | Role:Retrieves the state of the RunTextBehavior parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunTextBehaviorInfo(io_admin_level, io_locked)

    def get_run_text_msg_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunTextMsgInfo
                | o Func GetRunTextMsgInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunTextMsg parameter.
                | Role:Retrieves the state of the RunTextMsg parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunTextMsgInfo(io_admin_level, io_locked)

    def get_run_viewpoint_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunViewpointInfo
                | o Func GetRunViewpointInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunViewpoint parameter.
                | Role:Retrieves the state of the RunViewpoint parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunViewpointInfo(io_admin_level, io_locked)

    def get_run_vis_behavior_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRunVisBehaviorInfo
                | o Func GetRunVisBehaviorInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the RunVisBehavior parameter.
                | Role:Retrieves the state of the RunVisBehavior parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |      level that imposes the value of the parameter.
                |      If the parameter is not locked, AdminLevel gives the administration
                |      level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |      Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |        Indicates if the parameter has been explicitly modified or remain
                |      to the administrated value.


        """
        return self.simulationsettingatt.GetRunVisBehaviorInfo(io_admin_level, io_locked)

    def set_as_navigation_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetASNavigationModeLock
                | o Sub SetASNavigationModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ASNavigationMode parameter. Role:Locks or unlocks
                | the ASNavigationMode parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetASNavigationModeLock(i_locked)

    def set_as_step_size_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetASStepSizeLock
                | o Sub SetASStepSizeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ASStepSize parameter. Role:Locks or unlocks the
                | ASStepSize parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetASStepSizeLock(i_locked)

    def set_ath_annotation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAthAnnotationLock
                | o Sub SetAthAnnotationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AthAnnotation parameter. Role:Locks or unlocks
                | the AthAnnotation parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetAthAnnotationLock(i_locked)

    def set_ath_disable_sim_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAthDisableSimLock
                | o Sub SetAthDisableSimLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AthDisableSim parameter. Role:Locks or unlocks
                | the AthDisableSim parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetAthDisableSimLock(i_locked)

    def set_ath_end_condition_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAthEndConditionLock
                | o Sub SetAthEndConditionLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AthEndCondition parameter. Role:Locks or unlocks
                | the AthEndCondition parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetAthEndConditionLock(i_locked)

    def set_ath_hyperlink_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAthHyperlinkLock
                | o Sub SetAthHyperlinkLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AthHyperlink parameter. Role:Locks or unlocks the
                | AthHyperlink parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetAthHyperlinkLock(i_locked)

    def set_ath_sel_agent_dlg_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAthSelAgentDlgLock
                | o Sub SetAthSelAgentDlgLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AthSelAgentDlg parameter. Role:Locks or unlocks
                | the AthSelAgentDlg parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetAthSelAgentDlgLock(i_locked)

    def set_ath_state_mgt_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAthStateMgtLock
                | o Sub SetAthStateMgtLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AthStateMgt parameter. Role:Locks or unlocks the
                | AthStateMgt parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetAthStateMgtLock(i_locked)

    def set_ath_text_msg_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAthTextMsgLock
                | o Sub SetAthTextMsgLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AthTextMsg parameter. Role:Locks or unlocks the
                | AthTextMsg parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetAthTextMsgLock(i_locked)

    def set_ath_viewpoint_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAthViewpointLock
                | o Sub SetAthViewpointLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AthViewpoint parameter. Role:Locks or unlocks the
                | AthViewpoint parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetAthViewpointLock(i_locked)

    def set_ps_cycle_time_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPSCycleTimeLock
                | o Sub SetPSCycleTimeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PSCycleTime parameter. Role:Locks or unlocks the
                | PSCycleTime parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetPSCycleTimeLock(i_locked)

    def set_ps_dyn_clash_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPSDynClashModeLock
                | o Sub SetPSDynClashModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PSDynClashMode parameter. Role:Locks or unlocks
                | the PSDynClashMode parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetPSDynClashModeLock(i_locked)

    def set_ps_graphic_sim_step_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPSGraphicSimStepLock
                | o Sub SetPSGraphicSimStepLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PSGraphicSimStep parameter. Role:Locks or unlocks
                | the PSGraphicSimStep parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetPSGraphicSimStepLock(i_locked)

    def set_ps_graphic_update_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPSGraphicUpdateLock
                | o Sub SetPSGraphicUpdateLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PSGraphicUpdate parameter. Role:Locks or unlocks
                | the PSGraphicUpdate parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetPSGraphicUpdateLock(i_locked)

    def set_pv_end_condition_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPVEndConditionLock
                | o Sub SetPVEndConditionLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PVEndCondition parameter. Role:Locks or unlocks
                | the PVEndCondition parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetPVEndConditionLock(i_locked)

    def set_pv_state_mgt_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPVStateMgtLock
                | o Sub SetPVStateMgtLock(    boolean    iLocked)
                | 
                | Locks or unlocks the PVStateMgt parameter. Role:Locks or unlocks the
                | PVStateMgt parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetPVStateMgtLock(i_locked)

    def set_run_annot_behavior_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunAnnotBehaviorLock
                | o Sub SetRunAnnotBehaviorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunAnnotBehavior parameter. Role:Locks or unlocks
                | the RunAnnotBehavior parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunAnnotBehaviorLock(i_locked)

    def set_run_annotation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunAnnotationLock
                | o Sub SetRunAnnotationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunAnnotation parameter. Role:Locks or unlocks
                | the RunAnnotation parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunAnnotationLock(i_locked)

    def set_run_end_condition_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunEndConditionLock
                | o Sub SetRunEndConditionLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunEndCondition parameter. Role:Locks or unlocks
                | the RunEndCondition parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunEndConditionLock(i_locked)

    def set_run_hlnk_behavior_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunHlnkBehaviorLock
                | o Sub SetRunHlnkBehaviorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunHlnkBehavior parameter. Role:Locks or unlocks
                | the RunHlnkBehavior parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunHlnkBehaviorLock(i_locked)

    def set_run_hyperlink_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunHyperlinkLock
                | o Sub SetRunHyperlinkLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunHyperlink parameter. Role:Locks or unlocks the
                | RunHyperlink parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunHyperlinkLock(i_locked)

    def set_run_pause_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunPauseLock
                | o Sub SetRunPauseLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunPause parameter. Role:Locks or unlocks the
                | RunPause parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunPauseLock(i_locked)

    def set_run_state_mgt_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunStateMgtLock
                | o Sub SetRunStateMgtLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunStateMgt parameter. Role:Locks or unlocks the
                | RunStateMgt parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunStateMgtLock(i_locked)

    def set_run_step_size_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunStepSizeLock
                | o Sub SetRunStepSizeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunStepSize parameter. Role:Locks or unlocks the
                | RunStepSize parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunStepSizeLock(i_locked)

    def set_run_text_behavior_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunTextBehaviorLock
                | o Sub SetRunTextBehaviorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunTextBehavior parameter. Role:Locks or unlocks
                | the RunTextBehavior parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunTextBehaviorLock(i_locked)

    def set_run_text_msg_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunTextMsgLock
                | o Sub SetRunTextMsgLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunTextMsg parameter. Role:Locks or unlocks the
                | RunTextMsg parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunTextMsgLock(i_locked)

    def set_run_viewpoint_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunViewpointLock
                | o Sub SetRunViewpointLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunViewpoint parameter. Role:Locks or unlocks the
                | RunViewpoint parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunViewpointLock(i_locked)

    def set_run_vis_behavior_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRunVisBehaviorLock
                | o Sub SetRunVisBehaviorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the RunVisBehavior parameter. Role:Locks or unlocks
                | the RunVisBehavior parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |      the locking operation to be performed
                |      Legal values:
                |      TRUE :   to lock the parameter.
                |      FALSE:   to unlock the parameter.


        """
        return self.simulationsettingatt.SetRunVisBehaviorLock(i_locked)

