#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class SimulationInitState:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface used to save/restore the simulation initial state.Role: This
                | interface is used to save/restore the initial state for       objects
                | in the current document.The following code snippet can be used to save
                | the simulation initial state        for all the objects in the current
                | document (all attributes). The         rootProduct can be any product
                | from the current document.

    """

    def __init__(self, catia):
        self.simulationinitstate = catia.SimulationInitState     

    def restore_initial_state(self, i_attr_mask):
        """
        .. note::
            CAA V5 Visual Basic help

                | RestoreInitialState
                | o Sub RestoreInitialState(    DNBSimInitStateAttr    iAttrMask)
                | 
                | Restores initial state attributes for all objects in the current
                | document   that have a saved initial state.


                | Parameters:
                | iAttrMask
                |    Indicates which initial state attributes will be restored
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The restore operation succeeded
                | E_FAIL 
                | The restore operation failed


        """
        return self.simulationinitstate.RestoreInitialState(i_attr_mask)

    def restore_initial_state_list(self, i_product_lists, i_attr_mask):
        """
        .. note::
            CAA V5 Visual Basic help

                | RestoreInitialStateList
                | o Sub RestoreInitialStateList(    CATSafeArrayVariant    iProductLists,
                |                                   DNBSimInitStateAttr    iAttrMask)
                | 
                | Restores initial state attributes for the objects in the given list.


                | Parameters:
                | iProductLists
                |    Indicates which objects will be used for the restore initial state operation
                |  
                |  iAttrMask
                |    Indicates which initial state attributes will be restored
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The restore operation succeeded
                | E_FAIL 
                | The restore operation failed


        """
        return self.simulationinitstate.RestoreInitialStateList(i_product_lists, i_attr_mask)

    def save_initial_state(self, i_attr_mask):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveInitialState
                | o Sub SaveInitialState(    DNBSimInitStateAttr    iAttrMask)
                | 
                | Saves initial state attributes for all objects in the current
                | document.


                | Parameters:
                | iAttrMask
                |    Indicates which initial state attributes will be saved
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The save operation succeeded
                | E_FAIL 
                | The save operation failed


        """
        return self.simulationinitstate.SaveInitialState(i_attr_mask)

    def save_initial_state_list(self, i_product_lists, i_attr_mask):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveInitialStateList
                | o Sub SaveInitialStateList(    CATSafeArrayVariant    iProductLists,
                |                                DNBSimInitStateAttr    iAttrMask)
                | 
                | Saves initial state attributes for the objects in the given list.


                | Parameters:
                | iProductLists
                |    Indicates which objects will be used for the save initial state operation
                |  
                |  iAttrMask
                |    Indicates which initial state attributes will be saved
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The save operation succeeded
                | E_FAIL 
                | The save operation failed


        """
        return self.simulationinitstate.SaveInitialStateList(i_product_lists, i_attr_mask)

