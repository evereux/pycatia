#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class StiDBItem:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the SmarTeam Integration Object, that is to say the
                | Document coming from SmarTeam database.Role: It retrieves SmarTeam
                | Document information. It is managed
                | byactivateLinkAnchor('StiEngine','','StiEngine').

    """

    def __init__(self, catia):
        self.stidbitem = catia.StiDBItem     

    def get_children(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetChildren
                | o Func GetChildren(    ) As StiDBChildren
                | 
                | Returns both all the Children of the CATIA Document -associated to the
                | CATIAStiDBItem-  and their corresponding Link Types with their Father
                | CATIA Document.  See also:
                | activateLinkAnchor('StiDBChildren','','StiDBChildren')  Returns:
                | This ouptut corresponds to the retrieved CATIAStiDBChildren from the
                | Father CATIAStiDBItem.    Example:    The following example returns in
                | ochildrenList both all the Children  and their Link Types with their
                | CATIAStiDBItem Father oStiDBItem.  Dim oStiDBItem As StiDBItem Dim
                | ochildrenList As StiDBChildren Set ochildrenList =
                | oStiDBItem.GetChildren Dim lChildrenNumber As long lChildrenNumber =
                | ochildrenList.Count For i = 1 To lChildrenNumber    Dim
                | oChildStiDBItem As StiDBItem    Set oChildStiDBItem =
                | ochildrenList.Item(i)    Dim sChildLinkType As CATBSTR
                | sChildLinkType = ochildrenList.LinkType(i) Next


                | Parameters:


        """
        return self.stidbitem.GetChildren()

    def get_document(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDocument
                | o Func GetDocument(    ) As Document
                | 
                | Returns the CATIA Document associated to the CATIAStiDBItem -the
                | SmarTeam Integration Object.  Returns:   This ouptut corresponds to
                | the retrieved CATIA Document.    Example:    The following example
                | returns in oDocument the CATIA Document corresponding to  the
                | CATIAStiDBItem oStiDBItem.  Dim oStiEngine As StiEngine Set oStiEngine
                | = CATIA.GetItem("CAIEngine") Dim oStiDBItem As StiDBItem Set
                | oStiDBItem =
                | oStiEngine.GetStiDBItemFromCATBSTR("E:\CATIAFiles\Engine.CATProduct")
                | Dim oDocument As Document Set oDocument = oStiDBItem.GetDocument


                | Parameters:


        """
        return self.stidbitem.GetDocument()

    def get_document_full_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDocumentFullPath
                | o Func GetDocumentFullPath(    ) As CATBSTR
                | 
                | Returns the Full Path of the CATIA Document associated to the
                | CATIAStiDBItem.  Returns:   This ouptut corresponds to the retrieved
                | Full Path of the CATIAStiDBItem.    Example:    The following example
                | returns in oFullPath the full path corresponding to  the
                | CATIAStiDBItem oStiDBItem.  Dim oStiDBItem As StiDBItem Dim oFullPath
                | As string oFullPath = oStiDBItem.GetDocumentFullPath


                | Parameters:


        """
        return self.stidbitem.GetDocumentFullPath()

    def is_cfo_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsCFOType
                | o Func IsCFOType(    ) As boolean
                | 
                | Returns if the CATIA Document -associated to the CATIAStiDBItem- is a
                | Component File or not.  Returns:   This ouptut corresponds to the
                | boolean 'oIsCFOType'. 'oIsCFOType' is True when the CATIAStiDBItem is
                | a Component File, False otherwise.    Example:    The following
                | example tests if the CATIAStiDBItem is a Component File.  Dim
                | oStiEngine As StiEngine Set oStiEngine = CATIA.GetItem("CAIEngine")
                | (...) Dim oIsCFOType As boolean oIsCFOType = oStiEngine.IsCFOType


                | Parameters:


        """
        return self.stidbitem.IsCFOType()

    def is_root(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsRoot
                | o Func IsRoot(    ) As boolean
                | 
                | Returns if the CATIA Document -associated to the CATIAStiDBItem- is a
                | Root. This method returns True if the Document is a Root, False
                | otherwise.  Returns:   This ouptut corresponds to the boolean
                | 'oIsRootCFO'.    Example:    The following example tests if the
                | CATIAStiDBItem is a Root component file.  Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine") (...) Dim oIsRootCFO As
                | boolean oIsRootCFO = oStiEngine.IsRoot


                | Parameters:


        """
        return self.stidbitem.IsRoot()

