#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class StiEngine:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the SmarTeam Integration Engine, that is to say the entry
                | point to the CATIA/SmarTeam Integration.It allows end user to realize
                | the following operations (also called StiEngine methods): connection
                | and disconnection to SmarTeam Integration, creation of SmarTeam
                | Integration Objects (StiDBItem) and management of their lifecycle
                | (Save, Check In, Check Out, Release, New Release, ...).Note that all
                | operations performed from this interface are the same as operations
                | available and launched from the   SmarTeam menu in CATIA.Warning: By
                | Default, these operations launched from this interface are
                | executedWithout Panel.

    """

    def __init__(self, catia):
        self.stiengine = catia.StiEngine     

    @property
    def integration_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IntegrationType
                | o Property IntegrationType(    ) As CATBSTR
                | 
                | Returns the Engine Integration Type. Warning: Do Not use this method.
                | It is Not implemented.


                | Parameters:


        """
        return self.stiengine.IntegrationType

    @property
    def use_graphical_ui(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseGraphicalUI
                | o Property UseGraphicalUI(    ) As boolean
                | 
                | Returns (gets) or sets the use of Graphical User Interface (GUI) in
                | order to display or not panels. This method allows programmer to
                | define if methods of this Interface Definition Language (IDL) will be
                | executed With or Without user interactions. Warning: By Default,
                | operations launched from this interface are executed Without GUI, that
                | is to say 'UseGraphicalUI' is set to 'False'. In practice, No GUI
                | means that treatments are executed  With Default Values because
                | additional parameters or options can not be set, as there is no user
                | interaction. If GUI are allowed, panels will be displayed. These
                | panels correspond to the usual ones displayed when the corresponding
                | functionnalities are launched from the SmarTeam Intagration menu. The
                | behaviour is so the same as in Interactive Mode. Note that the
                | Connection to SmarTeam Integration is totally Independent of the Value
                | of UseGraphicalUI.  Example:    The following example returns in the
                | boolean bIsActive the current value of this option -that is to say  if
                | we use or not GUI for StiEngine methods- and then sets it -if needed-
                | to 'True' -that corresponds to GUI operating mode.  Dim oStiEngine As
                | StiEngine Set oStiEngine = CATIA.GetItem("CAIEngine") Dim bIsActive As
                | boolean bIsActive = oStiEngine.UseGraphicalUI If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True End If


                | Parameters:


        """
        return self.stiengine.UseGraphicalUI

    def build_doc_db_item_from_smar_team_id(self, iobject_id, iclass_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | BuildDocDBItemFromSmarTeamID
                | o Func BuildDocDBItemFromSmarTeamID(    long    iobjectId,
                |                                         short    iclassId) As StiDBItem
                | 
                | Copys the SmarTeam object -and its children- to default Work
                | directory, opens it into CATIA session and returns the corresponding
                | CATIAStiDBItem. Note that this method is always executed Without any
                | GUI and is so totally independent of the value returned by
                | 'UseGraphicalUI'.


                | Parameters:
                | iobjectId
                |  This input corresponds to the Object ID of the required SmarTeam object.
                |  
                |  iclassId
                |  This input corresponds to the Class ID of the required SmarTeam object.
                |  
                | 
                |  Returns:
                |   This output corresponds to the retrieved CATIAStiDBItem.


                | Examples:
                | 
                | The following example retrieves a loaded document corresponding to a SmarTeam ID {Object ID, Class ID}.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim iobjectId As long
                | iobjectId = 963
                | Dim iclassId As short
                | iclassId = 57
                | Dim oStiDBItem As StiDBItem
                | Set oStiDBItem = oStiEngine.BuildDocDBItemFromSmarTeamID iobjectId, iclassId
                | 
                | 
                | 
        """
        return self.stiengine.BuildDocDBItemFromSmarTeamID(iobject_id, iclass_id)

    def build_file_db_item_from_smar_team_id(self, iobject_id, iclass_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | BuildFileDBItemFromSmarTeamID
                | o Func BuildFileDBItemFromSmarTeamID(    long    iobjectId,
                |                                          short    iclassId) As StiDBItem
                | 
                | Copys the SmarTeam object -and its children- to default Work directory
                | and returns the corresponding CATIAStiDBItem, Without opening the file
                | into CATIA session. Note that this method is always executed Without
                | any GUI and is so totally independent of the value returned by
                | 'UseGraphicalUI'.


                | Parameters:
                | iobjectId
                |  This input corresponds to the Object ID of the required SmarTeam object.
                |  
                |  iclassId
                |  This input corresponds to the Class ID of the required SmarTeam object.
                |  
                | 
                |  Returns:
                |   This output corresponds to the retrieved CATIAStiDBItem.


                | Examples:
                | 
                | The following example retrieves a loaded document corresponding to a SmarTeam ID {Object ID, Class ID}.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim iobjectId As long
                | iobjectId = 963
                | Dim iclassId As short
                | iclassId = 57
                | Dim oStiDBItem As StiDBItem
                | Set oStiDBItem = oStiEngine.BuildFileDBItemFromSmarTeamID iobjectId, iclassId
                | 
                | 
                | 
        """
        return self.stiengine.BuildFileDBItemFromSmarTeamID(iobject_id, iclass_id)

    def connect(self, i_user_login, i_user_password):
        """
        .. note::
            CAA V5 Visual Basic help

                | Connect
                | o Sub Connect(    CATBSTR    iUserLogin,
                |                   CATBSTR    iUserPassword)
                | 
                | Connects to SmarTeam Integration. This connection to SmarTeam
                | Integration is equivalent to launch in CATIA the command
                | SmarTeam/Connect. Note that this method is totally independent of the
                | value returned by 'UseGraphicalUI' and that the 'SmarTeam User Login'
                | panel (dedicated connection panel) may be displayed.


                | Parameters:
                | iUserLogin
                |  This input corresponds to the Login name of the end user, who wants to connect to SmarTeam Integration.
                |  
                |  iUserPassword
                |  This input corresponds to the associated Password of this end user.
                |  
                | Note that when 'iUserLogin' is EMPTY, the 'SmarTeam User Login' panel is displayed and the end user has to login himself.
                |  Note that 'iUserPassword' is taken into account if and only if 'iUserLogin' is NOT empty.


                | Examples:
                | 
                | ********** Connection With 'iUserLogin' & 'iUserPassword' **********
                | The following example connects end user to SmarTeam database on StiEngine oStiEngine Without displaying
                | 'SmarTeam User Login' panel. The User Login is "xxx" and his associated Password "yyy".
                | Note that User Login and Password should NOT be EMPTY. Otherwise the 'SmarTeam User Login' panel will be displayed.
                | If User Login or Password are NOT correct, the connection failed.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim iUserLogin As CATBSTR
                | iUserLogin = "xxx"
                | Dim iUserPassword As CATBSTR
                | iUserPassword = "yyy"
                | oStiEngine.Connect iUserLogin,iUserPassword
                | 
                | 
                | ********** Connection Without 'iUserLogin' & 'iUserPassword' **********
                | The following example connects end user to SmarTeam database on stiEngine oStiEngine With 'SmarTeam User Login' panel.
                | The end user will have to type his Login and his Password in the dedicated panel.
                | Note that if the User Login and his Password are specified, the 'SmarTeam User Login' panel will NOT be displayed.
                | If the end user only specifies his Login or if User Login and/or Password are NOT correct, the connection failed.
                | In these cases, the 'SmarTeam User Login' panel will NOT be displayed.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | oStiEngine.Connect "",""
                | 
                | 
                | 
        """
        return self.stiengine.Connect(i_user_login, i_user_password)

    def disconnect(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Disconnect
                | o Sub Disconnect(    )
                | 
                | Disconnects to SmarTeam Integration. This disconnection to SmarTeam
                | Integration is equivalent to launch in CATIA the command
                | SmarTeam/Disconnect. Note that this method is always executed Without
                | any GUI and is so totally independent of the value returned by
                | 'UseGraphicalUI'.  Example:    The following example disconnects end
                | user to SmarTeam database on StiEngine oStiEngine.  Dim oStiEngine As
                | StiEngine Set oStiEngine = CATIA.GetItem("CAIEngine")
                | oStiEngine.Connect "","" (...) oStiEngine.Disconnect


                | Parameters:


        """
        return self.stiengine.Disconnect()

    def get_smarteam_class_id(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSMARTEAMClassID
                | o Func GetSMARTEAMClassID(    StiDBItem    iStiDBItem) As short
                | 
                | Returns the Class Identifier of a SmarTeam Integration Object
                | CATIAStiDBItem -at least saved in SmarTeam.  Note that the Class
                | Identifier is unique for each Class defined in SmarTeam Data Model.
                | This data is so linked to the current DataBase, that is to say With
                | the SmarTeam Release (RXX). Note that this method is always executed
                | Without any GUI and is so totally independent of the value returned by
                | 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem.    
                |  
                | 
                |  Returns:
                |   This output corresponds to the retrieved Class Identifier of the CATIAStiDBItem.


                | Examples:
                | 
                | The following example returns in oClassId the Class Identifier of the CATIAStiDBItem oStiDBItem.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | ' Retrieve the Current Activated Product Document
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject(productDocument01)
                | Dim oClassId As short
                | oClassId = oStiEngine.GetSMARTEAMClassID(iStiDBItem)
                | 
                | 
                | 
        """
        return self.stiengine.GetSMARTEAMClassID(i_sti_db_item)

    def get_smarteam_object_id(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSMARTEAMObjectID
                | o Func GetSMARTEAMObjectID(    StiDBItem    iStiDBItem) As long
                | 
                | Returns the Object Identifier of a SmarTeam Integration Object
                | CATIAStiDBItem -at least saved in SmarTeam. This data is linked to the
                | current DataBase, that is to say to the SmarTeam Release (RXX). Note
                | that this method is always executed Without any GUI and is so totally
                | independent of the value returned by 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem.
                |  
                | 
                |  Returns:
                |   This output corresponds to the retrieved Object Identifier of the CATIAStiDBItem.


                | Examples:
                | 
                | The following example returns in oObjectId the Object Identifier of the CATIAStiDBItem oStiDBItem.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | ' Retrieve the Current Activated Product Document
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject(productDocument01)
                | Dim oObjectId As long
                | oObjectId = oStiEngine.GetSMARTEAMObjectID(iStiDBItem)
                | 
                | 
                | 
        """
        return self.stiengine.GetSMARTEAMObjectID(i_sti_db_item)

    def get_sti_db_item_from_any_object(self, i_any_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStiDBItemFromAnyObject
                | o Func GetStiDBItemFromAnyObject(    AnyObject    iAnyObject) As StiDBItem
                | 
                | Returns the SmarTeam Integration Object CATIAStiDBItem from an
                | AnyObject object. This method is useful to convert whatever CATIA V5
                | Object to a CATIAStiDBItem. Note that this method is always executed
                | Without any GUI and is so totally independent of the value returned by
                | 'UseGraphicalUI'.


                | Parameters:
                | iAnyObject
                |  This input corresponds to a CATIA V5 Object. It must be a Document, a Product, a Part or a DrawingSheet.
                |  
                | 
                |  Returns:
                |   This output corresponds to the retrieved CATIAStiDBItem.


                | Examples:
                | 
                | The following example returns in oStiDBItem the CATIAStiDBItem corresponding to the Document iDocument.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | ' Retrieve the Current Activated Product Document
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim oStiDBItem As StiDBItem
                | Set oStiDBItem = oStiEngine.GetStiDBItemFromAnyObject(productDocument01)
                | 
                | 
                | 
        """
        return self.stiengine.GetStiDBItemFromAnyObject(i_any_object)

    def get_sti_db_item_from_catbstr(self, i_full_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStiDBItemFromCATBSTR
                | o Func GetStiDBItemFromCATBSTR(    CATBSTR    iFullPath) As StiDBItem
                | 
                | Returns the SmarTeam Integration Object CATIAStiDBItem from a Full
                | Path. This method is useful to convert a path to a CATIAStiDBItem,
                | that is to say to create a SmarTeam Integration object. The programmer
                | is then able to manage its lifecycle (that is to say to Save, Check
                | In, Check Out, Release, New Release, ... it). Note that this method is
                | always executed Without any GUI and is so totally independent of the
                | value returned by 'UseGraphicalUI'.  See also: CATIAStiDBItem


                | Parameters:
                | iFullPath
                |  This input corresponds to the Full Path of the object to retrieve.
                |  
                | 
                |  Returns:
                |   This output corresponds to the retrieved CATIAStiDBItem.


                | Examples:
                | 
                | The following example returns in oStiDBItem the CATIAStiDBItem corresponding to the full path.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim iFullPath As CATBSTR
                | iFullPath = "E:\CATIAFiles\Engine.CATProduct"
                | Dim oStiDBItem As StiDBItem
                | Set oStiDBItem = oStiEngine.GetStiDBItemFromCATBSTR(iFullPath)
                | 
                | 
                | 
        """
        return self.stiengine.GetStiDBItemFromCATBSTR(i_full_path)

    def get_team_pdmurl(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTeamPDMURL
                | o Func GetTeamPDMURL(    StiDBItem    iStiDBItem) As CATBSTR
                | 
                | Returns the Team PDM URL of a CATIAStiDBItem. Note that the Team PDM
                | URL has the following syntax: TeamPDM://DBExtractor?CLASSID.EQ.www.
                | AND.OBJECTID.EQ.zzz.AND.Vers.EQ.1The only values which are modified
                | from a SmarTeam object to an other are the numbers corresponding to
                | the document Class ID (www) and Object ID (zzz).  Note that this
                | method is always executed With GUI. Indeed it returns a SmarTeam panel
                | displaying the TEAM PDM URL. It is so totally independent of the value
                | returned by 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem.
                |  
                | 
                |  Returns:
                |   This output corresponds to the retrieved Team PDM URL of the CATIAStiDBItem.


                | Examples:
                | 
                | The following example returns the Team PDM URL from a CATIAStiDBItem.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim iobjectId As long
                | iobjectId = 963
                | Dim iclassId As short
                | iclassId = 57
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.BuildFileDBItemFromSmarTeamID iobjectId, iclassId
                | Dim oTeamPDMURL As CATBSTR
                | oTeamPDMURL = oStiEngine.GetTeamPDMURL iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.GetTeamPDMURL(i_sti_db_item)

    def is_connected(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsConnected
                | o Func IsConnected(    ) As boolean
                | 
                | Returns if end user Is Connected to SmarTeam Integration (True) or not
                | (False). Note that this method is always executed Without any GUI and
                | is so totally independent of the value returned by 'UseGraphicalUI'.
                | Example:    The following example tests if end user is connected to
                | SmarTeam Integration on StiEngine oStiEngine. If end user is not
                | connected, this code sample allows her/him to connect to SmarTeam
                | Integration by displaying the 'SmarTeam User Login' panel.  Dim
                | oStiEngine As StiEngine Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim oIsConnected As boolean oIsConnected = oStiEngine.IsConnected If
                | Not oStiEngine.IsConnected() Then   oStiEngine.Connect End If


                | Parameters:


        """
        return self.stiengine.IsConnected()

    def life_cycle_check_in(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | LifeCycleCheckIn
                | o Sub LifeCycleCheckIn(    StiDBItem    iStiDBItem)
                | 
                | Checks the CATIAStiDBItem Into SmarTeam Check-In Vault. This
                | LifeCycleCheckIn operation is equivalent to launch in CATIA the
                | command SmarTeam/LifeCycle/CheckIn. 2 cases: either the document is
                | NEW (that is to say already saved in SmarTeam) or the document is
                | being Modified (Checked-Out) and is removed back into the vault. Note
                | that this method should be executed With GUI and is so totally
                | dependent of the value returned by 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem to Check-In.


                | Examples:
                | 
                | ********** LifeCycleCheckIn With GUI **********
                | The following example checks the current activated document -associated to the CATIAStiDBItem oStiDBItem and
                | already saved in SmarTeam -into the vault.
                | Note that in the dedicated panel, the end user should choose to activate the following options 'Keep Local File' or 'Keep Checked-Out'.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleCheckIn iStiDBItem
                | 
                | 
                | ********** LifeCycleCheckIn Without GUI **********
                | The following example checks the current activated document -associated to the CATIAStiDBItem oStiDBItem and
                | already saved in SmarTeam- into the vault.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If bIsActive Then
                | oStiEngine.UseGraphicalUI = False
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleCheckIn iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.LifeCycleCheckIn(i_sti_db_item)

    def life_cycle_check_out(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | LifeCycleCheckOut
                | o Sub LifeCycleCheckOut(    StiDBItem    iStiDBItem)
                | 
                | Checks Out Without Propagation the CATIAStiDBItem in SmarTeam. This
                | LifeCycleCheckOut operation is equivalent to launch in CATIA the
                | command SmarTeam/LifeCycle/CheckOut. Note that this method should be
                | executed With GUI and is so totally dependent of the value returned by
                | 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem to Check-Out.


                | Examples:
                | 
                | ********** LifeCycleCheckOut With GUI **********
                | The following example checks out from the vault the current activated document -associated to the CATIAStiDBItem oStiDBItem.
                | Note that in the dedicated panel, the end user is able to realize the following action 'Propagate Operation' to select which children she/he also wants to Check-Out.
                | She/he has also access to the SmarTeam panel option 'Do not get the file from vault'.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleCheckOut iStiDBItem
                | 
                | 
                | **********  LifeCycleCheckOut Without GUI **********
                | The following example Checks Out from the vault the current activated document -associated to the StiDBItem oStiDBItem.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If bIsActive Then
                | oStiEngine.UseGraphicalUI = False
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleCheckOut iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.LifeCycleCheckOut(i_sti_db_item)

    def life_cycle_check_out_propagated(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | LifeCycleCheckOutPropagated
                | o Sub LifeCycleCheckOutPropagated(    StiDBItem    iStiDBItem)
                | 
                | Checks Out With Propagation the CATIAStiDBItem in SMARTEAM. This
                | LifeCycleCheckOutPropagated operation is equivalent to launch in CATIA
                | the command SmarTeam/LifeCycle/CheckOut  and then to specify in the
                | associated SmarTeam panel 'Actions/Propagate Operation'. Note that
                | this method should be executed With GUI and is so totally dependent of
                | the value returned by 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem to be Checked-Out.


                | Examples:
                | 
                | **********  LifeCycleCheckOutPropagated With GUI **********
                | The following example Checks Out from the vault the current activated document -associated to the CATIAStiDBItem oStiDBItem
                | AND its children.
                | She/he has also access to the SmarTeam panel option 'Do not get the file from vault'.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleCheckOutPropagated iStiDBItem
                | 
                | 
                | **********  LifeCycleCheckOutPropagated Without GUI **********
                | The following example Checks Out from the vault the current activated document -associated to the StiDBItem oStiDBItem
                | AND its children.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If bIsActive Then
                | oStiEngine.UseGraphicalUI = False
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleCheckOutPropagated iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.LifeCycleCheckOutPropagated(i_sti_db_item)

    def life_cycle_new_release(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | LifeCycleNewRelease
                | o Sub LifeCycleNewRelease(    StiDBItem    iStiDBItem)
                | 
                | Enables a New Release Without Propagation for the CATIAStiDBItem in
                | SmarTeam. This LifeCycleNewRelease operation to SmarTeam Integration
                | is equivalent to launch in CATIA the command
                | SmarTeam/LifeCycle/NewRelease. Note that this method should be
                | executed With GUI and is so totally dependent of the value returned by
                | 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem to New Release.


                | Examples:
                | 
                | **********  LifeCycleNewRelease With GUI **********
                | The following example makes a new copy of a Released document associated to the CATIAStiDBItem oStiDBItem
                | that was moved into the Released vault. The resulting document is a new revision of the source document.
                | Note that in the dedicated panel,the end user is also able to realize the following action 'Propagate Operation' to select which children
                | she/he also wants to Check-Out. She/he has also access to the SmarTeam panel option 'Do not get the file from vault'.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleNewRelease iStiDBItem
                | 
                | 
                | **********  LifeCycleNewRelease Without GUI **********
                | The following example makes a new copy of a Released document associated to the CATIAStiDBItem oStiDBItem
                | that was moved into the Released vault. The resulting document is a new revision of the source document.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If bIsActive Then
                | oStiEngine.UseGraphicalUI = False
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleNewRelease iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.LifeCycleNewRelease(i_sti_db_item)

    def life_cycle_new_release_propagated(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | LifeCycleNewReleasePropagated
                | o Sub LifeCycleNewReleasePropagated(    StiDBItem    iStiDBItem)
                | 
                | Enables a NewRelease action With Propagation for the CATIAStiDBItem in
                | SmarTeam. This LifeCycleNewReleasePropagated operation is equivalent
                | to launch in CATIA the command SmarTeam/LifeCycle/NewRelease and then
                | to specify in the associated SmarTeam panel 'Propagate Operation'.
                | Note that this method should be executed With GUI and is so totally
                | dependent of the value returned by 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem to be New Released.


                | Examples:
                | 
                | ********** LifeCycleNewReleasePropagated With GUI **********
                | The following example makes a new copy of the Released document associated to the CATIAStiDBItem oStiDBItem and of its children.
                | This document was previously saved into the Released vault. The resulting document is a new revision of the source document.
                | She/he has also access to the SmarTeam panel option 'Do not get the file from vault'.
                | 
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleNewReleasePropagated iStiDBItem
                | 
                | 
                | ********** LifeCycleNewReleasePropagated Without GUI **********
                | The following example makes a new copy of a Released document associated to the CATIAStiDBItem oStiDBItem and of its children.
                | This document was previously saved into the Released vault. The resulting document is a new revision of the source document.
                | 
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If bIsActive Then
                | oStiEngine.UseGraphicalUI = False
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleNewReleasePropagated iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.LifeCycleNewReleasePropagated(i_sti_db_item)

    def life_cycle_release(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | LifeCycleRelease
                | o Sub LifeCycleRelease(    StiDBItem    iStiDBItem)
                | 
                | Releases the CATIAStiDBItem in SmarTeam Release Vault. This
                | LifeCycleRelease operation is equivalent to launch in CATIA the
                | command SmarTeam/LifeCycle/Release. 3 cases: either the document is
                | New (that is to say already saved in SmarTeam) or it is being Modified
                | (Checked-Out or New Released) and is removed back into the vault or it
                | is Checked-In and is moved from the Check-In vault to the Release one.
                | Note that this method should be executed With GUI and is so totally
                | dependent of the value returned by 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem to Released.


                | Examples:
                | 
                | ********** LifeCycleRelease With GUI **********
                | The following example releases the current activated document -associated to the CATIAStiDBItem oStiDBItem and
                | already saved in SmarTeam- into the vault.
                | Note that in the dedicated panel, the end user should choose to activate the following options 'Keep Local File' or 'Keep Checked-Out'.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True
                | End If
                | ' Retrieve the Current activated document
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleRelease iStiDBItem
                | 
                | 
                | ********** LifeCycleRelease Without GUI **********
                | The following example moves the current activated document -associated to the CATIAStiDBItem oStiDBItem and
                | already saved in SmarTeam -into the Released vault.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If bIsActive Then
                | oStiEngine.UseGraphicalUI = False
                | End If
                | ' Retrieve the Current activated document
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleRelease iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.LifeCycleRelease(i_sti_db_item)

    def life_cycle_undo_check_out(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | LifeCycleUndoCheckOut
                | o Sub LifeCycleUndoCheckOut(    StiDBItem    iStiDBItem)
                | 
                | Cancels Check-Out operation on the CATIAStiDBItem in SmarTeam. So the
                | programmer is able to retrieve the previous latest state (Checked-In
                | or Released) of the CATIAStiDBItem. This LifeCycleUndoCheckOut
                | operation is equivalent to launch in CATIA the command
                | SmarTeam/LifeCycle/UndoCheckOut. Note that this method should be
                | executed With GUI and is so totally dependent of the value returned by
                | 'UseGraphicalUI'.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem to be Undo Checked-Out.


                | Examples:
                | 
                | **********  LifeCycleUndoCheckOut With GUI **********
                | The following example retrieves a copy of a document associated to the CATIAStiDBItem oStiDBItem
                | in the previous latest state (Checked-In or Released).
                | A CATIA panel is firstly displayed to warn the end user that it is strongly recommanded to confirm the file deletion when asked.
                | If, the end user clicks "OK", a SmarTeam panel is then displayed "File '(...)\Work\CATPRD-XXXX.CATProduct' is referenced only by
                | Object 'CATPRD-XXXX RevX.X', and will be deleted. Do you want to delete this file?" The end user had better accept.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleUndoCheckOut iStiDBItem
                | 
                | 
                | **********  LifeCycleUndoCheckOut Without GUI **********
                | The following example cancels the Check-Out of the document associated to the CATIAStiDBItem oStiDBItem
                | in the previous latest state (Checked-In or Released).
                | By default, the Undo Check-Out operation is not propagated, i.e. available only for the current CATIAStiDBItem.
                | 
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If bIsActive Then
                | oStiEngine.UseGraphicalUI = False
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | oStiEngine.LifeCycleUndoCheckOut iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.LifeCycleUndoCheckOut(i_sti_db_item)

    def refresh_info(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RefreshInfo
                | o Sub RefreshInfo(    )
                | 
                | Refreshes Information concerning all CATIA Documents in session. This
                | RefreshInfo operation is equivalent to launch in CATIA the command
                | SmarTeam/Tools/Refresh. Note that this method is always executed
                | Without any GUI and is so totally independent of the value returned by
                | 'UseGraphicalUI'.  During this RefreshInfo operation, the following
                | steps are executed:  - Checking the document synchronization on disk,
                | - Updating internal info,   - Updating Read/Write status for valid
                | documents,   - Updating icons,   - Sending error or warning message
                | for not synchronized or removed documents if GUIs are activated.
                | Example:    The following example refreshs the CATIA session:  Dim
                | oStiEngine As StiEngine Set oStiEngine = CATIA.GetItem("CAIEngine")
                | oStiEngine.RefreshInfo


                | Parameters:


        """
        return self.stiengine.RefreshInfo()

    def save(self, i_sti_db_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | Save
                | o Sub Save(    StiDBItem    iStiDBItem)
                | 
                | Saves the CATIAStiDBItem in SmarTeam. This Save operation is
                | equivalent to launch in CATIA the command SmarTeam/Save. Note that
                | this method should be executed With GUI and is so totally dependent of
                | the value returned by 'UseGraphicalUI'. The SmarTeam Integration
                | Object (and its children) is(are) saved in the current Work -if NOT
                | already saved on disc.


                | Parameters:
                | iStiDBItem
                |  This input corresponds to the CATIAStiDBItem to save.


                | Examples:
                | 
                | ********** Save With GUI **********
                | Note that in the 'Projects Manager' panel, the end user should select the 'Project' in which she/he wants to save the corresponding file.
                | If she/he selects one, then she/he can activate the option 'Link To Projects' and then 'Secured By' and to finish 'Propagate security'.
                | She/he is also able to choose to activate the following option 'Add To Desktop'.
                | The following example saves in SmarTeam the CATIAStiDBItem oStiDBItem With GUI.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If Not bIsActive Then
                | oStiEngine.UseGraphicalUI = True
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject(productDocument01)
                | oStiEngine.Save iStiDBItem
                | 
                | 
                | ********** Save Without GUI **********
                | By Default, the SmarTeam Integration Object (and its children) is(are) saved in the current Work -if NOT already saved on disc,
                | NOT linked With any Project and NOT Added to Desktop.
                | The following example saves in SmarTeam the CATIAStiDBItem oStiDBItem Without GUI.
                | 
                | Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine")
                | Dim bIsActive As boolean
                | bIsActive = oStiEngine.UseGraphicalUI
                | If bIsActive Then
                | oStiEngine.UseGraphicalUI = False
                | End If
                | ' Retrieve the Current Activated Product
                | Dim productDocument01 As Document
                | Set productDocument01 = CATIA.ActiveDocument
                | ' Retrieve the StiDBItem from the Document
                | Dim iStiDBItem As StiDBItem
                | Set iStiDBItem = oStiEngine.GetStiDBItemFromAnyObject( productDocument01 )
                | ' Save the Product
                | oStiEngine.Save iStiDBItem
                | 
                | 
                | 
        """
        return self.stiengine.Save(i_sti_db_item)

