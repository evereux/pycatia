#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class PlugMapViewSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | DNBIAPlugMapViewSettingAtt are ...Do not use the
                | DNBIAPlugMapViewSettingAtt interface for such and such ClassReference,
                | Class#MethodReference, #InternalMethod...

    """

    def __init__(self, catia):
        self.plugmapviewsettingatt = catia.PlugMapViewSettingAtt     

    @property
    def logical_data_attr_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LogicalDataAttrList
                | o Property LogicalDataAttrList(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the LogicalDataAttrList parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.plugmapviewsettingatt.LogicalDataAttrList

    @property
    def termination_attr_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationAttrList
                | o Property TerminationAttrList(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the ConstraintsSimul parameter.  Ensure consistency
                | with the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.plugmapviewsettingatt.TerminationAttrList

    def addto_logical_data_attr_list(self, iparameter_name, i_refparam_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddtoLogicalDataAttrList
                | o Sub AddtoLogicalDataAttrList(    CATBSTR    iparameterName,
                |                                    CATBSTR    iRefparamName)
                | 
                | Method to add a parameter to the LogicalDataAttrList.


                | Parameters:


        """
        return self.plugmapviewsettingatt.AddtoLogicalDataAttrList(iparameter_name, i_refparam_name)

    def addto_termination_attr_list(self, iparameter_name, i_refparam_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddtoTerminationAttrList
                | o Sub AddtoTerminationAttrList(    CATBSTR    iparameterName,
                |                                    CATBSTR    iRefparamName)
                | 
                | Method to add a parameter to the TerminationAttrList.


                | Parameters:


        """
        return self.plugmapviewsettingatt.AddtoTerminationAttrList(iparameter_name, i_refparam_name)

    def get_logical_data_attr_list_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLogicalDataAttrListInfo
                | o Func GetLogicalDataAttrListInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the LogicalDataAttrList
                | parameter. Role:Retrieves the state of the LogicalDataAttrList
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.plugmapviewsettingatt.GetLogicalDataAttrListInfo(io_admin_level, io_locked)

    def get_termination_attr_list_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTerminationAttrListInfo
                | o Func GetTerminationAttrListInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TerminationAttrList
                | parameter. Role:Retrieves the state of the TerminationAttrList
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.plugmapviewsettingatt.GetTerminationAttrListInfo(io_admin_level, io_locked)

    def removefrom_logical_data_attr_list(self, iparameter_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovefromLogicalDataAttrList
                | o Sub RemovefromLogicalDataAttrList(    CATBSTR    iparameterName)
                | 
                | Method to Remove a parameter fron the LogicalDataAttrList.


                | Parameters:


        """
        return self.plugmapviewsettingatt.RemovefromLogicalDataAttrList(iparameter_name)

    def removefrom_termination_attr_list(self, iparameter_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovefromTerminationAttrList
                | o Sub RemovefromTerminationAttrList(    CATBSTR    iparameterName)
                | 
                | Method to Remove a parameter fron the TerminationAttrList.


                | Parameters:


        """
        return self.plugmapviewsettingatt.RemovefromTerminationAttrList(iparameter_name)

    def set_logical_data_attr_list_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLogicalDataAttrListLock
                | o Sub SetLogicalDataAttrListLock(    boolean    iLocked)
                | 
                | Locks or unlocks the LogicalDataAttrList parameter. Role:Locks or
                | unlocks the LogicalDataAttrList parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.plugmapviewsettingatt.SetLogicalDataAttrListLock(i_locked)

    def set_termination_attr_list_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTerminationAttrListLock
                | o Sub SetTerminationAttrListLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TerminationAttrList parameter. Role:Locks or
                | unlocks the TerminationAttrList parameter if it is possible in the
                | current administrative context. In user mode this method will always
                | return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.plugmapviewsettingatt.SetTerminationAttrListLock(i_locked)

