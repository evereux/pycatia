#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class EHMInsertionActPlugMapViewData:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access Plug Map view data associated to an Insertion
                | activity.Role: Component that implement
                | DNBIAEHMInsertionActPlugMapViewData is DNBEHMModel.

    """

    def __init__(self, catia):
        self.ehminsertionactplugmapviewdata = catia.EHMInsertionActPlugMapViewData     

    @property
    def connector_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorName
                | o Property ConnectorName(    ) As CATBSTR
                | 
                | Gets ConnectorName.


                | Parameters:
                | oConnectorName
                |      the Connector Name.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ConnectorName

    @property
    def connector_part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorPartNumber
                | o Property ConnectorPartNumber(    ) As CATBSTR
                | 
                | Gets Connector Part Number.


                | Parameters:
                | oConnectorPartNumber
                |      the Connector Part Number.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ConnectorPartNumber

    @property
    def connector_ref_designator(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorRefDesignator
                | o Property ConnectorRefDesignator(    ) As CATBSTR
                | 
                | Gets Connector Reference Designator.


                | Parameters:
                | oConnectorRefDesignator
                |      the Connector Reference Designator.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ConnectorRefDesignator

    @property
    def connector_sub_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorSubType
                | o Property ConnectorSubType(    ) As CATBSTR
                | 
                | Gets Connector Sub Type.


                | Parameters:
                | oConnectorSubType
                |      the Connector Sub Type.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ConnectorSubType

    @property
    def connector_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorType
                | o Property ConnectorType(    ) As CATBSTR
                | 
                | Gets Connector Type.


                | Parameters:
                | oConnectorType
                |      the Connector Type.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ConnectorType

    @property
    def contact_elec_barrel_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactElecBarrelDiameter
                | o Property ContactElecBarrelDiameter(    ) As double
                | 
                | Gets Contact Elec Barrel Diameter.


                | Parameters:
                | oContactElecBarrelDiameter
                |      the Contact Elec Barrel Diameter.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ContactElecBarrelDiameter

    @property
    def contact_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactName
                | o Property ContactName(    ) As CATBSTR
                | 
                | Gets Contact Name.


                | Parameters:
                | oContactName
                |      the Contact Name.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ContactName

    @property
    def contact_part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactPartNumber
                | o Property ContactPartNumber(    ) As CATBSTR
                | 
                | Gets Contact Part Number.


                | Parameters:
                | oContactPartNumber
                |      the Contact Part Number.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ContactPartNumber

    @property
    def contact_ref_designator(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactRefDesignator
                | o Property ContactRefDesignator(    ) As CATBSTR
                | 
                | Gets Contact Reference Designator.


                | Parameters:
                | oContactRefDesignator
                |      the Contact Ref Designator.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ContactRefDesignator

    @property
    def contact_sub_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactSubType
                | o Property ContactSubType(    ) As CATBSTR
                | 
                | Gets Contact Sub Type.


                | Parameters:
                | oContactSubType
                |      the Contact Sub Type.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ContactSubType

    @property
    def contact_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactType
                | o Property ContactType(    ) As CATBSTR
                | 
                | Gets Contact Type.


                | Parameters:
                | oContactType
                |      the Contact Type.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.ContactType

    @property
    def num_inserted_wires(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumInsertedWires
                | o Property NumInsertedWires(    ) As long
                | 
                | Gets the number of inserted wires.


                | Parameters:
                | NumInsertedWires
                |      the number of inserted wires.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the wire ID is set successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.NumInsertedWires

    @property
    def termination_id_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationIDNumber
                | o Property TerminationIDNumber(    ) As CATBSTR
                | 
                | Gets Termination ID Number.


                | Parameters:
                | oTerminationIDNumber.
                |      the Termination ID Number
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.TerminationIDNumber

    @property
    def termination_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationName
                | o Property TerminationName(    ) As CATBSTR
                | 
                | Gets Termination Name.


                | Parameters:
                | oTerminationName
                |      the Termination Name.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.TerminationName

    @property
    def termination_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationNumber
                | o Property TerminationNumber(    ) As CATBSTR
                | 
                | Gets Termination Number.


                | Parameters:
                | oTerminationNumber
                |      the Termination Number.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.TerminationNumber

    @property
    def termination_ref_designator(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationRefDesignator
                | o Property TerminationRefDesignator(    ) As CATBSTR
                | 
                | Gets Termination Reference Designator.


                | Parameters:
                | oTerminationRefDesignator
                |      the Termination Ref Designator.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.TerminationRefDesignator

    @property
    def termination_sub_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationSubType
                | o Property TerminationSubType(    ) As CATBSTR
                | 
                | Gets Termination Sub Type.


                | Parameters:
                | oTerminationSubType
                |      the Termination Sub Type.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.TerminationSubType

    @property
    def termination_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationType
                | o Property TerminationType(    ) As CATBSTR
                | 
                | Gets Termination Type.


                | Parameters:
                | oTerminationType
                |      the Termination Type.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.TerminationType

    @property
    def wire_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireColor
                | o Property WireColor(    ) As CATBSTR
                | 
                | Gets Wire Color.


                | Parameters:
                | oWireColor
                |      the Wire Color.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireColor

    @property
    def wire_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireDiameter
                | o Property WireDiameter(    ) As double
                | 
                | Gets Wire Diameter.


                | Parameters:
                | oWireDiameter
                |      the Wire Diameter.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireDiameter

    @property
    def wire_id(self, i_wire_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireID
                | o Property WireID(    long    iWireID) (Write Only)
                | 
                | Sets the index of wire.


                | Parameters:
                | iWireID
                |      Index of wire between 1 & NumInsertedWires associated to an Insertion Activity.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the wire ID is set successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireID

    @property
    def wire_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireLength
                | o Property WireLength(    ) As double
                | 
                | Gets Wire Length.


                | Parameters:
                | oWireLength
                |      the Wire Length.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireLength

    @property
    def wire_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireName
                | o Property WireName(    ) As CATBSTR
                | 
                | Gets Wire Name.


                | Parameters:
                | oWireName
                |      the Wire Name.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireName

    @property
    def wire_part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WirePartNumber
                | o Property WirePartNumber(    ) As CATBSTR
                | 
                | Gets Wire Part Number.


                | Parameters:
                | oWirePartNumber
                |      the Wire Part Number.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WirePartNumber

    @property
    def wire_ref_designator(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireRefDesignator
                | o Property WireRefDesignator(    ) As CATBSTR
                | 
                | Gets Wire Reference Designator.


                | Parameters:
                | oWireRefDesignator
                |      the Wire Ref Designator.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireRefDesignator

    @property
    def wire_separation_code(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireSeparationCode
                | o Property WireSeparationCode(    ) As CATBSTR
                | 
                | Gets Wire Separation Code.


                | Parameters:
                | oWireSeparationCode
                |      the Wire Separation Code.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireSeparationCode

    @property
    def wire_signal_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireSignalID
                | o Property WireSignalID(    ) As CATBSTR
                | 
                | Gets Wire Signal ID.


                | Parameters:
                | oWireSignalID
                |      the Wire Signal ID.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireSignalID

    @property
    def wire_sub_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireSubType
                | o Property WireSubType(    ) As CATBSTR
                | 
                | Gets Wire Sub Type.


                | Parameters:
                | oWireSubType
                |      the Wire Sub Type.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireSubType

    @property
    def wire_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireType
                | o Property WireType(    ) As CATBSTR
                | 
                | Gets Wire Type.


                | Parameters:
                | oWireType
                |      the Wire Type.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .


        """
        return self.ehminsertionactplugmapviewdata.WireType

