#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Task:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Task of a resource.Role: Task is the object used to
                | access and manage the attributes of the task.The following code
                | snippet can be used to obtain the Task from the Resource program
                | manager.Dim objResourceProgramManager As ResourceProgramManager   Dim
                | oTask As Task      objResourceProgramManager.GetTask  "RobotTask.1",
                | oTask

    """

    def __init__(self, catia):
        self.task = catia.Task     

    def get_name(self, o_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetName
                | o Sub GetName(    CATBSTR    oName)
                | 
                | Get the name of the Task


                | Parameters:
                | oName
                |    The user defined name of the Task.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The name of the task was corrrectly retrieved
                | E_FAIL 
                | The name of the task was not corrrectly retrieved


                | Examples:
                | 
                | The following example get the name of the task.
                | 
                | Dim objTask As Task
                | Dim strTaskName As String
                | ..
                | objTask.GetName strTaskName
                | 
                | 
                | 
                | 
        """
        return self.task.GetName(o_name)

    def get_resource(self, o_res):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetResource
                | o Sub GetResource(    Product    oRes)
                | 
                | Gets the Owning Resource


                | Parameters:
                | oRes
                |    The Owning Resource.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The owning resource was corrrectly retrieved
                | E_FAIL 
                | The owning resource was not corrrectly retrieved


                | Examples:
                | 
                | The following example retrieves the owning resource of the task.
                | 
                | Dim objTask As Task
                | Dim objRobot as Product
                | ..
                | objTask.GetResource objRobot
                | 
                | 
                | 
                | 
        """
        return self.task.GetResource(o_res)

    def set_name(self, i_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetName
                | o Sub SetName(    CATBSTR    iName)
                | 
                | Set the name of the task


                | Parameters:
                | iName
                |    The user defined name of the Task.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The name of the task was set corrrectly 
                | E_FAIL 
                | The name of the task was not set corrrectly


                | Examples:
                | 
                | The following example set the name of the task.
                | 
                | Dim objTask As Task
                | ..
                | objTask.SetName("RobotTask.2")
                | 
                | 
                | 
                | 
        """
        return self.task.SetName(i_name)

