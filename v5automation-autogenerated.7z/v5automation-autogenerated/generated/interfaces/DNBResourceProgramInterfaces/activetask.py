#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ActiveTask:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Active task of the resource in conjunction with a
                | particular activity.Role: Active Task is the object used to access and
                | manage the active task  set for all the resources assigned for the
                | activity.The following code snippet can be used to obtain the Active
                | Task from the activity.Dim objChildActivity As Activity   Dim
                | objActiveActivity As ActiveTask      Set objActiveActivity =
                | objChildActivity.GetTechnologicalObject("ActiveTask")

    """

    def __init__(self, catia):
        self.activetask = catia.ActiveTask     

    def get_active_task(self, i_resource, o_task):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetActiveTask
                | o Sub GetActiveTask(    AnyObject    iResource,
                |                         Task    oTask)
                | 
                | Retrieves the Active Task for an activity for a particular Resource.


                | Parameters:
                | iResource
                |    The resources.
                |  
                |  oTask
                |    The Active Task.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The status could be successfully queried from the activity
                | E_FAIL 
                | The query failed.


                | Examples:
                | 
                | The following example get the active task of the particular resource in the activity.
                | 
                | Dim oActiveAct As ActiveTask
                | Dim iResPrgMngr As ResourceProgramManager
                | Dim oTask As Task
                | ..
                | oActiveAct.GetActiveTask iResPrgMngr, oTask
                | 
                | 
                | 
                | 
        """
        return self.activetask.GetActiveTask(i_resource, o_task)

    def set_active_task(self, i_resource, i_task):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetActiveTask
                | o Sub SetActiveTask(    AnyObject    iResource,
                |                         Task    iTask)
                | 
                | Defines the Active Task for an activity for a particular Resource.


                | Parameters:
                | iResource
                |    The resources that owns the Task.
                |  
                |  iTask
                |    The Tasks to be made active.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The Active Task was corrrectly set
                | E_FAIL 
                | The Active Task was not corrrectly set


                | Examples:
                | 
                | The following example sets Active Task for an activity for a particular Resource.
                | 
                | Dim iActiveAct As ActiveTask
                | Dim iResPrgMngr As ResourceProgramManager
                | Dim iTask As Task
                | ..
                | oActiveAct.SetActiveTask iResPrgMngr, iTask
                | 
                | 
                | 
                | 
        """
        return self.activetask.SetActiveTask(i_resource, i_task)

