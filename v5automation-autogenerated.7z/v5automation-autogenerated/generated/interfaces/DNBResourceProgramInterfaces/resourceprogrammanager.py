#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class ResourceProgramManager:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Resource Program manager of a resource.Role: Resource
                | Program manager is the object used to access the tasks associated to
                | the resource.The following code snippet can be used to obtain the
                | Resource Program manager from the robot product.Dim
                | objResourceProgramManager As ResourceProgramManager   Dim objRobot as
                | Product      Set objResourceProgramManager =
                | objRobot.GetTechnologicalObject("ResourceProgramManager" )

    """

    def __init__(self, catia):
        self.resourceprogrammanager = catia.ResourceProgramManager     

    def get_all_tasks(self, o_task_list):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAllTasks
                | o Sub GetAllTasks(    CATSafeArrayVariant    oTaskList)
                | 
                | Retrieves all the Tasks corresponding to this Resource.


                | Parameters:
                | oTaskList
                |    The list of Tasks.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The Tasks were corrrectly retrieved
                | E_FAIL 
                | The Tasks were not corrrectly retrieved


                | Examples:
                | 
                | The following example retrieves the list of tasks on the resource.
                | 
                | Dim objResourceProgramManager As ResourceProgramManager
                | Dim TaskList(3) As Task
                | ..
                | objResourceProgramManager.GetAllTasks TaskList
                | 
                | 
                | 
                | 
        """
        return self.resourceprogrammanager.GetAllTasks(o_task_list)

    def get_task(self, i_task_name, o_task):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTask
                | o Sub GetTask(    CATBSTR    iTaskName,
                |                   Task    oTask)
                | 
                | Retrieves the Tasks corresponding to the given Task Name.


                | Parameters:
                | iTaskName
                |    The name of the Task.
                |  
                |  oTask
                |    The output Task.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The Task was corrrectly retrieved
                | E_FAIL 
                | The Task was not corrrectly retrieved


                | Examples:
                | 
                | The following example Retrieves the task corresponding the given task name.
                | 
                | Dim objResourceProgramManager As ResourceProgramManager
                | Dim oTask As Task
                | ..
                | objResourceProgramManager.GetTask  "RobotTask.1", oTask
                | 
                | 
                | 
                | 
        """
        return self.resourceprogrammanager.GetTask(i_task_name, o_task)

