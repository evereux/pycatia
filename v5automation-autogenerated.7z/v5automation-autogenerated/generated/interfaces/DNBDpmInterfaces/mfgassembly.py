#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class MfgAssembly:
    """
        .. note::
            CAA V5 Visual Basic help

                | This Interface represents a Manufacturing Assembly.Role: It gives
                | access to the C++ DNBIMfgAssembly interface methods Such as

    """

    def __init__(self, catia):
        self.mfgassembly = catia.MfgAssembly     

    @property
    def count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Count
                | o Property Count(    ) As long
                | 
                | Returns the number of assigned Parts (can be fetched via
                | activateLinkAnchor('','Item','Item')  ).  Example: This example
                | fetches the Number of assigned Parts of a Manufacturing Assembly  Dim
                | Number As Long Number = obj.Count


                | Parameters:


        """
        return self.mfgassembly.Count

    @property
    def ma_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MAName
                | o Property MAName(    ) As CATBSTR
                | 
                | Returns or sets the Name of the Manufacturing Assembly. Name of the
                | AST Manufacturing Assembly cannot be set/changed   Example: This
                | example fetches the Name of a Manufacturing Assembly  Dim myName As
                | String myName = obj.MAName  This example sets the Name of a
                | Manufacturing Assembly  Dim newName As String newName = "NewMAName"
                | obj.MAName = newName


                | Parameters:


        """
        return self.mfgassembly.MAName

    @property
    def ma_part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MAPartNumber
                | o Property MAPartNumber(    ) As CATBSTR
                | 
                | Returns or sets the Part Number of the Manufacturing Assembly. Part
                | Number of the AST MA cannot be set/changed  Example: This example
                | fetches the Part Number of a Manufacturing Assembly  Dim myPart As
                | String myPart = obj.MAPartNumber  This example sets the Part Number of
                | a Manufacturing Assembly  Dim newPartNbr As String newPartNbr =
                | "NewMAPartNumber" obj.MAPartNumber = newPartNbr


                | Parameters:


        """
        return self.mfgassembly.MAPartNumber

    @property
    def ma_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MAType
                | o Property MAType(    ) As DNBIAMfgAssemblyType
                | 
                | Returns the Type of the Manufacturing Assembly. It will be either a
                | manufacturingAssembly or a manufacturingKit defined in
                | activateLinkAnchor('DNBIAMfgAssemblyType','','DNBIAMfgAssemblyType')
                | Example: This example fetches the Type of a Manufacturing Assembly
                | Dim MAtype As String If obj.MAType = manufacturingAssembly Then
                | MAtype = "Manufacturing Assembly" Else   MAtype = "Manufacturing Kit"
                | End If


                | Parameters:


        """
        return self.mfgassembly.MAType

    def add_part(self, i_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPart
                | o Sub AddPart(    Item    iItem)
                | 
                | Assignes a part (Product, Resource or other MA/MK) to the
                | Manufacturing Assembly. No part can be assigned to AST MA


                | Parameters:
                | iItem
                |    The item to be assigned


                | Examples:
                | 
                | 
                | This example adds a product to the assigned Parts of a Manufacturing Assembly
                | 
                | Dim myProducts As PPRProducts
                | Set myProducts = DELMIA.ActiveDocument.PPRDocument.Products
                | Dim Part As Item
                | Set Part = myProducts.Item(2)
                | obj.AddPart(Part)
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassembly.AddPart(i_item)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As Item
                | 
                | Returns one assigned Part (Product, Resource or other MA/MK) of the
                | Manufacturing Assembly.


                | Parameters:
                | iIndex
                |    The index to the item to be returned
                |  
                | 
                |  Returns:
                |     The assigned item


                | Examples:
                | 
                | 
                | This example cycles through the list of assigned Parts of a Manufacturing Assembly
                | 
                | Dim j As Long
                | For j = 1 To obj.Count
                | Dim it As Item
                | Set it = obj.Item(j)
                | Dim ItemName As String
                | ItemName = it.Name
                | Next
                | 
                | 
                | 
                | 
        """
        return self.mfgassembly.Item(i_index)

    def remove_part(self, i_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePart
                | o Sub RemovePart(    Item    iItem)
                | 
                | Removes a part (Product, Resource or other MA/MK) from the
                | Manufacturing Assembly. No part can be removed from AST MA


                | Parameters:
                | iItem
                |    The item to be removed


                | Examples:
                | 
                | 
                | This example removes a product from the assigned Parts of a Manufacturing Assembly
                | 
                | Dim myProducts As PPRProducts
                | Set myProducts = DELMIA.ActiveDocument.PPRDocument.Products
                | Dim Part As Item
                | Set Part = myProducts.Item(2)
                | obj.RemovePart(Part)
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassembly.RemovePart(i_item)

