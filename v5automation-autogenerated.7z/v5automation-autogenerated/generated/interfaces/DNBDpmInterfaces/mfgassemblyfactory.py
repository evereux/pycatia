#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class MfgAssemblyFactory:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the factory to creates a manufacturing assembly.Role: It
                | gives access to the C++ DNBIMfgAssemblyFactory interface methods Such
                | as

    """

    def __init__(self, catia):
        self.mfgassemblyfactory = catia.MfgAssemblyFactory     

    def create_mfg_assembly(self, i_name_bstr, i_part_number_bstr, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateMfgAssembly
                | o Func CreateMfgAssembly(    CATBSTR    iNameBSTR,
                |                              CATBSTR    iPartNumberBSTR,
                |                              DNBIAMfgAssemblyType    iType) As Item
                | 
                | Creates a manufacturing assembly of given type "iType". This API
                | cannot be used to create a Manufacturing Assembly of type
                | AST(assemblySpecTree) or Manufacturing Output(manufacturingOutput)


                | Parameters:
                | iNameBSTR
                |    Name of the manufacturing assembly 
                |  
                |  iPartNumberBSTR
                |    Part-number of the manufacturing assembly 
                |  
                |  iType
                |    Type of the Manufacturing Assembly. If its value is "notSpecified" (or 4), the new assembly created will be of type "manufacturingAssembly"
                |  
                |  oMfgAssembly
                |    Handler of the Manufacturing Assembly created


                | Examples:
                | 
                | 
                | This example creates a Manufacturing Assembly of type "manufacturingKit" having MAName as "MKit1" and part-number as "Kit1"
                | 
                | Dim matype As DNBIAMfgAssemblyType
                | matype=manufacturingKit
                | Dim MA As MfgAssembly (Or Dim MA As item)
                | objMAfact.CreateMfgAssembly "MKit1","Kit1",matype,MA
                | where objMAfact is a instance of Automation Interface for Manufacturing Assembly as shown earlier
                | 
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassemblyfactory.CreateMfgAssembly(i_name_bstr, i_part_number_bstr, i_type)

    def get_number_of_mfg_assemblies(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNumberOfMfgAssemblies
                | o Func GetNumberOfMfgAssemblies(    ) As long
                | 
                | Get the number of Manufacturing Assemblies in MA Applicative Container


                | Parameters:
                | oNumOfMfgAssemblies
                |    number of Manufacturing Assemblies in MA Applicative Container


                | Examples:
                | 
                | 
                | For example getting the number of Manufacturing assemblies and displaying them in the Message Box.
                | 
                | Dim nbMfgAssemblies
                | Set nbMfgAssemblies =  objMAfact.GetNumberOfMfgAssemblies
                | MsgBox  nbMfgAssemblies
                | 
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassemblyfactory.GetNumberOfMfgAssemblies()

    def get_numberof_all_mfg_assy(self, i_type, o_num_of_mfg_assemblies):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNumberofALLMfgAssy
                | o Sub GetNumberofALLMfgAssy(    DNBIAMfgAssemblyType    iType,
                |                                 long    oNumOfMfgAssemblies)
                | 
                | Get the number of Manufacturing Assemblies(MA) of given type in MA
                | Applicative Container


                | Parameters:
                | iType
                |    Type of MA to be considered. If its value is "notSpecified" (or 4), all the MAs will be considered
                |  
                |  oNumOfMfgAssemblies
                |    Number of MAs found


                | Examples:
                | 
                | 
                | For example getting the number of MA of type "manufacturingKit" and displaying them in the Message Box.
                | 
                | Dim matype As DNBIAMfgAssemblyType
                | matype=manufacturingKit
                | Dim nbMfgAssemblies
                | objMAfact.GetNumberofALLMfgAssy matype,nbMfgAssemblies
                | MsgBox  nbMfgAssemblies
                | 
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassemblyfactory.GetNumberofALLMfgAssy(i_type, o_num_of_mfg_assemblies)

    def remove_mfg_assembly(self, i_mfg_assembly):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveMfgAssembly
                | o Sub RemoveMfgAssembly(    Item    iMfgAssembly)
                | 
                | Removes a given Manufacturing Assembly from the MA Applicative
                | Container. Please note that the AST MA cannot be removed


                | Parameters:
                | iMfgAssembly
                |    Manufacturing assembly to be removed or deleted


                | Examples:
                | 
                | 
                | For example deleting the first MA from the Applicative Container
                | 
                | Dim mfgAssy As Item
                | Set mfgAssy =  objMAfact.RetrieveMfgAssemblyAtIndex(1)
                | objMAfact.RemoveMfgAssembly mfgAssy
                | 
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassemblyfactory.RemoveMfgAssembly(i_mfg_assembly)

    def retrieve_mfg_assembly(self, i_name_bstr, o_mfg_assemblies, o_num_of_mfg_assemblies):
        """
        .. note::
            CAA V5 Visual Basic help

                | RetrieveMfgAssembly
                | o Sub RetrieveMfgAssembly(    CATBSTR    iNameBSTR,
                |                               CATSafeArrayVariant    oMfgAssemblies,
                |                               long    oNumOfMfgAssemblies)
                | 
                | Retrieve all the Manufacturing Assemblies of a given name.


                | Parameters:
                | iNameBSTR
                |    Name of the manufacturing assembly 
                |  
                |  oMfgAssemblies
                |    Array of the Items of the type "MfgAssembly". Array need to be allocated before passing.
                | 	In case, if the size allocated is found to be less than the actual number of Manufacturing Assemblies found, the number of MAs returned will be equal to size of array passed only
                |  
                |  oNumOfMfgAssemblies
                |    Number of MAs found with the given name. If the actual number of MAs found is greater than the size of the array passed, then value returned will be equal to the size of the array itself.


                | Examples:
                | 
                | 
                | For example retriving all the MAs with the name "MA_TYPE1" from the MA Applicative Container
                | 
                | Dim nbMfgAssemblies
                | Set nbMfgAssemblies =  objMAfact.GetNumberOfMfgAssemblies
                | Dim MAList() As AnyObject
                | ReDim MAList(nbMfgAssemblies-1)
                | Dim NbMA
                | objMAfact.RetrieveMfgAssembly "MA_TYPE1",MAList,NbMA
                | MsgBox  NbMA
                | 
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassemblyfactory.RetrieveMfgAssembly(i_name_bstr, o_mfg_assemblies, o_num_of_mfg_assemblies)

    def retrieve_mfg_assembly_at_index(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | RetrieveMfgAssemblyAtIndex
                | o Func RetrieveMfgAssemblyAtIndex(    CATVariant    iIndex) As Item
                | 
                | Retrieves a Manufacturing Assembly at the given index from the MA
                | Applicative Container.


                | Parameters:
                | iIndex
                |    Index 
                |  
                |  oItem
                |    Manufacturing Assembly at the above Index


                | Examples:
                | 
                | 
                | For example retriving all the MAs from the Applicative Container
                | 
                | Dim nbMfgAssemblies
                | Set nbMfgAssemblies =  objMAfact.GetNumberOfMfgAssemblies
                | For II = 0 to MyNum-1
                | Dim mfgAssy As Item
                | Set mfgAssy =  objMAfact.RetrieveMfgAssemblyAtIndex(II)
                | Next
                | 
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassemblyfactory.RetrieveMfgAssemblyAtIndex(i_index)

    def retrive_all_mfg_assy(self, i_type, o_all_m_as, o_num_of_mfg_assemblies):
        """
        .. note::
            CAA V5 Visual Basic help

                | RetriveALLMfgAssy
                | o Sub RetriveALLMfgAssy(    DNBIAMfgAssemblyType    iType,
                |                             CATSafeArrayVariant    oAllMAs,
                |                             long    oNumOfMfgAssemblies)
                | 
                | Retrieve all the Manufacturing Assemblies of a given type.


                | Parameters:
                | iType
                |    Type of manufacturing assemblies to be retrieved. If its value is "notSpecified" (or 4), all the manufacturing assemblies will be returned
                |  
                |  oMfgAssemblies
                |    Array of the Items of the type "MfgAssembly". Array need to be allocated before passing.
                | 	 In case, if the size allocated is found to be less than the actual number of Manufacturing Assemblies found, the number of MAs returned will be equal to size of array passed only
                |  
                |  oNumOfMfgAssemblies
                |    Number of MAs found. If the actual number of MAs found is greater than the size of the array passed, then value returned will be equal to the size of the array itself.


                | Examples:
                | 
                | 
                | For example: Code for retriving all the MAs of type "manufacturingKit" from the MA Applicative Container
                | 
                | Dim matype As DNBIAMfgAssemblyType
                | matype=manufacturingKit
                | Dim nbMfgAssemblies
                | objMAfact.GetNumberofALLMfgAssy matype,nbMfgAssemblies
                | Dim MAList() As AnyObject
                | ReDim MAList(nbMfgAssemblies)
                | Dim NbMA
                | objMAfact.RetriveALLMfgAssy matype,MAList,NbMA
                | 
                | 
                | 
                | 
                | 
                | 
        """
        return self.mfgassemblyfactory.RetriveALLMfgAssy(i_type, o_all_m_as, o_num_of_mfg_assemblies)

