#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DNBIAMfgAssemblyType:
    """
        .. note::
            CAA V5 Visual Basic help

                | This file defines the possible types of a Manufacturing Assembly.Role:
                | List the possible types of a Manufacturing Assembly namely

    """

    def __init__(self, catia):
        self.dnbiamfgassemblytype = catia.DNBIAMfgAssemblyType     

