#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintStatus:
    """
        .. note::
            CAA V5 Visual Basic help

                | Possible state of a constraint.Indicates whether a constraint is
                | satisfied or not, along with a diagnosis when not satisfied.

    """

    def __init__(self, catia):
        self.catconstraintstatus = catia.CatConstraintStatus     

