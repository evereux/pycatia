#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintRefType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Constraint reference type.In the PartDesign context, an element having
                | a Reference constraint will not move during the update.  The Assembly
                | context allows two behaviours : Either the element will not move, or
                | the element will move to the position where it was when  the Reference
                | type has been set to FixInSpace.ReferenceType. This enum lists
                | appropriate values to  set this property.

    """

    def __init__(self, catia):
        self.catconstraintreftype = catia.CatConstraintRefType     

