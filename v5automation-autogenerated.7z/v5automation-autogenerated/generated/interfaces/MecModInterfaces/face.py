#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Face:
    """
        .. note::
            CAA V5 Visual Basic help

                | 2-D boundary.Role:
                | ThisactivateLinkAnchor('Boundary','','Boundary')object may be, for
                | example, the lateral face of cylinder. You will create a Face object
                | using theactivateLinkAnchor('Shapes','GetBoundary','Shapes.GetBoundary
                | '),activateLinkAnchor('HybridShapes','GetBoundary','HybridShapes.GetBo
                | undary'),activateLinkAnchor('Sketches','GetBoundary','Sketches.GetBoun
                | dary')oractivateLinkAnchor('Selection','SelectElement2','Selection.Sel
                | ectElement2')method. Then, you pass it to the operator (such asactivat
                | eLinkAnchor('ShapeFactory','AddNewFaceFillet','ShapeFactory.AddNewFace
                | Fillet')).  The lifetime of a Face object is limited,
                | seeactivateLinkAnchor('Boundary','','Boundary').See also:activateLinkA
                | nchor('PlanarFace','','PlanarFace'),activateLinkAnchor('CylindricalFac
                | e','','CylindricalFace').

    """

    def __init__(self, catia):
        self.face = catia.Face     

