#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATAxisSystemAxisType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Specification of the axes of the coordinate system.

    """

    def __init__(self, catia):
        self.cataxissystemaxistype = catia.CATAxisSystemAxisType     

