#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatPartUpdateMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Update mode setting parameter's possible values.Role: This enum is
                | used in theactivateLinkAnchor('PartInfrastructureSettingAtt','','PartI
                | nfrastructureSettingAtt')interface.

    """

    def __init__(self, catia):
        self.catpartupdatemode = catia.CatPartUpdateMode     

