#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class OriginElements:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the part's 3D reference axis system.It allows an easy
                | access to 3D reference axis system of a Part object thru the three
                | planes XY, YZ, and ZX.SeeactivateLinkAnchor('Part','','Part')for
                | parent object.

    """

    def __init__(self, catia):
        self.originelements = catia.OriginElements     

    @property
    def plane_xy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PlaneXY
                | o Property PlaneXY(    ) As AnyObject
                | 
                | Returns the XY plane of the part 3D reference axis system. Example:The
                | following example returns in plnXY the XY plane of the partRoot part
                | from the partDoc part document:  Set partRoot = partDoc.Part Set plnXY
                | = partRoot.originElements.PlaneXY


                | Parameters:


        """
        return self.originelements.PlaneXY

    @property
    def plane_yz(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PlaneYZ
                | o Property PlaneYZ(    ) As AnyObject
                | 
                | Returns the YZ plane of the part 3D reference axis system. Example:The
                | following example returns in plnYZ the YZ plane of the partRoot part
                | from the partDoc part document:  Set partRoot = partDoc.Part Set plnYZ
                | = partRoot.originElements.PlaneYZ


                | Parameters:


        """
        return self.originelements.PlaneYZ

    @property
    def plane_zx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PlaneZX
                | o Property PlaneZX(    ) As AnyObject
                | 
                | Returns the ZX plane of the part 3D reference axis system. Example:The
                | following example returns in plnZX the ZX plane of the partRoot part
                | from the partDoc part document:  Set partRoot = partDoc.Part Set plnZX
                | = partRoot.originElements.PlaneZX


                | Parameters:


        """
        return self.originelements.PlaneZX

