#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Edge:
    """
        .. note::
            CAA V5 Visual Basic help

                | 1-D boundary.Role:
                | ThisactivateLinkAnchor('Boundary','','Boundary')object may be, for
                | example, the edge of a cylinder. You will create an Edge object using 
                | theactivateLinkAnchor('Shapes','GetBoundary','Shapes.GetBoundary'),act
                | ivateLinkAnchor('HybridShapes','GetBoundary','HybridShapes.GetBoundary
                | '),activateLinkAnchor('Sketches','GetBoundary','Sketches.GetBoundary')
                | oractivateLinkAnchor('Selection','SelectElement2','Selection.SelectEle
                | ment2')method. Then, you pass it to the operator (such asactivateLinkA
                | nchor('HybridShapeFactory','AddNewPointTangent','HybridShapeFactory.Ad
                | dNewPointTangent')).  The lifetime of an Edge object is limited,
                | seeactivateLinkAnchor('Boundary','','Boundary').See also:activateLinkA
                | nchor('TriDimFeatEdge','','TriDimFeatEdge'),activateLinkAnchor('Rectil
                | inearTriDimFeatEdge','','RectilinearTriDimFeatEdge'),activateLinkAncho
                | r('BiDimFeatEdge','','BiDimFeatEdge'),activateLinkAnchor('RectilinearB
                | iDimFeatEdge','','RectilinearBiDimFeatEdge'),activateLinkAnchor('MonoD
                | imFeatEdge','','MonoDimFeatEdge'),activateLinkAnchor('RectilinearMonoD
                | imFeatEdge','','RectilinearMonoDimFeatEdge').

    """

    def __init__(self, catia):
        self.edge = catia.Edge     

