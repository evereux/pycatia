#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintSide:
    """
        .. note::
            CAA V5 Visual Basic help

                | Constrained elements relative side.When two geometrical elements are
                | constrained, there is often a variety  of relative positions and
                | orientations of these elements that respect  the constraint. For
                | instance,    if a distance constraint is placed on two planes,  the
                | second plane can lie on both sides of first plane while maintaining
                | the requested distance: the constraint is respected, but  geometry
                | remains unresolved. Furthermore, even if the side is fixed, second
                | plane still can be oriented so that its normal points towards the
                | first plane or in the opposite direction, without breaking the
                | constraint.Managing such indetermination requires control over two
                | variables:This enum deals with possibles options for dealing with
                | theSidevariable (seeactivateLinkAnchor('CatConstraintOrientation','','
                | CatConstraintOrientation')for possibles options forOrientation).This
                | enum is based on the notion of characteristic vector. A characteristic
                | vector is a vector which is associated with a constrained element each
                | time it can be assimilated to a line or a plane. The vector represents
                | the direction of the line, or the direction normal to the  plane.

    """

    def __init__(self, catia):
        self.catconstraintside = catia.CatConstraintSide     

