#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Shapes:
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of the shapes making up a body.

    """

    def __init__(self, catia):
        self.shapes = catia.Shapes     

    def get_boundary(self, i_label):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundary
                | o Func GetBoundary(    CATBSTR    iLabel) As Boundary
                | 
                | Returns a boundary using its label.


                | Parameters:
                | iLabel
                |    Identification of the 
                | 
                |  activateLinkAnchor('Boundary','','Boundary')  object.   See 
                |  activateLinkAnchor('Reference','DisplayName','Reference.DisplayName') . 
                |    Returns:
                |   The retrieved boundary


        """
        return self.shapes.GetBoundary(i_label)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As Shape
                | 
                | Returns a shape using its index or its name from the Shapes
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the shape to retrieve from
                |    the collection of shapes.
                |    As a numerics, this index is the rank of the shape
                |    in the collection.
                |    The index of the first shape in the collection is 1, and
                |    the index of the last shape is 
                | 
                |  activateLinkAnchor('Collection','Count','Collection.Count') .   As a string, it is the name you assigned to the shape using
                |    the 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved shape


                | Examples:
                | 
                | 
                | This example retrieves in ThisShape the third shape,
                | and in ThatShape the shape named
                | MyShape in the shape collection of the active document,
                | supposed to be a part document.
                | 
                | Set ThisShape = CATIA.ActiveDocument.Shapes.Item(3)
                | Set ThatShape = CATIA.ActiveDocument.Shapes.Item("MyShape")
                | 
                | 
                | 
        """
        return self.shapes.Item(i_index)

