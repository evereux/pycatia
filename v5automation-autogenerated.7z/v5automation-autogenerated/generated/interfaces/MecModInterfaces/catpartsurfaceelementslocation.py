#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatPartSurfaceElementsLocation:
    """
        .. note::
            CAA V5 Visual Basic help

                | Wireframe and surface elements location parameter's possible
                | values.Role: This enum is used in theactivateLinkAnchor('PartInfrastru
                | ctureSettingAtt','','PartInfrastructureSettingAtt')interface.

    """

    def __init__(self, catia):
        self.catpartsurfaceelementslocation = catia.CatPartSurfaceElementsLocation     

