#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintRefAxis:
    """
        .. note::
            CAA V5 Visual Basic help

                | Constraint reference axis.Constraints that specify parallelism or
                | perpendicularity to an  axis in 3D are mono-element constraints. The
                | axis to which the  constraint applies is determined by the constraint
                | propertyReferenceAxis. This enum lists appropriate values to  set this
                | property.

    """

    def __init__(self, catia):
        self.catconstraintrefaxis = catia.CatConstraintRefAxis     

