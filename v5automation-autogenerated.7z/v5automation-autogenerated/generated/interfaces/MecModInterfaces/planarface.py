#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class PlanarFace:
    """
        .. note::
            CAA V5 Visual Basic help

                | 2-D boundary with a planar geometry.Role:
                | ThisactivateLinkAnchor('Boundary','','Boundary')object may be, for
                | example, the face of a cube. You will create a PlanarFace object using
                | theactivateLinkAnchor('Shapes','GetBoundary','Shapes.GetBoundary'),act
                | ivateLinkAnchor('HybridShapes','GetBoundary','HybridShapes.GetBoundary
                | '),activateLinkAnchor('Sketches','GetBoundary','Sketches.GetBoundary')
                | oractivateLinkAnchor('Selection','SelectElement2','Selection.SelectEle
                | ment2')method. Then, you pass it to the operator (such asactivateLinkA
                | nchor('ShapeFactory','AddNewDraft','ShapeFactory.AddNewDraft')).  The
                | lifetime of a PlanarFace object is limited,
                | seeactivateLinkAnchor('Boundary','','Boundary').

    """

    def __init__(self, catia):
        self.planarface = catia.PlanarFace     

    def get_first_axis(self, o_first_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFirstAxis
                | o Sub GetFirstAxis(    CATSafeArrayVariant    oFirstAxis)
                | 
                | Returns the planar face first axis


                | Parameters:
                | oFirstAxis[0]
                |    The X Coordinate of the planar face first axis
                |    
                |  oFirstAxis[1]
                |    The Y Coordinate of the planar face first axis
                |    
                |  oFirstAxis[2]
                |    The Z Coordinate of the planar face first axis


        """
        return self.planarface.GetFirstAxis(o_first_axis)

    def get_origin(self, o_origin):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrigin
                | o Sub GetOrigin(    CATSafeArrayVariant    oOrigin)
                | 
                | Returns the origin of the planar face.


                | Parameters:
                | oOrigin[0]
                |    The X Coordinate of the planar face origin
                |    
                |  oOrigin[1]
                |    The Y Coordinate of the planar face origin
                |    
                |  oOrigin[2]
                |    The Z Coordinate of the planar face origin


        """
        return self.planarface.GetOrigin(o_origin)

    def get_second_axis(self, o_second_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSecondAxis
                | o Sub GetSecondAxis(    CATSafeArrayVariant    oSecondAxis)
                | 
                | Returns the planar face second axis.


                | Parameters:
                | oSecondAxis[0]
                |     The X Coordinate of the planar face second axis
                |    
                |  oSecondAxis[1]
                |    The Y Coordinate of the planar face second axis
                |    
                |  oSecondAxis[2]
                |    The Z Coordinate of the planar face second axis


        """
        return self.planarface.GetSecondAxis(o_second_axis)

