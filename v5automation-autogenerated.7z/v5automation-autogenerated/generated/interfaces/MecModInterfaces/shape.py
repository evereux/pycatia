#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Shape:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Shape object.It is an abstract object which is not
                | intended to be created as such, from which all objects having a shape
                | representation derive.

    """

    def __init__(self, catia):
        self.shape = catia.Shape     

