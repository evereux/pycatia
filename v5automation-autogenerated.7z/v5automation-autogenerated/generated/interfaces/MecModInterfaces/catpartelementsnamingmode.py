#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatPartElementsNamingMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Naming mode parameter's possible values.Role: This enumeration is used
                | in theactivateLinkAnchor('PartInfrastructureSettingAtt','','PartInfras
                | tructureSettingAtt')interface.

    """

    def __init__(self, catia):
        self.catpartelementsnamingmode = catia.CatPartElementsNamingMode     

