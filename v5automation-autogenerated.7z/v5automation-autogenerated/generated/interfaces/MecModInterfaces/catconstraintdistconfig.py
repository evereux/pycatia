#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintDistConfig:
    """
        .. note::
            CAA V5 Visual Basic help

                | Special constraint configurations for distance constraints.When
                | distance constraints involve lines or cylinders, the constrained
                | elements  can  rotate around the line on which the distance is
                | measured, while still respecting the distance constraint. This degree
                | of  freedom is in most cases not wanted.This enum is used to further
                | qualify the distance constraint, so that  such  degree of freedom can
                | be eliminated in case of need, without  requiring another distinct
                | constraint to be defined.

    """

    def __init__(self, catia):
        self.catconstraintdistconfig = catia.CatConstraintDistConfig     

