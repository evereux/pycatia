#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FixTogethers:
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all the FixTogether objects contained in the product.

    """

    def __init__(self, catia):
        self.fixtogethers = catia.FixTogethers     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As FixTogether
                | 
                | Creates a new FixTogether and adds it to the FixTogethers collection.
                | Returns:  The created FixTogether  Example: The following example
                | creates a FixTogether newFixTogether in the FixTogether collection.
                | Set newFixTogether = fixTogethers.Add


                | Parameters:


        """
        return self.fixtogethers.Add()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(    CATVariant    iIndex) As FixTogether
                | 
                | Returns a FixTogether using its index or its name from the
                | FixTogethers collection.


                | Parameters:
                | iIndex
                |    The index or the name of the FixTogether to retrieve from
                |    the collection of FixTogether.
                |    As a numerics, this index is the rank of the FixTogether
                |    in the collection.
                |    The index of the first FixTogether in the collection is 1, and
                |    the index of the last FixTogether is Count.
                |    As a string, it is the name you assigned to the FixTogether using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved FixTogether


                | Examples:
                | 
                | 
                | This example retrieves in thisFixTogether the fifth FixTogether
                | in the collection and in thatFixTogether the FixTogether
                | named MyFixTogether in the FixTogether collection of the product
                | product.
                | 
                | Set fixTogetherColl = product.FixTogethers
                | Set thisFixTogether = fixTogetherColl.Item(5)
                | Set thatFixTogether = fixTogetherColl.Item("MyFixTogether")
                | 
                | 
                | 
        """
        return self.fixtogethers.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    CATVariant    iIndex)
                | 
                | Removes a FixTogether from the FixTogethers collection.


                | Parameters:
                | iIndex
                |    The index or the name of the FixTogether to remove from the FixTogethers
                |    collection.
                |    As a numerics, this index is the rank of the FixTogether
                |    in the collection.
                |    The index of the first FixTogether in the collection is 1, and
                |    the index of the last FixTogether is Count.
                |    As a string, it is the name you assigned to the FixTogether using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property.


                | Examples:
                | 
                | 
                | This example removes the last FixTogether in the collection.
                | 
                | fixTogetherColl.Remove(fixTogetherColl.Count)
                | 
                | 
        """
        return self.fixtogethers.Remove(i_index)

