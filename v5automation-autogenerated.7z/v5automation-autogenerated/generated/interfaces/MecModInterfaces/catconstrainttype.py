#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintType:
    """
        .. note::
            CAA V5 Visual Basic help

                | Possible types of constraints.According to their type, constraint may
                | exist in 3D space (at the part  level), in 2D space (at the sketch
                | level), or both.The constraint type also determines the number of
                | elements (from  1 to 3) that are necessary to define the constraint,
                | plus the  type of those elements. Also, the constraint type defines
                | the  valid combinations between those types, and the associated
                | semantics.These combinations plus usage notes are detailed in tables
                | on a per-type basis below.

    """

    def __init__(self, catia):
        self.catconstrainttype = catia.CatConstraintType     

