#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class Factory:
    """
        .. note::
            CAA V5 Visual Basic help

                | Abstract object gathering behaviours of all objects being a factory.

    """

    def __init__(self, catia):
        self.factory = catia.Factory     

