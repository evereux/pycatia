#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintMode:
    """
        .. note::
            CAA V5 Visual Basic help

                | Inconstraintmode, the value assigned to the constraint  drives the
                | actual  position of the constrained geometry.Inmeasurementmode, the
                | constraint value only reflects what  can be observed from the actual
                | position of the constrained geometry.

    """

    def __init__(self, catia):
        self.catconstraintmode = catia.CatConstraintMode     

