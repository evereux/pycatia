#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class NotWireBoundaryMonoDimFeatVertex:
    """
        .. note::
            CAA V5 Visual Basic help

                | 0-D boundary belonging to a feature whose topological result is one
                | dimensional, the boundary not beeing the extremity of the
                | feature.Role:  ThisactivateLinkAnchor('Boundary','','Boundary')object
                | may be, for example, in a part containing a Sketch which is made up of
                | a circle arc and a spline, the vertex between the circle arc and the
                | spline.  You will create a NotWireBoundaryMonoDimFeatVertex object
                | using theactivateLinkAnchor('Shapes','GetBoundary','Shapes.GetBoundary
                | '),activateLinkAnchor('HybridShapes','GetBoundary','HybridShapes.GetBo
                | undary'),activateLinkAnchor('Sketches','GetBoundary','Sketches.GetBoun
                | dary')oractivateLinkAnchor('Selection','SelectElement2','Selection.Sel
                | ectElement2')method. Then, you pass it to the operator.  The lifetime
                | of a NotWireBoundaryMonoDimFeatVertex object is limited,
                | seeactivateLinkAnchor('Boundary','','Boundary').

    """

    def __init__(self, catia):
        self.notwireboundarymonodimfeatvertex = catia.NotWireBoundaryMonoDimFeatVertex     

