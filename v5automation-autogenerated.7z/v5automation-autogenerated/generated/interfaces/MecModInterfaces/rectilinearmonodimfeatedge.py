#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class RectilinearMonoDimFeatEdge:
    """
        .. note::
            CAA V5 Visual Basic help

                | 1-D boundary belonging to a feature whose topological result is one
                | dimensional, the boundary having a rectilinear geometry.Role:
                | ThisactivateLinkAnchor('Boundary','','Boundary')object may be, for
                | example, in a part containing a Sketch which is made up of a line
                | segment and a spline, the line segment.  You will create a
                | RectilinearMonoDimFeatEdge object using theactivateLinkAnchor('Shapes'
                | ,'GetBoundary','Shapes.GetBoundary'),activateLinkAnchor('HybridShapes'
                | ,'GetBoundary','HybridShapes.GetBoundary'),activateLinkAnchor('Sketche
                | s','GetBoundary','Sketches.GetBoundary')oractivateLinkAnchor('Selectio
                | n','SelectElement2','Selection.SelectElement2')method. Then, you pass
                | it to the operator (such
                | asactivateLinkAnchor('Hole','SetDirection','Hole.SetDirection')).  The
                | lifetime of a RectilinearMonoDimFeatEdge object is limited,
                | seeactivateLinkAnchor('Boundary','','Boundary').

    """

    def __init__(self, catia):
        self.rectilinearmonodimfeatedge = catia.RectilinearMonoDimFeatEdge     

    def get_direction(self, o_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDirection
                | o Sub GetDirection(    CATSafeArrayVariant    oDirection)
                | 
                | Returns the direction of the rectilinear edge


                | Parameters:
                | oDirection[0]
                |    The X Coordinate of the direction
                |    
                |  oDirection[1]
                |    The Y Coordinate of the direction
                |    
                |  oDirection[2]
                |    The Z Coordinate of the direction


        """
        return self.rectilinearmonodimfeatedge.GetDirection(o_direction)

    def get_origin(self, o_origin):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrigin
                | o Sub GetOrigin(    CATSafeArrayVariant    oOrigin)
                | 
                | Returns the origin of the the rectilinear edge.


                | Parameters:
                | oOrigin[0]
                |    The X Coordinate of the rectilinear edge origin
                |    
                |  oOrigin[1]
                |    The Y Coordinate of the rectilinear edge origin
                |    
                |  oOrigin[2]
                |    The Z Coordinate of the rectilinear edge origin


        """
        return self.rectilinearmonodimfeatedge.GetOrigin(o_origin)

