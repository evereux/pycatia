#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintDistDirection:
    """
        .. note::
            CAA V5 Visual Basic help

                | Constraint distance direction.DistanceDirection. This enum lists the
                | appropriate values to  set this property.

    """

    def __init__(self, catia):
        self.catconstraintdistdirection = catia.CatConstraintDistDirection     

