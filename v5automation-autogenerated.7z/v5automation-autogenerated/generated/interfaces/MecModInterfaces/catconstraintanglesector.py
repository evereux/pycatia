#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CatConstraintAngleSector:
    """
        .. note::
            CAA V5 Visual Basic help

                | Special constraint property for angle constraints.It only applies to
                | the constraints of type Angle or PlanarAngle.The geometric elements of
                | an angle constraint (e.g. : 2 lines or 2 planes) divide the sketch or
                | the space in 4 regions which are called angular  sectors, numbered
                | from 0 to 3. By default, the constraint is created in the sector
                | number 0. One angular sector corresponds exactly to particular values
                | of the Dimension.Value, the Side and the Orientation. When changing
                | the angular sector, the Dimension.Value, Side and Orientation are also
                | modified.          1  / 0 ---/---   2/   3 By default, the constraint
                | is created in the sector number 0. One angle sector corresponds
                | exactly to particular values  of the Dimension.Value, the Side and the
                | Orientation. When changing the angle sector, the Dimension.Value,
                | Side and Orientation are also modified.

    """

    def __init__(self, catia):
        self.catconstraintanglesector = catia.CatConstraintAngleSector     

