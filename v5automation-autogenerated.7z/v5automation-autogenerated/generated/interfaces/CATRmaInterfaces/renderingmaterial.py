#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class RenderingMaterial:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an RenderingMaterial object.This object is used to manage
                | the Rendering properties of a material.

    """

    def __init__(self, catia):
        self.renderingmaterial = catia.RenderingMaterial     

    @property
    def adaptive_coeff(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AdaptiveCoeff
                | o Property AdaptiveCoeff(    ) As short
                | 
                | Returns or sets the adaptive coeffcient of a material. Adaptive
                | coeffcient value is between 1 an 8.


                | Parameters:


        """
        return self.renderingmaterial.AdaptiveCoeff

    @property
    def ambient_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AmbientCoefficient
                | o Property AmbientCoefficient(    ) As double
                | 
                | Returns or sets the ambient coefficient of a material. Ambient
                | coefficient value is between 0 to 1.


                | Parameters:


        """
        return self.renderingmaterial.AmbientCoefficient

    @property
    def bump(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Bump
                | o Property Bump(    ) As double
                | 
                | Returns or sets the texture bump. Image texture bump value is between
                | -10 to 10.


                | Parameters:


        """
        return self.renderingmaterial.Bump

    @property
    def chessboard_joint_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ChessboardJointHeight
                | o Property ChessboardJointHeight(    ) As double
                | 
                | Returns or sets the height of the join of a chessboard texture. Height
                | value is between 0 to 100. N.B. Parameter use for CHESSBOARD texture
                | type only.


                | Parameters:


        """
        return self.renderingmaterial.ChessboardJointHeight

    @property
    def chessboard_joint_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ChessboardJointWidth
                | o Property ChessboardJointWidth(    ) As double
                | 
                | Returns or sets the width of the join of a chessboard texture. Width
                | value is between 0 to 100. N.B. Parameter use for CHESSBOARD texture
                | type only.


                | Parameters:


        """
        return self.renderingmaterial.ChessboardJointWidth

    @property
    def chessboard_offset(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ChessboardOffset
                | o Property ChessboardOffset(    ) As double
                | 
                | Returns or sets the offset coefficient for a chessboard texture. It
                | indicates the offset between each line of the chessboard texture.
                | Offset value is between 0 to 0.5. N.B. Parameter use for CHESSBOARD
                | texture type only.


                | Parameters:


        """
        return self.renderingmaterial.ChessboardOffset

    @property
    def chessboard_tile_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ChessboardTileHeight
                | o Property ChessboardTileHeight(    ) As double
                | 
                | Returns or sets the height of the tile of a chessboard texture. Height
                | value is between 0 to 100. N.B. Parameter use for CHESSBOARD texture
                | type only.


                | Parameters:


        """
        return self.renderingmaterial.ChessboardTileHeight

    @property
    def chessboard_tile_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ChessboardTileWidth
                | o Property ChessboardTileWidth(    ) As double
                | 
                | Returns or sets the width of the tile of a chessboard texture. Width
                | value is between 0 to 100. N.B. Parameter use for CHESSBOARD texture
                | type only.


                | Parameters:


        """
        return self.renderingmaterial.ChessboardTileWidth

    @property
    def color_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ColorNumber
                | o Property ColorNumber(    ) As short
                | 
                | Returns or sets the 3d texture color number. Possible color numbers
                | are:  - From 2 to 5 for marble, vein and chessboard texture types  -
                | From 1 to 5 for alternate vein texture types N.B. Parameter useless
                | for ROCK textures (color number is fixed) and IMAGE texture


                | Parameters:


        """
        return self.renderingmaterial.ColorNumber

    @property
    def diffuse_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DiffuseCoefficient
                | o Property DiffuseCoefficient(    ) As double
                | 
                | Returns or sets the diffuse coefficient of a material. Diffuse
                | coefficient value is between 0 to 1.


                | Parameters:


        """
        return self.renderingmaterial.DiffuseCoefficient

    @property
    def environment_image(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EnvironmentImage
                | o Property EnvironmentImage(    ) As CATBSTR
                | 
                | Returns or sets the environment image pathname of a material.


                | Parameters:


        """
        return self.renderingmaterial.EnvironmentImage

    @property
    def flip_u(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlipU
                | o Property FlipU(    ) As boolean
                | 
                | Returns or sets the texture flip status along U axis. N.B. Parameter
                | use for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.FlipU

    @property
    def flip_v(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlipV
                | o Property FlipV(    ) As boolean
                | 
                | Returns or sets the texture flip status along V axis. N.B. Parameter
                | use for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.FlipV

    @property
    def mapping_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MappingType
                | o Property MappingType(    ) As short
                | 
                | Returns or sets the mapping type of a material.  Possible types are:
                | 0: Planar mapping   1: Spherical mapping   2: Cylindrical mapping   3:
                | Cubical mapping   4: Auto mapping   5: Manual mapping


                | Parameters:


        """
        return self.renderingmaterial.MappingType

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property Orientation(    ) As double
                | 
                | Returns or sets the texture orientation. Orientation value should be
                | between -360 to +360 degrees N.B. Parameter use for IMAGE texture type
                | only


                | Parameters:


        """
        return self.renderingmaterial.Orientation

    @property
    def position_u(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PositionU
                | o Property PositionU(    ) As double
                | 
                | Returns or sets the texture position along U axis. N.B. Parameter use
                | for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.PositionU

    @property
    def position_v(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PositionV
                | o Property PositionV(    ) As double
                | 
                | Returns or sets the texture position along V axis. N.B. Parameter use
                | for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.PositionV

    @property
    def preview_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PreviewSize
                | o Property PreviewSize(    ) As double
                | 
                | Returns or sets the preview size of a material. Preview size value is
                | 0.1mm minimum.


                | Parameters:


        """
        return self.renderingmaterial.PreviewSize

    @property
    def reflection_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReflectionHeight
                | o Property ReflectionHeight(    ) As double
                | 
                | Returns or sets the non-linear reflection height of a material. Non-
                | linear reflection height value is between 0 to 1. N.B. Parameter use
                | for CUSTOM reflection mode only.


                | Parameters:


        """
        return self.renderingmaterial.ReflectionHeight

    @property
    def reflection_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReflectionLength
                | o Property ReflectionLength(    ) As double
                | 
                | Returns or sets the non-linear reflection length of a material. Non-
                | linear reflection length value is between 0 to 1. N.B. Parameter use
                | for CUSTOM reflection mode only.


                | Parameters:


        """
        return self.renderingmaterial.ReflectionLength

    @property
    def reflection_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReflectionMode
                | o Property ReflectionMode(    ) As short
                | 
                | Returns or sets the non-linear reflection mode of a material.
                | Possible reflection mode values are:     0: CHROMA reflection mode
                | 1: PAINT reflection mode   2: MATTE_METAL reflection mode   3:
                | BRIGHT_PLASTIC reflection mode   4: CUSTOM reflection mode


                | Parameters:


        """
        return self.renderingmaterial.ReflectionMode

    @property
    def reflectivity_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReflectivityCoefficient
                | o Property ReflectivityCoefficient(    ) As double
                | 
                | Returns or sets the reflectivity coefficient of a material.
                | Reflectivity coefficient value is between 0 to 1.


                | Parameters:


        """
        return self.renderingmaterial.ReflectivityCoefficient

    @property
    def refraction_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RefractionCoefficient
                | o Property RefractionCoefficient(    ) As double
                | 
                | Returns or sets the refraction coefficient of a material. Refraction
                | coefficient value is between 1 to 2.


                | Parameters:


        """
        return self.renderingmaterial.RefractionCoefficient

    @property
    def repeat_u(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RepeatU
                | o Property RepeatU(    ) As boolean
                | 
                | Returns or sets the texture repeat status along U axis. N.B. Parameter
                | use for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.RepeatU

    @property
    def repeat_v(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RepeatV
                | o Property RepeatV(    ) As boolean
                | 
                | Returns or sets the texture repeat status along V axis. N.B. Parameter
                | use for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.RepeatV

    @property
    def scale_u(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ScaleU
                | o Property ScaleU(    ) As double
                | 
                | Returns or sets the texture scale along U axis. U scale value is
                | between 0 to 100. N.B. Parameter use for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.ScaleU

    @property
    def scale_v(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ScaleV
                | o Property ScaleV(    ) As double
                | 
                | Returns or sets the texture scale along V axis. V scale value is
                | between 0 to 100. N.B. Parameter use for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.ScaleV

    @property
    def specular_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpecularCoefficient
                | o Property SpecularCoefficient(    ) As double
                | 
                | Returns or sets the specular coefficient of a material. Specular
                | coefficient value is between 0 to 1.


                | Parameters:


        """
        return self.renderingmaterial.SpecularCoefficient

    @property
    def specular_exponent(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpecularExponent
                | o Property SpecularExponent(    ) As double
                | 
                | Returns or sets the specular exponent of a material. Specular exponent
                | value is between 0 to 1.


                | Parameters:


        """
        return self.renderingmaterial.SpecularExponent

    @property
    def texture_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextureAmplitude
                | o Property TextureAmplitude(    ) As double
                | 
                | Returns or sets the 3d texture amplitude coefficient. Amplitude value
                | is between 0 to 1. N.B. Parameter use for MARBLE and ROCK texture type
                | only.


                | Parameters:


        """
        return self.renderingmaterial.TextureAmplitude

    @property
    def texture_complexity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextureComplexity
                | o Property TextureComplexity(    ) As short
                | 
                | Returns or sets the 3d texture complexity. Complexity value is between
                | 0 to 10. N.B. Parameter use for MARBLE and ROCK texture types only.


                | Parameters:


        """
        return self.renderingmaterial.TextureComplexity

    @property
    def texture_gain(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextureGain
                | o Property TextureGain(    ) As double
                | 
                | Returns or sets the 3d texture gain coefficient. Gain value is between
                | 0 to 2. N.B. Parameter use for ROCK texture type only.


                | Parameters:


        """
        return self.renderingmaterial.TextureGain

    @property
    def texture_image(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextureImage
                | o Property TextureImage(    ) As CATBSTR
                | 
                | Returns or sets the texture image pathname of a material. N.B.
                | Parameter use for IMAGE texture type only


                | Parameters:


        """
        return self.renderingmaterial.TextureImage

    @property
    def texture_perturbation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TexturePerturbation
                | o Property TexturePerturbation(    ) As double
                | 
                | Returns or sets the 3d texture perturbation coefficient. Perturbation
                | value is between 1 to 10. N.B. Parameter use for VEIN, ALTERNATE VEIN
                | and ROCK texture types only.


                | Parameters:


        """
        return self.renderingmaterial.TexturePerturbation

    @property
    def texture_turbulence(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextureTurbulence
                | o Property TextureTurbulence(    ) As boolean
                | 
                | Returns or sets the 3d texture turbulence status. N.B. Parameter use
                | for ROCK texture type only.


                | Parameters:


        """
        return self.renderingmaterial.TextureTurbulence

    @property
    def texture_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextureType
                | o Property TextureType(    ) As short
                | 
                | Returns or sets the texture type of a material. The possible values
                | for this type can be:  Possible reflection mode values are:     0: NO
                | texture   1: IMAGE texture   2: MARBLE texture   3: VEIN texture   4:
                | ALTERNATE VEIN texture   5: ROCK texture   6: CHESSBOARD texture


                | Parameters:


        """
        return self.renderingmaterial.TextureType

    @property
    def texture_vein_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextureVeinAmplitude
                | o Property TextureVeinAmplitude(    ) As double
                | 
                | Returns or sets the 3d texture vein amplitude coefficient. Amplitude
                | value is between 0 to 10. N.B. Parameter use for VEIN and ALTERNATE
                | VEIN texture types only.


                | Parameters:


        """
        return self.renderingmaterial.TextureVeinAmplitude

    @property
    def transparency_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TransparencyCoefficient
                | o Property TransparencyCoefficient(    ) As double
                | 
                | Returns or sets the transparency coefficient of a material.
                | Transparency coefficient value is between 0 to 1.


                | Parameters:


        """
        return self.renderingmaterial.TransparencyCoefficient

    def get_3d_texture_color(self, i_color_index, o__3_d_texture_colo):
        """
        .. note::
            CAA V5 Visual Basic help

                | Get3DTextureColor
                | o Sub Get3DTextureColor(    short    iColorIndex,
                |                             CATSafeArrayVariant    o3DTextureColor)
                | 
                | Returns one color of a 3d texture. The color to access is identified
                | with its index. The color is expressed with r, g, and b coefficients
                | (between 0 and 255).


                | Parameters:
                | iColorIndex
                |    The index of the color to access
                |  
                | 
                | 
                |  Returns:
                |   the color as a safe array made up of three doubles: r, g, b 
                |    The r, g, b values ranges from 0 to 255.
                |  
                |    The array must be previously initialized.
                |  N.B. Parameter useless for image textures.


        """
        return self.renderingmaterial.Get3DTextureColor(i_color_index, o__3_d_texture_colo)

    def get_3d_texture_color_coefficient(self, i_color_index, o__3_d_texture_color_coefficien):
        """
        .. note::
            CAA V5 Visual Basic help

                | Get3DTextureColorCoefficient
                | o Sub Get3DTextureColorCoefficient(    short    iColorIndex,
                |                                        double    o3DTextureColorCoefficient)
                | 
                | Returns one color coefficient of a 3d texture. The color to access is
                | identified with its index.


                | Parameters:
                | iColorIndex
                |    The index of the color to access.
                |  
                | 
                | 
                |  Returns:
                |   the color coefficient. 
                |    If the color is enable, the color coefficient value should range from 0 to 1.
                |  
                |    If color is disable, the color coefficient is equal to -1.
                |  
                |  N.B. Parameter useless for rock, chessboard and image textures.


        """
        return self.renderingmaterial.Get3DTextureColorCoefficient(i_color_index, o__3_d_texture_color_coefficien)

    def get_3d_texture_orientation(self, o__3_d_texture_orientatio):
        """
        .. note::
            CAA V5 Visual Basic help

                | Get3DTextureOrientation
                | o Sub Get3DTextureOrientation(    CATSafeArrayVariant    o3DTextureOrientation)
                | 
                | Returns the orientation of a texture. The orientation is expressed
                | with 3 coefficients (orientation around X, Y and Z axis). The
                | orientation values must be between -360 and 360 degrees. N.B.
                | Parameter useless for IMAGE textures  (use get_Orientation,
                | set_Orientation methods for IMAGE type).  Returns:  the orientation as
                | a safe array made up of three doubles: rotationX, rotationY,
                | rotationZ.    The array must be previously initialized.


                | Parameters:


        """
        return self.renderingmaterial.Get3DTextureOrientation(o__3_d_texture_orientatio)

    def get_3d_texture_position(self, o__3_d_texture_positio):
        """
        .. note::
            CAA V5 Visual Basic help

                | Get3DTexturePosition
                | o Sub Get3DTexturePosition(    CATSafeArrayVariant    o3DTexturePosition)
                | 
                | Returns the position of a texture. The position is expressed with 3
                | coefficients (position along X, Y and Z axis). The position values
                | must be between -100 and 100. N.B. Parameter useless for IMAGE
                | textures  (use PositionU, PositionV  methods for IMAGE type).
                | Returns:  the position as a safe array made up of three doubles:
                | positionX, positionY, positionZ.    The array must be previously
                | initialized.


                | Parameters:


        """
        return self.renderingmaterial.Get3DTexturePosition(o__3_d_texture_positio)

    def get_3d_texture_scale(self, o__3_d_texture_scal):
        """
        .. note::
            CAA V5 Visual Basic help

                | Get3DTextureScale
                | o Sub Get3DTextureScale(    CATSafeArrayVariant    o3DTextureScale)
                | 
                | Returns the scale of a texture. The scale is expressed with 3
                | coefficients (scale along X, Y and Z axis) The scale values must be >
                | 0 and ≤ 100. N.B. Parameter useless for IMAGE textures.  (use
                | get_ScaleU, set_ScaleU, get_ScaleV, set_ScaleV methods for IMAGE type)
                | Returns:  the scale as a safe array made up of three doubles: scaleX,
                | scaleY, scaleZ.    The array must be previously initialized.


                | Parameters:


        """
        return self.renderingmaterial.Get3DTextureScale(o__3_d_texture_scal)

    def get_ambient_color(self, o_ambient_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAmbientColor
                | o Sub GetAmbientColor(    CATSafeArrayVariant    oAmbientColor)
                | 
                | Returns the ambient color of a material. The color is expressed with
                | r, g, and b coefficients (between 0 and 255)  Returns:  the color as a
                | safe array made up of three doubles: r, g, b    The r, g, b values
                | ranges from 0 to 255.    The array must be previously initialized.


                | Parameters:


        """
        return self.renderingmaterial.GetAmbientColor(o_ambient_color)

    def get_diffuse_color(self, o_diffuse_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDiffuseColor
                | o Sub GetDiffuseColor(    CATSafeArrayVariant    oDiffuseColor)
                | 
                | Returns the diffuse color of a material. The color is expressed with
                | r, g, and b coefficients (between 0 and 255)  Returns:  the color as a
                | safe array made up of three doubles: r, g, b    The r, g, b values
                | ranges from 0 to 255.    The array must be previously initialized.


                | Parameters:


        """
        return self.renderingmaterial.GetDiffuseColor(o_diffuse_color)

    def get_specular_color(self, o_specular_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSpecularColor
                | o Sub GetSpecularColor(    CATSafeArrayVariant    oSpecularColor)
                | 
                | Returns the specular color of a material. The color is expressed with
                | r, g, and b coefficients (between 0 and 255)  Returns:  the color as a
                | safe array made up of three doubles: r, g, b    The r, g, b values
                | ranges from 0 to 255.    The array must be previously initialized.


                | Parameters:


        """
        return self.renderingmaterial.GetSpecularColor(o_specular_color)

    def get_transparency_color(self, o_transparency_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTransparencyColor
                | o Sub GetTransparencyColor(    CATSafeArrayVariant    oTransparencyColor)
                | 
                | Returns the transparent color of a material. The color is expressed
                | with r, g, and b coefficients (between 0 and 255)


                | Parameters:
                | oTransparencyColor
                |    The color as a safe array made up of three doubles: r, g, b
                |  
                |    The r, g, b values ranges from 0 to 255.
                |  
                |    The array must be previously initialized.


        """
        return self.renderingmaterial.GetTransparencyColor(o_transparency_color)

    def put_3d_texture_color(self, i_color_index, i__3_d_texture_colo):
        """
        .. note::
            CAA V5 Visual Basic help

                | Put3DTextureColor
                | o Sub Put3DTextureColor(    short    iColorIndex,
                |                             CATSafeArrayVariant    i3DTextureColor)
                | 
                | Sets one color of a 3d texture. The color to access is identified with
                | its index. The color is expressed with r, g, and b coefficients
                | (between 0 and 255)


                | Parameters:
                | iColorIndex
                |    The index of the color to access.
                |  
                | 
                |  i3DTextureColor
                |    The color as a safe array made up of three doubles: r, g, b
                |  
                |    The r, g, b values ranges from 0 to 255.
                |  
                |    The array must be previously initialized.
                |  N.B. Parameter useless for image textures.


        """
        return self.renderingmaterial.Put3DTextureColor(i_color_index, i__3_d_texture_colo)

    def put_3d_texture_color_coefficient(self, i_color_index, i__3_d_texture_color_coefficien):
        """
        .. note::
            CAA V5 Visual Basic help

                | Put3DTextureColorCoefficient
                | o Sub Put3DTextureColorCoefficient(    short    iColorIndex,
                |                                        double    i3DTextureColorCoefficient)
                | 
                | Sets one color coefficient of a 3d texture. The color to access is
                | identified with its index.


                | Parameters:
                | iColorIndex
                |    The index of the color to access.
                |  
                | 
                |  i3DTextureColorCoefficient.
                |    The color coefficient.
                |  
                |    If color is enable, the color coefficient value should range from 0 to 1.
                |  
                |    If color is disable, the color coefficient should be equal to -1.
                |  
                |  N.B. Parameter useless for rock, chessboard and image textures.


        """
        return self.renderingmaterial.Put3DTextureColorCoefficient(i_color_index, i__3_d_texture_color_coefficien)

    def put_3d_texture_orientation(self, i__3_d_texture_orientatio):
        """
        .. note::
            CAA V5 Visual Basic help

                | Put3DTextureOrientation
                | o Sub Put3DTextureOrientation(    CATSafeArrayVariant    i3DTextureOrientation)
                | 
                | Sets the orientation of a texture. The orientation is expressed with 3
                | coefficients (orientation around X, Y and Z axis). The orientation
                | values must be between -360 and 360 degrees. N.B. Parameter useless
                | for IMAGE textures  (use get_Orientation, set_Orientation methods for
                | IMAGE type).


                | Parameters:
                | i3DTextureOrientation
                |    The orientation as a safe array made up of three doubles: rotationX, rotationY, rotationZ.
                |  
                |    The array must be previously initialized.


        """
        return self.renderingmaterial.Put3DTextureOrientation(i__3_d_texture_orientatio)

    def put_3d_texture_position(self, i__3_d_texture_positio):
        """
        .. note::
            CAA V5 Visual Basic help

                | Put3DTexturePosition
                | o Sub Put3DTexturePosition(    CATSafeArrayVariant    i3DTexturePosition)
                | 
                | Sets the position of a texture. The position is expressed with 3
                | coefficients (position along X, Y and Z axis). The position values
                | must be between -100 and 100. N.B. Parameter useless for IMAGE
                | textures  (use PositionU, PositionV  methods for IMAGE type).


                | Parameters:
                | i3DTexturePosition
                |    The position as a safe array made up of three doubles: positionX, positionY, positionZ.
                |  
                |    The array must be previously initialized.


        """
        return self.renderingmaterial.Put3DTexturePosition(i__3_d_texture_positio)

    def put_3d_texture_scale(self, i__3_d_texture_scal):
        """
        .. note::
            CAA V5 Visual Basic help

                | Put3DTextureScale
                | o Sub Put3DTextureScale(    CATSafeArrayVariant    i3DTextureScale)
                | 
                | Sets the scale of a texture. The scale is expressed with 3
                | coefficients (scale along X, Y and Z axis). The scale values must be >
                | 0 and ≤ 100. N.B. Parameter useless for IMAGE textures  (use
                | get_ScaleU, set_ScaleU, get_ScaleV, set_ScaleV methods for IMAGE
                | type).


                | Parameters:
                | i3DTextureScale
                |    The scale as a safe array made up of three doubles: scaleX, scaleY, scaleZ.
                |  
                |    The array must be previously initialized.


        """
        return self.renderingmaterial.Put3DTextureScale(i__3_d_texture_scal)

    def put_ambient_color(self, i_ambient_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutAmbientColor
                | o Sub PutAmbientColor(    CATSafeArrayVariant    iAmbientColor)
                | 
                | Sets the ambient color of a material. The color is expressed with r,
                | g, and b coefficients (between 0 and 255)


                | Parameters:
                | oAmbientColor
                |    The color as a safe array made up of three doubles: r, g, b
                |  
                |    The r, g, b values ranges from 0 to 255.
                |  
                |    The array must be previously initialized.


        """
        return self.renderingmaterial.PutAmbientColor(i_ambient_color)

    def put_diffuse_color(self, i_diffuse_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutDiffuseColor
                | o Sub PutDiffuseColor(    CATSafeArrayVariant    iDiffuseColor)
                | 
                | Sets the diffuse color of a material. The color is expressed with r,
                | g, and b coefficients (between 0 and 255)


                | Parameters:
                | oDiffuseColor
                |    The color as a safe array made up of three doubles: r, g, b
                |  
                |    The r, g, b values ranges from 0 to 255.
                |  
                |    The array must be previously initialized.


        """
        return self.renderingmaterial.PutDiffuseColor(i_diffuse_color)

    def put_specular_color(self, i_specular_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutSpecularColor
                | o Sub PutSpecularColor(    CATSafeArrayVariant    iSpecularColor)
                | 
                | Sets the specular color of a material. The color is expressed with r,
                | g, and b coefficients (between 0 and 255)


                | Parameters:
                | oSpecularColor
                |    The color as a safe array made up of three doubles: r, g, b
                |  
                |    The r, g, b values ranges from 0 to 255.
                |  
                |    The array must be previously initialized.


        """
        return self.renderingmaterial.PutSpecularColor(i_specular_color)

    def put_transparency_color(self, i_transparency_color):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutTransparencyColor
                | o Sub PutTransparencyColor(    CATSafeArrayVariant    iTransparencyColor)
                | 
                | Sets the transparent color of a material. The color is expressed with
                | r, g, and b coefficients (between 0 and 255)


                | Parameters:
                | iTransparencyColor
                |    The color as a safe array made up of three doubles: r, g, b
                |  
                |    The r, g, b values ranges from 0 to 255.
                |  
                |    The array must be previously initialized.


        """
        return self.renderingmaterial.PutTransparencyColor(i_transparency_color)

