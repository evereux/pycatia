#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class NavigatorInterfaces:
    """
        .. note::
            CAA V5 Visual Basic help

                | Object IndexEnumerated IndexMacro Index

    """

    def __init__(self, catia):
        self.navigatorinterfaces = catia.NavigatorInterfaces     

