#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalObjects:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access a collection of FunctionalObjects.

    """

    def __init__(self, catia):
        self.functionalobjects = catia.FunctionalObjects     

    def create(self, i_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create
                | o Func Create(    CATBSTR    iName) As FunctionalObject
                | 
                | Creates a FunctionalObject.


                | Parameters:


        """
        return self.functionalobjects.Create(i_name)

    def create_proxy(self, i_name, i_desc):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateProxy
                | o Func CreateProxy(    CATBSTR    iName,
                |                        FunctionalDescription    iDesc) As FunctionalObjectProxy
                | 
                | Creates a FunctionalObjectProxi.


                | Parameters:


        """
        return self.functionalobjects.CreateProxy(i_name, i_desc)

    def delete(self, i_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | Delete
                | o Sub Delete(    FunctionalObject    iObject)
                | 
                | Deletes a FunctionalObject.


                | Parameters:


        """
        return self.functionalobjects.Delete(i_object)

    def elem(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Elem
                | o Func Elem(    CATVariant    iIndex) As FunctionalObject
                | 
                | Returns an action using its index or its name from the actions
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the action to retrieve from
                |    the collection of actions.
                |    As a numerics, this index is the rank of the action
                |    in the collection.
                |    The index of the first action in the collection is 1, and
                |    the index of the last action is Count.
                |    As a string, it is the name you assigned to the action using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved action


                | Examples:
                | 
                | 
                | This example retrieves in Obj1 the fifth object
                | in the collection and in Obj2 the action
                | named Valve.
                | 
                | Dim Obj1 As FunctionalObject
                | Set Obj1 = Desc.Object(5)
                | Dim Obj2 As FunctionalObject
                | Set Obj2 = Desc.Object("Valve")
                | 
                | 
                | 
        """
        return self.functionalobjects.Elem(i_index)

