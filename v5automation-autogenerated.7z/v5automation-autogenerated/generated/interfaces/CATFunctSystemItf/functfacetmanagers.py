#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctFacetManagers:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Functional Facet's Managers.

    """

    def __init__(self, catia):
        self.functfacetmanagers = catia.FunctFacetManagers     

    def elem(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Elem
                | o Func Elem(    CATVariant    iIndex) As FunctionalFacetMgr
                | 
                | Returns a facet manager using its index or its name from the facet
                | managers collection.


                | Parameters:
                | iIndex
                |    The index or the name of the facet manager to retrieve from
                |    the collection of facet managers.
                |    As a numerics, this index is the rank of the facet manager
                |    in the collection.
                |    The index of the first facet manager in the collection is 1, and
                |    the index of the last facet manager is Count.
                |    As a string, it is the name you assigned to the facet manager using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved action


                | Examples:
                | 
                | 
                | This example retrieves in Obj1 the fifth facet manager
                | in the collection and in Obj2 the facet manager
                | named IMC.
                | 
                | Dim Obj1 As FunctFacetManager
                | Set Obj1 = Desc.FacetManagers.Elem(5)
                | Dim Obj2 As FunctFacetManager
                | Set Obj2 = Desc.FacetManagers.Elem("IMC")
                | 
                | 
                | 
        """
        return self.functfacetmanagers.Elem(i_index)

