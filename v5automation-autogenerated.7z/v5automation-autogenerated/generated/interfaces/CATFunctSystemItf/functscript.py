#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctScript:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional Script.It is managed on a
                | Functional Element, thru the GenerativeKnowledge Facet Manager (GKW).

    """

    def __init__(self, catia):
        self.functscript = catia.FunctScript     

    @property
    def script_text(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ScriptText
                | o Property ScriptText(    ) As CATBSTR
                | 
                | Get the ScriptText.


                | Parameters:


        """
        return self.functscript.ScriptText

