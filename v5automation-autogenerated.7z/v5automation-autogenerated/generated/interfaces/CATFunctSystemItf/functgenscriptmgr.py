#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctGenScriptMgr:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional GenerativeScripts manager.

    """

    def __init__(self, catia):
        self.functgenscriptmgr = catia.FunctGenScriptMgr     

    @property
    def current_script(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentScript
                | o Property CurrentScript(    ) As long
                | 
                | Get the CurrentScript.


                | Parameters:


        """
        return self.functgenscriptmgr.CurrentScript

    @property
    def scripts(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Scripts
                | o Property Scripts(    ) As FunctScripts
                | 
                | Get the Generative Scripts collection.


                | Parameters:


        """
        return self.functgenscriptmgr.Scripts

