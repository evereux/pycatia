#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctScripts:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a set of Functional Scripts.It is managed on a
                | Functional Element, thru the GenerativeKnowledge Facet Manager (GKW).

    """

    def __init__(self, catia):
        self.functscripts = catia.FunctScripts     

    def create(self, i_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create
                | o Func Create(    CATBSTR    iName) As FunctScript
                | 
                | Create a FunctScript.


                | Parameters:


        """
        return self.functscripts.Create(i_name)

    def delete(self, i_script):
        """
        .. note::
            CAA V5 Visual Basic help

                | Delete
                | o Sub Delete(    FunctScript    iScript)
                | 
                | Delete a FunctScript.


                | Parameters:


        """
        return self.functscripts.Delete(i_script)

    def elem(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Elem
                | o Func Elem(    CATVariant    iIndex) As FunctScript
                | 
                | Returns an association using its index or its name from the Scripts
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the Script to retrieve from
                |    the collection of Scripts.
                |    As a numerics, this index is the rank of the Script
                |    in the collection.
                |    The index of the first Script in the collection is 1, and
                |    the index of the last Script is Count.
                |    As a string, it is the name you assigned to the Script using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved Script


                | Examples:
                | 
                | 
                | This example retrieves in Act1 the fifth Script
                | in the collection and in Act2 the Script
                | named Moves.
                | 
                | Dim FunctElem As FunctionalObject
                | Set FunctElem = FunctDoc.CurrentDescription.Objects.Elem("Valve")
                | Dim FacetGKW As FunctionalGenScriptMgr
                | Set FacetGKW = FunctElem.GetFacetByName("GKW")
                | Dim Assoc1 As FunctScript
                | Set Assoc1 = FacetGKW.Scripts.Elem(5)
                | Dim Assoc2 As FunctScript
                | Set Assoc2 = FacetGKW.Scripts.Elem("Producing the Skeleton 2D")
                | 
                | 
                | 
        """
        return self.functscripts.Elem(i_index)

