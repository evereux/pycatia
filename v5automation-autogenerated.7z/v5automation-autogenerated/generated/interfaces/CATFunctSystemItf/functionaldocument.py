#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalDocument:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Functional Document.

    """

    def __init__(self, catia):
        self.functionaldocument = catia.FunctionalDocument     

    @property
    def current_description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentDescription
                | o Property CurrentDescription(    ) As FunctionalDescription
                | 
                | Returns the Current Description.


                | Parameters:


        """
        return self.functionaldocument.CurrentDescription

    @property
    def facet_managers(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FacetManagers
                | o Property FacetManagers(    ) As FunctFacetManagers
                | 
                | Returns the Facet Managers.


                | Parameters:


        """
        return self.functionaldocument.FacetManagers

    @property
    def original_description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OriginalDescription
                | o Property OriginalDescription(    ) As FunctionalDescription
                | 
                | Returns the Original Description.


                | Parameters:


        """
        return self.functionaldocument.OriginalDescription

