#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctActionsGroups:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access the groups of functional actions in a system.

    """

    def __init__(self, catia):
        self.functactionsgroups = catia.FunctActionsGroups     

    def create(self, i_name, i_input_x, i_input_y, i_output_x, i_output_y):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create
                | o Func Create(    CATBSTR    iName,
                |                   double    iInputX,
                |                   double    iInputY,
                |                   double    iOutputX,
                |                   double    iOutputY) As FunctActionsGroup
                | 
                | Create a Group of Actions.


                | Parameters:


        """
        return self.functactionsgroups.Create(i_name, i_input_x, i_input_y, i_output_x, i_output_y)

    def delete(self, i_act_grp):
        """
        .. note::
            CAA V5 Visual Basic help

                | Delete
                | o Sub Delete(    FunctActionsGroup    iActGrp)
                | 
                | Delete a Group of Actions.


                | Parameters:


        """
        return self.functactionsgroups.Delete(i_act_grp)

    def elem(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Elem
                | o Func Elem(    CATVariant    iIndex) As FunctActionsGroup
                | 
                | Returns an actions'group using its index or its name from the actions'
                | groups collection.


                | Parameters:
                | iIndex
                |    The index or the name of the actions'group to retrieve from
                |    the collection of actions' groups.
                |    As a numerics, this index is the rank of the actions' group
                |    in the collection.
                |    The index of the first actions' group in the collection is 1, and
                |    the index of the last actions' group is Count.
                |    As a string, it is the name you assigned to the actions' group using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved action


                | Examples:
                | 
                | 
                | This example retrieves in AG1 the fifth actions' group
                | in the collection and in AG2 the actions' group
                | named Transmission.
                | 
                | Dim AG1 As FunctActionsGroup
                | Set AG1 = ActionsGroups.Elem(5)
                | Dim AG2 As FunctActionsGroup
                | Set AG2 = ActionsGroups.Elem("Transmission")
                | 
                | 
                | 
        """
        return self.functactionsgroups.Elem(i_index)

