#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctAssociations:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a set of Functional Associations.It is managed
                | on a Functional Element, thru the MultiRep Facet Manager (MRM).

    """

    def __init__(self, catia):
        self.functassociations = catia.FunctAssociations     

    def create(self, i_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create
                | o Func Create(    CATBSTR    iName) As FunctAssociation
                | 
                | Create a FunctAssociation.


                | Parameters:


        """
        return self.functassociations.Create(i_name)

    def delete(self, i_association):
        """
        .. note::
            CAA V5 Visual Basic help

                | Delete
                | o Sub Delete(    FunctAssociation    iAssociation)
                | 
                | Delete a FunctAssociation.


                | Parameters:


        """
        return self.functassociations.Delete(i_association)

    def elem(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Elem
                | o Func Elem(    CATVariant    iIndex) As FunctAssociation
                | 
                | Returns an association using its index or its name from the
                | associations collection.


                | Parameters:
                | iIndex
                |    The index or the name of the association to retrieve from
                |    the collection of associations.
                |    As a numerics, this index is the rank of the association
                |    in the collection.
                |    The index of the first association in the collection is 1, and
                |    the index of the last association is Count.
                |    As a string, it is the name you assigned to the association using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved association


                | Examples:
                | 
                | 
                | This example retrieves in Act1 the fifth association
                | in the collection and in Act2 the association
                | named Moves.
                | 
                | Dim FunctElem As FunctionalObject
                | Set FunctElem = FunctDoc.CurrentDescription.Objects.Elem("Valve")
                | Dim FacetMRM As FunctionalMultiRepMgr
                | Set FacetMRM = FunctElem.GetFacetByName("MRM")
                | Dim Assoc1 As FunctAssociation
                | Set Assoc1 = FacetMRM.Associations.Elem(5)
                | Dim Assoc2 As FunctAssociation
                | Set Assoc2 = FacetMRM.Associations.Elem("Skeleton 2D")
                | 
                | 
                | 
        """
        return self.functassociations.Elem(i_index)

