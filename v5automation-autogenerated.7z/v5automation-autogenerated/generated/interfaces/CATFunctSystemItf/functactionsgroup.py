#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctActionsGroup:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a group of functional actions in a system.

    """

    def __init__(self, catia):
        self.functactionsgroup = catia.FunctActionsGroup     

    @property
    def actions_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActionsCount
                | o Property ActionsCount(    ) As long
                | 
                | Get the count of actions referenced by the actions' group.


                | Parameters:


        """
        return self.functactionsgroup.ActionsCount

    def add(self, i_action):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Sub Add(    FunctionalAction    iAction)
                | 
                | Adds an action to the actions' group.   Fails if the action : is
                | already in a group     has "From" and "To" extremities inconsistent
                | with the existing actions.  In case of an ordered group, the added
                | action will be appended. (i.e. for flows sequencing actions)


                | Parameters:
                | iAction
                |    The action to be added to the group of actions.


        """
        return self.functactionsgroup.Add(i_action)

    def get_extremities(self, o_input_x, o_input_y, o_output_x, o_output_y):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExtremities
                | o Sub GetExtremities(    double    oInputX,
                |                          double    oInputY,
                |                          double    oOutputX,
                |                          double    oOutputY)
                | 
                | Get coordinates of Input and Output extremities.


                | Parameters:


        """
        return self.functactionsgroup.GetExtremities(o_input_x, o_input_y, o_output_x, o_output_y)

    def remove(self, i_action):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(    FunctionalAction    iAction)
                | 
                | Removes an action from the actions' group.


                | Parameters:
                | iAction
                |    The action to be removed from the group of actions.


        """
        return self.functactionsgroup.Remove(i_action)

    def remove_position(self, i_position):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePosition
                | o Sub RemovePosition(    long    iPosition)
                | 
                | Removes an action from the actions' group.


                | Parameters:
                | iPosition
                |    The position of the action to be removed from the group of actions.


        """
        return self.functactionsgroup.RemovePosition(i_position)

    def retrieve(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Retrieve
                | o Func Retrieve(    CATVariant    iIndex) As FunctionalAction
                | 
                | Returns an action using its index or its name from the actions group.


                | Parameters:
                | iIndex
                |    The index or the name of the action to retrieve from
                |    the group of actions.
                |    As a numerics, this index is the rank of the action
                |    in the group.
                |    The index of the first action in the group is 1, and
                |    the index of the last action is Count.
                |    As a string, it is the name you assigned to the action using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved action


                | Examples:
                | 
                | 
                | This example retrieves in Obj1 the fifth action
                | in the group and in Obj2 the action
                | named Valve.
                | 
                | Dim Act1 As FunctionalAction
                | Set Act1 = ActionsGrp.Retrieve(5)
                | Dim Act2 As FunctionalAction
                | Set Act2 = ActionsGrp.Retrieve("Reduces noise")
                | 
                | 
                | 
        """
        return self.functactionsgroup.Retrieve(i_index)

    def set_extremities(self, i_input_x, i_input_y, i_output_x, i_output_y):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExtremities
                | o Sub SetExtremities(    double    iInputX,
                |                          double    iInputY,
                |                          double    iOutputX,
                |                          double    iOutputY)
                | 
                | Set coordinates of Input and Output extremities.


                | Parameters:


        """
        return self.functactionsgroup.SetExtremities(i_input_x, i_input_y, i_output_x, i_output_y)

