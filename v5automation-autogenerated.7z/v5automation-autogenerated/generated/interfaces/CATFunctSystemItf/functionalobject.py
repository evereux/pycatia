#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalObject:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional Object.

    """

    def __init__(self, catia):
        self.functionalobject = catia.FunctionalObject     

    def get_facet(self, i_fm):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFacet
                | o Func GetFacet(    FunctionalFacetMgr    iFM) As FunctionalFacet
                | 
                | Returns the Facet.


                | Parameters:


        """
        return self.functionalobject.GetFacet(i_fm)

    def get_facet_by_name(self, i_fm):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFacetByName
                | o Func GetFacetByName(    CATBSTR    iFM) As FunctionalFacet
                | 
                | Returns the Facet.


                | Parameters:


        """
        return self.functionalobject.GetFacetByName(i_fm)

    def search_facet(self, i_fm, i_create_if_necessary):
        """
        .. note::
            CAA V5 Visual Basic help

                | SearchFacet
                | o Func SearchFacet(    FunctionalFacetMgr    iFM,
                |                        boolean    iCreateIfNecessary) As FunctionalFacet
                | 
                | Searches the Facet.


                | Parameters:


        """
        return self.functionalobject.SearchFacet(i_fm, i_create_if_necessary)

    def search_facet_by_name(self, i_fm, i_create_if_necessary):
        """
        .. note::
            CAA V5 Visual Basic help

                | SearchFacetByName
                | o Func SearchFacetByName(    CATBSTR    iFM,
                |                              boolean    iCreateIfNecessary) As FunctionalFacet
                | 
                | Searches the Facet.


                | Parameters:


        """
        return self.functionalobject.SearchFacetByName(i_fm, i_create_if_necessary)

