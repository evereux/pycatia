#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctNodeGraphLayout:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a CATIAFunctNodeGraphLayout.

    """

    def __init__(self, catia):
        self.functnodegraphlayout = catia.FunctNodeGraphLayout     

    @property
    def height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Height
                | o Property Height(    ) As double
                | 
                | Returns the Height coordinate.


                | Parameters:


        """
        return self.functnodegraphlayout.Height

    @property
    def width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Width
                | o Property Width(    ) As double
                | 
                | Returns the Width coordinate.


                | Parameters:


        """
        return self.functnodegraphlayout.Width

    def set_height_and_width(self, i_height, i_width):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHeightAndWidth
                | o Sub SetHeightAndWidth(    double    iHeight,
                |                             double    iWidth)
                | 
                | Sets the height and width.


                | Parameters:
                | iHeight
                |  the height value. 
                |  iWidth
                |  the width value.


        """
        return self.functnodegraphlayout.SetHeightAndWidth(i_height, i_width)

