#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctAssociation:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional Association.It is managed on a
                | Functional Element, thru the MultiRep Facet Manager (MRM).

    """

    def __init__(self, catia):
        self.functassociation = catia.FunctAssociation     

    @property
    def linked_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LinkedCount
                | o Property LinkedCount(    ) As long
                | 
                | Get count of linked objects.


                | Parameters:


        """
        return self.functassociation.LinkedCount

    def detach_from(self, i_linked):
        """
        .. note::
            CAA V5 Visual Basic help

                | DetachFrom
                | o Sub DetachFrom(    AnyObject    iLinked)
                | 
                | Delete a link to a linked object.


                | Parameters:


        """
        return self.functassociation.DetachFrom(i_linked)

    def link_to(self, i_linked, i_kind):
        """
        .. note::
            CAA V5 Visual Basic help

                | LinkTo
                | o Sub LinkTo(    AnyObject    iLinked,
                |                  CATBSTR    iKind)
                | 
                | Create a link to another object.


                | Parameters:


        """
        return self.functassociation.LinkTo(i_linked, i_kind)

    def retrieve_kind_of_linked(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | RetrieveKindOfLinked
                | o Func RetrieveKindOfLinked(    CATVariant    iIndex) As CATBSTR
                | 
                | Retrieve the kind of linked object.


                | Parameters:


        """
        return self.functassociation.RetrieveKindOfLinked(i_index)

    def retrieve_linked(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | RetrieveLinked
                | o Func RetrieveLinked(    CATVariant    iIndex) As AnyObject
                | 
                | Retrieve a linked object.


                | Parameters:


        """
        return self.functassociation.RetrieveLinked(i_index)

