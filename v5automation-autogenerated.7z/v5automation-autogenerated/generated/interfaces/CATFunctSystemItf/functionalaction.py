#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalAction:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional Action.

    """

    def __init__(self, catia):
        self.functionalaction = catia.FunctionalAction     

    @property
    def from(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | From
                | o Property From(    ) As FunctionalPosition
                | 
                | Get the From object.


                | Parameters:


        """
        return self.functionalaction.From

    @property
    def group(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Group
                | o Property Group(    ) As FunctActionsGroup
                | 
                | Get the Group property.  Vary when adding/removing the action to/from
                | a group.


                | Parameters:


        """
        return self.functionalaction.Group

    @property
    def orientation_direction(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OrientationDirection
                | o Property OrientationDirection(    ) As CATFunctOrientationDirection
                | 
                | Get the OrientationDirection property.  See also:  activateLinkAnchor(
                | 'CATFunctOrientationDirection','','CATFunctOrientationDirection')


                | Parameters:


        """
        return self.functionalaction.OrientationDirection

    @property
    def to(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | To
                | o Property To(    ) As FunctionalPosition
                | 
                | Get the To object.


                | Parameters:


        """
        return self.functionalaction.To

    def get_facet(self, i_fm):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFacet
                | o Func GetFacet(    FunctionalFacetMgr    iFM) As FunctionalFacet
                | 
                | Returns the Facet.


                | Parameters:


        """
        return self.functionalaction.GetFacet(i_fm)

    def get_facet_by_name(self, i_fm):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFacetByName
                | o Func GetFacetByName(    CATBSTR    iFM) As FunctionalFacet
                | 
                | Returns the Facet.


                | Parameters:


        """
        return self.functionalaction.GetFacetByName(i_fm)

    def invert_direction(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InvertDirection
                | o Sub InvertDirection(    )
                | 
                | Invert the action's Direction.  Fails if the action is included in a
                | group.


                | Parameters:


        """
        return self.functionalaction.InvertDirection()

    def search_facet(self, i_fm, i_create_if_necessary):
        """
        .. note::
            CAA V5 Visual Basic help

                | SearchFacet
                | o Func SearchFacet(    FunctionalFacetMgr    iFM,
                |                        boolean    iCreateIfNecessary) As FunctionalFacet
                | 
                | Searches the Facet.


                | Parameters:


        """
        return self.functionalaction.SearchFacet(i_fm, i_create_if_necessary)

    def search_facet_by_name(self, i_fm, i_create_if_necessary):
        """
        .. note::
            CAA V5 Visual Basic help

                | SearchFacetByName
                | o Func SearchFacetByName(    CATBSTR    iFM,
                |                              boolean    iCreateIfNecessary) As FunctionalFacet
                | 
                | Searches the Facet.


                | Parameters:


        """
        return self.functionalaction.SearchFacetByName(i_fm, i_create_if_necessary)

