#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalPosition:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Functional Position.

    """

    def __init__(self, catia):
        self.functionalposition = catia.FunctionalPosition     

    @property
    def x(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | X
                | o Property X(    ) As double
                | 
                | Returns the X coordinate.


                | Parameters:


        """
        return self.functionalposition.X

    @property
    def y(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Y
                | o Property Y(    ) As double
                | 
                | Returns the Y coordinate.


                | Parameters:


        """
        return self.functionalposition.Y

    def set_coords(self, i_x, i_y):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCoords
                | o Sub SetCoords(    double    iX,
                |                     double    iY)
                | 
                | Sets the coordinates.


                | Parameters:
                | iX
                |  the x coordinate. 
                |  iY
                |  the y coordinate


        """
        return self.functionalposition.SetCoords(i_x, i_y)

