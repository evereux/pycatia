#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class CATFunctOrientationDirection:
    """
        .. note::
            CAA V5 Visual Basic help

                | The qualifications of Orientation and Direction of a Functional
                | Action.

    """

    def __init__(self, catia):
        self.catfunctorientationdirection = catia.CATFunctOrientationDirection     

