#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalSystemSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Enables attribute access to PFD options.

    """

    def __init__(self, catia):
        self.functionalsystemsettingatt = catia.FunctionalSystemSettingAtt     

    @property
    def document_content_at_creation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DocumentContentAtCreation
                | o Property DocumentContentAtCreation(    ) As long
                | 
                | Returns or sets the DocumentContentAtCreation parameter.


                | Parameters:
                | iDocumentContentAtCreation
                |  oDocumentContentAtCreation	Document Content At Creation Attribute
                | 	Legal values:
                | 	0 :  Sample elements
                |  	1:   empty
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.DocumentContentAtCreation

    @property
    def functional_action_presentation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FunctionalActionPresentation
                | o Property FunctionalActionPresentation(    ) As long
                | 
                | Returns or sets the FunctionalActionPresentation parameter.


                | Parameters:
                | iDocumentContentAtCreation
                |  or oDocumentContentAtCreation	Functional Action Presentation
                | 	Legal values:
                | 	0 :  A   : Action
                |  	1:   SAO : Subject Action  Object
                |  	2:   ASO : Action  Subject Object
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.FunctionalActionPresentation

    @property
    def show_parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShowParameters
                | o Property ShowParameters(    ) As long
                | 
                | Returns or sets the ShowParameters parameter.


                | Parameters:
                | iShowParameters
                |  or oShowParameters	Show Parameters
                | 	Legal values:
                | 	False :
                | True:
                | 
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.ShowParameters

    @property
    def show_relations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShowRelations
                | o Property ShowRelations(    ) As long
                | 
                | Returns or sets the ShowRelations parameter.


                | Parameters:
                | iShowRelations
                |  or oShowRelations	Show Relations
                | 	Legal values:
                | 	False :
                | True:


        """
        return self.functionalsystemsettingatt.ShowRelations

    @property
    def show_synchro_status_of_local_param_cache(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShowSynchroStatusOfLocalParamCache
                | o Property ShowSynchroStatusOfLocalParamCache(    ) As long
                | 
                | Returns or sets the ShowSynchroStatusOfLocalParamCache parameter.


                | Parameters:
                | iShowSynchroStatusOfLocalParamCache
                |  or oShowSynchroStatusOfLocalParamCache	Show Synchronisation Status OfLocal Parameter Cache
                | 	Legal values:
                | 	False :
                | True  :


        """
        return self.functionalsystemsettingatt.ShowSynchroStatusOfLocalParamCache

    @property
    def split_functional_object_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SplitFunctionalObjectName
                | o Property SplitFunctionalObjectName(    ) As long
                | 
                | Returns or sets the SplitFunctionalObjectName parameter.


                | Parameters:
                | iSplitFunctionalObjectName
                |  or oSplitFunctionalObjectName	Legal values:
                | 	False :  don't split functional object name
                |  	True  :  split Functional object name
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.SplitFunctionalObjectName

    @property
    def string_used_as_carriage_return(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StringUsedAsCarriageReturn
                | o Property StringUsedAsCarriageReturn(    ) As CATBSTR
                | 
                | Returns or sets the StringUsedAsCarriageReturn parameter.


                | Parameters:
                | iStringUsedAsCarriageReturn
                |  or oStringUsedAsCarriageReturn	String Used As Carriage Return
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.StringUsedAsCarriageReturn

    @property
    def type_of_icon_on_functional_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TypeOfIconOnFunctionalElement
                | o Property TypeOfIconOnFunctionalElement(    ) As long
                | 
                | Returns or sets the TypeOfIconOnFunctionalElement parameter.


                | Parameters:
                | iTypeOfIconOnFunctionalElement
                |  or oTypeOfIconOnFunctionalElement	Type Of Icon On Functional Elements
                | 	Legal values:
                | 	0 :  indicate a current association with PPR links.
                |  	1:   indicate a current generative script.


        """
        return self.functionalsystemsettingatt.TypeOfIconOnFunctionalElement

    def get_document_content_at_creation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDocumentContentAtCreationInfo
                | o Func GetDocumentContentAtCreationInfo(    CATBSTR    ioAdminLevel,
                |                                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the DocumentContentAtCreation
                | parameter. Role:Retrieves the state of the DocumentContentAtCreation
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.functionalsystemsettingatt.GetDocumentContentAtCreationInfo(io_admin_level, io_locked)

    def get_functional_action_presentation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFunctionalActionPresentationInfo
                | o Func GetFunctionalActionPresentationInfo(    CATBSTR    ioAdminLevel,
                |                                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the
                | FunctionalActionPresentation parameter. Role:Retrieves the state of
                | the FunctionalActionPresentation parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.functionalsystemsettingatt.GetFunctionalActionPresentationInfo(io_admin_level, io_locked)

    def get_show_parameters_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShowParametersInfo
                | o Func GetShowParametersInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ShowParameters parameter.
                | Role:Retrieves the state of the ShowParameters parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.functionalsystemsettingatt.GetShowParametersInfo(io_admin_level, io_locked)

    def get_show_relations_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShowRelationsInfo
                | o Func GetShowRelationsInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the ShowRelations parameter.
                | Role:Retrieves the state of the ShowRelations parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.functionalsystemsettingatt.GetShowRelationsInfo(io_admin_level, io_locked)

    def get_show_synchro_status_of_local_param_cache_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShowSynchroStatusOfLocalParamCacheInfo
                | o Func GetShowSynchroStatusOfLocalParamCacheInfo(    CATBSTR    ioAdminLevel,
                |                                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the
                | ShowSynchroStatusOfLocalParamCache parameter. Role:Retrieves the state
                | of the ShowSynchroStatusOfLocalParamCache parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.functionalsystemsettingatt.GetShowSynchroStatusOfLocalParamCacheInfo(io_admin_level, io_locked)

    def get_split_functional_object_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSplitFunctionalObjectNameInfo
                | o Func GetSplitFunctionalObjectNameInfo(    CATBSTR    ioAdminLevel,
                |                                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the SplitFunctionalObjectName
                | parameter. Role:Retrieves the state of the SplitFunctionalObjectName
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.functionalsystemsettingatt.GetSplitFunctionalObjectNameInfo(io_admin_level, io_locked)

    def get_string_used_as_carriage_return_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStringUsedAsCarriageReturnInfo
                | o Func GetStringUsedAsCarriageReturnInfo(    CATBSTR    ioAdminLevel,
                |                                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the StringUsedAsCarriageReturn
                | parameter. Role:Retrieves the state of the StringUsedAsCarriageReturn
                | parameter  in the current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.functionalsystemsettingatt.GetStringUsedAsCarriageReturnInfo(io_admin_level, io_locked)

    def get_type_of_icon_on_functional_element_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTypeOfIconOnFunctionalElementInfo
                | o Func GetTypeOfIconOnFunctionalElementInfo(    CATBSTR    ioAdminLevel,
                |                                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the
                | TypeOfIconOnFunctionalElement parameter. Role:Retrieves the state of
                | the TypeOfIconOnFunctionalElement parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.functionalsystemsettingatt.GetTypeOfIconOnFunctionalElementInfo(io_admin_level, io_locked)

    def set_document_content_at_creation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDocumentContentAtCreationLock
                | o Sub SetDocumentContentAtCreationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the DocumentContentAtCreation parameter. Role:Locks
                | or unlocks the DocumentContentAtCreation parameter if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.SetDocumentContentAtCreationLock(i_locked)

    def set_functional_action_presentation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFunctionalActionPresentationLock
                | o Sub SetFunctionalActionPresentationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the FunctionalActionPresentation parameter.
                | Role:Locks or unlocks the FunctionalActionPresentation parameter if it
                | is possible in the current administrative context. In user mode this
                | method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.SetFunctionalActionPresentationLock(i_locked)

    def set_show_parameters_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShowParametersLock
                | o Sub SetShowParametersLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ShowParameters parameter. Role:Locks or unlocks
                | the ShowParameters parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.SetShowParametersLock(i_locked)

    def set_show_relations_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShowRelationsLock
                | o Sub SetShowRelationsLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ShowRelations parameter. Role:Locks or unlocks
                | the ShowRelations parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.SetShowRelationsLock(i_locked)

    def set_show_synchro_status_of_local_param_cache_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShowSynchroStatusOfLocalParamCacheLock
                | o Sub SetShowSynchroStatusOfLocalParamCacheLock(    boolean    iLocked)
                | 
                | Locks or unlocks the ShowSynchroStatusOfLocalParamCache parameter.
                | Role:Locks or unlocks the ShowSynchroStatusOfLocalParamCache parameter
                | if it is possible in the current administrative context. In user mode
                | this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.SetShowSynchroStatusOfLocalParamCacheLock(i_locked)

    def set_split_functional_object_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSplitFunctionalObjectNameLock
                | o Sub SetSplitFunctionalObjectNameLock(    boolean    iLocked)
                | 
                | Locks or unlocks the SplitFunctionalObjectName parameter. Role:Locks
                | or unlocks the SplitFunctionalObjectName parameter if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.SetSplitFunctionalObjectNameLock(i_locked)

    def set_string_used_as_carriage_return_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetStringUsedAsCarriageReturnLock
                | o Sub SetStringUsedAsCarriageReturnLock(    boolean    iLocked)
                | 
                | Locks or unlocks the StringUsedAsCarriageReturn parameter. Role:Locks
                | or unlocks the StringUsedAsCarriageReturn parameter if it is possible
                | in the current administrative context. In user mode this method will
                | always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.


        """
        return self.functionalsystemsettingatt.SetStringUsedAsCarriageReturnLock(i_locked)

    def set_type_of_icon_on_functional_element_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTypeOfIconOnFunctionalElementLock
                | o Sub SetTypeOfIconOnFunctionalElementLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TypeOfIconOnFunctionalElement parameter.
                | Role:Locks or unlocks the TypeOfIconOnFunctionalElement parameter if
                | it is possible in the current administrative context. In user mode
                | this method will always return E_FAIL.


                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure


        """
        return self.functionalsystemsettingatt.SetTypeOfIconOnFunctionalElementLock(i_locked)

