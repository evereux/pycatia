#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalVariants:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a collection of FunctionalVariants.

    """

    def __init__(self, catia):
        self.functionalvariants = catia.FunctionalVariants     

    def create(self, i_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create
                | o Func Create(    CATBSTR    iName) As FunctionalVariant
                | 
                | Create a FunctionalVariant.


                | Parameters:


        """
        return self.functionalvariants.Create(i_name)

    def delete(self, i_variant):
        """
        .. note::
            CAA V5 Visual Basic help

                | Delete
                | o Sub Delete(    FunctionalVariant    iVariant)
                | 
                | Delete a FunctionalVariant.


                | Parameters:


        """
        return self.functionalvariants.Delete(i_variant)

    def elem(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Elem
                | o Func Elem(    CATVariant    iIndex) As FunctionalVariant
                | 
                | Returns a Variant using its index or its name from the Variants
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the Variant to retrieve from
                |    the collection of Variants.
                |    As a numerics, this index is the rank of the Variant
                |    in the collection.
                |    The index of the first Variant in the collection is 1, and
                |    the index of the last Variant is Count.
                |    As a string, it is the name you assigned to the Variant using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved Variant


                | Examples:
                | 
                | 
                | This example retrieves in Act1 the fifth Variant
                | in the collection and in Act2 the Variant
                | named Moves.
                | 
                | Dim Act1 As FunctionalVariant
                | Set Act1 = Desc.Variant(5)
                | Dim Act2 As FunctionalVariant
                | Set Act2 = Desc.Variant("Adding new substance")
                | 
                | 
                | 
        """
        return self.functionalvariants.Elem(i_index)

