#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalFacet:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional Facet.

    """

    def __init__(self, catia):
        self.functionalfacet = catia.FunctionalFacet     

    @property
    def functional_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FunctionalElement
                | o Property FunctionalElement(    ) As FunctionalElement
                | 
                | Get the Functional Element owning the Facet.


                | Parameters:


        """
        return self.functionalfacet.FunctionalElement

    def free(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Free
                | o Sub Free(    )
                | 
                | Free the resources allocated by the Facet.


                | Parameters:


        """
        return self.functionalfacet.Free()

    def init(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Init
                | o Sub Init(    )
                | 
                | Init resources for the Facet.


                | Parameters:


        """
        return self.functionalfacet.Init()

