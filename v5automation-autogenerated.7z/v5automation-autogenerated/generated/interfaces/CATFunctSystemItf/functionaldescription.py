#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalDescription:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional Description.

    """

    def __init__(self, catia):
        self.functionaldescription = catia.FunctionalDescription     

    @property
    def actions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Actions
                | o Property Actions(    ) As FunctionalActions
                | 
                | Get the Actions collection.


                | Parameters:


        """
        return self.functionaldescription.Actions

    @property
    def actions_groups(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActionsGroups
                | o Property ActionsGroups(    ) As FunctActionsGroups
                | 
                | Get the ActionsGroups collection.


                | Parameters:


        """
        return self.functionaldescription.ActionsGroups

    @property
    def objects(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Objects
                | o Property Objects(    ) As FunctionalObjects
                | 
                | Get the Objects collection.


                | Parameters:


        """
        return self.functionaldescription.Objects

    @property
    def variants(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Variants
                | o Property Variants(    ) As FunctionalVariants
                | 
                | Get the Variants collection.  (gives a NULL pointer if the description
                | is a itself variant)


                | Parameters:


        """
        return self.functionaldescription.Variants

    def create_position(self, i_x, i_y):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreatePosition
                | o Func CreatePosition(    double    iX,
                |                           double    iY) As FunctionalPosition
                | 
                | Create a Position.  To create actions pointing to NULL


                | Parameters:


        """
        return self.functionaldescription.CreatePosition(i_x, i_y)

    def get_facet(self, i_fm):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFacet
                | o Func GetFacet(    FunctionalFacetMgr    iFM) As FunctionalFacet
                | 
                | Returns the Facet.


                | Parameters:


        """
        return self.functionaldescription.GetFacet(i_fm)

    def get_facet_by_name(self, i_fm):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFacetByName
                | o Func GetFacetByName(    CATBSTR    iFM) As FunctionalFacet
                | 
                | Returns the Facet.


                | Parameters:


        """
        return self.functionaldescription.GetFacetByName(i_fm)

    def search_facet(self, i_fm, i_create_if_necessary):
        """
        .. note::
            CAA V5 Visual Basic help

                | SearchFacet
                | o Func SearchFacet(    FunctionalFacetMgr    iFM,
                |                        boolean    iCreateIfNecessary) As FunctionalFacet
                | 
                | Searches the Facet.


                | Parameters:


        """
        return self.functionaldescription.SearchFacet(i_fm, i_create_if_necessary)

    def search_facet_by_name(self, i_fm, i_create_if_necessary):
        """
        .. note::
            CAA V5 Visual Basic help

                | SearchFacetByName
                | o Func SearchFacetByName(    CATBSTR    iFM,
                |                              boolean    iCreateIfNecessary) As FunctionalFacet
                | 
                | Searches the Facet.


                | Parameters:


        """
        return self.functionaldescription.SearchFacetByName(i_fm, i_create_if_necessary)

    def unlock(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Unlock
                | o Sub Unlock(    )
                | 
                | Unlock.  To remove the protection against modifications.


                | Parameters:


        """
        return self.functionaldescription.Unlock()

