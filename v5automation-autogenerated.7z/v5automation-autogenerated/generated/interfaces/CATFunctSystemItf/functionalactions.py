#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalActions:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a collection of FunctionalActions.

    """

    def __init__(self, catia):
        self.functionalactions = catia.FunctionalActions     

    def create(self, i_name, i_from, i_to):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create
                | o Func Create(    CATBSTR    iName,
                |                   FunctionalPosition    iFrom,
                |                   FunctionalPosition    iTo) As FunctionalAction
                | 
                | Create a FunctionalAction.


                | Parameters:


        """
        return self.functionalactions.Create(i_name, i_from, i_to)

    def delete(self, i_action):
        """
        .. note::
            CAA V5 Visual Basic help

                | Delete
                | o Sub Delete(    FunctionalAction    iAction)
                | 
                | Delete a FunctionalAction.


                | Parameters:


        """
        return self.functionalactions.Delete(i_action)

    def elem(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Elem
                | o Func Elem(    CATVariant    iIndex) As FunctionalAction
                | 
                | Returns an action using its index or its name from the actions
                | collection.


                | Parameters:
                | iIndex
                |    The index or the name of the action to retrieve from
                |    the collection of actions.
                |    As a numerics, this index is the rank of the action
                |    in the collection.
                |    The index of the first action in the collection is 1, and
                |    the index of the last action is Count.
                |    As a string, it is the name you assigned to the action using
                |    the 
                | 
                |  activateLinkAnchor('AnyObject','Name','AnyObject.Name')  property. 
                |    Returns:
                |   The retrieved action


                | Examples:
                | 
                | 
                | This example retrieves in Act1 the fifth action
                | in the collection and in Act2 the action
                | named Moves.
                | 
                | Dim Act1 As FunctionalAction
                | Set Act1 = Desc.Action(5)
                | Dim Act2 As FunctionalAction
                | Set Act2 = Desc.Action("Moves")
                | 
                | 
                | 
        """
        return self.functionalactions.Elem(i_index)

