#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalVariant:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional Variant.

    """

    def __init__(self, catia):
        self.functionalvariant = catia.FunctionalVariant     

    @property
    def original_description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OriginalDescription
                | o Property OriginalDescription(    ) As FunctionalDescription
                | 
                | Returns the Original Description the Variant comes from.


                | Parameters:


        """
        return self.functionalvariant.OriginalDescription

