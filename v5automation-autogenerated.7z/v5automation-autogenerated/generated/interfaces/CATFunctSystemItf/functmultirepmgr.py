#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctMultiRepMgr:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional Multi-Rep manager.

    """

    def __init__(self, catia):
        self.functmultirepmgr = catia.FunctMultiRepMgr     

    @property
    def associations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Associations
                | o Property Associations(    ) As FunctAssociations
                | 
                | Get the Associations collection.


                | Parameters:


        """
        return self.functmultirepmgr.Associations

    @property
    def current_assoc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentAssoc
                | o Property CurrentAssoc(    ) As long
                | 
                | Get the CurrentAssoc.


                | Parameters:


        """
        return self.functmultirepmgr.CurrentAssoc

