#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalObjectProxy:
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Functional ObjectProxy.

    """

    def __init__(self, catia):
        self.functionalobjectproxy = catia.FunctionalObjectProxy     

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As FunctionalDescription
                | 
                | Get the description attached to the proxi.


                | Parameters:


        """
        return self.functionalobjectproxy.Description

    def set__description(self, i_desc):
        """
        .. note::
            CAA V5 Visual Basic help

                | set_Description
                | o Sub set_Description(    FunctionalDescription    iDesc)
                | 
                | set the description attached to the proxi.


                | Parameters:


        """
        return self.functionalobjectproxy.set_Description(i_desc)

