#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class FunctionalElement:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Functional Element.

    """

    def __init__(self, catia):
        self.functionalelement = catia.FunctionalElement     

    @property
    def document(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Document
                | o Property Document(    ) As FunctionalDocument
                | 
                | Returns the Document.


                | Parameters:


        """
        return self.functionalelement.Document

    @property
    def parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Parameters
                | o Property Parameters(    ) As Parameters
                | 
                | Returns the parameters collection.


                | Parameters:


        """
        return self.functionalelement.Parameters

