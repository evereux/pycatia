#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class IgesSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the CATIA IGES setting controller object.Role: The CATIA
                | IGES setting controller object deals with the setting attributes
                | displayed in the IGES property page. To access this property page:The
                | New Elements setting controller object can be retrieved as an item of
                | the setting controller collection using its name
                | "CAACafNewEltSettingCtrl" as follows:Dim settingControllers1 As
                | SettingControllers Set settingControllers1 = CATIA.SettingControllers
                | Dim CATIAIGESSettingAtt1 As SettingController Set CATIAIGESSettingAtt1
                | = settingControllers1.Item("CATIdeIgesSettingCtrl")

    """

    def __init__(self, catia):
        self.igessettingatt = catia.IgesSettingAtt     

    @property
    def angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Angle
                | o Property Angle(    ) As double
                | 
                | Returns or sets the Angle setting parameter value. Role: The Angle
                | setting parameter manages the maximal angle of deformation.


                | Parameters:
                | oAngle
                |  [out]   The Angle parameter value
                |    Legal values: value of angle in degree, between 0.0 and 10.0 deg.


        """
        return self.igessettingatt.Angle

    @property
    def apply_join(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyJoin
                | o Property ApplyJoin(    ) As long
                | 
                | Returns or sets the Apply join setting parameter value. Role: The XXX
                | setting parameter manages the Apply Join mode


                | Parameters:
                | oApplyJoin
                |  [out]   The Apply join parameter value
                |    Legal values: 1 To Apply Join on faces, 0 otherwise.


        """
        return self.igessettingatt.ApplyJoin

    @property
    def author_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AuthorName
                | o Property AuthorName(    ) As CATBSTR
                | 
                | Returns or sets the Author Name setting parameter value. Role: The
                | Author Name setting parameter manages the Author Name.


                | Parameters:
                | oAuthorName
                |  [out]   The Author Name parameter value
                |    Legal values: (any text).


        """
        return self.igessettingatt.AuthorName

    @property
    def author_organization(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AuthorOrganization
                | o Property AuthorOrganization(    ) As CATBSTR
                | 
                | Returns or sets the Author Organization setting parameter value. Role:
                | The Author Organization setting parameter manages the Author
                | Organization.


                | Parameters:
                | oAuthorOrganization
                |  [out]   The Author Organization parameter value
                |    Legal values: (any text).


        """
        return self.igessettingatt.AuthorOrganization

    @property
    def crv_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CrvMod
                | o Property CrvMod(    ) As long
                | 
                | Returns or sets the Export BSpline mode setting parameter value. Role:
                | The Export BSpline mode setting parameter manages the mode to export
                | curves and surfaces


                | Parameters:
                | oCrvMod
                |  [out]   The Export BSpline mode parameter value
                |    Legal values: 0 for standard mode;
                |    1 for BSpline mode : all curves and surfaces will be exported as B-Spline curves and surfaces.


        """
        return self.igessettingatt.CrvMod

    @property
    def export_msbo(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportMSBO
                | o Property ExportMSBO(    ) As long
                | 
                | Returns or sets the Export Solid Mode setting parameter value. Role:
                | The Export Solid Mode setting parameter manages the export of solids
                | and shells


                | Parameters:
                | oExportMSBO
                |  [out]   The Export Solid Mode parameter value
                |    Legal values: 1 to export solids and shells as 186/514 IGES entities, 0 to export them as trimmed surfaces.


        """
        return self.igessettingatt.ExportMSBO

    @property
    def export_unit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportUnit
                | o Property ExportUnit(    ) As long
                | 
                | Returns or sets the Export Units setting parameter value. Role: The
                | Export Units setting parameter manages the unit in exported IGES
                | Files.


                | Parameters:
                | oExportUnit
                |  [out]   The Export Units parameter value
                |    Legal values: 0-10 :
                |     0 : user unit;
                |     1 : Inches;
                |     2 : Millimeters;
                |     3 : Feet;
                |     4 : Miles;
                |     5 : Meters;
                |     6 : Kilometers;
                |     7 : Mils;
                |     8 : Microns;
                |     9 : Centimeters;
                |    10 : Microinches.


        """
        return self.igessettingatt.ExportUnit

    @property
    def import_group_as_sel_set(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImportGroupAsSelSet
                | o Property ImportGroupAsSelSet(    ) As long
                | 
                | Returns or sets the Import Selection Set mode setting parameter value.
                | Role: The Import Selection Set mode setting parameter manages the
                | Import of IGES groups.


                | Parameters:
                | oImportGroupAsSelSet
                |  [out]   The Import Selection Set mode parameter value
                |    Legal values: 1 To map IGES Groups as Selection Sets, 0 otherwise.


        """
        return self.igessettingatt.ImportGroupAsSelSet

    @property
    def only_show(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OnlyShow
                | o Property OnlyShow(    ) As long
                | 
                | Returns or sets the Export only show setting parameter value. Role:
                | The Export only show setting parameter manages the mode to export
                | entities in No-Show


                | Parameters:
                | oOnlyShow
                |  [out]   The Export only show parameter value
                |    Legal values: 1 to export only visible elements, 0 to export visible and invisible elements.


        """
        return self.igessettingatt.OnlyShow

    @property
    def opt_c2_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptC2Mode
                | o Property OptC2Mode(    ) As long
                | 
                | Returns or sets the Continuity Optimization Mode setting parameter
                | value. Role: The Continuity Optimization Mode setting parameter
                | manages the ...


                | Parameters:
                | oOptC2Mode
                |  [out]   The Continuity Optimization Mode parameter value
                |    Legal values: 0 to Disable Optimize Continuity ;
                |                             1 to Enable default Optimize Continuity
                |                             2 to Enable Advanced Optimize Continuity.


        """
        return self.igessettingatt.OptC2Mode

    @property
    def opt_clean_topo_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptCleanTopoMode
                | o Property OptCleanTopoMode(    ) As long
                | 
                | Returns or sets the clean topo mode setting parameter value. Role: The
                | clean topo mode setting parameter manages the the Fitting Mode, in
                | Advanced Optimize Continuity Mode.


                | Parameters:
                | oOptCleanTopoMode
                |  [out]   The clean topo mode parameter value
                |    Legal values: 0 to Disable the clean topo Mode, 1 to Enable the clean topo Mode.


        """
        return self.igessettingatt.OptCleanTopoMode

    @property
    def opt_fitting_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptFittingMode
                | o Property OptFittingMode(    ) As long
                | 
                | Returns or sets the Fitting Mode setting parameter value. Role: The
                | Fitting Mode setting parameter manages the Fitting Mode, in Advanced
                | Optimize Continuity Mode.


                | Parameters:
                | oOptFittingMode
                |  [out]   The Fitting Mode parameter value
                |    Fitting Mode values: 0 to Disable the Fitting Mode, 1 to Enable the Fitting Mode.


        """
        return self.igessettingatt.OptFittingMode

    @property
    def opt_invalid_geom_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptInvalidGeomMode
                | o Property OptInvalidGeomMode(    ) As long
                | 
                | Returns or sets the InvalidGeom mode setting parameter value. Role:
                | The InvalidGeom mode setting parameter manages the Invalid Geometry
                | Checks.


                | Parameters:
                | oOptInvalidGeomMode
                |  [out]   The InvalidGeom mode parameter value
                |    Legal values: 0 to disable Invalid Geometry Checks, 1 to enable it.


        """
        return self.igessettingatt.OptInvalidGeomMode

    @property
    def opt_loop_3d_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptLoop3DMode
                | o Property OptLoop3DMode(    ) As long
                | 
                | Returns or sets the Force 3D Loop setting parameter value. Role: The
                | Force 3D Loop setting parameter manages the Import of IGES boundaries,
                | to use only the 3D representation.


                | Parameters:
                | oOptLoop3DMode
                |  [out]   The Force 3D Loop parameter value
                |    Legal values: 0 to keep file preference, 1 to Force the use of 3D representation.


        """
        return self.igessettingatt.OptLoop3DMode

    @property
    def part_prod_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartProdMode
                | o Property PartProdMode(    ) As long
                | 
                | Returns or sets the Import Product mode setting parameter value. Role:
                | The Import Product mode setting parameter manages the Product mode for
                | Import of 308/408 IGES entities.


                | Parameters:
                | oPartProdMode
                |  [out]   The Import Product mode parameter value
                |    Legal values: 0 to import 308/408 in a CATPart, 1 to create a Product Structure.


        """
        return self.igessettingatt.PartProdMode

    @property
    def rep_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RepMod
                | o Property RepMod(    ) As long
                | 
                | Returns or sets the Export representation mode setting parameter
                | value. Role: The Export representation mode setting parameter manages
                | the export of faces as surfaces or as wireframe.


                | Parameters:
                | oRepMod
                |  [out]   The Export representation mode parameter value
                |    Legal values: 1 to export surfaces as wireframes, 0 otherwise.


        """
        return self.igessettingatt.RepMod

    @property
    def show_completion_dialog_box(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShowCompletionDialogBox
                | o Property ShowCompletionDialogBox(    ) As long
                | 
                | Returns or sets the Show/No Show dialog box setting parameter value.
                | Role: The Show/No Show dialog box setting parameter manages the
                | visibility of the Completion dialog box. Legal values: 1 to show, and
                | 0 to hide the Show/No Show dialog box.


                | Parameters:


        """
        return self.igessettingatt.ShowCompletionDialogBox

    @property
    def tol_join(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TolJoin
                | o Property TolJoin(    ) As double
                | 
                | Returns or sets the join tolerance setting parameter value. Role: The
                | join tolerance setting parameter manages the Tolerance for Join


                | Parameters:
                | oTolJoin
                |  [out]   The join tolerance parameter value
                |    Legal values: Value of tolerance in mm, between 0.0 and 0.1 mm.


        """
        return self.igessettingatt.TolJoin

    @property
    def tol_opt_invalid_geom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TolOptInvalidGeom
                | o Property TolOptInvalidGeom(    ) As double
                | 
                | Returns or sets the InvalidGeom Tolerance setting parameter value.
                | Role: The InvalidGeom Tolerance setting parameter manages the
                | Tolerance for invalid geometry checks.


                | Parameters:
                | oTolOptInvalidGeom
                |  [out]   The InvalidGeom Tolerance parameter value
                |    Legal values: value of tolerance, in mm, between 0.5 and 20 mm.


        """
        return self.igessettingatt.TolOptInvalidGeom

    @property
    def tolerance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Tolerance
                | o Property Tolerance(    ) As double
                | 
                | Returns or sets the tolerance ( optimize - fitting ) setting parameter
                | value. Role: The tolerance ( optimize - fitting ) setting parameter
                | manages the tolerance for Optimize continuity and Fitting.


                | Parameters:
                | oTolerance
                |  [out]   The tolerance ( optimize - fitting ) parameter value
                |    Legal values: value of tolerance in mm, between 0.0005 and 0.10 mm.


        """
        return self.igessettingatt.Tolerance

    def get_angle_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAngleInfo
                | o Func GetAngleInfo(    CATBSTR    ioAdminLevel,
                |                         CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Angle setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetAngleInfo(io_admin_level, io_locked)

    def get_apply_join_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetApplyJoinInfo
                | o Func GetApplyJoinInfo(    CATBSTR    ioAdminLevel,
                |                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Apply Join setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetApplyJoinInfo(io_admin_level, io_locked)

    def get_author_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAuthorNameInfo
                | o Func GetAuthorNameInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AuthorName parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetAuthorNameInfo(io_admin_level, io_locked)

    def get_author_organization_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAuthorOrganizationInfo
                | o Func GetAuthorOrganizationInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AuthorOrganization
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetAuthorOrganizationInfo(io_admin_level, io_locked)

    def get_crv_mod_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCrvModInfo
                | o Func GetCrvModInfo(    CATBSTR    ioAdminLevel,
                |                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Export BSpline mode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetCrvModInfo(io_admin_level, io_locked)

    def get_export_msbo_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportMSBOInfo
                | o Func GetExportMSBOInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Export Solid Mode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetExportMSBOInfo(io_admin_level, io_locked)

    def get_export_unit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportUnitInfo
                | o Func GetExportUnitInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Export Units setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetExportUnitInfo(io_admin_level, io_locked)

    def get_import_group_as_sel_set_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetImportGroupAsSelSetInfo
                | o Func GetImportGroupAsSelSetInfo(    CATBSTR    ioAdminLevel,
                |                                       CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Import Selection Set mode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetImportGroupAsSelSetInfo(io_admin_level, io_locked)

    def get_only_show_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOnlyShowInfo
                | o Func GetOnlyShowInfo(    CATBSTR    ioAdminLevel,
                |                            CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Export only show setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetOnlyShowInfo(io_admin_level, io_locked)

    def get_opt_c2_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptC2ModeInfo
                | o Func GetOptC2ModeInfo(    CATBSTR    ioAdminLevel,
                |                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Continuity Optimization Mode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetOptC2ModeInfo(io_admin_level, io_locked)

    def get_opt_clean_topo_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptCleanTopoModeInfo
                | o Func GetOptCleanTopoModeInfo(    CATBSTR    ioAdminLevel,
                |                                    CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Clean Topo Mode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetOptCleanTopoModeInfo(io_admin_level, io_locked)

    def get_opt_fitting_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptFittingModeInfo
                | o Func GetOptFittingModeInfo(    CATBSTR    ioAdminLevel,
                |                                  CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Fitting Mode setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetOptFittingModeInfo(io_admin_level, io_locked)

    def get_opt_invalid_geom_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptInvalidGeomModeInfo
                | o Func GetOptInvalidGeomModeInfo(    CATBSTR    ioAdminLevel,
                |                                      CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the InvalidGeom mode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetOptInvalidGeomModeInfo(io_admin_level, io_locked)

    def get_opt_loop_3d_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptLoop3DModeInfo
                | o Func GetOptLoop3DModeInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Force 3D Loop setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetOptLoop3DModeInfo(io_admin_level, io_locked)

    def get_part_prod_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPartProdModeInfo
                | o Func GetPartProdModeInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Import Product mode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetPartProdModeInfo(io_admin_level, io_locked)

    def get_rep_mod_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRepModInfo
                | o Func GetRepModInfo(    CATBSTR    ioAdminLevel,
                |                          CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Export representation mode setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetRepModInfo(io_admin_level, io_locked)

    def get_show_completion_dialog_box_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShowCompletionDialogBoxInfo
                | o Func GetShowCompletionDialogBoxInfo(    CATBSTR    ioAdminLevel,
                |                                           CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Show/No Show dialog box setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetShowCompletionDialogBoxInfo(io_admin_level, io_locked)

    def get_tol_join_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTolJoinInfo
                | o Func GetTolJoinInfo(    CATBSTR    ioAdminLevel,
                |                           CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the join tolerance setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetTolJoinInfo(io_admin_level, io_locked)

    def get_tol_opt_invalid_geom_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTolOptInvalidGeomInfo
                | o Func GetTolOptInvalidGeomInfo(    CATBSTR    ioAdminLevel,
                |                                     CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the InvalidGeom Tolerance setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetTolOptInvalidGeomInfo(io_admin_level, io_locked)

    def get_tolerance_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetToleranceInfo
                | o Func GetToleranceInfo(    CATBSTR    ioAdminLevel,
                |                             CATBSTR    ioLocked) As boolean
                | 
                | Retrieves information about the Tolerance  ( optimize - fitting )
                | setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.GetToleranceInfo(io_admin_level, io_locked)

    def set_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAngleLock
                | o Sub SetAngleLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Angle setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetAngleLock(i_locked)

    def set_apply_join_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetApplyJoinLock
                | o Sub SetApplyJoinLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Apply Join setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetApplyJoinLock(i_locked)

    def set_author_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAuthorNameLock
                | o Sub SetAuthorNameLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AuthorName parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetAuthorNameLock(i_locked)

    def set_author_organization_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAuthorOrganizationLock
                | o Sub SetAuthorOrganizationLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AuthorOrganization parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetAuthorOrganizationLock(i_locked)

    def set_crv_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCrvModLock
                | o Sub SetCrvModLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Export BSpline mode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetCrvModLock(i_locked)

    def set_export_msbo_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportMSBOLock
                | o Sub SetExportMSBOLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Export Solid Mode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetExportMSBOLock(i_locked)

    def set_export_unit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportUnitLock
                | o Sub SetExportUnitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Export Units setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetExportUnitLock(i_locked)

    def set_import_group_as_sel_set_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetImportGroupAsSelSetLock
                | o Sub SetImportGroupAsSelSetLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Import Selection Set mode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetImportGroupAsSelSetLock(i_locked)

    def set_only_show_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOnlyShowLock
                | o Sub SetOnlyShowLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Export only show setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetOnlyShowLock(i_locked)

    def set_opt_c2_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptC2ModeLock
                | o Sub SetOptC2ModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Continuity Optimizationmode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetOptC2ModeLock(i_locked)

    def set_opt_clean_topo_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptCleanTopoModeLock
                | o Sub SetOptCleanTopoModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Clean Topo Mode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetOptCleanTopoModeLock(i_locked)

    def set_opt_fitting_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptFittingModeLock
                | o Sub SetOptFittingModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Fitting Mode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetOptFittingModeLock(i_locked)

    def set_opt_invalid_geom_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptInvalidGeomModeLock
                | o Sub SetOptInvalidGeomModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the InvalidGeom mode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetOptInvalidGeomModeLock(i_locked)

    def set_opt_loop_3d_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptLoop3DModeLock
                | o Sub SetOptLoop3DModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Force 3D Loop setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetOptLoop3DModeLock(i_locked)

    def set_part_prod_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPartProdModeLock
                | o Sub SetPartProdModeLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Import Product mode setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetPartProdModeLock(i_locked)

    def set_rep_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRepModLock
                | o Sub SetRepModLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Export representation mode setting parameter.
                | Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetRepModLock(i_locked)

    def set_show_completion_dialog_box_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShowCompletionDialogBoxLock
                | o Sub SetShowCompletionDialogBoxLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Show/No Show dialog box setting parameter. Refer
                | to  activateLinkAnchor('SettingController','','SettingController')
                | for a detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetShowCompletionDialogBoxLock(i_locked)

    def set_tol_join_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTolJoinLock
                | o Sub SetTolJoinLock(    boolean    iLocked)
                | 
                | Locks or unlocks the join tolerance setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetTolJoinLock(i_locked)

    def set_tol_opt_invalid_geom_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTolOptInvalidGeomLock
                | o Sub SetTolOptInvalidGeomLock(    boolean    iLocked)
                | 
                | Locks or unlocks the InvalidGeom Tolerance setting parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetTolOptInvalidGeomLock(i_locked)

    def set_tolerance_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetToleranceLock
                | o Sub SetToleranceLock(    boolean    iLocked)
                | 
                | Locks or unlocks the Tolerance  ( optimize - fitting ) setting
                | parameter. Refer to
                | activateLinkAnchor('SettingController','','SettingController')  for a
                | detailed description.


                | Parameters:


        """
        return self.igessettingatt.SetToleranceLock(i_locked)

