#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DevAnalysisSettingAtt:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to handle parameters of Infrastructure-DELMIA
                | Infrastructure-Device Analysis Tools Options Tab page.Role: This
                | interface is implemented by a component which  represents the
                | controller of Device Analysis Tools Options parameter settings.Here is
                | the list of parameters to use and their meaning:

    """

    def __init__(self, catia):
        self.devanalysissettingatt = catia.DevAnalysisSettingAtt     

    @property
    def accel_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AccelColor
                | o Property AccelColor(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the AccelColor parameter.  Ensure consistency with the
                | C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.devanalysissettingatt.AccelColor

    @property
    def accel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AccelLimit
                | o Property AccelLimit(    ) As DNBAnalysisLevel
                | 
                | Returns or sets the AccelLimit parameter.  Ensure consistency with the
                | C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.devanalysissettingatt.AccelLimit

    @property
    def caution_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CautionColor
                | o Property CautionColor(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the CautionColor parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.devanalysissettingatt.CautionColor

    @property
    def caution_zone(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CautionZone
                | o Property CautionZone(    ) As DNBAnalysisLevel
                | 
                | Returns or sets the CautionZone parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.devanalysissettingatt.CautionZone

    @property
    def travel_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TravelColor
                | o Property TravelColor(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the TravelColor parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.devanalysissettingatt.TravelColor

    @property
    def travel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TravelLimit
                | o Property TravelLimit(    ) As DNBAnalysisLevel
                | 
                | Returns or sets the TravelLimit parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.devanalysissettingatt.TravelLimit

    @property
    def velocity_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VelocityColor
                | o Property VelocityColor(    ) As CATSafeArrayVariant
                | 
                | Returns or sets the VelocityColor parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.devanalysissettingatt.VelocityColor

    @property
    def velocity_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VelocityLimit
                | o Property VelocityLimit(    ) As DNBAnalysisLevel
                | 
                | Returns or sets the VelocityLimit parameter.  Ensure consistency with
                | the C++ interface to which the work is delegated.


                | Parameters:


        """
        return self.devanalysissettingatt.VelocityLimit

    def get_accel_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAccelColorInfo
                | o Func GetAccelColorInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AccelColor parameter.
                | Role:Retrieves the state of the AccelColor parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.devanalysissettingatt.GetAccelColorInfo(io_admin_level, io_locked)

    def get_accel_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAccelLimitInfo
                | o Func GetAccelLimitInfo(    CATBSTR    ioAdminLevel,
                |                              CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the AccelLimit parameter.
                | Role:Retrieves the state of the AccelLimit parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.devanalysissettingatt.GetAccelLimitInfo(io_admin_level, io_locked)

    def get_caution_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCautionColorInfo
                | o Func GetCautionColorInfo(    CATBSTR    ioAdminLevel,
                |                                CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the CautionColor parameter.
                | Role:Retrieves the state of the CautionColor parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.devanalysissettingatt.GetCautionColorInfo(io_admin_level, io_locked)

    def get_caution_zone_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCautionZoneInfo
                | o Func GetCautionZoneInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the CautionZone parameter.
                | Role:Retrieves the state of the CautionZone parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.devanalysissettingatt.GetCautionZoneInfo(io_admin_level, io_locked)

    def get_travel_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTravelColorInfo
                | o Func GetTravelColorInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TravelColor parameter.
                | Role:Retrieves the state of the TravelColor parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.devanalysissettingatt.GetTravelColorInfo(io_admin_level, io_locked)

    def get_travel_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTravelLimitInfo
                | o Func GetTravelLimitInfo(    CATBSTR    ioAdminLevel,
                |                               CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the TravelLimit parameter.
                | Role:Retrieves the state of the TravelLimit parameter  in the current
                | environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.devanalysissettingatt.GetTravelLimitInfo(io_admin_level, io_locked)

    def get_velocity_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetVelocityColorInfo
                | o Func GetVelocityColorInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the VelocityColor parameter.
                | Role:Retrieves the state of the VelocityColor parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.devanalysissettingatt.GetVelocityColorInfo(io_admin_level, io_locked)

    def get_velocity_limit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetVelocityLimitInfo
                | o Func GetVelocityLimitInfo(    CATBSTR    ioAdminLevel,
                |                                 CATBSTR    ioLocked) As boolean
                | 
                | Retrieves environment informations for the VelocityLimit parameter.
                | Role:Retrieves the state of the VelocityLimit parameter  in the
                | current environment.


                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |   If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.


        """
        return self.devanalysissettingatt.GetVelocityLimitInfo(io_admin_level, io_locked)

    def set_accel_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAccelColorLock
                | o Sub SetAccelColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AccelColor parameter. Role:Locks or unlocks the
                | AccelColor parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.devanalysissettingatt.SetAccelColorLock(i_locked)

    def set_accel_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAccelLimitLock
                | o Sub SetAccelLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the AccelLimit parameter. Role:Locks or unlocks the
                | AccelLimit parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.devanalysissettingatt.SetAccelLimitLock(i_locked)

    def set_caution_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCautionColorLock
                | o Sub SetCautionColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the CautionColor parameter. Role:Locks or unlocks the
                | CautionColor parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.devanalysissettingatt.SetCautionColorLock(i_locked)

    def set_caution_zone_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCautionZoneLock
                | o Sub SetCautionZoneLock(    boolean    iLocked)
                | 
                | Locks or unlocks the CautionZone parameter. Role:Locks or unlocks the
                | CautionZone parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.devanalysissettingatt.SetCautionZoneLock(i_locked)

    def set_travel_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTravelColorLock
                | o Sub SetTravelColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TravelColor parameter. Role:Locks or unlocks the
                | TravelColor parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.devanalysissettingatt.SetTravelColorLock(i_locked)

    def set_travel_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTravelLimitLock
                | o Sub SetTravelLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the TravelLimit parameter. Role:Locks or unlocks the
                | TravelLimit parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.devanalysissettingatt.SetTravelLimitLock(i_locked)

    def set_velocity_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVelocityColorLock
                | o Sub SetVelocityColorLock(    boolean    iLocked)
                | 
                | Locks or unlocks the VelocityColor parameter. Role:Locks or unlocks
                | the VelocityColor parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.devanalysissettingatt.SetVelocityColorLock(i_locked)

    def set_velocity_limit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVelocityLimitLock
                | o Sub SetVelocityLimitLock(    boolean    iLocked)
                | 
                | Locks or unlocks the VelocityLimit parameter. Role:Locks or unlocks
                | the VelocityLimit parameter if it is possible in the current
                | administrative context. In user mode this method will always return
                | E_FAIL.


                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.


        """
        return self.devanalysissettingatt.SetVelocityLimitLock(i_locked)

