#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DeviceSim:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface allowing simulation of a Device.Role: This interface is used
                | to simulate the devices that are available  in the Device Building
                | workbench.  This includes devices created in both V5 and D5.The
                | following code snippet can be used to obtain a device in a CATProduct
                | document.Dim objDeviceSim As DeviceSim   Set objDeviceSim =
                | CATIA.ActiveDocument.Product.GetTechnologicalObject("DeviceSim")

    """

    def __init__(self, catia):
        self.devicesim = catia.DeviceSim     

    def finalize(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Finalize
                | o Sub Finalize(    )
                | 
                | Cleans the WDM world.  Please note that no refrence counting will be
                | maintained.       Cleanup should be done on each device before another
                | device is Initialized  Returns:   an HRESULT value.    Example:
                | Dim objDeviceSim As DeviceSim   Set objDeviceSim =
                | CATIA.ActiveDocument.Product.GetTechnologicalObject("DeviceSim")
                | objDeviceSim.Initialize   ...   objDevice.Finalize


                | Parameters:


        """
        return self.devicesim.Finalize()

    def get_dof_values(self, i_mechanism):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDOFValues
                | o Func GetDOFValues(    CATBaseDispatch    iMechanism) As CATSafeArrayVariant
                | 
                | Get the DOF values for the device.


                | Parameters:
                | iMechanism
                |    This inner parameter contains a handle to the mechanism
                |  
                |  oValues
                |    This outer parameter contains a list of the current DOF values.
                |    Please note that distances are measured in meters and
                |    angles in radians.
                |  
                | 
                |  Returns:
                |    an HRESULT value.


                | Examples:
                | 
                | 
                | Dim  ListMechanisms  As Mechanisms
                | Set  ListMechanisms  =  CATIA.ActiveDocument.Product.GetTechnologicalObject("Mechanisms")
                | On Error Resume Next
                | Dim mech
                | Set mech = ListMechanisms.Item(1)
                | If Err.Number <> 0 Then
                | 'If there are no mechanisms (i.e. D5 devices), use the device sim handle instead
                | Set mech = CATIA.ActiveDocument.Product.GetTechnologicalObject("DeviceSim")
                | End If
                | On Error GoTo 0
                | 
                | Dim objDeviceSim As DeviceSim
                | Set objDeviceSim = CATIA.ActiveDocument.Product.GetTechnologicalObject("DeviceSim")
                | objDeviceSim.Initialize
                | 
                | Dim ListOfDOFValues
                | ListOfDOFValues = objDevice.GetDOFValues (mech)
                | ...
                | 
                | 
                | 
        """
        return self.devicesim.GetDOFValues(i_mechanism)

    def initialize(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Initialize
                | o Sub Initialize(    )
                | 
                | Initializes the WDM world.  Required for calls to Get/SetDOFValues
                | Returns:   an HRESULT value.    Example:         Dim objDeviceSim As
                | DeviceSim   Set objDeviceSim =
                | CATIA.ActiveDocument.Product.GetTechnologicalObject("DeviceSim")
                | objDeviceSim.Initialize


                | Parameters:


        """
        return self.devicesim.Initialize()

    def set_dof_values(self, i_mechanism, i_values, i_is_relative):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDOFValues
                | o Sub SetDOFValues(    CATBaseDispatch    iMechanism,
                |                        CATSafeArrayVariant    iValues,
                |                        boolean    iIsRelative)
                | 
                | Set the DOF values for the device.


                | Parameters:
                | iValues
                |    This inner parameter contains a list of the DOF values to be applied. Size of iValues should
                |    be equal to the number of DOFs. Please note that distances are measured in meters and
                |    angles in radians.
                |  
                |  iMechanism
                |    This inner parameter contains a handle to the mechanism. For D5 devices the device itself 
                |    should be used as the mechanism (sample below)
                |  
                |  iIsRelative
                |    This inner parameter indicates if iValues is relative to the existing DOF values.
                |    If set to TRUE, iValues will be added to the existing values
                |  
                | 
                |  Returns:
                |    an HRESULT value.


                | Examples:
                | 
                | 
                | 
                | Dim  ListMechanisms  As Mechanisms
                | Set  ListMechanisms  =  CATIA.ActiveDocument.Product.GetTechnologicalObject("Mechanisms")
                | On Error Resume Next
                | Dim mech
                | Set mech = ListMechanisms.Item(1)
                | If Err.Number <> 0 Then
                | 'If there are no mechanisms (i.e. D5 devices), use the device handle instead
                | Set mech = CATIA.ActiveDocument.Product.GetTechnologicalObject("DeviceSim")
                | End If
                | On Error GoTo 0
                | 
                | Dim objDeviceSim As DeviceSim
                | Set objDeviceSim = CATIA.ActiveDocument.Product.GetTechnologicalObject("DeviceSim")
                | objDeviceSim.Initialize
                | Dim ListOfDOFValues (5)
                | 'Populate ListOfDOFValues with some values
                | ...
                | objDevice.SetDOFValues mech, ListOfDOFValues, TRUE
                | ...
                | 
                | 
                | 
        """
        return self.devicesim.SetDOFValues(i_mechanism, i_values, i_is_relative)

