#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class BasicDevice:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing a Basic Device.Role: This interface is used to
                | interact with devices that are available  in the Device Building
                | workbench.  This includes devices created in both V5 and D5.The
                | following code snippet can be used to obtain a device in a CATProduct
                | document.Dim objDevice As BasicDevice   set objDevice =
                | CATIA.ActiveDocument.Product.GetTechnologicalObject("BasicDevice")

    """

    def __init__(self, catia):
        self.basicdevice = catia.BasicDevice     

    def get_dof_values(self, o_values):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDOFValues
                | o Sub GetDOFValues(    CATSafeArrayVariant    oValues)
                | 
                | Get the DOF values for the device.


                | Parameters:
                | oValues
                |    This contains a list of the current DOF values.
                |    Please note that distances are measured in meters and
                |    angles in radians.


                | Examples:
                | 
                | 
                | Dim objDevice As BasicDevice
                | set objDevice = CATIA.ActiveDocument.Product.GetTechnologicalObject("BasicDevice")
                | Dim ListOfDOFValues ()
                | objDevice.GetDOFValues ListOfDOFValues
                | For i = 0 to ubound (ListOfDOFValues)
                | ...
                | Next
                | 
                | 
                | 
        """
        return self.basicdevice.GetDOFValues(o_values)

    def get_home_positions(self, o_home_pos_list):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHomePositions
                | o Sub GetHomePositions(    CATSafeArrayVariant    oHomePosList)
                | 
                | Get list of home positions of the device.


                | Parameters:
                | oHomePosList
                |    This outer parameter contains list of home position .    
                |  
                | 
                |  Returns:
                |      An HRESULT


        """
        return self.basicdevice.GetHomePositions(o_home_pos_list)

    def set_home_position(self, i_name, idb_trans):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHomePosition
                | o Sub SetHomePosition(    CATBSTR    iName,
                |                           CATSafeArrayVariant    idbTrans)
                | 
                | Set home position of the device.


                | Parameters:
                | iName
                |    This parameter contains name of home position .    
                |  
                |  idbTrans
                |    This parameter contains distance data in Meters 
                |     or angular data in degree radian.    
                |  
                | 
                |  Returns:
                |   HRESULT  indicate whether function succeed.


        """
        return self.basicdevice.SetHomePosition(i_name, idb_trans)

