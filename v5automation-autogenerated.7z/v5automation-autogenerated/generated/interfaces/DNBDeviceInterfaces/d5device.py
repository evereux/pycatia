#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class D5Device:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing a D5 Device.Role: This interface is used to
                | interact with devices that are available in the Device Building
                | workbench.  This interfaces is derived from BasicDevice to support
                | specific properties for D5 devices.The following code snippet can be
                | used to obtain a device in a CATProduct  document.Dim objDevice As
                | BasicDevice   set objDevice =
                | CATIA.ActiveDocument.Product.GetTechnologicalObject("BasicDevice")
                | Dim objD5Device as D5Device   Set objD5Device = objDevice

    """

    def __init__(self, catia):
        self.d5device = catia.D5Device     

    def get_linked_device_file(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLinkedDeviceFile
                | o Func GetLinkedDeviceFile(    ) As CATBSTR
                | 
                | Get the Linked D5 Device File.


                | Parameters:
                | oFileName
                |    This will contain the full path to the file (file name and path) to the D5 
                |    device file.


        """
        return self.d5device.GetLinkedDeviceFile()

