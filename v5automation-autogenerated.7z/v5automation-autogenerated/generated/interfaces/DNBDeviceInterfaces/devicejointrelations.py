#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class DeviceJointRelations:
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, catia):
        self.devicejointrelations = catia.DeviceJointRelations     

    def get_joint_relation_expression(self, joint, expr):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetJointRelationExpression
                | o Sub GetJointRelationExpression(    Joint    joint,
                |                                      CATBSTR    expr)
                | 
                | Get Kin expression of the given Joint.


                | Parameters:
                | joint
                |    This input parameter specify CATIAJoint interface.
                |  
                |  expr
                |    This out parameter contains kin expression assigned to 'joint'.
                |  
                | 
                |  Returns:
                |    an HRESULT value.
                |  Legal values:
                |  
                | S_OK if the operation succeeds 
                | E_FAIL otherwise .


        """
        return self.devicejointrelations.GetJointRelationExpression(joint, expr)

    def set_joint_relation_expression(self, joint, expr):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetJointRelationExpression
                | o Sub SetJointRelationExpression(    Joint    joint,
                |                                      CATBSTR    expr)
                | 
                | Set Kin expression for the given Joint.


                | Parameters:
                | joint
                |    This input parameter specifies CATIAJoint interface.
                |  
                |  profile
                |    This input parameter contains kin expression to be assigned for 'joint'.
                |  
                | 
                |  Returns:
                |    an HRESULT value.
                |  Legal values:
                |  
                | S_OK if the operation succeeds 
                | E_FAIL otherwise .


        """
        return self.devicejointrelations.SetJointRelationExpression(joint, expr)

    def set_user_variable_expr(self, user_expr):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUserVariableExpr
                | o Sub SetUserVariableExpr(    CATBSTR    user_expr)
                | 
                | Add the user-variable expression to the mechanism


                | Parameters:
                | user_expr
                |    This input parameter is an user-variable expression.
                |  
                | 
                |  Returns:
                |    an HRESULT value.
                |  Legal values:
                |  
                | S_OK if the operation succeeds 
                | E_FAIL otherwise .


        """
        return self.devicejointrelations.SetUserVariableExpr(user_expr)

