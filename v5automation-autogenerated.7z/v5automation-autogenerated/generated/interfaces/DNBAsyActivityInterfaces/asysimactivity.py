#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATVIA R25


class AsySimActivity:
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for a Delmia Simulation Activity.Currently the main focus is
                | to synchronize an activity with the  simulation world.

    """

    def __init__(self, catia):
        self.asysimactivity = catia.AsySimActivity     

    def synchronize(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Synchronize
                | o Sub Synchronize(    )
                | 
                | Updates the simulation world up to this activity. Role: Updates the
                | simulation world (and its contents) to the end of the specified
                | activity.  Please note that no animation will occur, and the execution
                | will wait for the simulation to finish before this method is complete.


                | Parameters:


        """
        return self.asysimactivity.Synchronize()

