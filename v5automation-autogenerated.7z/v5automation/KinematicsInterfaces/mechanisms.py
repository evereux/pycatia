#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class Mechanisms(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     Mechanisms
                | 
                | A collection of all Mechanism entities currently managed by the
                | application.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.mechanisms = com_object

    def add(self) -> Mechanism:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Add() As Mechanism
                | 
                |     Creates a new Mechanism and adds it to the Mechanisms
                |     collection.
                | 
                |     Returns:
                |         The created Mechanism 
                |     Example:
                |         This example creates a new Mechanism in the TheMechanisms
                |         collection.
                | 
                |             Dim NewMechanism As Mechanism
                |             Set NewMechanism = TheMechanisms.Add()

        :return: Mechanism
        :rtype: Mechanism
        """
        return Mechanism(self.mechanisms.Add())

    def item(self, i_index: CATVariant) -> Mechanism:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Item(CATVariant iIndex) As Mechanism
                | 
                |     Returns a Mechanism using its index or its name from the Mechanisms
                |     collection.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The index or the name of the Mechanism to retrieve from the
                |             collection of Mechanisms. As a numerics, this index is the rank of the
                |             Mechanism in the collection. The index of the first Mechanism in the collection
                |             is 1, and the index of the last Mechanism is Count. As a string, it is the name
                |             you assigned to the Mechanism using the 
                | 
                |         AnyObject.Name property. 
                |     Returns:
                |         The retrieved Mechanism 
                |     Example:
                |         This example returns in ThisMechanism the third Mechanism in the
                |         collection, and in ThatMechanism the Mechanism named
                |         MyMechanism.
                | 
                |          Dim ThisMechanism As Mechanism
                |          Set ThisMechanism = TheMechanisms.Item(3)
                |          Dim ThatMechanism As Mechanism
                |          Set ThatMechanism = CATIA.Mechanisms.Item("MyMechanism")

        :param CATVariant i_index:
        :return: Mechanism
        :rtype: Mechanism
        """
        return Mechanism(self.mechanisms.Item(i_index.com_object))

    def remove(self, i_index: CATVariant) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub Remove(CATVariant iIndex)
                | 
                |     Removes a Mechanism from the Mechanisms collection.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The index or the name of the Mechanism to retrieve from the
                |             collection of mechanisms. As a numerics, this index is the rank of the
                |             Mechanism in the collection. The index of the first Mechanism in the collection
                |             is 1, and the index of the last Mechanism is Count. As a string, it is the name
                |             you assigned to the Mechanism. 
                | 
                |     Returns:
                |         Nothing 
                |     Example:
                |         The following example removes the tenth Mechanism and the Mechanism
                |         named MechanismTwo from the TheMechanisms collection.
                | 
                |             TheMechanisms.Remove(10)
                |             TheMechanisms.Remove("MechanismTwo")

        :param CATVariant i_index:
        :return: None
        :rtype: None
        """
        return self.mechanisms.Remove(i_index.com_object)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'remove'
        # # vba_code = """
        # # Public Function remove(mechanisms)
        # #     Dim iIndex (2)
        # #     mechanisms.Remove iIndex
        # #     remove = iIndex
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def __repr__(self):
        return f'Mechanisms(name="{ self.name }")'
