#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.in_interfaces.workbench import Workbench


class KinematicsWorkbench(Workbench):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     InfInterfaces.Workbench
                |                         KinematicsWorkbench
                | 
                | Interface to access all Kinematics entities.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.kinematics_workbench = com_object

    @property
    def mechanisms(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Mechanisms() As Mechanisms (Read Only)
                | 
                |     Returns the Mechanisms collection.
                | 
                |     Returns:
                |         The Mechanisms collection 
                |     Example:
                |         This example retrieves the Mechanisms collection of the active
                |         document.
                | 
                |             Dim TheKinWorkbench As Workbench
                |             Set TheKinWorkbench = CATIA.ActiveDocument.GetWorkbench ( "KinematicsWorkbench" )
                |             Dim TheMechanismsList As Mechanisms
                |             Set TheMechanismsList = TheKinWorkbench.Mechanisms

        :return: Mechanisms
        """

        return Mechanisms(self.kinematics_workbench.Mechanisms)

    def __repr__(self):
        return f'KinematicsWorkbench(name="{ self.name }")'
