#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class SwkManikinPart(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     SWKManikinPart
                | 
                | This interface represents any part of the manikin that is
                | persistent.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.swk_manikin_part = com_object

    @property
    def memo(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Memo() As CATBSTR
                | 
                |     Returns or records miscellaneous user-added information about the part.

        :return: str
        """

        return self.swk_manikin_part.Memo

    @memo.setter
    def memo(self, value):
        """
        :param str value:
        """

        self.swk_manikin_part.Memo = value

    def __repr__(self):
        return f'SwkManikinPart(name="{ self.name }")'
