#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.in_interfaces.move import Move


class SwkManikin(SWKManikinPart):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     DNBHumanModelingInterfaces.SWKManikinPart
                |                         SWKManikin
                | 
                | This interface groups the methods directly related to the definition of a
                | manikin.
                | 
                | Its main purpose is to provide bridges to the other interfaces related to a
                | manikin.
                | Once these interfaces are recovered, it is possible to have access to their
                | specific functionalities.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.swk_manikin = com_object

    @property
    def anthro(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Anthro() As SWKAnthro (Read Only)
                | 
                |     Returns the anthropometry of the current manikin. The anthropometry can
                |     also be obtained by invoking method GetItem (from AnyObject) with the character
                |     string "Anthro" as an argument.

        :return: SWKAnthro
        """

        return SWKAnthro(self.swk_manikin.Anthro)

    @property
    def body(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Body() As SWKBody (Read Only)
                | 
                |     Returns the body of the current manikin. The body can also be obtained by
                |     invoking method GetItem (from AnyObject) with the character string "Body" as an
                |     argument.

        :return: SWKBody
        """

        return SWKBody(self.swk_manikin.Body)

    @property
    def body_node(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property BodyNode() As SWKSegmentNode (Read Only)
                | 
                |     Returns the body node of the current manikin. The body node is the node
                |     named "Body", as it appears underneath the manikin in the specification tree.
                |     This body node can also be obtained by invoking method GetItem (from AnyObject)
                |     with the character string "BodyNode" as an argument.

        :return: SWKSegmentNode
        """

        return SWKSegmentNode(self.swk_manikin.BodyNode)

    @property
    def ergo(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Ergo() As SWKErgo (Read Only)
                | 
                |     Returns the ergonomic analysis of the current manikin. The ergo can also be
                |     obtained by invoking method GetItem (from AnyObject) with the character string
                |     "Ergo" as an argument.

        :return: SWKErgo
        """

        return SWKErgo(self.swk_manikin.Ergo)

    @property
    def ik_manager(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property IKManager() As SWKIKManager (Read Only)
                | 
                |     Returns the inverse kinematics (IK) engine of the current manikin. The IK
                |     manager can also be obtained by invoking method GetItem (from AnyObject) with
                |     the character string "IKManager" as an argument.

        :return: SWKIKManager
        """

        return SWKIKManager(self.swk_manikin.IKManager)

    @property
    def line_of_sight_node(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property LineOfSightNode() As SWKLineOfSightNode (Read
                | Only)
                | 
                |     Returns the Line of sight node of the current manikin. The Line of sight
                |     node can also be obtained by invoking method GetItem (from AnyObject) with the
                |     character string "LineOfSightNode" as an argument.

        :return: SWKLineOfSightNode
        """

        return SWKLineOfSightNode(self.swk_manikin.LineOfSightNode)

    @property
    def move(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Move() As Move (Read Only)
                | 
                |     Returns the manikin's move object. The move object is aggregated by the
                |     manikin object and itself aggregates a movable object to which you can apply a
                |     move transformation by means of an isometry matrix. It moves the manikin's
                |     representation according to this isometry.
                | 
                |     Example:
                | 
                |           This example retrieves the move object for the
                |           manikin
                |          myManikin.
                |          
                | 
                |          Dim myManikinMoveObject As Move
                |          Set myManikinMoveObject = myManikin.Move

        :return: Move
        """

        return Move(self.swk_manikin.Move)

    @property
    def profiles_node(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property ProfilesNode() As SWKNode (Read Only)
                | 
                |     Returns the Profiles node of the current manikin. The Profiles node can
                |     also be obtained by invoking method GetItem (from AnyObject) with the character
                |     string "ProfilesNode" as an argument.

        :return: SWKNode
        """

        return SWKNode(self.swk_manikin.ProfilesNode)

    @property
    def settings_node(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property SettingsNode() As SWKNode (Read Only)
                | 
                |     Returns the settings node of the current manikin. The Settings node can
                |     also be obtained by invoking method GetItem (from AnyObject) with the character
                |     string "SettingsNode" as an argument.

        :return: SWKNode
        """

        return SWKNode(self.swk_manikin.SettingsNode)

    @property
    def vision(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Vision() As SWKVision (Read Only)
                | 
                |     Returns the vision of the current manikin. The vision can also be obtained
                |     by invoking method GetItem (from AnyObject) with the character string "Vision"
                |     as an argument.

        :return: SWKVision
        """

        return SWKVision(self.swk_manikin.Vision)

    def __repr__(self):
        return f'SwkManikin(name="{ self.name }")'
