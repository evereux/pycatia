#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""




class SwkAnthro(SWKManikinPart):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     DNBHumanModelingInterfaces.SWKManikinPart
                |                         SWKAnthro
                | 
                | This interface manages the anthropometry of the manikin.
                | It provides access to the anthropometry data (variables,
                | sex...)
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.swk_anthro = com_object

    @property
    def construction_type(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property ConstructionType() As CATBSTR
                | 
                |     Return or sets the construction type of the manikin. This property can take
                |     the following two values: "Standing" and "Sitting".
                |     If the construction is set to "Standing",
                |     then the manikin is constructed as of type 'standing'.
                |     If the construction is set to "Sitting",
                |     then the manikin is constructed as of type 'sitting'.
                | 
                |     The chosen construction type influences the way the manikin's
                |     hips,
                |     thighs and knees are constructed to reflect the changes in those
                |     body
                |     parts when a human changes from a standing to a sitting posture.

        :return: str
        """

        return self.swk_anthro.ConstructionType

    @construction_type.setter
    def construction_type(self, value):
        """
        :param str value:
        """

        self.swk_anthro.ConstructionType = value

    @property
    def gender(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Gender() As CATBSTR
                | 
                |     Returns or sets the gender of the manikin.

        :return: str
        """

        return self.swk_anthro.Gender

    @gender.setter
    def gender(self, value):
        """
        :param str value:
        """

        self.swk_anthro.Gender = value

    @property
    def interpolation_method(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property InterpolationMethod() As CATBSTR
                | 
                |     Returns or sets the interpolation. The interpolation is an
                |     algorithm
                |     that restricts the values entered by the user to a certain minimum and
                |     maximum value. Valid values are "None" or "Multinormal".

        :return: str
        """

        return self.swk_anthro.InterpolationMethod

    @interpolation_method.setter
    def interpolation_method(self, value):
        """
        :param str value:
        """

        self.swk_anthro.InterpolationMethod = value

    @property
    def limit_bound(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property LimitBound() As double
                | 
                |     Returns or sets the population accommodation, in terms of a limit
                |     bound.
                |     The population accommodation is used in the multi-normal
                |     algorithm, to calculate the limits of the automatic
                |     variables
                |     when a user-defined anthropometry is entered.
                |     The greater the population accommodation is, the wider the
                |     limits
                |     on the automatic variables will be. The value of this property must le
                |     within the range [0.0, 4.0].

        :return: float
        """

        return self.swk_anthro.LimitBound

    @limit_bound.setter
    def limit_bound(self, value):
        """
        :param float value:
        """

        self.swk_anthro.LimitBound = value

    @property
    def number_of_variables(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property NumberOfVariables() As long (Read Only)
                | 
                |     Returns the number of variables contained in this anthropometry.

        :return: int
        """

        return self.swk_anthro.NumberOfVariables

    @property
    def population(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Population() As CATBSTR
                | 
                |     Return or sets the Population of the manikin. The population provided must
                |     be one of the default populations ("American", "Canadian", "French",
                |     "Japanese", "Korean", "German" or "Chinese (Taiwan)"), or an external
                |     population defined by the user. Please note that no user-defined population
                |     should bear the name of one of the default populations.

        :return: str
        """

        return self.swk_anthro.Population

    @population.setter
    def population(self, value):
        """
        :param str value:
        """

        self.swk_anthro.Population = value

    @property
    def population_accommodation(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property PopulationAccommodation() As double
                | 
                |     Returns or sets the population accommodation. The population accommodation
                |     is used in the multi-normal
                |     algorithm, to calculate the limits of the automatic
                |     variables
                |     when a user-defined anthropometry is entered.
                |     The greater the population accommodation is, the wider the
                |     limits
                |     on the automatic variables will be. The value of this property must le
                |     within the range [0.0, 100.0].

        :return: float
        """

        return self.swk_anthro.PopulationAccommodation

    @population_accommodation.setter
    def population_accommodation(self, value):
        """
        :param float value:
        """

        self.swk_anthro.PopulationAccommodation = value

    def get_variable_at_index(self, pi_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetVariableAtIndex(long piIndex) As SWKAnthroVariable
                | 
                |     Returns the variable at the specified index.
                | 
                |     Parameters:
                | 
                |         piIndex
                |             The index of the variable to retrieve.

        :param int pi_index:
        :return: SWKAnthroVariable
        """
        return SWKAnthroVariable(self.swk_anthro.GetVariableAtIndex(pi_index))

    def get_variable_from_us_number(self, pi_ref_number=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetVariableFromUsNumber(long piRefNumber) As
                | SWKAnthroVariable
                | 
                |     Returns the variable from a specified us number.
                | 
                |     Parameters:
                | 
                |         piRefNumber
                |             The reference number of the variable to retrieve (ex.: 3 for us3,
                |             100 for us100, etc).

        :param int pi_ref_number:
        :return: SWKAnthroVariable
        """
        return SWKAnthroVariable(self.swk_anthro.GetVariableFromUsNumber(pi_ref_number))

    def reset(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub Reset()
                | 
                |     Reset the anthtropometry. This method resets each variable back to the
                |     automatic mode, and then updates the anthropometry.

        :return: None
        """
        return self.swk_anthro.Reset()

    def __repr__(self):
        return f'SwkAnthro(name="{ self.name }")'
