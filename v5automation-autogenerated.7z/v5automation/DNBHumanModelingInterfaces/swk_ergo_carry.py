#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class SwkErgoCarry(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     SWKErgoCarry
                | 
                | This interface deals the carry ergonomic analysis.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.swk_ergo_carry = com_object

    @property
    def distance_of_carry(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property DistanceOfCarry() As CATBSTR
                | 
                |     Returns or sets the distance of carry.
                |     This distance must specified at least once.
                |     Failure to do so will result in invalid output values.

        :return: str
        """

        return self.swk_ergo_carry.DistanceOfCarry

    @distance_of_carry.setter
    def distance_of_carry(self, value):
        """
        :param str value:
        """

        self.swk_ergo_carry.DistanceOfCarry = value

    @property
    def frequency(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Frequency() As double
                | 
                |     Returns or sets the carry frequecy.
                |     This frequency must be expressed in carries per second, and
                |     must
                |     be specified before attempting to retrive any output value from the
                |     study.
                |     Failure to do so will result in invalid output values.

        :return: float
        """

        return self.swk_ergo_carry.Frequency

    @frequency.setter
    def frequency(self, value):
        """
        :param float value:
        """

        self.swk_ergo_carry.Frequency = value

    @property
    def maximum_weight(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property MaximumWeight() As CATBSTR (Read Only)
                | 
                |     This field is the maximum weight that can be carried force, given the
                |     current input guidelines.

        :return: str
        """

        return self.swk_ergo_carry.MaximumWeight

    @property
    def population(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Population() As double
                | 
                |     Returns or sets the percentage of the population that should be able to
                |     perform the carry task safely.
                |     This property can only take the values 50.0, 75.0 and 90.0, and must be
                |     specified
                |     at least once.
                |     Failure to do so will result in invalid output values.

        :return: float
        """

        return self.swk_ergo_carry.Population

    @population.setter
    def population(self, value):
        """
        :param float value:
        """

        self.swk_ergo_carry.Population = value

    def __repr__(self):
        return f'SwkErgoCarry(name="{ self.name }")'
