#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class SwkErgo(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     SWKErgo
                | 
                | This interface groups the properties giving access to all the ergonomic studies
                | that can be performed on a manikin.
                | 
                | Its main purpose is to provide bridges to the specific ergonomic analysis
                | interfaces.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.swk_ergo = com_object

    @property
    def carry(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Carry() As SWKErgoCarry (Read Only)
                | 
                |     Returns the object for a carry analysis. The Carry can also be obtained by
                |     invoking method GetItem (from AnyObject) with the character string "Carry" as
                |     an argument.

        :return: SWKErgoCarry
        """

        return SWKErgoCarry(self.swk_ergo.Carry)

    @property
    def lift_lower(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property LiftLower() As SWKErgoLiftLower (Read Only)
                | 
                |     Returns the object for a lift/lower analysis. The Lift/Lower can also be
                |     obtained by invoking method GetItem (from AnyObject) with the character string
                |     "LiftLower" as an argument.

        :return: SWKErgoLiftLower
        """

        return SWKErgoLiftLower(self.swk_ergo.LiftLower)

    @property
    def push_pull(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property PushPull() As SWKErgoPushPull (Read Only)
                | 
                |     Returns the object for a push/pull analysis. The Push/Pull can also be
                |     obtained by invoking method GetItem (from AnyObject) with the character string
                |     "PushPull" as an argument.

        :return: SWKErgoPushPull
        """

        return SWKErgoPushPull(self.swk_ergo.PushPull)

    @property
    def rula(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property RULA() As SWKErgoRULA (Read Only)
                | 
                |     Returns the object for a RULA analysis. The RULA object can also be
                |     obtained by invoking method GetItem (from AnyObject) with the character string
                |     "RULA" as an argument.

        :return: SWKErgoRULA
        """

        return SWKErgoRULA(self.swk_ergo.RULA)

    def __repr__(self):
        return f'SwkErgo(name="{ self.name }")'
