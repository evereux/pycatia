#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class Cd5IDs(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     CD5IDs
                | 
                | Represents a list of ENOVIA V6 Integration identifier(CD5ID).
                | 
                | Example:
                | 
                |       The following example indicates how to retrieve list of ENOVIA V6
                |       Integration identifier.
                |      
                | 
                | 
                |          
                |         PhysicalIDs : "6EFB8D2E00008A445257E36100000DF7,6EFB8D2E00008A445257E3610000090".
                | 
                |          
                | 
                | 
                |      
                | 
                |      Dim oIDs As ENOIACD5IDs
                |      Set oIDs = GetIDsFromPhysicalIDs(PhysicalIDs);
                |      
                | 
                | 
                |      
                | 
                | See also:
                |     CD5EngineV6R2015, CD5ID
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_i_ds = com_object

    def item(self, i_index: CATVariant) -> CD5ID:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Item(CATVariant iIndex) As CD5ID
                | 
                |     Returns (gets) CD5ID from the list of ids.
                | 
                |     Example:
                | 
                |           The following example gets a CD5ID at index 1.
                |          
                | 
                |          Dim oID As ENOIACD5ID
                |          Set oID = CD5IDs.Item(1)

        :param CATVariant i_index:
        :return: CD5ID
        :rtype: CD5ID
        """
        return CD5ID(self.cd5_i_ds.Item(i_index.com_object))

    def __repr__(self):
        return f'Cd5IDs(name="{ self.name }")'
