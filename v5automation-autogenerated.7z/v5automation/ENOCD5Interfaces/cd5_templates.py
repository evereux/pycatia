#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class Cd5Templates(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     CD5Templates
                | 
                | Represents a List of all Templates from a Template type.
                | 
                | Example:
                | 
                |       The following example indicates how to retrieve the List of all
                |       Templates.
                |      
                | 
                |      Dim oTemplates As ENOIACD5Templates
                |      Set oTemplates = oTemplateType.Templates
                |      
                | 
                | 
                |      
                | 
                | See also:
                |     CD5TemplateType
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_templates = com_object

    def item(self, i_index: CATVariant) -> CD5Template:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Item(CATVariant iIndex) As CD5Template
                | 
                |     Returns (gets) an item from the list of items.
                | 
                |     Example:
                | 
                |           The following example gets a Template at index 1.
                |          
                | 
                |          Dim oTemplate As ENOIACD5Template
                |          Set oTemplate = oTemplates.Item(1)

        :param CATVariant i_index:
        :return: CD5Template
        :rtype: CD5Template
        """
        return CD5Template(self.cd5_templates.Item(i_index.com_object))

    def __repr__(self):
        return f'Cd5Templates(name="{ self.name }")'
