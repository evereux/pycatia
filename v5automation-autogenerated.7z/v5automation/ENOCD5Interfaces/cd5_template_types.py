#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class Cd5TemplateTypes(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     CD5TemplateTypes
                | 
                | Represents a List of all Template types.
                | 
                | Example:
                | 
                |       The following example indicates how to retrieve List of all Template
                |       types.
                |      
                | 
                |      Dim oCD5Engine As CD5EngineV6R2015
                |      Set oCD5Engine = CATIA.GetItem("CD5EngineV6R2015")
                |      Dim oTemplateTypes As ENOIACD5TemplateTypes
                |      Set oTemplateTypes = oCD5Engine.TemplateTypes
                |      
                | 
                | 
                |      
                | 
                | See also:
                |     CD5EngineV6R2015
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_template_types = com_object

    def item(self, i_index: CATVariant) -> CD5TemplateType:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Item(CATVariant iIndex) As CD5TemplateType
                | 
                |     Returns (gets) an item from the list of items.
                | 
                |     Example:
                | 
                |           The following example gets a Template Type at index
                |           1.
                |          
                | 
                |          Dim oTemplateType As ENOIACD5TemplateType
                |          Set oTemplateType = oTemplateTypes.Item(1)

        :param CATVariant i_index:
        :return: CD5TemplateType
        :rtype: CD5TemplateType
        """
        return CD5TemplateType(self.cd5_template_types.Item(i_index.com_object))

    def __repr__(self):
        return f'Cd5TemplateTypes(name="{ self.name }")'
