#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class Cd5Properties(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     CD5Properties
                | 
                | Represents a collection of all the properties of an ENOVIA V6
                | object.
                | 
                | Role: It represents all the properties of a given object/document already saved
                | into ENOVIA. The purpose of this interface is to get a collection of an ENOVIA
                | V6 object properties. The properties are accessible through Edit/Properties
                | menu item after user has clicked the ‘More…’ button It is managed by
                | CD5Engine.
                | 
                | Example:
                | 
                |       The following example indicates how to retrieve CD5Properties from ENOVIA
                |       V6 Integration Engine.
                |      
                | 
                |      Dim objCD5Properties As CD5Properties
                |      'To get properties of regular documents
                |      Set objCD5Properties = oCD5Engine.GetPropertiesOfDocument(objCATIADocument)
                |      'To get properties of Embedded Component
                |      Set objCD5Properties = oCD5Engine.GetPropertiesOfDocument(objCATIADocument, "Embedded_Component_Name")
                |      
                | 
                | 
                |      
                | 
                | See also:
                |     CD5Engine, CD5Property
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_properties = com_object

    def item(self, i_index: CATVariant) -> CD5Property:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Item(CATVariant iIndex) As CD5Property
                | 
                |     Returns ENOVIA V6 object property specified by 1 based index. That is, 1th
                |     index is the first property ergo last property is (Total Count)th
                |     Index
                | 
                |     Throws:
                | 
                |         -1641847650 : Connection to ENOVIA V6 is necessary to intialize this option.
                | 
                |     Example:
                | 
                |           The following example shows how to retrieve a single property from
                |           the collection of all properties.
                |          
                | 
                |          Dim objCD5Property As CD5Property
                |          Set objCD5Property = objCD5Properties.Item(1)

        :param CATVariant i_index:
        :return: CD5Property
        :rtype: CD5Property
        """
        return CD5Property(self.cd5_properties.Item(i_index.com_object))

    def __repr__(self):
        return f'Cd5Properties(name="{ self.name }")'
