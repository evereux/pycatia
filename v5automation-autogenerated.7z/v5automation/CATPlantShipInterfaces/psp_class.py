#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class PspClass(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     PspClass
                | 
                | Represent Interface to list the start up object classes of an
                | application.
                | Role: Application object classes.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_class = com_object

    @property
    def start_up_connectors(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property StartUpConnectors() As PspListOfBSTRs (Read Only)
                | 
                |     Returns a List of start-up Connector object classes.
                | 
                |     Example:
                | 
                |           
                | 
                |          Dim objThisIntf As PspClass
                |          Dim objArg1 As PspListOfBSTRs
                |           ...
                |          Set objArg1 = objThisIntf.StartUpConnectors

        :return: PspListOfBSTRs
        """

        return PspListOfBSTRs(self.psp_class.StartUpConnectors)

    @property
    def start_up_functions(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property StartUpFunctions() As PspListOfBSTRs (Read Only)
                | 
                |     Returns a List of start-up Function object classes.
                | 
                |     Example:
                | 
                |           
                | 
                |          Dim objThisIntf As PspClass
                |          Dim objArg1 As PspListOfBSTRs
                |           ...
                |          Set objArg1 = objThisIntf.StartupFunctions

        :return: PspListOfBSTRs
        """

        return PspListOfBSTRs(self.psp_class.StartUpFunctions)

    @property
    def start_up_physicals(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property StartUpPhysicals() As PspListOfBSTRs (Read Only)
                | 
                |     Returns a List of start-up physical object classes.
                | 
                |     Example:
                | 
                |           
                | 
                |          Dim objThisIntf As PspClass
                |          Dim objArg1 As PspListOfBSTRs
                |           ...
                |          Set objArg1 = objThisIntf.StartupPhysicals

        :return: PspListOfBSTRs
        """

        return PspListOfBSTRs(self.psp_class.StartUpPhysicals)

    def __repr__(self):
        return f'PspClass(name="{ self.name }")'
