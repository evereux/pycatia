#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class PspTempListFactory(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     PspTempListFactory
                | 
                | Create temporary (non-persistent) lists to be used in VB
                | environment.
                | Role: Create lists in VB environment.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_temp_list_factory = com_object

    def create_list_of_bst_rs(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func CreateListOfBSTRs() As PspListOfBSTRs
                | 
                |     Returns a new empty list of strings.
                | 
                |     Returns:
                |         a empty list of strings. 
                |     Example:
                | 
                |           This example illustrates how to create a new empty list of
                |           strings.
                |          
                | 
                |          Dim PspListFact As PspTempListFactory
                |          Dim NewList As PspListOfBSTRs
                |          Set NewList = PspListFact.CreateListOfBSTRs

        :return: PspListOfBSTRs
        """
        return PspListOfBSTRs(self.psp_temp_list_factory.CreateListOfBSTRs())

    def create_list_of_doubles(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func CreateListOfDoubles() As PspListOfDoubles
                | 
                |     Returns a new empty list of doubles.
                | 
                |     Returns:
                |         a empty list of doubles. 
                |     Example:
                | 
                |           This example illustrates how to create a new empty list of
                |           doubles.
                |          
                | 
                |          Dim PspListFact As PspTempListFactory
                |          Dim NewList As PspListOfDoubles
                |          Set NewList = PspListFact.CreateListOfDoubles

        :return: PspListOfDoubles
        """
        return PspListOfDoubles(self.psp_temp_list_factory.CreateListOfDoubles())

    def create_list_of_longs(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func CreateListOfLongs() As PspListOfLongs
                | 
                |     Returns a new empty list of long integers.
                | 
                |     Returns:
                |         a empty list of long integers. 
                |     Example:
                | 
                |           This example illustrates how to create a new empty list of long
                |           integers.
                |          
                | 
                |          Dim PspListFact As PspTempListFactory
                |          Dim NewList As PspListOfLongs
                |          Set NewList = PspListFact.CreateListOfLongs

        :return: PspListOfLongs
        """
        return PspListOfLongs(self.psp_temp_list_factory.CreateListOfLongs())

    def create_list_of_objects(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func CreateListOfObjects() As PspListOfObjects
                | 
                |     Returns a new empty list of objects.
                | 
                |     Returns:
                |         a empty list of objects. 
                |     Example:
                | 
                |           This example illustrates how to create a new empty list of
                |           objects.
                |          
                | 
                |          Dim PspListFact As PspTempListFactory
                |          Dim NewList As PspListOfObjects
                |          Set NewList = PspListFact.CreateListOfObjects

        :return: PspListOfObjects
        """
        return PspListOfObjects(self.psp_temp_list_factory.CreateListOfObjects())

    def __repr__(self):
        return f'PspTempListFactory(name="{ self.name }")'
