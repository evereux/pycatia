#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class ManufacturingFeatures(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     ManufacturingFeatures
                | 
                | Collection of Manufacturing Features.
                | 
                | See also:
                |     ManufacturingFeature
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.manufacturing_features = com_object

    def add(self, i_type=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Add(CATBSTR iType) As ManufacturingFeature
                | 
                |     Create and Add a Manufacturing Feature of a specified type to the
                |     Collection.
                | 
                |     Example:
                |         The following example creates and adds in Features the manufacturing feature Feature of type : type
                | 
                |          Set Feature = Features.Add(Type)

        :param str i_type:
        :return: ManufacturingFeature
        """
        return ManufacturingFeature(self.manufacturing_features.Add(i_type))

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Item(CATVariant iIndex) As ManufacturingFeature
                | 
                |     Retrieve the Manufacturing Feature of a the specified index from the
                |     Collection.
                | 
                |     Example:
                |         The following example retrieves from Feature the manufacturing feature Feature from index : Index
                | 
                |          Set Feature = Features.Item(Index)

        :param CATVariant i_index:
        :return: ManufacturingFeature
        """
        return ManufacturingFeature(self.manufacturing_features.Item(i_index.com_object))

    def __repr__(self):
        return f'ManufacturingFeatures(name="{ self.name }")'
