#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class ManufacturingFactories(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ManufacturingFactories
                | 
                | Interface to manage manufacturing factories.
                | 
                | Role: CATIAMfgManufacturingFactories has methods to manage manufacturing
                | factories.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.manufacturing_factories = com_object

    def get_manufacturing_resource_factory(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetManufacturingResourceFactory() As AnyObject
                | 
                |     Retrieves the manufacturing resource factory from the given
                |     object.
                | 
                |     Parameters:
                | 
                |         oResourceFactory
                |             The manufacturing resource factory.

        :return: AnyObject
        """
        return AnyObject(self.manufacturing_factories.GetManufacturingResourceFactory())

    def __repr__(self):
        return f'ManufacturingFactories(name="{ self.name }")'
