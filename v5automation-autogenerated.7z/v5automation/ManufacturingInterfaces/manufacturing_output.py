#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class ManufacturingOutput(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ManufacturingOutput
                | 
                | Object that represents the output machining code.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.manufacturing_output = com_object

    @property
    def size(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Size() As long (Read Only)
                | 
                |     Returns the number of bytes written to this data output.
                | 
                |     Parameters:
                | 
                |         oBytes
                |             The integer value of the number of bytes

        :return: int
        """

        return self.manufacturing_output.Size

    def close_stream(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub CloseStream()
                | 
                |     Close the Stream.

        :return: None
        """
        return self.manufacturing_output.CloseStream()

    def decrement_tabulation(self, i_tab=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub DecrementTabulation(long iTab)
                | 
                |     Decrement the tabulation of the current block of text by the specified
                |     number of characters.

        :param int i_tab:
        :return: None
        """
        return self.manufacturing_output.DecrementTabulation(i_tab)

    def end_block(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub EndBlock()
                | 
                |     Specify that the Block is ended.

        :return: None
        """
        return self.manufacturing_output.EndBlock()

    def end_line(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub EndLine()
                | 
                |     Specify that the line is ended.

        :return: None
        """
        return self.manufacturing_output.EndLine()

    def flush(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub Flush()
                | 
                |     Flush all Data in the Stream.

        :return: None
        """
        return self.manufacturing_output.Flush()

    def increment_tabulation(self, i_tab=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub IncrementTabulation(long iTab)
                | 
                |     Increment the tabulation of the current block of text by the specified
                |     number of characters.

        :param int i_tab:
        :return: None
        """
        return self.manufacturing_output.IncrementTabulation(i_tab)

    def new_block(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub NewBlock()
                | 
                |     Create a New Block in the underlying output stream.

        :return: None
        """
        return self.manufacturing_output.NewBlock()

    def new_line(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub NewLine()
                | 
                |     Create a New Line in the underlying output stream.

        :return: None
        """
        return self.manufacturing_output.NewLine()

    def set_buffer_length(self, i_lines=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub SetBufferLength(long iLines)
                | 
                |     Set the number of lines of the buffer before it will be flushed (default is
                |     200).
                | 
                |     Parameters:
                | 
                |         iLines
                |             The integer value of the number of lines

        :param int i_lines:
        :return: None
        """
        return self.manufacturing_output.SetBufferLength(i_lines)

    def write_chars(self, i_text=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub write_Chars(CATBSTR iText)
                | 
                |     Write the specified string to the underlying output stream.

        :param str i_text:
        :return: None
        """
        return self.manufacturing_output.write_Chars(i_text)

    def write_double(self, i_val=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub write_Double(double iVal)
                | 
                |     Write the specified double to the underlying output stream.

        :param float i_val:
        :return: None
        """
        return self.manufacturing_output.write_Double(i_val)

    def write_long(self, i_val=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub write_Long(long iVal)
                | 
                |     Write the specified long to the underlying output stream.

        :param int i_val:
        :return: None
        """
        return self.manufacturing_output.write_Long(i_val)

    def __repr__(self):
        return f'ManufacturingOutput(name="{ self.name }")'
