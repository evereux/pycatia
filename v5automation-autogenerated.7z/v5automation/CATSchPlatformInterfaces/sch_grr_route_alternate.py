#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-09-25 14:34:21.593357

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class SchGrrRouteAlternate(AnyObject):

    """
        .. note::
            :class: toggle

            CAA V5 Visual Basic Help (2020-09-25 14:34:21.593357)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     SchGRRRouteAlternate
                | 
                | Manage the graphical styles for alternative route graphics.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.sch_grr_route_alternate = com_object

    def get_alternate_style(self, o_e_graphic_style: int) -> None:
        """
        .. note::
            :class: toggle

            CAA V5 Visual Basic Help (2020-09-25 14:34:21.593357))
                | o Sub GetAlternateStyle(CatSchIDLRouteAlternateGraphicStyle
                | oEGraphicStyle)
                | 
                |     Returns the graphicl style of the alternate graphic
                |     object.
                | 
                |     Parameters:
                | 
                |         oEGraphicStyle
                |             Enum describing the graphic style of the object. (see
                |             CATSchGeneralEnum.h for descriptions) 
                | 
                |     Example:
                | 
                |           
                | 
                |          Dim objThisIntf As SchGRRRouteAlternate
                | 
                |           ...
                |         
objThisIntf.GetAlternateStyleCatSchIDLRouteAlternateGraphicStyle_Enum

        :param int o_e_graphic_style:
        :return: None
        :rtype: None
        """
        return self.sch_grr_route_alternate.GetAlternateStyle(o_e_graphic_style)

    def __repr__(self):
        return f'SchGrrRouteAlternate(name="{ self.name }")'
