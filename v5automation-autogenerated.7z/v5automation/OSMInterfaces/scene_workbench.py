#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.in_interfaces.workbench import Workbench


class SceneWorkbench(Workbench):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     InfInterfaces.Workbench
                |                         SceneWorkbench
                | 
                | Represent the access point to scenes management.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.scene_workbench = com_object

    @property
    def work_scenes(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property WorkScenes() As Scenes (Read Only)
                | 
                |     Returns the Scenes collection.
                | 
                |     Example:
                | 
                |               This example retrieves the WorkScenes collection of the active
                |               document.
                |             
                | 
                |             Dim TheWorkSceneWorkbench As Workbench
                |             Set TheWorkSceneWorkbench = CATIA.ActiveDocument.GetWorkbench ( "SceneWorkbench" )
                |             Dim TheScenesList As WorkScenes
                |             Set TheScenesList = TheWorkSceneWorkbench.WorkScenes

        :return: Scenes
        """

        return Scenes(self.scene_workbench.WorkScenes)

    def __repr__(self):
        return f'SceneWorkbench(name="{ self.name }")'
