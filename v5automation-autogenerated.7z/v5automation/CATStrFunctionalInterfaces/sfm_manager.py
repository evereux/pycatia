#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.in_interfaces.reference import Reference
from pycatia.in_interfaces.references import References
from pycatia.system_interfaces.any_object import AnyObject


class SfmManager(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     SfmManager
                | 
                | Services about Structure Functional Modeler applications: SFD and
                | SDD.
                | Role: To manage some services.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.sfm_manager = com_object

    def add_hull(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub AddHull()
                | 
                |     Add the Hull feature according to the PRM resources.
                |     Role: Allows adding the Hull feature according to the PRM
                |     resources.
                | 
                |     Returns:
                |         S_OK if everything ran ok.

        :return: None
        """
        return self.sfm_manager.AddHull()

    def get_all_uc1_welds(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetAllUC1Welds() As SfmWelds
                | 
                |     Gets all UC1 Weld features in Part.
                | 
                |     Parameters:
                | 
                |         oWelds
                |             [out] The retrieved UC1 Weld features. 
                | 
                |     Returns:
                |         S_OK if everything ran ok.
                | 
                |         Example
                |         :
                |             This example gets welds features in Part.
                | 
                |              Dim Welds As SfmWelds
                |              Set Welds = ManagerObj.GetWelds(Nothing)

        :return: SfmWelds
        """
        return SfmWelds(self.sfm_manager.GetAllUC1Welds())

    def get_hull(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetHull() As Reference
                | 
                |     Returns the Hull feature in the part.
                | 
                |     Example
                |     :
                |         This example retrieves in Hull the Hull object.
                | 
                |          Dim Hull As Reference
                |          SfmManager.GetHull Hull

        :return: Reference
        """
        return Reference(self.sfm_manager.GetHull())

    def get_plane_systems(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetPlaneSystems() As References
                | 
                |     Returns the list of PlaneSystems in the part.
                | 
                |     Example
                |     :
                |         This example retrieves in PlaneSystems the list of PlaneSystems
                |         objects.
                | 
                |          Dim PlaneSystems As References
                |          SfmManager.GetPlaneSystems PlaneSystems

        :return: References
        """
        return References(self.sfm_manager.GetPlaneSystems())

    def get_reference_plane(self, i_plane_system_index=None, i_plane_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetReferencePlane(CATVariant iPlaneSystemIndex,
                | CATVariant iPlaneIndex) As Reference
                | 
                |     Returns a reference plane in the specific PlaneSystems.
                | 
                |     Example
                |     :
                |         This example retrieves in RefPlane the reference planes contained into
                |         the 1st PlaneSystem, and which has CROSS.12 as a name.
                | 
                |          Dim RefPlane As Reference
                |          SfmManager.GetReferencePlane 1, "CROSS.12", RefPlane

        :param CATVariant i_plane_system_index:
        :param CATVariant i_plane_index:
        :return: Reference
        """
        return Reference(self.sfm_manager.GetReferencePlane(i_plane_system_index.com_object, i_plane_index.com_object))

    def get_super_members(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetSuperMembers() As References
                | 
                |     Returns the list of SuperMembers in the part.
                | 
                |     Example
                |     :
                |         This example retrieves in SuperMembers the list of SuperMembers
                |         objects.
                | 
                |          Dim SuperMembers As References
                |          SfmManager.GetSuperMembers SuperMembers

        :return: References
        """
        return References(self.sfm_manager.GetSuperMembers())

    def get_super_plates(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetSuperPlates() As References
                | 
                |     Returns the list of SuperPlates in the part.
                | 
                |     Example
                |     :
                |         This example retrieves in SuperPlates the list of SuperPlates
                |         objects.
                | 
                |          Dim SuperPlates As References
                |          SfmManager.GetSuperPlates SuperPlates

        :return: References
        """
        return References(self.sfm_manager.GetSuperPlates())

    def get_super_stiffeners(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetSuperStiffeners() As References
                | 
                |     Returns the list of SuperStiffeners in the part.
                | 
                |     Example
                |     :
                |         This example retrieves in SuperStiffeners the list of SuperStiffeners
                |         objects.
                | 
                |          Dim SuperStiffeners As References
                |          SfmManager.GetSuperStiffeners SuperStiffeners

        :return: References
        """
        return References(self.sfm_manager.GetSuperStiffeners())

    def get_super_stiffeners_on_free_edge(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func GetSuperStiffenersOnFreeEdge() As References
                | 
                |     Returns the list of SuperStiffenersOnFreeEdge in the part.
                | 
                |     Example
                |     :
                |         This example retrieves in SuperStiffenersOnFreeEdge the list of
                |         SuperStiffenersOnFreeEdge objects.
                | 
                |          Dim SuperStiffenersOnFreeEdge As References
                |          SfmManager.GetSuperStiffenersOnFreeEdge
                |          SuperStiffenersOnFreeEdge

        :return: References
        """
        return References(self.sfm_manager.GetSuperStiffenersOnFreeEdge())

    def init_resources(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub InitResources()
                | 
                |     Initialize environment (PRM resources).
                |     Role: Allows initializing environment (PRM resources).
                | 
                |     Returns:
                |         S_OK if everything ran ok.

        :return: None
        """
        return self.sfm_manager.InitResources()

    def synchronize_hull(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub SynchronizeHull()
                | 
                |     Synchronize PlaneSystems according with the PRM resources.
                |     Role: Allows synchronizing the PlaneSystems with the PRM
                |     resources.
                | 
                |     Returns:
                |         S_OK if everything ran ok.

        :return: None
        """
        return self.sfm_manager.SynchronizeHull()

    def synchronize_planes(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Sub SynchronizePlanes()
                | 
                |     Synchronize PlaneSystems according with the PRM resources.
                |     Role: Allows synchronizing the PlaneSystems with the PRM
                |     resources.
                | 
                |     Returns:
                |         S_OK if everything ran ok.

        :return: None
        """
        return self.sfm_manager.SynchronizePlanes()

    def __repr__(self):
        return f'SfmManager(name="{ self.name }")'
