#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class SfmSplitPlates(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     SfmSplitPlates
                | 
                | Interface to manage the Structure Functional Modeler Split Plates
                | object.
                | Role: Provides access to split plates of a super plate as a
                | collection.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.sfm_split_plates = com_object

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Item(CATVariant iIndex) As SfmSplitPlate
                | 
                |     Gets Split Plate.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             [in] Index of the Split Plate to be retrieved. 
                |         oSfmSplitPlate
                |             [out] The retrieved Split Plate. 
                | 
                |     Returns:
                |         S_OK if everything ran ok
                | 
                |         Example
                |         :
                |             This example gets existing Split Plate of a Super
                |             Plate.
                | 
                |              Dim ListSplitPlates As SfmSplitPlates
                |              Set ListSplitPlates = SuperPlate.SplitPlatesObjects
                |              Dim Split_Plate As SfmSplitPlate
                |              Set Split_Plate = ListSplitPlates.Item(i)
                |              Next

        :param CATVariant i_index:
        :return: SfmSplitPlate
        """
        return SfmSplitPlate(self.sfm_split_plates.Item(i_index.com_object))

    def __repr__(self):
        return f'SfmSplitPlates(name="{ self.name }")'
