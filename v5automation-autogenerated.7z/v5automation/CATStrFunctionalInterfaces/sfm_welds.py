#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class SfmWelds(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     SfmWelds
                | 
                | Interface to manage the Structure Functional Modeler Weld object's
                | collection.
                | Role: Provides access to Weld objects as a collection.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.sfm_welds = com_object

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Item(CATVariant iIndex) As SfmWeld
                | 
                |     Gets Weld Feature.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             [in] Index of the Weld Feature to be retrieved. 
                |         oSfmWeld
                |             [out] The retrieved Weld Feature. 
                | 
                |     Returns:
                |         S_OK if everything ran ok
                | 
                |         Example
                |         :
                |             This example gets Weld Feature.
                | 
                |              Dim Welds As SfmWelds
                |              Set Welds = Split_Plate.GetWelds(Nothing)
                |              Dim j As Integer
                |              For j = 1 To Welds.Count
                |              Dim EachWeld As SfmWeld
                |              Set EachWeld = Welds.Item(j)
                |              Next

        :param CATVariant i_index:
        :return: SfmWeld
        """
        return SfmWeld(self.sfm_welds.Item(i_index.com_object))

    def __repr__(self):
        return f'SfmWelds(name="{ self.name }")'
