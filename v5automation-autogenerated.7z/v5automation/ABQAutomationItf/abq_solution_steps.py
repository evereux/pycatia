#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class AbqSolutionSteps(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     ABQSolutionSteps
                | 
                | The collection of Abaqus solution step (ABQSolutionStep) objects contained
                | in
                | ABQSolutionCase objects.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_solution_steps = com_object

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Item(CATVariant iIndex) As ABQSolutionStep
                | 
                |     Returns an Abaqus solution step using its index or its name from the
                |     ABQSolutionSteps collection.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The index or the name of the Abaqus solution step to retrieve from
                |             the collection of Abaqus solution steps. If the index is a number, it specifies
                |             the rank of the Abaqus solution step in the collection. The index of the first
                |             Abaqus solution step in the collection is 1, and the index of the last solution
                |             step is Count. If the index is a string, it specifies the name you assigned to
                |             the solution step using the CATIACollection::Name property.
                |             
                | 
                |     Returns:
                |         The specified ABQSolutionStep.

        :param CATVariant i_index:
        :return: ABQSolutionStep
        """
        return ABQSolutionStep(self.abq_solution_steps.Item(i_index.com_object))

    def __repr__(self):
        return f'AbqSolutionSteps(name="{ self.name }")'
