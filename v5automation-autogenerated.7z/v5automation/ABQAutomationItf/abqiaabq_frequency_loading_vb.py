#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""




class AbqiaabqFrequencyLoadingVb(ABQLoad):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ABQAutomationItf.ABQLoad
                |                         ABQIAABQFrequencyLoadingVB
                | 
                | Interface representing xxx.
                | 
                | Role: Components that implement ABQIAABQFrequencyLoading are
                | ...
                | 
                | Do not use the ABQIAABQFrequencyLoading interface for such and such
                | ClassReference, Class#MethodReference, #InternalMethod...
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abqiaabq_frequency_loading_vb = com_object

    @property
    def dof(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property DOF() As double

        :return: float
        """

        return self.abqiaabq_frequency_loading_vb.DOF

    @dof.setter
    def dof(self, value):
        """
        :param float value:
        """

        self.abqiaabq_frequency_loading_vb.DOF = value

    @property
    def data_type(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property DataType() As boolean

        :return: bool
        """

        return self.abqiaabq_frequency_loading_vb.DataType

    @data_type.setter
    def data_type(self, value):
        """
        :param bool value:
        """

        self.abqiaabq_frequency_loading_vb.DataType = value

    @property
    def frequency_data_values(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property FrequencyDataValues(CATSafeArrayVariant iFreqDataVal) (Write
                | Only)

        :return: False
        """

        return None

    @frequency_data_values.setter
    def frequency_data_values(self, value):
        """
        :param False value:
        """

        self.abqiaabq_frequency_loading_vb.FrequencyDataValues = value

    @property
    def imaginary_data_values(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property ImaginaryDataValues(CATSafeArrayVariant iImaginaryDataValues)
                | (Write Only)

        :return: False
        """

        return None

    @imaginary_data_values.setter
    def imaginary_data_values(self, value):
        """
        :param False value:
        """

        self.abqiaabq_frequency_loading_vb.ImaginaryDataValues = value

    @property
    def real_data_values(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property RealDataValues(CATSafeArrayVariant iRealDataVal) (Write
                | Only)

        :return: False
        """

        return None

    @real_data_values.setter
    def real_data_values(self, value):
        """
        :param False value:
        """

        self.abqiaabq_frequency_loading_vb.RealDataValues = value

    @property
    def scale(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Scale() As double

        :return: float
        """

        return self.abqiaabq_frequency_loading_vb.Scale

    @scale.setter
    def scale(self, value):
        """
        :param float value:
        """

        self.abqiaabq_frequency_loading_vb.Scale = value

    def __repr__(self):
        return f'AbqiaabqFrequencyLoadingVb(name="{ self.name }")'
