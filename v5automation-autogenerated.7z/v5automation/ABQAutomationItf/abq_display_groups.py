#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class AbqDisplayGroups(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     ABQDisplayGroups
                | 
                | The collection of display groups under the abaqus analysis
                | case
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_display_groups = com_object

    def item(self, i_index: CATVariant) -> ABQDisplayGroup:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Item(CATVariant iIndex) As ABQDisplayGroup
                | 
                |     Returns an display group using its index or its name from the
                |     ABQDisplayGroups collection.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The index or the name of the display group to retrieve from the
                |             collection of display groups. If the index is a number, it specifies the rank
                |             of the display group in the collection. The index of the first display group in
                |             the collection is 1, and the index of the last display group is Count. If the
                |             index is a string, it specifies the name you assigned to the display group
                |             using the CATIACollection::Name property. 
                | 
                |     Returns:
                |         The specified ABQDisplayGroup.

        :param CATVariant i_index:
        :return: ABQDisplayGroup
        :rtype: ABQDisplayGroup
        """
        return ABQDisplayGroup(self.abq_display_groups.Item(i_index.com_object))

    def __repr__(self):
        return f'AbqDisplayGroups(name="{ self.name }")'
