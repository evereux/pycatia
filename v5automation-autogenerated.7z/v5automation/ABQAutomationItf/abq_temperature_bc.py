#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""




class AbqTemperatureBc(ABQBoundaryCondition):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ABQAutomationItf.ABQBoundaryCondition
                |                         ABQTemperatureBC
                | 
                | Represents an Abaqus Temperature boundary condition (ABQTemperatureBC)
                | feature.
                | Role:Access an Abaqus Temperature boundary condition feature or determine its
                | properties.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_temperature_bc = com_object

    @property
    def magnitude(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Magnitude() As double
                | 
                |     Sets or returns the magnitude of the temperature boundary
                |     condition.
                | 
                |     Returns:
                |         The magnitude of the temperature boundary condition.

        :return: float
        """

        return self.abq_temperature_bc.Magnitude

    @magnitude.setter
    def magnitude(self, value):
        """
        :param float value:
        """

        self.abq_temperature_bc.Magnitude = value

    @property
    def use_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property UseAmplitude() As boolean
                | 
                |     Sets or returns the UseAmplitude flag.
                | 
                |     Returns:
                |         A boolean specifying whether an amplitude will be
                |         used.

        :return: bool
        """

        return self.abq_temperature_bc.UseAmplitude

    @use_amplitude.setter
    def use_amplitude(self, value):
        """
        :param bool value:
        """

        self.abq_temperature_bc.UseAmplitude = value

    def __repr__(self):
        return f'AbqTemperatureBc(name="{ self.name }")'
