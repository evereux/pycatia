#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""




class AbqiaabqBaseMotionVb(ABQBoundaryCondition):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ABQAutomationItf.ABQBoundaryCondition
                |                         ABQIAABQBaseMotionVB
                | 
                | Interface representing xxx.
                | 
                | Role: Components that implement ABQIAABQBaseMotion are ...
                | 
                | Do not use the ABQIAABQBaseMotion interface for such and such ClassReference,
                | Class#MethodReference, #InternalMethod...
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abqiaabq_base_motion_vb = com_object

    @property
    def base_motion_type(self) -> str:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property BaseMotionType() As CATBSTR

        :return: str
        :rtype: str
        """

        return self.abqiaabq_base_motion_vb.BaseMotionType

    @base_motion_type.setter
    def base_motion_type(self, value: str):
        """
        :param str value:
        """

        self.abqiaabq_base_motion_vb.BaseMotionType = value

    @property
    def base_type(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property BaseType() As short

        :return: int
        :rtype: int
        """

        return self.abqiaabq_base_motion_vb.BaseType

    @base_type.setter
    def base_type(self, value: int):
        """
        :param int value:
        """

        self.abqiaabq_base_motion_vb.BaseType = value

    @property
    def clamp_support(self) -> ABQClampBC:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ClampSupport() As ABQClampBC

        :return: ABQClampBC
        :rtype: ABQClampBC
        """

        return ABQClampBC(self.abqiaabq_base_motion_vb.ClampSupport)

    @clamp_support.setter
    def clamp_support(self, value: ABQClampBC):
        """
        :param ABQClampBC value:
        """

        self.abqiaabq_base_motion_vb.ClampSupport = value

    @property
    def dof(self) -> float:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property DOF() As double

        :return: float
        :rtype: float
        """

        return self.abqiaabq_base_motion_vb.DOF

    @dof.setter
    def dof(self, value: float):
        """
        :param float value:
        """

        self.abqiaabq_base_motion_vb.DOF = value

    @property
    def data_type(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property DataType() As boolean

        :return: bool
        :rtype: bool
        """

        return self.abqiaabq_base_motion_vb.DataType

    @data_type.setter
    def data_type(self, value: bool):
        """
        :param bool value:
        """

        self.abqiaabq_base_motion_vb.DataType = value

    @property
    def disp_bc_support(self) -> ABQDisplacementBC:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property DispBCSupport() As ABQDisplacementBC

        :return: ABQDisplacementBC
        :rtype: ABQDisplacementBC
        """

        return ABQDisplacementBC(self.abqiaabq_base_motion_vb.DispBCSupport)

    @disp_bc_support.setter
    def disp_bc_support(self, value: ABQDisplacementBC):
        """
        :param ABQDisplacementBC value:
        """

        self.abqiaabq_base_motion_vb.DispBCSupport = value

    @property
    def frequency_data_values(self) -> False:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property FrequencyDataValues(CATSafeArrayVariant iFreqDataVal) (Write
                | Only)

        :return: False
        :rtype: False
        """

        return None

    @frequency_data_values.setter
    def frequency_data_values(self, value: False):
        """
        :param False value:
        """

        self.abqiaabq_base_motion_vb.FrequencyDataValues = value

    @property
    def imaginary_data_values(self) -> False:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImaginaryDataValues(CATSafeArrayVariant iImaginaryDataValues)
                | (Write Only)

        :return: False
        :rtype: False
        """

        return None

    @imaginary_data_values.setter
    def imaginary_data_values(self, value: False):
        """
        :param False value:
        """

        self.abqiaabq_base_motion_vb.ImaginaryDataValues = value

    @property
    def real_data_values(self) -> False:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property RealDataValues(CATSafeArrayVariant iRealDataVal) (Write
                | Only)

        :return: False
        :rtype: False
        """

        return None

    @real_data_values.setter
    def real_data_values(self, value: False):
        """
        :param False value:
        """

        self.abqiaabq_base_motion_vb.RealDataValues = value

    @property
    def scale(self) -> float:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property Scale() As double

        :return: float
        :rtype: float
        """

        return self.abqiaabq_base_motion_vb.Scale

    @scale.setter
    def scale(self, value: float):
        """
        :param float value:
        """

        self.abqiaabq_base_motion_vb.Scale = value

    def add_centre_of_rotation(self, i_product: Product, i_ref: Reference) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub AddCentreOfRotation(Product iProduct,
                | Reference iRef)

        :param Product i_product:
        :param Reference i_ref:
        :return: None
        :rtype: None
        """
        return self.abqiaabq_base_motion_vb.AddCentreOfRotation(i_product.com_object, i_ref.com_object)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'add_centre_of_rotation'
        # # vba_code = """
        # # Public Function add_centre_of_rotation(abqiaabq_base_motion_vb)
        # #     Dim iProduct (2)
        # #     abqiaabq_base_motion_vb.AddCentreOfRotation iProduct
        # #     add_centre_of_rotation = iProduct
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def __repr__(self):
        return f'AbqiaabqBaseMotionVb(name="{ self.name }")'
