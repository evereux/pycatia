#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.mec_mod_interfaces.axis_system import AxisSystem


class AbqDamperConnectionProperty(ABQProperty):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ABQAutomationItf.ABQProperty
                |                         ABQDamperConnectionProperty
                | 
                | Represents an Abaqus Damper connection property (ABQDamper)
                | object.
                | Role:Access an Abaqus Damper connection property object or determine its
                | properties.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_damper_connection_property = com_object

    @property
    def axis_sys(self) -> AxisSystem:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property Axis_sys() As AxisSystem
                | 
                |     Sets or returns the axis system in the Damper connection
                |     property.
                | 
                |     Returns:
                |         The object of axis system.

        :return: AxisSystem
        :rtype: AxisSystem
        """

        return AxisSystem(self.abq_damper_connection_property.Axis_sys)

    @axis_sys.setter
    def axis_sys(self, value: AxisSystem):
        """
        :param AxisSystem value:
        """

        self.abq_damper_connection_property.Axis_sys = value

    @property
    def damper_def(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property DamperDef() As SpringDef_Type
                | 
                |     Sets or returns the definition of Damper.
                | 
                |     Returns:
                |         the Definition of Damper.
                | 
                |         Legal values:
                | 
                |         ABQ_LINE
                |         ABQ_NON_LINEAR

        :return: int
        :rtype: int
        """

        return self.abq_damper_connection_property.DamperDef

    @damper_def.setter
    def damper_def(self, value: int):
        """
        :param int value:
        """

        self.abq_damper_connection_property.DamperDef = value

    @property
    def damper_type(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property DamperType() As SpringType_Type
                | 
                |     Sets or returns the type of Damper.
                | 
                |     Returns:
                |         The type of Damper.
                | 
                |         Legal values:
                | 
                |         AXIAL
                |         GENERAL
                | 
                |           
                |          
                | 
                |     Methods
                | 
                | o Sub AddSupportFromReference(Reference iReference,
                | Reference iSupport)
                | 
                |     Adds support to the Damper connection property.
                | 
                |     Parameters:
                | 
                |         iReference
                |             The CATIA Reference specifying the region to which the Damper
                |             connection property is applied.
                |         iSupport
                |             The CATIA Reference specifying the region to which the Damper
                |             connection property is applied.
                | 
                |             Refer: CATIAReference
                | 
                | o Func GetLinearDamping(SpringDof_Type iDof) As double
                | 
                |     Gets the linear damping value of the Damper given the degree of
                |     freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which damping is asked.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         oDampingValue
                |             The Dampingvalue.
                | 
                | o Sub GetNonLinearDamping(SpringDof_Type iDof,
                | CATSafeArrayVariant oForceArray,
                | CATSafeArrayVariant oVelocityArray)
                | 
                |     Gets the non-linear damping value of the Damper in the form of array, given
                |     the degree of freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which damping is asked.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         oForceArray
                |             The array of force values.
                |         oVelocityArray
                |             The array of velocity values.
                | 
                |             Refer: CATSafeArrayVariant
                | 
                | o Sub ReadDampingDataFromFile(SpringDof_Type iDof,
                | CATBSTR iFileName)
                | 
                |     Reads damping data from a text file for a damper connection
                |     property.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which damping data is
                |             asked.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         iFileName
                |             The complete path of the text file which contains the damping
                |             data.
                | 
                | o Sub RemoveAxisSystem()
                | 
                | o Sub RemoveDof(SpringDof_Type iDof)
                | 
                |     Unsets the linear damping value of the Damper for given degree of
                |     freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which damping is set.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                | o Sub SetLinearDamping(SpringDof_Type iDof,
                | double iDampingValue)
                | 
                |     Sets the linear damping value of the Damper given the degree of
                |     freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which damping is set.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         iDampingValue
                |             The Dampingvalue.
                | 
                | o Sub SetNonLinearDamping(SpringDof_Type iDof,
                | CATSafeArrayVariant iForceArray,
                | CATSafeArrayVariant iVelocityArray)
                | 
                |     Sets the non-linear damping value of the Damper in the form of array, given
                |     the degree of freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which damping is asked.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         iForceArray
                |             The array of force values.
                |         iVelocityArray
                |             The array of displacement values.
                |             The value in velocity array must be greater than previous value
                |             .
                | 
                |             Refer: CATSafeArrayVariant

        :return: int
        :rtype: int
        """

        return self.abq_damper_connection_property.DamperType

    @damper_type.setter
    def damper_type(self, value: int):
        """
        :param int value:
        """

        self.abq_damper_connection_property.DamperType = value

    def __repr__(self):
        return f'AbqDamperConnectionProperty(name="{ self.name }")'
