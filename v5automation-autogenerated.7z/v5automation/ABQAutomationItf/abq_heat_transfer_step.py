#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""




class AbqHeatTransferStep(ABQStep):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ABQAutomationItf.ABQStep
                |                         ABQHeatTransferStep
                | 
                | Represents an Abaqus heat transfer step (ABQHeatTransferStep)
                | object.
                | Role: Access an Abaqus heat transfer step object or determine its
                | properties.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_heat_transfer_step = com_object

    @property
    def boundary_conditions(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property BoundaryConditions() As ABQBoundaryConditions (Read
                | Only)
                | 
                |     Returns the ABQBoundaryConditions container associated with the
                |     step.
                | 
                |     Example:
                |         This example retrieves the ABQBoundaryConditions container
                |         abqBCs.
                | 
                |          Dim abqHeatStep As ABQHeatTransferStep 
                |          Dim abqBCs As ABQBoundaryConditions
                |          Set abqBCs = abqHeatStep.BoundaryConditions

        :return: ABQBoundaryConditions
        """

        return ABQBoundaryConditions(self.abq_heat_transfer_step.BoundaryConditions)

    @property
    def deltmx(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Deltmx() As double
                | 
                |     Sets or returns the maximum temperature change to be allowed in an
                |     increment during a transient heat transfer analysis.
                | 
                |     Returns:
                |         Maximum temperature change to be allowed in an
                |         increment

        :return: float
        """

        return self.abq_heat_transfer_step.Deltmx

    @deltmx.setter
    def deltmx(self, value):
        """
        :param float value:
        """

        self.abq_heat_transfer_step.Deltmx = value

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Description() As CATBSTR
                | 
                |     Sets or returns the description of the step.
                | 
                |     Returns:
                |         The description of the step

        :return: str
        """

        return self.abq_heat_transfer_step.Description

    @description.setter
    def description(self, value):
        """
        :param str value:
        """

        self.abq_heat_transfer_step.Description = value

    @property
    def end_step_on_temp_change(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property EndStepOnTempChange() As boolean
                | 
                |     Sets or returns whether the step should end when steady state is reached. A
                |     value of true indicates that the step will end.
                | 
                |     Returns:
                |         A boolean indicating whether the step will end when steady state is
                |         reached

        :return: bool
        """

        return self.abq_heat_transfer_step.EndStepOnTempChange

    @end_step_on_temp_change.setter
    def end_step_on_temp_change(self, value):
        """
        :param bool value:
        """

        self.abq_heat_transfer_step.EndStepOnTempChange = value

    @property
    def initial_inc(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property InitialInc() As double
                | 
                |     Sets or returns the initial increment size.
                | 
                |     Returns:
                |         The initial increment size

        :return: float
        """

        return self.abq_heat_transfer_step.InitialInc

    @initial_inc.setter
    def initial_inc(self, value):
        """
        :param float value:
        """

        self.abq_heat_transfer_step.InitialInc = value

    @property
    def loads(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Loads() As ABQLoads (Read Only)
                | 
                |     Returns the ABQLoads container associated with the step.
                | 
                |     Example:
                |         The following example retrieves the ABQLoads container
                |         abqLoads:
                | 
                |          Dim abqHeatStep As ABQHeatTransferStep
                |          Dim abqLoads As ABQLoads
                |          Set abqLoads = abqHeatStep.Loads

        :return: ABQLoads
        """

        return ABQLoads(self.abq_heat_transfer_step.Loads)

    @property
    def max_inc(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property MaxInc() As double
                | 
                |     Sets or returns the maximum increment size if
                |     TimeIncrementationMethod=AUTO_INCREMENT.
                | 
                |     Returns:
                |         The maximum increment size

        :return: float
        """

        return self.abq_heat_transfer_step.MaxInc

    @max_inc.setter
    def max_inc(self, value):
        """
        :param float value:
        """

        self.abq_heat_transfer_step.MaxInc = value

    @property
    def max_num_inc(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property MaxNumInc() As short
                | 
                |     Sets or returns the maximum number of increments if
                |     TimeIncrementationMethod=AUTO_INCREMENT.
                | 
                |     Returns:
                |         The maximum number of increments

        :return: enum
        """

        return self.abq_heat_transfer_step.MaxNumInc

    @max_num_inc.setter
    def max_num_inc(self, value):
        """
        :param enum value:
        """

        self.abq_heat_transfer_step.MaxNumInc = value

    @property
    def min_inc(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property MinInc() As double
                | 
                |     Sets or returns the minimum increment size if
                |     TimeIncrementationMethod=AUTO_INCREMENT.
                | 
                |     Returns:
                |         The minimum increment size

        :return: float
        """

        return self.abq_heat_transfer_step.MinInc

    @min_inc.setter
    def min_inc(self, value):
        """
        :param float value:
        """

        self.abq_heat_transfer_step.MinInc = value

    @property
    def mxdem(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Mxdem() As double
                | 
                |     Sets or returns the maximum allowable emissivity change with temperature
                |     and field variables during an increment.
                | 
                |     Returns:
                |         The maximum allowable emissivity change

        :return: float
        """

        return self.abq_heat_transfer_step.Mxdem

    @mxdem.setter
    def mxdem(self, value):
        """
        :param float value:
        """

        self.abq_heat_transfer_step.Mxdem = value

    @property
    def response(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Response() As Response_Type
                | 
                |     Sets or returns the response type.
                | 
                |     Returns:
                |         The response type
                | 
                |          
                |          
                |         Legal values:
                |           STEADY_STATE  
                |           TRANSIENT

        :return: Response_Type
        """

        return Response_Type(self.abq_heat_transfer_step.Response)

    @response.setter
    def response(self, value):
        """
        :param Response_Type value:
        """

        self.abq_heat_transfer_step.Response = value

    @property
    def time_incrementation_method(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property TimeIncrementationMethod() As Incrementation_Type
                | 
                |     Sets or returns the incrementation type.
                | 
                |     Returns:
                |         The incrementation type
                | 
                |          
                |          
                |         Legal values:
                |           AUTO_INCREMENT
                |           FIXED_INCREMENT

        :return: Incrementation_Type
        """

        return Incrementation_Type(self.abq_heat_transfer_step.TimeIncrementationMethod)

    @time_incrementation_method.setter
    def time_incrementation_method(self, value):
        """
        :param Incrementation_Type value:
        """

        self.abq_heat_transfer_step.TimeIncrementationMethod = value

    @property
    def time_period(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property TimePeriod() As double
                | 
                |     Sets or returns the step time.
                | 
                |     Returns:
                |         The step time

        :return: float
        """

        return self.abq_heat_transfer_step.TimePeriod

    @time_period.setter
    def time_period(self, value):
        """
        :param float value:
        """

        self.abq_heat_transfer_step.TimePeriod = value

    def __repr__(self):
        return f'AbqHeatTransferStep(name="{ self.name }")'
