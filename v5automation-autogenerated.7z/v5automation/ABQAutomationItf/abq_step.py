#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class AbqStep(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ABQStep
                | 
                | Represents a Abaqus analysis step (ABQStep) object.
                | Role: Access an Abaqus analysis step or determine its
                | properties.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_step = com_object

    @property
    def data_output_requests(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property DataOutputRequests() As ABQDataOutputRequests (Read
                | Only)
                | 
                |     Returns the ABQDataOutputRequests container associated with the
                |     step.
                | 
                |     Example:
                |         The following example retrieves the ABQDataOutputRequests container
                |         abqOutputRequests:
                | 
                |          Dim abqStep As ABQGeneralStaticStep 
                |          Dim abqDataOutputRequests As ABQDataOutputRequests
                |          Set abqDataOutputRequests = abqStep.OutputRequests

        :return: ABQDataOutputRequests
        """

        return ABQDataOutputRequests(self.abq_step.DataOutputRequests)

    @property
    def field_output_requests(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property FieldOutputRequests() As ABQFieldOutputRequests (Read
                | Only)
                | 
                |     Returns the ABQFieldOutputRequests container associated with the
                |     step.
                | 
                |     Example:
                |         The following example retrieves the ABQFieldOutputRequests container
                |         abqOutputRequests:
                | 
                |          Dim abqStep As ABQGeneralStaticStep 
                |          Dim abqFieldOutputRequests As ABQFieldOutputRequests
                |          Set abqFieldOutputRequests = abqStep.OutputRequests

        :return: ABQFieldOutputRequests
        """

        return ABQFieldOutputRequests(self.abq_step.FieldOutputRequests)

    @property
    def history_output_requests(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property HistoryOutputRequests() As ABQHistoryOutputRequests (Read
                | Only)
                | 
                |     Returns the ABQHistoryOutputRequests container associated with the
                |     step.
                | 
                |     Example:
                |         The following example retrieves the ABQHistoryOutputRequests container
                |         abqOutputRequests:
                | 
                |          Dim abqStep As ABQGeneralStaticStep 
                |          Dim abqHistoryOutputRequests As
                |          ABQHistoryOutputRequests
                |          Set abqHistoryOutputRequests = abqStep.OutputRequests

        :return: ABQHistoryOutputRequests
        """

        return ABQHistoryOutputRequests(self.abq_step.HistoryOutputRequests)

    @property
    def interactions(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Interactions() As ABQInteractions (Read Only)
                | 
                |     Returns the ABQInteractions container associated with the
                |     step.
                | 
                |     Example:
                |         The following example retrieves the ABQInteractions container
                |         abqInteractions:
                | 
                |          Dim abqStep As ABQGeneralStaticStep 
                |          Dim abqInteractions As ABQInteractions
                |          Set abqInteractions = abqStep.Interactions

        :return: ABQInteractions
        """

        return ABQInteractions(self.abq_step.Interactions)

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Type() As CATBSTR (Read Only)
                | 
                |     Returns the type of the step.
                | 
                |     Returns:
                |         The string representing the type of the step.

        :return: str
        """

        return self.abq_step.Type

    def __repr__(self):
        return f'AbqStep(name="{ self.name }")'
