#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.mec_mod_interfaces.axis_system import AxisSystem


class AbqSpringConnectionProperty(ABQProperty):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ABQAutomationItf.ABQProperty
                |                         ABQSpringConnectionProperty
                | 
                | Represents an Abaqus spring connection property (ABQSpring)
                | object.
                | Role:Access an Abaqus spring connection property object or determine its
                | properties.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_spring_connection_property = com_object

    @property
    def axis_sys(self) -> AxisSystem:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property Axis_sys() As AxisSystem
                | 
                |     Sets or returns the axis system in the spring connection
                |     property.
                | 
                |     Returns:
                |         The object of axis system.

        :return: AxisSystem
        :rtype: AxisSystem
        """

        return AxisSystem(self.abq_spring_connection_property.Axis_sys)

    @axis_sys.setter
    def axis_sys(self, value: AxisSystem):
        """
        :param AxisSystem value:
        """

        self.abq_spring_connection_property.Axis_sys = value

    @property
    def spring_def(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property SpringDef() As SpringDef_Type
                | 
                |     Sets or returns the definition of spring.
                | 
                |     Returns:
                |         the Definition of spring.
                | 
                |         Legal values:
                | 
                |         ABQ_LINE
                |         ABQ_NON_LINEAR

        :return: int
        :rtype: int
        """

        return self.abq_spring_connection_property.SpringDef

    @spring_def.setter
    def spring_def(self, value: int):
        """
        :param int value:
        """

        self.abq_spring_connection_property.SpringDef = value

    @property
    def spring_type(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property SpringType() As SpringType_Type
                | 
                |     Sets or returns the type of spring.
                | 
                |     Returns:
                |         The type of spring.
                | 
                |         Legal values:
                | 
                |         AXIAL
                |         GENERAL
                | 
                |           
                |          
                | 
                |     Methods
                | 
                | o Sub AddSupportFromReference(Reference iReference,
                | Reference iSupport)
                | 
                |     Adds support to the spring connection property.
                | 
                |     Parameters:
                | 
                |         iReference
                |             The CATIA Reference specifying the region to which the spring
                |             connection property is applied.
                |         iSupport
                |             The CATIA Reference specifying the region to which the spring
                |             connection property is applied.
                | 
                |             Refer: CATIAReference
                | 
                | o Func GetLinearStiffness(SpringDof_Type iDof) As double
                | 
                |     Gets the linear stiffness of the spring given the degree of
                |     freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which stiffness is
                |             asked.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         oStiffnessValue
                |             The stiffnessvalue.
                | 
                | o Sub GetNonLinearStiffness(SpringDof_Type iDof,
                | CATSafeArrayVariant oForceArray,
                | CATSafeArrayVariant oDispArray)
                | 
                |     Gets the non-linear stiffness of the spring in the form of array, given the
                |     degree of freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which stiffness is
                |             asked.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         oForceArray
                |             The array of force values.
                |         oDispArray
                |             The array of displacement values.
                | 
                |             Refer: CATSafeArrayVariant
                | 
                | o Sub ReadStiffnessDataFromFile(SpringDof_Type iDof,
                | CATBSTR iFileName)
                | 
                |     Reads stiffness data from a text file for a spring connection
                |     property.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which stiffness is
                |             asked.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         iFileName
                |             The complete path of the text file which contains the stiffness
                |             data.
                | 
                | o Sub RemoveAxisSystem()
                | 
                | o Sub RemoveDof(SpringDof_Type iDof)
                | 
                |     Unsets the stiffness of the spring for given degree of
                |     freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which stiffness is set.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                | o Sub SetLinearStiffness(SpringDof_Type iDof,
                | double iStiffnessValue)
                | 
                |     Sets the linear stiffness of the spring given the degree of
                |     freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which stiffness is set.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         iStiffnessValue
                |             The stiffnessvalue.
                | 
                | o Sub SetNonLinearStiffness(SpringDof_Type iDof,
                | CATSafeArrayVariant iForceArray,
                | CATSafeArrayVariant iDispArray)
                | 
                |     Sets the non-linear stiffness of the spring in the form of array, given the
                |     degree of freedom.
                | 
                |     Parameters:
                | 
                |         iDof
                |             The degree of freedom for which stiffness is
                |             asked.
                | 
                | 
                |             Legal values:
                | 
                |             U1_DOF
                |             U2_DOF
                |             U3_DOF
                |             UR1_DOF
                |             UR2_DOF
                |             UR3_DOF
                | 
                |         iForceArray
                |             The array of force values.
                |         iDispArray
                |             The array of displacement values.
                |             The value in displacement array must be greater than previous value
                |             .
                | 
                |             Refer: CATSafeArrayVariant

        :return: int
        :rtype: int
        """

        return self.abq_spring_connection_property.SpringType

    @spring_type.setter
    def spring_type(self, value: int):
        """
        :param int value:
        """

        self.abq_spring_connection_property.SpringType = value

    def __repr__(self):
        return f'AbqSpringConnectionProperty(name="{ self.name }")'
