#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class AbqInteraction(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ABQInteraction
                | 
                | Represents the base interface for Abaqus interaction objects.
                | Role: The ABQInteraction interface manages the common properties of any
                | interaction.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_interaction = com_object

    @property
    def type(self) -> str:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property Type() As CATBSTR (Read Only)
                | 
                |     Returns the type of the Interaction.
                | 
                |     Returns:
                |         The type of the Interaction.

        :return: str
        :rtype: str
        """

        return self.abq_interaction.Type

    def __repr__(self):
        return f'AbqInteraction(name="{ self.name }")'
