#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.in_interfaces.reference import Reference
from pycatia.mec_mod_interfaces.hybrid_shape import HybridShape


class HybridShapeNear(HybridShape):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     MecModInterfaces.HybridShape
                |                         HybridShapeNear
                | 
                | The Near feature : an Near is made up of a face to process and one Near parameter.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.hybrid_shape_near = com_object

    @property
    def multiple_solution(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property MultipleSolution() As Reference
                | 
                |     Role: To get_MultipleSolution on the object.
                | 
                |     Parameters:
                | 
                |         oMultipleSolution
                |             multiple element return value for CATScript applications, with
                |             (IDLRETVAL) function type 
                | 
                |     See also:
                |         Reference 
                |     Returns:
                |         HRESULT S_OK if Ok E_FAIL else return error code for C++
                |         Implementations 
                |     See also:
                |         HybridShapeFactory

        :return: Reference
        """

        return Reference(self.hybrid_shape_near.MultipleSolution)

    @multiple_solution.setter
    def multiple_solution(self, value):
        """
        :param Reference value:
        """

        self.hybrid_shape_near.MultipleSolution = value

    @property
    def reference_element(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property ReferenceElement() As Reference
                | 
                |     Role: To get_ReferenceElement on the object.
                | 
                |     Parameters:
                | 
                |         oRefElem
                |             reference element return value for CATScript applications, with
                |             (IDLRETVAL) function type 
                | 
                |     See also:
                |         Reference 
                |     Returns:
                |         HRESULT S_OK if Ok E_FAIL else return error code for C++
                |         Implementations 
                |     See also:
                |         HybridShapeFactory

        :return: Reference
        """

        return Reference(self.hybrid_shape_near.ReferenceElement)

    @reference_element.setter
    def reference_element(self, value):
        """
        :param Reference value:
        """

        self.hybrid_shape_near.ReferenceElement = value

    def __repr__(self):
        return f'HybridShapeNear(name="{ self.name }")'
