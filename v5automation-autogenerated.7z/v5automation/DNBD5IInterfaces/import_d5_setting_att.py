#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.setting_controller import SettingController


class ImportD5SettingAtt(SettingController):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     System.SettingController
                |                         ImportD5SettingAtt
                | 
                | Interface to handle parameters of General-Compatibility-DELMIA D5 Tools Options
                | Tab page.
                | Role: This interface is implemented by a component which represents the
                | controller of DELMIA D5 Tools Options parameter settings.
                | 
                |     Methods to set value of each parameter xxx
                |     Methods to get value of each parameter xxx
                |     Methods to get information on each parameter xxx
                |     Methods to lock/unlock value of each parameter xxx
                | 
                | Here are the list of parameters to use and their meanings:
                | 
                |     ImportLibrary: define the D5 root libraries. For several libraries, they
                |     are separated by the character ;.
                |         D:\Syslib;D:\Robotlib; for Windows
                |         /usr/deneb/Syslib;/usr/deneb/Robotlib; for UNIX 
                |     ImportConfigFile: defines the configuration file to
                |     append.
                |     ImportConfigFile: defines the configuration file to
                |     append.
                |     ImportPDBCache : defines the D5 pdb cache directory for UG files.
                |     ImportRecording : defines the option for importing D5 recording file into V5 replays.
                |     ImportUserViews : defines the option for importing D5 user views into V5 cameras. For workcells only.
                |     ImportAnnotation: defines the option for importing D5 annotations into V5
                |     3D annotations. For workcells only.
                |     ImportWclMessage: defines the option for displaying the D5 workcell
                |     messages after importing. Message is stored on the product. For workcells
                |     only.
                |     ImportCollision : defines the option for importing D5 collision queues into V5 interferences objects. For workcells only.
                |     ImportFloor : defines the option for importing D5 floor into V5 Area. For workcells only.
                |     ImportUserAttr : defines the option for importing D5 user attributes into V5 knowledgeware parameters.
                |     ImportEdge : defines the option for importing D5 geometric (edge) information.
                |     ImportCoorsys : defines the option for importing D5 coorsys into V5 frames of interests (by default as DESIGN).
                |     ImportToolFrm : defines the option for importing D5 tool frame into V5 frames of interests (by default as TOOL).
                |     ImportBaseFrm : defines the option for importing D5 base frame into V5 base frames of interests (by default as BASE).
                |     ImportWclPath : defines the option for importing D5 workcell paths into V5 frames of interests (by default as MANUFACTURING).
                |     VisCoorsys : defines the visibility status at the import of D5 coorsys.
                |     VisToolFrm : defines the visibility status at the import of D5 tool frame.
                |     VisBaseFrm : defines the visibility status at the import of D5 base frame.
                |     VisWclPath : defines the visibility status at the import of D5 workcell paths.
                |     TypeCoorsys : defines the V5 frame of interest matching type when importing D5 coorsys.
                |     TypeToolFrm : defines the V5 frame of interest matching type when importing D5 tool frame.
                |     TypeBaseFrm : defines the V5 frame of interest matching type when importing D5 base frame.
                |     TypeWclPath : defines the V5 frame of interest matching type when importing D5 workcell paths.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.import_d5_setting_att = com_object

    @property
    def import_annotation(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportAnnotation() As boolean
                | 
                |     Returns or sets the ImportAnnotation parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportAnnotation

    @import_annotation.setter
    def import_annotation(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportAnnotation = value

    @property
    def import_base_frm(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportBaseFrm() As boolean
                | 
                |     Returns or sets the ImportBaseFrm parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportBaseFrm

    @import_base_frm.setter
    def import_base_frm(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportBaseFrm = value

    @property
    def import_collision(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportCollision() As boolean
                | 
                |     Returns or sets the ImportCollision parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportCollision

    @import_collision.setter
    def import_collision(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportCollision = value

    @property
    def import_config_file(self) -> str:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportConfigFile() As CATBSTR
                | 
                |     Returns or sets the ImportConfigFile parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: str
        :rtype: str
        """

        return self.import_d5_setting_att.ImportConfigFile

    @import_config_file.setter
    def import_config_file(self, value: str):
        """
        :param str value:
        """

        self.import_d5_setting_att.ImportConfigFile = value

    @property
    def import_coorsys(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportCoorsys() As boolean
                | 
                |     Returns or sets the ImportCoorsys parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportCoorsys

    @import_coorsys.setter
    def import_coorsys(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportCoorsys = value

    @property
    def import_edge(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportEdge() As boolean
                | 
                |     Returns or sets the ImportEdge parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportEdge

    @import_edge.setter
    def import_edge(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportEdge = value

    @property
    def import_floor(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportFloor() As boolean
                | 
                |     Returns or sets the ImportFloor parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportFloor

    @import_floor.setter
    def import_floor(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportFloor = value

    @property
    def import_library(self) -> str:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportLibrary() As CATBSTR
                | 
                |     Returns or sets the ImportLibrary parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: str
        :rtype: str
        """

        return self.import_d5_setting_att.ImportLibrary

    @import_library.setter
    def import_library(self, value: str):
        """
        :param str value:
        """

        self.import_d5_setting_att.ImportLibrary = value

    @property
    def import_pdb_cache(self) -> str:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportPDBCache() As CATBSTR
                | 
                |     Returns or sets the ImportPDBCache parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: str
        :rtype: str
        """

        return self.import_d5_setting_att.ImportPDBCache

    @import_pdb_cache.setter
    def import_pdb_cache(self, value: str):
        """
        :param str value:
        """

        self.import_d5_setting_att.ImportPDBCache = value

    @property
    def import_recording(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportRecording() As boolean
                | 
                |     Returns or sets the ImportRecording parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportRecording

    @import_recording.setter
    def import_recording(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportRecording = value

    @property
    def import_tool_frm(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportToolFrm() As boolean
                | 
                |     Returns or sets the ImportToolFrm parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportToolFrm

    @import_tool_frm.setter
    def import_tool_frm(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportToolFrm = value

    @property
    def import_user_attr(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportUserAttr() As boolean
                | 
                |     Returns or sets the ImportUserAttr parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportUserAttr

    @import_user_attr.setter
    def import_user_attr(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportUserAttr = value

    @property
    def import_user_views(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportUserViews() As boolean
                | 
                |     Returns or sets the ImportUserViews parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportUserViews

    @import_user_views.setter
    def import_user_views(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportUserViews = value

    @property
    def import_wcl_message(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportWclMessage() As boolean
                | 
                |     Returns or sets the ImportWclMessage parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportWclMessage

    @import_wcl_message.setter
    def import_wcl_message(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportWclMessage = value

    @property
    def import_wcl_path(self) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ImportWclPath() As boolean
                | 
                |     Returns or sets the ImportWclPath parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        :rtype: bool
        """

        return self.import_d5_setting_att.ImportWclPath

    @import_wcl_path.setter
    def import_wcl_path(self, value: bool):
        """
        :param bool value:
        """

        self.import_d5_setting_att.ImportWclPath = value

    @property
    def type_base_frm(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property TypeBaseFrm() As long
                | 
                |     Returns or sets the TypeBaseFrm parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: int
        :rtype: int
        """

        return self.import_d5_setting_att.TypeBaseFrm

    @type_base_frm.setter
    def type_base_frm(self, value: int):
        """
        :param int value:
        """

        self.import_d5_setting_att.TypeBaseFrm = value

    @property
    def type_coorsys(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property TypeCoorsys() As long
                | 
                |     Returns or sets the TypeCoorsys parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: int
        :rtype: int
        """

        return self.import_d5_setting_att.TypeCoorsys

    @type_coorsys.setter
    def type_coorsys(self, value: int):
        """
        :param int value:
        """

        self.import_d5_setting_att.TypeCoorsys = value

    @property
    def type_tool_frm(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property TypeToolFrm() As long
                | 
                |     Returns or sets the TypeToolFrm parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: int
        :rtype: int
        """

        return self.import_d5_setting_att.TypeToolFrm

    @type_tool_frm.setter
    def type_tool_frm(self, value: int):
        """
        :param int value:
        """

        self.import_d5_setting_att.TypeToolFrm = value

    @property
    def type_wcl_path(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property TypeWclPath() As long
                | 
                |     Returns or sets the TypeWclPath parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: int
        :rtype: int
        """

        return self.import_d5_setting_att.TypeWclPath

    @type_wcl_path.setter
    def type_wcl_path(self, value: int):
        """
        :param int value:
        """

        self.import_d5_setting_att.TypeWclPath = value

    @property
    def vis_base_frm(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property VisBaseFrm() As FrameVisibility
                | 
                |     Returns or sets the VisBaseFrm parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: int
        :rtype: int
        """

        return self.import_d5_setting_att.VisBaseFrm

    @vis_base_frm.setter
    def vis_base_frm(self, value: int):
        """
        :param int value:
        """

        self.import_d5_setting_att.VisBaseFrm = value

    @property
    def vis_coorsys(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property VisCoorsys() As FrameVisibility
                | 
                |     Returns or sets the VisCoorsys parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: int
        :rtype: int
        """

        return self.import_d5_setting_att.VisCoorsys

    @vis_coorsys.setter
    def vis_coorsys(self, value: int):
        """
        :param int value:
        """

        self.import_d5_setting_att.VisCoorsys = value

    @property
    def vis_tool_frm(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property VisToolFrm() As FrameVisibility
                | 
                |     Returns or sets the VisToolFrm parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: int
        :rtype: int
        """

        return self.import_d5_setting_att.VisToolFrm

    @vis_tool_frm.setter
    def vis_tool_frm(self, value: int):
        """
        :param int value:
        """

        self.import_d5_setting_att.VisToolFrm = value

    @property
    def vis_wcl_path(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property VisWclPath() As FrameVisibility
                | 
                |     Returns or sets the VisWclPath parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: int
        :rtype: int
        """

        return self.import_d5_setting_att.VisWclPath

    @vis_wcl_path.setter
    def vis_wcl_path(self, value: int):
        """
        :param int value:
        """

        self.import_d5_setting_att.VisWclPath = value

    def get_import_annotation_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportAnnotationInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportAnnotation
                |     parameter.
                |     Role:Retrieves the state of the ImportAnnotation parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportAnnotationInfo(io_admin_level, io_locked)

    def get_import_base_frm_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportBaseFrmInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportBaseFrm
                |     parameter.
                |     Role:Retrieves the state of the ImportBaseFrm parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportBaseFrmInfo(io_admin_level, io_locked)

    def get_import_collision_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportCollisionInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportCollision
                |     parameter.
                |     Role:Retrieves the state of the ImportCollision parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportCollisionInfo(io_admin_level, io_locked)

    def get_import_config_file_expanded(self) -> str:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportConfigFileExpanded() As CATBSTR
                | 
                |     Returns the ImportConfigFile parameter (manages expanded file
                |     pathnames).
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: str
        :rtype: str
        """
        return self.import_d5_setting_att.GetImportConfigFileExpanded()

    def get_import_config_file_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportConfigFileInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportConfigFile
                |     parameter.
                |     Role:Retrieves the state of the ImportConfigFile parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportConfigFileInfo(io_admin_level, io_locked)

    def get_import_coorsys_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportCoorsysInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportCoorsys
                |     parameter.
                |     Role:Retrieves the state of the ImportCoorsys parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportCoorsysInfo(io_admin_level, io_locked)

    def get_import_edge_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportEdgeInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportEdge
                |     parameter.
                |     Role:Retrieves the state of the ImportEdge parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportEdgeInfo(io_admin_level, io_locked)

    def get_import_floor_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportFloorInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportFloor
                |     parameter.
                |     Role:Retrieves the state of the ImportFloor parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportFloorInfo(io_admin_level, io_locked)

    def get_import_library_expanded(self) -> str:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportLibraryExpanded() As CATBSTR
                | 
                |     Returns the ImportLibrary parameter (manages expanded file
                |     pathnames).
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: str
        :rtype: str
        """
        return self.import_d5_setting_att.GetImportLibraryExpanded()

    def get_import_library_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportLibraryInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportLibrary
                |     parameter.
                |     Role:Retrieves the state of the ImportLibrary parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportLibraryInfo(io_admin_level, io_locked)

    def get_import_pdb_cache_expanded(self) -> str:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportPDBCacheExpanded() As CATBSTR
                | 
                |     Returns the ImportPDBCache parameter (manages expanded file
                |     pathnames).
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: str
        :rtype: str
        """
        return self.import_d5_setting_att.GetImportPDBCacheExpanded()

    def get_import_pdb_cache_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportPDBCacheInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportPDBCache
                |     parameter.
                |     Role:Retrieves the state of the ImportPDBCache parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportPDBCacheInfo(io_admin_level, io_locked)

    def get_import_recording_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportRecordingInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportRecording
                |     parameter.
                |     Role:Retrieves the state of the ImportRecording parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportRecordingInfo(io_admin_level, io_locked)

    def get_import_tool_frm_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportToolFrmInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportToolFrm
                |     parameter.
                |     Role:Retrieves the state of the ImportToolFrm parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportToolFrmInfo(io_admin_level, io_locked)

    def get_import_user_attr_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportUserAttrInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportUserAttr
                |     parameter.
                |     Role:Retrieves the state of the ImportUserAttr parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportUserAttrInfo(io_admin_level, io_locked)

    def get_import_user_views_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportUserViewsInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportUserViews
                |     parameter.
                |     Role:Retrieves the state of the ImportUserViews parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportUserViewsInfo(io_admin_level, io_locked)

    def get_import_wcl_message_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportWclMessageInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportWclMessage
                |     parameter.
                |     Role:Retrieves the state of the ImportWclMessage parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportWclMessageInfo(io_admin_level, io_locked)

    def get_import_wcl_path_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetImportWclPathInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ImportWclPath
                |     parameter.
                |     Role:Retrieves the state of the ImportWclPath parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetImportWclPathInfo(io_admin_level, io_locked)

    def get_type_base_frm_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetTypeBaseFrmInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the TypeBaseFrm
                |     parameter.
                |     Role:Retrieves the state of the TypeBaseFrm parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetTypeBaseFrmInfo(io_admin_level, io_locked)

    def get_type_coorsys_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetTypeCoorsysInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the TypeCoorsys
                |     parameter.
                |     Role:Retrieves the state of the TypeCoorsys parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetTypeCoorsysInfo(io_admin_level, io_locked)

    def get_type_tool_frm_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetTypeToolFrmInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the TypeToolFrm
                |     parameter.
                |     Role:Retrieves the state of the TypeToolFrm parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetTypeToolFrmInfo(io_admin_level, io_locked)

    def get_type_wcl_path_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetTypeWclPathInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the TypeWclPath
                |     parameter.
                |     Role:Retrieves the state of the TypeWclPath parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetTypeWclPathInfo(io_admin_level, io_locked)

    def get_vis_base_frm_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetVisBaseFrmInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the VisBaseFrm
                |     parameter.
                |     Role:Retrieves the state of the VisBaseFrm parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetVisBaseFrmInfo(io_admin_level, io_locked)

    def get_vis_coorsys_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetVisCoorsysInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the VisCoorsys
                |     parameter.
                |     Role:Retrieves the state of the VisCoorsys parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetVisCoorsysInfo(io_admin_level, io_locked)

    def get_vis_tool_frm_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetVisToolFrmInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the VisToolFrm
                |     parameter.
                |     Role:Retrieves the state of the VisToolFrm parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetVisToolFrmInfo(io_admin_level, io_locked)

    def get_vis_wcl_path_info(self, io_admin_level: str, io_locked: str) -> bool:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func GetVisWclPathInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the VisWclPath
                |     parameter.
                |     Role:Retrieves the state of the VisWclPath parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        :rtype: bool
        """
        return self.import_d5_setting_att.GetVisWclPathInfo(io_admin_level, io_locked)

    def set_import_annotation_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportAnnotationLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportAnnotation parameter.
                |     Role:Locks or unlocks the ImportAnnotation parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportAnnotationLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_annotation_lock'
        # # vba_code = """
        # # Public Function set_import_annotation_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportAnnotationLock iLocked
        # #     set_import_annotation_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_base_frm_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportBaseFrmLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportBaseFrm parameter.
                |     Role:Locks or unlocks the ImportBaseFrm parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportBaseFrmLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_base_frm_lock'
        # # vba_code = """
        # # Public Function set_import_base_frm_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportBaseFrmLock iLocked
        # #     set_import_base_frm_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_collision_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportCollisionLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportCollision parameter.
                |     Role:Locks or unlocks the ImportCollision parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportCollisionLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_collision_lock'
        # # vba_code = """
        # # Public Function set_import_collision_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportCollisionLock iLocked
        # #     set_import_collision_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_config_file_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportConfigFileLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportConfigFile parameter.
                |     Role:Locks or unlocks the ImportConfigFile parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportConfigFileLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_config_file_lock'
        # # vba_code = """
        # # Public Function set_import_config_file_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportConfigFileLock iLocked
        # #     set_import_config_file_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_coorsys_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportCoorsysLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportCoorsys parameter.
                |     Role:Locks or unlocks the ImportCoorsys parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportCoorsysLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_coorsys_lock'
        # # vba_code = """
        # # Public Function set_import_coorsys_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportCoorsysLock iLocked
        # #     set_import_coorsys_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_edge_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportEdgeLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportEdge parameter.
                |     Role:Locks or unlocks the ImportEdge parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportEdgeLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_edge_lock'
        # # vba_code = """
        # # Public Function set_import_edge_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportEdgeLock iLocked
        # #     set_import_edge_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_floor_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportFloorLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportFloor parameter.
                |     Role:Locks or unlocks the ImportFloor parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportFloorLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_floor_lock'
        # # vba_code = """
        # # Public Function set_import_floor_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportFloorLock iLocked
        # #     set_import_floor_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_library_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportLibraryLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportLibrary parameter.
                |     Role:Locks or unlocks the ImportLibrary parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportLibraryLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_library_lock'
        # # vba_code = """
        # # Public Function set_import_library_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportLibraryLock iLocked
        # #     set_import_library_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_pdb_cache_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportPDBCacheLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportPDBCache parameter.
                |     Role:Locks or unlocks the ImportPDBCache parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportPDBCacheLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_pdb_cache_lock'
        # # vba_code = """
        # # Public Function set_import_pdb_cache_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportPDBCacheLock iLocked
        # #     set_import_pdb_cache_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_recording_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportRecordingLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportRecording parameter.
                |     Role:Locks or unlocks the ImportRecording parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportRecordingLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_recording_lock'
        # # vba_code = """
        # # Public Function set_import_recording_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportRecordingLock iLocked
        # #     set_import_recording_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_tool_frm_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportToolFrmLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportToolFrm parameter.
                |     Role:Locks or unlocks the ImportToolFrm parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportToolFrmLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_tool_frm_lock'
        # # vba_code = """
        # # Public Function set_import_tool_frm_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportToolFrmLock iLocked
        # #     set_import_tool_frm_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_user_attr_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportUserAttrLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportUserAttr parameter.
                |     Role:Locks or unlocks the ImportUserAttr parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportUserAttrLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_user_attr_lock'
        # # vba_code = """
        # # Public Function set_import_user_attr_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportUserAttrLock iLocked
        # #     set_import_user_attr_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_user_views_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportUserViewsLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportUserViews parameter.
                |     Role:Locks or unlocks the ImportUserViews parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportUserViewsLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_user_views_lock'
        # # vba_code = """
        # # Public Function set_import_user_views_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportUserViewsLock iLocked
        # #     set_import_user_views_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_wcl_message_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportWclMessageLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportWclMessage parameter.
                |     Role:Locks or unlocks the ImportWclMessage parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportWclMessageLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_wcl_message_lock'
        # # vba_code = """
        # # Public Function set_import_wcl_message_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportWclMessageLock iLocked
        # #     set_import_wcl_message_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_import_wcl_path_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetImportWclPathLock(boolean iLocked)
                | 
                |     Locks or unlocks the ImportWclPath parameter.
                |     Role:Locks or unlocks the ImportWclPath parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetImportWclPathLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_import_wcl_path_lock'
        # # vba_code = """
        # # Public Function set_import_wcl_path_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetImportWclPathLock iLocked
        # #     set_import_wcl_path_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_type_base_frm_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetTypeBaseFrmLock(boolean iLocked)
                | 
                |     Locks or unlocks the TypeBaseFrm parameter.
                |     Role:Locks or unlocks the TypeBaseFrm parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetTypeBaseFrmLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_type_base_frm_lock'
        # # vba_code = """
        # # Public Function set_type_base_frm_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetTypeBaseFrmLock iLocked
        # #     set_type_base_frm_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_type_coorsys_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetTypeCoorsysLock(boolean iLocked)
                | 
                |     Locks or unlocks the TypeCoorsys parameter.
                |     Role:Locks or unlocks the TypeCoorsys parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetTypeCoorsysLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_type_coorsys_lock'
        # # vba_code = """
        # # Public Function set_type_coorsys_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetTypeCoorsysLock iLocked
        # #     set_type_coorsys_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_type_tool_frm_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetTypeToolFrmLock(boolean iLocked)
                | 
                |     Locks or unlocks the TypeToolFrm parameter.
                |     Role:Locks or unlocks the TypeToolFrm parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetTypeToolFrmLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_type_tool_frm_lock'
        # # vba_code = """
        # # Public Function set_type_tool_frm_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetTypeToolFrmLock iLocked
        # #     set_type_tool_frm_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_type_wcl_path_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetTypeWclPathLock(boolean iLocked)
                | 
                |     Locks or unlocks the TypeWclPath parameter.
                |     Role:Locks or unlocks the TypeWclPath parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetTypeWclPathLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_type_wcl_path_lock'
        # # vba_code = """
        # # Public Function set_type_wcl_path_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetTypeWclPathLock iLocked
        # #     set_type_wcl_path_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_vis_base_frm_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetVisBaseFrmLock(boolean iLocked)
                | 
                |     Locks or unlocks the VisBaseFrm parameter.
                |     Role:Locks or unlocks the VisBaseFrm parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetVisBaseFrmLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_vis_base_frm_lock'
        # # vba_code = """
        # # Public Function set_vis_base_frm_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetVisBaseFrmLock iLocked
        # #     set_vis_base_frm_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_vis_coorsys_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetVisCoorsysLock(boolean iLocked)
                | 
                |     Locks or unlocks the VisCoorsys parameter.
                |     Role:Locks or unlocks the VisCoorsys parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetVisCoorsysLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_vis_coorsys_lock'
        # # vba_code = """
        # # Public Function set_vis_coorsys_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetVisCoorsysLock iLocked
        # #     set_vis_coorsys_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_vis_tool_frm_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetVisToolFrmLock(boolean iLocked)
                | 
                |     Locks or unlocks the VisToolFrm parameter.
                |     Role:Locks or unlocks the VisToolFrm parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetVisToolFrmLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_vis_tool_frm_lock'
        # # vba_code = """
        # # Public Function set_vis_tool_frm_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetVisToolFrmLock iLocked
        # #     set_vis_tool_frm_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_vis_wcl_path_lock(self, i_locked: bool) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub SetVisWclPathLock(boolean iLocked)
                | 
                |     Locks or unlocks the VisWclPath parameter.
                |     Role:Locks or unlocks the VisWclPath parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        :rtype: None
        """
        return self.import_d5_setting_att.SetVisWclPathLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_vis_wcl_path_lock'
        # # vba_code = """
        # # Public Function set_vis_wcl_path_lock(import_d5_setting_att)
        # #     Dim iLocked (2)
        # #     import_d5_setting_att.SetVisWclPathLock iLocked
        # #     set_vis_wcl_path_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def __repr__(self):
        return f'ImportD5SettingAtt(name="{ self.name }")'
