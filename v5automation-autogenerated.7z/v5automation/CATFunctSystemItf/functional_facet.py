#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class FunctionalFacet(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     FunctionalFacet
                | 
                | The interface to access a Functional Facet.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.functional_facet = com_object

    @property
    def functional_element(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property FunctionalElement() As FunctionalElement (Read
                | Only)
                | 
                |     Get the Functional Element owning the Facet.

        :return: FunctionalElement
        """

        return FunctionalElement(self.functional_facet.FunctionalElement)

    def free(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub Free()
                | 
                |     Free the resources allocated by the Facet.

        :return: None
        """
        return self.functional_facet.Free()

    def init(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub Init()
                | 
                |     Init resources for the Facet.

        :return: None
        """
        return self.functional_facet.Init()

    def __repr__(self):
        return f'FunctionalFacet(name="{ self.name }")'
