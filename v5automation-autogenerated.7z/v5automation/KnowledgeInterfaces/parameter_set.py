#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-09-25 14:34:21.593357

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.knowledge_interfaces.parameters import Parameters
from pycatia.system_interfaces.any_object import AnyObject


class ParameterSet(AnyObject):

    """
        .. note::
            :class: toggle

            CAA V5 Visual Basic Help (2020-09-25 14:34:21.593357)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     ParameterSet
                | 
                | Represents parameter set.
                | It is the node that contains user parameters.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.parameter_set = com_object

    @property
    def all_parameters(self) -> Parameters:
        """
        .. note::
            :class: toggle

            CAA V5 Visual Basic Help (2020-09-25 14:34:21.593357)
                | o Property AllParameters() As Parameters (Read Only)
                | 
                |     Returns all parameters under this set of parameter.

        :return: Parameters
        :rtype: Parameters
        """

        return Parameters(self.parameter_set.AllParameters)

    @property
    def direct_parameters(self) -> Parameters:
        """
        .. note::
            :class: toggle

            CAA V5 Visual Basic Help (2020-09-25 14:34:21.593357)
                | o Property DirectParameters() As Parameters (Read Only)
                | 
                |     Returns directly aggregated parameters.

        :return: Parameters
        :rtype: Parameters
        """

        return Parameters(self.parameter_set.DirectParameters)

    @property
    def parameter_sets(self) -> ParameterSets:
        """
        .. note::
            :class: toggle

            CAA V5 Visual Basic Help (2020-09-25 14:34:21.593357)
                | o Property ParameterSets() As ParameterSets (Read Only)
                | 
                |     Returns the children parameter sets.

        :return: ParameterSets
        :rtype: ParameterSets
        """

        return ParameterSets(self.parameter_set.ParameterSets)

    def __repr__(self):
        return f'ParameterSet(name="{ self.name }")'
