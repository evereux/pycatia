#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.knowledge_interfaces.relation import Relation


class Law(Relation):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     KnowledgeInterfaces.KnowledgeObject
                |                        
KnowledgeInterfaces.KnowledgeActivateObject                |                             KnowledgeInterfaces.Relation
                |                                 Law
                | 
                | Represents the Law object.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.law = com_object

    def add_formal_parameter(self, i_name=None, i_magnitude=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub AddFormalParameter(CATBSTR iName,
                | CATBSTR iMagnitude)
                | 
                |     Creates a formal parameter for the law.
                | 
                |     Parameters:
                | 
                |         iName
                |             The name of the formal parameter. 
                |         iType
                |             The type name of the formal parameter.

        :param str i_name:
        :param str i_magnitude:
        :return: None
        """
        return self.law.AddFormalParameter(i_name, i_magnitude)

    def remove_formal_parameter(self, i_name=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub RemoveFormalParameter(CATBSTR iName)
                | 
                |     Removes a formal parameter of the law.
                | 
                |     Parameters:
                | 
                |         iName
                |             The name of the formal parameter.

        :param str i_name:
        :return: None
        """
        return self.law.RemoveFormalParameter(i_name)

    def __repr__(self):
        return f'Law(name="{ self.name }")'
