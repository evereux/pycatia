#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class AnnotationSet(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     AnnotationSet
                | 
                | Interface for the TPS Set of objects.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.annotation_set = com_object

    @property
    def active_view(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property ActiveView() As TPSView
                | 
                |     Gets or Sets Annotation Set ActiveView.
                | 
                |     Parameters:
                | 
                |         oView
                |             Value of CATIATPSView.

        :return: TPSView
        """

        return TPSView(self.annotation_set.ActiveView)

    @active_view.setter
    def active_view(self, value):
        """
        :param TPSView value:
        """

        self.annotation_set.ActiveView = value

    @property
    def an_empty_annotations_list(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnEmptyAnnotationsList() As Annotations (Read
                | Only)
                | 
                |     Retrieves an empty Annotations'Collection.
                | 
                |     Parameters:
                | 
                |         oAnnots
                |             Empty Annotations' Collection.

        :return: Annotations
        """

        return Annotations(self.annotation_set.AnEmptyAnnotationsList)

    @property
    def annotation_factory(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnnotationFactory() As AnnotationFactory (Read
                | Only)
                | 
                |     Obtain the factory to create annotations.
                | 
                |     Parameters:
                | 
                |         oAFact
                |             Annotations' factory.

        :return: AnnotationFactory
        """

        return AnnotationFactory(self.annotation_set.AnnotationFactory)

    @property
    def annotation_factory2(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnnotationFactory2() As AnnotationFactory2 (Read
                | Only)
                | 
                |     Obtain the factory to create annotations.
                | 
                |     Parameters:
                | 
                |         oAFact
                |             Annotations' factory.

        :return: AnnotationFactory2
        """

        return AnnotationFactory2(self.annotation_set.AnnotationFactory2)

    @property
    def annotation_set_type(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnnotationSetType() As CatAnnotationSetType (Read
                | Only)
                | 
                |     Get the annotation Set type.
                | 
                |     Parameters:
                | 
                |         oAnnotationSetType
                |             Value of Set Type.

        :return: enum cat_annotation_set_type
        """

        return self.annotation_set.AnnotationSetType

    @property
    def annotations(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Annotations() As Annotations (Read Only)
                | 
                |     Retrieves the TPS components of the set.
                | 
                |     Parameters:
                | 
                |         oAnnots
                |             Collection of returned component.

        :return: Annotations
        """

        return Annotations(self.annotation_set.Annotations)

    @property
    def capture_factory(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property CaptureFactory() As CaptureFactory (Read Only)
                | 
                |     Obtain the factory to create Capture.
                | 
                |     Parameters:
                | 
                |         opiCapFact
                |             Capture factory.

        :return: CaptureFactory
        """

        return CaptureFactory(self.annotation_set.CaptureFactory)

    @property
    def captures(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Captures() As Captures (Read Only)
                | 
                |     Retrieves all the Captures that belong to the set.
                | 
                |     Parameters:
                | 
                |         oCaptures
                |             Collection of returned Captures.

        :return: Captures
        """

        return Captures(self.annotation_set.Captures)

    @property
    def kind_of_set(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property KindOfSet() As CATBSTR (Read Only)
                | 
                |     Give the kind of set (Part, Product...).
                | 
                |     Parameters:
                | 
                |         oKindOfSet
                |             It could be : Part Product Product_TP Process_BB Cgr Cgr_TP.

        :return: str
        """

        return self.annotation_set.KindOfSet

    @property
    def standard(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property Standard() As CATBSTR (Read Only)
                | 
                |     Retrieves the Parent Standard defined at set creation.
                | 
                |     Parameters:
                | 
                |         oStandard
                |             Name of the Parent Standard applied for all TPS in the set. The
                |             Parent Standard is the international standard on which Standard File is based
                |             on. It can only be ISO, ANSI and JIS. (ANSI stands for
                |             ASME).

        :return: str
        """

        return self.annotation_set.Standard

    @property
    def switch_on(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property SwitchOn() As boolean
                | 
                |     Gets or Sets Annotation Set Visualization.
                | 
                |     Parameters:
                | 
                |         oDisplay
                |             Value of visualisation mode.

        :return: bool
        """

        return self.annotation_set.SwitchOn

    @switch_on.setter
    def switch_on(self, value):
        """
        :param bool value:
        """

        self.annotation_set.SwitchOn = value

    @property
    def tps_view_factory(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property TPSViewFactory() As TPSViewFactory (Read Only)
                | 
                |     Obtain the factory to create TPS Views.
                | 
                |     Parameters:
                | 
                |         oTPSViewFact
                |             TPS Views' factory.

        :return: TPSViewFactory
        """

        return TPSViewFactory(self.annotation_set.TPSViewFactory)

    @property
    def tps_views(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property TPSViews() As TPSViews (Read Only)
                | 
                |     Retrieves all the TPSViews that belong to the set.
                | 
                |     Parameters:
                | 
                |         oViews
                |             Collection of returned views.

        :return: TPSViews
        """

        return TPSViews(self.annotation_set.TPSViews)

    def apply_view_re_use_when_copy_set_to(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub ApplyViewReUseWhenCopySetTo()
                | 
                |     Register for next call to either GlobalCopySetTo and like
                |     methods.
                | 
                |     See also:
                |         CATIAAnnotationSet#GlobalCopySetTo or CATIAAnnotationSet, they are
                |         placed in existing Views. This call sets an option valid for the next import
                |         run only; in other words, this option is reset at the end of import. When
                |         activated, this option will not break the import processing; if no View in
                |         target set can receive a candidate FTA entity resulting from the import,
                |         regular handling is carried on

        :return: None
        """
        return self.annotation_set.ApplyViewReUseWhenCopySetTo()

    def global_copy_set_to(self, i_destination_part=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GlobalCopySetTo(Part iDestinationPart) As CATBSTR
                | 
                |     Copies the entire or a subpart of a part level Annotation Set into a
                |     destination CATPart
                | 
                |     Parameters:
                | 
                |         iDestinationPart
                |             destination CATPart. 
                |         oMessage
                |             result of datums merge.

        :param Part i_destination_part:
        :return: str
        """
        return self.annotation_set.GlobalCopySetTo(i_destination_part.com_object)

    def global_copy_set_to_with_transformation(self, i_destination_part=None, i_transfo=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GlobalCopySetToWithTransformation(Part
                | iDestinationPart,
                | CATSafeArrayVariant iTransfo) As CATBSTR
                | 
                |     Copies the entire Annotation Set into a destination
                |     CATPart
                | 
                |     Parameters:
                | 
                |         iDestinationPart
                |             destination CATPart. 
                |         iTransfo
                |             Optional argument. Transformation matrix to apply to FTA features
                |             during copy. The transformation is also used for retrieving in the destination
                |             CATPart the geometrical elements the FTA features are rerouted on.
                |             Transformation matrix is composed by a matrix3x3 and a translation vector:
                |             [[a11 a12 a13 a21 a22 a23 a31 a32 a33] [u1 u2 u3]] a11 is in iTransfo(0) a12 is
                |             in iTransfo(1) a13 is in iTransfo(2) a21 is in iTransfo(3) a22 is in
                |             iTransfo(4) a23 is in iTransfo(5) a31 is in iTransfo(6) a32 is in iTransfo(7)
                |             a33 is in iTransfo(8) u1 is in iTransfo(9) u2 is in iTransfo(10) u3 is in
                |             iTransfo(11) 
                |         oMessage
                |             result of datums merge.

        :param Part i_destination_part:
        :param tuple i_transfo:
        :return: str
        """
        return self.annotation_set.GlobalCopySetToWithTransformation(i_destination_part.com_object, i_transfo)

    def __repr__(self):
        return f'AnnotationSet(name="{ self.name }")'
