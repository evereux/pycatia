#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Captures(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     Captures
                | 
                | The interface to access a CATIACaptures
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.captures = com_object

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Item(CATVariant iIndex) As AnyObject
                | 
                |     Retrieve a Capture.

        :param CATVariant i_index:
        :return: AnyObject
        """
        return AnyObject(self.captures.Item(i_index.com_object))

    def __repr__(self):
        return f'Captures(name="{ self.name }")'
