#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class UserSurfaces(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     UserSurfaces

    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.user_surfaces = com_object

    def generate(self, i_support=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func Generate(Reference iSupport) As UserSurface
                | 
                |     Use this method in a Part. Creates a new user surface and adds it to the
                |     Surfaces collection.
                | 
                |     Parameters:
                | 
                |         iSupport
                |             The first reference that will support the user surface
                |             
                | 
                |     Returns:
                |         The created user surface 
                |     Example:
                |         The following example creates a user surface names NewUserSurf from the
                |         reference Ref in the Surfaces collection of the rootPart part in the partDoc
                |         part document.
                | 
                |          Set rootPart = partDoc.Part
                |          Set NewUserSurf = rootPart.UserSurfaces.Add(Ref)

        :param Reference i_support:
        :return: UserSurface
        """
        return UserSurface(self.user_surfaces.Generate(i_support.com_object))

    def generate_in_a_product_ctx(self, i_product=None, i_prod_inst=None, i_support=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GenerateInAProductCtx(Product iProduct,
                | Product iProdInst,
                | Reference iSupport) As UserSurface
                | 
                |     Use this method in a Product. Creates a new user surface and adds it to the
                |     Surfaces collection.
                | 
                |     Parameters:
                | 
                |         iProduct
                |             The level on which you want to create annotation (part or product).
                |             
                |         iProdInst
                |             The product instance where there is the geometry. 
                |         iSupport
                |             The first reference that will support the user surface
                |             
                | 
                |     Returns:
                |         The created user surface

        :param Product i_product:
        :param Product i_prod_inst:
        :param Reference i_support:
        :return: UserSurface
        """
        return UserSurface(self.user_surfaces.GenerateInAProductCtx(i_product.com_object, i_prod_inst.com_object, i_support.com_object))

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func Item(CATVariant iIndex) As UserSurface
                | 
                |     Find a user surface inside the collection.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The position of the users surface in the collection
                |             
                | 
                |     Returns:
                |         The user surface that is in the iIndex position in the collection

        :param CATVariant i_index:
        :return: UserSurface
        """
        return UserSurface(self.user_surfaces.Item(i_index.com_object))

    def make_user_surface_node(self, i_first_user_surf=None, i_second_user_surf=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func MakeUserSurfaceNode(UserSurface iFirstUserSurf,
                | UserSurface iSecondUserSurf) As UserSurface
                | 
                |     Usefull to create a User Surface Node from two others User Surface. Creates
                |     a new user surface and adds it to the Surfaces collection.
                | 
                |     Parameters:
                | 
                |         iFirstUserSurf
                |             The first User Surface to use. 
                |         iSecondUserSurf
                |             The second User Surface to use. 
                | 
                |     Returns:
                |         The created user surface

        :param UserSurface i_first_user_surf:
        :param UserSurface i_second_user_surf:
        :return: UserSurface
        """
        return UserSurface(self.user_surfaces.MakeUserSurfaceNode(i_first_user_surf.com_object, i_second_user_surf.com_object))

    def make_user_surface_node2(self, i_list_of_user_surfaces=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func MakeUserSurfaceNode2(CATSafeArrayVariant iListOfUserSurfaces) As
                | UserSurface
                | 
                |     Usefull to create a User Surface Node from a list of User Surfaces. Creates
                |     a new user surface and adds it to the Surfaces collection.
                | 
                |     Parameters:
                | 
                |         iListOfUserSurfaces
                |             The list User Surfaces to use. 
                | 
                |     Returns:
                |         The created user surface

        :param tuple i_list_of_user_surfaces:
        :return: UserSurface
        """
        return UserSurface(self.user_surfaces.MakeUserSurfaceNode2(i_list_of_user_surfaces))

    def __repr__(self):
        return f'UserSurfaces(name="{ self.name }")'
