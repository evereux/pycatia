#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.drafting_interfaces.drawing_text import DrawingText
from pycatia.system_interfaces.any_object import AnyObject


class Text(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     Text
                | 
                | Interface for the TPS Text object.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.text = com_object

    @property
    def text(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)
                | o Property Text() As CATBSTR
                | 
                |     Gets the annotation's text.

        :return: str
        """

        return self.text.Text

    @text.setter
    def text(self, value):
        """
        :param str value:
        """

        self.text.Text = value

    def get2d_annot(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Get2dAnnot() As DrawingText
                | 
                |     Retrieves Drafting text.

        :return: DrawingText
        """
        return DrawingText(self.text.Get2dAnnot())

    def tps_parallel_on_screen(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func TPSParallelOnScreen() As TPSParallelOnScreen
                | 
                |     Gets the annotation on TPSParallelOnScreen interface.

        :return: TPSParallelOnScreen
        """
        return TPSParallelOnScreen(self.text.TPSParallelOnScreen())

    def __repr__(self):
        return f'Text(name="{ self.name }")'
