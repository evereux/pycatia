#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""




class CollisionFreeWalk(WalkActivity):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     DMAPSInterfaces.Activity
                |                         DNBHumanSimInterfaces.WorkerActivity
                |                             DNBHumanSimInterfaces.WalkActivity
                |                                 CollisionFreeWalk
                | 
                | Interface representing Collision free walk activity
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.collision_free_walk = com_object

    @property
    def collision_clearance(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property CollisionClearance() As double
                | 
                |     Returns and sets the value for 'collision clearance' in a collision free
                |     walk.
                |     Role: Returns and sets the value of 'colllision clearance' from a collision
                |     free walk Activity
                | 
                |     Returns:
                |         Legal values:
                |         S_OK : on Success
                |         E_FAIL: on failure

        :return: float
        """

        return self.collision_free_walk.CollisionClearance

    @collision_clearance.setter
    def collision_clearance(self, value):
        """
        :param float value:
        """

        self.collision_free_walk.CollisionClearance = value

    @property
    def search_intensity(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property SearchIntensity() As HTSSearchIntensity
                | 
                |     Returns and sets the value for 'Search Intensity' in a collision free walk.
                |     Refer DNBIAHumanSimDefs for setting the HTSSearchIntensity
                |     option
                |     Role: Returns and sets the value of 'Search Intensity' from a collision
                |     free walk Activity
                | 
                |     Returns:
                |         Legal values:
                |         S_OK : on Success
                |         E_FAIL: on failure

        :return: enum hts_search_intensity
        """

        return self.collision_free_walk.SearchIntensity

    @search_intensity.setter
    def search_intensity(self, value):
        """
        :param enum hts_search_intensity value:
        """

        self.collision_free_walk.SearchIntensity = value

    def __repr__(self):
        return f'CollisionFreeWalk(name="{ self.name }")'
