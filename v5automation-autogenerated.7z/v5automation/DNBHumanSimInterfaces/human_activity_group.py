#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""




class HumanActivityGroup(WorkerActivity):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     DMAPSInterfaces.Activity
                |                         DNBHumanSimInterfaces.WorkerActivity
                |                             HumanActivityGroup
                | 
                | Interface representing xxx.
                | 
                | Role: Components that implement DNBIAHumanActivityGroup are
                | ...
                | 
                | Do not use the DNBIAHumanActivityGroup interface for such and such
                | ClassReference, Class#MethodReference, #InternalMethod...
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.human_activity_group = com_object

    @property
    def motion_basis(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property MotionBasis() As HTSActivityGroupMotionBasis
                | 
                |     Returns or Sets Motion-Basis (see HTSActivityGroupMotionBasis for list of
                |     possible values)

        :return: int
        :rtype: int
        """

        return self.human_activity_group.MotionBasis

    @motion_basis.setter
    def motion_basis(self, value: int):
        """
        :param int value:
        """

        self.human_activity_group.MotionBasis = value

    @property
    def reference_time(self) -> float:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property ReferenceTime() As double
                | 
                |     Returns or Sets ReferenceTime for HumanActivityGroup Activity

        :return: float
        :rtype: float
        """

        return self.human_activity_group.ReferenceTime

    @reference_time.setter
    def reference_time(self, value: float):
        """
        :param float value:
        """

        self.human_activity_group.ReferenceTime = value

    @property
    def user_speed(self) -> float:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property UserSpeed() As double
                | 
                |     Returns or Sets Speed for HumanActivityGroup Activity

        :return: float
        :rtype: float
        """

        return self.human_activity_group.UserSpeed

    @user_speed.setter
    def user_speed(self, value: float):
        """
        :param float value:
        """

        self.human_activity_group.UserSpeed = value

    @property
    def user_time(self) -> float:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)
                | o Property UserTime() As double
                | 
                |     Returns or Sets Time for HumanActivityGroup Activity

        :return: float
        :rtype: float
        """

        return self.human_activity_group.UserTime

    @user_time.setter
    def user_time(self, value: float):
        """
        :param float value:
        """

        self.human_activity_group.UserTime = value

    def __repr__(self):
        return f'HumanActivityGroup(name="{ self.name }")'
