#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.any_object import AnyObject


class HumanProgram(AnyObject):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     HumanProgram
                | 
                | The object that represents program-node of Worker.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.human_program = com_object

    @property
    def task_list(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property TaskList() As HumanTaskList (Read Only)
                | 
                |     Returns the HumanTaskList from HumanProgram
                | 
                |     Returns:
                |         oTaskList

        :return: HumanTaskList
        """

        return HumanTaskList(self.human_program.TaskList)

    def create_human_task(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func CreateHumanTask() As HumanTask
                | 
                |     Returns newly created HumanTask.
                | 
                |     Returns:
                |         oManikin

        :return: HumanTask
        """
        return HumanTask(self.human_program.CreateHumanTask())

    def __repr__(self):
        return f'HumanProgram(name="{ self.name }")'
