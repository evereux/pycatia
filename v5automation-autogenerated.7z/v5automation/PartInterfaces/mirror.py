#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.in_interfaces.reference import Reference
from pycatia.part_interfaces.transformation_shape import TransformationShape
from pycatia.system_interfaces.any_object import AnyObject


class Mirror(TransformationShape):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     MecModInterfaces.Shape
                |                         PartInterfaces.TransformationShape
                |                             Mirror
                | 
                | Represents the mirror shape.
                | It duplicates a shape with respect to a planar mirroring element, such as a
                | planar face or a plane.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.mirror = com_object

    @property
    def mirroring_object(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property MirroringObject() As AnyObject (Read Only)
                | 
                |     Returns the mirroring Object.

        :return: AnyObject
        """

        return AnyObject(self.mirror.MirroringObject)

    @property
    def mirroring_plane(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property MirroringPlane() As Reference
                | 
                |     Returns or sets the mirroring reference plane. It can be a plane, or a
                |     plane face.
                |     To set the property, you can use the following Boundary object:
                |     PlanarFace.
                | 
                |     Example:
                |         The following example returns in ref the mirroring reference plane of
                |         the mirroring firstMirroring, and then sets it to the created
                |         MyRef:
                | 
                |          Set ref = firstMirroring.MirroringPlane
                |          Set MyRef = part.CreateReferenceFromGeometry (plane)
                |          firstMirroring.MirroringPlane = MyRef

        :return: Reference
        """

        return Reference(self.mirror.MirroringPlane)

    @mirroring_plane.setter
    def mirroring_plane(self, value):
        """
        :param Reference value:
        """

        self.mirror.MirroringPlane = value

    def __repr__(self):
        return f'Mirror(name="{ self.name }")'
