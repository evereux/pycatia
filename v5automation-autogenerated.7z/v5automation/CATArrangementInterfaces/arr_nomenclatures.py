#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class ArrNomenclatures(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     ArrNomenclatures
                | 
                | The collection of UserNomenclature objects.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arr_nomenclatures = com_object

    def add_user_nomenclature(self, i_name=None, i_icon_name=None, i_class_type=None, i_super_type=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func AddUserNomenclature(CATBSTR iName,
                | CATBSTR iIconName,
                | CATBSTR iClassType,
                | CATBSTR iSuperType) As ArrNomenclature
                | 
                |     Creates a new UserNomenclature and adds it to this collection. The
                |     NomenclatureType of the new UserNomenclature will be "User". The base objects
                |     in the UserDictionary are created when the UserDictionary is
                |     created.
                | 
                |     Parameters:
                | 
                |         iName
                |             The user nomenclature name. 
                |         iIconName
                |             The icon name associated to this nomenclature name.
                |             
                | 
                |     Returns:
                |         The new UserNomenclature.

        :param str i_name:
        :param str i_icon_name:
        :param str i_class_type:
        :param str i_super_type:
        :return: ArrNomenclature
        """
        return ArrNomenclature(self.arr_nomenclatures.AddUserNomenclature(i_name, i_icon_name, i_class_type, i_super_type))

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Item(CATVariant iIndex) As ArrNomenclature
                | 
                |     Returns the specified item of the collection
                | 
                |     Parameters:
                | 
                |         iItem
                |             The list index (long) or name (CATBSTR) of the member to retrieve.
                |             
                | 
                |     Returns:
                |         The retrieved member object.

        :param CATVariant i_index:
        :return: ArrNomenclature
        """
        return ArrNomenclature(self.arr_nomenclatures.Item(i_index.com_object))

    def __repr__(self):
        return f'ArrNomenclatures(name="{ self.name }")'
