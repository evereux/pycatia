#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class MaterialFamilies(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     MaterialFamilies
                | 
                | A collection of all the MaterialFamily objects.
                | This collection is currently managed by a CATIAMaterialDocument
                | object.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.material_families = com_object

    def add(self) -> MaterialFamily:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Add() As MaterialFamily
                | 
                |     Adds a new material family to the MaterialFamilies collection.
                |     
                | 
                | Example:
                |     The following adds a material family to the collection attached to a
                |     document. This document must be a MaterialDocument object.
                | 
                |      FileToOpen = "e:\users\ast\materials\Catalog.CATMaterial"
                |      Dim MyDocument As MaterialDocument
                |      Set MyDocument = Documents.Open(FileToOpen)
                |      Dim MyMaterialFamily As MaterialFamily
                |      Set MyMaterialFamily = MyDocument.MaterialFamilies.Add

        :return: MaterialFamily
        :rtype: MaterialFamily
        """
        return MaterialFamily(self.material_families.Add())

    def item(self, i_index: CATVariant) -> MaterialFamily:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Item(CATVariant iIndex) As MaterialFamily
                | 
                |     Returns a material family from its index in the MaterialFamilies
                |     collection.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The index of the material family to retrieve in the collection of
                |             material families. Compared with other collections, you cannot use the name of
                |             the material family as argument. 
                | 
                |     Returns:
                |         The retrieved material family 
                | 
                | Example:
                |     The following example returns in MyMaterialFamily the sixth material family
                |     in the collection.
                | 
                |      Dim MyMaterialFamily As MaterialFamily
                |      Set MyMaterialFamily = MaterialFamilies.Item(6)

        :param CATVariant i_index:
        :return: MaterialFamily
        :rtype: MaterialFamily
        """
        return MaterialFamily(self.material_families.Item(i_index.com_object))

    def remove(self, i_index: CATVariant) -> None:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Sub Remove(CATVariant iIndex)
                | 
                |     Removes a material family from the MaterialFamilies
                |     collection.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The index of the material family to remove. Compared with other
                |             collections, you cannot use the name of the material family as argument.
                |             
                | 
                |     Example:
                |         The following example removes the second material family in the
                |         collection attached to the active document. This document must be a
                |         
                | 
                |     MaterialDocument object.
                | 
                |      FileToOpen = "e:\users\ast\materials\Catalog.CATMaterial"
                |      Dim MyDocument As MaterialDocument
                |      Set MyDocument = Documents.Open(FileToOpen)
                |      MyDocument.MaterialFamilies.Remove(2)

        :param CATVariant i_index:
        :return: None
        :rtype: None
        """
        return self.material_families.Remove(i_index.com_object)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'remove'
        # # vba_code = """
        # # Public Function remove(material_families)
        # #     Dim iIndex (2)
        # #     material_families.Remove iIndex
        # #     remove = iIndex
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def __repr__(self):
        return f'MaterialFamilies(name="{ self.name }")'
