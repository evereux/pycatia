#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-03 17:02:05.216737

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.setting_controller import SettingController


class AnalysisSettingAtt(SettingController):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.AnyObject
                |                     System.SettingController
                |                         AnalysisSettingAtt
                | 
                | Interface to handle parameters of DELMIA Analysis Tools Options Tab page Role:
                | This interface is implemented by a component which represents the controller of
                | Analysis Tools Options parameter settings.
                | 
                |     Methods to set value of each parameter
                |     Methods to get value of each parameter
                |     Methods to get information on each parameter
                |     Methods to lock/unlock value of each parameter
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.analysis_setting_att = com_object

    @property
    def analysis_level(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnalysisLevel() As DNBAnalysisLevel
                | 
                |     Returns or sets the AnalysisLevel parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: enum dnb_analysis_level
        """

        return self.analysis_setting_att.AnalysisLevel

    @analysis_level.setter
    def analysis_level(self, value):
        """
        :param enum dnb_analysis_level value:
        """

        self.analysis_setting_att.AnalysisLevel = value

    @property
    def anl_accel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlAccelLimit() As boolean
                | 
                |     Returns or sets the AnlAccelLimit parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlAccelLimit

    @anl_accel_limit.setter
    def anl_accel_limit(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlAccelLimit = value

    @property
    def anl_caution_zone(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlCautionZone() As boolean
                | 
                |     Returns or sets the AnlCautionZone parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlCautionZone

    @anl_caution_zone.setter
    def anl_caution_zone(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlCautionZone = value

    @property
    def anl_io_analysis(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlIOAnalysis() As boolean
                | 
                |     Returns or sets the AnlIOAnalysis parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlIOAnalysis

    @anl_io_analysis.setter
    def anl_io_analysis(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlIOAnalysis = value

    @property
    def anl_int_dist(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlIntDist() As boolean
                | 
                |     Returns or sets the AnlIntDist parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlIntDist

    @anl_int_dist.setter
    def anl_int_dist(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlIntDist = value

    @property
    def anl_intf(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlIntf() As boolean
                | 
                |     Returns or sets the AnlIntf parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlIntf

    @anl_intf.setter
    def anl_intf(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlIntf = value

    @property
    def anl_lin_accel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlLinAccelLimit() As boolean
                | 
                |     Returns or sets the AnlLinAccelLimit parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlLinAccelLimit

    @anl_lin_accel_limit.setter
    def anl_lin_accel_limit(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlLinAccelLimit = value

    @property
    def anl_lin_speed_limit(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlLinSpeedLimit() As boolean
                | 
                |     Returns or sets the AnlLinSpeedLimit parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlLinSpeedLimit

    @anl_lin_speed_limit.setter
    def anl_lin_speed_limit(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlLinSpeedLimit = value

    @property
    def anl_measure(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlMeasure() As boolean
                | 
                |     Returns or sets the AnlMeasure parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlMeasure

    @anl_measure.setter
    def anl_measure(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlMeasure = value

    @property
    def anl_rot_accel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlRotAccelLimit() As boolean
                | 
                |     Returns or sets the AnlRotAccelLimit parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlRotAccelLimit

    @anl_rot_accel_limit.setter
    def anl_rot_accel_limit(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlRotAccelLimit = value

    @property
    def anl_rot_speed_limit(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlRotSpeedLimit() As boolean
                | 
                |     Returns or sets the AnlRotSpeedLimit parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlRotSpeedLimit

    @anl_rot_speed_limit.setter
    def anl_rot_speed_limit(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlRotSpeedLimit = value

    @property
    def anl_travel_limit(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlTravelLimit() As boolean
                | 
                |     Returns or sets the AnlTravelLimit parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlTravelLimit

    @anl_travel_limit.setter
    def anl_travel_limit(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlTravelLimit = value

    @property
    def anl_velocity_limit(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AnlVelocityLimit() As boolean
                | 
                |     Returns or sets the AnlVelocityLimit parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AnlVelocityLimit

    @anl_velocity_limit.setter
    def anl_velocity_limit(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AnlVelocityLimit = value

    @property
    def ask_anl_mode(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property AskAnlMode() As boolean
                | 
                |     Returns or sets the AskAnlMode parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.AskAnlMode

    @ask_anl_mode.setter
    def ask_anl_mode(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.AskAnlMode = value

    @property
    def beep_mode(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property BeepMode() As boolean
                | 
                |     Returns or sets the BeepMode parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.BeepMode

    @beep_mode.setter
    def beep_mode(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.BeepMode = value

    @property
    def clash_color(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property ClashColor() As CATSafeArrayVariant
                | 
                |     Returns or sets the ClashColor parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: tuple
        """

        return self.analysis_setting_att.ClashColor

    @clash_color.setter
    def clash_color(self, value):
        """
        :param tuple value:
        """

        self.analysis_setting_att.ClashColor = value

    @property
    def clearance_color(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property ClearanceColor() As CATSafeArrayVariant
                | 
                |     Returns or sets the ClearanceColor parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: tuple
        """

        return self.analysis_setting_att.ClearanceColor

    @clearance_color.setter
    def clearance_color(self, value):
        """
        :param tuple value:
        """

        self.analysis_setting_att.ClearanceColor = value

    @property
    def color_mode(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property ColorMode() As boolean
                | 
                |     Returns or sets the ColorMode parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.ColorMode

    @color_mode.setter
    def color_mode(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.ColorMode = value

    @property
    def display_anl_status(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property DisplayAnlStatus() As boolean
                | 
                |     Returns or sets the DisplayAnlStatus parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.DisplayAnlStatus

    @display_anl_status.setter
    def display_anl_status(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.DisplayAnlStatus = value

    @property
    def enable_anl_mode(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property EnableAnlMode() As boolean
                | 
                |     Returns or sets the EnableAnlMode parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.EnableAnlMode

    @enable_anl_mode.setter
    def enable_anl_mode(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.EnableAnlMode = value

    @property
    def sync_anl_specs(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property SyncAnlSpecs() As boolean
                | 
                |     Returns or sets the SyncAnlSpecs parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.SyncAnlSpecs

    @sync_anl_specs.setter
    def sync_anl_specs(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.SyncAnlSpecs = value

    @property
    def visualization_mode(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property VisualizationMode() As DNBVisualizationMode
                | 
                |     Returns or sets the VisualizationMode parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: enum dnb_visualization_mode
        """

        return self.analysis_setting_att.VisualizationMode

    @visualization_mode.setter
    def visualization_mode(self, value):
        """
        :param enum dnb_visualization_mode value:
        """

        self.analysis_setting_att.VisualizationMode = value

    @property
    def voxel_static_anl(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property VoxelStaticAnl() As boolean
                | 
                |     Returns or sets the VoxelStaticAnl parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.VoxelStaticAnl

    @voxel_static_anl.setter
    def voxel_static_anl(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.VoxelStaticAnl = value

    @property
    def white_mode(self):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737)
                | o Property WhiteMode() As boolean
                | 
                |     Returns or sets the WhiteMode parameter.
                | 
                |     Ensure consistency with the C++ interface to which the work is delegated.

        :return: bool
        """

        return self.analysis_setting_att.WhiteMode

    @white_mode.setter
    def white_mode(self, value):
        """
        :param bool value:
        """

        self.analysis_setting_att.WhiteMode = value

    def get_analysis_level_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnalysisLevelInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnalysisLevel
                |     parameter.
                |     Role:Retrieves the state of the AnalysisLevel parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnalysisLevelInfo(io_admin_level, io_locked)

    def get_anl_accel_limit_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlAccelLimitInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlAccelLimit
                |     parameter.
                |     Role:Retrieves the state of the AnlAccelLimit parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlAccelLimitInfo(io_admin_level, io_locked)

    def get_anl_caution_zone_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlCautionZoneInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlCautionZone
                |     parameter.
                |     Role:Retrieves the state of the AnlCautionZone parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlCautionZoneInfo(io_admin_level, io_locked)

    def get_anl_io_analysis_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlIOAnalysisInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlIOAnalysis
                |     parameter.
                |     Role:Retrieves the state of the AnlIOAnalysis parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlIOAnalysisInfo(io_admin_level, io_locked)

    def get_anl_int_dist_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlIntDistInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlIntDist
                |     parameter.
                |     Role:Retrieves the state of the AnlIntDist parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlIntDistInfo(io_admin_level, io_locked)

    def get_anl_intf_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlIntfInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlIntf
                |     parameter.
                |     Role:Retrieves the state of the AnlIntf parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlIntfInfo(io_admin_level, io_locked)

    def get_anl_lin_accel_limit_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlLinAccelLimitInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlLinAccelLimit
                |     parameter.
                |     Role:Retrieves the state of the AnlLinAccelLimit parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlLinAccelLimitInfo(io_admin_level, io_locked)

    def get_anl_lin_speed_limit_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlLinSpeedLimitInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlLinSpeedLimit
                |     parameter.
                |     Role:Retrieves the state of the AnlLinSpeedLimit parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlLinSpeedLimitInfo(io_admin_level, io_locked)

    def get_anl_measure_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlMeasureInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlMeasure
                |     parameter.
                |     Role:Retrieves the state of the AnlMeasure parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlMeasureInfo(io_admin_level, io_locked)

    def get_anl_rot_accel_limit_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlRotAccelLimitInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlRotAccelLimit
                |     parameter.
                |     Role:Retrieves the state of the AnlRotAccelLimit parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlRotAccelLimitInfo(io_admin_level, io_locked)

    def get_anl_rot_speed_limit_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlRotSpeedLimitInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlRotSpeedLimit
                |     parameter.
                |     Role:Retrieves the state of the AnlRotSpeedLimit parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlRotSpeedLimitInfo(io_admin_level, io_locked)

    def get_anl_travel_limit_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlTravelLimitInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlTravelLimit
                |     parameter.
                |     Role:Retrieves the state of the AnlTravelLimit parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlTravelLimitInfo(io_admin_level, io_locked)

    def get_anl_velocity_limit_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAnlVelocityLimitInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AnlVelocityLimit
                |     parameter.
                |     Role:Retrieves the state of the AnlVelocityLimit parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAnlVelocityLimitInfo(io_admin_level, io_locked)

    def get_ask_anl_mode_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetAskAnlModeInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the AskAnlMode
                |     parameter.
                |     Role:Retrieves the state of the AskAnlMode parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetAskAnlModeInfo(io_admin_level, io_locked)

    def get_beep_mode_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetBeepModeInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the BeepMode
                |     parameter.
                |     Role:Retrieves the state of the BeepMode parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetBeepModeInfo(io_admin_level, io_locked)

    def get_clash_color_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetClashColorInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ClashColor
                |     parameter.
                |     Role:Retrieves the state of the ClashColor parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetClashColorInfo(io_admin_level, io_locked)

    def get_clearance_color_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetClearanceColorInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ClearanceColor
                |     parameter.
                |     Role:Retrieves the state of the ClearanceColor parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetClearanceColorInfo(io_admin_level, io_locked)

    def get_color_mode_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetColorModeInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the ColorMode
                |     parameter.
                |     Role:Retrieves the state of the ColorMode parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetColorModeInfo(io_admin_level, io_locked)

    def get_display_anl_status_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetDisplayAnlStatusInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the DisplayAnlStatus
                |     parameter.
                |     Role:Retrieves the state of the DisplayAnlStatus parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetDisplayAnlStatusInfo(io_admin_level, io_locked)

    def get_enable_anl_mode_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetEnableAnlModeInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the EnableAnlMode
                |     parameter.
                |     Role:Retrieves the state of the EnableAnlMode parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetEnableAnlModeInfo(io_admin_level, io_locked)

    def get_sync_anl_specs_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetSyncAnlSpecsInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the SyncAnlSpecs
                |     parameter.
                |     Role:Retrieves the state of the SyncAnlSpecs parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetSyncAnlSpecsInfo(io_admin_level, io_locked)

    def get_visualization_mode_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetVisualizationModeInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the VisualizationMode
                |     parameter.
                |     Role:Retrieves the state of the VisualizationMode parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetVisualizationModeInfo(io_admin_level, io_locked)

    def get_voxel_static_anl_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetVoxelStaticAnlInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the VoxelStaticAnl
                |     parameter.
                |     Role:Retrieves the state of the VoxelStaticAnl parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetVoxelStaticAnlInfo(io_admin_level, io_locked)

    def get_white_mode_info(self, io_admin_level=None, io_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Func GetWhiteModeInfo(CATBSTR ioAdminLevel,
                | CATBSTR ioLocked) As boolean
                | 
                |     Retrieves environment informations for the WhiteMode
                |     parameter.
                |     Role:Retrieves the state of the WhiteMode parameter in the current
                |     environment.
                | 
                |     Parameters:
                | 
                |         ioAdminLevel
                | 
                |             If the parameter is locked, AdminLevel gives the administration
                |             level that imposes the value of the parameter.
                |             If the parameter is not locked, AdminLevel gives the administration
                |             level that will give the value of the parameter after a reset.
                |             
                |         ioLocked
                |             Indicates if the parameter has been locked. 
                | 
                |     Returns:
                |         Indicates if the parameter has been explicitly modified or remain to
                |         the administrated value.

        :param str io_admin_level:
        :param str io_locked:
        :return: bool
        """
        return self.analysis_setting_att.GetWhiteModeInfo(io_admin_level, io_locked)

    def set_analysis_level_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnalysisLevelLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnalysisLevel parameter.
                |     Role:Locks or unlocks the AnalysisLevel parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnalysisLevelLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_analysis_level_lock'
        # # vba_code = """
        # # Public Function set_analysis_level_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnalysisLevelLock iLocked
        # #     set_analysis_level_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_accel_limit_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlAccelLimitLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlAccelLimit parameter.
                |     Role:Locks or unlocks the AnlAccelLimit parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlAccelLimitLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_accel_limit_lock'
        # # vba_code = """
        # # Public Function set_anl_accel_limit_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlAccelLimitLock iLocked
        # #     set_anl_accel_limit_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_caution_zone_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlCautionZoneLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlCautionZone parameter.
                |     Role:Locks or unlocks the AnlCautionZone parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlCautionZoneLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_caution_zone_lock'
        # # vba_code = """
        # # Public Function set_anl_caution_zone_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlCautionZoneLock iLocked
        # #     set_anl_caution_zone_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_io_analysis_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlIOAnalysisLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlIOAnalysis parameter.
                |     Role:Locks or unlocks the AnlIOAnalysis parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlIOAnalysisLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_io_analysis_lock'
        # # vba_code = """
        # # Public Function set_anl_io_analysis_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlIOAnalysisLock iLocked
        # #     set_anl_io_analysis_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_int_dist_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlIntDistLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlIntDist parameter.
                |     Role:Locks or unlocks the AnlIntDist parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlIntDistLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_int_dist_lock'
        # # vba_code = """
        # # Public Function set_anl_int_dist_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlIntDistLock iLocked
        # #     set_anl_int_dist_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_intf_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlIntfLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlIntf parameter.
                |     Role:Locks or unlocks the AnlIntf parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlIntfLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_intf_lock'
        # # vba_code = """
        # # Public Function set_anl_intf_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlIntfLock iLocked
        # #     set_anl_intf_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_lin_accel_limit_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlLinAccelLimitLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlLinAccelLimit parameter.
                |     Role:Locks or unlocks the AnlLinAccelLimit parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlLinAccelLimitLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_lin_accel_limit_lock'
        # # vba_code = """
        # # Public Function set_anl_lin_accel_limit_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlLinAccelLimitLock iLocked
        # #     set_anl_lin_accel_limit_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_lin_speed_limit_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlLinSpeedLimitLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlLinSpeedLimit parameter.
                |     Role:Locks or unlocks the AnlLinSpeedLimit parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlLinSpeedLimitLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_lin_speed_limit_lock'
        # # vba_code = """
        # # Public Function set_anl_lin_speed_limit_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlLinSpeedLimitLock iLocked
        # #     set_anl_lin_speed_limit_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_measure_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlMeasureLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlMeasure parameter.
                |     Role:Locks or unlocks the AnlMeasure parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlMeasureLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_measure_lock'
        # # vba_code = """
        # # Public Function set_anl_measure_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlMeasureLock iLocked
        # #     set_anl_measure_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_rot_accel_limit_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlRotAccelLimitLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlRotAccelLimit parameter.
                |     Role:Locks or unlocks the AnlRotAccelLimit parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlRotAccelLimitLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_rot_accel_limit_lock'
        # # vba_code = """
        # # Public Function set_anl_rot_accel_limit_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlRotAccelLimitLock iLocked
        # #     set_anl_rot_accel_limit_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_rot_speed_limit_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlRotSpeedLimitLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlRotSpeedLimit parameter.
                |     Role:Locks or unlocks the AnlRotSpeedLimit parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlRotSpeedLimitLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_rot_speed_limit_lock'
        # # vba_code = """
        # # Public Function set_anl_rot_speed_limit_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlRotSpeedLimitLock iLocked
        # #     set_anl_rot_speed_limit_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_travel_limit_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlTravelLimitLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlTravelLimit parameter.
                |     Role:Locks or unlocks the AnlTravelLimit parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlTravelLimitLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_travel_limit_lock'
        # # vba_code = """
        # # Public Function set_anl_travel_limit_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlTravelLimitLock iLocked
        # #     set_anl_travel_limit_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_anl_velocity_limit_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAnlVelocityLimitLock(boolean iLocked)
                | 
                |     Locks or unlocks the AnlVelocityLimit parameter.
                |     Role:Locks or unlocks the AnlVelocityLimit parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAnlVelocityLimitLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_anl_velocity_limit_lock'
        # # vba_code = """
        # # Public Function set_anl_velocity_limit_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAnlVelocityLimitLock iLocked
        # #     set_anl_velocity_limit_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_ask_anl_mode_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetAskAnlModeLock(boolean iLocked)
                | 
                |     Locks or unlocks the AskAnlMode parameter.
                |     Role:Locks or unlocks the AskAnlMode parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetAskAnlModeLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_ask_anl_mode_lock'
        # # vba_code = """
        # # Public Function set_ask_anl_mode_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetAskAnlModeLock iLocked
        # #     set_ask_anl_mode_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_beep_mode_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetBeepModeLock(boolean iLocked)
                | 
                |     Locks or unlocks the BeepMode parameter.
                |     Role:Locks or unlocks the BeepMode parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetBeepModeLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_beep_mode_lock'
        # # vba_code = """
        # # Public Function set_beep_mode_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetBeepModeLock iLocked
        # #     set_beep_mode_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_clash_color_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetClashColorLock(boolean iLocked)
                | 
                |     Locks or unlocks the ClashColor parameter.
                |     Role:Locks or unlocks the ClashColor parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetClashColorLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_clash_color_lock'
        # # vba_code = """
        # # Public Function set_clash_color_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetClashColorLock iLocked
        # #     set_clash_color_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_clearance_color_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetClearanceColorLock(boolean iLocked)
                | 
                |     Locks or unlocks the ClearanceColor parameter.
                |     Role:Locks or unlocks the ClearanceColor parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetClearanceColorLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_clearance_color_lock'
        # # vba_code = """
        # # Public Function set_clearance_color_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetClearanceColorLock iLocked
        # #     set_clearance_color_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_color_mode_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetColorModeLock(boolean iLocked)
                | 
                |     Locks or unlocks the ColorMode parameter.
                |     Role:Locks or unlocks the ColorMode parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetColorModeLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_color_mode_lock'
        # # vba_code = """
        # # Public Function set_color_mode_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetColorModeLock iLocked
        # #     set_color_mode_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_display_anl_status_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetDisplayAnlStatusLock(boolean iLocked)
                | 
                |     Locks or unlocks the DisplayAnlStatus parameter.
                |     Role:Locks or unlocks the DisplayAnlStatus parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetDisplayAnlStatusLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_display_anl_status_lock'
        # # vba_code = """
        # # Public Function set_display_anl_status_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetDisplayAnlStatusLock iLocked
        # #     set_display_anl_status_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_enable_anl_mode_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetEnableAnlModeLock(boolean iLocked)
                | 
                |     Locks or unlocks the EnableAnlMode parameter.
                |     Role:Locks or unlocks the EnableAnlMode parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetEnableAnlModeLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_enable_anl_mode_lock'
        # # vba_code = """
        # # Public Function set_enable_anl_mode_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetEnableAnlModeLock iLocked
        # #     set_enable_anl_mode_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_sync_anl_specs_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetSyncAnlSpecsLock(boolean iLocked)
                | 
                |     Locks or unlocks the SyncAnlSpecs parameter.
                |     Role:Locks or unlocks the SyncAnlSpecs parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetSyncAnlSpecsLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_sync_anl_specs_lock'
        # # vba_code = """
        # # Public Function set_sync_anl_specs_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetSyncAnlSpecsLock iLocked
        # #     set_sync_anl_specs_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_visualization_mode_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetVisualizationModeLock(boolean iLocked)
                | 
                |     Locks or unlocks the VisualizationMode parameter.
                |     Role:Locks or unlocks the VisualizationMode parameter if it is possible in
                |     the current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetVisualizationModeLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_visualization_mode_lock'
        # # vba_code = """
        # # Public Function set_visualization_mode_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetVisualizationModeLock iLocked
        # #     set_visualization_mode_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_voxel_static_anl_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetVoxelStaticAnlLock(boolean iLocked)
                | 
                |     Locks or unlocks the VoxelStaticAnl parameter.
                |     Role:Locks or unlocks the VoxelStaticAnl parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetVoxelStaticAnlLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_voxel_static_anl_lock'
        # # vba_code = """
        # # Public Function set_voxel_static_anl_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetVoxelStaticAnlLock iLocked
        # #     set_voxel_static_anl_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def set_white_mode_lock(self, i_locked=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-03 17:02:05.216737))
                | o Sub SetWhiteModeLock(boolean iLocked)
                | 
                |     Locks or unlocks the WhiteMode parameter.
                |     Role:Locks or unlocks the WhiteMode parameter if it is possible in the
                |     current administrative context. In user mode this method will always return
                |     E_FAIL.
                | 
                |     Parameters:
                | 
                |         iLocked
                |             the locking operation to be performed Legal
                |             values:
                |             TRUE : to lock the parameter.
                |             FALSE: to unlock the parameter.

        :param bool i_locked:
        :return: None
        """
        return self.analysis_setting_att.SetWhiteModeLock(i_locked)
        # # # # Autogenerated comment: 
        # # some methods require a system service call as the methods expects a vb array object
        # # passed to it and there is no way to do this directly with python. In those cases the following code
        # # should be uncommented and edited accordingly. Otherwise completely remove all this.
        # # vba_function_name = 'set_white_mode_lock'
        # # vba_code = """
        # # Public Function set_white_mode_lock(analysis_setting_att)
        # #     Dim iLocked (2)
        # #     analysis_setting_att.SetWhiteModeLock iLocked
        # #     set_white_mode_lock = iLocked
        # # End Function
        # # """

        # # system_service = SystemService(self.application.SystemService)
        # # return system_service.evaluate(vba_code, 0, vba_function_name, [self.com_object])

    def __repr__(self):
        return f'AnalysisSettingAtt(name="{ self.name }")'
