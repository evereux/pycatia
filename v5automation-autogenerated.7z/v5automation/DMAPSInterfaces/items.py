#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class Items(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     Items
                | 
                | The collection of items related to the current activity.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.items = com_object

    def add(self, i_product=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Add(Item iProduct) As Item
                | 
                |     This method adds the specified item in the current list
                | 
                |     Parameters:
                | 
                |         iItem
                |             The item to add 
                | 
                |     Returns:
                |         oitem The item

        :param Item i_product:
        :return: Item
        """
        return Item(self.items.Add(i_product.com_object))

    def add_by_assignment_type(self, i_item=None, i_assignment_type=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func AddByAssignmentType(Item iItem,
                | ItemAssignmentType iAssignmentType) As Item
                | 
                |     This method Assigns the specified item with the specified assignment
                |     type
                | 
                |     Parameters:
                | 
                |         iItem
                |             The item to be assigned 
                |         iAssignmentType
                |             Type of the Assignment (Item to the Process) 
                | 
                |     Returns:
                |         oitem The item

        :param Item i_item:
        :param ItemAssignmentType i_assignment_type:
        :return: Item
        """
        return Item(self.items.AddByAssignmentType(i_item.com_object, i_assignment_type.com_object))

    def count_by_assignment_type(self, i_assignment_type=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func CountByAssignmentType(ItemAssignmentType iAssignmentType) As
                | long
                | 
                |     This method returns the Number of items that assocated with the activity
                |     with given Assignment Type.
                | 
                |     Parameters:
                | 
                |         iAssignmentType
                |             Type of the Assignment between items & the activity
                |             
                | 
                |     Returns:
                |         oNbItems No. of Items that are assigned to the activity with the given
                |         assignment type.

        :param ItemAssignmentType i_assignment_type:
        :return: int
        """
        return self.items.CountByAssignmentType(i_assignment_type.com_object)

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Item(CATVariant iIndex) As Item
                | 
                |     This method returns the idl object Item for the specified item
                |     identifier.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The item identifier 
                | 
                |     Returns:
                |         oItem The idl item

        :param CATVariant i_index:
        :return: Item
        """
        return Item(self.items.Item(i_index.com_object))

    def item_by_assignment_type(self, i_index=None, i_assignment_type=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func ItemByAssignmentType(CATVariant iIndex,
                | ItemAssignmentType iAssignmentType) As Item
                | 
                |     This method returns the item assocated with the activity with given
                |     Assignment Type.
                | 
                |     Parameters:
                | 
                |         iAssignmentType
                |             Type of the Assignment between item & the activity
                |             
                | 
                |     Returns:
                |         oItem idl item to be returned

        :param CATVariant i_index:
        :param ItemAssignmentType i_assignment_type:
        :return: Item
        """
        return Item(self.items.ItemByAssignmentType(i_index.com_object, i_assignment_type.com_object))

    def remove_by_assignment_type(self, i_item=None, i_assignment_type=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func RemoveByAssignmentType(Item iItem,
                | ItemAssignmentType iAssignmentType) As Item
                | 
                |     This method used to unassign the specified item (with the given assignment
                |     type)
                | 
                |     Parameters:
                | 
                |         iItem
                |             The item to be Unassigned 
                |         iAssignmentType
                |             Type of the Assignment (Item to the Process) to be removed
                |             
                | 
                |     Returns:
                |         oitem The item

        :param Item i_item:
        :param ItemAssignmentType i_assignment_type:
        :return: Item
        """
        return Item(self.items.RemoveByAssignmentType(i_item.com_object, i_assignment_type.com_object))

    def __repr__(self):
        return f'Items(name="{ self.name }")'
