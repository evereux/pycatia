#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-06-11 10:31:25.529975

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class Resources(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     Resources
                | 
                | The collection of resources related to the current activity.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.resources = com_object

    def add(self, i_resource=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Add(Resource iResource) As Resource
                | 
                |     This method add the specified item in the current list
                | 
                |     Parameters:
                | 
                |         iItem
                |             The item to add 
                | 
                |     Returns:
                |         oitem The item

        :param Resource i_resource:
        :return: Resource
        """
        return Resource(self.resources.Add(i_resource.com_object))

    def add_by_assignment_type(self, i_resource=None, i_assignment_type=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func AddByAssignmentType(Resource iResource,
                | DNBResourceAssignmentType iAssignmentType) As Resource
                | 
                |     This method Assigns/Adds the specified resource with the specified
                |     assignment type
                | 
                |     Parameters:
                | 
                |         iResource
                |             The resource to be assigned 
                |         iAssignmentType
                |             Type of the Assignment (Resource to the Process). Only the
                |             following four types are supported at the moment: Process_Uses_Resource,
                |             Process_Runs_On_Resource, Process_Attaches_Resource, Process_Detaches_Resource
                |             
                | 
                |     Returns:
                |         oResource The resource when Add succeeds, unchanged otherwise

        :param Resource i_resource:
        :param DNBResourceAssignmentType i_assignment_type:
        :return: Resource
        """
        return Resource(self.resources.AddByAssignmentType(i_resource.com_object, i_assignment_type.com_object))

    def item(self, i_index=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func Item(CATVariant iIndex) As Resource
                | 
                |     This method returns the idl object Resource for the specified resource
                |     identifier.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The resource identifier 
                | 
                |     Returns:
                |         oResource The idl resource

        :param CATVariant i_index:
        :return: Resource
        """
        return Resource(self.resources.Item(i_index.com_object))

    def remove_by_assignment_type(self, i_resource=None, i_assignment_type=None):
        """
        .. note::
            CAA V5 Visual Basic Help (2020-06-11 10:31:25.529975))
                | o Func RemoveByAssignmentType(Resource iResource,
                | DNBResourceAssignmentType iAssignmentType) As Resource
                | 
                |     This method Unassigns/Removes the specified resource if the assignement
                |     exists and is of the given type
                | 
                |     Parameters:
                | 
                |         iResource
                |             The resource to be Unassigned 
                |         iAssignmentType
                |             Type of the Assignment (Resource to the Process) to be removed
                |             
                | 
                |     Returns:
                |         oResource The resource when Remove succeeds, unchanged otherwise

        :param Resource i_resource:
        :param DNBResourceAssignmentType i_assignment_type:
        :return: Resource
        """
        return Resource(self.resources.RemoveByAssignmentType(i_resource.com_object, i_assignment_type.com_object))

    def __repr__(self):
        return f'Resources(name="{ self.name }")'
