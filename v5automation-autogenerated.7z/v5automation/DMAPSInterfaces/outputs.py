#! usr/bin/python3.6
"""
    Module initially auto generated using V5Automation files from CATIA V5 R28 on 2020-07-06 14:02:20.222384

    .. warning::
        The notes denoted "CAA V5 Visual Basic Help" are to be used as reference only.
        They are there as a guide as to how the visual basic / catscript functions work
        and thus help debugging in pycatia.
        
"""

from pycatia.system_interfaces.collection import Collection


class Outputs(Collection):

    """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384)

                | System.IUnknown
                |     System.IDispatch
                |         System.CATBaseUnknown
                |             System.CATBaseDispatch
                |                 System.Collection
                |                     Outputs
                | 
                | The collection of outputs related to the current activity.
    
    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.outputs = com_object

    def add(self, i_output: Item) -> Item:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Add(Item iOutput) As Item
                | 
                |     This method can be used to assign a given product as an
                |     output
                | 
                |     Parameters:
                | 
                |         iOutput
                |             The output to add 
                | 
                |     Returns:
                |         oProduct The assigned product

        :param Item i_output:
        :return: Item
        :rtype: Item
        """
        return Item(self.outputs.Add(i_output.com_object))

    def count(self) -> int:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Count() As long
                | 
                |     This method returns the no. of products / features that are assigned to a
                |     process as output.
                | 
                |     Returns:
                |         oNbOutputs No. of Outputss that are assigned to the activity.

        :return: int
        :rtype: int
        """
        return self.outputs.Count()

    def item(self, i_index: CATVariant) -> Item:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Item(CATVariant iIndex) As Item
                | 
                |     This method can be used to get the associated output
                |     product.
                | 
                |     Parameters:
                | 
                |         iIndex
                |             The item identifier (can be the index or the name)
                |             
                | 
                |     Returns:
                |         oProduct The indexed product/MA that is assigned to the process.

        :param CATVariant i_index:
        :return: Item
        :rtype: Item
        """
        return Item(self.outputs.Item(i_index.com_object))

    def remove(self, i_output: Item) -> Item:
        """
        .. note::
            CAA V5 Visual Basic Help (2020-07-06 14:02:20.222384))
                | o Func Remove(Item iOutput) As Item
                | 
                |     This method can be used to unassign an output product from a
                |     process
                | 
                |     Parameters:
                | 
                |         iProduct
                |             The product to remove 
                | 
                |     Returns:
                |         oProduct The item

        :param Item i_output:
        :return: Item
        :rtype: Item
        """
        return Item(self.outputs.Remove(i_output.com_object))

    def __repr__(self):
        return f'Outputs(name="{ self.name }")'
