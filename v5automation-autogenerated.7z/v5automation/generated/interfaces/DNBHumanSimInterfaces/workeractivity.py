#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class WorkerActivity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The object that represents an Worker activity.Following activity types
                | qualify as worker activities:

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.worker_activity = com_object     

    @property
    def human_task(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HumanTask
                | o Property HumanTask(    ) As   (Read Only)
                | 
                | Returns the parent HumanTask Returns: oHumanTask (see for
                | more details)
                |

        :return:
        """
        return self.worker_activity.HumanTask

    @property
    def worker_resource(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WorkerResource
                | o Property WorkerResource(    ) As   (Read Only)
                | 
                | Returns the Worker-Resource associated with this worker-
                | activity. Returns: oManikin (see for more details)
                |

        :return:
        """
        return self.worker_activity.WorkerResource

    def __repr__(self):
        return f'WorkerActivity()'
