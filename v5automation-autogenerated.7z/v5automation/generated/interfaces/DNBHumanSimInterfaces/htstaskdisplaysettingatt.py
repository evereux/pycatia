#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HtsTaskDisplaySettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.hts_task_display_setting_att = com_object     

    @property
    def auto_walk_act_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoWalkActColor
                | o Property AutoWalkActColor(    ) As
                | 
                | Returns or sets the AutoWalkActColor parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_task_display_setting_att.AutoWalkActColor

    @auto_walk_act_color.setter
    def auto_walk_act_color(self, value):
        """
            :param type value:
        """
        self.hts_task_display_setting_att.AutoWalkActColor = value 

    @property
    def auto_walk_act_line_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoWalkActLineType
                | o Property AutoWalkActLineType(    ) As
                | 
                | Returns or sets the AutoWalkActLineType parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_task_display_setting_att.AutoWalkActLineType

    @auto_walk_act_line_type.setter
    def auto_walk_act_line_type(self, value):
        """
            :param type value:
        """
        self.hts_task_display_setting_att.AutoWalkActLineType = value 

    @property
    def auto_walk_act_line_weight(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoWalkActLineWeight
                | o Property AutoWalkActLineWeight(    ) As
                | 
                | Returns or sets the AutoWalkActLineWeight parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_task_display_setting_att.AutoWalkActLineWeight

    @auto_walk_act_line_weight.setter
    def auto_walk_act_line_weight(self, value):
        """
            :param type value:
        """
        self.hts_task_display_setting_att.AutoWalkActLineWeight = value 

    @property
    def mtp_act_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MTPActColor
                | o Property MTPActColor(    ) As
                | 
                | Returns or sets the MTPActColor parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_task_display_setting_att.MTPActColor

    @mtp_act_color.setter
    def mtp_act_color(self, value):
        """
            :param type value:
        """
        self.hts_task_display_setting_att.MTPActColor = value 

    @property
    def mtp_act_symbol(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MTPActSymbol
                | o Property MTPActSymbol(    ) As
                | 
                | Returns or sets the MTPActSymbol parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_task_display_setting_att.MTPActSymbol

    @mtp_act_symbol.setter
    def mtp_act_symbol(self, value):
        """
            :param type value:
        """
        self.hts_task_display_setting_att.MTPActSymbol = value 

    @property
    def walk_act_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WalkActColor
                | o Property WalkActColor(    ) As
                | 
                | Returns or sets the WalkActColor parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_task_display_setting_att.WalkActColor

    @walk_act_color.setter
    def walk_act_color(self, value):
        """
            :param type value:
        """
        self.hts_task_display_setting_att.WalkActColor = value 

    @property
    def walk_act_line_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WalkActLineType
                | o Property WalkActLineType(    ) As
                | 
                | Returns or sets the WalkActLineType parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_task_display_setting_att.WalkActLineType

    @walk_act_line_type.setter
    def walk_act_line_type(self, value):
        """
            :param type value:
        """
        self.hts_task_display_setting_att.WalkActLineType = value 

    @property
    def walk_act_line_weight(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WalkActLineWeight
                | o Property WalkActLineWeight(    ) As
                | 
                | Returns or sets the WalkActLineWeight parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_task_display_setting_att.WalkActLineWeight

    @walk_act_line_weight.setter
    def walk_act_line_weight(self, value):
        """
            :param type value:
        """
        self.hts_task_display_setting_att.WalkActLineWeight = value 

    def get_auto_walk_act_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoWalkActColorInfo
                | o Func GetAutoWalkActColorInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the AutoWalkActColor
                | parameter. Role:Retrieves the state of the AutoWalkActColor
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_task_display_setting_att.GetAutoWalkActColorInfo(io_admin_level, io_locked)

    def get_auto_walk_act_line_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoWalkActLineTypeInfo
                | o Func GetAutoWalkActLineTypeInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves environment informations for the
                | AutoWalkActLineType parameter. Role:Retrieves the state of
                | the AutoWalkActLineType parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_task_display_setting_att.GetAutoWalkActLineTypeInfo(io_admin_level, io_locked)

    def get_auto_walk_act_line_weight_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoWalkActLineWeightInfo
                | o Func GetAutoWalkActLineWeightInfo(        ioAdminLevel,
                |                                             ioLocked) As
                | 
                | Retrieves environment informations for the
                | AutoWalkActLineWeight parameter. Role:Retrieves the state of
                | the AutoWalkActLineWeight parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_task_display_setting_att.GetAutoWalkActLineWeightInfo(io_admin_level, io_locked)

    def get_mtp_act_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMTPActColorInfo
                | o Func GetMTPActColorInfo(        ioAdminLevel,
                |                                   ioLocked) As
                | 
                | Retrieves environment informations for the MTPActColor
                | parameter. Role:Retrieves the state of the MTPActColor
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_task_display_setting_att.GetMTPActColorInfo(io_admin_level, io_locked)

    def get_mtp_act_symbol_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMTPActSymbolInfo
                | o Func GetMTPActSymbolInfo(        ioAdminLevel,
                |                                    ioLocked) As
                | 
                | Retrieves environment informations for the MTPActSymbol
                | parameter. Role:Retrieves the state of the MTPActSymbol
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_task_display_setting_att.GetMTPActSymbolInfo(io_admin_level, io_locked)

    def get_walk_act_color_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetWalkActColorInfo
                | o Func GetWalkActColorInfo(        ioAdminLevel,
                |                                    ioLocked) As
                | 
                | Retrieves environment informations for the WalkActColor
                | parameter. Role:Retrieves the state of the WalkActColor
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_task_display_setting_att.GetWalkActColorInfo(io_admin_level, io_locked)

    def get_walk_act_line_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetWalkActLineTypeInfo
                | o Func GetWalkActLineTypeInfo(        ioAdminLevel,
                |                                       ioLocked) As
                | 
                | Retrieves environment informations for the WalkActLineType
                | parameter. Role:Retrieves the state of the WalkActLineType
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_task_display_setting_att.GetWalkActLineTypeInfo(io_admin_level, io_locked)

    def get_walk_act_line_weight_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetWalkActLineWeightInfo
                | o Func GetWalkActLineWeightInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment informations for the WalkActLineWeight
                | parameter. Role:Retrieves the state of the WalkActLineWeight
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_task_display_setting_att.GetWalkActLineWeightInfo(io_admin_level, io_locked)

    def set_auto_walk_act_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoWalkActColorLock
                | o Sub SetAutoWalkActColorLock(        iLocked)
                | 
                | Locks or unlocks the AutoWalkActColor parameter. Role:Locks
                | or unlocks the AutoWalkActColor parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_task_display_setting_att.SetAutoWalkActColorLock(i_locked)

    def set_auto_walk_act_line_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoWalkActLineTypeLock
                | o Sub SetAutoWalkActLineTypeLock(        iLocked)
                | 
                | Locks or unlocks the AutoWalkActLineType parameter.
                | Role:Locks or unlocks the AutoWalkActLineType parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_task_display_setting_att.SetAutoWalkActLineTypeLock(i_locked)

    def set_auto_walk_act_line_weight_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoWalkActLineWeightLock
                | o Sub SetAutoWalkActLineWeightLock(        iLocked)
                | 
                | Locks or unlocks the AutoWalkActLineWeight parameter.
                | Role:Locks or unlocks the AutoWalkActLineWeight parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_task_display_setting_att.SetAutoWalkActLineWeightLock(i_locked)

    def set_mtp_act_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMTPActColorLock
                | o Sub SetMTPActColorLock(        iLocked)
                | 
                | Locks or unlocks the MTPActColor parameter. Role:Locks or
                | unlocks the MTPActColor parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_task_display_setting_att.SetMTPActColorLock(i_locked)

    def set_mtp_act_symbol_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMTPActSymbolLock
                | o Sub SetMTPActSymbolLock(        iLocked)
                | 
                | Locks or unlocks the MTPActSymbol parameter. Role:Locks or
                | unlocks the MTPActSymbol parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_task_display_setting_att.SetMTPActSymbolLock(i_locked)

    def set_walk_act_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetWalkActColorLock
                | o Sub SetWalkActColorLock(        iLocked)
                | 
                | Locks or unlocks the WalkActColor parameter. Role:Locks or
                | unlocks the WalkActColor parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_task_display_setting_att.SetWalkActColorLock(i_locked)

    def set_walk_act_line_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetWalkActLineTypeLock
                | o Sub SetWalkActLineTypeLock(        iLocked)
                | 
                | Locks or unlocks the WalkActLineType parameter. Role:Locks
                | or unlocks the WalkActLineType parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_task_display_setting_att.SetWalkActLineTypeLock(i_locked)

    def set_walk_act_line_weight_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetWalkActLineWeightLock
                | o Sub SetWalkActLineWeightLock(        iLocked)
                | 
                | Locks or unlocks the WalkActLineWeight parameter. Role:Locks
                | or unlocks the WalkActLineWeight parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_task_display_setting_att.SetWalkActLineWeightLock(i_locked)

    def __repr__(self):
        return f'HtsTaskDisplaySettingAtt()'
