#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PlaceActivity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The object that represents an PlaceActivity.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.place_activity = com_object     

    def add_placed_mfg_assembly(self, p_picked_item, vb_sav):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPlacedMfgAssembly
                | o Sub AddPlacedMfgAssembly(        pPickedItem,
                |                                    vbSAV)
                | 
                | Adds a Manufacturing Assembly to the List of placed Items
                |
                | Parameters:

                |
        :param p_picked_item:
        :param vb_sav:
        :return:
        """
        return self.place_activity.AddPlacedMfgAssembly(p_picked_item, vb_sav)

    def add_placed_product(self, p_picked_item, vb_sav):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPlacedProduct
                | o Sub AddPlacedProduct(        pPickedItem,
                |                                vbSAV)
                | 
                | Adds a product to the List of placed Items
                |
                | Parameters:

                |
        :param p_picked_item:
        :param vb_sav:
        :return:
        """
        return self.place_activity.AddPlacedProduct(p_picked_item, vb_sav)

    def get_offset(self, o_offset_trans_list):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOffset
                | o Sub GetOffset(        oOffsetTransList)
                | 
                | This method gets the relative offset List for placing the
                | product
                |
                | Parameters:
                | oOffsetTrans
                |  list of Offsets between EndEff and Product at time of placing
                |  first 12 values reprsent 1st offset, next 12, 2nd offset and so on..
                |  The offset matrix is intrepreted as follows:
                |  The first 9 entries correspond to the rotation matrix and the  
                |  next 3 entries correspond to the position vector The first 9 entries are interpreted row wise for the matrix 
                |  shown below
                |   
                |  R1x  R1y  R1z  
                |  R2x  R2y  R2z  
                |  R3x  R3y  R3z  
                |  Px  Py  Pz  
                | 
                |    R1x:x-component of x axis  
                |    R2x:y-component of x axis  
                |    R3x:z-component of x axis  
                |    R1y:x-component of y axis  
                |    R2y:y-component of y axis  
                |    R3y:z-component of y axis  
                |    R1z:x-component of z axis  
                |    R2z:y-component of z axis  
                |    R3z:z-component of z axis

                |
        :param o_offset_trans_list:
        :return:
        """
        return self.place_activity.GetOffset(o_offset_trans_list)

    def get_placed_products(self, p_placed_prods):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPlacedProducts
                | o Sub GetPlacedProducts(        pPlacedProds)
                | 
                | Returns or Sets Placed Products
                |
                | Parameters:

                |
        :param p_placed_prods:
        :return:
        """
        return self.place_activity.GetPlacedProducts(p_placed_prods)

    def remove_placed_mfg_assembly(self, p_picked_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePlacedMfgAssembly
                | o Sub RemovePlacedMfgAssembly(        pPickedItem)
                | 
                | Removes a Manufacturing Assembly from the list of placed
                | items
                |
                | Parameters:

                |
        :param p_picked_item:
        :return:
        """
        return self.place_activity.RemovePlacedMfgAssembly(p_picked_item)

    def remove_placed_product(self, p_picked_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePlacedProduct
                | o Sub RemovePlacedProduct(        pPickedItem)
                | 
                | Removes a product from the list of placed items
                |
                | Parameters:

                |
        :param p_picked_item:
        :return:
        """
        return self.place_activity.RemovePlacedProduct(p_picked_item)

    def set_offset(self, o_offset_trans_list):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOffset
                | o Sub SetOffset(        oOffsetTransList)
                | 
                | This method sets the relative offsets for placing the
                | product
                |
                | Parameters:
                | oOffsetTransList
                |  list of Offsets between EndEffs and Products at time of placing
                |  first 12 values represnt 1st offset, next 12, 2nd offset and so on..
                |  The offset matrix is intrepreted as follows:
                |  The first 9 entries correspond to the rotation matrix and the  
                |  next 3 entries correspond to the position vector
                |   
                |  R1x  R1y  R1z  
                |  R2x  R2y  R2z  
                |  R3x  R3y  R3z  
                |  Px  Py  Pz  
                | 
                |    R1x:x-component of x axis  
                |    R2x:y-component of x axis  
                |    R3x:z-component of x axis  
                |    R1y:x-component of y axis  
                |    R2y:y-component of y axis  
                |    R3y:z-component of y axis  
                |    R1z:x-component of z axis  
                |    R2z:y-component of z axis  
                |    R3z:z-component of z axis

                |                | Examples:
                | This example shows how the offset list needs to be populated
                | ' Example of 45 degree rotation around the x-axis of placing
                | hand Dim oOffsetTransList(11) ' 0 to 11; relative
                | transformation between hand and object ' X axis rotation
                | component oOffsetTransList( 0 ) = 1 oOffsetTransList( 3 ) =
                | 0 oOffsetTransList( 6 ) = 0 ' Y axis rotation component
                | oOffsetTransList( 1 ) = 0 oOffsetTransList( 4 ) = 0.7071
                | oOffsetTransList( 7 ) = 0.7071 ' Z axis rotation component
                | oOffsetTransList( 2 ) = 0 oOffsetTransList( 5 ) = -0.7071
                | oOffsetTransList( 8 ) = 0.7071 ' position vector (relative
                | vector between the hand and object) oOffsetTransList( 9 ) =
                | 0 oOffsetTransList( 10 ) = 0 oOffsetTransList( 11 ) = 0

        :param o_offset_trans_list:
        :return:
        """
        return self.place_activity.SetOffset(o_offset_trans_list)

    def set_pick_act(self, pick_act):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPickAct
                | o Sub SetPickAct(        pickAct)
                | 
                | Sets or append a link to a Pick activity
                |
                | Parameters:

                |
        :param pick_act:
        :return:
        """
        return self.place_activity.SetPickAct(pick_act)

    def set_placed_products(self, p_placed_prods):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPlacedProducts
                | o Sub SetPlacedProducts(        pPlacedProds)
                | 
                |
                | Parameters:

                |
        :param p_placed_prods:
        :return:
        """
        return self.place_activity.SetPlacedProducts(p_placed_prods)

    def __repr__(self):
        return f'PlaceActivity()'
