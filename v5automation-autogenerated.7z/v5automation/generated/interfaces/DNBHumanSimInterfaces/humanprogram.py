#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HumanProgram(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The object that represents program-node of Worker.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.human_program = com_object     

    @property
    def task_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TaskList
                | o Property TaskList(    ) As   (Read Only)
                | 
                | Returns the HumanTaskList from HumanProgram Returns:
                | oTaskList
                |

        :return:
        """
        return self.human_program.TaskList

    def create_human_task(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateHumanTask
                | o Func CreateHumanTask(    ) As
                | 
                | Returns newly created HumanTask. Returns: oManikin
                |
                | Parameters:

                |
        :return:
        """
        return self.human_program.CreateHumanTask()

    def __repr__(self):
        return f'HumanProgram()'
