#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class MoveToPostureActivity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The object that represents an MoveToPosture(MTP) Activity.MTP allows
                | to store a target posture for a specific manikin at a specific time in
                | the process. When a MTP is created, the current posture of the manikin
                | along with any constraints (if any).

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.move_to_posture_activity = com_object     

    @property
    def acceleration_percent(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AccelerationPercent
                | o Property AccelerationPercent(    ) As
                | 
                | Returns or Sets Acceleration Percentage
                |

        :return:
        """
        return self.move_to_posture_activity.AccelerationPercent

    @property
    def corner_rounding(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CornerRounding
                | o Property CornerRounding(    ) As
                | 
                | Returns or Sets Corner Rounding
                |

        :return:
        """
        return self.move_to_posture_activity.CornerRounding

    @property
    def motion_basis(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MotionBasis
                | o Property MotionBasis(    ) As
                | 
                | Returns or Sets Motion-Basis (see for list of possible
                | values)
                |

        :return:
        """
        return self.move_to_posture_activity.MotionBasis

    @property
    def referential(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Referential
                | o Property Referential(    ) As
                | 
                | Returns or Sets Manikin Referential (see for list of
                | possible values)
                |

        :return:
        """
        return self.move_to_posture_activity.Referential

    @property
    def speed_percent(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpeedPercent
                | o Property SpeedPercent(    ) As
                | 
                | Returns or Sets Speed Percentage
                |

        :return:
        """
        return self.move_to_posture_activity.SpeedPercent

    def add_constraint(self, pi_constraint):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddConstraint
                | o Sub AddConstraint(        piConstraint)
                | 
                | Adds the given constraint to MoveToPosture activity
                |
                | Parameters:
                | piConstraint
                |  Constraint to be added.
                |  (see 
                | 
                |  for list of possible values)

                |
        :param pi_constraint:
        :return:
        """
        return self.move_to_posture_activity.AddConstraint(pi_constraint)

    def apply_posture_to_manikin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyPostureToManikin
                | o Sub ApplyPostureToManikin(    )
                | 
                | Set the MoveToPosture(MTP) Activity's DegreeOfFreedom(DOF)
                | values onto Manikin (which owns this MTP activity).
                |
                | Parameters:

                |
        :return:
        """
        return self.move_to_posture_activity.ApplyPostureToManikin()

    def get_constraint(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetConstraint
                | o Func GetConstraint(        iIndex) As
                | 
                | Returns the constraint at given index
                |
                | Parameters:
                | iIndex
                |  Index in the constraint-list to be retrieved
                |  
                | 
                |  Returns:
                |   pioConstraint Constraint at given index
                |  (see 
                |  for list of possible values)

                |
        :param i_index:
        :return:
        """
        return self.move_to_posture_activity.GetConstraint(i_index)

    def get_joint_values(self, o_joint_vals):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetJointValues
                | o Sub GetJointValues(        oJointVals)
                | 
                | Gets the Manikin's Position and Posture values in 137
                | doubles. (Array includeds Position information - first 6
                | values represent X,Y,Z and R,P,Y value of Manikin w.r.to its
                | Father.)
                |
                | Parameters:
                | oJointVals
                |  Joint Values

                |
        :param o_joint_vals:
        :return:
        """
        return self.move_to_posture_activity.GetJointValues(o_joint_vals)

    def get_number_of_constraints(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNumberOfConstraints
                | o Func GetNumberOfConstraints(    ) As
                | 
                | Returns the number of constraints on the MoveToPosture
                | activity Returns: iNumber Number of Constraints
                |
                | Parameters:

                |
        :return:
        """
        return self.move_to_posture_activity.GetNumberOfConstraints()

    def get_part_relation(self, e_ee, o_product, o_offset_trans):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPartRelation
                | o Func GetPartRelation(        eEE,
                |                                oProduct,
                |                                oOffsetTrans) As
                | 
                | DEPRECATED. DO NOT USE
                |
                | Parameters:

                |
        :param e_ee:
        :param o_product:
        :param o_offset_trans:
        :return:
        """
        return self.move_to_posture_activity.GetPartRelation(e_ee, o_product, o_offset_trans)

    def get_position(self, o_trans_matrix):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPosition
                | o Sub GetPosition(        oTransMatrix)
                | 
                | This gets the position value in 12 doubles
                |
                | Parameters:
                | oTransMatrix
                |  The first nine represent succcessively the components of the x-axis,
                |  y-axis, and z-axis.
                |  The last three represent the coordinates of the origin point.

                |
        :param o_trans_matrix:
        :return:
        """
        return self.move_to_posture_activity.GetPosition(o_trans_matrix)

    def get_posture_values(self, o_pos_vals):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPostureValues
                | o Sub GetPostureValues(        oPosVals)
                | 
                | Gets the Manikin's Posture values in 131 doubles. (This
                | array excludes Position information)
                |
                | Parameters:
                | oPosVals
                |  Posture values

                |
        :param o_pos_vals:
        :return:
        """
        return self.move_to_posture_activity.GetPostureValues(o_pos_vals)

    def get_segment_values(self, in_seg_name, o_dof_vals):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSegmentValues
                | o Sub GetSegmentValues(        inSegName,
                |                                oDofVals)
                | 
                | Gets the DOF values of the given segment from MoveToPosture
                | activity
                |
                | Parameters:
                | inSegName
                |  Name of the Segment
                |  
                |  oDofVals
                |  Dof values of constraint, array of size 3

                |
        :param in_seg_name:
        :param o_dof_vals:
        :return:
        """
        return self.move_to_posture_activity.GetSegmentValues(in_seg_name, o_dof_vals)

    def has_part_relation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasPartRelation
                | o Func HasPartRelation(    ) As
                | 
                | DEPRECATED. DO NOT USE
                |
                | Parameters:

                |
        :return:
        """
        return self.move_to_posture_activity.HasPartRelation()

    def remove_constraint(self, pi_constraint):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveConstraint
                | o Sub RemoveConstraint(        piConstraint)
                | 
                | Removes the given constraint from MoveToPosture activity
                |
                | Parameters:
                | piConstraint
                |  Constraint to be removed.
                |  (see 
                | 
                |  for list of possible values)

                |
        :param pi_constraint:
        :return:
        """
        return self.move_to_posture_activity.RemoveConstraint(pi_constraint)

    def set_current_constraint_set(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCurrentConstraintSet
                | o Sub SetCurrentConstraintSet(    )
                | 
                | Set the current Constraints existing on Manikin onto
                | MoveToPosture activity
                |
                | Parameters:

                |
        :return:
        """
        return self.move_to_posture_activity.SetCurrentConstraintSet()

    def set_joint_values(self, o_joint_vals):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetJointValues
                | o Sub SetJointValues(        oJointVals)
                | 
                | Sets the Manikin's Position and Posture values with 137
                | doubles. (Array should includes Position information - first
                | 6 values represent X,Y,Z and R,P,Y value of Manikin w.r.to
                | its Father.)
                |
                | Parameters:
                | oJointVals
                |  Joint Values

                |
        :param o_joint_vals:
        :return:
        """
        return self.move_to_posture_activity.SetJointValues(o_joint_vals)

    def set_part_relation(self, e_ee, o_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPartRelation
                | o Sub SetPartRelation(        eEE,
                |                               oProduct)
                | 
                | DEPRECATED. DO NOT USE
                |
                | Parameters:

                |
        :param e_ee:
        :param o_product:
        :return:
        """
        return self.move_to_posture_activity.SetPartRelation(e_ee, o_product)

    def set_part_relation_with_offset(self, e_ee, o_product, o_offset_trans):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPartRelationWithOffset
                | o Sub SetPartRelationWithOffset(        eEE,
                |                                         oProduct,
                |                                         oOffsetTrans)
                | 
                | DEPRECATED. DO NOT USE
                |
                | Parameters:

                |
        :param e_ee:
        :param o_product:
        :param o_offset_trans:
        :return:
        """
        return self.move_to_posture_activity.SetPartRelationWithOffset(e_ee, o_product, o_offset_trans)

    def set_position(self, o_trans_matrix):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPosition
                | o Sub SetPosition(        oTransMatrix)
                | 
                | Sets the Manikin's position value in the MoveToPosture
                | Activity. ( Pos. vals are w.r.to Manikin's Father )
                |
                | Parameters:
                | oTransMatrix
                |  The array initialized with the components to set to the
                |  Manikin's position.
                |  The first nine represent succcessively the components of the x-axis,
                |  y-axis, and z-axis.
                |  The last three represent the coordinates of the origin point.

                |                | Examples:
                | This example sets the Position of Manikin oTransMatrix for
                | MoveToPosture oMTP Dim oTransMatrix( 11 ) 'Rotation( 45
                | degrees around the Z axis) components ' x axis components
                | oTransMatrix( 0 ) = 0.707 oTransMatrix( 1 ) = 0.707
                | oTransMatrix( 2 ) = 0.0 ' y axis components oTransMatrix( 3
                | ) = -0.707 oTransMatrix( 4 ) = 0.707 oTransMatrix( 5 ) = 0 '
                | z axis components oTransMatrix( 6 ) = 0 oTransMatrix( 7 ) =
                | 0 oTransMatrix( 8 ) = 1 ' origin point coordinates
                | oTransMatrix( 9 ) = 0 oTransMatrix( 10 ) = 0 oTransMatrix(
                | 11 ) = 947.0 oMTP.SetPosition(oTransMatrix)

        :param o_trans_matrix:
        :return:
        """
        return self.move_to_posture_activity.SetPosition(o_trans_matrix)

    def set_posture_values(self, o_pos_vals):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPostureValues
                | o Sub SetPostureValues(        oPosVals)
                | 
                | Sets the Manikin's Posture values with 131 values
                |
                | Parameters:
                | oPosVals
                |  Posture values

                |
        :param o_pos_vals:
        :return:
        """
        return self.move_to_posture_activity.SetPostureValues(o_pos_vals)

    def set_segment_values(self, in_seg_name, o_dof_vals):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSegmentValues
                | o Sub SetSegmentValues(        inSegName,
                |                                oDofVals)
                | 
                | Sets the given DOF values for Segments from MoveToPosture
                | activity
                |
                | Parameters:
                | inSegName
                |  Name of the Segment
                |  
                |  oDofVals
                |  Dof values of constraint, array of size 3

                |
        :param in_seg_name:
        :param o_dof_vals:
        :return:
        """
        return self.move_to_posture_activity.SetSegmentValues(in_seg_name, o_dof_vals)

    def __repr__(self):
        return f'MoveToPostureActivity()'
