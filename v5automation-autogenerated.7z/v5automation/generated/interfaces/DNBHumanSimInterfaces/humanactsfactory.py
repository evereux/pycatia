#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HumanActsFactory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The object that represents the Human Activity Factory.Following
                | activity types could be created using the HumanActivity Factory.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.human_acts_factory = com_object     

    def create_auto_walk(self, o_prev_act):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateAutoWalk
                | o Func CreateAutoWalk(        oPrevAct) As
                | 
                | Returns newly created AutoWalkActivity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                | 
                |  Returns:
                |   oCreatedAutoWalk    newly created AutoWalkActivity

                |                | Examples:
                | This example creates AutoWalk Activity on Plane ' Get the
                | Human Acts factory and Human Task List Dim oHumActsFactory
                | As HumanActsFactory Dim oHumanTask As HumanTask Dim iPevAct
                | As Activity Dim oHT as HumanTask Dim ActList As Activities
                | Dim iPrevAct As Activity Dim oHumTaskList As HumanTaskList
                | Set oHT = oHumTaskList.Item(1) Set ActList =
                | oHT.ChildrenActivities Set iPrevAct = ActList.Item(2) '
                | MoveToPosture.1 Dim oCreatedAutoWalk as AutoWalkActivity
                | .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create AutoWalk Activity Set oCreatedAutoWalk =
                | oHumActsFactory.CreateAutoWalk(iPrevAct)

        :param o_prev_act:
        :return:
        """
        return self.human_acts_factory.CreateAutoWalk(o_prev_act)

    def create_collision_free_walk_bwd_on_arr_area(self, i_prev_act, i_arr_area, i_num_points, i_search_int, i_clearence, i_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateCollisionFreeWalkBwdOnArrArea
                | o Func CreateCollisionFreeWalkBwdOnArrArea(        iPrevAct,
                |                                                    iArrArea,
                |                                                    iNumPoints,
                |                                                    iSearchInt,
                |                                                    iClearence,
                |                                                    iPoints) As
                | 
                | Returns newly created Collision free Walk Backward Activity
                | on Arrangement Area.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iArrArea
                |     Arrangment Area - Plane of Walk
                |  
                |  iNumPoints
                |     Number of Coplanar-Points defining the Walk Path
                |  
                |  iSearchInt
                | 	(see 
                | 
                |  for list of possible values) 
                |      iClearance
                | 	The clearance value to be used for detecting collision between objects
                |  
                |  iPoints
                |     Point values   x1,y1,z1 , x2,y2,z2, .... in iArrArea coordinates
                |  
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity

                |                | Examples:
                | This example creates WalkBackward Activity on Arrangement
                | Area ' From the ProductList get the Arrangement Area Dim
                | oPPRDoc As PPRDocument Dim pprprodsProdList As PPRProducts
                | Dim prodAreasFather As Product Dim prodAreaFathersChildren
                | As Products Set oPPRDoc = DELMIA.ActiveDocument.PPRDocument
                | Set pprprodsProdList = oPPRDoc.Products Set prodAreasFather
                | = pprprodsProdList.Item(1) Set prodAreaFathersChildren =
                | prodAreasFather.Products Dim iArrArea As Product Set
                | iArrArea = prodAreaFathersChildren.GetItem("Area1.1") '
                | Specify the number of coplanar points defining the walk path
                | Dim iNumPoints as Long iNumPoints = 2 ' Specify the point
                | values for the walk path in oArrArea co-ordinates Dim
                | iPoints(6) as Double iPoints(0) = 0.0 ' Point1 - X
                | iPoints(1) = 0.0 ' Point1 - Y iPoints(2) = 0.0 ' Point1 - Z
                | iPoints(3) = 2000.0 ' Point2 - X iPoints(4) = 0.0 ' Point2 -
                | Y iPoints(5) = 0.0 ' Point2 - Z ' Get the Human Acts factory
                | Dim oHumActsFactory As HumanActsFactory Dim oHumanTask As
                | HumanTask Dim iPrevAct As Activity Dim oCreatedWalk as
                | DNBIACollisionFreeWalk .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create Collision free WalkBackward Activity on Arrangement
                | area Set oCreatedWalk = oHumActsFactory.CreateCollisionFreeW
                | alkBwdOnArrArea(iPrevAct, iArrArea, iNumPoints, iSearchInt,
                | iClearance, iPoints) ' Generate constituting MTPs
                | oCreatedWalk.Update .... ....

        :param i_prev_act:
        :param i_arr_area:
        :param i_num_points:
        :param i_search_int:
        :param i_clearence:
        :param i_points:
        :return:
        """
        return self.human_acts_factory.CreateCollisionFreeWalkBwdOnArrArea(i_prev_act, i_arr_area, i_num_points, i_search_int, i_clearence, i_points)

    def create_collision_free_walk_bwd_on_plane(self, i_prev_act, i_plane_prod, i_plane_def, i_num_points, i_search_int, i_clearence, i_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateCollisionFreeWalkBwdOnPlane
                | o Func CreateCollisionFreeWalkBwdOnPlane(        iPrevAct,
                |                                                  iPlaneProd,
                |                                                  iPlaneDef,
                |                                                  iNumPoints,
                |                                                  iSearchInt,
                |                                                  iClearence,
                |                                                  iPoints) As
                | 
                | Returns newly created Collision free Walk Backward Activity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iPlaneProd
                |     Handle to Product
                |  
                |  iPlaneDef
                |     Walk Plane definition - 9 doubles
                |     FirstAxis(i,j,k), SecondAxis(i,j,k), OriginOfPlane(x,y,z) in iPlaneProd Coordinates
                |  
                |  iNumPoints
                |  
                |  iSearchInt
                | 	(see 
                | 
                |  for list of possible values) 
                |      iClearance
                | 	The clearance value to be used for detecting collision between objects
                |     Number of Coplanar-Points defining the Walk Path in Plane
                |  
                |  iPoints
                |     Point values   x1,y1,z1 , x2,y2,z2, .... iPlaneDef coordinates
                |  
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity

                |                | Examples:
                | This example creates WalkBackward Activity on Plane ' From
                | the ProductList get the Walk Plane product Dim oPPRDoc As
                | PPRDocument Dim pprprodsProdList As PPRProducts Set oPPRDoc
                | = DELMIA.ActiveDocument.PPRDocument Set pprprodsProdList =
                | oPPRDoc.Products Dim oPlaneProd As Product Set oPlaneProd =
                | pprprodsProdList.Item(2) ' Plane Definition.. w.r.to Product
                | Dim iPlaneDef(9) as Double iPlaneDef(0) = 1.0 ' First Axis -
                | i vec iPlaneDef(1) = 0.0 ' First Axis - j vec iPlaneDef(2) =
                | 0.0 ' First Axis - k vec iPlaneDef(3) = 0.0 ' Second Axis -
                | i vec iPlaneDef(4) = 1.0 ' Second Axis - j vec iPlaneDef(5)
                | = 0.0 ' Second Axis - k vec iPlaneDef(6) = 0.0 ' Origin - X
                | iPlaneDef(7) = 0.0 ' Origin - Y iPlaneDef(8) = 0.0 ' Origin
                | - Z ' Specify the number of coplanar points defining the
                | walk path Dim iNumPoints as Long iNumPoints = 2 ' Specify
                | the point values for the walk path in oArrArea co-ordinates
                | Dim iPoints(6) as Double iPoints(0) = 0.0 ' Point1 - X
                | iPoints(1) = 0.0 ' Point1 - Y iPoints(2) = 0.0 ' Point1 - Z
                | iPoints(3) = 2000.0 ' Point2 - X iPoints(4) = 0.0 ' Point2 -
                | Y iPoints(5) = 0.0 ' Point2 - Z ' Get the Human Acts factory
                | Dim oHumActsFactory As HumanActsFactory Dim oHumanTask As
                | HumanTask Dim iPrevAct As Activity Dim oCreatedWalk as
                | DNBIACollisionFreeWalk .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create Collision free WalkBackward Activity on Plane Set
                | oCreatedWalk =
                | oHumActsFactory.CreateCollisionFreeWalkBwdOnPlane(iPrevAct,
                | iPlaneProd, iPlaneDef, iNumPoints, iSearchInt, iClearance,
                | iPoints) ' Generate constituting MTPs oCreatedWalk.Update
                | .... ....

        :param i_prev_act:
        :param i_plane_prod:
        :param i_plane_def:
        :param i_num_points:
        :param i_search_int:
        :param i_clearence:
        :param i_points:
        :return:
        """
        return self.human_acts_factory.CreateCollisionFreeWalkBwdOnPlane(i_prev_act, i_plane_prod, i_plane_def, i_num_points, i_search_int, i_clearence, i_points)

    def create_collision_free_walk_fwd_on_arr_area(self, i_prev_act, i_arr_area, i_num_points, i_search_int, i_clearence, i_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateCollisionFreeWalkFwdOnArrArea
                | o Func CreateCollisionFreeWalkFwdOnArrArea(        iPrevAct,
                |                                                    iArrArea,
                |                                                    iNumPoints,
                |                                                    iSearchInt,
                |                                                    iClearence,
                |                                                    iPoints) As
                | 
                | Returns newly created Collision free Walk Forward Activity.
                |
                | Parameters:
                | iPrevAct
                |     Previous Activity
                |  
                |  iArrArea
                |     Arrangment Area - Plane of Walk
                |  
                |  iNumPoints
                |     Number of Coplanar-Points defining the Walk Path
                |  
                |  iSearchInt
                |  (see 
                | 
                |  for list of possible values) 
                |      iClearance
                |   The clearance value to be used for detecting collision between objects
                |  
                |  iPoints
                |     Point values    x1,y1,z1 , x2,y2,z2, .... in iArrArea coordinates
                |  
                |  Returns:
                |   oCreatedWalk    Newly created WalkActivity

                |                | Examples:
                | This example creates Collision free WalkForward Activity on
                | Arrangement Area ' From the ProductList get the Arrangement
                | Area Dim oPPRDoc As PPRDocument Dim pprprodsProdList As
                | PPRProducts Dim prodAreasFather As Product Dim
                | prodAreaFathersChildren As Products Set oPPRDoc =
                | DELMIA.ActiveDocument.PPRDocument Set pprprodsProdList =
                | oPPRDoc.Products Set prodAreasFather =
                | pprprodsProdList.Item(1) Set prodAreaFathersChildren =
                | prodAreasFather.Products Dim iArrArea As Product Set
                | iArrArea = prodAreaFathersChildren.GetItem("Area1.1") '
                | Specify the number of coplanar points defining the walk path
                | Dim iNumPoints as Long iNumPoints = 2 ' Specify the point
                | values for the walk path in oArrArea co-ordinates Dim
                | iPoints(6) as Double iPoints(0) = 0.0 ' Point1 - X
                | iPoints(1) = 0.0 ' Point1 - Y iPoints(2) = 0.0 ' Point1 - Z
                | iPoints(3) = 2000.0 ' Point2 - X iPoints(4) = 0.0 ' Point2 -
                | Y iPoints(5) = 0.0 ' Point2 - Z ' Get the Human Acts factory
                | Dim oHumActsFactory As HumanActsFactory Dim oHumanTask As
                | HumanTask Dim iPrevAct As Activity Dim oCreatedWalk as
                | DNBIACollisionFreeWalk .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") Dim
                | iClearance as Double iClearance = 170 Dim iSearchInt as Long
                | iSearchInt = 1 ' Create Collision free WalkForward Activity
                | on Arrangement area Set oCreatedWalk = oHumActsFactory.Creat
                | eCollisionFreeWalkFwdOnArrArea(iPrevAct, iArrArea,
                | iNumPoints, iSearchInt, iClearance, iPoints) ' Generate
                | constituting MTPs oCreatedWalk.Update .... ....

        :param i_prev_act:
        :param i_arr_area:
        :param i_num_points:
        :param i_search_int:
        :param i_clearence:
        :param i_points:
        :return:
        """
        return self.human_acts_factory.CreateCollisionFreeWalkFwdOnArrArea(i_prev_act, i_arr_area, i_num_points, i_search_int, i_clearence, i_points)

    def create_collision_free_walk_fwd_on_plane(self, i_prev_act, i_plane_prod, i_plane_def, i_num_points, i_search_int, i_clearence, i_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateCollisionFreeWalkFwdOnPlane
                | o Func CreateCollisionFreeWalkFwdOnPlane(        iPrevAct,
                |                                                  iPlaneProd,
                |                                                  iPlaneDef,
                |                                                  iNumPoints,
                |                                                  iSearchInt,
                |                                                  iClearence,
                |                                                  iPoints) As
                | 
                | Returns newly created Collision free Walk Forward Activity
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iPlaneProd
                |     Handle to Walk plane product
                |  
                |  iPlaneDef
                |     Walk Plane definition - 9 doubles
                |     FirstAxis(i,j,k), SecondAxis(i,j,k), OriginOfPlane(x,y,z) in iPlaneProd Coordinates
                |  
                |  iNumPoints
                |     Number of Coplanar-Points defining the Walk Path in Plane
                |  
                |  iSearchInt
                | 	(see 
                | 
                |  for list of possible values) 
                |      iClearance
                | 	The clearance value to be used for detecting collision between objects
                |  
                |  iPoints
                |     Point values   x1,y1,z1 , x2,y2,z2, .... iPlaneDef coordinates
                |  
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity

                |                | Examples:
                | This example creates WalkForward Activity on Plane ' From
                | the ProductList get the Walk Plane product Dim oPPRDoc As
                | PPRDocument Dim pprprodsProdList As PPRProducts Set oPPRDoc
                | = DELMIA.ActiveDocument.PPRDocument Set pprprodsProdList =
                | oPPRDoc.Products Dim oPlaneProd As Product Set oPlaneProd =
                | pprprodsProdList.Item(2) ' Plane Definition.. w.r.to Product
                | Dim iPlaneDef(9) as Double iPlaneDef(0) = 1.0 ' First Axis -
                | i vec iPlaneDef(1) = 0.0 ' First Axis - j vec iPlaneDef(2) =
                | 0.0 ' First Axis - k vec iPlaneDef(3) = 0.0 ' Second Axis -
                | i vec iPlaneDef(4) = 1.0 ' Second Axis - j vec iPlaneDef(5)
                | = 0.0 ' Second Axis - k vec iPlaneDef(6) = 0.0 ' Origin - X
                | iPlaneDef(7) = 0.0 ' Origin - Y iPlaneDef(8) = 0.0 ' Origin
                | - Z ' Specify the number of coplanar points defining the
                | walk path Dim iNumPoints as Long iNumPoints = 2 ' Specify
                | the point values for the walk path in oArrArea co-ordinates
                | Dim iPoints(6) as Double iPoints(0) = 0.0 ' Point1 - X
                | iPoints(1) = 0.0 ' Point1 - Y iPoints(2) = 0.0 ' Point1 - Z
                | iPoints(3) = 2000.0 ' Point2 - X iPoints(4) = 0.0 ' Point2 -
                | Y iPoints(5) = 0.0 ' Point2 - Z ' Get the Human Acts factory
                | Dim oHumActsFactory As HumanActsFactory Dim oHumanTask As
                | HumanTask Dim iPrevAct As Activity Dim oCreatedWalk as
                | DNBIACollisionFreeWalk .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create Collision free WalkForward Activity on Plane Set
                | oCreatedWalk =
                | oHumActsFactory.CreateCollisionFreeWalkFwdOnPlane(iPrevAct,
                | iPlaneProd, iPlaneDef, iNumPoints, iPoints) ' Generate
                | constituting MTPs oCreatedWalk.Update .... ....

        :param i_prev_act:
        :param i_plane_prod:
        :param i_plane_def:
        :param i_num_points:
        :param i_search_int:
        :param i_clearence:
        :param i_points:
        :return:
        """
        return self.human_acts_factory.CreateCollisionFreeWalkFwdOnPlane(i_prev_act, i_plane_prod, i_plane_def, i_num_points, i_search_int, i_clearence, i_points)

    def create_human_activity_group(self, i_prev_act):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateHumanActivityGroup
                | o Func CreateHumanActivityGroup(        iPrevAct) As
                | 
                | Returns newly created HumanActivityGroupActivity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                | 
                |  Returns:
                |   oHAG    newly created HumanActivityGroup

                |                | Examples:
                | This example creates Human Activity Group Activity ' Get the
                | Human Acts factory Dim oHumActsFactory As HumanActsFactory
                | Dim oHumanTask As HumanTask ... Dim iPrevAct As Activity Dim
                | oCreatedHAG as DNBIAHumanActivityGroup .... .... Set
                | oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create Human Activity Group Set oCreatedHAG =
                | oHumActsFactory.CreateHumanActivityGroup(iPrevAct)

        :param i_prev_act:
        :return:
        """
        return self.human_acts_factory.CreateHumanActivityGroup(i_prev_act)

    def create_human_call_task(self, i_previous_activity, i_called_task):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateHumanCallTask
                | o Func CreateHumanCallTask(        iPreviousActivity,
                |                                    iCalledTask) As
                | 
                | Returns newly created HumanCallTask.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iCalledTask
                |     The Human Task that has to be called from the Call Task Activity
                |  
                | 
                |  Returns:
                |   oCreatedHumanCallTaskAct    newly created Human Call Task activity

                |                | Examples:
                | This example creates Human CallTask Activity ' Get the Human
                | Acts factory Dim oHumActsFactory As HumanActsFactory Dim
                | oHumanTask As HumanTask ' The parent task that will have the
                | call task activity as child ... Dim iPrevAct As Activity Dim
                | iCalledTask As HumanTask ' The human task that will be
                | called from CallTask activity ... Dim
                | oCreatedHumanCallTaskAct as DNBIAHumanCallTaskActivity ....
                | .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create Human Call Task Activity Set oCreatedHumanCallTaskAct
                | = oHumActsFactory.CreateHumanCallTask(iPrevAct, iCalledTask)

        :param i_previous_activity:
        :param i_called_task:
        :return:
        """
        return self.human_acts_factory.CreateHumanCallTask(i_previous_activity, i_called_task)

    def create_move_to_posture(self, i_prev_act):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateMoveToPosture
                | o Func CreateMoveToPosture(        iPrevAct) As
                | 
                | Returns newly created MoveToPostureActivity. Current posture
                | of Manikin is set as joint-values for created
                | MoveToPostureActivity. Use MoveToPostureActivity APIs to
                | change joint-values.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                | 
                |  Returns:
                |   oCreatedMTP    newly created MoveToPostureActivity

                |                | Examples:
                | This example creates MoveToPosture Activity ' Get the Human
                | Acts factory Dim oHumActsFactory As HumanActsFactory Dim
                | oHumanTask As HumanTask Dim iPrevAct As Activity Dim
                | oCreatedMTP as MoveToPostureActivity .... .... Set
                | oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create MoveToPosture Activity Set oCreatedMTP =
                | oHumActsFactory.CreateMoveToPosture(iPrevAct) .... ....

        :param i_prev_act:
        :return:
        """
        return self.human_acts_factory.CreateMoveToPosture(i_prev_act)

    def create_pick(self, i_prev_act, i_pick_type, b_create_cst_with_picking_hand, i_picking_hand, i_picked_products):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreatePick
                | o Func CreatePick(        iPrevAct,
                |                           iPickType,
                |                           bCreateCstWithPickingHand,
                |                           iPickingHand,
                |                           iPickedProducts) As
                | 
                | Returns newly created Pick Activity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iPickType
                | 	  Pick Type: SINGLE_HAND or BOTH_HANDS
                |  
                |  bCreateCstWithPickingHand
                | 	  Boolean flag to indicate whether constraint has to be created between the picked object and picking hand
                |  
                |  iPickingHand
                |     picking hand: HAND_RIGHT or HAND_LEFT
                |  
                |  iPickedProducts
                |     List of picked products
                |  
                | 
                |  Returns:
                |   oCreatedPick    newly created PickActivity

                |                | Examples:
                | This example creates Pick Activity ' Get the Human Acts
                | factory and Human Task List Dim oHumActsFactory As
                | HumanActsFactory Dim oHumanTask As HumanTask Dim oHT as
                | HumanTask Dim ActList As Activities Dim iPrevAct As Activity
                | Dim oHumTaskList As HumanTaskList Set oHT =
                | oHumTaskList.Item(1) Set ActList = oHT.ChildrenActivities
                | Set iPrevAct = ActList.Item(2) ' MoveToPosture.1 Dim
                | oCreatedPick as PickActivity .... ' Specify the picked
                | products Dim iPickedProds(1) As AnyObject Dim oPPRDoc As
                | PPRDocument Dim pprprodsProdList As PPRProducts Set
                | pprprodsProdList = oPPRDoc.Products Set iPickedProducts =
                | pprprodsProdList.Item(2) .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create Pick Activity Set oCreatePick =
                | oHumActsFactory.CreatePick(iPrevAct,SINGLE_HAND, TRUE,
                | HAND_RIGHT, iPickedProducts)

        :param i_prev_act:
        :param i_pick_type:
        :param b_create_cst_with_picking_hand:
        :param i_picking_hand:
        :param i_picked_products:
        :return:
        """
        return self.human_acts_factory.CreatePick(i_prev_act, i_pick_type, b_create_cst_with_picking_hand, i_picking_hand, i_picked_products)

    def create_place(self, i_prev_act, i_placed_products, i_offset):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreatePlace
                | o Func CreatePlace(        iPrevAct,
                |                            iPlacedProducts,
                |                            iOffset) As
                | 
                | Returns newly created Place Activity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iPlacedProducts
                |     List of products to be placed
                |  
                |  iPlaceOffset
                |     Offset to be maintainted between the placing hand and the object. 
                | 	 The offset has to be specified as the relative trnsformation between the placing hand
                | 	 and the object to be placed. The first 9 entries correspond to the rotation matrix and the  
                | 	 next 3 entries correspond to the position vector. 
                |   
                |  R1x  R1y  R1z  
                |  R2x  R2y  R2z  
                |  R3x  R3y  R3z  
                |  Px  Py  Pz  
                | 
                |    R1x:x-component of x axis  
                |    R2x:y-component of x axis  
                |    R3x:z-component of x axis  
                |    R1y:x-component of y axis  
                |    R2y:y-component of y axis  
                |    R3y:z-component of y axis  
                |    R1z:x-component of z axis  
                |    R2z:y-component of z axis  
                |    R3z:z-component of z axis 
                | 
                | 
                |  Returns:
                |   oCreatedPlace    Newly created PlaceActivity

                |                | Examples:
                | This example creates Place Activity ' Get the Human Acts
                | factory and Human Task List Dim oHumActsFactory As
                | HumanActsFactory Dim oHumanTask As HumanTask Dim oHT as
                | HumanTask Dim ActList As Activities Dim iPrevAct As Activity
                | Dim oHumTaskList As HumanTaskList Set oHT =
                | oHumTaskList.Item(1) Set ActList = oHT.ChildrenActivities
                | Set iPrevAct = ActList.Item(2) ' MoveToPosture.1 Dim
                | oCreatedPlace as Placectivity .... ' Get the list of picked
                | products from the Pick Activity Dim iPickedProducts As
                | AnyObject 'Example of 45 degree rotation around the x-axis
                | of placing hand Dim iPlaceOffset(12) As Double ' 12 doubles
                | - 0 to 11; relative transformation between hand and object '
                | X axis rotation component iPlaceOffset( 0 ) = 1
                | iPlaceOffset( 3 ) = 0 iPlaceOffset( 6 ) = 0 ' Y axis
                | rotation component iPlaceOffset( 1 ) =0 iPlaceOffset( 4 )
                | =0.707 iPlaceOffset( 7 ) = 0.707 ' Z axis rotation component
                | iPlaceOffset( 2 ) = 0 iPlaceOffset( 5 ) = -0.707
                | iPlaceOffset( 8 ) = 0.707 ' position vector (relative vector
                | between the hand and object) iPlaceOffset( 9 ) = 0
                | iPlaceOffset( 10 ) = 0 iPlaceOffset( 11 ) = 0 Set
                | oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create Place Activity Set oCreatedPlace =
                | oHumActsFactory.CreatePlace(iPrevAct,iPickedProducts,
                | iPlaceOffset);

        :param i_prev_act:
        :param i_placed_products:
        :param i_offset:
        :return:
        """
        return self.human_acts_factory.CreatePlace(i_prev_act, i_placed_products, i_offset)

    def create_side_step_on_arr_area(self, i_prev_act, i_arr_area, i_start_pt, i_end_pt):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSideStepOnArrArea
                | o Func CreateSideStepOnArrArea(        iPrevAct,
                |                                        iArrArea,
                |                                        iStartPt,
                |                                        iEndPt) As
                | 
                | Returns newly created Side-Step Activity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iArrArea
                |     Arrangment Area - Plane of Walk
                |  
                |  iStartPt
                |     Start Point - x,y,z in iArrArea coordinates
                |  
                |  iEndPt
                |     End Point - x,y,z in iArrArea coordinates
                |  
                | 
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity
                |  
                | 	' From the ProductList get the Arrangement Area
                | 	Dim oPPRDoc As PPRDocument
                | 	Dim pprprodsProdList As PPRProducts
                | 	Dim prodAreasFather As Product
                | 	Dim prodAreaFathersChildren As Products
                | 
                | 	Set oPPRDoc = DELMIA.ActiveDocument.PPRDocument
                | 	Set pprprodsProdList = oPPRDoc.Products
                | 	Set prodAreasFather = pprprodsProdList.Item(1)
                | 	Set prodAreaFathersChildren = prodAreasFather.Products
                | 
                | 	Dim iArrArea As Product
                | 	Set iArrArea = prodAreaFathersChildren.GetItem("Area1.1")
                | 
                | 	' Specify the Start and End  points for the side step walk activity
                | 	Dim iStart(3) as Double
                | 	Dim iEnd(3) as Double
                | 	iStart(0) = 0
                | 	iStart(1) = 0
                | 	iStart(2) = 0.0
                | 	iEnd(0) = 2000
                | 	iEnd(1) = 0
                | 	iEnd(2) = 0.0
                | 
                |    ' Get the Human Acts factory
                | 	Dim oHumActsFactory As HumanActsFactory
                |    Dim oHumanTask As HumanTask
                |    Dim iPrevAct As Activity
                | 	Dim oCreatedWalk as WalkActivity
                |    ....
                |    ....
                |    Set oHumActsFactory = oHumanTask.GetTechnologicalObject("HumanActsFactory")
                | 
                |    ' Create SideStep Activity on Arrangement area
                |    oCreatedWalk = oHumActsFactory.CreateSideStepOnArrArea(iPrevAct, iArrArea, iStartPt, iEndPt) 
                | 	' Generate constituting MTPs
                | 	oCreatedWalk.Update

                |
        :param i_prev_act:
        :param i_arr_area:
        :param i_start_pt:
        :param i_end_pt:
        :return:
        """
        return self.human_acts_factory.CreateSideStepOnArrArea(i_prev_act, i_arr_area, i_start_pt, i_end_pt)

    def create_side_step_on_plane(self, i_prev_act, i_plane_prod, i_plane_def, i_start_pt, id_end_pt):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSideStepOnPlane
                | o Func CreateSideStepOnPlane(        iPrevAct,
                |                                      iPlaneProd,
                |                                      iPlaneDef,
                |                                      iStartPt,
                |                                      idEndPt) As
                | 
                | Returns newly created Side-Step Activity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iPlaneProd
                |     Handle to Product
                |  
                |  iPlaneDef
                |     Walk Plane definition - 9 doubles
                |     FirstAxis(i,j,k), SecondAxis(i,j,k), OriginOfPlane(x,y,z) in oCGRProd Coordinates
                |  
                |  iStartPt
                |     Start Point - x,y,z in iPlaneDef coordinates
                |  
                |  iEndPt
                |     End Point - x,y,z in iPlaneDef coordinates
                |  
                | 
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity

                |                | Examples:
                | This example creates SideStep Activity on Plane ' From the
                | ProductList get the Walk Plane product Dim oPPRDoc As
                | PPRDocument Dim pprprodsProdList As PPRProducts Set oPPRDoc
                | = DELMIA.ActiveDocument.PPRDocument Set pprprodsProdList =
                | oPPRDoc.Products Dim oPlaneProd As Product Set oPlaneProd =
                | pprprodsProdList.Item(2) ' Plane Definition.. w.r.to Product
                | Dim adPlaneDef(9) as Double adPlaneDef(0) = 1.0 ' First Axis
                | - i vec adPlaneDef(1) = 0.0 ' First Axis - j vec
                | adPlaneDef(2) = 0.0 ' First Axis - k vec adPlaneDef(3) = 0.0
                | ' Second Axis - i vec adPlaneDef(4) = 1.0 ' Second Axis - j
                | vec adPlaneDef(5) = 0.0 ' Second Axis - k vec adPlaneDef(6)
                | = 0.0 ' Origin - X adPlaneDef(7) = 0.0 ' Origin - Y
                | adPlaneDef(8) = 0.0 ' Origin - Z ' Specify the number of
                | coplanar points defining the walk path Dim iNumPoints as
                | Long iNumPoints = 2 ' Specify the point values for the walk
                | path in oArrArea co-ordinates Dim adStart(3) as Double Dim
                | adEnd(3) as Double adStart(0) = 0 adStart(1) = 0 adStart(2)
                | = 0.0 adEnd(0) = 2000 adEnd(1) = 0 adEnd(2) = 0.0 ' Get the
                | Human Acts factory Dim oHumActsFactory As HumanActsFactory
                | Dim oHumanTask As HumanTask Dim iPeviousActivity As Activity
                | Dim oCreatedWalk as WalkActivity .... .... Set
                | oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create SideStep Activity on Plane oCreatedWalk =
                | oHumActsFactory.CreateSideStepOnPlane(iPrevAct, iPlaneProd,
                | iPlaneDef, iStartPt, iEndPt) ' Generate constituting MTPs
                | oCreatedWalk.Update .... ....

        :param i_prev_act:
        :param i_plane_prod:
        :param i_plane_def:
        :param i_start_pt:
        :param id_end_pt:
        :return:
        """
        return self.human_acts_factory.CreateSideStepOnPlane(i_prev_act, i_plane_prod, i_plane_def, i_start_pt, id_end_pt)

    def create_walk_bwd_on_arr_area(self, i_prev_act, i_arr_area, i_num_points, i_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateWalkBwdOnArrArea
                | o Func CreateWalkBwdOnArrArea(        iPrevAct,
                |                                       iArrArea,
                |                                       iNumPoints,
                |                                       iPoints) As
                | 
                | Returns newly created Walk Backward Activity on Arrangement
                | Area.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iArrArea
                |     Arrangment Area - Plane of Walk
                |  
                |  iNumPoints
                |     Number of Coplanar-Points defining the Walk Path
                |  
                |  iPoints
                |     Point values   x1,y1,z1 , x2,y2,z2, .... in iArrArea coordinates
                |  
                | 
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity

                |                | Examples:
                | This example creates WalkBackward Activity on Arrangement
                | Area ' From the ProductList get the Arrangement Area Dim
                | oPPRDoc As PPRDocument Dim pprprodsProdList As PPRProducts
                | Dim prodAreasFather As Product Dim prodAreaFathersChildren
                | As Products Set oPPRDoc = DELMIA.ActiveDocument.PPRDocument
                | Set pprprodsProdList = oPPRDoc.Products Set prodAreasFather
                | = pprprodsProdList.Item(1) Set prodAreaFathersChildren =
                | prodAreasFather.Products Dim iArrArea As Product Set
                | iArrArea = prodAreaFathersChildren.GetItem("Area1.1") '
                | Specify the number of coplanar points defining the walk path
                | Dim iNumPoints as Long iNumPoints = 2 ' Specify the point
                | values for the walk path in oArrArea co-ordinates Dim
                | iPoints(6) as Double iPoints(0) = 0.0 ' Point1 - X
                | iPoints(1) = 0.0 ' Point1 - Y iPoints(2) = 0.0 ' Point1 - Z
                | iPoints(3) = 2000.0 ' Point2 - X iPoints(4) = 0.0 ' Point2 -
                | Y iPoints(5) = 0.0 ' Point2 - Z ' Get the Human Acts factory
                | Dim oHumActsFactory As HumanActsFactory Dim oHumanTask As
                | HumanTask Dim iPrevAct As Activity Dim oCreatedWalk as
                | WalkActivity .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create WalkBackward Activity on Arrangement area Set
                | oCreatedWalk =
                | oHumActsFactory.CreateWalkBwdOnArrArea(iPrevAct, iArrArea,
                | iNumPoints, iPoints) ' Generate constituting MTPs
                | oCreatedWalk.Update .... ....

        :param i_prev_act:
        :param i_arr_area:
        :param i_num_points:
        :param i_points:
        :return:
        """
        return self.human_acts_factory.CreateWalkBwdOnArrArea(i_prev_act, i_arr_area, i_num_points, i_points)

    def create_walk_bwd_on_plane(self, i_prev_act, i_plane_prod, i_plane_def, i_num_points, i_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateWalkBwdOnPlane
                | o Func CreateWalkBwdOnPlane(        iPrevAct,
                |                                     iPlaneProd,
                |                                     iPlaneDef,
                |                                     iNumPoints,
                |                                     iPoints) As
                | 
                | Returns newly created Walk Backward Activity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iPlaneProd
                |     Handle to Product
                |  
                |  iPlaneDef
                |     Walk Plane definition - 9 doubles
                |     FirstAxis(i,j,k), SecondAxis(i,j,k), OriginOfPlane(x,y,z) in iPlaneProd Coordinates
                |  
                |  iNumPoints
                |     Number of Coplanar-Points defining the Walk Path in Plane
                |  
                |  iPoints
                |     Point values   x1,y1,z1 , x2,y2,z2, .... iPlaneDef coordinates
                |  
                | 
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity

                |                | Examples:
                | This example creates WalkBackward Activity on Plane ' From
                | the ProductList get the Walk Plane product Dim oPPRDoc As
                | PPRDocument Dim pprprodsProdList As PPRProducts Set oPPRDoc
                | = DELMIA.ActiveDocument.PPRDocument Set pprprodsProdList =
                | oPPRDoc.Products Dim oPlaneProd As Product Set oPlaneProd =
                | pprprodsProdList.Item(2) ' Plane Definition.. w.r.to Product
                | Dim iPlaneDef(9) as Double iPlaneDef(0) = 1.0 ' First Axis -
                | i vec iPlaneDef(1) = 0.0 ' First Axis - j vec iPlaneDef(2) =
                | 0.0 ' First Axis - k vec iPlaneDef(3) = 0.0 ' Second Axis -
                | i vec iPlaneDef(4) = 1.0 ' Second Axis - j vec iPlaneDef(5)
                | = 0.0 ' Second Axis - k vec iPlaneDef(6) = 0.0 ' Origin - X
                | iPlaneDef(7) = 0.0 ' Origin - Y iPlaneDef(8) = 0.0 ' Origin
                | - Z ' Specify the number of coplanar points defining the
                | walk path Dim iNumPoints as Long iNumPoints = 2 ' Specify
                | the point values for the walk path in oArrArea co-ordinates
                | Dim iPoints(6) as Double iPoints(0) = 0.0 ' Point1 - X
                | iPoints(1) = 0.0 ' Point1 - Y iPoints(2) = 0.0 ' Point1 - Z
                | iPoints(3) = 2000.0 ' Point2 - X iPoints(4) = 0.0 ' Point2 -
                | Y iPoints(5) = 0.0 ' Point2 - Z ' Get the Human Acts factory
                | Dim oHumActsFactory As HumanActsFactory Dim oHumanTask As
                | HumanTask Dim iPrevAct As Activity Dim oCreatedWalk as
                | WalkActivity .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create WalkBackward Activity on Plane Set oCreatedWalk =
                | oHumActsFactory.CreateWalkBwdOnPlane(iPrevAct, iPlaneProd,
                | iPlaneDef, iNumPoints, iPoints) ' Generate constituting MTPs
                | oCreatedWalk.Update .... ....

        :param i_prev_act:
        :param i_plane_prod:
        :param i_plane_def:
        :param i_num_points:
        :param i_points:
        :return:
        """
        return self.human_acts_factory.CreateWalkBwdOnPlane(i_prev_act, i_plane_prod, i_plane_def, i_num_points, i_points)

    def create_walk_fwd_on_arr_area(self, i_prev_act, i_arr_area, i_num_points, i_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateWalkFwdOnArrArea
                | o Func CreateWalkFwdOnArrArea(        iPrevAct,
                |                                       iArrArea,
                |                                       iNumPoints,
                |                                       iPoints) As
                | 
                | Returns newly created Walk Forward Activity.
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iArrArea
                |     Arrangment Area - Plane of Walk
                |  
                |  iNumPoints
                |     Number of Coplanar-Points defining the Walk Path
                |  
                |  iPoints
                |     Point values    x1,y1,z1 , x2,y2,z2, .... in iArrArea coordinates
                |  
                | 
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity

                |                | Examples:
                | This example creates WalkForward Activity on Arrangement
                | Area ' From the ProductList get the Arrangement Area Dim
                | oPPRDoc As PPRDocument Dim pprprodsProdList As PPRProducts
                | Dim prodAreasFather As Product Dim prodAreaFathersChildren
                | As Products Set oPPRDoc = DELMIA.ActiveDocument.PPRDocument
                | Set pprprodsProdList = oPPRDoc.Products Set prodAreasFather
                | = pprprodsProdList.Item(1) Set prodAreaFathersChildren =
                | prodAreasFather.Products Dim iArrArea As Product Set
                | iArrArea = prodAreaFathersChildren.GetItem("Area1.1") '
                | Specify the number of coplanar points defining the walk path
                | Dim iNumPoints as Long iNumPoints = 2 ' Specify the point
                | values for the walk path in oArrArea co-ordinates Dim
                | iPoints(6) as Double iPoints(0) = 0.0 ' Point1 - X
                | iPoints(1) = 0.0 ' Point1 - Y iPoints(2) = 0.0 ' Point1 - Z
                | iPoints(3) = 2000.0 ' Point2 - X iPoints(4) = 0.0 ' Point2 -
                | Y iPoints(5) = 0.0 ' Point2 - Z ' Get the Human Acts factory
                | Dim oHumActsFactory As HumanActsFactory Dim oHumanTask As
                | HumanTask Dim iPrevAct As Activity Dim oCreatedWalk as
                | WalkActivity .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create WalkForward Activity on Arrangement area Set
                | oCreatedWalk =
                | oHumActsFactory.CreateWalkFwdOnArrArea(iPrevAct, iArrArea,
                | iNumPoints, iPoints) ' Generate constituting MTPs
                | oCreatedWalk.Update .... ....

        :param i_prev_act:
        :param i_arr_area:
        :param i_num_points:
        :param i_points:
        :return:
        """
        return self.human_acts_factory.CreateWalkFwdOnArrArea(i_prev_act, i_arr_area, i_num_points, i_points)

    def create_walk_fwd_on_plane(self, i_prev_act, i_prod, i_plane_def, i_num_points, i_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateWalkFwdOnPlane
                | o Func CreateWalkFwdOnPlane(        iPrevAct,
                |                                     iProd,
                |                                     iPlaneDef,
                |                                     iNumPoints,
                |                                     iPoints) As
                | 
                | Returns newly created Walk Forward Activity
                |
                | Parameters:
                | iPrevAct
                |     previous activity
                |  
                |  iPlaneProd
                |     Handle to Walk plane product
                |  
                |  iPlaneDef
                |     Walk Plane definition - 9 doubles
                |     FirstAxis(i,j,k), SecondAxis(i,j,k), OriginOfPlane(x,y,z) in iPlaneProd Coordinates
                |  
                |  iNumPoints
                |     Number of Coplanar-Points defining the Walk Path in Plane
                |  
                |  iPoints
                |     Point values   x1,y1,z1 , x2,y2,z2, .... iPlaneDef coordinates
                |  
                | 
                |  Returns:
                |   oCreatedWalk    newly created WalkActivity

                |                | Examples:
                | This example creates WalkForward Activity on Plane ' From
                | the ProductList get the Walk Plane product Dim oPPRDoc As
                | PPRDocument Dim pprprodsProdList As PPRProducts Set oPPRDoc
                | = DELMIA.ActiveDocument.PPRDocument Set pprprodsProdList =
                | oPPRDoc.Products Dim oPlaneProd As Product Set oPlaneProd =
                | pprprodsProdList.Item(2) ' Plane Definition.. w.r.to Product
                | Dim iPlaneDef(9) as Double iPlaneDef(0) = 1.0 ' First Axis -
                | i vec iPlaneDef(1) = 0.0 ' First Axis - j vec iPlaneDef(2) =
                | 0.0 ' First Axis - k vec iPlaneDef(3) = 0.0 ' Second Axis -
                | i vec iPlaneDef(4) = 1.0 ' Second Axis - j vec iPlaneDef(5)
                | = 0.0 ' Second Axis - k vec iPlaneDef(6) = 0.0 ' Origin - X
                | iPlaneDef(7) = 0.0 ' Origin - Y iPlaneDef(8) = 0.0 ' Origin
                | - Z ' Specify the number of coplanar points defining the
                | walk path Dim iNumPoints as Long iNumPoints = 2 ' Specify
                | the point values for the walk path in oArrArea co-ordinates
                | Dim iPoints(6) as Double iPoints(0) = 0.0 ' Point1 - X
                | iPoints(1) = 0.0 ' Point1 - Y iPoints(2) = 0.0 ' Point1 - Z
                | iPoints(3) = 2000.0 ' Point2 - X iPoints(4) = 0.0 ' Point2 -
                | Y iPoints(5) = 0.0 ' Point2 - Z ' Get the Human Acts factory
                | Dim oHumActsFactory As HumanActsFactory Dim oHumanTask As
                | HumanTask Dim iPrevAct As Activity Dim oCreatedWalk as
                | WalkActivity .... .... Set oHumActsFactory =
                | oHumanTask.GetTechnologicalObject("HumanActsFactory") '
                | Create WalkForward Activity on Plane Set oCreatedWalk =
                | oHumActsFactory.CreateWalkFwdOnPlane(iPrevAct, iPlaneProd,
                | iPlaneDef, iNumPoints, iPoints) ' Generate constituting MTPs
                | oCreatedWalk.Update .... ....

        :param i_prev_act:
        :param i_prod:
        :param i_plane_def:
        :param i_num_points:
        :param i_points:
        :return:
        """
        return self.human_acts_factory.CreateWalkFwdOnPlane(i_prev_act, i_prod, i_plane_def, i_num_points, i_points)

    def __repr__(self):
        return f'HumanActsFactory()'
