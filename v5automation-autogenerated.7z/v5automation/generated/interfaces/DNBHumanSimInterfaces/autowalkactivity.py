#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AutoWalkActivity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface that represents an Auto-Walk activity

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.auto_walk_activity = com_object     

    def get_length_in_metre(self, d_length, b_curr_manikin_pose):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLengthInMetre
                | o Sub GetLengthInMetre(        dLength,
                |                                bCurrManikinPose)
                | 
                | This gets the auto walk length in metres
                |
                | Parameters:
                | bCurrManikinPosition
                |  The bCurrManikinPosition flag is used to obtain the walk length for autowalk dynamically based 
                |  on the location of manikin irrespective of its previous MoveToPosture activity;
                |  in a line tracking scenario if the manikin has a body constraint with a moving object then, 
                |  the Degree Of Freedom (DOF)of previous MoveToPosture activity gives only the static walk length
                |  and is incorrect. By defuault, this value will be taken as FALSE
                |  
                | 
                |  Returns:
                |   dLength walk length in metre

                |
        :param d_length:
        :param b_curr_manikin_pose:
        :return:
        """
        return self.auto_walk_activity.GetLengthInMetre(d_length, b_curr_manikin_pose)

    def __repr__(self):
        return f'AutoWalkActivity()'
