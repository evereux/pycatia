#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CollisionFreeWalk(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing Collision free walk activity

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.collision_free_walk = com_object     

    @property
    def collision_clearance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CollisionClearance
                | o Property CollisionClearance(    ) As
                | 
                | Returns and sets the value for 'collision clearance' in a
                | collision free walk. Role: Returns and sets the value of
                | 'colllision clearance' from a collision free walk Activity
                | Returns: Legal values: S_OK : on Success E_FAIL: on failure
                |

        :return:
        """
        return self.collision_free_walk.CollisionClearance

    @collision_clearance.setter
    def collision_clearance(self, value):
        """
            :param type value:
        """
        self.collision_free_walk.CollisionClearance = value 

    @property
    def search_intensity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SearchIntensity
                | o Property SearchIntensity(    ) As
                | 
                | Returns and sets the value for 'Search Intensity' in a
                | collision free walk. Refer DNBIAHumanSimDefs for setting the
                | HTSSearchIntensity option Role: Returns and sets the value
                | of 'Search Intensity' from a collision free walk Activity
                | Returns: Legal values: S_OK : on Success E_FAIL: on failure
                |

        :return:
        """
        return self.collision_free_walk.SearchIntensity

    @search_intensity.setter
    def search_intensity(self, value):
        """
            :param type value:
        """
        self.collision_free_walk.SearchIntensity = value 

    def __repr__(self):
        return f'CollisionFreeWalk()'
