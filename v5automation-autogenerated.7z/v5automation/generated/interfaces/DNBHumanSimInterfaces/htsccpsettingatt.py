#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HtsCCPSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.hts_ccp_setting_att = com_object     

    @property
    def automatized_ccp(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutomatizedCCP
                | o Property AutomatizedCCP(    ) As
                | 
                | Returns or sets the AutoCCP parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.
                |

        :return:
        """
        return self.hts_ccp_setting_att.AutomatizedCCP

    @automatized_ccp.setter
    def automatized_ccp(self, value):
        """
            :param type value:
        """
        self.hts_ccp_setting_att.AutomatizedCCP = value 

    @property
    def compass_pos(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CompassPos
                | o Property CompassPos(    ) As
                | 
                | Returns or sets the CompassPos parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.
                |

        :return:
        """
        return self.hts_ccp_setting_att.CompassPos

    @compass_pos.setter
    def compass_pos(self, value):
        """
            :param type value:
        """
        self.hts_ccp_setting_att.CompassPos = value 

    @property
    def current_pos(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentPos
                | o Property CurrentPos(    ) As
                | 
                | Returns or sets the CurrentPos parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.
                |

        :return:
        """
        return self.hts_ccp_setting_att.CurrentPos

    @current_pos.setter
    def current_pos(self, value):
        """
            :param type value:
        """
        self.hts_ccp_setting_att.CurrentPos = value 

    @property
    def first_act(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstAct
                | o Property FirstAct(    ) As
                | 
                | Returns or sets the FirstAct parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.
                |

        :return:
        """
        return self.hts_ccp_setting_att.FirstAct

    @first_act.setter
    def first_act(self, value):
        """
            :param type value:
        """
        self.hts_ccp_setting_att.FirstAct = value 

    @property
    def last_act(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LastAct
                | o Property LastAct(    ) As
                | 
                | Returns or sets the LastAct parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.
                |

        :return:
        """
        return self.hts_ccp_setting_att.LastAct

    @last_act.setter
    def last_act(self, value):
        """
            :param type value:
        """
        self.hts_ccp_setting_att.LastAct = value 

    def get_auto_ccp_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoCCPInfo
                | o Func GetAutoCCPInfo(        ioAdminLevel,
                |                               ioLocked) As
                | 
                | Retrieves environment informations for the AutoCCP
                | parameter. Role:Retrieves the state of the AutoCCP parameter
                | in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_ccp_setting_att.GetAutoCCPInfo(io_admin_level, io_locked)

    def get_compass_pos_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCompassPosInfo
                | o Func GetCompassPosInfo(        ioAdminLevel,
                |                                  ioLocked) As
                | 
                | Retrieves environment informations for the CompassPos
                | parameter. Role:Retrieves the state of the CompassPos
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_ccp_setting_att.GetCompassPosInfo(io_admin_level, io_locked)

    def get_current_pos_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCurrentPosInfo
                | o Func GetCurrentPosInfo(        ioAdminLevel,
                |                                  ioLocked) As
                | 
                | Retrieves environment informations for the CurrentPos
                | parameter. Role:Retrieves the state of the CurrentPos
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_ccp_setting_att.GetCurrentPosInfo(io_admin_level, io_locked)

    def get_first_act_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFirstActInfo
                | o Func GetFirstActInfo(        ioAdminLevel,
                |                                ioLocked) As
                | 
                | Retrieves environment informations for the FirstAct
                | parameter. Role:Retrieves the state of the FirstAct
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_ccp_setting_att.GetFirstActInfo(io_admin_level, io_locked)

    def get_last_act_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLastActInfo
                | o Func GetLastActInfo(        ioAdminLevel,
                |                               ioLocked) As
                | 
                | Retrieves environment informations for the LastAct
                | parameter. Role:Retrieves the state of the LastAct parameter
                | in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_ccp_setting_att.GetLastActInfo(io_admin_level, io_locked)

    def set_auto_ccp_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoCCPLock
                | o Sub SetAutoCCPLock(        iLocked)
                | 
                | Locks or unlocks the AutoCCP parameter. Role:Locks or
                | unlocks the AutoCCP parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |     the locking operation to be performed
                |     Legal values:
                |        TRUE :   to lock the parameter.
                |        FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_ccp_setting_att.SetAutoCCPLock(i_locked)

    def set_compass_pos_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCompassPosLock
                | o Sub SetCompassPosLock(        iLocked)
                | 
                | Locks or unlocks the CompassPos parameter. Role:Locks or
                | unlocks the CompassPos parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_ccp_setting_att.SetCompassPosLock(i_locked)

    def set_current_pos_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCurrentPosLock
                | o Sub SetCurrentPosLock(        iLocked)
                | 
                | Locks or unlocks the CurrentPos parameter. Role:Locks or
                | unlocks the CurrentPos parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_ccp_setting_att.SetCurrentPosLock(i_locked)

    def set_first_act_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFirstActLock
                | o Sub SetFirstActLock(        iLocked)
                | 
                | Locks or unlocks the FirstAct parameter. Role:Locks or
                | unlocks the FirstAct parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_ccp_setting_att.SetFirstActLock(i_locked)

    def set_last_act_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLastActLock
                | o Sub SetLastActLock(        iLocked)
                | 
                | Locks or unlocks the LastAct parameter. Role:Locks or
                | unlocks the LastAct parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_ccp_setting_att.SetLastActLock(i_locked)

    def __repr__(self):
        return f'HtsCCPSettingAtt()'
