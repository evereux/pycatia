#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PickActivity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The object that represents an PickActivity.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.pick_activity = com_object     

    @property
    def pick_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PickType
                | o Property PickType(    ) As
                | 
                | Returns or SetsPick Type (see for list of possible values)
                | SINGLE_HAND for Single-Handed Pick, BOTH_HANDS for Double-
                | Handed Pick
                |

        :return:
        """
        return self.pick_activity.PickType

    @property
    def picking_hand(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PickingHand
                | o Property PickingHand(    ) As
                | 
                | Returns or Sets "Picking Hand" (see for list of possible
                | values )
                |

        :return:
        """
        return self.pick_activity.PickingHand

    def add_picked_mfg_assembly(self, p_picked_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPickedMfgAssembly
                | o Sub AddPickedMfgAssembly(        pPickedItem)
                | 
                | Adds a Manufacturing Assembly to the List of Picked Items
                | (see for list of possible values)
                |
                | Parameters:

                |
        :param p_picked_item:
        :return:
        """
        return self.pick_activity.AddPickedMfgAssembly(p_picked_item)

    def add_picked_product(self, p_picked_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPickedProduct
                | o Sub AddPickedProduct(        pPickedItem)
                | 
                | Adds a product to the List of Picked Items
                |
                | Parameters:

                |
        :param p_picked_item:
        :return:
        """
        return self.pick_activity.AddPickedProduct(p_picked_item)

    def get_picked_products(self, p_picked_prods):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPickedProducts
                | o Sub GetPickedProducts(        pPickedProds)
                | 
                | Returns or Sets Picked Products
                |
                | Parameters:

                |
        :param p_picked_prods:
        :return:
        """
        return self.pick_activity.GetPickedProducts(p_picked_prods)

    def remove_picked_mfg_assembly(self, p_picked_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePickedMfgAssembly
                | o Sub RemovePickedMfgAssembly(        pPickedItem)
                | 
                | Removes a Manufacturing Assembly from the list of Picked
                | items (see for list of possible values)
                |
                | Parameters:

                |
        :param p_picked_item:
        :return:
        """
        return self.pick_activity.RemovePickedMfgAssembly(p_picked_item)

    def remove_picked_product(self, p_picked_item):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemovePickedProduct
                | o Sub RemovePickedProduct(        pPickedItem)
                | 
                | Removes a product from the list of Picked items (see for
                | list of possible values)
                |
                | Parameters:

                |
        :param p_picked_item:
        :return:
        """
        return self.pick_activity.RemovePickedProduct(p_picked_item)

    def set_picked_products(self, p_picked_prods):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPickedProducts
                | o Sub SetPickedProducts(        pPickedProds)
                | 
                |
                | Parameters:

                |
        :param p_picked_prods:
        :return:
        """
        return self.pick_activity.SetPickedProducts(p_picked_prods)

    def set_place_act(self, place_act):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPlaceAct
                | o Sub SetPlaceAct(        placeAct)
                | 
                | Sets or append a link to a Place activity (see for list of
                | possible values)
                |
                | Parameters:

                |
        :param place_act:
        :return:
        """
        return self.pick_activity.SetPlaceAct(place_act)

    def __repr__(self):
        return f'PickActivity()'
