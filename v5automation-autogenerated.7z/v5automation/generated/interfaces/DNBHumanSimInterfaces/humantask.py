#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HumanTask(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.human_task = com_object     

    @property
    def specified_cycle_time(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpecifiedCycleTime
                | o Property SpecifiedCycleTime(    ) As   (Read Only)
                | 
                | returns the time set by the user by set_SpecifiedCycleTime
                |

        :return:
        """
        return self.human_task.SpecifiedCycleTime

    @property
    def specified_joint_speed(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpecifiedJointSpeed
                | o Property SpecifiedJointSpeed(    ) As   (Read Only)
                | 
                | returns the speed set by the user by set_SpecifiedJointSpeed
                |

        :return:
        """
        return self.human_task.SpecifiedJointSpeed

    @property
    def worker_resource(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WorkerResource
                | o Property WorkerResource(    ) As   (Read Only)
                | 
                | Returns the Worker-Resource associated with this worker-
                | activity. Returns: oManikin
                |

        :return:
        """
        return self.human_task.WorkerResource

    def set__specified_cycle_time(self, time, i_override_child_act_simulation_time):
        """
        .. note::
            CAA V5 Visual Basic help

                | set_SpecifiedCycleTime
                | o Sub set_SpecifiedCycleTime(        time,
                |                                      iOverrideChildActSimulationTime)
                | 
                | sets the time on the specified task
                | iOverrideChildActSimulationTime: this should be set equal to
                | zero when no child act overriding is required
                |
                | Parameters:

                |
        :param time:
        :param i_override_child_act_simulation_time:
        :return:
        """
        return self.human_task.set_SpecifiedCycleTime(time, i_override_child_act_simulation_time)

    def set__specified_joint_speed(self, speed, i_override_child_joint_speed):
        """
        .. note::
            CAA V5 Visual Basic help

                | set_SpecifiedJointSpeed
                | o Sub set_SpecifiedJointSpeed(        speed,
                |                                       iOverrideChildJointSpeed)
                | 
                | sets the joint speed on the specified task(speed should be
                | between 0.0 to 1.0) iOverrideChildJointSpeed: this should be
                | set equal to zero when no child act overriding is required
                |
                | Parameters:

                |
        :param speed:
        :param i_override_child_joint_speed:
        :return:
        """
        return self.human_task.set_SpecifiedJointSpeed(speed, i_override_child_joint_speed)

    def __repr__(self):
        return f'HumanTask()'
