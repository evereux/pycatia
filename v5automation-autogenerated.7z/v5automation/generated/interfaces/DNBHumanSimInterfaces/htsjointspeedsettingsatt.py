#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HtsJointSpeedSettingsAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | DNBIAHtsJointSpeedSettingAtt are ...Do not use the
                | DNBIAHtsJointSpeedSettingAtt interface for such and such
                | ClassReference, Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.hts_joint_speed_settings_att = com_object     

    @property
    def all_joints_speed(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AllJointsSpeed
                | o Property AllJointsSpeed(    ) As
                | 
                | Returns or sets the JointSpeed parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.
                |

        :return:
        """
        return self.hts_joint_speed_settings_att.AllJointsSpeed

    @all_joints_speed.setter
    def all_joints_speed(self, value):
        """
            :param type value:
        """
        self.hts_joint_speed_settings_att.AllJointsSpeed = value 

    @property
    def rating(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Rating
                | o Property Rating(    ) As
                | 
                | Returns or sets the Rating parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.
                |

        :return:
        """
        return self.hts_joint_speed_settings_att.Rating

    @rating.setter
    def rating(self, value):
        """
            :param type value:
        """
        self.hts_joint_speed_settings_att.Rating = value 

    def get_all_joints_speed_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAllJointsSpeedInfo
                | o Func GetAllJointsSpeedInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the JointSpeed
                | parameter. Role:Retrieves the state of the JointSpeed
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_joint_speed_settings_att.GetAllJointsSpeedInfo(io_admin_level, io_locked)

    def get_rating_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRatingInfo
                | o Func GetRatingInfo(        ioAdminLevel,
                |                              ioLocked) As
                | 
                | Retrieves environment informations for the Rating parameter.
                | Role:Retrieves the state of the Rating parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_joint_speed_settings_att.GetRatingInfo(io_admin_level, io_locked)

    def set_all_joints_speed_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAllJointsSpeedLock
                | o Sub SetAllJointsSpeedLock(        iLocked)
                | 
                | Locks or unlocks the JointSpeed parameter. Role:Locks or
                | unlocks the JointSpeed parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_joint_speed_settings_att.SetAllJointsSpeedLock(i_locked)

    def set_rating_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRatingLock
                | o Sub SetRatingLock(        iLocked)
                | 
                | Locks or unlocks the Rating parameter. Role:Locks or unlocks
                | the Rating parameter if it is possible in the current
                | administrative context. In user mode this method will always
                | return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_joint_speed_settings_att.SetRatingLock(i_locked)

    def __repr__(self):
        return f'HtsJointSpeedSettingsAtt()'
