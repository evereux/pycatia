#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HTSSwingOptions(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Swing Options used in specifying swing options
                | foractivateLinkAnchor('WalkActivity','','WalkActivity')activity

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.hts_swing_options = com_object     

    def __repr__(self):
        return f'HTSSwingOptions()'
