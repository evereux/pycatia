#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HtsGeneralSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.hts_general_setting_att = com_object     

    @property
    def coll_walk_clearance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CollWalkClearance
                | o Property CollWalkClearance(    ) As
                | 
                |

        :return:
        """
        return self.hts_general_setting_att.CollWalkClearance

    @property
    def collision_search_intensity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CollisionSearchIntensity
                | o Property CollisionSearchIntensity(    ) As
                | 
                |

        :return:
        """
        return self.hts_general_setting_att.CollisionSearchIntensity

    @property
    def constraints_simul(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConstraintsSimul
                | o Property ConstraintsSimul(    ) As
                | 
                | Returns or sets the ConstraintsSimul parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_general_setting_att.ConstraintsSimul

    @constraints_simul.setter
    def constraints_simul(self, value):
        """
            :param type value:
        """
        self.hts_general_setting_att.ConstraintsSimul = value 

    @property
    def default_walk_speed(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultWalkSpeed
                | o Property DefaultWalkSpeed(    ) As
                | 
                | Returns or sets the DefaultWalkSpeed parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_general_setting_att.DefaultWalkSpeed

    @default_walk_speed.setter
    def default_walk_speed(self, value):
        """
            :param type value:
        """
        self.hts_general_setting_att.DefaultWalkSpeed = value 

    @property
    def side_step_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SideStepAngle
                | o Property SideStepAngle(    ) As
                | 
                | Returns or sets the SideStepAngle parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_general_setting_att.SideStepAngle

    @side_step_angle.setter
    def side_step_angle(self, value):
        """
            :param type value:
        """
        self.hts_general_setting_att.SideStepAngle = value 

    @property
    def sync_time_and_speed_in_simulation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SyncTimeAndSpeedInSimulation
                | o Property SyncTimeAndSpeedInSimulation(    ) As
                | 
                | Returns or sets the SyncTimeAndSpeed parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_general_setting_att.SyncTimeAndSpeedInSimulation

    @sync_time_and_speed_in_simulation.setter
    def sync_time_and_speed_in_simulation(self, value):
        """
            :param type value:
        """
        self.hts_general_setting_att.SyncTimeAndSpeedInSimulation = value 

    @property
    def update_analysis_in_simulation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpdateAnalysisInSimulation
                | o Property UpdateAnalysisInSimulation(    ) As
                | 
                | Returns or sets the UpdateAnalysisInSimulation parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.hts_general_setting_att.UpdateAnalysisInSimulation

    @update_analysis_in_simulation.setter
    def update_analysis_in_simulation(self, value):
        """
            :param type value:
        """
        self.hts_general_setting_att.UpdateAnalysisInSimulation = value 

    @property
    def user_walk_speed_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UserWalkSpeedStatus
                | o Property UserWalkSpeedStatus(    ) As
                | 
                | Returns or sets the UserWalkSpeedStatus parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_general_setting_att.UserWalkSpeedStatus

    @user_walk_speed_status.setter
    def user_walk_speed_status(self, value):
        """
            :param type value:
        """
        self.hts_general_setting_att.UserWalkSpeedStatus = value 

    @property
    def walk_forward_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WalkForwardAngle
                | o Property WalkForwardAngle(    ) As
                | 
                | Returns or sets the WalkForwardAngle parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_general_setting_att.WalkForwardAngle

    @walk_forward_angle.setter
    def walk_forward_angle(self, value):
        """
            :param type value:
        """
        self.hts_general_setting_att.WalkForwardAngle = value 

    @property
    def walk_forward_distance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WalkForwardDistance
                | o Property WalkForwardDistance(    ) As
                | 
                | Returns or sets the WalkForwardDistance parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.hts_general_setting_att.WalkForwardDistance

    @walk_forward_distance.setter
    def walk_forward_distance(self, value):
        """
            :param type value:
        """
        self.hts_general_setting_att.WalkForwardDistance = value 

    def get_coll_walk_clearance_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCollWalkClearanceInfo
                | o Func GetCollWalkClearanceInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetCollWalkClearanceInfo(io_admin_level, io_locked)

    def get_collision_search_intensity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCollisionSearchIntensityInfo
                | o Func GetCollisionSearchIntensityInfo(        ioAdminLevel,
                |                                                ioLocked) As
                | 
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetCollisionSearchIntensityInfo(io_admin_level, io_locked)

    def get_constraints_simul_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetConstraintsSimulInfo
                | o Func GetConstraintsSimulInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the ConstraintsSimul
                | parameter. Role:Retrieves the state of the ConstraintsSimul
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetConstraintsSimulInfo(io_admin_level, io_locked)

    def get_default_walk_speed_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDefaultWalkSpeedInfo
                | o Func GetDefaultWalkSpeedInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the DefaultWalkSpeed
                | parameter. Role:Retrieves the state of the DefaultWalkSpeed
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetDefaultWalkSpeedInfo(io_admin_level, io_locked)

    def get_side_step_angle_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSideStepAngleInfo
                | o Func GetSideStepAngleInfo(        ioAdminLevel,
                |                                     ioLocked) As
                | 
                | Retrieves environment informations for the SideStepAngle
                | parameter. Role:Retrieves the state of the SideStepAngle
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetSideStepAngleInfo(io_admin_level, io_locked)

    def get_sync_time_and_speed_in_simulation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSyncTimeAndSpeedInSimulationInfo
                | o Func GetSyncTimeAndSpeedInSimulationInfo(        ioAdminLevel,
                |                                                    ioLocked) As
                | 
                | Retrieves environment informations for the SyncTimeAndSpeed
                | parameter. Role:Retrieves the state of the SyncTimeAndSpeed
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetSyncTimeAndSpeedInSimulationInfo(io_admin_level, io_locked)

    def get_update_analysis_in_simulation_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUpdateAnalysisInSimulationInfo
                | o Func GetUpdateAnalysisInSimulationInfo(        ioAdminLevel,
                |                                                  ioLocked) As
                | 
                | Retrieves environment informations for the
                | UpdateAnalysisInSimulation parameter. Role:Retrieves the
                | state of the UpdateAnalysisInSimulation parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetUpdateAnalysisInSimulationInfo(io_admin_level, io_locked)

    def get_user_walk_speed_status_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUserWalkSpeedStatusInfo
                | o Func GetUserWalkSpeedStatusInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves environment informations for the
                | UserWalkSpeedStatus parameter. Role:Retrieves the state of
                | the UserWalkSpeedStatus parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetUserWalkSpeedStatusInfo(io_admin_level, io_locked)

    def get_walk_forward_angle_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetWalkForwardAngleInfo
                | o Func GetWalkForwardAngleInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the WalkForwardAngle
                | parameter. Role:Retrieves the state of the WalkForwardAngle
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetWalkForwardAngleInfo(io_admin_level, io_locked)

    def get_walk_forward_distance_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetWalkForwardDistanceInfo
                | o Func GetWalkForwardDistanceInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves environment informations for the
                | WalkForwardDistance parameter. Role:Retrieves the state of
                | the WalkForwardDistance parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.hts_general_setting_att.GetWalkForwardDistanceInfo(io_admin_level, io_locked)

    def set_coll_walk_clearance_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCollWalkClearanceLock
                | o Sub SetCollWalkClearanceLock(        iLocked)
                | 
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetCollWalkClearanceLock(i_locked)

    def set_collision_search_intensity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCollisionSearchIntensityLock
                | o Sub SetCollisionSearchIntensityLock(        iLocked)
                | 
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetCollisionSearchIntensityLock(i_locked)

    def set_constraints_simul_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetConstraintsSimulLock
                | o Sub SetConstraintsSimulLock(        iLocked)
                | 
                | Locks or unlocks the ConstraintsSimul parameter. Role:Locks
                | or unlocks the ConstraintsSimul parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetConstraintsSimulLock(i_locked)

    def set_default_walk_speed_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDefaultWalkSpeedLock
                | o Sub SetDefaultWalkSpeedLock(        iLocked)
                | 
                | Locks or unlocks the DefaultWalkSpeed parameter. Role:Locks
                | or unlocks the DefaultWalkSpeed parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetDefaultWalkSpeedLock(i_locked)

    def set_side_step_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSideStepAngleLock
                | o Sub SetSideStepAngleLock(        iLocked)
                | 
                | Locks or unlocks the SideStepAngle parameter. Role:Locks or
                | unlocks the SideStepAngle parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetSideStepAngleLock(i_locked)

    def set_sync_time_and_speed_in_simulation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSyncTimeAndSpeedInSimulationLock
                | o Sub SetSyncTimeAndSpeedInSimulationLock(        iLocked)
                | 
                | Locks or unlocks the SyncTimeAndSpeed parameter. Role:Locks
                | or unlocks the SyncTimeAndSpeed parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetSyncTimeAndSpeedInSimulationLock(i_locked)

    def set_update_analysis_in_simulation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUpdateAnalysisInSimulationLock
                | o Sub SetUpdateAnalysisInSimulationLock(        iLocked)
                | 
                | Locks or unlocks the UpdateAnalysisInSimulation parameter.
                | Role:Locks or unlocks the UpdateAnalysisInSimulation
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetUpdateAnalysisInSimulationLock(i_locked)

    def set_user_walk_speed_status_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUserWalkSpeedStatusLock
                | o Sub SetUserWalkSpeedStatusLock(        iLocked)
                | 
                | Locks or unlocks the UserWalkSpeedStatus parameter.
                | Role:Locks or unlocks the UserWalkSpeedStatus parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetUserWalkSpeedStatusLock(i_locked)

    def set_walk_forward_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetWalkForwardAngleLock
                | o Sub SetWalkForwardAngleLock(        iLocked)
                | 
                | Locks or unlocks the WalkForwardAngle parameter. Role:Locks
                | or unlocks the WalkForwardAngle parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetWalkForwardAngleLock(i_locked)

    def set_walk_forward_distance_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetWalkForwardDistanceLock
                | o Sub SetWalkForwardDistanceLock(        iLocked)
                | 
                | Locks or unlocks the WalkForwardDistance parameter.
                | Role:Locks or unlocks the WalkForwardDistance parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.hts_general_setting_att.SetWalkForwardDistanceLock(i_locked)

    def __repr__(self):
        return f'HtsGeneralSettingAtt()'
