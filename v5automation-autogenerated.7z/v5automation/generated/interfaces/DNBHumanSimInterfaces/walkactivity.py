#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class WalkActivity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.walk_activity = com_object     

    @property
    def body_pose(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BodyPose
                | o Property BodyPose(    ) As
                | 
                | Returns or Sets Body Posture option (see for list of
                | possible values)
                |

        :return:
        """
        return self.walk_activity.BodyPose

    @property
    def motion_basis(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MotionBasis
                | o Property MotionBasis(    ) As
                | 
                | Returns or Sets Motion-Basis (see for list of possible
                | values)
                |

        :return:
        """
        return self.walk_activity.MotionBasis

    @property
    def stride(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Stride
                | o Property Stride(    ) As
                | 
                | Returns or Sets Stride option (see for list of possible
                | values)
                |

        :return:
        """
        return self.walk_activity.Stride

    @property
    def swing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Swing
                | o Property Swing(    ) As
                | 
                | Returns or Sets Swing option (see for list of possible
                | values)
                |

        :return:
        """
        return self.walk_activity.Swing

    @property
    def user_speed(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UserSpeed
                | o Property UserSpeed(    ) As
                | 
                | Returns or Sets Speed for Walk Activity
                |

        :return:
        """
        return self.walk_activity.UserSpeed

    @property
    def user_time(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UserTime
                | o Property UserTime(    ) As
                | 
                | Returns or Sets Time for Walk Activity
                |

        :return:
        """
        return self.walk_activity.UserTime

    @property
    def walk_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WalkLength
                | o Property WalkLength(    ) As   (Read Only)
                | 
                | Returns WalkLength for Walk Activity
                |

        :return:
        """
        return self.walk_activity.WalkLength

    def get_walk_curve_def_points(self, i_num_points, ad_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetWalkCurveDefPoints
                | o Sub GetWalkCurveDefPoints(        iNumPoints,
                |                                     adPoints)
                | 
                | This gets the Walk Path definition Point
                |
                | Parameters:
                | iNumPoints
                |     Number of Coplanar-Points defining the Walk Path in Plane
                |  
                |  adPoints
                |     Point values   x1,y1,z1 , x2,y2,z2, .... Area of Plane coordinates
                |     User needs to pass in sufficiently large-sized array

                |
        :param i_num_points:
        :param ad_points:
        :return:
        """
        return self.walk_activity.GetWalkCurveDefPoints(i_num_points, ad_points)

    def has_part_relation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasPartRelation
                | o Func HasPartRelation(    ) As
                | 
                | Returns if there is any PartRelation Returns: bFlag TRUE, if
                | there exist any Part-Relation
                |
                | Parameters:

                |
        :return:
        """
        return self.walk_activity.HasPartRelation()

    def set_walk_curve_def_points(self, i_num_points, ad_points):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetWalkCurveDefPoints
                | o Sub SetWalkCurveDefPoints(        iNumPoints,
                |                                     adPoints)
                | 
                | This sets the Walk Path definition Point
                |
                | Parameters:
                | iNumPoints
                |     Number of Coplanar-Points defining the Walk Path in Plane
                |  
                |  adPoints
                |     Point values   x1,y1,z1 , x2,y2,z2, .... Area of Plane coordinates

                |
        :param i_num_points:
        :param ad_points:
        :return:
        """
        return self.walk_activity.SetWalkCurveDefPoints(i_num_points, ad_points)

    def update(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Update
                | o Sub Update(    )
                | 
                | This method is the key-method to create children-
                | MoveToPostures for a created Walk. This is must be called
                | after setting appropriate values for Walk Activity.
                |
                | Parameters:

                |
        :return:
        """
        return self.walk_activity.Update()

    def __repr__(self):
        return f'WalkActivity()'
