#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class HumanCallTask(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | DNBIAHumanCallTaskActivity are ...Do not use the
                | DNBIAHumanCallTaskActivity interface for such and such ClassReference,
                | Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.human_call_task = com_object     

    @property
    def called_task(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CalledTask
                | o Property CalledTask(    ) As   (Read Only)
                | 
                | Gets the Called Task
                |

        :return:
        """
        return self.human_call_task.CalledTask

    def set_called_task(self, i_target_task):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCalledTask
                | o Sub SetCalledTask(        iTargetTask)
                | 
                | Set the called task
                |
                | Parameters:
                | iTargetTask
                |  
                | 
                |  Returns:
                |        E_FAIL : If the Desired Task belongs to different Manikin or there is Cyclic

                |
        :param i_target_task:
        :return:
        """
        return self.human_call_task.SetCalledTask(i_target_task)

    def __repr__(self):
        return f'HumanCallTask()'
