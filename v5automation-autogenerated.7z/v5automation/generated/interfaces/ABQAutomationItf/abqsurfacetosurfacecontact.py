#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQSurfaceToSurfaceContact(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus contact pair (ABQSurfaceToSurfaceContact)
                | object.Role:Access an Abaqus contact pair object or determine its
                | properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_surface_to_surface_contact = com_object     

    @property
    def adjust_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AdjustMethod
                | o Property AdjustMethod(    ) As
                | 
                | Sets or returns the method type in a contact pair. Returns:
                | The method type. Legal values: OVERCLOSED TOLERANCE o
                | Property AdjustToleranceVal() As Sets or returns the
                | tolerance value of the contact pair. Returns: The tolerance
                | value of the contact pair. o Property ConnectionProperty()
                | As Sets or returns the connection property in a contact
                | pair. Returns: The connection property. o Property
                | FormulationOption() As Sets or returns the formulation
                | option in a contact pair. Returns: Formulation option type.
                | Legal values: SURFACETOSURFACE NODETOSURFACE o Property
                | InteractionProperty() As Sets or returns the interaction
                | property in a contact pair. Returns: The specified . o
                | Property InterferenceFit() As Assigns / gets interference
                | fit of a contact pair. This can be assigned to contact pairs
                | created in structual case except initialization step.
                | Returns: The interference magnitude for gradual interference
                | with uniform overclosure. returns 0 if no interference fit
                | is defined. Usage: Dim abqSurfCont As
                | ABQSurfaceToSurfaceContact Dim clearance As double Set
                | clearance = 2.5 abqSurfCont.InterferenceFit = clearance o
                | Property InterferenceFitAmplitude() As Assigns / gets
                | interference fit amplitude of a contact pair. Returns: The
                | interference fit amplitude for gradual interference with
                | uniform overclosure. returns NULL if no interference fit is
                | defined. returns E_FAIL if unable to find amplitude object.
                | Usage: Dim abqSurfCont As ABQSurfaceToSurfaceContact Dim
                | clearance As double Set clearance = 2.5
                | abqSurfCont.InterferenceFit = clearance Dim Amp As
                | ABQProperty ....(Get the amplitude property)
                | abqSurfCont.InterferenceFitAmplitude = Amp; o Property
                | Sliding() As Sets or returns the sliding type in a contact
                | pair. Returns: The sliding type. Legal values: FINITE SMALL
                | o Property SwapMasterSlave() As Returns the activation
                | status if the master surface is swapped as slave surface.
                | Returns: A boolean specifying whether the master surface
                | surface is swapped as slave. o Property
                | UseAutomaticGeometrySmoothing() As Returns a boolean
                | indicating whether automatic geometry smoothing is used for
                | the contact pair Returns: boolean specifying whether
                | automatic geometry smoothing is active. Legal values: TRUE
                | FALSE o Property UseInterferenceFitAmplitude() As (Read
                | Only) Returns a boolean indicating whether amplitude is used
                | in the interference fit for a contact pair Returns: boolean
                | specifying whether user defined amplitude is active. o
                | Property UseMasterNegativeSide() As Returns the activation
                | status if the master surface is specified as the negative
                | side. Returns: A boolean specifying whether the master
                | surface is specified as the negative side. o Property
                | UseSlaveNegativeSide() As Returns the activation status if
                | the slave surface is specified as the negative side.
                | Returns: A boolean specifying whether the slave surface is
                | specified as the negative side. Methods o Sub
                | AddSupportFromConstraint( iReference, iSupport) Creates a
                | new support and adds it to the description of the Analysis
                | Entity.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.AdjustMethod

    @property
    def adjust_tolerance_val(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AdjustToleranceVal
                | o Property AdjustToleranceVal(    ) As
                | 
                | Sets or returns the tolerance value of the contact pair.
                | Returns: The tolerance value of the contact pair.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.AdjustToleranceVal

    @property
    def connection_property(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectionProperty
                | o Property ConnectionProperty(    ) As
                | 
                | Sets or returns the connection property in a contact pair.
                | Returns: The connection property.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.ConnectionProperty

    @property
    def formulation_option(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FormulationOption
                | o Property FormulationOption(    ) As
                | 
                | Sets or returns the formulation option in a contact pair.
                | Returns: Formulation option type. Legal values:
                | SURFACETOSURFACE NODETOSURFACE o Property
                | InteractionProperty() As Sets or returns the interaction
                | property in a contact pair. Returns: The specified . o
                | Property InterferenceFit() As Assigns / gets interference
                | fit of a contact pair. This can be assigned to contact pairs
                | created in structual case except initialization step.
                | Returns: The interference magnitude for gradual interference
                | with uniform overclosure. returns 0 if no interference fit
                | is defined. Usage: Dim abqSurfCont As
                | ABQSurfaceToSurfaceContact Dim clearance As double Set
                | clearance = 2.5 abqSurfCont.InterferenceFit = clearance o
                | Property InterferenceFitAmplitude() As Assigns / gets
                | interference fit amplitude of a contact pair. Returns: The
                | interference fit amplitude for gradual interference with
                | uniform overclosure. returns NULL if no interference fit is
                | defined. returns E_FAIL if unable to find amplitude object.
                | Usage: Dim abqSurfCont As ABQSurfaceToSurfaceContact Dim
                | clearance As double Set clearance = 2.5
                | abqSurfCont.InterferenceFit = clearance Dim Amp As
                | ABQProperty ....(Get the amplitude property)
                | abqSurfCont.InterferenceFitAmplitude = Amp; o Property
                | Sliding() As Sets or returns the sliding type in a contact
                | pair. Returns: The sliding type. Legal values: FINITE SMALL
                | o Property SwapMasterSlave() As Returns the activation
                | status if the master surface is swapped as slave surface.
                | Returns: A boolean specifying whether the master surface
                | surface is swapped as slave. o Property
                | UseAutomaticGeometrySmoothing() As Returns a boolean
                | indicating whether automatic geometry smoothing is used for
                | the contact pair Returns: boolean specifying whether
                | automatic geometry smoothing is active. Legal values: TRUE
                | FALSE o Property UseInterferenceFitAmplitude() As (Read
                | Only) Returns a boolean indicating whether amplitude is used
                | in the interference fit for a contact pair Returns: boolean
                | specifying whether user defined amplitude is active. o
                | Property UseMasterNegativeSide() As Returns the activation
                | status if the master surface is specified as the negative
                | side. Returns: A boolean specifying whether the master
                | surface is specified as the negative side. o Property
                | UseSlaveNegativeSide() As Returns the activation status if
                | the slave surface is specified as the negative side.
                | Returns: A boolean specifying whether the slave surface is
                | specified as the negative side. Methods o Sub
                | AddSupportFromConstraint( iReference, iSupport) Creates a
                | new support and adds it to the description of the Analysis
                | Entity.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.FormulationOption

    @property
    def interaction_property(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InteractionProperty
                | o Property InteractionProperty(    ) As
                | 
                | Sets or returns the interaction property in a contact pair.
                | Returns: The specified .
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.InteractionProperty

    @property
    def interference_fit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InterferenceFit
                | o Property InterferenceFit(    ) As
                | 
                | Assigns / gets interference fit of a contact pair. This can
                | be assigned to contact pairs created in structual case
                | except initialization step. Returns: The interference
                | magnitude for gradual interference with uniform overclosure.
                | returns 0 if no interference fit is defined. Usage: Dim
                | abqSurfCont As ABQSurfaceToSurfaceContact Dim clearance As
                | double Set clearance = 2.5 abqSurfCont.InterferenceFit =
                | clearance
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.InterferenceFit

    @property
    def interference_fit_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InterferenceFitAmplitude
                | o Property InterferenceFitAmplitude(    ) As
                | 
                | Assigns / gets interference fit amplitude of a contact pair.
                | Returns: The interference fit amplitude for gradual
                | interference with uniform overclosure. returns NULL if no
                | interference fit is defined. returns E_FAIL if unable to
                | find amplitude object. Usage: Dim abqSurfCont As
                | ABQSurfaceToSurfaceContact Dim clearance As double Set
                | clearance = 2.5 abqSurfCont.InterferenceFit = clearance Dim
                | Amp As ABQProperty ....(Get the amplitude property)
                | abqSurfCont.InterferenceFitAmplitude = Amp;
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.InterferenceFitAmplitude

    @property
    def sliding(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Sliding
                | o Property Sliding(    ) As
                | 
                | Sets or returns the sliding type in a contact pair. Returns:
                | The sliding type. Legal values: FINITE SMALL o Property
                | SwapMasterSlave() As Returns the activation status if the
                | master surface is swapped as slave surface. Returns: A
                | boolean specifying whether the master surface surface is
                | swapped as slave. o Property UseAutomaticGeometrySmoothing()
                | As Returns a boolean indicating whether automatic geometry
                | smoothing is used for the contact pair Returns: boolean
                | specifying whether automatic geometry smoothing is active.
                | Legal values: TRUE FALSE o Property
                | UseInterferenceFitAmplitude() As (Read Only) Returns a
                | boolean indicating whether amplitude is used in the
                | interference fit for a contact pair Returns: boolean
                | specifying whether user defined amplitude is active. o
                | Property UseMasterNegativeSide() As Returns the activation
                | status if the master surface is specified as the negative
                | side. Returns: A boolean specifying whether the master
                | surface is specified as the negative side. o Property
                | UseSlaveNegativeSide() As Returns the activation status if
                | the slave surface is specified as the negative side.
                | Returns: A boolean specifying whether the slave surface is
                | specified as the negative side. Methods o Sub
                | AddSupportFromConstraint( iReference, iSupport) Creates a
                | new support and adds it to the description of the Analysis
                | Entity.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.Sliding

    @property
    def swap_master_slave(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SwapMasterSlave
                | o Property SwapMasterSlave(    ) As
                | 
                | Returns the activation status if the master surface is
                | swapped as slave surface. Returns: A boolean specifying
                | whether the master surface surface is swapped as slave.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.SwapMasterSlave

    @property
    def use_automatic_geometry_smoothing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseAutomaticGeometrySmoothing
                | o Property UseAutomaticGeometrySmoothing(    ) As
                | 
                | Returns a boolean indicating whether automatic geometry
                | smoothing is used for the contact pair Returns: boolean
                | specifying whether automatic geometry smoothing is active.
                | Legal values: TRUE FALSE o Property
                | UseInterferenceFitAmplitude() As (Read Only) Returns a
                | boolean indicating whether amplitude is used in the
                | interference fit for a contact pair Returns: boolean
                | specifying whether user defined amplitude is active. o
                | Property UseMasterNegativeSide() As Returns the activation
                | status if the master surface is specified as the negative
                | side. Returns: A boolean specifying whether the master
                | surface is specified as the negative side. o Property
                | UseSlaveNegativeSide() As Returns the activation status if
                | the slave surface is specified as the negative side.
                | Returns: A boolean specifying whether the slave surface is
                | specified as the negative side. Methods o Sub
                | AddSupportFromConstraint( iReference, iSupport) Creates a
                | new support and adds it to the description of the Analysis
                | Entity.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.UseAutomaticGeometrySmoothing

    @property
    def use_interference_fit_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseInterferenceFitAmplitude
                | o Property UseInterferenceFitAmplitude(    ) As   (Read Only)
                | 
                | Returns a boolean indicating whether amplitude is used in
                | the interference fit for a contact pair Returns: boolean
                | specifying whether user defined amplitude is active.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.UseInterferenceFitAmplitude

    @property
    def use_master_negative_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseMasterNegativeSide
                | o Property UseMasterNegativeSide(    ) As
                | 
                | Returns the activation status if the master surface is
                | specified as the negative side. Returns: A boolean
                | specifying whether the master surface is specified as the
                | negative side.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.UseMasterNegativeSide

    @property
    def use_slave_negative_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseSlaveNegativeSide
                | o Property UseSlaveNegativeSide(    ) As
                | 
                | Returns the activation status if the slave surface is
                | specified as the negative side. Returns: A boolean
                | specifying whether the slave surface is specified as the
                | negative side.
                |

        :return:
        """
        return self.abq_surface_to_surface_contact.UseSlaveNegativeSide

    def add_support_from_constraint(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromConstraint
                | o Sub AddSupportFromConstraint(        iReference,
                |                                        iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the contact is applied.
                | 
                |  iSupport
                |      The CATIA Constraint specifying the region to which the contact is applied.
                |  Refer: CATIAReference, CATIAProduct

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_surface_to_surface_contact.AddSupportFromConstraint(i_reference, i_support)

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iReference,
                |                                       iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iReference
                |      The CATIA Reference specifying the object to which the contact is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the contact is applied.
                |  Refer: CATIAReference

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_surface_to_surface_contact.AddSupportFromReference(i_reference, i_support)

    def remove_interference_fit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveInterferenceFit
                | o Sub RemoveInterferenceFit(    )
                | 
                | Removes interference fit from a contact pair feature.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_surface_to_surface_contact.RemoveInterferenceFit()

    def __repr__(self):
        return f'ABQSurfaceToSurfaceContact()'
