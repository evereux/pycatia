#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQTemperature(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus temperature object (ABQTemperature).Role:Access
                | an Abaqus temperature object or determine its properties. It has
                | common properties ofactivateLinkAnchor('ABQInitialTemperature','','ABQ
                | InitialTemperature'),activateLinkAnchor('ABQTemperatureHistory','','AB
                | QTemperatureHistory')

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_temperature = com_object     

    @property
    def apply_user_subroutine(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyUserSubroutine
                | o Property ApplyUserSubroutine(    ) As
                | 
                | Sets or returns the user subroutine flag. Returns: A boolean
                | specifying whether a user subroutine will be applied.
                |

        :return:
        """
        return self.abq_temperature.ApplyUserSubroutine

    @property
    def distribution(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Distribution
                | o Property Distribution(    ) As
                | 
                | Sets or returns the distribution type associated with this
                | temperature field. Legal values: UNIFORM JOB USERDEFINED
                | JOB_USERDEFINED Example: This example sets the distribution
                | type to USERDEFINED. Dim abqTemperature As ABQTemperature
                | abqTemperature.Distribution = USERDEFINED
                |

        :return:
        """
        return self.abq_temperature.Distribution

    @property
    def job(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Job
                | o Property Job(    ) As
                | 
                | Sets or returns the Abaqus job associated with this
                | temperature field. * The job being attached to the
                | temperature field must belong to a thermal case and must not
                | belong to same analysis case to which the temperature field
                | belongs. Example: This example retrieves the ABQJob abqJob.
                | Dim abqTemperature As ABQTemperature Dim abqJob As ABQJob
                | Set abqJob = abqTemperature.Job
                |

        :return:
        """
        return self.abq_temperature.Job

    @property
    def magnitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Magnitude
                | o Property Magnitude(    ) As
                | 
                | Sets or returns the magnitude of the temperature field.
                | Returns: The magnitude of the temperature field.
                |

        :return:
        """
        return self.abq_temperature.Magnitude

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the type of the Temperature. Returns: The type of
                | the Temperature.
                |

        :return:
        """
        return self.abq_temperature.Type

    def add_support_from_product(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromProduct
                | o Sub AddSupportFromProduct(        iProduct,
                |                                     iSupport)
                | 
                | This adds the support from a product to the Field.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the field is applied.
                | 
                |  iSupport
                |               The CATIA Reference specifying the region to which the field is applied.
                |  Refer: CATIAReference , CATIAProduct

                |
        :param i_product:
        :param i_support:
        :return:
        """
        return self.abq_temperature.AddSupportFromProduct(i_product, i_support)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the field is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the field is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_temperature.AddSupportFromPublication(i_product, i_publication)

    def __repr__(self):
        return f'ABQTemperature()'
