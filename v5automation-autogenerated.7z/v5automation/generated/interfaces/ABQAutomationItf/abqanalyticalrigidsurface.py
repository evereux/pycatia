#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQAnalyticalRigidSurface(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus Analytical rigid surface
                | (ABQAnalyticalRigidSurface) object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_analytical_rigid_surface = com_object     

    @property
    def flip_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlipSide
                | o Property FlipSide(    ) As
                | 
                | Sets or returns the flip state for the ARS.
                |

        :return:
        """
        return self.abq_analytical_rigid_surface.FlipSide

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Adds a support to the Analytical rigid surface. If the
                | support already exists, it is removed.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the rigid body constraint is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the rigid body constraint is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_analytical_rigid_surface.AddSupportFromPublication(i_product, i_publication)

    def add_support_from_reference(self, i_product, i_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iProduct,
                |                                       iRef)
                | 
                | Creates a new support for the Reference and adds it to the
                | description of the Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the positioning object.
                | 
                |  iSupport
                |               The CATIAReference specifying the object that is being pointed to.
                |  Refer: CATIAReference , CATIAProduct

                |
        :param i_product:
        :param i_ref:
        :return:
        """
        return self.abq_analytical_rigid_surface.AddSupportFromReference(i_product, i_ref)

    def set_handler(self, i_product, i_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandler
                | o Sub SetHandler(        iProduct,
                |                          iRef)
                | 
                | Set the handler for the Analytical rigid surface.
                |
                | Parameters:
                | iProduct
                |      The CATIAProduct specifying the positioning object.
                | 
                |  iRef
                |    The CATIAReference specifying the object that is being pointed to.

                |
        :param i_product:
        :param i_ref:
        :return:
        """
        return self.abq_analytical_rigid_surface.SetHandler(i_product, i_ref)

    def set_handler_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandlerFromPublication
                | o Sub SetHandlerFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Sets the handler for the Analytical rigid surface. Any
                | previously set handler will be replaced with the new value.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product for handeler.
                | 
                |  iPublication
                |               The CATIA Publication for handeler.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_analytical_rigid_surface.SetHandlerFromPublication(i_product, i_publication)

    def __repr__(self):
        return f'ABQAnalyticalRigidSurface()'
