#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQIAABQSteadyStateLinDynStepSubspaceVB(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | ABQIAABQSteadyStateLinDynStepSubspace are ...Do not use the
                | ABQIAABQSteadyStateLinDynStepSubspace interface for such and such
                | ClassReference, Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abqiaabq_steady_state_lin_dyn_step_subspace_vb = com_object     

    @property
    def max_damping_change(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxDampingChange
                | o Property MaxDampingChange(    ) As
                | 
                | Returns or sets Maximum Damping Change. Returns: The Maximum
                | Damping Change. Applicable only for Projection Type = As a
                | function of property changes.
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.MaxDampingChange

    @max_damping_change.setter
    def max_damping_change(self, value):
        """
            :param type value:
        """
        self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.MaxDampingChange = value 

    @property
    def max_stiffness_change(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxStiffnessChange
                | o Property MaxStiffnessChange(    ) As
                | 
                | Returns or sets Maximum Stiffness Change. Returns: The
                | Maximum Stiffness Change. Applicable only for Projection
                | Type = As a function of property changes.
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.MaxStiffnessChange

    @max_stiffness_change.setter
    def max_stiffness_change(self, value):
        """
            :param type value:
        """
        self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.MaxStiffnessChange = value 

    @property
    def subspace_friction_damping(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SubspaceFrictionDamping
                | o Property SubspaceFrictionDamping(    ) As
                | 
                | Sets or returns if the Subspace Responase. Returns: A
                | boolean specifying whether the Subspace Responase is ued.
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.SubspaceFrictionDamping

    @property
    def subspace_projection_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SubspaceProjectionType
                | o Property SubspaceProjectionType(    ) As
                | 
                | Returns or sets Subspace Projection Type. Returns: The
                | Subspace Projection Type. Legal values: 1 - Evaluate at each
                | frequency. 2 - Constant. 3 - Interpolate at eigen frequency.
                | 4 - As a function of property changes. 5 - Interpolate at
                | upper and lower frequency limits. Example: This example sets
                | the Subspace Projection Type as Evaluate at each frequency
                | for abqSSDStep abqSSDStep.SubspaceProjectionType = 1
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.SubspaceProjectionType

    @subspace_projection_type.setter
    def subspace_projection_type(self, value):
        """
            :param type value:
        """
        self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.SubspaceProjectionType = value 

    @property
    def subspace_responase(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SubspaceResponase
                | o Property SubspaceResponase(    ) As
                | 
                | Returns or sets Subspace Responase. Returns: The Subspace
                | Responase. Legal values: 1 - Real. 2 - Complex. Example:
                | This example sets the Subspace Responase as Real for
                | abqSSDStep abqSSDStep.SubspaceResponase = 1
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.SubspaceResponase

    @subspace_responase.setter
    def subspace_responase(self, value):
        """
            :param type value:
        """
        self.abqiaabq_steady_state_lin_dyn_step_subspace_vb.SubspaceResponase = value 

    def __repr__(self):
        return f'ABQIAABQSteadyStateLinDynStepSubspaceVB()'
