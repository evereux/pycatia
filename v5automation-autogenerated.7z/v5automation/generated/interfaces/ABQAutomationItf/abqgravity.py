#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQGravity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus gravity (ABQGravity) object.Role:Access an Abaqus
                | gravity load object or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_gravity = com_object     

    @property
    def uselocal_csys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UselocalCsys
                | o Property UselocalCsys(    ) As
                | 
                | Sets or returns a boolean indicating whether local
                | coordinate system is used in Gravity load. Returns: boolean
                | specifying whether local csys is active.
                |

        :return:
        """
        return self.abq_gravity.UselocalCsys

    @property
    def comp1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | comp1
                | o Property comp1(    ) As
                | 
                | Sets or returns the gravity component in the 1-direction.
                | Returns: The gravity component in the 1-direction.
                |

        :return:
        """
        return self.abq_gravity.comp1

    @property
    def comp2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | comp2
                | o Property comp2(    ) As
                | 
                | Sets or returns the gravity component in the 2-direction.
                | Returns: The gravity component in the 2-direction.
                |

        :return:
        """
        return self.abq_gravity.comp2

    @property
    def comp3(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | comp3
                | o Property comp3(    ) As
                | 
                | Sets or returns the gravity component in the 3-direction.
                | Returns: The gravity component in the 3-direction.
                |

        :return:
        """
        return self.abq_gravity.comp3

    @property
    def local_csys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | localCsys
                | o Property localCsys(    ) As
                | 
                | Sets or returns the local coordinate system of the gravity
                | load. Returns: The local coordinate system.
                |

        :return:
        """
        return self.abq_gravity.localCsys

    def get_local_csys_from_publication(self, o_product, o_pub_axis_system):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLocalCsysFromPublication
                | o Sub GetLocalCsysFromPublication(        oProduct,
                |                                           oPubAxisSystem)
                | 
                | Gets the published local coordinate system of the gravity
                | load.
                |
                | Parameters:
                | oProduct
                |      The CATIA Product specifying the local coordinate system publication.
                | 
                |  oPubAxisSystem
                |               The CATIA Axis system.
                |  Refer: CATIAAxisSystem

                |
        :param o_product:
        :param o_pub_axis_system:
        :return:
        """
        return self.abq_gravity.GetLocalCsysFromPublication(o_product, o_pub_axis_system)

    def set_local_csys_from_publication(self, i_product, i_pub_axis_system):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLocalCsysFromPublication
                | o Sub SetLocalCsysFromPublication(        iProduct,
                |                                           iPubAxisSystem)
                | 
                | Sets the published local coordinate system of the gravity
                | load. Returns: Fails if the publication is not an axis
                | system.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the local coordinate system publication.
                | 
                |  iPublication
                |               The CATIA Publication on the axis system.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_pub_axis_system:
        :return:
        """
        return self.abq_gravity.SetLocalCsysFromPublication(i_product, i_pub_axis_system)

    def __repr__(self):
        return f'ABQGravity()'
