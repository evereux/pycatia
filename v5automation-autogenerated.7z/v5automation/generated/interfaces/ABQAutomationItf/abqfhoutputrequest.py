#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQFHOutputRequest(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the base interface for field and history output request
                | objects.Role:The ABQFHOutputRequest interface manages the common
                | properties of field and history output requests.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abqfh_output_request = com_object     

    @property
    def equally_spaced_incr(self, i_at_equally_spaced_incr):
        """
        .. note::
            CAA V5 Visual Basic help

                | EquallySpacedIncr
                | o Property EquallySpacedIncr(        iAtEquallySpacedIncr) (Write Only)
                | 
                | For explicit dynamic step: Sets request for output results
                | at equally spaced increments.
                |

        :param i_at_equally_spaced_incr:
        :return:
        """
        return self.abqfh_output_request.EquallySpacedIncr

    @property
    def every_x_incr_of_time(self, i_at_every_x_incr):
        """
        .. note::
            CAA V5 Visual Basic help

                | EveryXIncrOfTime
                | o Property EveryXIncrOfTime(        iAtEveryXIncr) (Write Only)
                | 
                | For explicit dynamic step: Sets request for output results
                | at every specified units of time.
                |

        :param i_at_every_x_incr:
        :return:
        """
        return self.abqfh_output_request.EveryXIncrOfTime

    @property
    def output_at_def_or_all_sec_pts(self, i_output_at_sec_pts):
        """
        .. note::
            CAA V5 Visual Basic help

                | OutputAtDefOrAllSecPts
                | o Property OutputAtDefOrAllSecPts(        iOutputAtSecPts) (Write Only)
                | 
                | Sets request for output results at section points.
                |

        :param i_output_at_sec_pts:
        :return:
        """
        return self.abqfh_output_request.OutputAtDefOrAllSecPts

    @property
    def pre_select_default_or_all(self, i_output_var_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | PreSelectDefaultOrAll
                | o Property PreSelectDefaultOrAll(        iOutputVarType) (Write Only)
                | 
                | Sets request for results for preselect default or ALL
                | variables.
                |

        :param i_output_var_type:
        :return:
        """
        return self.abqfh_output_request.PreSelectDefaultOrAll

    @property
    def specified_modes(self, i_specified_modes):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpecifiedModes
                | o Property SpecifiedModes(        iSpecifiedModes) (Write Only)
                | 
                | For frequency step: Sets request for output results at
                | specified modes.
                |

        :param i_specified_modes:
        :return:
        """
        return self.abqfh_output_request.SpecifiedModes

    @property
    def specified_output_variables(self, i_variable_name_bstr):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpecifiedOutputVariables
                | o Property SpecifiedOutputVariables(        iVariableNameBSTR) (Write Only)
                | 
                | Sets the specified variables for which results are
                | requested.
                |

        :param i_variable_name_bstr:
        :return:
        """
        return self.abqfh_output_request.SpecifiedOutputVariables

    @property
    def specified_sec_pts(self, i_specified_sec_pts):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpecifiedSecPts
                | o Property SpecifiedSecPts(        iSpecifiedSecPts) (Write Only)
                | 
                | Sets request for output results at specified section points.
                |

        :param i_specified_sec_pts:
        :return:
        """
        return self.abqfh_output_request.SpecifiedSecPts

    @property
    def timing_flag(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimingFlag
                | o Property TimingFlag(    ) As
                | 
                | Returns or sets a flag for output at approximate or exact
                | times. A true value indicates that request for output
                | results at approximate times and a false value for output
                | results at exact times. Returns: A boolean specifying
                | whether request for output results at approximate or exact
                | times.
                |

        :return:
        """
        return self.abqfh_output_request.TimingFlag

    @timing_flag.setter
    def timing_flag(self, value):
        """
            :param type value:
        """
        self.abqfh_output_request.TimingFlag = value 

    def set_output_at_all_modes(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOutputAtAllModes
                | o Sub SetOutputAtAllModes(    )
                | 
                | For frequency step: Sets request for output results at all
                | modes.
                |
                | Parameters:

                |
        :return:
        """
        return self.abqfh_output_request.SetOutputAtAllModes()

    def __repr__(self):
        return f'ABQFHOutputRequest()'
