#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQAnalysisCase(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus analysis case (ABQAnalysisCase)
                | object.Role:Access an Abaqus analysis case object or determine its
                | properties. An ABQAnalysisCase object contains the collection of
                | Abaqus steps (activateLinkAnchor('ABQSteps','','ABQSteps')) and Abaqus
                | jobs (activateLinkAnchor('ABQJobs','','ABQJobs')). An Abaqus analysis
                | case object contains the data required to manage and run an Abaqus
                | finite element analysis.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_analysis_case = com_object     

    @property
    def display_groups(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayGroups
                | o Property DisplayGroups(    ) As   (Read Only)
                | 
                | Returns the Abaqus display groups associated with this
                | analysis case. Returns: The collection of display groups.
                | Example: The following example retrieves the Abaqus display
                | group collection DisplayGroups in ListDisplayGroups. Dim
                | MyCase As ABQAnalysisCase Dim ListDisplayGroups As
                | ABQDisplayGroups Set ListDisplayGroups =
                | MyCase.DisplayGroups
                |

        :return:
        """
        return self.abq_analysis_case.DisplayGroups

    @property
    def global_elem_assignment(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GlobalElemAssignment
                | o Property GlobalElemAssignment(    ) As   (Read Only)
                | 
                | Returns the Global Element Assignement feature associated
                | with this analysis case. Returns: The associated Global
                | Element Assignement feature . Example: The following example
                | retrieves the Global Element Assignement feature collection
                | GlobalElemAssignment in oGlobalElementAssignment. Dim MyCase
                | As ABQAnalysisCase Dim GlobalElementAssignment As
                | ABQGlobalElementAssignment Set GlobalElementAssignment =
                | MyCase.GlobalElemAssignment
                |

        :return:
        """
        return self.abq_analysis_case.GlobalElemAssignment

    @property
    def jobs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Jobs
                | o Property Jobs(    ) As   (Read Only)
                | 
                | Returns the Abaqus jobs associated with this analysis case.
                | Returns: The collection of jobs. Example: The following
                | example retrieves the Abaqus job collection Jobs in
                | ListJobs. Dim MyCase As ABQAnalysisCase Dim ListJobs As
                | ABQJobs Set ListJobs = MyCase.Jobs
                |

        :return:
        """
        return self.abq_analysis_case.Jobs

    @property
    def solution_case(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SolutionCase
                | o Property SolutionCase(    ) As   (Read Only)
                | 
                | Returns the Abaqus solution case associated with this
                | analysis case. Returns: The associated Abaqus solution case.
                | Example: The following example retrieves the Abaqus solution
                | case collection SolutionCase in SolutionCase. Dim MyCase As
                | ABQAnalysisCase Dim SolutionCase As ABQSolutionCase Set
                | SolutionCase = MyCase.SolutionCase
                |

        :return:
        """
        return self.abq_analysis_case.SolutionCase

    @property
    def steps(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Steps
                | o Property Steps(    ) As   (Read Only)
                | 
                | Returns the Abaqus analysis steps associated with this
                | analysis case. Returns: The collection of analysis steps.
                | Example: The following example retrieves the Abaqus analysis
                | step collection Steps in ListSteps. Dim MyCase As
                | ABQAnalysisCase Dim ListSteps As ABQSteps Set ListSteps =
                | MyCase.Steps
                |

        :return:
        """
        return self.abq_analysis_case.Steps

    def __repr__(self):
        return f'ABQAnalysisCase()'
