#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQIAABQSteadyStateLinDynStepModalVB(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | ABQIAABQSteadyStateLinDynStepModal are ...Do not use the
                | ABQIAABQSteadyStateLinDynStepModal interface for such and such
                | ClassReference, Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abqiaabq_steady_state_lin_dyn_step_modal_vb = com_object     

    @property
    def use_composite_damping_data(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseCompositeDampingData
                | o Property UseCompositeDampingData(    ) As
                | 
                | Sets or returns if the composite damping data is ued.
                | Returns: A boolean specifying whether the composite damping
                | data is ued.
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_modal_vb.UseCompositeDampingData

    @property
    def use_direct_damping_data(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseDirectDampingData
                | o Property UseDirectDampingData(    ) As
                | 
                | Sets or returns if the direct damping data is ued. Returns:
                | A boolean specifying whether the direct damping data is ued.
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_modal_vb.UseDirectDampingData

    @property
    def use_rayleigh_damping_data(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseRayleighDampingData
                | o Property UseRayleighDampingData(    ) As
                | 
                | Sets or returns if the rayleigh damping data is ued.
                | Returns: A boolean specifying whether the rayleigh damping
                | data is ued.
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_modal_vb.UseRayleighDampingData

    @property
    def use_structural_damping_data(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseStructuralDampingData
                | o Property UseStructuralDampingData(    ) As
                | 
                | Sets or returns if the structural damping data is ued.
                | Returns: A boolean specifying whether the structural damping
                | data is ued.
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_modal_vb.UseStructuralDampingData

    def add_composite_damping_data_table(self, i_column_1, i_column_2):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddCompositeDampingDataTable
                | o Sub AddCompositeDampingDataTable(        iColumn1,
                |                                            iColumn2)
                | 
                | Adds a composite damping data over ranges of Modes or
                | Frequencies The number of values in both the parameters must
                | match. If either list contains extra values, the extra
                | values are discarded. Valid only for damping over ranges of
                | Modes.
                |
                | Parameters:
                | iColumn1
                |     The list of start modes.
                | 
                |  iColumn2
                |              The list of end modes.

                |
        :param i_column_1:
        :param i_column_2:
        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_modal_vb.AddCompositeDampingDataTable(i_column_1, i_column_2)

    def add_direct_damping_data_table(self, i_damping_range, i_column_1, i_column_2, i_column_3):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddDirectDampingDataTable
                | o Sub AddDirectDampingDataTable(        iDampingRange,
                |                                         iColumn1,
                |                                         iColumn2,
                |                                         iColumn3)
                | 
                | Adds a direct damping data over ranges of Modes or
                | Frequencies The number of values in all the three of the
                | parameters must match. If either list contains extra values,
                | the extra values are discarded.
                |
                | Parameters:
                | iDampingRange
                |      The range over which damping is defined.
                | 
                |   Legal values:
                |  MODES.
                |  FREQUENCIES.
                |  
                | 
                |  iColumn1
                |      For daming range = MODES - The list of start modes.
                |    For daming range = FREQUENCIES - The list of frequencies.
                | 
                |  iColumn2
                |               For daming range = MODES - The list of end modes.
                |    For daming range = FREQUENCIES - The list of critical damping fraction.
                | 
                |  iColumn3
                |               For daming range = MODES - The list of critical damping fraction.
                |    For daming range = FREQUENCIES - iColumn3 will be ignored if the damping range is FREQUENCIES.

                |
        :param i_damping_range:
        :param i_column_1:
        :param i_column_2:
        :param i_column_3:
        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_modal_vb.AddDirectDampingDataTable(i_damping_range, i_column_1, i_column_2, i_column_3)

    def add_rayleigh_damping_data_table(self, i_damping_range, i_column_1, i_column_2, i_column_3, i_column_4):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddRayleighDampingDataTable
                | o Sub AddRayleighDampingDataTable(        iDampingRange,
                |                                           iColumn1,
                |                                           iColumn2,
                |                                           iColumn3,
                |                                           iColumn4)
                | 
                | Adds a rayleigh damping data over ranges of Modes or
                | Frequencies The number of values in all the four of the
                | parameters must match. If either list contains extra values,
                | the extra values are discarded.
                |
                | Parameters:
                | iDampingRange
                |      The range over which damping is defined.
                | 
                |   Legal values:
                |  MODES.
                |  FREQUENCIES.
                |  
                | 
                |  iColumn1
                |      For daming range = MODES - The list of start modes.
                |    For daming range = FREQUENCIES - The list of frequencies.
                | 
                |  iColumn2
                |               For daming range = MODES - The list of end modes.
                |    For daming range = FREQUENCIES - The list of alpha coefficients.
                | 
                |  iColumn3
                |               For daming range = MODES - The list of alpha coefficients.
                |    For daming range = FREQUENCIES - The list of beta coefficients.
                | 
                |  iColumn4
                |               For daming range = MODES - The list of beta coefficients.
                |    For daming range = FREQUENCIES - iColumn4 will be ignored if the damping range is FREQUENCIES.

                |
        :param i_damping_range:
        :param i_column_1:
        :param i_column_2:
        :param i_column_3:
        :param i_column_4:
        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_modal_vb.AddRayleighDampingDataTable(i_damping_range, i_column_1, i_column_2, i_column_3, i_column_4)

    def add_structural_damping_data_table(self, i_damping_range, i_column_1, i_column_2, i_column_3):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddStructuralDampingDataTable
                | o Sub AddStructuralDampingDataTable(        iDampingRange,
                |                                             iColumn1,
                |                                             iColumn2,
                |                                             iColumn3)
                | 
                | Adds a structural damping data over ranges of Modes or
                | Frequencies The number of values in all the three of the
                | parameters must match. If either list contains extra values,
                | the extra values are discarded.
                |
                | Parameters:
                | iDampingRange
                |      The range over which damping is defined.
                | 
                |   Legal values:
                |  MODES.
                |  FREQUENCIES.
                |  
                | 
                |  iColumn1
                |      For daming range = MODES - The list of start modes.
                |    For daming range = FREQUENCIES - The list of frequencies.
                | 
                |  iColumn2
                |               For daming range = MODES - The list of end modes.
                |    For daming range = FREQUENCIES - The list of damping constant.
                | 
                |  iColumn3
                |               For daming range = MODES - The list of damping constant.
                |    For daming range = FREQUENCIES - iColumn3 will be ignored if the damping range is FREQUENCIES.

                |
        :param i_damping_range:
        :param i_column_1:
        :param i_column_2:
        :param i_column_3:
        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_modal_vb.AddStructuralDampingDataTable(i_damping_range, i_column_1, i_column_2, i_column_3)

    def __repr__(self):
        return f'ABQIAABQSteadyStateLinDynStepModalVB()'
