#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQFieldOutputRequests(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of Abaqus field output request (ABQFieldOutputRequest)
                | objects attached to anactivateLinkAnchor('ABQGeneralStaticStep','','AB
                | QGeneralStaticStep'),
                | anactivateLinkAnchor('ABQFrequencyStep','','ABQFrequencyStep'),
                | anactivateLinkAnchor('ABQHeatTransferStep','','ABQHeatTransferStep'),
                | or anactivateLinkAnchor('ABQExplicitDynamicsStep','','ABQExplicitDynam
                | icsStep')object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_field_output_requests = com_object     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As
                | 
                | Creates a new Abaqus field output request and adds it to the
                | collection of Abaqus field output requests. Returns:
                | oFieldOutputRequest The Abaqus field output request object
                | that was created. Example: The following example creates a
                | field output request in the ABQFieldOutputRequests
                | collection: Dim abqFieldOutputRequests As
                | ABQFieldOutputRequests Set abqFieldOutputRequests =
                | generalstaticstep.FieldOutputRequests Dim
                | abqFieldOutputRequest As ABQFieldOutputRequest Set
                | abqFieldOutputRequest = abqFieldOutputRequests.Add()
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_field_output_requests.Add()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus field output request using its index or
                | its name from the collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus field output request to retrieve from
                |    the collection of Abaqus field output requests.
                |    If the index is a number, it specifies the rank of the Abaqus field output request
                |    in the collection. The index of the first Abaqus field output request in the collection is 1,
                |    and the index of the last field output request is Count.
                |    If the index is a string, it specifies the name you assigned to the field output request using
                |    the CATIACollection::Name property.
                |    
                |  
                | 
                |  Returns:
                |   The specified 
                | .

                |
        :param i_index:
        :return:
        """
        return self.abq_field_output_requests.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes an Abaqus field output request using its index or
                | its name from the field output requests collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the field output request to retrieve from
                |    the collection of field output requests.
                |    As a numeric, this index is the rank of the field output request
                |    in the collection. The index of the first field output request in the collection is 1,
                |    and the index of the last field output request is Count.
                |    As a string, it is the name you assigned to the field output request using
                |    the CATIABase::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_field_output_requests.Remove(i_index)

    def __repr__(self):
        return f'ABQFieldOutputRequests()'
