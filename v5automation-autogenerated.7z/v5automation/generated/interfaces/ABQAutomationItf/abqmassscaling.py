#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQMassScaling(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus Mass Scaling entity.Role: Used to access the
                | properties of a Mass Scaling entity.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_mass_scaling = com_object     

    @property
    def frequency_increment(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FrequencyIncrement
                | o Property FrequencyIncrement(    ) As
                | 
                | Sets or returns the scaling frequency increment. Applies
                | only when FrequencyType is ABQ_INCREMENT.
                |

        :return:
        """
        return self.abq_mass_scaling.FrequencyIncrement

    @property
    def frequency_interval(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FrequencyInterval
                | o Property FrequencyInterval(    ) As
                | 
                | Sets or returns the scaling frequency interval. Applies only
                | when FrequencyType is ABQ_INTERVAL.
                |

        :return:
        """
        return self.abq_mass_scaling.FrequencyInterval

    @property
    def frequency_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FrequencyType
                | o Property FrequencyType(    ) As
                | 
                | Sets or returns the scaling frequency type.
                |

        :return:
        """
        return self.abq_mass_scaling.FrequencyType

    @property
    def global(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Global
                | o Property Global(    ) As
                | 
                | Sets or returns whether the mass scaling is global.
                |

        :return:
        """
        return self.abq_mass_scaling.Global

    @property
    def num_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumSupports
                | o Property NumSupports(    ) As   (Read Only)
                | 
                | Retrieves the number of supports.
                |

        :return:
        """
        return self.abq_mass_scaling.NumSupports

    @property
    def scale_factor(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ScaleFactor
                | o Property ScaleFactor(    ) As
                | 
                | Sets or returns the scale factor.
                |

        :return:
        """
        return self.abq_mass_scaling.ScaleFactor

    @property
    def scale_factor_on(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ScaleFactorOn
                | o Property ScaleFactorOn(    ) As
                | 
                | Sets or returns whether the scale factor is active.
                |

        :return:
        """
        return self.abq_mass_scaling.ScaleFactorOn

    @property
    def target_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TargetMethod
                | o Property TargetMethod(    ) As
                | 
                | Sets or returns the target time scaling method. Applies only
                | when target time is active.
                |

        :return:
        """
        return self.abq_mass_scaling.TargetMethod

    @property
    def target_time(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TargetTime
                | o Property TargetTime(    ) As
                | 
                | Sets or returns the scaling target time.
                |

        :return:
        """
        return self.abq_mass_scaling.TargetTime

    @property
    def target_time_on(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TargetTimeOn
                | o Property TargetTimeOn(    ) As
                | 
                | Sets or returns whether the target time scaling is active.
                |

        :return:
        """
        return self.abq_mass_scaling.TargetTimeOn

    @property
    def variable(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Variable
                | o Property Variable(    ) As
                | 
                | Sets or returns whether the mass scaling is variable.
                |

        :return:
        """
        return self.abq_mass_scaling.Variable

    def add_support_for_body(self, i_product, i_body):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportForBody
                | o Sub AddSupportForBody(        iProduct,
                |                                 iBody)
                | 
                | Adds the specified body as a support.
                |
                | Parameters:
                | iProduct
                |      The CATIAProduct specifying the positioning object.
                |  
                |  iBody
                |               The CATIABody to serve as the support.
                |   Refer: CATIABody , CATIAProduct

                |
        :param i_product:
        :param i_body:
        :return:
        """
        return self.abq_mass_scaling.AddSupportForBody(i_product, i_body)

    def add_support_from_product(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromProduct
                | o Sub AddSupportFromProduct(        iProduct,
                |                                     iSupport)
                | 
                | Adds the specified product reference as a support. If the
                | support already exists then it is removed.
                |
                | Parameters:
                | iProduct
                |      The CATIAProduct specifying the positioning object.
                |  
                |  iSupport
                |      The CATIAReference to serve as the support.

                |
        :param i_product:
        :param i_support:
        :return:
        """
        return self.abq_mass_scaling.AddSupportFromProduct(i_product, i_support)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Adds a support from the publication. If the support already
                | exists, it is removed.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the mass scaling is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the mass scaling is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_mass_scaling.AddSupportFromPublication(i_product, i_publication)

    def clear_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClearSupports
                | o Sub ClearSupports(    )
                | 
                | Clear the list of supports.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_mass_scaling.ClearSupports()

    def get_supports(self, o_products, o_supports):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSupports
                | o Sub GetSupports(        oProducts,
                |                           oSupports)
                | 
                | Gets the supports that define the mass scaling region(s).
                |
                | Parameters:
                | oProducts
                |    Returned safe array of products for the supports, 
                |    as CATIAReferences.
                |    This array has a one-to-one mapping with the supports array.
                |  
                |  oSupports
                |    Returned safe array of supports, as CATIAReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param o_products:
        :param o_supports:
        :return:
        """
        return self.abq_mass_scaling.GetSupports(o_products, o_supports)

    def set_supports(self, i_products, i_supports):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSupports
                | o Sub SetSupports(        iProducts,
                |                           iSupports)
                | 
                | Sets the supports that define the mass scaling region(s).
                | Any previously set support regions will be replaced with
                | this new list. The list must contain at least one item.
                |
                | Parameters:
                | iProducts
                |    Safe array of products for the supports as CATIAReferences.  
                |    This array has a one-to-one mapping with the supports array.
                |  
                |  iSupports
                |     Safe array of supports as CATIAReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param i_products:
        :param i_supports:
        :return:
        """
        return self.abq_mass_scaling.SetSupports(i_products, i_supports)

    def __repr__(self):
        return f'ABQMassScaling()'
