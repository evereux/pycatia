#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQOutputRequest(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the base interface for all output request objects.Role:The
                | ABQOutputRequest interface manages the common attributes of any output
                | requests.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_output_request = com_object     

    @property
    def activation_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActivationStatus
                | o Property ActivationStatus(    ) As
                | 
                | Sets or returns the activation status. Returns: A boolean
                | specifying whether the output request is activated or
                | deactivated.
                |

        :return:
        """
        return self.abq_output_request.ActivationStatus

    @property
    def num_increment_frequency(self, i_num_increment_frequency):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumIncrementFrequency
                | o Property NumIncrementFrequency(        iNumIncrementFrequency) (Write Only)
                | 
                | Sets request for output results at specified increment.
                |

        :param i_num_increment_frequency:
        :return:
        """
        return self.abq_output_request.NumIncrementFrequency

    @property
    def status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Status
                | o Property Status(    ) As   (Read Only)
                | 
                | Returns the propagating status of the output request.
                | Returns: The propagating status for example: if the output
                | request feature is created, it will return "CREATED" if the
                | output request feature is propagated from previous step, it
                | will return "PROPAGATED" if the output request feature is
                | modified in current step, it will return "MODIFIED"
                |

        :return:
        """
        return self.abq_output_request.Status

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the type of the output request. Returns: The string
                | representing the type of the output request.
                |

        :return:
        """
        return self.abq_output_request.Type

    @property
    def whole_model_as_supp(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WholeModelAsSupp
                | o Property WholeModelAsSupp(    ) As
                | 
                | Sets or returns whether the whole model is selected as
                | support. A value of true indicates that the whole model is
                | selected as support. Returns: A boolean specifying whether
                | the whole model is selected as support.
                |

        :return:
        """
        return self.abq_output_request.WholeModelAsSupp

    def add_support_from_product(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromProduct
                | o Sub AddSupportFromProduct(        iProduct,
                |                                     iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the output request is applied.
                | 
                |  iSupport
                |               The CATIA Reference specifying the region to which the output request is applied.
                |  Refer: CATIAReference , CATIAProduct

                |
        :param i_product:
        :param i_support:
        :return:
        """
        return self.abq_output_request.AddSupportFromProduct(i_product, i_support)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the output request is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the output request is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_output_request.AddSupportFromPublication(i_product, i_publication)

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iReference,
                |                                       iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iReference
                |      The CATIA Reference specifying the object to which the output request is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the output request is applied.
                |  Refer: CATIAReference

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_output_request.AddSupportFromReference(i_reference, i_support)

    def set_output_at_last_increment(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOutputAtLastIncrement
                | o Sub SetOutputAtLastIncrement(    )
                | 
                | Sets request for output results at last increment.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_output_request.SetOutputAtLastIncrement()

    def __repr__(self):
        return f'ABQOutputRequest()'
