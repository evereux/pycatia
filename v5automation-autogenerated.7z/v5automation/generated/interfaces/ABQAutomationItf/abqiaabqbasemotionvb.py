#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQIAABQBaseMotionVB(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | ABQIAABQBaseMotion are ...Do not use the ABQIAABQBaseMotion interface
                | for such and such ClassReference, Class#MethodReference,
                | #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abqiaabq_base_motion_vb = com_object     

    @property
    def base_motion_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BaseMotionType
                | o Property BaseMotionType(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_base_motion_vb.BaseMotionType

    @property
    def base_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BaseType
                | o Property BaseType(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_base_motion_vb.BaseType

    @property
    def clamp_support(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClampSupport
                | o Property ClampSupport(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_base_motion_vb.ClampSupport

    @property
    def dof(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DOF
                | o Property DOF(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_base_motion_vb.DOF

    @property
    def data_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DataType
                | o Property DataType(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_base_motion_vb.DataType

    @property
    def disp_bc_support(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DispBCSupport
                | o Property DispBCSupport(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_base_motion_vb.DispBCSupport

    @property
    def frequency_data_values(self, i_freq_data_val):
        """
        .. note::
            CAA V5 Visual Basic help

                | FrequencyDataValues
                | o Property FrequencyDataValues(        iFreqDataVal) (Write Only)
                | 
                |

        :param i_freq_data_val:
        :return:
        """
        return self.abqiaabq_base_motion_vb.FrequencyDataValues

    @property
    def imaginary_data_values(self, i_imaginary_data_values):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImaginaryDataValues
                | o Property ImaginaryDataValues(        iImaginaryDataValues) (Write Only)
                | 
                |

        :param i_imaginary_data_values:
        :return:
        """
        return self.abqiaabq_base_motion_vb.ImaginaryDataValues

    @property
    def real_data_values(self, i_real_data_val):
        """
        .. note::
            CAA V5 Visual Basic help

                | RealDataValues
                | o Property RealDataValues(        iRealDataVal) (Write Only)
                | 
                |

        :param i_real_data_val:
        :return:
        """
        return self.abqiaabq_base_motion_vb.RealDataValues

    @property
    def scale(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Scale
                | o Property Scale(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_base_motion_vb.Scale

    def add_centre_of_rotation(self, i_product, i_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddCentreOfRotation
                | o Sub AddCentreOfRotation(        iProduct,
                |                                   iRef)
                | 
                |
                | Parameters:

                |
        :param i_product:
        :param i_ref:
        :return:
        """
        return self.abqiaabq_base_motion_vb.AddCentreOfRotation(i_product, i_ref)

    def __repr__(self):
        return f'ABQIAABQBaseMotionVB()'
