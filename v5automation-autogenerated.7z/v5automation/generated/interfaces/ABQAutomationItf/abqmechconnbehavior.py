#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQMechConnBehavior(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus mechanical connection behavior
                | (ABQMechConnBehavior) object.Role:Access an Abaqus mechanical
                | connection behaviour object or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_mech_conn_behavior = com_object     

    @property
    def allow_separation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AllowSeparation
                | o Property AllowSeparation(    ) As
                | 
                | Sets or returns the seperation status for the hard contact
                | pressure overclosure. Returns: A boolean specifying whether
                | seperation status is on or off.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.AllowSeparation

    @property
    def apply_user_subroutine(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyUserSubroutine
                | o Property ApplyUserSubroutine(    ) As
                | 
                | Sets or returns the user subroutine flag. Returns: A boolean
                | specifying whether a user subroutine will be applied.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.ApplyUserSubroutine

    @property
    def augmented_lagrange(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AugmentedLagrange
                | o Property AugmentedLagrange(    ) As
                | 
                | Sets or returns the augmented lagrange formulation in a
                | mechanical connection. Returns: A boolean specifying whether
                | augmented lagrange formulation is applied.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.AugmentedLagrange

    @property
    def clearance_contact_pressure_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClearanceContactPressureValue
                | o Property ClearanceContactPressureValue(    ) As
                | 
                | Sets or returns the clearance at which contact pressure is
                | zero in a mechanical connection. Returns: clearance at which
                | contact pressure is zero.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.ClearanceContactPressureValue

    @property
    def contact_stiffness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactStiffness
                | o Property ContactStiffness(    ) As
                | 
                | Sets or returns the contact stiffness type hard contact
                | pressure overclosure. Returns: The contact stiffness Legal
                | values: DEFAULT STIFF_VALUE
                |

        :return:
        """
        return self.abq_mech_conn_behavior.ContactStiffness

    @property
    def contact_stiffness_scale_factor_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactStiffnessScaleFactorValue
                | o Property ContactStiffnessScaleFactorValue(    ) As
                | 
                | Sets or returns the contact stiffness scale factor value in
                | a mechanical connection. Returns: contact stiffness scale
                | factor value.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.ContactStiffnessScaleFactorValue

    @property
    def contact_stiffness_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactStiffnessValue
                | o Property ContactStiffnessValue(    ) As
                | 
                | Sets or returns the contact stiffness value for hard contact
                | pressure overclosure. Returns: The stiffness value.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.ContactStiffnessValue

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As
                | 
                | Sets or returns the description. Returns: The description of
                | the step.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.Description

    @property
    def formulation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Formulation
                | o Property Formulation(    ) As
                | 
                | Sets or returns the formulation in a mechanical connection.
                | Returns: The formulation. Legal values: FRICTIONLESS PENALTY
                |

        :return:
        """
        return self.abq_mech_conn_behavior.Formulation

    @property
    def friction_coefficient(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FrictionCoefficient
                | o Property FrictionCoefficient(    ) As
                | 
                | Sets or returns the friction coefficient if the formulation
                | is PENALTY. Returns: The friction coefficient.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.FrictionCoefficient

    @property
    def max_stiffness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxStiffness
                | o Property MaxStiffness(    ) As
                | 
                | Sets or returns the contact stiffness type hard contact
                | pressure overclosure. Returns: The contact stiffness Legal
                | values: DEFAULT STIFF_VALUE
                |

        :return:
        """
        return self.abq_mech_conn_behavior.MaxStiffness

    @property
    def max_stiffness_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxStiffnessValue
                | o Property MaxStiffnessValue(    ) As
                | 
                | Sets or returns the max stiffness value for mechanical
                | connection. Returns: The stiffness value.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.MaxStiffnessValue

    @property
    def penalty_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PenaltyMethod
                | o Property PenaltyMethod(    ) As
                | 
                | Sets or returns the penalty method formulation in a
                | mechanical connection. Returns: A boolean specifying whether
                | penalty method formulation is applied.
                |

        :return:
        """
        return self.abq_mech_conn_behavior.PenaltyMethod

    @property
    def pressure_overclosure(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PressureOverclosure
                | o Property PressureOverclosure(    ) As
                | 
                | Sets or returns the pressure overclosure in a mechanical
                | connection. Returns: The pressure overclosure. Legal values:
                | HARD EXPONENTIAL LINEAR TABULAR
                |

        :return:
        """
        return self.abq_mech_conn_behavior.PressureOverclosure

    def add_pressure_overclosure_table(self, i_pressure, i_overclosure):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddPressureOverclosureTable
                | o Sub AddPressureOverclosureTable(        iPressure,
                |                                           iOverclosure)
                | 
                | Adds a list of tabular pressure overclosure in the
                | connection behavior. The number of values in both of the
                | parameters should match. If either list contains extra
                | values, the extra values are discarded.
                |
                | Parameters:
                | iPressure
                |      The list of pressure values.
                | 
                |  iOverclosure
                |    The  list of overclosures.

                |
        :param i_pressure:
        :param i_overclosure:
        :return:
        """
        return self.abq_mech_conn_behavior.AddPressureOverclosureTable(i_pressure, i_overclosure)

    def get_pressure_overclosure_table(self, o_pressure, o_overclosure):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPressureOverclosureTable
                | o Sub GetPressureOverclosureTable(        oPressure,
                |                                           oOverclosure)
                | 
                | Returns a list of tabular pressure overclosure in connection
                | behavior.
                |
                | Parameters:
                | oPressure
                |      The list of pressure values.
                | 
                |  oOverclosure
                |               The  list of overclosures.

                |
        :param o_pressure:
        :param o_overclosure:
        :return:
        """
        return self.abq_mech_conn_behavior.GetPressureOverclosureTable(o_pressure, o_overclosure)

    def __repr__(self):
        return f'ABQMechConnBehavior()'
