#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQSteps(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of Abaqus analysis step (ABQStep) objects contained in
                | anactivateLinkAnchor('ABQAnalysisCase','','ABQAnalysisCase')object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_steps = com_object     

    def add(self, i_step_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iStepType) As
                | 
                | Creates a new Abaqus Step and adds it to the collection of
                | Abaqus steps.
                |
                | Parameters:
                | iStepType
                |  The type of the step to create.  Legal values:
                |  "ABQGeneralStaticStep",
                |  "ABQFrequencyStep",
                |  "ABQExplicitDynamicsStep",
                |  "ABQHeatTransferStep"
                |  "ABQLinearDynamicStepModal"
                |  "ABQLinearDynamicStepSubspace"
                |  
                |  
                | 
                |  Returns:
                |   oStep The Abaqus step object that was created.

                |                | Examples:
                | The following example creates a general static step in the
                | ABQSteps collection: Dim abqCase As ABQAnalysisCase Dim
                | abaqusSteps As ABQSteps Dim generalstaticstep As
                | ABQGeneralStaticStep Set abaqusSteps = abqCase.Steps Set
                | generalstaticstep = abaqusSteps.Add("ABQGeneralStaticStep")

        :param i_step_type:
        :return:
        """
        return self.abq_steps.Add(i_step_type)

    def insert(self, i_step_type, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Insert
                | o Func Insert(        iStepType,
                |                       iIndex) As
                | 
                | Creates a new Abaqus Step and inserts it to the collection
                | of Abaqus steps.
                |
                | Parameters:
                | iStepType
                |  The type of the step to create.  Legal values:
                |  "ABQGeneralStaticStep",
                |  "ABQFrequencyStep",
                |  "ABQExplicitDynamicsStep",
                |  "ABQHeatTransferStep"
                |  
                |  
                |  iIndex
                |  Index of Abaqus step after which the new step is to be inserted. for initialization step iIndex is 1 
                | 
                | 
                |  Returns:
                |   oStep The Abaqus step object that was inserted.

                |                | Examples:
                | The following example creates a general static step in the
                | ABQSteps collection: Dim abqCase As ABQAnalysisCase Dim
                | abaqusSteps As ABQSteps Dim generalstaticstep As
                | ABQGeneralStaticStep Set abaqusSteps = abqCase.Steps Set
                | generalstaticstep =
                | abaqusSteps.Insert("ABQGeneralStaticStep", 1)

        :param i_step_type:
        :param i_index:
        :return:
        """
        return self.abq_steps.Insert(i_step_type, i_index)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus step using its index or its name from the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus step to retrieve from
                |    the collection of Abaqus steps.
                |    If the index is a number, it specifies the rank of the Abaqus step
                |    in the collection. The index of the first Abaqus step in the collection is 1,
                |    and the index of the last step is Count.
                |    If the index is a string, it specifies the name you assigned to the step using
                |    the CATIACollection::Name property.
                |  
                | 
                |  Returns:
                |   The specified 
                | .

                |                | Examples:
                | This example retrieves the fifth Abaqus step in the
                | collection and saves it in a variable called FirstStep. The
                | example also retrieves the Abaqus step named "MyStep" in the
                | collection and saves it in a variable called SecondStep. Set
                | CaseColl = AnalysisDoc.ABQAnalysisModel.Cases Set ThisCase =
                | CaseColl.Item(5) Set StepColl = ThisCase.Steps Set
                | FirstStaticStep = StepColl.Item(5) Set SecondStaticStep =
                | StepColl.Item("MyStep")

        :param i_index:
        :return:
        """
        return self.abq_steps.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes an Abaqus step using its index or its name from the
                | Step collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus step to retrieve from
                |    the collection of Abaqus Steps.
                |    If the index is a number, it specifies the rank of the Abaqus step
                |    in the collection. The index of the first Abaqus step in the collection is 1,
                |    and the index of the last step is Count.
                |    If the index is a string, it specifies the name you assigned to the step using
                |    the CATIABase::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_steps.Remove(i_index)

    def __repr__(self):
        return f'ABQSteps()'
