#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQSolutionCase(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus solution case (ABQSolutionCase) object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_solution_case = com_object     

    @property
    def analysis_images(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisImages
                | o Property AnalysisImages(    ) As   (Read Only)
                | 
                | Returns the analysis images associated with this solution
                | case. Returns: The collection of analysis images. Example:
                | The following example retrieves the analysis images
                | collection AnalysisImages in ListSolutionCaseImages. Dim
                | MySolutionCase As ABQSolutionCase Dim ListSolutionCaseImages
                | As ABQSolutionCaseImages Set ListSolutionCaseImages =
                | MySolutionCase.AnalysisImages
                |

        :return:
        """
        return self.abq_solution_case.AnalysisImages

    @property
    def solution_steps(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SolutionSteps
                | o Property SolutionSteps(    ) As   (Read Only)
                | 
                | Returns the Abaqus solution steps associated with this
                | solution case. Returns: The collection of solution steps.
                | Example: The following example retrieves the Abaqus solution
                | steps collection SolutionSteps in ListSolutionSteps. Dim
                | MySolutionCase As ABQSolutionCase Dim ListSolutionSteps As
                | ABQSolutionSteps Set ListSolutionSteps =
                | MySolutionCase.SolutionSteps
                |

        :return:
        """
        return self.abq_solution_case.SolutionSteps

    def create_image(self, i_image_name, i_hide_existing_images, i_step_number, i_increment_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateImage
                | o Func CreateImage(        iImageName,
                |                            iHideExistingImages,
                |                            iStepNumber,
                |                            iIncrementNumber) As
                | 
                | Creates a new image under this solution case.
                |
                | Parameters:
                | iImageName
                |  The name of the image to create.
                |  
                |  iHideExistingImages
                |  To deactivate or not all the activated images before create the new image.
                |  
                |  iStepNumber
                |  Step number to be set in created image.
                |  
                |  iIncrementNumber
                |  Increment number to be set in created image.
                |  
                | 
                |  Returns:
                |   The created Analysis Image

                |                | Examples:
                | This example create ThisAnalysisImage in the MySolutionCase.
                | The image to create is supposed to be a mesh deformed image
                | for first increment of first step. Dim MySolutionCase As
                | ABQSolutionCase Dim ThisAnalysisImage As AnalysisImage Set
                | ThisAnalysisImage =
                | MySolutionCase.CreateImage("Mesh_Deformed", True, 1, 1)

        :param i_image_name:
        :param i_hide_existing_images:
        :param i_step_number:
        :param i_increment_number:
        :return:
        """
        return self.abq_solution_case.CreateImage(i_image_name, i_hide_existing_images, i_step_number, i_increment_number)

    def set_step_increment_number(self, i_step_number, i_increment_number, i_image):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetStepIncrementNumber
                | o Sub SetStepIncrementNumber(        iStepNumber,
                |                                      iIncrementNumber,
                |                                      iImage)
                | 
                | Sets step and increment number for an image. This is done
                | related to an existing image
                |
                | Parameters:
                | iStepNumber
                |   The step number to select 
                |  iIncrementNumber
                |   The increment number to select

                |
        :param i_step_number:
        :param i_increment_number:
        :param i_image:
        :return:
        """
        return self.abq_solution_case.SetStepIncrementNumber(i_step_number, i_increment_number, i_image)

    def __repr__(self):
        return f'ABQSolutionCase()'
