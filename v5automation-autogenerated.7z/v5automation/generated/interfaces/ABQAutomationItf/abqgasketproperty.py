#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQGasketProperty(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_gasket_property = com_object     

    @property
    def initial_gap(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InitialGap
                | o Property InitialGap(    ) As
                | 
                | Sets or returns the Initial gap value
                |

        :return:
        """
        return self.abq_gasket_property.InitialGap

    @property
    def initial_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InitialThickness
                | o Property InitialThickness(    ) As
                | 
                | Sets or returns the Initial thickness value
                |

        :return:
        """
        return self.abq_gasket_property.InitialThickness

    @property
    def initial_thickness_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InitialThicknessType
                | o Property InitialThicknessType(    ) As
                | 
                | Sets or returns the Initial thickness type
                |

        :return:
        """
        return self.abq_gasket_property.InitialThicknessType

    @property
    def initial_void(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InitialVoid
                | o Property InitialVoid(    ) As
                | 
                | Sets or returns the Initial void value
                |

        :return:
        """
        return self.abq_gasket_property.InitialVoid

    @property
    def stabilization_stiffness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StabilizationStiffness
                | o Property StabilizationStiffness(    ) As
                | 
                | Sets or returns the Stabilization stiffness value
                |

        :return:
        """
        return self.abq_gasket_property.StabilizationStiffness

    @property
    def stabilization_stiffness_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StabilizationStiffnessType
                | o Property StabilizationStiffnessType(    ) As
                | 
                | Sets or returns the Stabilization stiffness type
                |

        :return:
        """
        return self.abq_gasket_property.StabilizationStiffnessType

    @property
    def support_property(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SupportProperty
                | o Property SupportProperty(    ) As
                | 
                | Sets or returns the 3D structrel property.
                |

        :return:
        """
        return self.abq_gasket_property.SupportProperty

    def __repr__(self):
        return f'ABQGasketProperty()'
