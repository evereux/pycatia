#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQSpringConnectionProperty(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus spring connection property (ABQSpring)
                | object.Role:Access an Abaqus spring connection property object or
                | determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_spring_connection_property = com_object     

    @property
    def axis_sys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Axis_sys
                | o Property Axis_sys(    ) As
                | 
                | Sets or returns the axis system in the spring connection
                | property. Returns: The object of axis system.
                |

        :return:
        """
        return self.abq_spring_connection_property.Axis_sys

    @property
    def spring_def(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpringDef
                | o Property SpringDef(    ) As
                | 
                | Sets or returns the definition of spring. Returns: the
                | Definition of spring. Legal values: ABQ_LINE ABQ_NON_LINEAR
                | o Property SpringType() As Sets or returns the type of
                | spring. Returns: The type of spring. Legal values: AXIAL
                | GENERAL Methods o Sub AddSupportFromReference( iReference,
                | iSupport) Adds support to the spring connection property.
                |

        :return:
        """
        return self.abq_spring_connection_property.SpringDef

    @property
    def spring_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SpringType
                | o Property SpringType(    ) As
                | 
                | Sets or returns the type of spring. Returns: The type of
                | spring. Legal values: AXIAL GENERAL Methods o Sub
                | AddSupportFromReference( iReference, iSupport) Adds support
                | to the spring connection property.
                |

        :return:
        """
        return self.abq_spring_connection_property.SpringType

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iReference,
                |                                       iSupport)
                | 
                | Adds support to the spring connection property.
                |
                | Parameters:
                | iReference
                |      The CATIA Reference specifying the region to which the spring connection property is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the spring connection property is applied.
                |  Refer: CATIAReference

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_spring_connection_property.AddSupportFromReference(i_reference, i_support)

    def get_linear_stiffness(self, i_dof):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLinearStiffness
                | o Func GetLinearStiffness(        iDof) As
                | 
                | Gets the linear stiffness of the spring given the degree of
                | freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which stiffness is asked.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  oStiffnessValue
                |      The stiffnessvalue.

                |
        :param i_dof:
        :return:
        """
        return self.abq_spring_connection_property.GetLinearStiffness(i_dof)

    def get_non_linear_stiffness(self, i_dof, o_force_array, o_disp_array):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNonLinearStiffness
                | o Sub GetNonLinearStiffness(        iDof,
                |                                     oForceArray,
                |                                     oDispArray)
                | 
                | Gets the non-linear stiffness of the spring in the form of
                | array, given the degree of freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which stiffness is asked.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  oForceArray
                |      The array of force values.
                | 
                |  oDispArray
                |      The array of displacement values.
                |  Refer: CATSafeArrayVariant

                |
        :param i_dof:
        :param o_force_array:
        :param o_disp_array:
        :return:
        """
        return self.abq_spring_connection_property.GetNonLinearStiffness(i_dof, o_force_array, o_disp_array)

    def read_stiffness_data_from_file(self, i_dof, i_file_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReadStiffnessDataFromFile
                | o Sub ReadStiffnessDataFromFile(        iDof,
                |                                         iFileName)
                | 
                | Reads stiffness data from a text file for a spring
                | connection property.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which stiffness is asked.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  iFileName
                |      The complete path of the text file which contains the stiffness data.

                |
        :param i_dof:
        :param i_file_name:
        :return:
        """
        return self.abq_spring_connection_property.ReadStiffnessDataFromFile(i_dof, i_file_name)

    def remove_axis_system(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAxisSystem
                | o Sub RemoveAxisSystem(    )
                | 
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_spring_connection_property.RemoveAxisSystem()

    def remove_dof(self, i_dof):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveDof
                | o Sub RemoveDof(        iDof)
                | 
                | Unsets the stiffness of the spring for given degree of
                | freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which stiffness is set.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF

                |
        :param i_dof:
        :return:
        """
        return self.abq_spring_connection_property.RemoveDof(i_dof)

    def set_linear_stiffness(self, i_dof, i_stiffness_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLinearStiffness
                | o Sub SetLinearStiffness(        iDof,
                |                                  iStiffnessValue)
                | 
                | Sets the linear stiffness of the spring given the degree of
                | freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which stiffness is set.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  iStiffnessValue
                |      The stiffnessvalue.

                |
        :param i_dof:
        :param i_stiffness_value:
        :return:
        """
        return self.abq_spring_connection_property.SetLinearStiffness(i_dof, i_stiffness_value)

    def set_non_linear_stiffness(self, i_dof, i_force_array, i_disp_array):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNonLinearStiffness
                | o Sub SetNonLinearStiffness(        iDof,
                |                                     iForceArray,
                |                                     iDispArray)
                | 
                | Sets the non-linear stiffness of the spring in the form of
                | array, given the degree of freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which stiffness is asked.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  iForceArray
                |      The array of force values.
                | 
                |  iDispArray
                |      The array of displacement values.
                |    The value in displacement array must be greater than previous value .
                |  Refer: CATSafeArrayVariant

                |
        :param i_dof:
        :param i_force_array:
        :param i_disp_array:
        :return:
        """
        return self.abq_spring_connection_property.SetNonLinearStiffness(i_dof, i_force_array, i_disp_array)

    def __repr__(self):
        return f'ABQSpringConnectionProperty()'
