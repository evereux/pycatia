#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQProperties(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The  collection of Abaqus property objects (ABQProperty) attached to
                | anactivateLinkAnchor('ABQAnalysisModel','','ABQAnalysisModel')object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_properties = com_object     

    def add(self, i_property_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iPropertyType) As
                | 
                | Creates a new Abaqus Property and adds it to the collection
                | of Abaqus Properties.
                |
                | Parameters:
                | iPropertyType
                |     The type of the Property to create.  
                |  Legal values:
                |  
                |  "ABQTabularAmplitude"
                |  "ABQSmoothStepAmplitude"
                |  "ABQMechConnBehavior"
                |  "ABQThermalConnBehavior"
                |  "ABQPreTensionProperty"
                |  "ABQGasketProperty"
                | 
                | 
                | 
                |  Returns:
                |   oProperty    The Abaqus Property object that was created.

                |                | Examples:
                | The following example creates a Tabular Amplitude Property
                | in the ABQProperties collection: Dim abaqusproperties As
                | ABQPropertiess Dim abqtabularAmpl As ABQTabularAmplitude Set
                | abqtabularAmpl = abaqusproperties.Add("ABQTabularAmplitude")

        :param i_property_type:
        :return:
        """
        return self.abq_properties.Add(i_property_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus property using its index or its name from
                | the collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus property to retrieve from
                |    the collection of Abaqus properties.
                |    If the index is a number, it specifies the rank of the Abaqus property
                |    in the collection. The index of the first Abaqus property in the collection is 1,
                |    and the index of the last property is Count.
                |    If the index is a string, it specifies the name you assigned to the property using
                |    the CATIACollection::Name property.
                |  
                | 
                |  Returns:
                |   The specified 
                | .

                |
        :param i_index:
        :return:
        """
        return self.abq_properties.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes a Abaqus property using its index or its name from
                | the property collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus property to retrieve from
                |    the collection of Abaqus Properties.
                |    If the index is a number, it specifies the rank of the Abaqus property
                |    in the collection. The index of the first Abaqus property in the collection is 1,
                |    and the index of the last property is Count.
                |    If the index is a string, it specifies the name you assigned to the property using
                |    the CATIABase::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_properties.Remove(i_index)

    def __repr__(self):
        return f'ABQProperties()'
