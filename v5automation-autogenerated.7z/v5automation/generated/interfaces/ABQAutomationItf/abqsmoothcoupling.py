#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQSmoothCoupling(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus smooth coupling (ABQSmoothCoupling) object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_smooth_coupling = com_object     

    @property
    def num_exclusion_regions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumExclusionRegions
                | o Property NumExclusionRegions(    ) As   (Read Only)
                | 
                | Retrieves the number of currently active exclusion regions.
                |

        :return:
        """
        return self.abq_smooth_coupling.NumExclusionRegions

    @property
    def num_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumSupports
                | o Property NumSupports(    ) As   (Read Only)
                | 
                | Retrieves the number of supports.
                |

        :return:
        """
        return self.abq_smooth_coupling.NumSupports

    @property
    def ur1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UR1
                | o Property UR1(    ) As
                | 
                | Returns or sets the UR1 degree of freedom.
                |

        :return:
        """
        return self.abq_smooth_coupling.UR1

    @ur1.setter
    def ur1(self, value):
        """
            :param type value:
        """
        self.abq_smooth_coupling.UR1 = value 

    @property
    def ur2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UR2
                | o Property UR2(    ) As
                | 
                | Returns or sets the UR2 degree of freedom.
                |

        :return:
        """
        return self.abq_smooth_coupling.UR2

    @ur2.setter
    def ur2(self, value):
        """
            :param type value:
        """
        self.abq_smooth_coupling.UR2 = value 

    @property
    def ur3(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UR3
                | o Property UR3(    ) As
                | 
                | Returns or sets the UR3 degree of freedom.
                |

        :return:
        """
        return self.abq_smooth_coupling.UR3

    @ur3.setter
    def ur3(self, value):
        """
            :param type value:
        """
        self.abq_smooth_coupling.UR3 = value 

    @property
    def local_csys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | localCsys
                | o Property localCsys(    ) As
                | 
                | Returns or sets the local coordinate system. If nothing is
                | passed in then it defaults to the global coordinate system.
                |

        :return:
        """
        return self.abq_smooth_coupling.localCsys

    @local_csys.setter
    def local_csys(self, value):
        """
            :param type value:
        """
        self.abq_smooth_coupling.localCsys = value 

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Adds a support to the coupling. If the support already
                | exists, it is removed from the coupling. If an attempt to
                | remove the last support is made, the support is maintained
                | and an error is returned.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the smooth coupling is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the smooth coupling is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_smooth_coupling.AddSupportFromPublication(i_product, i_publication)

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iReference,
                |                                       iSupport)
                | 
                | AddSupportFromReference - adds a support to the coupling. If
                | the support already exists, it is removed from the coupling.
                | If an attempt to remove the last support is made, the
                | support is maintained and an error is returned.
                |
                | Parameters:
                | iReference
                |       The reference to the product as a CATIAReference.
                |    
                |  iSupport
                |      The reference to the support as a CATIAReference.

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_smooth_coupling.AddSupportFromReference(i_reference, i_support)

    def clear_exclusion_regions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClearExclusionRegions
                | o Sub ClearExclusionRegions(    )
                | 
                | Clears the exclusion regions list.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_smooth_coupling.ClearExclusionRegions()

    def clear_handler(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClearHandler
                | o Sub ClearHandler(    )
                | 
                | Clears the handler.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_smooth_coupling.ClearHandler()

    def get_exclusion_regions(self, o_products, o_regions):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExclusionRegions
                | o Sub GetExclusionRegions(        oProducts,
                |                                   oRegions)
                | 
                | Returns the exclusion regions for the coupling. param
                | oProducts Returned safe array of products for the excluded
                | region, as CATIAReferences. This array has a one-to-one
                | mapping with the regions array.
                |
                | Parameters:
                | oRegions
                |     Returned safe array of regions to exclude, as CATIAReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param o_products:
        :param o_regions:
        :return:
        """
        return self.abq_smooth_coupling.GetExclusionRegions(o_products, o_regions)

    def get_handler(self, o_product, o_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHandler
                | o Sub GetHandler(        oProduct,
                |                          oRef)
                | 
                | Returns the handler for the coupling.
                |
                | Parameters:
                | oProduct
                |    The product for the handler.
                |  
                |  oRef
                |    The reference to the handler.

                |
        :param o_product:
        :param o_ref:
        :return:
        """
        return self.abq_smooth_coupling.GetHandler(o_product, o_ref)

    def get_local_csys_from_publication(self, o_product, o_pub_axis_system):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLocalCsysFromPublication
                | o Sub GetLocalCsysFromPublication(        oProduct,
                |                                           oPubAxisSystem)
                | 
                | Gets the published local coordinate system of for the
                | coupling.
                |
                | Parameters:
                | oProduct
                |      The CATIA Product specifying the local coordinate system publication.
                | 
                |  oPubAxisSystem
                |               The CATIA Axis system.
                |  Refer: CATIAAxisSystem

                |
        :param o_product:
        :param o_pub_axis_system:
        :return:
        """
        return self.abq_smooth_coupling.GetLocalCsysFromPublication(o_product, o_pub_axis_system)

    def get_supports(self, o_products, o_supports):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSupports
                | o Sub GetSupports(        oProducts,
                |                           oSupports)
                | 
                | Returns the supports for the coupling.
                |
                | Parameters:
                | oProducts
                |    Returned safe array of products for the supports, as CATIAReferences.  
                |    This array has a one-to-one mapping with the supports array.
                |  
                |  oSupports
                |    Returned safe array of supports, as CATIAReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param o_products:
        :param o_supports:
        :return:
        """
        return self.abq_smooth_coupling.GetSupports(o_products, o_supports)

    def set_exclusion_regions(self, i_products, i_regions):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExclusionRegions
                | o Sub SetExclusionRegions(        iProducts,
                |                                   iRegions)
                | 
                | Sets the exclusion regions for the coupling. Any previously
                | set exclusion regions will be replaced with this new list.
                | The list of excluded regions can be cleared by passing in
                | two empty lists for the products and the regions. Note: null
                | values for products and regions are not accepted.
                |
                | Parameters:
                | iProducts
                |    Safe array of products for the excluded region, as CATIAReferences.
                |    This array has a one-to-one mapping with the regions array.
                |  
                |  iRegions
                |     Safe array of regions to exclude, as CATIAReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param i_products:
        :param i_regions:
        :return:
        """
        return self.abq_smooth_coupling.SetExclusionRegions(i_products, i_regions)

    def set_handler(self, i_product, i_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandler
                | o Sub SetHandler(        iProduct,
                |                          iRef)
                | 
                | Sets the handler for the coupling. Any previously set
                | handler will be replaced with this new value.
                |
                | Parameters:
                | iProduct
                |    The product for the handler.
                |  
                |  iRef
                |    The reference to the handler.

                |
        :param i_product:
        :param i_ref:
        :return:
        """
        return self.abq_smooth_coupling.SetHandler(i_product, i_ref)

    def set_handler_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandlerFromPublication
                | o Sub SetHandlerFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Sets the handler for the coupling. Any previously set
                | handler will be replaced with this new value.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product for handeler.
                | 
                |  iPublication
                |               The CATIA Publication for handeler.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_smooth_coupling.SetHandlerFromPublication(i_product, i_publication)

    def set_local_csys_from_publication(self, i_product, i_pub_axis_system):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLocalCsysFromPublication
                | o Sub SetLocalCsysFromPublication(        iProduct,
                |                                           iPubAxisSystem)
                | 
                | Sets the published local coordinate system for the coupling.
                | Fails if the publication is not an axis system.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the local coordinate system publication.
                | 
                |  iPublication
                |               The CATIA Publication on the axis system.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_pub_axis_system:
        :return:
        """
        return self.abq_smooth_coupling.SetLocalCsysFromPublication(i_product, i_pub_axis_system)

    def set_supports(self, i_products, i_regions):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSupports
                | o Sub SetSupports(        iProducts,
                |                           iRegions)
                | 
                | Sets the support regions for the coupling. Any previously
                | set support regions will be replaced with this new list. At
                | least one item in the list is required.
                |
                | Parameters:
                | iProducts
                |    Safe array of products for the support region as CATIAReferences.  
                |    This array has a one-to-one mapping with the regions array.
                |  
                |  iRegions
                |     Safe array of supports as CATIAReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param i_products:
        :param i_regions:
        :return:
        """
        return self.abq_smooth_coupling.SetSupports(i_products, i_regions)

    def __repr__(self):
        return f'ABQSmoothCoupling()'
