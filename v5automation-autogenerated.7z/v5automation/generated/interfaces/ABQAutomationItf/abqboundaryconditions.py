#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQBoundaryConditions(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of Abaqus boundary condition objects attached toactivat
                | eLinkAnchor('ABQGeneralStaticStep','','ABQGeneralStaticStep'),activate
                | LinkAnchor('ABQHeatTransferStep','','ABQHeatTransferStep'), andactivat
                | eLinkAnchor('ABQExplicitDynamicsStep','','ABQExplicitDynamicsStep')obj
                | ect.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_boundary_conditions = com_object     

    def add(self, i_boundary_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iBoundaryType) As
                | 
                | Creates a new Abaqus boundary condition and adds it to the
                | collection of Abaqus boundary conditions.
                |
                | Parameters:
                | iBoundaryType
                |     The type of the boundary condition to create. 
                |  Legal values:
                |  
                |  "ABQClamp"
                |   "ABQDisplacementBC"
                |   "ABQTemperatureBC"
                | 
                | 
                | 
                |  Returns:
                |   oBoundaryCondition    The Abaqus boundary condition object that was created.

                |                | Examples:
                | The following example creates a clamp boundary condition in
                | the ABQBoundaryConditions collection: Dim abaqusBCs As
                | ABQBoundaryConditions Dim abqClampBC As ABQClampBC Set
                | abqClampBC = abaqusBCs.Add("ABQClamp")

        :param i_boundary_type:
        :return:
        """
        return self.abq_boundary_conditions.Add(i_boundary_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus boundary condition using its index or its
                | name from the collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus boundary condition to retrieve from
                |    the collection of Abaqus boundary conditions.
                |    If the index is a number, it specifies the rank of the Abaqus boundary condition
                |    in the collection. The index of the first Abaqus boundary condition in the collection is 1,
                |    and the index of the last boundary condition is Count.
                |    If the index is a string, it specifies the name you assigned to the boundary condition using
                |    the CATIACollection::Name property.
                |  
                | 
                |  Returns:
                |   The specified 
                | .

                |
        :param i_index:
        :return:
        """
        return self.abq_boundary_conditions.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes an Abaqus boundary condition using its index or its
                | name from the collection of boundary conditions.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus boundary condition to retrieve from
                |    the collection of Abaqus boundary conditions.
                |    If the index is a number, it specifies the rank of the Abaqus boundary condition
                |    in the collection. The index of the first Abaqus boundary condition in the collection is 1,
                |    and the index of the last boundary condition is Count.
                |    If the index is a string, it specifies the name you assigned to the boundary condition using
                |    the CATIACollection::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_boundary_conditions.Remove(i_index)

    def __repr__(self):
        return f'ABQBoundaryConditions()'
