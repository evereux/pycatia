#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQPretensionProperty(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a pretension property (ABQPretensionProperty)
                | object.Role:Access an Abaqus pretension property.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_pretension_property = com_object     

    def add_support_from_product(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromProduct
                | o Sub AddSupportFromProduct(        iProduct,
                |                                     iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | bolt pretension property.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the bolt pretension property is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the bolt pretension property is applied.
                |  Refer: CATIAReference, CATIAProduct

                |
        :param i_product:
        :param i_support:
        :return:
        """
        return self.abq_pretension_property.AddSupportFromProduct(i_product, i_support)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Creates a new support and adds it to the description of the
                | bolt pretension property.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the bolt pretension property is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the bolt pretension property is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_pretension_property.AddSupportFromPublication(i_product, i_publication)

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iReference,
                |                                       iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | bolt pretension property.
                |
                | Parameters:
                | iReference
                |      The CATIA Reference specifying the object to which the bolt pretension property is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the bolt pretension property is applied.
                |  Refer: CATIAReference

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_pretension_property.AddSupportFromReference(i_reference, i_support)

    def clear_cutting_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClearCuttingPlane
                | o Sub ClearCuttingPlane(    )
                | 
                | Clears the cutting plane.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_pretension_property.ClearCuttingPlane()

    def set_cutting_plane(self, i_product, i_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCuttingPlane
                | o Sub SetCuttingPlane(        iProduct,
                |                               iRef)
                | 
                | Sets the cutting plane for the bolt pretension property.
                | Cutting plane will be needed in case user wants to model
                | pretension in 3D bolt. Any previously set plane will be
                | replaced with this new value.
                |
                | Parameters:
                | iProduct
                |    The product for the plane.
                |  
                |  iRef
                |    The reference to the plane.

                |
        :param i_product:
        :param i_ref:
        :return:
        """
        return self.abq_pretension_property.SetCuttingPlane(i_product, i_ref)

    def __repr__(self):
        return f'ABQPretensionProperty()'
