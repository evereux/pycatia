#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQExplicitDynamicsStep(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus explicit dynamics step (ABQExplicitDynamicsStep)
                | object.Role:Access an Abaqus explicit dynamics step object or
                | determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_explicit_dynamics_step = com_object     

    @property
    def auto_time_increment_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoTimeIncrementMethod
                | o Property AutoTimeIncrementMethod(    ) As
                | 
                | Sets or returns the automatic time increment estimator
                | method. Applies only when TimeIncrementationMethod is
                | AUTO_INCREMENT. Legal values: ABQ_ATI_GLOBAL
                | ABQ_ATI_ELEMENT_BY_ELEMENT
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.AutoTimeIncrementMethod

    @property
    def boundary_conditions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BoundaryConditions
                | o Property BoundaryConditions(    ) As   (Read Only)
                | 
                | Returns the ABQBoundaryConditions container associated with
                | the step. Example: This example retrieves the
                | ABQBoundaryConditions container abqBCs. Dim abqStep As
                | ABQExplicitDynamicsStep Dim abqBCs As ABQBoundaryConditions
                | Set abqBCs = abqStep.BoundaryConditions
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.BoundaryConditions

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As
                | 
                | Sets or returns the description of the Abaqus explicit
                | dynamics step. Returns: The description of the Abaqus
                | explicit dynamics step.
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.Description

    @property
    def fields(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Fields
                | o Property Fields(    ) As   (Read Only)
                | 
                | Returns the ABQFields container associated with the step.
                | Example: This example retrieves the ABQFields container
                | abqFields. Dim abqStep As ABQExplicitDynamicsStep Dim
                | abqFields As ABQFields Set abqFields = abqStep.Fields
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.Fields

    @property
    def fixed_time_increment_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FixedTimeIncrementMethod
                | o Property FixedTimeIncrementMethod(    ) As
                | 
                | Sets or returns the fixed time increment method. Applies
                | only when TimeIncrementationMethod is FIXED_INCREMENT. If
                | the method is set to ABQ_FTI_USER_DEFINED, the
                | UserDefinedTimeIncrementValue property must be set to
                | specifiy the time increment value.
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.FixedTimeIncrementMethod

    @property
    def loads(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Loads
                | o Property Loads(    ) As   (Read Only)
                | 
                | Returns the ABQLoads container associated with the step.
                | Example: The following example retrieves the ABQLoads
                | container abqLoads: Dim abqStep As ABQExplicitDynamicsStep
                | Dim abqLoads As ABQLoads Set abqLoads = abqStep.Loads
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.Loads

    @property
    def maximum_time_increment_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaximumTimeIncrementLimit
                | o Property MaximumTimeIncrementLimit(    ) As
                | 
                | Sets or returns the maximum time increment limit. Applies
                | only when TimeIncrementationMethod is AUTO_INCREMENT. Zero
                | specifies that the maximum time increment is unlimited.
                | Returns: The maximum time increment limit.
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.MaximumTimeIncrementLimit

    @property
    def nl_geom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NLGeom
                | o Property NLGeom(    ) As
                | 
                | Sets or returns whether the geometry remains linear during
                | the analysis. A value of true indicates that the geometry
                | remains linear. Returns: A boolean specifying whether the
                | geometry remains linear during the analysis.
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.NLGeom

    @property
    def time_incrementation_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimeIncrementationMethod
                | o Property TimeIncrementationMethod(    ) As
                | 
                | Sets or returns the type of the incrementation during the
                | step. Returns: The type of the incrementation Legal values:
                | AUTO_INCREMENT FIXED_INCREMENT
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.TimeIncrementationMethod

    @property
    def time_period(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimePeriod
                | o Property TimePeriod(    ) As
                | 
                | Sets or returns the total time period of the Abaqus explicit
                | dynamics step. Returns: The total time period of the Abaqus
                | explicit dynamics step.
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.TimePeriod

    @property
    def time_scaling_factor(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimeScalingFactor
                | o Property TimeScalingFactor(    ) As
                | 
                | Sets or returns the time scaling factor.
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.TimeScalingFactor

    @property
    def user_defined_time_increment_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UserDefinedTimeIncrementValue
                | o Property UserDefinedTimeIncrementValue(    ) As
                | 
                | Sets or returns the user-defined time increment value.
                | Applies only when FixedTimeIncrementMethod is set to
                | ABQ_FTI_USER_DEFINED.
                |

        :return:
        """
        return self.abq_explicit_dynamics_step.UserDefinedTimeIncrementValue

    def __repr__(self):
        return f'ABQExplicitDynamicsStep()'
