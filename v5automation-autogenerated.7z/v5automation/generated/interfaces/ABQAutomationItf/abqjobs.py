#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQJobs(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of Abaqus (ABQJob) objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_jobs = com_object     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As
                | 
                | Creates a new Abaqus job and adds it to the collection of
                | Abaqus jobs. Returns: oJob The Abaqus job object that was
                | created. Example: The following example creates a job in the
                | ABQJobs collection: Dim abaqusJobs As ABQJobs Dim abqJob As
                | ABQJob Set abaqusJobs = abqCase.Jobs Set abqJob =
                | abaqusJobs.Add()
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_jobs.Add()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus job using its index or its name from the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus job to retrieve from
                |    the collection of Abaqus jobs.
                |    If the index is a number, it specifies the rank of the Abaqus job
                |    in the collection. The index of the first Abaqus job in the collection is 1,
                |    and the index of the last job is Count.
                |    If the index is a string, it specifies the name you assigned to the job using
                |    the CATIACollection::Name property.
                |  
                | 
                |  Returns:
                |   oJob The specified 
                | .

                |
        :param i_index:
        :return:
        """
        return self.abq_jobs.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes an Abaqus Job using its index or its name from the
                | job collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the job to retrieve from
                |    the collection of jobs.
                |    As a numeric, this index is the rank of the job
                |    in the collection. The index of the first job in the collection is 1,
                |    and the index of the last job is Count.
                |    As a string, it is the name you assigned to the job using
                |    the CATIABase::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_jobs.Remove(i_index)

    def __repr__(self):
        return f'ABQJobs()'
