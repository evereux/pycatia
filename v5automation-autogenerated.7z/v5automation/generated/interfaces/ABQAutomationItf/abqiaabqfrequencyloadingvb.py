#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQIAABQFrequencyLoadingVB(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | ABQIAABQFrequencyLoading are ...Do not use the
                | ABQIAABQFrequencyLoading interface for such and such ClassReference,
                | Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abqiaabq_frequency_loading_vb = com_object     

    @property
    def dof(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DOF
                | o Property DOF(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_frequency_loading_vb.DOF

    @property
    def data_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DataType
                | o Property DataType(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_frequency_loading_vb.DataType

    @property
    def frequency_data_values(self, i_freq_data_val):
        """
        .. note::
            CAA V5 Visual Basic help

                | FrequencyDataValues
                | o Property FrequencyDataValues(        iFreqDataVal) (Write Only)
                | 
                |

        :param i_freq_data_val:
        :return:
        """
        return self.abqiaabq_frequency_loading_vb.FrequencyDataValues

    @property
    def imaginary_data_values(self, i_imaginary_data_values):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImaginaryDataValues
                | o Property ImaginaryDataValues(        iImaginaryDataValues) (Write Only)
                | 
                |

        :param i_imaginary_data_values:
        :return:
        """
        return self.abqiaabq_frequency_loading_vb.ImaginaryDataValues

    @property
    def real_data_values(self, i_real_data_val):
        """
        .. note::
            CAA V5 Visual Basic help

                | RealDataValues
                | o Property RealDataValues(        iRealDataVal) (Write Only)
                | 
                |

        :param i_real_data_val:
        :return:
        """
        return self.abqiaabq_frequency_loading_vb.RealDataValues

    @property
    def scale(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Scale
                | o Property Scale(    ) As
                | 
                |

        :return:
        """
        return self.abqiaabq_frequency_loading_vb.Scale

    def __repr__(self):
        return f'ABQIAABQFrequencyLoadingVB()'
