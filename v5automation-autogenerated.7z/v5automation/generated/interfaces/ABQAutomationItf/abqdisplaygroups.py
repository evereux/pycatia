#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQDisplayGroups(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of display groups under the abaqus analysis case

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_display_groups = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an display group using its index or its name from
                | the collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the display group to retrieve from
                |    the collection of display groups.
                |    If the index is a number, it specifies the rank of the display group
                |    in the collection. The index of the first display group in the collection is 1,
                |    and the index of the last display group is Count.
                |    If the index is a string, it specifies the name you assigned to the display group using
                |    the CATIACollection::Name property.
                |    
                |  
                | 
                |  Returns:
                |   The specified 
                | .

                |
        :param i_index:
        :return:
        """
        return self.abq_display_groups.Item(i_index)

    def __repr__(self):
        return f'ABQDisplayGroups()'
