#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQSmoothStepAmplitude(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a smooth step amplitude (ABQSmoothStepAmplitude)
                | object.Role:Access an Abaqus smooth step amplitude or determine its
                | properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_smooth_step_amplitude = com_object     

    @property
    def time_amplitude_table_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimeAmplitudeTableSize
                | o Property TimeAmplitudeTableSize(    ) As   (Read Only)
                | 
                | Returns the size of the time/amplitude table. Returns: The
                | size of the time/amplitude table.
                |

        :return:
        """
        return self.abq_smooth_step_amplitude.TimeAmplitudeTableSize

    @property
    def time_span(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimeSpan
                | o Property TimeSpan(    ) As
                | 
                | Sets or returns the timespan in smooth step amplitude.
                | Returns: The timespan Legal values: STEP_TIME TOTAL_TIME
                |

        :return:
        """
        return self.abq_smooth_step_amplitude.TimeSpan

    def add_time_amplitude_table(self, i_time, i_amplitude):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddTimeAmplitudeTable
                | o Sub AddTimeAmplitudeTable(        iTime,
                |                                     iAmplitude)
                | 
                | Adds a list of time and amplitude for the specified time
                | span STEP_TIME or TOTAL_TIME The number of values in both of
                | the parameters must match. If either list contains extra
                | values, the extra values are discarded.
                |
                | Parameters:
                | iTime
                |      The list of times.
                | 
                |  iAmplitude
                |               The  list of amplitudes.

                |
        :param i_time:
        :param i_amplitude:
        :return:
        """
        return self.abq_smooth_step_amplitude.AddTimeAmplitudeTable(i_time, i_amplitude)

    def get_time_amplitude_table(self, o_time, o_amplitude):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTimeAmplitudeTable
                | o Sub GetTimeAmplitudeTable(        oTime,
                |                                     oAmplitude)
                | 
                | Returns a list of time and amplitude for the specified
                | timespan (STEP_TIME or TOTAL_TIME).
                |
                | Parameters:
                | oTime
                |      The list of times.
                | 
                |  oTemperature
                |               The list of amplitudes.

                |
        :param o_time:
        :param o_amplitude:
        :return:
        """
        return self.abq_smooth_step_amplitude.GetTimeAmplitudeTable(o_time, o_amplitude)

    def __repr__(self):
        return f'ABQSmoothStepAmplitude()'
