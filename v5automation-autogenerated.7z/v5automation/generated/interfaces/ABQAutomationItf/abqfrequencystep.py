#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQFrequencyStep(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus frequency step (ABQFrequencyStep)
                | object.Role:Access an Abaqus frequency step object or determine its
                | properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_frequency_step = com_object     

    @property
    def boundary_conditions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BoundaryConditions
                | o Property BoundaryConditions(    ) As   (Read Only)
                | 
                | Returns the ABQBoundaryConditions container associated with
                | the step. Example: This example retrieves the
                | ABQBoundaryConditions container abqBCs. Dim abqFreqStep As
                | ABQFrequencyStep Dim abqBCs As ABQBoundaryConditions Set
                | abqBCs = abqFreqStep.BoundaryConditions
                |

        :return:
        """
        return self.abq_frequency_step.BoundaryConditions

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As
                | 
                | Returns or sets the description of the Abaqus general static
                | step. Returns: The description of the Abaqus general static
                | step.
                |

        :return:
        """
        return self.abq_frequency_step.Description

    @description.setter
    def description(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.Description = value 

    @property
    def eigensolver_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EigensolverValue
                | o Property EigensolverValue(    ) As
                | 
                | Returns or sets Eigensolver Value. Returns: The Eigensolver
                | Value. Legal values: 1 - Lanczos. 2 - AMS. Example: This
                | example sets eigensolver as Lanczos abqFreqStep
                | abqFreqStep.EigensolverValue = 1
                |

        :return:
        """
        return self.abq_frequency_step.EigensolverValue

    @eigensolver_value.setter
    def eigensolver_value(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.EigensolverValue = value 

    @property
    def frequency_shift(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FrequencyShift
                | o Property FrequencyShift(    ) As
                | 
                | Returns or sets frequency shift value. Returns: The
                | frequency shift value. Example: This example sets the
                | maximum frequency for abqFreqStep abqFreqStep.FrequencyShift
                | = 10
                |

        :return:
        """
        return self.abq_frequency_step.FrequencyShift

    @frequency_shift.setter
    def frequency_shift(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.FrequencyShift = value 

    @property
    def loads(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Loads
                | o Property Loads(    ) As   (Read Only)
                | 
                | Returns the ABQLoads container associated with the step.
                | Example: The following example retrieves the ABQLoads
                | container abqLoads: Dim abqFreqStep As ABQFrequencyStep Dim
                | abqLoads As ABQLoads Set abqLoads = abqFreqStep.Loads
                |

        :return:
        """
        return self.abq_frequency_step.Loads

    @property
    def maximum_frequency(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaximumFrequency
                | o Property MaximumFrequency(    ) As
                | 
                | Returns or sets maximum frequency value. Returns: The
                | maximum frequency value. Example: This example sets the
                | maximum frequency for abqFreqStep
                | abqFreqStep.MaximumFrequency = 100
                |

        :return:
        """
        return self.abq_frequency_step.MaximumFrequency

    @maximum_frequency.setter
    def maximum_frequency(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.MaximumFrequency = value 

    @property
    def minimum_frequency(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MinimumFrequency
                | o Property MinimumFrequency(    ) As
                | 
                | Returns or sets minimum frequency value. Returns: The
                | minimum frequency value. Example: This example sets the
                | minimum frequency for abqFreqStep
                | abqFreqStep.MinimumFrequency = 10
                |

        :return:
        """
        return self.abq_frequency_step.MinimumFrequency

    @minimum_frequency.setter
    def minimum_frequency(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.MinimumFrequency = value 

    @property
    def normalization_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NormalizationValue
                | o Property NormalizationValue(    ) As
                | 
                | Returns or sets Normalization Value. Returns: The
                | Normalization Value. Legal values: 1 - Displacement. 2 -
                | Mass. Example: This example sets Normalization as
                | Displacement abqFreqStep abqFreqStep.NormalizationValue = 1
                |

        :return:
        """
        return self.abq_frequency_step.NormalizationValue

    @normalization_value.setter
    def normalization_value(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.NormalizationValue = value 

    @property
    def requested_modes_option(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RequestedModesOption
                | o Property RequestedModesOption(    ) As
                | 
                | Sets or returns the requested modes option. Returns: The
                | option of requested modes. Legal values: ABQ_ALL - All
                | modes. ABQ_VALUE - Specify the no of modes to be requested.
                | Example: This example sets the requested modes option for
                | abqFreqStep job to every increment.
                | abqFreqStep.RequestedModesOption = ABQ_ALL
                |

        :return:
        """
        return self.abq_frequency_step.RequestedModesOption

    @requested_modes_option.setter
    def requested_modes_option(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.RequestedModesOption = value 

    @property
    def requested_modes_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RequestedModesValue
                | o Property RequestedModesValue(    ) As
                | 
                | Returns or sets requested modes value. This is only valid if
                | RestartRequestOption is ABQ_VALUE Returns: The requested
                | modes value. Example: This example sets the requested modes
                | for abqFreqStep abqFreqStep.RequestedModesValue = 10
                |

        :return:
        """
        return self.abq_frequency_step.RequestedModesValue

    @requested_modes_value.setter
    def requested_modes_value(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.RequestedModesValue = value 

    @property
    def residual_mode_req_boolean(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ResidualModeReqBoolean
                | o Property ResidualModeReqBoolean(    ) As
                | 
                | Returns or sets Residual Mode Request Boolean Value.
                | Returns: The Residual Mode Request Boolean Value.
                |

        :return:
        """
        return self.abq_frequency_step.ResidualModeReqBoolean

    @residual_mode_req_boolean.setter
    def residual_mode_req_boolean(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.ResidualModeReqBoolean = value 

    @property
    def sim_architecture_req_boolean(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SIMArchitectureReqBoolean
                | o Property SIMArchitectureReqBoolean(    ) As
                | 
                | Returns or sets SIM Architecture Request Boolean Value.
                | Returns: The SIM Architecture Request Boolean Value.
                |

        :return:
        """
        return self.abq_frequency_step.SIMArchitectureReqBoolean

    @sim_architecture_req_boolean.setter
    def sim_architecture_req_boolean(self, value):
        """
            :param type value:
        """
        self.abq_frequency_step.SIMArchitectureReqBoolean = value 

    def add_residual_mode_region(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddResidualModeRegion
                | o Sub AddResidualModeRegion(        iProduct,
                |                                     iSupport)
                | 
                | Adds the Residual Mode Region.
                |
                | Parameters:
                | iProduct
                |      The CATIAProduct specifying the positioning object.
                | 
                |  iSupport
                |    The CATIAReference specifying the object that is being pointed to.

                |
        :param i_product:
        :param i_support:
        :return:
        """
        return self.abq_frequency_step.AddResidualModeRegion(i_product, i_support)

    def add_residual_mode_region_dof(self, i_dof, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddResidualModeRegionDOF
                | o Sub AddResidualModeRegionDOF(        iDOF,
                |                                        iIndex)
                | 
                | Adds the Residual Mode Region DOF.
                |
                | Parameters:
                | iDOF
                |      The DOF.
                | 
                |  iIndex
                |    The index at which the DOF is being set.

                |
        :param i_dof:
        :param i_index:
        :return:
        """
        return self.abq_frequency_step.AddResidualModeRegionDOF(i_dof, i_index)

    def __repr__(self):
        return f'ABQFrequencyStep()'
