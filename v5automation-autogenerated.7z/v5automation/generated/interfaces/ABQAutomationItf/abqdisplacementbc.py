#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQDisplacementBC(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus displacement boundary condition
                | (ABQDisplacementBC) object.Role:Access an Abaqus displacement boundary
                | condition object or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_displacement_bc = com_object     

    @property
    def uselocal_csys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UselocalCsys
                | o Property UselocalCsys(    ) As
                | 
                | Sets or returns a boolean indicating whether local
                | coordinate system is used in Displacement BC Returns:
                | boolean specifying whether local csys is active.
                |

        :return:
        """
        return self.abq_displacement_bc.UselocalCsys

    @property
    def local_csys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | localCsys
                | o Property localCsys(    ) As
                | 
                | Sets or returns the local coordinate system of the boundary
                | condition's degrees of freedom. Returns: The local
                | coordinate system.
                |

        :return:
        """
        return self.abq_displacement_bc.localCsys

    @property
    def u1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | u1
                | o Property u1(    ) As
                | 
                | Sets or returns the first translational component. Returns:
                | The first translational component.
                |

        :return:
        """
        return self.abq_displacement_bc.u1

    @property
    def u2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | u2
                | o Property u2(    ) As
                | 
                | Sets or returns the second translational component. Returns:
                | The second translational component.
                |

        :return:
        """
        return self.abq_displacement_bc.u2

    @property
    def u3(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | u3
                | o Property u3(    ) As
                | 
                | Sets or returns the third translational component. Returns:
                | The third translational component.
                |

        :return:
        """
        return self.abq_displacement_bc.u3

    @property
    def ur1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ur1
                | o Property ur1(    ) As
                | 
                | Sets or returns the first rotational component. Returns: The
                | second rotational component.
                |

        :return:
        """
        return self.abq_displacement_bc.ur1

    @property
    def ur2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ur2
                | o Property ur2(    ) As
                | 
                | Sets or returns the second rotational component. Returns:
                | The second rotational component.
                |

        :return:
        """
        return self.abq_displacement_bc.ur2

    @property
    def ur3(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ur3
                | o Property ur3(    ) As
                | 
                | Sets or returns the third rotational component. Returns: The
                | third rotational component.
                |

        :return:
        """
        return self.abq_displacement_bc.ur3

    def get_dof_activation(self, i_dof, o_flag):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDOFActivation
                | o Sub GetDOFActivation(        iDOF,
                |                                oFlag)
                | 
                | Gets the activation of a DOF for Displacement BC
                |
                | Parameters:
                | iDOF
                |      The DOF number from 1 to 6, in order U1 = 1,...., UR3 = 6.
                | 
                |  oFlag
                |               DOF activation status true or false.

                |
        :param i_dof:
        :param o_flag:
        :return:
        """
        return self.abq_displacement_bc.GetDOFActivation(i_dof, o_flag)

    def get_local_csys_from_publication(self, o_product, o_pub_axis_system):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLocalCsysFromPublication
                | o Sub GetLocalCsysFromPublication(        oProduct,
                |                                           oPubAxisSystem)
                | 
                | Gets the published local coordinate system of the
                | Displacement BC.
                |
                | Parameters:
                | oProduct
                |      The CATIA Product specifying the local coordinate system publication.
                | 
                |  oPubAxisSystem
                |               The CATIA Axis system.
                |  Refer: CATIAAxisSystem

                |
        :param o_product:
        :param o_pub_axis_system:
        :return:
        """
        return self.abq_displacement_bc.GetLocalCsysFromPublication(o_product, o_pub_axis_system)

    def get_use_coordinate_system_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUseCoordinateSystemType
                | o Func GetUseCoordinateSystemType(    ) As
                | 
                | Get the user coordinate system type.
                |
                | Parameters:
                | oCsystemType
                |  e.g. ABQ_CARTESIAN (for Cartesian coordinate system),						   ABQ_CYLINDRICAL (for Cylindrical coordinate system),
                | 						   ABQ_SPHERICAL (for Spherical coordinate system),

                |
        :return:
        """
        return self.abq_displacement_bc.GetUseCoordinateSystemType()

    def set_dof_activation(self, i_dof, i_flag):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDOFActivation
                | o Sub SetDOFActivation(        iDOF,
                |                                iFlag)
                | 
                | Sets the activation of a DOF for Displacement BC
                |
                | Parameters:
                | iDOF
                |      The DOF number from 1 to 6, in order U1 = 1,...., UR3 = 6.
                | 
                |  iFlag
                |               DOF activation status true or false.

                |
        :param i_dof:
        :param i_flag:
        :return:
        """
        return self.abq_displacement_bc.SetDOFActivation(i_dof, i_flag)

    def set_local_csys_from_publication(self, i_product, i_pub_axis_system):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLocalCsysFromPublication
                | o Sub SetLocalCsysFromPublication(        iProduct,
                |                                           iPubAxisSystem)
                | 
                | Sets the published local coordinate system of the
                | Displacement BC. Returns: Fails if the publication is not on
                | the axis system.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the local coordinate system publication.
                | 
                |  iPublication
                |               The CATIA Publication on the axis system.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_pub_axis_system:
        :return:
        """
        return self.abq_displacement_bc.SetLocalCsysFromPublication(i_product, i_pub_axis_system)

    def set_use_coordinate_system_type(self, i_csystem_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUseCoordinateSystemType
                | o Sub SetUseCoordinateSystemType(        iCsystemType)
                | 
                | Set the user coordinate system type.
                |
                | Parameters:
                | iCsystemType
                |  e.g. ABQ_CARTESIAN (for Cartesian coordinate system),						   ABQ_CYLINDRICAL (for Cylindrical coordinate system),
                | 						   ABQ_SPHERICAL (for Spherical coordinate system),

                |
        :param i_csystem_type:
        :return:
        """
        return self.abq_displacement_bc.SetUseCoordinateSystemType(i_csystem_type)

    def __repr__(self):
        return f'ABQDisplacementBC()'
