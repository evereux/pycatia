#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQInitialTemperature(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus initial temperature object
                | (ABQInitialTemperature).Role:Access an Abaqus initial temperature
                | object or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_initial_temperature = com_object     

    @property
    def step_num(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StepNum
                | o Property StepNum(    ) As
                | 
                | Sets or returns the step number from which to read the
                | temperature data.
                |

        :return:
        """
        return self.abq_initial_temperature.StepNum

    def __repr__(self):
        return f'ABQInitialTemperature()'
