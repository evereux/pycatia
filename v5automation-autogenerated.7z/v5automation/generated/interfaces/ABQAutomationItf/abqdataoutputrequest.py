#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQDataOutputRequest(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus data output request (ABQDataOutputRequest)
                | object.Role:Access an Abaqus data output request object or determine
                | its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_data_output_request = com_object     

    def set_specified_output_variables(self, i_variable_name_bstr, i_dat_output_var_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSpecifiedOutputVariables
                | o Sub SetSpecifiedOutputVariables(        iVariableNameBSTR,
                |                                           iDatOutputVarType)
                | 
                | Sets the specified variables and category type for which
                | results are requested.
                |
                | Parameters:
                | iVariableNameBSTR
                |     The list of variables for which output is requested
                |     For example: If user wants to request for output for variables 'U' and 'S', 
                |     then iVariableNameBSTR will be "U, S"
                |  
                |  iDatOutputVarType
                |     The variable type: Node based, Element based etc.  
                |  Legal values:
                |  
                | "DATOUTPUTTYPE_NODE"
                | "DATOUTPUTTYPE_ELEMENT"
                | "DATOUTPUTTYPE_CONTACT"
                | "DATOUTPUTTYPE_ENERGY"

                |
        :param i_variable_name_bstr:
        :param i_dat_output_var_type:
        :return:
        """
        return self.abq_data_output_request.SetSpecifiedOutputVariables(i_variable_name_bstr, i_dat_output_var_type)

    def unset_output_type(self, i_dat_output_var_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetOutputType
                | o Sub UnsetOutputType(        iDatOutputVarType)
                | 
                | Unset the data output request for specified type
                |
                | Parameters:
                | iDatOutputVarType
                |     The variable type: Node based, Element based etc. 
                |     User can unset the request for the variable type, if user does not want result for this type and
                |     it it was requested in previous step
                |  Legal values:
                |  
                | "DATOUTPUTTYPE_NODE"
                | "DATOUTPUTTYPE_ELEMENT"
                | "DATOUTPUTTYPE_CONTACT"
                | "DATOUTPUTTYPE_ENERGY"

                |
        :param i_dat_output_var_type:
        :return:
        """
        return self.abq_data_output_request.UnsetOutputType(i_dat_output_var_type)

    def __repr__(self):
        return f'ABQDataOutputRequest()'
