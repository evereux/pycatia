#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQLoad(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the base interface for all load objects.Role:The ABQLoad
                | interface manages the common properties  of any load.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_load = com_object     

    @property
    def activation_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActivationStatus
                | o Property ActivationStatus(    ) As
                | 
                | Sets or returns the activation status. Returns: A boolean
                | specifying whether the pressure is activated.
                |

        :return:
        """
        return self.abq_load.ActivationStatus

    @property
    def amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Amplitude
                | o Property Amplitude(    ) As
                | 
                | Sets or returns the amplitude, given the name of the
                | amplitude. Returns: The amplitude object selected.
                |

        :return:
        """
        return self.abq_load.Amplitude

    @property
    def regions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Regions
                | o Property Regions(    ) As   (Read Only)
                | 
                | Returns the region to which the load is applied. Returns:
                | The region.
                |

        :return:
        """
        return self.abq_load.Regions

    @property
    def smooth_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SmoothAmplitude
                | o Property SmoothAmplitude(    ) As
                | 
                | Sets or returns the Smooth Amplitude, given the refernce of
                | the Smooth amplitude. Returns: The amplitude object
                | selected.
                |

        :return:
        """
        return self.abq_load.SmoothAmplitude

    @property
    def status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Status
                | o Property Status(    ) As   (Read Only)
                | 
                | Returns the propagating status of the load. Returns: The
                | propagating status for example: if the load feature is
                | created, it will return "CREATED" if the load feature is
                | propagated from previous step, it will return "PROPAGATED"
                |

        :return:
        """
        return self.abq_load.Status

    @property
    def tabular_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TabularAmplitude
                | o Property TabularAmplitude(    ) As
                | 
                | Sets or returns the amplitude, given the Tabular amplitude
                | refrence. Returns: The amplitude object selected.
                |

        :return:
        """
        return self.abq_load.TabularAmplitude

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the type of the load. Returns: The type of the load.
                |

        :return:
        """
        return self.abq_load.Type

    @property
    def use_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseAmplitude
                | o Property UseAmplitude(    ) As
                | 
                | Sets or returns a boolean indicating whether amplitude is
                | used in a load Returns: boolean specifying whether user
                | defined amplitude is active.
                |

        :return:
        """
        return self.abq_load.UseAmplitude

    def add_support_from_product(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromProduct
                | o Sub AddSupportFromProduct(        iProduct,
                |                                     iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the load is applied.
                | 
                |  iSupport
                |               The CATIA Reference specifying the region to which the load is applied.
                |  Refer: CATIAReference , CATIAProduct

                |
        :param i_product:
        :param i_support:
        :return:
        """
        return self.abq_load.AddSupportFromProduct(i_product, i_support)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the load is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the load is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_load.AddSupportFromPublication(i_product, i_publication)

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iReference,
                |                                       iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iReference
                |      The CATIA Reference specifying the object to which the load is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the load is applied.
                |  Refer: CATIAReference

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_load.AddSupportFromReference(i_reference, i_support)

    def __repr__(self):
        return f'ABQLoad()'
