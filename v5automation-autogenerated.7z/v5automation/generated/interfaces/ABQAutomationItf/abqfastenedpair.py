#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQFastenedPair(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus Fastened Pair (ABQFastenedPair) object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_fastened_pair = com_object     

    @property
    def adjust_slave_node(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AdjustSlaveNode
                | o Property AdjustSlaveNode(    ) As
                | 
                | Sets or returns the adjust slave node flag.
                |

        :return:
        """
        return self.abq_fastened_pair.AdjustSlaveNode

    @property
    def connection_property(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectionProperty
                | o Property ConnectionProperty(    ) As
                | 
                | This property has been deprecated. Use the
                | AddSupportFromAnalysisEntity instead.
                |

        :return:
        """
        return self.abq_fastened_pair.ConnectionProperty

    @property
    def formulation_option(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FormulationOption
                | o Property FormulationOption(    ) As
                | 
                | Sets or returns the formulation option. Returns: The
                | formulation option. Legal values: SOLVERDEFAULT
                | SURFACETOSURFACE NODETOSURFACE
                |

        :return:
        """
        return self.abq_fastened_pair.FormulationOption

    @property
    def include_shell_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IncludeShellThickness
                | o Property IncludeShellThickness(    ) As
                | 
                | Sets or returns the include shell element thickness flag.
                |

        :return:
        """
        return self.abq_fastened_pair.IncludeShellThickness

    @property
    def invert_master_surface(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InvertMasterSurface
                | o Property InvertMasterSurface(    ) As
                | 
                | Sets or returns the invert master surface flag.
                |

        :return:
        """
        return self.abq_fastened_pair.InvertMasterSurface

    @property
    def invert_slave_surface(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InvertSlaveSurface
                | o Property InvertSlaveSurface(    ) As
                | 
                | Sets or returns the invert slave surface flag.
                |

        :return:
        """
        return self.abq_fastened_pair.InvertSlaveSurface

    @property
    def position_tolerance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PositionTolerance
                | o Property PositionTolerance(    ) As
                | 
                | Sets or returns the position tolerance. Returns: The
                | position tolerance Legal values: COMPUTED SPECIFIED
                |

        :return:
        """
        return self.abq_fastened_pair.PositionTolerance

    @property
    def position_tolerance_val(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PositionToleranceVal
                | o Property PositionToleranceVal(    ) As
                | 
                | Sets or returns the position tolerance value.
                |

        :return:
        """
        return self.abq_fastened_pair.PositionToleranceVal

    @property
    def swap_master_slave(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SwapMasterSlave
                | o Property SwapMasterSlave(    ) As
                | 
                | Sets or returns the swap master/slave surface flag.
                |

        :return:
        """
        return self.abq_fastened_pair.SwapMasterSlave

    def add_support_from_analysis_entity(self, i_product, i_entity):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromAnalysisEntity
                | o Sub AddSupportFromAnalysisEntity(        iProduct,
                |                                            iEntity)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the contact is applied.
                | 
                |  iEntity
                |      The CATIA Analysis Entity specifying the region to which the contact is applied.

                |
        :param i_product:
        :param i_entity:
        :return:
        """
        return self.abq_fastened_pair.AddSupportFromAnalysisEntity(i_product, i_entity)

    def add_support_from_constraint(self, i_product, i_constraint):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromConstraint
                | o Sub AddSupportFromConstraint(        iProduct,
                |                                        iConstraint)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the contact is applied.
                | 
                |  iConstraint
                |      The CATIA Constraint specifying the region to which the contact is applied.

                |
        :param i_product:
        :param i_constraint:
        :return:
        """
        return self.abq_fastened_pair.AddSupportFromConstraint(i_product, i_constraint)

    def __repr__(self):
        return f'ABQFastenedPair()'
