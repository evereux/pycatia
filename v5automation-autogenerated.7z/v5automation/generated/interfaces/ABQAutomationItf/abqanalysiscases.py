#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQAnalysisCases(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of ABQAQUS analysis case objects attached to
                | anactivateLinkAnchor('ABQAnalysisModel','','ABQAnalysisModel')object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_analysis_cases = com_object     

    def add(self, i_analysis_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iAnalysisType) As
                | 
                | Creates a new Abaqus analysis case and adds it to the
                | collection of Abaqus analysis cases.
                |
                | Parameters:
                | iAnalysisType
                |    The type of Analysis Case to create.  
                |    Legal values:
                |    
                | "STRUCTURAL"
                | "THERMAL"
                | "EXPLICIT_DYNAMICS"
                | 
                | 
                | 
                |  Returns:
                |   The Abaqus analysis case object that was created.

                |                | Examples:
                | The following example creates an Abaqus analysis case
                | abqCase1: Dim abqCases As ABQAnalysisCases Dim abqCase1 As
                | ABQAnalysisCase Set abqCase1 = abqCases.Add("STRUCTURAL")

        :param i_analysis_type:
        :return:
        """
        return self.abq_analysis_cases.Add(i_analysis_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus analysis case using its index or its name
                | from the collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus analysis case to retrieve from
                |    the collection of Abaqus analysis cases.
                |    If the index is a number, it specifies the rank of the Abaqus analysis case
                |    in the collection. The index of the first Abaqus analysis case in the collection is 1,
                |    and the index of the last case is Count.
                |    If the index is a string, it specifies the name you assigned to the case using
                |    the CATIACollection::Name property.
                |  
                | 
                |  Returns:
                |   The specified ABQIAABQAnalysisCase.

                |                | Examples:
                | This example retrieves the fifth Abaqus analysis case in the
                | collection and saves it in a variable called ThisCase. The
                | example also retrieves the Abaqus analysis case named
                | "MyCase" in the collection and saves it in a variable called
                | ThatCase. Set CaseColl = AnalysisDoc.ABQAnalysisModel.Cases
                | Set ThisCase = CaseColl.Item(5) Set ThatCase =
                | CaseColl.Item("MyCase")

        :param i_index:
        :return:
        """
        return self.abq_analysis_cases.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes an Abaqus analysis case using its index or its name
                | from the collection of Abaqus analysis cases. This function
                | works only in CAAV5 R13 onwards.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus analysis case to retrieve from
                |    the collection of Abaqus analysis cases.
                |    If the index is a number, it specifies the rank of the Abaqus  analysis case 
                |    in the collection. The index of the first Abaqus analysis case in the collection is 1,
                |    and the index of the last  analysis case is Count.
                |    If the index is a string, it specifies the name you assigned to the  analysis case using
                |    the CATIABase::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_analysis_cases.Remove(i_index)

    def __repr__(self):
        return f'ABQAnalysisCases()'
