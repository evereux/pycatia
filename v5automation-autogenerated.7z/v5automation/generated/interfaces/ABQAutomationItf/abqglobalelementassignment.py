#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQGlobalElementAssignment(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus Global Element assignment
                | (ABQGlobalElementAssignment) object.Role:Access an Abaqus Global
                | Element assignment property object or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_global_element_assignment = com_object     

    def get_element_properties(self, i_elem_id, o_elem_behav, o_mff_lag, o_hf_flag, o_ri_flag, o_im_flag, o_in_flag):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetElementProperties
                | o Sub GetElementProperties(        iElemID,
                |                                    oElemBehav,
                |                                    oMFFLag,
                |                                    oHFFlag,
                |                                    oRIFlag,
                |                                    oIMFlag,
                |                                    oINFlag)
                | 
                | Gets the behavior and the modifier to given element type.
                |
                | Parameters:
                | iElemID
                |    The element type ID for which behavior and modifier is requested.
                | Legal values:
                |  
                | TET_LINEAR
                | TET_PARABOLIC
                | HEX_LINEAR
                | HEX_PARABOLIC
                | WEDG_LINEAR
                | WEDG_PARABOLIC
                | TRI_LINEAR
                | TRI_PARABOLIC
                | QUAD_LINEAR
                | QUAD_PARABOLIC
                | LINE_LINEAR
                | LINE_PARABOLIC 
                | 
                | 
                |  oElemBehav
                |    The element behavior set to given element type.
                | Legal values:
                |  
                | SHELL
                | MEMBRANE
                | SOLID3D
                | CONTINUUM_SHELL
                | BEAM
                | GASKET
                | 
                | 
                |  oMFFLag
                |    The modified formulation flag.
                | Legal values:
                |  
                | true
                | false
                | 
                | 
                |  oHFFlag
                |     The hybrid formulation flag.
                | Legal values:
                |  
                | true
                | false
                | 
                | 
                |  oRIFlag
                |  The reduced integration flag.
                | Legal values:
                |  
                | true
                | false
                | 
                | 
                |  oIMFlag
                |    The incompatible modes flag.
                | Legal values:
                |  
                | true
                | false
                | 
                | 
                |  oINFlag
                |    The Gasket thickness behavior flag.
                | Legal values:
                |  
                | true
                | false

                |
        :param i_elem_id:
        :param o_elem_behav:
        :param o_mff_lag:
        :param o_hf_flag:
        :param o_ri_flag:
        :param o_im_flag:
        :param o_in_flag:
        :return:
        """
        return self.abq_global_element_assignment.GetElementProperties(i_elem_id, o_elem_behav, o_mff_lag, o_hf_flag, o_ri_flag, o_im_flag, o_in_flag)

    def set_element_properties(self, i_elem_id, i_elem_behav, i_mff_lag, i_hf_flag, i_ri_flag, i_im_flag, i_in_flag):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetElementProperties
                | o Sub SetElementProperties(        iElemID,
                |                                    iElemBehav,
                |                                    iMFFLag,
                |                                    iHFFlag,
                |                                    iRIFlag,
                |                                    iIMFlag,
                |                                    iINFlag)
                | 
                | Sets the behavior and the modifier to given element type.
                |
                | Parameters:
                | iElemID
                |    The element type ID for which behavior and modifier is to be set.
                | Legal values:
                |  
                | TET_LINEAR
                | TET_PARABOLIC
                | HEX_LINEAR
                | HEX_PARABOLIC
                | WEDG_LINEAR
                | WEDG_PARABOLIC
                | TRI_LINEAR
                | TRI_PARABOLIC
                | QUAD_LINEAR
                | QUAD_PARABOLIC
                | LINE_LINEAR
                | LINE_PARABOLIC 
                | 
                | 
                |  iElemBehav
                |    The element behavior to be set to given element type.
                | Legal values:
                |  
                | SHELL
                | MEMBRANE
                | SOLID3D
                | CONTINUUM_SHELL
                | BEAM
                | GASKET
                | 
                | 
                |  iMFFLag
                |    The modified formulation flag.
                | Legal values:
                |  
                | true
                | false
                | 
                | 
                |  iHFFlag
                |     The hybrid formulation flag.
                | Legal values:
                |  
                | true
                | false
                | 
                | 
                |  iRIFlag
                |  The reduced integration flag.
                | Legal values:
                |  
                | true
                | false
                | 
                | 
                |  iIMFlag
                |    The incompatible modes flag.
                | Legal values:
                |  
                | true
                | false
                | 
                | 
                |  iINFlag
                |    The Gasket thickness behavior flag.
                | Legal values:
                |  
                | true
                | false

                |                | Examples:
                | To specify element type 'C3D10MH' user can use this method
                | as shown below. SetElementValues TET_PARABOLI SOLID3D true
                | true false false false false.

        :param i_elem_id:
        :param i_elem_behav:
        :param i_mff_lag:
        :param i_hf_flag:
        :param i_ri_flag:
        :param i_im_flag:
        :param i_in_flag:
        :return:
        """
        return self.abq_global_element_assignment.SetElementProperties(i_elem_id, i_elem_behav, i_mff_lag, i_hf_flag, i_ri_flag, i_im_flag, i_in_flag)

    def __repr__(self):
        return f'ABQGlobalElementAssignment()'
