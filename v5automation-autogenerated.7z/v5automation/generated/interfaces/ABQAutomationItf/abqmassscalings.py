#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQMassScalings(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a collection ofactivateLinkAnchor('ABQMassScaling','','ABQM
                | assScaling')entries.Role:

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_mass_scalings = com_object     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As
                | 
                | Adds a new to the collection. Returns: The created
                | ABQMassScaling entry.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_mass_scalings.Add()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns the entry for the specified index.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ABQMassScaling to retrieve.
                |    If the index is a number, it specifies the element offset
                |    within the collection. The offset starts at 1.
                |    If the index is a string, it specifies the name
                |    (MassScaling.Name property) of the desired element.

                |
        :param i_index:
        :return:
        """
        return self.abq_mass_scalings.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes the specified entry.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ABQMassScaling to remove.
                |    If the index is a number, it specifies the element offset
                |    within the collection. The offset starts at 1.
                |    If the index is a string, it specifies the name
                |    (MassScaling.Name property) of the desired element.

                |
        :param i_index:
        :return:
        """
        return self.abq_mass_scalings.Remove(i_index)

    def __repr__(self):
        return f'ABQMassScalings()'
