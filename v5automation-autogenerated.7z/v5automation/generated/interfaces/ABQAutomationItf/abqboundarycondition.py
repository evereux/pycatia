#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQBoundaryCondition(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the base interface for Abaqus boundary condition
                | objects.Role:The ABQBoundaryCondition interface manages the common
                | properties of any boundary condition.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_boundary_condition = com_object     

    @property
    def activation_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActivationStatus
                | o Property ActivationStatus(    ) As
                | 
                | Sets or Returns a boolean indicating whether the boundary
                | condition is activated. Returns: The activation status.
                |

        :return:
        """
        return self.abq_boundary_condition.ActivationStatus

    @property
    def apply_user_subroutine(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyUserSubroutine
                | o Property ApplyUserSubroutine(    ) As
                | 
                | Sets or returns the user subroutine flag. Returns: A boolean
                | specifying whether a user subroutine will be applied.
                |

        :return:
        """
        return self.abq_boundary_condition.ApplyUserSubroutine

    @property
    def regions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Regions
                | o Property Regions(    ) As   (Read Only)
                | 
                | Returns the region to which the boundary condition is
                | applied. Returns: The region
                |

        :return:
        """
        return self.abq_boundary_condition.Regions

    @property
    def smooth_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SmoothAmplitude
                | o Property SmoothAmplitude(    ) As
                | 
                | Sets or returns the Smooth Amplitude, given the reference of
                | the Smooth amplitude. Returns: The amplitude object.
                |

        :return:
        """
        return self.abq_boundary_condition.SmoothAmplitude

    @property
    def status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Status
                | o Property Status(    ) As   (Read Only)
                | 
                | Returns the propagating status of the boundary condition.
                | Returns: The propagating status for example: if the boundary
                | condition feature is created, it will return "CREATED" if
                | the boundary condition feature is propagated from previous
                | step, it will return "PROPAGATED"
                |

        :return:
        """
        return self.abq_boundary_condition.Status

    @property
    def tabular_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TabularAmplitude
                | o Property TabularAmplitude(    ) As
                | 
                | Sets or returns the amplitude, given the Tabular amplitude
                | reference. Returns: The amplitude object.
                |

        :return:
        """
        return self.abq_boundary_condition.TabularAmplitude

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the type of the boundary condition. Returns: The
                | type of the boundary condition
                |

        :return:
        """
        return self.abq_boundary_condition.Type

    def add_support_from_product(self, i_product, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromProduct
                | o Sub AddSupportFromProduct(        iProduct,
                |                                     iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the boundary condition is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the boundary condition is applied.
                |  Refer: CATIAReference, CATIAProduct

                |
        :param i_product:
        :param i_support:
        :return:
        """
        return self.abq_boundary_condition.AddSupportFromProduct(i_product, i_support)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the boundary condition is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the boundary condition is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_boundary_condition.AddSupportFromPublication(i_product, i_publication)

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iReference,
                |                                       iSupport)
                | 
                | Creates a new support and adds it to the description of the
                | Analysis Entity.
                |
                | Parameters:
                | iReference
                |      The CATIA Reference specifying the object to which the boundary condition is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the boundary condition is applied.
                |  Refer: CATIAReference

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_boundary_condition.AddSupportFromReference(i_reference, i_support)

    def __repr__(self):
        return f'ABQBoundaryCondition()'
