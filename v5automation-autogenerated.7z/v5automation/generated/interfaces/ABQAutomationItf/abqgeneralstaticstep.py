#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQGeneralStaticStep(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus general static step (ABQGeneralStaticStep)
                | object.Role:Access an Abaqus general static step object or determine
                | its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_general_static_step = com_object     

    @property
    def boundary_conditions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BoundaryConditions
                | o Property BoundaryConditions(    ) As   (Read Only)
                | 
                | Returns the ABQBoundaryConditions container associated with
                | the step. Example: This example retrieves the
                | ABQBoundaryConditions container abqBCs. Dim abqGenStep As
                | ABQGeneralStaticStep Dim abqBCs As ABQBoundaryConditions Set
                | abqBCs = abqGenStep.BoundaryConditions
                |

        :return:
        """
        return self.abq_general_static_step.BoundaryConditions

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As
                | 
                | Returns or sets the description of the Abaqus general static
                | step. Returns: The description of the Abaqus general static
                | step.
                |

        :return:
        """
        return self.abq_general_static_step.Description

    @description.setter
    def description(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.Description = value 

    @property
    def energy_fraction(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EnergyFraction
                | o Property EnergyFraction(    ) As
                | 
                | Returns or sets the EnergyFraction if the stabilization
                | method is DISSIPATION. Returns: The energy fraction.
                |

        :return:
        """
        return self.abq_general_static_step.EnergyFraction

    @energy_fraction.setter
    def energy_fraction(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.EnergyFraction = value 

    @property
    def fields(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Fields
                | o Property Fields(    ) As   (Read Only)
                | 
                | Returns the ABQFields container associated with the step.
                | Example: This example retrieves the ABQFields container
                | abqFields. Dim abqGenStep As ABQGeneralStaticStep Dim
                | abqFields As ABQFields Set abqFields = abqGenStep.Fields
                |

        :return:
        """
        return self.abq_general_static_step.Fields

    @property
    def initial_inc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InitialInc
                | o Property InitialInc(    ) As
                | 
                | Returns or sets the size of the initial increment. Returns:
                | The initial increment size.
                |

        :return:
        """
        return self.abq_general_static_step.InitialInc

    @initial_inc.setter
    def initial_inc(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.InitialInc = value 

    @property
    def loads(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Loads
                | o Property Loads(    ) As   (Read Only)
                | 
                | Returns the ABQLoads container associated with the step.
                | Example: The following example retrieves the ABQLoads
                | container abqLoads: Dim abqGenStep As ABQGeneralStaticStep
                | Dim abqLoads As ABQLoads Set abqLoads = abqGenStep.Loads
                |

        :return:
        """
        return self.abq_general_static_step.Loads

    @property
    def max_inc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxInc
                | o Property MaxInc(    ) As
                | 
                | Returns or sets the maximum increment if the type of the
                | incrementation is set to AUTO_INCREMENT. Returns: The
                | maximum increment.
                |

        :return:
        """
        return self.abq_general_static_step.MaxInc

    @max_inc.setter
    def max_inc(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.MaxInc = value 

    @property
    def max_num_inc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxNumInc
                | o Property MaxNumInc(    ) As
                | 
                | Returns or sets the maximum number of increments if the type
                | of the incremention is set to AUTO_INCREMENT. Returns: The
                | maximum number of increments.
                |

        :return:
        """
        return self.abq_general_static_step.MaxNumInc

    @max_num_inc.setter
    def max_num_inc(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.MaxNumInc = value 

    @property
    def min_inc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MinInc
                | o Property MinInc(    ) As
                | 
                | Returns or sets the minimum increment if the type of the
                | incrementation is set to AUTO_INCREMENT. Returns: The
                | minimum increment.
                |

        :return:
        """
        return self.abq_general_static_step.MinInc

    @min_inc.setter
    def min_inc(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.MinInc = value 

    @property
    def nl_geom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NLGeom
                | o Property NLGeom(    ) As
                | 
                | Returns or sets whether the geometry remains linear during
                | the analysis. A value of true indicates that the geometry
                | remains linear. Returns: A boolean specifying whether the
                | geometry remains linear during the analysis.
                |

        :return:
        """
        return self.abq_general_static_step.NLGeom

    @nl_geom.setter
    def nl_geom(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.NLGeom = value 

    @property
    def stabilization(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Stabilization
                | o Property Stabilization(    ) As   (Read Only)
                | 
                | Returns a boolean indicating whether the stabilization
                | option was selected. Returns: The stabilization status.
                | Example: The following example returns the status of the
                | stabilization option bFlag in the general static step
                | generalstaticstep. Dim generalstaticstep As
                | ABQGeneralStaticStep Dim bFlag As boolean Set bFlag =
                | generalstaticstep.Stabilization
                |

        :return:
        """
        return self.abq_general_static_step.Stabilization

    @property
    def stabilization_magnitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StabilizationMagnitude
                | o Property StabilizationMagnitude(    ) As
                | 
                | Sets and Returns the damping factor if the stabilization
                | method is FACTOR. Returns: The damping factor.
                |

        :return:
        """
        return self.abq_general_static_step.StabilizationMagnitude

    @property
    def stabilization_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StabilizationMethod
                | o Property StabilizationMethod(    ) As
                | 
                | Returns or sets the stabilization method if the
                | Stabilization option is selected. Returns: The stabilization
                | method Legal values: DISSIPATION FACTOR
                |

        :return:
        """
        return self.abq_general_static_step.StabilizationMethod

    @stabilization_method.setter
    def stabilization_method(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.StabilizationMethod = value 

    @property
    def time_incrementation_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimeIncrementationMethod
                | o Property TimeIncrementationMethod(    ) As
                | 
                | Returns or sets the type of the incrementation during the
                | step. Returns: The type of the incrementation. Legal values:
                | AUTO_INCREMENT FIXED_INCREMENT
                |

        :return:
        """
        return self.abq_general_static_step.TimeIncrementationMethod

    @time_incrementation_method.setter
    def time_incrementation_method(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.TimeIncrementationMethod = value 

    @property
    def time_period(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimePeriod
                | o Property TimePeriod(    ) As
                | 
                | Returns or sets the total time period of the Abaqus general
                | static step. Returns: The total time period of the Abaqus
                | general static step.
                |

        :return:
        """
        return self.abq_general_static_step.TimePeriod

    @time_period.setter
    def time_period(self, value):
        """
            :param type value:
        """
        self.abq_general_static_step.TimePeriod = value 

    def __repr__(self):
        return f'ABQGeneralStaticStep()'
