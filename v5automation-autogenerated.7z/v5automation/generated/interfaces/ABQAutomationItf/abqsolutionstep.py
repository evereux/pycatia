#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQSolutionStep(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus solution step (ABQSolutionStep) object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_solution_step = com_object     

    @property
    def analysis_images(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisImages
                | o Property AnalysisImages(    ) As   (Read Only)
                | 
                | Returns the analysis images associated with this solution
                | step. Returns: The collection of analysis images. Example:
                | The following example retrieves the analysis images
                | collection AnalysisImages in ListSolutionStepImages. Dim
                | MySolutionStep As ABQSolutionStep Dim ListSolutionStepImages
                | As ABQSolutionStepImages Set ListSolutionStepImages =
                | MySolutionStep.AnalysisImages
                |

        :return:
        """
        return self.abq_solution_step.AnalysisImages

    def create_image(self, i_image_name, i_hide_existing_images, i_incr_or_mode_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateImage
                | o Func CreateImage(        iImageName,
                |                            iHideExistingImages,
                |                            iIncrOrModeNumber) As
                | 
                | Creates a new image under this solution step.
                |
                | Parameters:
                | iImageName
                |  The name of the image to create.
                |  
                |  iHideExistingImages
                |  To deactivate or not all the activated images before create the new image.
                |  
                |  iIncrOrModeNumber
                |  Increment or mode (for frequency step) number to be set in created image.
                |  
                | 
                |  Returns:
                |   The created Analysis Image

                |                | Examples:
                | This example create ThisAnalysisImage in the MySolutionStep.
                | The image to create is supposed to be a mesh deformed image
                | for first increment. Dim MySolutionStep As ABQSolutionStep
                | Dim ThisAnalysisImage As AnalysisImage Set ThisAnalysisImage
                | = MySolutionStep.CreateImage("Mesh_Deformed", True, 1)

        :param i_image_name:
        :param i_hide_existing_images:
        :param i_incr_or_mode_number:
        :return:
        """
        return self.abq_solution_step.CreateImage(i_image_name, i_hide_existing_images, i_incr_or_mode_number)

    def set_increment_or_mode_number(self, i_incr_or_mode_number, i_image):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIncrementOrModeNumber
                | o Sub SetIncrementOrModeNumber(        iIncrOrModeNumber,
                |                                        iImage)
                | 
                | Sets increment number for an image. This is done related to
                | an existing image
                |
                | Parameters:
                | iIncrOrModeNumber
                |   The increment or mode (for frequency step) number to select

                |
        :param i_incr_or_mode_number:
        :param i_image:
        :return:
        """
        return self.abq_solution_step.SetIncrementOrModeNumber(i_incr_or_mode_number, i_image)

    def __repr__(self):
        return f'ABQSolutionStep()'
