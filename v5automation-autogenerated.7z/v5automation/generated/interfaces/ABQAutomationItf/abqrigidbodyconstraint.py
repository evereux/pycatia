#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQRigidBodyConstraint(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus rigid body constraint (ABQRigidBodyConstraint)
                | object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_rigid_body_constraint = com_object     

    @property
    def move_to_center_of_mass(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MoveToCenterOfMass
                | o Property MoveToCenterOfMass(    ) As
                | 
                | Sets or returns the move to center of mass flag.
                |

        :return:
        """
        return self.abq_rigid_body_constraint.MoveToCenterOfMass

    @property
    def num_pin_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumPinSupports
                | o Property NumPinSupports(    ) As   (Read Only)
                | 
                | Gets the number of pin point supports for the rigid body.
                |

        :return:
        """
        return self.abq_rigid_body_constraint.NumPinSupports

    @property
    def num_tie_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumTieSupports
                | o Property NumTieSupports(    ) As   (Read Only)
                | 
                | Gets the number of tie point supports for the rigid body.
                |

        :return:
        """
        return self.abq_rigid_body_constraint.NumTieSupports

    def add_support_from_body(self, i_product, i_body):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromBody
                | o Sub AddSupportFromBody(        iProduct,
                |                                  iBody)
                | 
                | Creates a new support for the body and adds it to the
                | description of the Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIAProduct specifying the positioning object.
                | 
                |  iBody
                |               The CATIABody specifying the object that is being pointed to.
                |  Refer: CATIABody , CATIAProduct

                |
        :param i_product:
        :param i_body:
        :return:
        """
        return self.abq_rigid_body_constraint.AddSupportFromBody(i_product, i_body)

    def add_support_from_part(self, i_product, i_part):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPart
                | o Sub AddSupportFromPart(        iProduct,
                |                                  iPart)
                | 
                | Creates a new support for the part and adds it to the
                | description of the Analysis Entity.
                |
                | Parameters:
                | iProduct
                |      The CATIAProduct specifying the positioning object.
                | 
                |  iSupport
                |               The CATIAPart specifying the object that is being pointed to.
                |  Refer: CATIAPart , CATIAProduct

                |
        :param i_product:
        :param i_part:
        :return:
        """
        return self.abq_rigid_body_constraint.AddSupportFromPart(i_product, i_part)

    def add_support_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromPublication
                | o Sub AddSupportFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Adds a support to the Rigid body constraint. If the support
                | already exists, it is removed.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the object to which the rigid body constraint is applied.
                | 
                |  iPublication
                |               The CATIA Publication specifying the region to which the rigid body constraint is applied.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_rigid_body_constraint.AddSupportFromPublication(i_product, i_publication)

    def clear_pin_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClearPinSupports
                | o Sub ClearPinSupports(    )
                | 
                | Clears the pin point supports for the rigid body.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_rigid_body_constraint.ClearPinSupports()

    def clear_tie_supports(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClearTieSupports
                | o Sub ClearTieSupports(    )
                | 
                | Clears the tie point supports for the rigid body.
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_rigid_body_constraint.ClearTieSupports()

    def get_pin_supports(self, i_products, i_regions):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPinSupports
                | o Sub GetPinSupports(        iProducts,
                |                              iRegions)
                | 
                | Gets the pin point supports for the rigid body.
                |
                | Parameters:
                | oProducts
                |    Safe array of products for the support region as CATIReferences.  
                |    This array has a one-to-one mapping with the regions array.
                |  
                |  oRegions
                |     Safe array of supports as CATIReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param i_products:
        :param i_regions:
        :return:
        """
        return self.abq_rigid_body_constraint.GetPinSupports(i_products, i_regions)

    def get_tie_supports(self, i_products, i_regions):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTieSupports
                | o Sub GetTieSupports(        iProducts,
                |                              iRegions)
                | 
                | Gets the tie point supports for the rigid body.
                |
                | Parameters:
                | oProducts
                |    Safe array of products for the support region as CATIReferences.  
                |    This array has a one-to-one mapping with the regions array.
                |  
                |  oRegions
                |     Safe array of supports as CATIReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param i_products:
        :param i_regions:
        :return:
        """
        return self.abq_rigid_body_constraint.GetTieSupports(i_products, i_regions)

    def set_handler(self, i_product, i_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandler
                | o Sub SetHandler(        iProduct,
                |                          iRef)
                | 
                | Set the handler for the rigid body.
                |
                | Parameters:
                | iProduct
                |      The CATIAProduct specifying the positioning object.
                | 
                |  iRef
                |    The CATIAReference specifying the object that is being pointed to.

                |
        :param i_product:
        :param i_ref:
        :return:
        """
        return self.abq_rigid_body_constraint.SetHandler(i_product, i_ref)

    def set_handler_from_publication(self, i_product, i_publication):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandlerFromPublication
                | o Sub SetHandlerFromPublication(        iProduct,
                |                                         iPublication)
                | 
                | Sets the handler for the Rigid body constraint. Any
                | previously set handler will be replaced with the new value.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product for handeler.
                | 
                |  iPublication
                |               The CATIA Publication for handeler.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_publication:
        :return:
        """
        return self.abq_rigid_body_constraint.SetHandlerFromPublication(i_product, i_publication)

    def set_pin_supports(self, i_products, i_regions):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPinSupports
                | o Sub SetPinSupports(        iProducts,
                |                              iRegions)
                | 
                | Sets the pin point supports for the rigid body. Any
                | previously set pin supports will be replaced with this new
                | list. At least one item in the list is required.
                |
                | Parameters:
                | iProducts
                |    Safe array of products for the support region as CATIReferences.  
                |    This array has a one-to-one mapping with the regions array.
                |  
                |  iRegions
                |     Safe array of supports as CATIReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param i_products:
        :param i_regions:
        :return:
        """
        return self.abq_rigid_body_constraint.SetPinSupports(i_products, i_regions)

    def set_tie_supports(self, i_products, i_regions):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTieSupports
                | o Sub SetTieSupports(        iProducts,
                |                              iRegions)
                | 
                | Sets the tie point supports for the rigid body. Any
                | previously set tie supports will be replaced with this new
                | list. At least one item in the list is required.
                |
                | Parameters:
                | iProducts
                |    Safe array of products for the support region as CATIReferences.  
                |    This array has a one-to-one mapping with the regions array.
                |  
                |  iRegions
                |     Safe array of supports as CATIReferences.
                |    This array has a one-to-one mapping with the products array.

                |
        :param i_products:
        :param i_regions:
        :return:
        """
        return self.abq_rigid_body_constraint.SetTieSupports(i_products, i_regions)

    def __repr__(self):
        return f'ABQRigidBodyConstraint()'
