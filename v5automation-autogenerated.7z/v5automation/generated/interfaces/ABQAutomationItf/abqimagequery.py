#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQImageQuery(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Provides an image query object.Role:Use to query result images for
                | values on nodes / elements / groups. Image query can be done
                | simultaneously for multiple images. User can call methods such as
                | ExportImageData or ExportGroupImageData. Use following method to get
                | an object of ABQImageQuery Dim abqCase As ABQAnalysisCase Dim
                | ImageQuery As ABQImageQuery Set ImageQuery = abqCase.GetItem
                | ("ABQVBImageQuery")

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_image_query = com_object     

    def export_group_image_data(self, i_images_list, i_group, i_type, i_file):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportGroupImageData
                | o Sub ExportGroupImageData(        iImagesList,
                |                                    iGroup,
                |                                    iType,
                |                                    iFile)
                | 
                | Method to export image data in text or excel format for a
                | group. The data in a row will be in following order: Node /
                | element id, X coordinate, Y coordinate, Z coordinate, value
                | for image 1, value for image 2, ... File type will be
                | identified using file extension. If file extension is 'xls'
                | then it will be exported in excel otherwise the file type
                | will be considered as text
                |
                | Parameters:
                | iImagesList
                |           List of images to export
                |  
                |  iGroup
                |           CATIA group or display group to query image data
                |  
                |  iType
                |           Entity type to query.
                |           Legal values
                | 
                | ABQ_NODE
                | ABQ_ELEMENT
                | 
                | 
                |  iFile
                |           File path to export data.

                |                | Examples:
                | The following example exports image query data to specified
                | file Dim ImageQuery As ABQImageQuery Dim File As FileSystem
                | Dim MyGroup As AnalysisEntity Dim imageList As
                | AnalysisImages ImageQuery.ExportImageData imageList,
                | MyGroup, ABQ_NODE, File

        :param i_images_list:
        :param i_group:
        :param i_type:
        :param i_file:
        :return:
        """
        return self.abq_image_query.ExportGroupImageData(i_images_list, i_group, i_type, i_file)

    def export_image_data(self, i_images_list, i_list_numbers, i_type, i_file):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportImageData
                | o Sub ExportImageData(        iImagesList,
                |                               iListNumbers,
                |                               iType,
                |                               iFile)
                | 
                | Method to export image data in text or excel format. The
                | data in a row will be in following order: Node / element id,
                | X coordinate, Y coordinate, Z coordinate, value for image 1,
                | value for image 2, ... File type will be identified using
                | file extension. If file extension is 'xls' then it will be
                | exported in excel otherwise the file type will be considered
                | as text
                |
                | Parameters:
                | iImagesList
                |           List of images to export
                |  
                |  iListNumbers
                |           List of entity indices to export (node numbers or element numbers)
                |  
                |  iType
                |           Entity type to query.
                |           Legal values
                | 
                | ABQ_NODE
                | ABQ_ELEMENT
                | 
                | 
                |  iFile
                |           File path to export data

                |                | Examples:
                | The following example exports image query data to specified
                | file Dim ImageQuery As ABQImageQuery Dim File As FileSystem
                | Dim EntityList As CATSafeArrayVariant Dim imageList As
                | AnalysisImages ImageQuery.ExportImageData imageList,
                | EntityList, ABQ_NODE, File

        :param i_images_list:
        :param i_list_numbers:
        :param i_type:
        :param i_file:
        :return:
        """
        return self.abq_image_query.ExportImageData(i_images_list, i_list_numbers, i_type, i_file)

    def __repr__(self):
        return f'ABQImageQuery()'
