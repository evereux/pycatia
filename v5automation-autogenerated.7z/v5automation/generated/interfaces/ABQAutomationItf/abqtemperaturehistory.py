#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQTemperatureHistory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus temperature history object
                | (ABQTemperatureHistory).Role:Access an Abaqus temperature history
                | object or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_temperature_history = com_object     

    @property
    def activation_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActivationStatus
                | o Property ActivationStatus(    ) As
                | 
                | Sets or returns the activation status. Returns: A boolean
                | specifying whether the feature is activated.
                |

        :return:
        """
        return self.abq_temperature_history.ActivationStatus

    @property
    def amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Amplitude
                | o Property Amplitude(    ) As
                | 
                | Sets or returns the amplitude of the temperature field.
                | Example: This example retrieves the ABQTabularAmplitude
                | abqAmplitude. Dim abqTemperature As ABQTemperature Dim
                | abqAmplitude As ABQTabularAmplitude Set abqAmplitude =
                | abqTemperature.Amplitude
                |

        :return:
        """
        return self.abq_temperature_history.Amplitude

    @property
    def begin_step_num(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BeginStepNum
                | o Property BeginStepNum(    ) As
                | 
                | Sets or returns the step number at which to start reading
                | the temperature data.
                |

        :return:
        """
        return self.abq_temperature_history.BeginStepNum

    @property
    def end_step_num(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EndStepNum
                | o Property EndStepNum(    ) As
                | 
                | Sets or returns the step number at which to stop reading the
                | temperature data.
                |

        :return:
        """
        return self.abq_temperature_history.EndStepNum

    @property
    def use_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseAmplitude
                | o Property UseAmplitude(    ) As
                | 
                | Sets or returns the UseAmplitude flag. Returns: A boolean
                | specifying whether an amplitude will be used.
                |

        :return:
        """
        return self.abq_temperature_history.UseAmplitude

    def __repr__(self):
        return f'ABQTemperatureHistory()'
