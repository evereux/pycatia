#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQLoads(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of Abaqus load (ABQLoad) objects attached to anactivate
                | LinkAnchor('ABQGeneralStaticStep','','ABQGeneralStaticStep'),activateL
                | inkAnchor('ABQHeatTransferStep','','ABQHeatTransferStep'), or anactiva
                | teLinkAnchor('ABQExplicitDynamicsStep','','ABQExplicitDynamicsStep')ob
                | ject.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_loads = com_object     

    def add(self, i_load_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iLoadType) As
                | 
                | Creates a new Abaqus load and adds it to the collection of
                | Abaqus loads.
                |
                | Parameters:
                | iLoadType
                |     The type of the load to create.  
                |  Legal values:
                |  
                | "ABQPressure"
                | "ABQConcentratedForce"
                | "ABQGravity"
                | "ABQFilmCondition"
                | 
                | 
                | 
                |  Returns:
                |   oLoad    The Abaqus load object that was created.

                |                | Examples:
                | The following example creates a pressure load in the
                | ABQLoads collection: Dim abaqusLoads As ABQLoads Dim
                | abqPressure As ABQPressure Set abaqusLoads =
                | generalstaticstep.Loads Set abqPressure =
                | abaqusLoads.Add("ABQPressure")

        :param i_load_type:
        :return:
        """
        return self.abq_loads.Add(i_load_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus load using its index or its name from the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus load to retrieve from
                |    the collection of Abaqus loads.
                |    If the index is a number, it specifies the rank of the Abaqus load
                |    in the collection. The index of the first Abaqus load in the collection is 1,
                |    and the index of the last load is Count.
                |    If the index is a string, it specifies the name you assigned to the load using
                |    the CATIACollection::Name property.
                |  
                | 
                |  Returns:
                |   The specified 
                | .

                |
        :param i_index:
        :return:
        """
        return self.abq_loads.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes a Abaqus load using its index or its name from the
                | collection od loads.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus load n to retrieve from
                |    the collection of Abaqus loads.
                |    If the index is a number, it specifies the rank of the Abaqus load
                |    in the collection. The index of the first Abaqus load in the collection is 1,
                |    and the index of the last load is Count.
                |    If the index is a string, it specifies the name you assigned to the load using
                |    the CATIACollection::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_loads.Remove(i_index)

    def __repr__(self):
        return f'ABQLoads()'
