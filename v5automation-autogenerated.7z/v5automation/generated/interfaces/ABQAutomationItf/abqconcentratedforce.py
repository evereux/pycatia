#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQConcentratedForce(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus concentrated force object
                | (ABQConcentratedForce).Role:Access an Abaqus concentrated force object
                | or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_concentrated_force = com_object     

    @property
    def apply_user_subroutine(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyUserSubroutine
                | o Property ApplyUserSubroutine(    ) As
                | 
                | Sets or returns the user subroutine flag. Returns: A boolean
                | specifying whether a user subroutine will be applied.
                |

        :return:
        """
        return self.abq_concentrated_force.ApplyUserSubroutine

    @property
    def follow_nodal_rotation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FollowNodalRotation
                | o Property FollowNodalRotation(    ) As
                | 
                | Sets or returns the follow nodal rotation flag.
                |

        :return:
        """
        return self.abq_concentrated_force.FollowNodalRotation

    @property
    def load_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadType
                | o Property LoadType(    ) As
                | 
                | Sets or returns the load type whether Point Load,
                | Distributed Load or Load Density. Returns: The load type.
                | Legal values: POINTLOAD DISTRIBUTEDLOAD LOADDENSITY o
                | Property UselocalCsys() As Sets or returns a boolean
                | indicating whether local coordinate system is used in Conc
                | force Returns: boolean specifying whether local csys is
                | active. o Property cf1() As Sets or returns the concentrated
                | force component in the 1-direction. Returns: The
                | concentrated force component in the 1-direction. o Property
                | cf2() As Sets or returns the concentrated force component in
                | the 2-direction. Returns: The concentrated force component
                | in the 2-direction. o Property cf3() As Sets or returns the
                | concentrated force component in the 3-direction. Returns:
                | The concentrated force component in the 3-direction. o
                | Property cm1() As Sets or returns the concentrated moment
                | component in the 1-direction. Returns: The concentrated
                | moment component in the 1-direction. o Property cm2() As
                | Sets or returns the concentrated moment component in the
                | 2-direction. Returns: The concentrated moment component in
                | the 2-direction. o Property cm3() As Sets or returns the
                | concentrated moment component in the 3-direction. Returns:
                | The concentrated moment component in the 3-direction. o
                | Property localCsys() As Sets or returns the local coordinate
                | system of the concentrated force. Returns: The local
                | coordinate system. Methods o Sub GetHandler( oProduct, oRef)
                | Returns the handler for the distributed load.
                |

        :return:
        """
        return self.abq_concentrated_force.LoadType

    @property
    def uselocal_csys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UselocalCsys
                | o Property UselocalCsys(    ) As
                | 
                | Sets or returns a boolean indicating whether local
                | coordinate system is used in Conc force Returns: boolean
                | specifying whether local csys is active.
                |

        :return:
        """
        return self.abq_concentrated_force.UselocalCsys

    @property
    def cf1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | cf1
                | o Property cf1(    ) As
                | 
                | Sets or returns the concentrated force component in the
                | 1-direction. Returns: The concentrated force component in
                | the 1-direction.
                |

        :return:
        """
        return self.abq_concentrated_force.cf1

    @property
    def cf2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | cf2
                | o Property cf2(    ) As
                | 
                | Sets or returns the concentrated force component in the
                | 2-direction. Returns: The concentrated force component in
                | the 2-direction.
                |

        :return:
        """
        return self.abq_concentrated_force.cf2

    @property
    def cf3(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | cf3
                | o Property cf3(    ) As
                | 
                | Sets or returns the concentrated force component in the
                | 3-direction. Returns: The concentrated force component in
                | the 3-direction.
                |

        :return:
        """
        return self.abq_concentrated_force.cf3

    @property
    def cm1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | cm1
                | o Property cm1(    ) As
                | 
                | Sets or returns the concentrated moment component in the
                | 1-direction. Returns: The concentrated moment component in
                | the 1-direction.
                |

        :return:
        """
        return self.abq_concentrated_force.cm1

    @property
    def cm2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | cm2
                | o Property cm2(    ) As
                | 
                | Sets or returns the concentrated moment component in the
                | 2-direction. Returns: The concentrated moment component in
                | the 2-direction.
                |

        :return:
        """
        return self.abq_concentrated_force.cm2

    @property
    def cm3(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | cm3
                | o Property cm3(    ) As
                | 
                | Sets or returns the concentrated moment component in the
                | 3-direction. Returns: The concentrated moment component in
                | the 3-direction.
                |

        :return:
        """
        return self.abq_concentrated_force.cm3

    @property
    def local_csys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | localCsys
                | o Property localCsys(    ) As
                | 
                | Sets or returns the local coordinate system of the
                | concentrated force. Returns: The local coordinate system.
                |

        :return:
        """
        return self.abq_concentrated_force.localCsys

    def get_handler(self, o_product, o_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHandler
                | o Sub GetHandler(        oProduct,
                |                          oRef)
                | 
                | Returns the handler for the distributed load.
                |
                | Parameters:
                | oProduct
                |    The product for the handler.
                |  
                |  oRef
                |    The reference to the handler.

                |
        :param o_product:
        :param o_ref:
        :return:
        """
        return self.abq_concentrated_force.GetHandler(o_product, o_ref)

    def get_local_csys_from_publication(self, o_product, o_pub_axis_system):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLocalCsysFromPublication
                | o Sub GetLocalCsysFromPublication(        oProduct,
                |                                           oPubAxisSystem)
                | 
                | Gets the published local coordinate system of the
                | concentrated force.
                |
                | Parameters:
                | oProduct
                |      The CATIA Product specifying the local coordinate system publication.
                | 
                |  oPubAxisSystem
                |               The CATIA Axis system.
                |  Refer: CATIAAxisSystem

                |
        :param o_product:
        :param o_pub_axis_system:
        :return:
        """
        return self.abq_concentrated_force.GetLocalCsysFromPublication(o_product, o_pub_axis_system)

    def get_use_coordinate_system_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUseCoordinateSystemType
                | o Func GetUseCoordinateSystemType(    ) As
                | 
                | Get the user coordinate system type.
                |
                | Parameters:
                | oCsystemType
                |  e.g.  ABQ_CARTESIAN,						    ABQ_CYLINDRICAL,
                | 							ABQ_SPHERICAL,
                | 							ABQ_DEFAULTAXIS

                |
        :return:
        """
        return self.abq_concentrated_force.GetUseCoordinateSystemType()

    def set_handler(self, i_product, i_ref):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHandler
                | o Sub SetHandler(        iProduct,
                |                          iRef)
                | 
                | Sets the handler for the distributed load. Any previously
                | set handler will be replaced with this new value.
                |
                | Parameters:
                | iProduct
                |    The product for the handler.
                |  
                |  iRef
                |    The reference to the handler.

                |
        :param i_product:
        :param i_ref:
        :return:
        """
        return self.abq_concentrated_force.SetHandler(i_product, i_ref)

    def set_local_csys_from_publication(self, i_product, i_pub_axis_system):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLocalCsysFromPublication
                | o Sub SetLocalCsysFromPublication(        iProduct,
                |                                           iPubAxisSystem)
                | 
                | Sets the published local coordinate system of the
                | concentrated force. Returns: Fails if the publication is not
                | an axis system.
                |
                | Parameters:
                | iProduct
                |      The CATIA Product specifying the local coordinate system publication.
                | 
                |  iPublication
                |               The CATIA Publication on the axis system.
                |  Refer: CATIAPublication

                |
        :param i_product:
        :param i_pub_axis_system:
        :return:
        """
        return self.abq_concentrated_force.SetLocalCsysFromPublication(i_product, i_pub_axis_system)

    def set_use_coordinate_system_type(self, i_csystem_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUseCoordinateSystemType
                | o Sub SetUseCoordinateSystemType(        iCsystemType)
                | 
                | set the user coordinate system type.
                |
                | Parameters:
                | iCsystemType
                |  e.g.  ABQ_CARTESIAN,						    ABQ_CYLINDRICAL,
                | 							ABQ_SPHERICAL,
                | 							ABQ_DEFAULTAXIS

                |
        :param i_csystem_type:
        :return:
        """
        return self.abq_concentrated_force.SetUseCoordinateSystemType(i_csystem_type)

    def __repr__(self):
        return f'ABQConcentratedForce()'
