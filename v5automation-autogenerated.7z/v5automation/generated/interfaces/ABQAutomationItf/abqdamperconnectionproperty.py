#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQDamperConnectionProperty(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus Damper connection property (ABQDamper)
                | object.Role:Access an Abaqus Damper connection property object or
                | determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_damper_connection_property = com_object     

    @property
    def axis_sys(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Axis_sys
                | o Property Axis_sys(    ) As
                | 
                | Sets or returns the axis system in the Damper connection
                | property. Returns: The object of axis system.
                |

        :return:
        """
        return self.abq_damper_connection_property.Axis_sys

    @property
    def damper_def(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DamperDef
                | o Property DamperDef(    ) As
                | 
                | Sets or returns the definition of Damper. Returns: the
                | Definition of Damper. Legal values: ABQ_LINE ABQ_NON_LINEAR
                | o Property DamperType() As Sets or returns the type of
                | Damper. Returns: The type of Damper. Legal values: AXIAL
                | GENERAL Methods o Sub AddSupportFromReference( iReference,
                | iSupport) Adds support to the Damper connection property.
                |

        :return:
        """
        return self.abq_damper_connection_property.DamperDef

    @property
    def damper_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DamperType
                | o Property DamperType(    ) As
                | 
                | Sets or returns the type of Damper. Returns: The type of
                | Damper. Legal values: AXIAL GENERAL Methods o Sub
                | AddSupportFromReference( iReference, iSupport) Adds support
                | to the Damper connection property.
                |

        :return:
        """
        return self.abq_damper_connection_property.DamperType

    def add_support_from_reference(self, i_reference, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSupportFromReference
                | o Sub AddSupportFromReference(        iReference,
                |                                       iSupport)
                | 
                | Adds support to the Damper connection property.
                |
                | Parameters:
                | iReference
                |      The CATIA Reference specifying the region to which the Damper connection property is applied.
                | 
                |  iSupport
                |      The CATIA Reference specifying the region to which the Damper connection property is applied.
                |  Refer: CATIAReference

                |
        :param i_reference:
        :param i_support:
        :return:
        """
        return self.abq_damper_connection_property.AddSupportFromReference(i_reference, i_support)

    def get_linear_damping(self, i_dof):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLinearDamping
                | o Func GetLinearDamping(        iDof) As
                | 
                | Gets the linear damping value of the Damper given the degree
                | of freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which damping is asked.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  oDampingValue
                |      The Dampingvalue.

                |
        :param i_dof:
        :return:
        """
        return self.abq_damper_connection_property.GetLinearDamping(i_dof)

    def get_non_linear_damping(self, i_dof, o_force_array, o_velocity_array):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNonLinearDamping
                | o Sub GetNonLinearDamping(        iDof,
                |                                   oForceArray,
                |                                   oVelocityArray)
                | 
                | Gets the non-linear damping value of the Damper in the form
                | of array, given the degree of freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which damping is asked.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  oForceArray
                |      The array of force values.
                | 
                |  oVelocityArray
                |      The array of velocity values.
                |  Refer: CATSafeArrayVariant

                |
        :param i_dof:
        :param o_force_array:
        :param o_velocity_array:
        :return:
        """
        return self.abq_damper_connection_property.GetNonLinearDamping(i_dof, o_force_array, o_velocity_array)

    def read_damping_data_from_file(self, i_dof, i_file_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReadDampingDataFromFile
                | o Sub ReadDampingDataFromFile(        iDof,
                |                                       iFileName)
                | 
                | Reads damping data from a text file for a damper connection
                | property.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which damping data is asked.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  iFileName
                |      The complete path of the text file which contains the damping data.

                |
        :param i_dof:
        :param i_file_name:
        :return:
        """
        return self.abq_damper_connection_property.ReadDampingDataFromFile(i_dof, i_file_name)

    def remove_axis_system(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAxisSystem
                | o Sub RemoveAxisSystem(    )
                | 
                |
                | Parameters:

                |
        :return:
        """
        return self.abq_damper_connection_property.RemoveAxisSystem()

    def remove_dof(self, i_dof):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveDof
                | o Sub RemoveDof(        iDof)
                | 
                | Unsets the linear damping value of the Damper for given
                | degree of freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which damping is set.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF

                |
        :param i_dof:
        :return:
        """
        return self.abq_damper_connection_property.RemoveDof(i_dof)

    def set_linear_damping(self, i_dof, i_damping_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLinearDamping
                | o Sub SetLinearDamping(        iDof,
                |                                iDampingValue)
                | 
                | Sets the linear damping value of the Damper given the degree
                | of freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which damping is set.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  iDampingValue
                |      The Dampingvalue.

                |
        :param i_dof:
        :param i_damping_value:
        :return:
        """
        return self.abq_damper_connection_property.SetLinearDamping(i_dof, i_damping_value)

    def set_non_linear_damping(self, i_dof, i_force_array, i_velocity_array):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNonLinearDamping
                | o Sub SetNonLinearDamping(        iDof,
                |                                   iForceArray,
                |                                   iVelocityArray)
                | 
                | Sets the non-linear damping value of the Damper in the form
                | of array, given the degree of freedom.
                |
                | Parameters:
                | iDof
                |    The degree of freedom for which damping is asked.
                | Legal values:
                |  
                | U1_DOF
                | U2_DOF
                | U3_DOF
                | UR1_DOF
                | UR2_DOF
                | UR3_DOF
                | 
                | 
                |  iForceArray
                |      The array of force values.
                | 
                |  iVelocityArray
                |      The array of displacement values.
                |    The value in velocity array must be greater than previous value .
                |  Refer: CATSafeArrayVariant

                |
        :param i_dof:
        :param i_force_array:
        :param i_velocity_array:
        :return:
        """
        return self.abq_damper_connection_property.SetNonLinearDamping(i_dof, i_force_array, i_velocity_array)

    def __repr__(self):
        return f'ABQDamperConnectionProperty()'
