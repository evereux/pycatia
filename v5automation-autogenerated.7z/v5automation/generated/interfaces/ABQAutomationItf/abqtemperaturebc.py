#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQTemperatureBC(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus Temperature boundary condition (ABQTemperatureBC)
                | feature.Role:Access an Abaqus Temperature boundary condition feature
                | or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_temperature_bc = com_object     

    @property
    def magnitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Magnitude
                | o Property Magnitude(    ) As
                | 
                | Sets or returns the magnitude of the temperature boundary
                | condition. Returns: The magnitude of the temperature
                | boundary condition.
                |

        :return:
        """
        return self.abq_temperature_bc.Magnitude

    @property
    def use_amplitude(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UseAmplitude
                | o Property UseAmplitude(    ) As
                | 
                | Sets or returns the UseAmplitude flag. Returns: A boolean
                | specifying whether an amplitude will be used.
                |

        :return:
        """
        return self.abq_temperature_bc.UseAmplitude

    def __repr__(self):
        return f'ABQTemperatureBC()'
