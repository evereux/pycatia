#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class SpringType_Type(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Spring type Options They are used by theactivateLinkAnchor('ABQSpringC
                | onnectionProperty','','ABQSpringConnectionProperty')object

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.spring_type_type = com_object     

    def __repr__(self):
        return f'SpringType_Type()'
