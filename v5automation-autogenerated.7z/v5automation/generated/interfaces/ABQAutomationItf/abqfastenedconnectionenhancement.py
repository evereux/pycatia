#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQFastenedConnectionEnhancement(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | This interface has been deprecated.Please use ABQFastenedPair instead.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_fastened_connection_enhancement = com_object     

    @property
    def adjust_slave_node(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AdjustSlaveNode
                | o Property AdjustSlaveNode(    ) As
                | 
                | Sets or returns the adjust slave node flag.
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.AdjustSlaveNode

    @property
    def connection_property(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectionProperty
                | o Property ConnectionProperty(    ) As
                | 
                | Sets or returns the connection property.
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.ConnectionProperty

    @property
    def formulation_option(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FormulationOption
                | o Property FormulationOption(    ) As
                | 
                | Sets or returns the formulation option. Returns: The
                | formulation option. Legal values: SOLVERDEFAULT
                | SURFACETOSURFACE NODETOSURFACE
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.FormulationOption

    @property
    def include_shell_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IncludeShellThickness
                | o Property IncludeShellThickness(    ) As
                | 
                | Sets or returns the include shell element thickness flag.
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.IncludeShellThickness

    @property
    def invert_master_surface(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InvertMasterSurface
                | o Property InvertMasterSurface(    ) As
                | 
                | Sets or returns the invert master surface flag.
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.InvertMasterSurface

    @property
    def invert_slave_surface(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InvertSlaveSurface
                | o Property InvertSlaveSurface(    ) As
                | 
                | Sets or returns the invert slave surface flag.
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.InvertSlaveSurface

    @property
    def position_tolerance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PositionTolerance
                | o Property PositionTolerance(    ) As
                | 
                | Sets or returns the position tolerance. Returns: The
                | position tolerance. Legal values: COMPUTED SPECIFIED
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.PositionTolerance

    @property
    def position_tolerance_val(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PositionToleranceVal
                | o Property PositionToleranceVal(    ) As
                | 
                | Sets or returns the position tolerance value
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.PositionToleranceVal

    @property
    def swap_master_slave(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SwapMasterSlave
                | o Property SwapMasterSlave(    ) As
                | 
                | Sets or returns the swap master/slave surface flag.
                |

        :return:
        """
        return self.abq_fastened_connection_enhancement.SwapMasterSlave

    def __repr__(self):
        return f'ABQFastenedConnectionEnhancement()'
