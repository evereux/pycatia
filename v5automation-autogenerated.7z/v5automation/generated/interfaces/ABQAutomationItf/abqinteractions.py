#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQInteractions(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of Abaqus interactions (ABQInteraction) objects
                | attached to
                | anactivateLinkAnchor('ABQInitialStep','','ABQInitialStep')object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_interactions = com_object     

    def add(self, i_interaction_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iInteractionType) As
                | 
                | Creates a new Abaqus interaction and adds it to the
                | collection of Abaqus Interactions.
                |
                | Parameters:
                | iInteractionType
                |     The type of the interaction to create.  
                |  Legal values:
                |  
                |  "ABQSurfaceToSurfaceContact"
                |  "ABQFastenedPair"
                |  "ABQRigidBodyConstraint"
                |  "ABQRigidCoupling"
                |  "ABQSmoothCoupling"
                |  "ABQARSurf"
                | 
                | 
                | 
                |  Returns:
                |   oInteraction    The Abaqus interaction object that was created.

                |                | Examples:
                | The following example creates a Contact pair interaction in
                | the ABQInteractions collection: Dim abaqusInteractions As
                | ABQInteractions Dim abqFPair As ABQFastenedPair Set abqFPair
                | = abaqusInteractions..Add("ABQFastenedPair")

        :param i_interaction_type:
        :return:
        """
        return self.abq_interactions.Add(i_interaction_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus interaction using its index or its name
                | from the collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus interaction to retrieve from
                |    the collection of Abaqus Interactions.
                |    If the index is a number, it specifies the rank of the Abaqus interaction
                |    in the collection. The index of the first Abaqus interaction in the collection is 1,
                |    and the index of the last interaction is Count.
                |    If the index is a string, it specifies the name you assigned to the interaction using
                |    the CATIACollection::Name property.
                |  
                | 
                |  Returns:
                |   The specified 
                | .

                |
        :param i_index:
        :return:
        """
        return self.abq_interactions.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes an Abaqus interaction using its index or its name
                | from the Interaction collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus interaction to retrieve from
                |    the collection of Abaqus Interactions.
                |    If the index is a number, it specifies the rank of the Abaqus interaction
                |    in the collection. The index of the first Abaqus interaction in the collection is 1,
                |    and the index of the last interaction is Count.
                |    If the index is a string, it specifies the name you assigned to the interaction using
                |    the CATIABase::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_interactions.Remove(i_index)

    def __repr__(self):
        return f'ABQInteractions()'
