#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQHeatTransferStep(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus heat transfer step (ABQHeatTransferStep)
                | object.Role:Access an Abaqus heat transfer step object or determine
                | its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_heat_transfer_step = com_object     

    @property
    def boundary_conditions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BoundaryConditions
                | o Property BoundaryConditions(    ) As   (Read Only)
                | 
                | Returns the ABQBoundaryConditions container associated with
                | the step. Example: This example retrieves the
                | ABQBoundaryConditions container abqBCs. Dim abqHeatStep As
                | ABQHeatTransferStep Dim abqBCs As ABQBoundaryConditions Set
                | abqBCs = abqHeatStep.BoundaryConditions
                |

        :return:
        """
        return self.abq_heat_transfer_step.BoundaryConditions

    @property
    def deltmx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Deltmx
                | o Property Deltmx(    ) As
                | 
                | Sets or returns the maximum temperature change to be allowed
                | in an increment during a transient heat transfer analysis.
                | Returns: Maximum temperature change to be allowed in an
                | increment
                |

        :return:
        """
        return self.abq_heat_transfer_step.Deltmx

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As
                | 
                | Sets or returns the description of the step. Returns: The
                | description of the step
                |

        :return:
        """
        return self.abq_heat_transfer_step.Description

    @property
    def end_step_on_temp_change(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EndStepOnTempChange
                | o Property EndStepOnTempChange(    ) As
                | 
                | Sets or returns whether the step should end when steady
                | state is reached. A value of true indicates that the step
                | will end. Returns: A boolean indicating whether the step
                | will end when steady state is reached
                |

        :return:
        """
        return self.abq_heat_transfer_step.EndStepOnTempChange

    @property
    def initial_inc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InitialInc
                | o Property InitialInc(    ) As
                | 
                | Sets or returns the initial increment size. Returns: The
                | initial increment size
                |

        :return:
        """
        return self.abq_heat_transfer_step.InitialInc

    @property
    def loads(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Loads
                | o Property Loads(    ) As   (Read Only)
                | 
                | Returns the ABQLoads container associated with the step.
                | Example: The following example retrieves the ABQLoads
                | container abqLoads: Dim abqHeatStep As ABQHeatTransferStep
                | Dim abqLoads As ABQLoads Set abqLoads = abqHeatStep.Loads
                |

        :return:
        """
        return self.abq_heat_transfer_step.Loads

    @property
    def max_inc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxInc
                | o Property MaxInc(    ) As
                | 
                | Sets or returns the maximum increment size if
                | TimeIncrementationMethod=AUTO_INCREMENT. Returns: The
                | maximum increment size
                |

        :return:
        """
        return self.abq_heat_transfer_step.MaxInc

    @property
    def max_num_inc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaxNumInc
                | o Property MaxNumInc(    ) As
                | 
                | Sets or returns the maximum number of increments if
                | TimeIncrementationMethod=AUTO_INCREMENT. Returns: The
                | maximum number of increments
                |

        :return:
        """
        return self.abq_heat_transfer_step.MaxNumInc

    @property
    def min_inc(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MinInc
                | o Property MinInc(    ) As
                | 
                | Sets or returns the minimum increment size if
                | TimeIncrementationMethod=AUTO_INCREMENT. Returns: The
                | minimum increment size
                |

        :return:
        """
        return self.abq_heat_transfer_step.MinInc

    @property
    def mxdem(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Mxdem
                | o Property Mxdem(    ) As
                | 
                | Sets or returns the maximum allowable emissivity change with
                | temperature and field variables during an increment.
                | Returns: The maximum allowable emissivity change
                |

        :return:
        """
        return self.abq_heat_transfer_step.Mxdem

    @property
    def response(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Response
                | o Property Response(    ) As
                | 
                | Sets or returns the response type. Returns: The response
                | type Legal values: STEADY_STATE TRANSIENT
                |

        :return:
        """
        return self.abq_heat_transfer_step.Response

    @property
    def time_incrementation_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimeIncrementationMethod
                | o Property TimeIncrementationMethod(    ) As
                | 
                | Sets or returns the incrementation type. Returns: The
                | incrementation type Legal values: AUTO_INCREMENT
                | FIXED_INCREMENT
                |

        :return:
        """
        return self.abq_heat_transfer_step.TimeIncrementationMethod

    @property
    def time_period(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TimePeriod
                | o Property TimePeriod(    ) As
                | 
                | Sets or returns the step time. Returns: The step time
                |

        :return:
        """
        return self.abq_heat_transfer_step.TimePeriod

    def __repr__(self):
        return f'ABQHeatTransferStep()'
