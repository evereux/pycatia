#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQFilmCondition(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus film condition (ABQFilmCondition)
                | object.Role:Access an Abaqus film condition object or determine its
                | properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_film_condition = com_object     

    @property
    def apply_user_subroutine(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyUserSubroutine
                | o Property ApplyUserSubroutine(    ) As
                | 
                | Sets or returns the user subroutine flag. Returns: A boolean
                | specifying whether a nonuniform film coefficient is defined
                | in user subroutine FILM.
                |

        :return:
        """
        return self.abq_film_condition.ApplyUserSubroutine

    @property
    def dependencies(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | dependencies
                | o Property dependencies(    ) As   (Read Only)
                | 
                | Returns the number of temperature-dependent film
                | coefficients. Returns: The number of temperature-dependent
                | film coefficients.
                |

        :return:
        """
        return self.abq_film_condition.dependencies

    @property
    def film_coeff(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | filmCoeff
                | o Property filmCoeff(    ) As
                | 
                | Sets or returns the reference film coefficient if the film
                | condition is not temperature dependent. Returns: The
                | reference film coefficient if the film condition is not
                | temperature dependent.
                |

        :return:
        """
        return self.abq_film_condition.filmCoeff

    @property
    def sink_temperature(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | sinkTemperature
                | o Property sinkTemperature(    ) As
                | 
                | Sets or returns the reference sink temperature. Returns: The
                | reference sink temperature.
                |

        :return:
        """
        return self.abq_film_condition.sinkTemperature

    @property
    def temperature_dependency(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | temperatureDependency
                | o Property temperatureDependency(    ) As
                | 
                | Sets or returns the temperature dependency. Returns: A
                | boolean specifying whether the film condition is dependent
                | on temperature.
                |

        :return:
        """
        return self.abq_film_condition.temperatureDependency

    def add_temp_dependent_film_coeff_table(self, i_film_coeff, i_temperature):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddTempDependentFilmCoeffTable
                | o Sub AddTempDependentFilmCoeffTable(        iFilmCoeff,
                |                                              iTemperature)
                | 
                | Adds a list of temperature dependent film coefficients if
                | the film condition is temperature dependent. The number of
                | values in both of the parameters should match. If either
                | list contains extra values, the extra values are discarded.
                |
                | Parameters:
                | iFilmCoeff
                |      The list of film coefficients.
                | 
                |  iTemperature
                |               The  list of temperatures.

                |
        :param i_film_coeff:
        :param i_temperature:
        :return:
        """
        return self.abq_film_condition.AddTempDependentFilmCoeffTable(i_film_coeff, i_temperature)

    def get_name_of_film_coeff_amplitude(self, ofilm_amplitude):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNameOfFilmCoeffAmplitude
                | o Sub GetNameOfFilmCoeffAmplitude(        ofilmAmplitude)
                | 
                | Returns the name of the amplitude that contains the
                | variation of the the film coefficient with time.
                |
                | Parameters:
                | ofilmAmplitude
                |     The name of the amplitude that contains the variation of the the film coefficient with time.

                |
        :param ofilm_amplitude:
        :return:
        """
        return self.abq_film_condition.GetNameOfFilmCoeffAmplitude(ofilm_amplitude)

    def get_name_of_sink_amplitude(self, osink_amplitude):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNameOfSinkAmplitude
                | o Sub GetNameOfSinkAmplitude(        osinkAmplitude)
                | 
                | Returns the name of the amplitude that contains the
                | variation of the sink temperature with time.
                |
                | Parameters:
                | osinkAmplitude
                |     The name of the amplitude that contains the variation of the sink temperature with time.

                |
        :param osink_amplitude:
        :return:
        """
        return self.abq_film_condition.GetNameOfSinkAmplitude(osink_amplitude)

    def get_temp_dependent_film_coeff_table(self, o_film_coeff, o_temperature):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTempDependentFilmCoeffTable
                | o Sub GetTempDependentFilmCoeffTable(        oFilmCoeff,
                |                                              oTemperature)
                | 
                | Returns a list of temperature dependent film coefficients if
                | the film condition is temperature dependent.
                |
                | Parameters:
                | oFilmCoeff
                |      The list of film coefficients.
                | 
                |  oTemperature
                |               The  list of temperatures.

                |
        :param o_film_coeff:
        :param o_temperature:
        :return:
        """
        return self.abq_film_condition.GetTempDependentFilmCoeffTable(o_film_coeff, o_temperature)

    def set_named_film_coeff_amplitude(self, ifilm_amplitude):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNamedFilmCoeffAmplitude
                | o Sub SetNamedFilmCoeffAmplitude(        ifilmAmplitude)
                | 
                | Sets the name of the amplitude that gives the variation of
                | the the film coefficient with time.
                |
                | Parameters:
                | ifilmAmplitude
                |     The name of the amplitude that gives the variation of the the film coefficient with time.

                |
        :param ifilm_amplitude:
        :return:
        """
        return self.abq_film_condition.SetNamedFilmCoeffAmplitude(ifilm_amplitude)

    def set_named_sink_amplitude(self, isink_amplitude):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNamedSinkAmplitude
                | o Sub SetNamedSinkAmplitude(        isinkAmplitude)
                | 
                | Sets the name of the amplitude that contains the variation
                | of the sink temperature with time.
                |
                | Parameters:
                | isinkAmplitude
                |     The name of the amplitude that contains the variation of the sink temperature with time.

                |
        :param isink_amplitude:
        :return:
        """
        return self.abq_film_condition.SetNamedSinkAmplitude(isink_amplitude)

    def __repr__(self):
        return f'ABQFilmCondition()'
