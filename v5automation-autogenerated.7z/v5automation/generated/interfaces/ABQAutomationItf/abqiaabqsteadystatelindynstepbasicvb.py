#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQIAABQSteadyStateLinDynStepBasicVB(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | ABQIAABQSteadyStateLinDynStepBasic are ...Do not use the
                | ABQIAABQSteadyStateLinDynStepBasic interface for such and such
                | ClassReference, Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abqiaabq_steady_state_lin_dyn_step_basic_vb = com_object     

    @property
    def boundary_conditions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BoundaryConditions
                | o Property BoundaryConditions(    ) As   (Read Only)
                | 
                | Returns the ABQBoundaryConditions container associated with
                | the step. Example: This example retrieves the
                | ABQBoundaryConditions container abqBCs. Dim abqSSDStep As
                | ABQSteadStateStep Dim abqBCs As ABQBoundaryConditions Set
                | abqBCs = abqSSDStep.BoundaryConditions
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_basic_vb.BoundaryConditions

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As
                | 
                | Returns or sets the description of the Abaqus steady state
                | dynamic step. Returns: The description of the Abaqus steady
                | state dynamic step.
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_basic_vb.Description

    @description.setter
    def description(self, value):
        """
            :param type value:
        """
        self.abqiaabq_steady_state_lin_dyn_step_basic_vb.Description = value 

    @property
    def interval_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IntervalType
                | o Property IntervalType(    ) As
                | 
                | Returns or sets Interval Type. Returns: The Interval Type.
                | Legal values: 1 - Eigenvalue. 2 - Range. Example: This
                | example sets the Interval Type as Eigenvalue for abqSSDStep
                | abqSSDStep.IntervalType = 1
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_basic_vb.IntervalType

    @interval_type.setter
    def interval_type(self, value):
        """
            :param type value:
        """
        self.abqiaabq_steady_state_lin_dyn_step_basic_vb.IntervalType = value 

    @property
    def loads(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Loads
                | o Property Loads(    ) As   (Read Only)
                | 
                | Returns the ABQLoads container associated with the step.
                | Example: The following example retrieves the ABQLoads
                | container abqLoads: Dim abqSSDStep As ABQSteadStateStep Dim
                | abqLoads As ABQLoads Set abqLoads = abqSSDStep.Loads
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_basic_vb.Loads

    @property
    def scale_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ScaleType
                | o Property ScaleType(    ) As
                | 
                | Returns or sets Scale Type. Returns: The Scale Type. Legal
                | values: 1 - Logarithmic. 2 - Linear. Example: This example
                | sets the Scale Type as Logarithmic for abqSSDStep
                | abqSSDStep.ScaleType = 1
                |

        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_basic_vb.ScaleType

    @scale_type.setter
    def scale_type(self, value):
        """
            :param type value:
        """
        self.abqiaabq_steady_state_lin_dyn_step_basic_vb.ScaleType = value 

    def add_frequency_data_table(self, i_lwr_frequency, i_upr_frequency, i_nb_points, i_bias):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFrequencyDataTable
                | o Sub AddFrequencyDataTable(        iLwrFrequency,
                |                                     iUprFrequency,
                |                                     iNbPoints,
                |                                     iBias)
                | 
                | Adds a list of frequency, real and imaginary The number of
                | values in all the four of the parameters must match. If
                | either list contains extra values, the extra values are
                | discarded.
                |
                | Parameters:
                | iLwrFrequency
                |      The list of lower frequencies.
                | 
                |  iUprFrequency
                |      The list of upper frequencies.
                | 
                |  iNbPoints
                |               The  list of number of points.
                | 
                |  iBias
                |               The  list of bias.

                |
        :param i_lwr_frequency:
        :param i_upr_frequency:
        :param i_nb_points:
        :param i_bias:
        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_basic_vb.AddFrequencyDataTable(i_lwr_frequency, i_upr_frequency, i_nb_points, i_bias)

    def add_global_damping(self, i_alpha, i_beta, i_structural):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddGlobalDamping
                | o Sub AddGlobalDamping(        iAlpha,
                |                                iBeta,
                |                                iStructural)
                | 
                | Returns or sets Global Damping values. Returns: Global
                | Damping values. Copyright © 1999-2011, Dassault Systèmes.
                | All rights reserved.
                |
                | Parameters:

                |
        :param i_alpha:
        :param i_beta:
        :param i_structural:
        :return:
        """
        return self.abqiaabq_steady_state_lin_dyn_step_basic_vb.AddGlobalDamping(i_alpha, i_beta, i_structural)

    def __repr__(self):
        return f'ABQIAABQSteadyStateLinDynStepBasicVB()'
