#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQThermalConnBehavior(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Abaqus thermal connection behavior
                | (ABQThermalConnBehavior) object.Role:Access an Abaqus thermal
                | connection behaviour object or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_thermal_conn_behavior = com_object     

    @property
    def conductance_table_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConductanceTableSize
                | o Property ConductanceTableSize(    ) As   (Read Only)
                | 
                | Returns the size of the conductance table. Returns: The size
                | of the conductance table.
                |

        :return:
        """
        return self.abq_thermal_conn_behavior.ConductanceTableSize

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As
                | 
                | Sets or returns the description. Returns: The description of
                | the step.
                |

        :return:
        """
        return self.abq_thermal_conn_behavior.Description

    @property
    def temperature_dependency(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | temperatureDependency
                | o Property temperatureDependency(    ) As
                | 
                | Sets or returns the temperature dependency. Returns: A
                | boolean specifying whether the values are dependent on
                | temperature.
                |

        :return:
        """
        return self.abq_thermal_conn_behavior.temperatureDependency

    def add_gap_conduction_table(self, i_conductance, i_clearance, i_temperature):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddGapConductionTable
                | o Sub AddGapConductionTable(        iConductance,
                |                                     iClearance,
                |                                     iTemperature)
                | 
                | Adds a gap-conductance table using three lists containing
                | gap, conductance, and temperature values. Temperature list
                | will be ignored if the temperature dependency is OFF. The
                | number of values in all of the parameter lists must match.
                | If either list contains extra values, the extra values are
                | discarded.
                |
                | Parameters:
                | iConductance
                |      The list of conductance values (in W/degK/m^2).
                | 
                |  iClearance
                |               The  list of clearance values (in meter).
                | 
                |  iTemperature
                |               The  list of temperature values (in degK).

                |
        :param i_conductance:
        :param i_clearance:
        :param i_temperature:
        :return:
        """
        return self.abq_thermal_conn_behavior.AddGapConductionTable(i_conductance, i_clearance, i_temperature)

    def get_gap_conduction_table(self, o_conductance, o_clearance, o_temperature):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGapConductionTable
                | o Sub GetGapConductionTable(        oConductance,
                |                                     oClearance,
                |                                     oTemperature)
                | 
                | Returns list(s) containing gap, conductance, and temperature
                | values. Returns: The lists of gap, conductance, and
                | temperature values. The list of temperature values will be
                | ignored if the temperature dependency is OFF.
                |
                | Parameters:
                | oConductance
                |      The list of conductance values (in W/degK/m^2).
                | 
                |  oClearance
                |               The  list of clearance values (in mm).
                | 
                |  oTemperature
                |               The  list of temperature values (in degK).

                |
        :param o_conductance:
        :param o_clearance:
        :param o_temperature:
        :return:
        """
        return self.abq_thermal_conn_behavior.GetGapConductionTable(o_conductance, o_clearance, o_temperature)

    def __repr__(self):
        return f'ABQThermalConnBehavior()'
