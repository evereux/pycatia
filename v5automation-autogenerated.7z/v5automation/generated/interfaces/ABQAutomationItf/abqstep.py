#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQStep(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Abaqus analysis step (ABQStep) object.Role: Access an
                | Abaqus analysis step or determine its properties.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_step = com_object     

    @property
    def data_output_requests(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DataOutputRequests
                | o Property DataOutputRequests(    ) As   (Read Only)
                | 
                | Returns the ABQDataOutputRequests container associated with
                | the step. Example: The following example retrieves the
                | ABQDataOutputRequests container abqOutputRequests: Dim
                | abqStep As ABQGeneralStaticStep Dim abqDataOutputRequests As
                | ABQDataOutputRequests Set abqDataOutputRequests =
                | abqStep.OutputRequests
                |

        :return:
        """
        return self.abq_step.DataOutputRequests

    @property
    def field_output_requests(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FieldOutputRequests
                | o Property FieldOutputRequests(    ) As   (Read Only)
                | 
                | Returns the ABQFieldOutputRequests container associated with
                | the step. Example: The following example retrieves the
                | ABQFieldOutputRequests container abqOutputRequests: Dim
                | abqStep As ABQGeneralStaticStep Dim abqFieldOutputRequests
                | As ABQFieldOutputRequests Set abqFieldOutputRequests =
                | abqStep.OutputRequests
                |

        :return:
        """
        return self.abq_step.FieldOutputRequests

    @property
    def history_output_requests(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HistoryOutputRequests
                | o Property HistoryOutputRequests(    ) As   (Read Only)
                | 
                | Returns the ABQHistoryOutputRequests container associated
                | with the step. Example: The following example retrieves the
                | ABQHistoryOutputRequests container abqOutputRequests: Dim
                | abqStep As ABQGeneralStaticStep Dim abqHistoryOutputRequests
                | As ABQHistoryOutputRequests Set abqHistoryOutputRequests =
                | abqStep.OutputRequests
                |

        :return:
        """
        return self.abq_step.HistoryOutputRequests

    @property
    def interactions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Interactions
                | o Property Interactions(    ) As   (Read Only)
                | 
                | Returns the ABQInteractions container associated with the
                | step. Example: The following example retrieves the
                | ABQInteractions container abqInteractions: Dim abqStep As
                | ABQGeneralStaticStep Dim abqInteractions As ABQInteractions
                | Set abqInteractions = abqStep.Interactions
                |

        :return:
        """
        return self.abq_step.Interactions

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the type of the step. Returns: The string
                | representing the type of the step.
                |

        :return:
        """
        return self.abq_step.Type

    def __repr__(self):
        return f'ABQStep()'
