#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ABQFields(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of Abaqus field (ABQTemperature) objects contained inac
                | tivateLinkAnchor('ABQInitialStep','','ABQInitialStep')andactivateLinkA
                | nchor('ABQGeneralStaticStep','','ABQGeneralStaticStep')andactivateLink
                | Anchor('ABQExplicitDynamicsStep','','ABQExplicitDynamicsStep')objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.abq_fields = com_object     

    def add(self, i_field_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iFieldType) As
                | 
                | Creates a new Abaqus field and adds it to the collection of
                | Abaqus fields. The ABQInitialTemperature object can be
                | created only in an ABQFields collection obtained from
                | ABQInitialStep. Similarly the ABQTemperatureHistory object
                | can be created only in an ABQFields collection obtained from
                | ABQGeneralStaticStep.
                |
                | Parameters:
                | iFieldType
                |     The type of the field to create. 
                |  Legal values:
                |  
                | "ABQInitialTemperature"
                | "ABQTemperatureHistory"
                | 
                | 
                | 
                |  Returns:
                |   oTemperature    The Abaqus field object that was created.

                |                | Examples:
                | The following example creates an initial temperature in the
                | ABQFields collection obtained from the ABQInitialStep type
                | object: Dim abqInitialStep As ABQInitialStep Dim abqFields
                | As ABQIAABQFields Dim abqInitalTemp As ABQTemperature Set
                | abqFields = abqInitialStep.Fields Set abqInitalTemp =
                | abqFields.Add("ABQInitialTemperature")

        :param i_field_type:
        :return:
        """
        return self.abq_fields.Add(i_field_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns an Abaqus field using its index or its name from the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus field to retrieve from
                |    the collection of Abaqus fields.
                |    If the index is a number, it specifies the rank of the Abaqus field
                |    in the collection. The index of the first Abaqus field in the collection is 1,
                |    and the index of the last field is Count.
                |    If the index is a string, it specifies the name you assigned to the field using
                |    the CATIACollection::Name property.
                |    
                |  
                | 
                |  Returns:
                |   The specified 
                | .

                |
        :param i_index:
        :return:
        """
        return self.abq_fields.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes an Abaqus field using its index or its name from the
                | field collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Abaqus field to retrieve from
                |    the collection of Abaqus Fields.
                |    If the index is a number, it specifies the rank of the Abaqus field
                |    in the collection. The index of the first Abaqus field in the collection is 1,
                |    and the index of the last field is Count.
                |    If the index is a string, it specifies the name you assigned to the field using
                |    the CATIABase::Name property.

                |
        :param i_index:
        :return:
        """
        return self.abq_fields.Remove(i_index)

    def __repr__(self):
        return f'ABQFields()'
