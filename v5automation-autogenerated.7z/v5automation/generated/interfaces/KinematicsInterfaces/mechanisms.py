#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Mechanisms(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all Mechanism entities currently managed by the
                | application.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.mechanisms = com_object     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As
                | 
                | Creates a new Mechanism and adds it to the Mechanisms
                | collection. Returns: The created Mechanism Example: This
                | example creates a new Mechanism in the TheMechanisms
                | collection. Dim NewMechanism As Mechanism Set NewMechanism =
                | TheMechanisms.Add()
                |
                | Parameters:

                |
        :return:
        """
        return self.mechanisms.Add()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns a Mechanism using its index or its name from the
                | Mechanisms collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Mechanism to retrieve from
                |    the collection of Mechanisms.
                |    As a numerics, this index is the rank of the Mechanism
                |    in the collection.
                |    The index of the first Mechanism in the collection is 1, and
                |    the index of the last Mechanism is Count.
                |    As a string, it is the name you assigned to the Mechanism using
                |    the 
                | 
                |  property. 
                |    Returns:
                |   The retrieved Mechanism

                |                | Examples:
                | This example returns in ThisMechanism the third Mechanism in
                | the collection, and in ThatMechanism the Mechanism named
                | MyMechanism. Dim ThisMechanism As Mechanism Set
                | ThisMechanism = TheMechanisms.Item(3) Dim ThatMechanism As
                | Mechanism Set ThatMechanism =
                | CATIA.Mechanisms.Item("MyMechanism")

        :param i_index:
        :return:
        """
        return self.mechanisms.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes a Mechanism from the Mechanisms collection.
                |
                | Parameters:
                | iIndex
                |     The index or the name of the Mechanism to retrieve from the collection of mechanisms.
                |     As a numerics, this index is the rank of the Mechanism in the collection.
                |     The index of the first Mechanism in the collection is 1, and
                |     the index of the last Mechanism is Count.
                |     As a string, it is the name you assigned to the Mechanism.
                |  
                | 
                |  Returns:
                |      Nothing

                |                | Examples:
                | The following example removes the tenth Mechanism and the
                | Mechanism named MechanismTwo from the TheMechanisms
                | collection. TheMechanisms.Remove(10)
                | TheMechanisms.Remove("MechanismTwo")

        :param i_index:
        :return:
        """
        return self.mechanisms.Remove(i_index)

    def __repr__(self):
        return f'Mechanisms()'
