#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class KinematicsWorkbench(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access all Kinematics entities.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.kinematics_workbench = com_object     

    @property
    def mechanisms(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Mechanisms
                | o Property Mechanisms(    ) As   (Read Only)
                | 
                | Returns the Mechanisms collection. Returns: The Mechanisms
                | collection Example: This example retrieves the Mechanisms
                | collection of the active document. Dim TheKinWorkbench As
                | Workbench Set TheKinWorkbench =
                | CATIA.ActiveDocument.GetWorkbench ( "KinematicsWorkbench" )
                | Dim TheMechanismsList As Mechanisms Set TheMechanismsList =
                | TheKinWorkbench.Mechanisms
                |

        :return:
        """
        return self.kinematics_workbench.Mechanisms

    def __repr__(self):
        return f'KinematicsWorkbench()'
