#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Joint(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to manage the Joint object.Depending on their type, joints
                | have parameters or not, representing length or angle:Each parameter
                | can have a lower and/or an upper limit.Methods are provided to set,
                | unset and return the limits for each parameter.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.joint = com_object     

    @property
    def current_value1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentValue1
                | o Property CurrentValue1(    ) As   (Read Only)
                | 
                | Gets the joint current value for first parameter.
                |

        :return:
        """
        return self.joint.CurrentValue1

    @property
    def current_value2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentValue2
                | o Property CurrentValue2(    ) As   (Read Only)
                | 
                | Gets the joint current value for second parameter.
                |

        :return:
        """
        return self.joint.CurrentValue2

    @property
    def lower_limit1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LowerLimit1
                | o Property LowerLimit1(    ) As
                | 
                | Gets or returns the lower limit of the joint, for the first
                | parameter.
                |

        :return:
        """
        return self.joint.LowerLimit1

    @property
    def lower_limit2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LowerLimit2
                | o Property LowerLimit2(    ) As
                | 
                | Gets or returns the lower limit of the joint, for the second
                | parameter.
                |

        :return:
        """
        return self.joint.LowerLimit2

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the joint type.
                |

        :return:
        """
        return self.joint.Type

    @property
    def upper_limit1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpperLimit1
                | o Property UpperLimit1(    ) As
                | 
                | Gets or returns the upper limit of the joint, for the first
                | parameter.
                |

        :return:
        """
        return self.joint.UpperLimit1

    @property
    def upper_limit2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpperLimit2
                | o Property UpperLimit2(    ) As
                | 
                | Gets or returns the upper limit of the joint, for the second
                | parameter.
                |

        :return:
        """
        return self.joint.UpperLimit2

    def unset_lower_limit1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetLowerLimit1
                | o Sub UnsetLowerLimit1(    )
                | 
                | Unsets the lower limit of the joint, for the first
                | parameter.
                |
                | Parameters:
                | iLimitValue
                |      The value for the limit
                |  When reading, an error is returned if the joint type has no such parameter, or if the limit is unset.

                |
        :return:
        """
        return self.joint.UnsetLowerLimit1()

    def unset_lower_limit2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetLowerLimit2
                | o Sub UnsetLowerLimit2(    )
                | 
                | Unsets the lower limit of the joint, for the second
                | parameter.
                |
                | Parameters:
                | iLimitValue
                |      The value for the limit

                |
        :return:
        """
        return self.joint.UnsetLowerLimit2()

    def unset_upper_limit1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetUpperLimit1
                | o Sub UnsetUpperLimit1(    )
                | 
                | Unsets the upper limit of the joint, for the first
                | parameter.
                |
                | Parameters:
                | iLimitValue
                |      The value for the limit

                |
        :return:
        """
        return self.joint.UnsetUpperLimit1()

    def unset_upper_limit2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnsetUpperLimit2
                | o Sub UnsetUpperLimit2(    )
                | 
                | Unsets the upper limit of the joint, for the second
                | parameter.
                |
                | Parameters:
                | iLimitValue
                |      The value for the limit

                |
        :return:
        """
        return self.joint.UnsetUpperLimit2()

    def __repr__(self):
        return f'Joint()'
