#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Joints(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all Joint entities currently managed by the
                | application.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.joints = com_object     

    def add(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(    ) As
                | 
                | Create a new Joint and adds it to the Joints collection.
                | Returns: The created Joint Example: This example creates a
                | new Joint in the TheJoints collection. Dim NewJoint As Joint
                | Set NewJoint = TheJoints.Add()
                |
                | Parameters:

                |
        :return:
        """
        return self.joints.Add()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns a Joint using its index or its name from the Joints
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Joint to retrieve from
                |    the collection of Joints.
                |    As a numerics, this index is the rank of the Joint
                |    in the collection.
                |    The index of the first Joint in the collection is 1, and
                |    the index of the last Joint is Count.
                |    As a string, it is the name you assigned to the Joint using
                |    the 
                | 
                |  property. 
                |    Returns:
                |   The retrieved Joint

                |                | Examples:
                | This example returns in ThisJoint the third Joint in the
                | collection, and in ThatJoint the Joint named MyJoint. Dim
                | ThisJoint As Joint Set ThisJoint = TheJoints.Item(3) Dim
                | ThatJoint As Joint Set ThatJoint =
                | CATIA.Joints.Item("MyJoint")

        :param i_index:
        :return:
        """
        return self.joints.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Remove a Joint from the Joints collection.
                |
                | Parameters:
                | iIndex
                |     The index or the name of the Joint to retrieve from the collection of Joints.
                |     As a numerics, this index is the rank of the Joint in the collection.
                |     The index of the first Joint in the collection is 1, and
                |     the index of the last Joint is Count.
                |     As a string, it is the name you assigned to the Joint.
                |  
                | 
                |  Returns:
                |      Nothing

                |                | Examples:
                | The following example removes the tenth Joint and the Joint
                | named JointTwo from the TheJoints collection.
                | TheJoints.Remove(10) TheJoints.Remove("JointTwo")

        :param i_index:
        :return:
        """
        return self.joints.Remove(i_index)

    def __repr__(self):
        return f'Joints()'
