#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Dressups(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of all Dressup entities currently managed by the
                | application.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.dressups = com_object     

    def add(self, i_mechanism, i_context):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iMechanism,
                |                    iContext) As
                | 
                | Creates a new Dressup and adds it to the Dressups
                | collection.
                |
                | Parameters:
                | iMechanism
                |    The mechanism on which the dressup will apply. 
                |  
                |  iContext
                |    The Context product on which the mechanism is defined
                |  
                | 
                |  Returns:
                |      The created Dressup

                |                | Examples:
                | This example creates a new Dressup in the TheDressups
                | collection. Dim NewDressup As Dressup Set NewDressup =
                | TheDressups.Add(Mechanism)

        :param i_mechanism:
        :param i_context:
        :return:
        """
        return self.dressups.Add(i_mechanism, i_context)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns a Dressup using its index or its name from the
                | Dressups collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the Dressup to retrieve from
                |    the collection of Dressups.
                |    As a numerics, this index is the rank of the Dressup
                |    in the collection.
                |    The index of the first Dressup in the collection is 1, and
                |    the index of the last Dressup is Count.
                |    As a string, it is the name you assigned to the Dressup using
                |    the 
                | 
                |  property. 
                |    Returns:
                |      The retrieved Dressup

                |                | Examples:
                | This example returns in ThisDressup the third Dressup in the
                | collection, and in ThatDressup the Dressup named MyDressup.
                | Dim ThisDressup As Dressup Set ThisDressup =
                | TheDressups.Item(3) Dim ThatDressup As Dressup Set
                | ThatDressup = CATIA.Dressups.Item("MyDressup")

        :param i_index:
        :return:
        """
        return self.dressups.Item(i_index)

    def list_mechanisms_context(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListMechanismsContext
                | o Func ListMechanismsContext(    ) As
                | 
                | Each mechanism of the list given by ListPossibleMechanisms
                | has a context product on which it is defined.
                |
                | Parameters:
                | Nothing
                | 
                | 
                | 
                |  Returns:
                |      The list of mechanisms' contexts on which a dressup can be created. 
                |     The context of oMechanismList(i) is oContextList(i).

                |                | Examples:
                | The following example returns the first and the last element
                | of the list of mechanisms' contexts. We assume that this
                | list contains at least two values. Dim ContextList As
                | Product ContextList = MyDressups.ListMechanismsContext() Dim
                | FirstContext As Product Set FirstContext = ContextList(0)
                | Dim LastContext As Product Set LastContext =
                | ContextList(ubound(ContextList))

        :return:
        """
        return self.dressups.ListMechanismsContext()

    def list_possible_mechanisms(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListPossibleMechanisms
                | o Func ListPossibleMechanisms(    ) As
                | 
                | Returns information about all possible mechanisms on which a
                | dressup can be created.
                |
                | Parameters:
                | Nothing
                | 
                | 
                | 
                |  Returns:
                |      The list of possible mechanisms on which a dressup can be created.

                |                | Examples:
                | The following example returns the first and the last element
                | of the list of possible mechanisms. We assume that this list
                | contains at least two values. Dim PossibleMecList As
                | Mechanism PossibleMecList =
                | MyDressups.ListPossibleMechanisms() Dim FirstMeca As
                | Mechanism Set Meca = PossibleMecList(0) Dim LastMeca As
                | Mechanism Set Meca =
                | PossibleMecList(ubound(PossibleMecList))

        :return:
        """
        return self.dressups.ListPossibleMechanisms()

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes a Dressup from the Dressups collection.
                |
                | Parameters:
                | iIndex
                |     The index or the name of the Dressup to retrieve from the collection of Dressups.
                |     As a numerics, this index is the rank of the Dressup in the collection.
                |     The index of the first Dressup in the collection is 1, and
                |     the index of the last Dressup is Count.
                |     As a string, it is the name you assigned to the Dressup.
                |  
                | 
                |  Returns:
                |      Nothing

                |                | Examples:
                | The following example removes the tenth Dressup and the
                | Dressup named DressupTwo from the TheDressups collection.
                | TheDressups.Remove(10) TheDressups.Remove("DressupTwo")

        :param i_index:
        :return:
        """
        return self.dressups.Remove(i_index)

    def __repr__(self):
        return f'Dressups()'
