#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class MechanismCommand(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access the Command object (in Kinematics context).

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.mechanism_command = com_object     

    @property
    def current_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurrentValue
                | o Property CurrentValue(    ) As   (Read Only)
                | 
                | Returns the current value for a command.
                |

        :return:
        """
        return self.mechanism_command.CurrentValue

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property Orientation(    ) As
                | 
                | Deprecated: V5R18 Not implemented - will be deprecated
                | Returns or sets the command orientation.
                |

        :return:
        """
        return self.mechanism_command.Orientation

    @orientation.setter
    def orientation(self, value):
        """
            :param type value:
        """
        self.mechanism_command.Orientation = value 

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the command type.
                |

        :return:
        """
        return self.mechanism_command.Type

    def __repr__(self):
        return f'MechanismCommand()'
