#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AttachmentCont(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | DNBIABasicDevice are ...Do not use the DNBIAMRLDocAttachments
                | interface for such and such ClassReference, Class#MethodReference,
                | #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.attachment_cont = com_object     

    def get_attachment_factory(self, o_attach_factory):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAttachmentFactory
                | o Sub GetAttachmentFactory(        oAttachFactory)
                | 
                | Get the AttachmentFactory for the current document
                |
                | Parameters:
                | oAttachFactory
                |    This output parameter contains the AttachmentFactory for the current document.
                |  
                | 
                |  Returns:
                |      An HRESULT

                |
        :param o_attach_factory:
        :return:
        """
        return self.attachment_cont.GetAttachmentFactory(o_attach_factory)

    def get_listof_attachments(self, o_attach_list):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetListofAttachments
                | o Sub GetListofAttachments(        oAttachList)
                | 
                | Get list of attachments from the Attachment Container
                |
                | Parameters:
                | oAttachList
                |    This output parameter contains the list of attachments in a document.
                |  
                | 
                |  Returns:
                |      An HRESULT

                |
        :param o_attach_list:
        :return:
        """
        return self.attachment_cont.GetListofAttachments(o_attach_list)

    def __repr__(self):
        return f'AttachmentCont()'
