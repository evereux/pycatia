#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DNBAttachment(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | DNBIABasicDevice are ...Do not use the DNBIAMRLAttachment interface
                | for such and such ClassReference, Class#MethodReference,
                | #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.dnb_attachment = com_object     

    def get_child(self, o_child):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetChild
                | o Sub GetChild(        oChild)
                | 
                | Get the Child Product of the Attachment.
                |
                | Parameters:
                | oChild
                |    This out parameter contains the Child Product .    
                |  
                | 
                |  Returns:
                |   HRESULT  indicate whether function succeed.

                |
        :param o_child:
        :return:
        """
        return self.dnb_attachment.GetChild(o_child)

    def get_child_ma(self, o_child_ma):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetChildMA
                | o Sub GetChildMA(        oChildMA)
                | 
                | Get the Child Manufacturing Assembly of the Attachment
                |
                | Parameters:
                | oChildMA
                |    This out parameter contains Child Manufacturing Assembly of the Attachment .    
                |  
                | 
                |  Returns:
                |   HRESULT  indicate whether function succeeded. It fails if the Child is not a Manufacturing Assembly

                |
        :param o_child_ma:
        :return:
        """
        return self.dnb_attachment.GetChildMA(o_child_ma)

    def get_parent(self, o_parent):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetParent
                | o Sub GetParent(        oParent)
                | 
                | Get the Parent Product of the Attachment.
                |
                | Parameters:
                | oParent
                |    This outer parameter contains the Parent Product .    
                |  
                | 
                |  Returns:
                |      An HRESULT

                |
        :param o_parent:
        :return:
        """
        return self.dnb_attachment.GetParent(o_parent)

    def get_parent_ma(self, o_parent_ma):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetParentMA
                | o Sub GetParentMA(        oParentMA)
                | 
                | Get the Parent Manufacturing Assembly of the Attachment.
                |
                | Parameters:
                | oParentMA
                |    This out parameter contains the Parent MA of the attachment .    
                |  
                |  idbTrans
                |    This parameter contains distance data in Meters 
                |     or angular data in degree radian.    
                |  
                | 
                |  Returns:
                |   HRESULT  indicate whether function succeed. It fails if the Parent is not a Manufacturing Assembly

                |
        :param o_parent_ma:
        :return:
        """
        return self.dnb_attachment.GetParentMA(o_parent_ma)

    def is_child_ma(self, i_child_ma):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsChildMA
                | o Sub IsChildMA(        iChildMA)
                | 
                | Get whether the Child is a Manufacturing Assembly
                |
                | Parameters:
                | iChildMA
                |    TRUE if child is MA, FALSE otherwise
                |  
                | 
                |  Returns:
                |   HRESULT  indicate whether function succeeded. It fails if the Child is not a Manufacturing Assembly

                |
        :param i_child_ma:
        :return:
        """
        return self.dnb_attachment.IsChildMA(i_child_ma)

    def is_parent_ma(self, i_parent_ma):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsParentMA
                | o Sub IsParentMA(        iParentMA)
                | 
                | Get whether the Parent is a Manufacturing Assembly
                |
                | Parameters:
                | iParentMA
                |    TRUE if Parent is MA, FALSE otherwise    
                |  
                | 
                |  Returns:
                |   HRESULT  indicate whether function succeeded. It fails if the Parent is not a Manufacturing Assembly

                |
        :param i_parent_ma:
        :return:
        """
        return self.dnb_attachment.IsParentMA(i_parent_ma)

    def __repr__(self):
        return f'DNBAttachment()'
