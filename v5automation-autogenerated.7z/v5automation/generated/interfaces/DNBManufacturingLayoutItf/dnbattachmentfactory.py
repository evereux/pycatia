#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DNBAttachmentFactory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | DNBIABasicDevice are ...Do not use the DNBIAMRLAttachmentFactory
                | interface for such and such ClassReference, Class#MethodReference,
                | #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.dnb_attachment_factory = com_object     

    def attach(self, i_parent, i_child, o_attachment):
        """
        .. note::
            CAA V5 Visual Basic help

                | Attach
                | o Sub Attach(        iParent,
                |                      iChild,
                |                      oAttachment)
                | 
                | Attach a Product/MA with another Product/MA
                |
                | Parameters:
                | iParent
                |    This input parameter contains the Parent product/MA of the attachment to be created   
                |  
                |  iChild
                |    This input parameter contains the Child product/MA of the attachment to be created   
                |  
                |  oAttachment
                |    This output parameter contains the attachment that is created. 
                |  
                | 
                |  Returns:
                |      An HRESULT

                |
        :param i_parent:
        :param i_child:
        :param o_attachment:
        :return:
        """
        return self.dnb_attachment_factory.Attach(i_parent, i_child, o_attachment)

    def remove(self, i_attachment):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iAttachment)
                | 
                | Remove an attachment.
                |
                | Parameters:
                | iAttachment
                |    This input parameter contains the Attachment to be deleted.    
                |  
                | 
                |  Returns:
                |      An HRESULT

                |
        :param i_attachment:
        :return:
        """
        return self.dnb_attachment_factory.Remove(i_attachment)

    def __repr__(self):
        return f'DNBAttachmentFactory()'
