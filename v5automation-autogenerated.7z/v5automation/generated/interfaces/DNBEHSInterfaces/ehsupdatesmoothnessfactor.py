#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class EHSUpdateSmoothnessFactor(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | DNBIAEHSUpdateSmoothnessFactor are ...Do not use the
                | DNBIAEHSUpdateSmoothnessFactor interface for such and such
                | ClassReference, Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.ehs_update_smoothness_factor = com_object     

    def update_bundle_smoothness(self, i_smoothness_factor):
        """
        .. note::
            CAA V5 Visual Basic help

                | UpdateBundleSmoothness
                | o Sub UpdateBundleSmoothness(        iSmoothnessFactor)
                | 
                | Sets Smoothness Factor for Bundle segment.
                |
                | Parameters:
                | iSmoothnessFactor
                |      the input smoothness factor.
                |    
                | 
                |  Returns:
                |                           An HRESULT
                |    Legal values:
                |    
                | S_OK if the Property is returned successfully. 
                | E_FAIL otherwise .

                |
        :param i_smoothness_factor:
        :return:
        """
        return self.ehs_update_smoothness_factor.UpdateBundleSmoothness(i_smoothness_factor)

    def __repr__(self):
        return f'EHSUpdateSmoothnessFactor()'
