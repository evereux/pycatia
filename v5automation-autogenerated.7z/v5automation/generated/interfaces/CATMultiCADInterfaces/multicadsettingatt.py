#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class MultiCADSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.multi_cad_setting_att = com_object     

    @property
    def annotation_3d_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Annotation3DMode
                | o Property Annotation3DMode(    ) As
                | 
                | Returns or sets the Annotation 3D mode R18sp3 on env.
                | variable
                |

        :return:
        """
        return self.multi_cad_setting_att.Annotation3DMode

    @annotation_3d_mode.setter
    def annotation_3d_mode(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.Annotation3DMode = value 

    @property
    def conversion_technology(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConversionTechnology
                | o Property ConversionTechnology(    ) As
                | 
                | Returns or sets the Conversion Technology
                |

        :return:
        """
        return self.multi_cad_setting_att.ConversionTechnology

    @conversion_technology.setter
    def conversion_technology(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.ConversionTechnology = value 

    @property
    def ideas_component_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IdeasComponentName
                | o Property IdeasComponentName(    ) As
                | 
                | Returns or sets the IdeasComponentName
                |

        :return:
        """
        return self.multi_cad_setting_att.IdeasComponentName

    @ideas_component_name.setter
    def ideas_component_name(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.IdeasComponentName = value 

    @property
    def ideas_component_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IdeasComponentType
                | o Property IdeasComponentType(    ) As
                | 
                | Returns or sets the IdeasComponentType
                |

        :return:
        """
        return self.multi_cad_setting_att.IdeasComponentType

    @ideas_component_type.setter
    def ideas_component_type(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.IdeasComponentType = value 

    @property
    def ideas_library_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IdeasLibraryName
                | o Property IdeasLibraryName(    ) As
                | 
                | Returns or sets the IdeasLibraryName
                |

        :return:
        """
        return self.multi_cad_setting_att.IdeasLibraryName

    @ideas_library_name.setter
    def ideas_library_name(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.IdeasLibraryName = value 

    @property
    def ideas_part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IdeasPartNumber
                | o Property IdeasPartNumber(    ) As
                | 
                | Returns or sets the IdeasPartNumber
                |

        :return:
        """
        return self.multi_cad_setting_att.IdeasPartNumber

    @ideas_part_number.setter
    def ideas_part_number(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.IdeasPartNumber = value 

    @property
    def ideas_project_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IdeasProjectName
                | o Property IdeasProjectName(    ) As
                | 
                | Returns or sets the IdeasProjectName
                |

        :return:
        """
        return self.multi_cad_setting_att.IdeasProjectName

    @ideas_project_name.setter
    def ideas_project_name(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.IdeasProjectName = value 

    @property
    def ideas_rev_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IdeasRevNumber
                | o Property IdeasRevNumber(    ) As
                | 
                | Returns or sets the IdeasRevNumber
                |

        :return:
        """
        return self.multi_cad_setting_att.IdeasRevNumber

    @ideas_rev_number.setter
    def ideas_rev_number(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.IdeasRevNumber = value 

    @property
    def ideas_tess_param(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IdeasTessParam
                | o Property IdeasTessParam(    ) As
                | 
                | Returns or sets the Ideas Tessellation Parameter
                |

        :return:
        """
        return self.multi_cad_setting_att.IdeasTessParam

    @ideas_tess_param.setter
    def ideas_tess_param(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.IdeasTessParam = value 

    @property
    def idi3d_annotation_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Idi3dAnnotationMode
                | o Property Idi3dAnnotationMode(    ) As
                | 
                | Returns or sets the IDI 3D Annotation Mode
                |

        :return:
        """
        return self.multi_cad_setting_att.Idi3dAnnotationMode

    @idi3d_annotation_mode.setter
    def idi3d_annotation_mode(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.Idi3dAnnotationMode = value 

    @property
    def link_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LinkMode
                | o Property LinkMode(    ) As
                | 
                | Returns or sets the Link Mode
                |

        :return:
        """
        return self.multi_cad_setting_att.LinkMode

    @link_mode.setter
    def link_mode(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.LinkMode = value 

    @property
    def output_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OutputPath
                | o Property OutputPath(    ) As
                | 
                | Returns or sets the Output Path
                |

        :return:
        """
        return self.multi_cad_setting_att.OutputPath

    @output_path.setter
    def output_path(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.OutputPath = value 

    @property
    def parts_parameter_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartsParameterMode
                | o Property PartsParameterMode(    ) As
                | 
                | Returns or sets the parts parameterization mode
                |

        :return:
        """
        return self.multi_cad_setting_att.PartsParameterMode

    @parts_parameter_mode.setter
    def parts_parameter_mode(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.PartsParameterMode = value 

    @property
    def pro_e_instance_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProEInstanceMode
                | o Property ProEInstanceMode(    ) As
                | 
                | Returns or sets the ProEInstanceMode
                |

        :return:
        """
        return self.multi_cad_setting_att.ProEInstanceMode

    @pro_e_instance_mode.setter
    def pro_e_instance_mode(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.ProEInstanceMode = value 

    @property
    def pro_e_instance_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProEInstanceName
                | o Property ProEInstanceName(    ) As
                | 
                | Returns or sets the ProEInstanceName
                |

        :return:
        """
        return self.multi_cad_setting_att.ProEInstanceName

    @pro_e_instance_name.setter
    def pro_e_instance_name(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.ProEInstanceName = value 

    @property
    def pro_e_quilts_read(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProEQuiltsRead
                | o Property ProEQuiltsRead(    ) As
                | 
                | Returns or sets the ProEQuiltsRead
                |

        :return:
        """
        return self.multi_cad_setting_att.ProEQuiltsRead

    @pro_e_quilts_read.setter
    def pro_e_quilts_read(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.ProEQuiltsRead = value 

    @property
    def pro_e_simp_rep_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProESimpRepMode
                | o Property ProESimpRepMode(    ) As
                | 
                | Returns or sets the ProESimpRepMode
                |

        :return:
        """
        return self.multi_cad_setting_att.ProESimpRepMode

    @pro_e_simp_rep_mode.setter
    def pro_e_simp_rep_mode(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.ProESimpRepMode = value 

    @property
    def pro_e_simp_rep_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProESimpRepName
                | o Property ProESimpRepName(    ) As
                | 
                | Returns or sets the ProESimpRepName
                |

        :return:
        """
        return self.multi_cad_setting_att.ProESimpRepName

    @pro_e_simp_rep_name.setter
    def pro_e_simp_rep_name(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.ProESimpRepName = value 

    @property
    def save_coorsys_in_cgr(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveCoorsysInCgr
                | o Property SaveCoorsysInCgr(    ) As
                | 
                | Returns or sets the Save Coordinate Systems in CGR
                |

        :return:
        """
        return self.multi_cad_setting_att.SaveCoorsysInCgr

    @save_coorsys_in_cgr.setter
    def save_coorsys_in_cgr(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.SaveCoorsysInCgr = value 

    @property
    def translator_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TranslatorMode
                | o Property TranslatorMode(    ) As
                | 
                | Returns or sets the Translator mode
                |

        :return:
        """
        return self.multi_cad_setting_att.TranslatorMode

    @translator_mode.setter
    def translator_mode(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.TranslatorMode = value 

    @property
    def ug_active_layers_only(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UGActiveLayersOnly
                | o Property UGActiveLayersOnly(    ) As
                | 
                | Returns or sets the UGActiveLayersOnly
                |

        :return:
        """
        return self.multi_cad_setting_att.UGActiveLayersOnly

    @ug_active_layers_only.setter
    def ug_active_layers_only(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.UGActiveLayersOnly = value 

    @property
    def ug_drawing_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UGDrawingName
                | o Property UGDrawingName(    ) As
                | 
                | Returns or sets the UGDrawingName
                |

        :return:
        """
        return self.multi_cad_setting_att.UGDrawingName

    @ug_drawing_name.setter
    def ug_drawing_name(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.UGDrawingName = value 

    @property
    def ug_layer_numbers(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UGLayerNumbers
                | o Property UGLayerNumbers(    ) As
                | 
                | Returns or sets the UGLayerNumbers
                |

        :return:
        """
        return self.multi_cad_setting_att.UGLayerNumbers

    @ug_layer_numbers.setter
    def ug_layer_numbers(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.UGLayerNumbers = value 

    @property
    def ug_open_surfaces(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UGOpenSurfaces
                | o Property UGOpenSurfaces(    ) As
                | 
                | Returns or sets the UGOpenSurfaces
                |

        :return:
        """
        return self.multi_cad_setting_att.UGOpenSurfaces

    @ug_open_surfaces.setter
    def ug_open_surfaces(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.UGOpenSurfaces = value 

    @property
    def ug_reference_set(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UgReferenceSet
                | o Property UgReferenceSet(    ) As
                | 
                | Returns or sets the UgReferenceSet
                |

        :return:
        """
        return self.multi_cad_setting_att.UgReferenceSet

    @ug_reference_set.setter
    def ug_reference_set(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.UgReferenceSet = value 

    @property
    def visu_format_unit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuFormatUnit
                | o Property VisuFormatUnit(    ) As
                | 
                | Returns or sets the Unit for Visu Format (number of
                | milimeters per unit of the file)
                |

        :return:
        """
        return self.multi_cad_setting_att.VisuFormatUnit

    @visu_format_unit.setter
    def visu_format_unit(self, value):
        """
            :param type value:
        """
        self.multi_cad_setting_att.VisuFormatUnit = value 

    def get_annotation_3d_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotation3DModeInfo
                | o Func GetAnnotation3DModeInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the Annotation3DMode
                | parameter. Role:Retrieves the state of the Annotation3DMode
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetAnnotation3DModeInfo(io_admin_level, io_locked)

    def get_conversion_technology_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetConversionTechnologyInfo
                | o Func GetConversionTechnologyInfo(        ioAdminLevel,
                |                                            ioLocked) As
                | 
                | Retrieves environment informations for the
                | ConversionTechnology parameter. Role:Retrieves the state of
                | the ConversionTechnology parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetConversionTechnologyInfo(io_admin_level, io_locked)

    def get_ideas_component_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdeasComponentNameInfo
                | o Func GetIdeasComponentNameInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | IdeasComponentName parameter. Role:Retrieves the state of
                | the IdeasComponentName parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetIdeasComponentNameInfo(io_admin_level, io_locked)

    def get_ideas_component_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdeasComponentTypeInfo
                | o Func GetIdeasComponentTypeInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | IdeasComponentType parameter. Role:Retrieves the state of
                | the IdeasComponentType parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetIdeasComponentTypeInfo(io_admin_level, io_locked)

    def get_ideas_library_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdeasLibraryNameInfo
                | o Func GetIdeasLibraryNameInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the IdeasLibraryName
                | parameter. Role:Retrieves the state of the IdeasLibraryName
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetIdeasLibraryNameInfo(io_admin_level, io_locked)

    def get_ideas_part_number_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdeasPartNumberInfo
                | o Func GetIdeasPartNumberInfo(        ioAdminLevel,
                |                                       ioLocked) As
                | 
                | Retrieves environment informations for the IdeasPartNumber
                | parameter. Role:Retrieves the state of the IdeasPartNumber
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetIdeasPartNumberInfo(io_admin_level, io_locked)

    def get_ideas_project_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdeasProjectNameInfo
                | o Func GetIdeasProjectNameInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the IdeasProjectName
                | parameter. Role:Retrieves the state of the IdeasProjectName
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetIdeasProjectNameInfo(io_admin_level, io_locked)

    def get_ideas_rev_number_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdeasRevNumberInfo
                | o Func GetIdeasRevNumberInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the IdeasRevNumber
                | parameter. Role:Retrieves the state of the IdeasRevNumber
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetIdeasRevNumberInfo(io_admin_level, io_locked)

    def get_ideas_tess_param_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdeasTessParamInfo
                | o Func GetIdeasTessParamInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the IdeasTessParam
                | parameter. Role:Retrieves the state of the IdeasTessParam
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetIdeasTessParamInfo(io_admin_level, io_locked)

    def get_idi3d_annotation_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIdi3dAnnotationModeInfo
                | o Func GetIdi3dAnnotationModeInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves environment informations for the
                | Idi3dAnnotationMode parameter. Role:Retrieves the state of
                | the Idi3dAnnotationMode parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetIdi3dAnnotationModeInfo(io_admin_level, io_locked)

    def get_link_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLinkModeInfo
                | o Func GetLinkModeInfo(        ioAdminLevel,
                |                                ioLocked) As
                | 
                | Retrieves environment informations for the LinkMode
                | parameter. Role:Retrieves the state of the LinkMode
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetLinkModeInfo(io_admin_level, io_locked)

    def get_output_path_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOutputPathInfo
                | o Func GetOutputPathInfo(        ioAdminLevel,
                |                                  ioLocked) As
                | 
                | Retrieves environment informations for the OutputPath
                | parameter. Role:Retrieves the state of the OutputPath
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetOutputPathInfo(io_admin_level, io_locked)

    def get_parts_parameter_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPartsParameterModeInfo
                | o Func GetPartsParameterModeInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | PartsParameterMode parameter. Role:Retrieves the state of
                | the PartsParameterMode parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetPartsParameterModeInfo(io_admin_level, io_locked)

    def get_pro_e_instance_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProEInstanceModeInfo
                | o Func GetProEInstanceModeInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the ProEInstanceMode
                | parameter. Role:Retrieves the state of the ProEInstanceMode
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetProEInstanceModeInfo(io_admin_level, io_locked)

    def get_pro_e_instance_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProEInstanceNameInfo
                | o Func GetProEInstanceNameInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the ProEInstanceName
                | parameter. Role:Retrieves the state of the ProEInstanceName
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetProEInstanceNameInfo(io_admin_level, io_locked)

    def get_pro_e_quilts_read_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProEQuiltsReadInfo
                | o Func GetProEQuiltsReadInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the ProEQuiltsRead
                | parameter. Role:Retrieves the state of the ProEQuiltsRead
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetProEQuiltsReadInfo(io_admin_level, io_locked)

    def get_pro_e_simp_rep_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProESimpRepModeInfo
                | o Func GetProESimpRepModeInfo(        ioAdminLevel,
                |                                       ioLocked) As
                | 
                | Retrieves environment informations for the ProESimpRepMode
                | parameter. Role:Retrieves the state of the ProESimpRepMode
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetProESimpRepModeInfo(io_admin_level, io_locked)

    def get_pro_e_simp_rep_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProESimpRepNameInfo
                | o Func GetProESimpRepNameInfo(        ioAdminLevel,
                |                                       ioLocked) As
                | 
                | Retrieves environment informations for the ProESimpRepName
                | parameter. Role:Retrieves the state of the ProESimpRepName
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetProESimpRepNameInfo(io_admin_level, io_locked)

    def get_save_coorsys_in_cgr_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSaveCoorsysInCgrInfo
                | o Func GetSaveCoorsysInCgrInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the SaveCoorsysInCgr
                | parameter. Role:Retrieves the state of the SaveCoorsysInCgr
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetSaveCoorsysInCgrInfo(io_admin_level, io_locked)

    def get_translator_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTranslatorModeInfo
                | o Func GetTranslatorModeInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the Translator mode
                | parameter. Role:Retrieves the state of the Translator mode
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetTranslatorModeInfo(io_admin_level, io_locked)

    def get_ug_active_layers_only_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUGActiveLayersOnlyInfo
                | o Func GetUGActiveLayersOnlyInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | UGActiveLayersOnly parameter. Role:Retrieves the state of
                | the UGActiveLayersOnly parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetUGActiveLayersOnlyInfo(io_admin_level, io_locked)

    def get_ug_drawing_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUGDrawingNameInfo
                | o Func GetUGDrawingNameInfo(        ioAdminLevel,
                |                                     ioLocked) As
                | 
                | Retrieves environment informations for the UGDrawingName
                | parameter. Role:Retrieves the state of the UGDrawingName
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetUGDrawingNameInfo(io_admin_level, io_locked)

    def get_ug_layer_numbers_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUGLayerNumbersInfo
                | o Func GetUGLayerNumbersInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the UGLayerNumbers
                | parameter. Role:Retrieves the state of the UGLayerNumbers
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetUGLayerNumbersInfo(io_admin_level, io_locked)

    def get_ug_open_surfaces_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUGOpenSurfacesInfo
                | o Func GetUGOpenSurfacesInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the UGOpenSurfaces
                | parameter. Role:Retrieves the state of the UGOpenSurfaces
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetUGOpenSurfacesInfo(io_admin_level, io_locked)

    def get_ug_reference_set_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetUgReferenceSetInfo
                | o Func GetUgReferenceSetInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the UgReferenceSet
                | parameter. Role:Retrieves the state of the UgReferenceSet
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetUgReferenceSetInfo(io_admin_level, io_locked)

    def get_visu_format_unit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetVisuFormatUnitInfo
                | o Func GetVisuFormatUnitInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the VisuFormatUnit
                | parameter. Role:Retrieves the state of the VisuFormatUnit
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                |    If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.multi_cad_setting_att.GetVisuFormatUnitInfo(io_admin_level, io_locked)

    def set_annotation_3d_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotation3DModeLock
                | o Sub SetAnnotation3DModeLock(        iLocked)
                | 
                | Locks or unlocks the Annotation3DMode parameter. Role:Locks
                | or unlocks the Annotation3DMode parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetAnnotation3DModeLock(i_locked)

    def set_conversion_technology_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetConversionTechnologyLock
                | o Sub SetConversionTechnologyLock(        iLocked)
                | 
                | Locks or unlocks the ConversionTechnology parameter.
                | Role:Locks or unlocks the ConversionTechnology parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetConversionTechnologyLock(i_locked)

    def set_ideas_component_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdeasComponentNameLock
                | o Sub SetIdeasComponentNameLock(        iLocked)
                | 
                | Locks or unlocks the IdeasComponentName parameter.
                | Role:Locks or unlocks the IdeasComponentName parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetIdeasComponentNameLock(i_locked)

    def set_ideas_component_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdeasComponentTypeLock
                | o Sub SetIdeasComponentTypeLock(        iLocked)
                | 
                | Locks or unlocks the IdeasComponentType parameter.
                | Role:Locks or unlocks the IdeasComponentType parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetIdeasComponentTypeLock(i_locked)

    def set_ideas_library_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdeasLibraryNameLock
                | o Sub SetIdeasLibraryNameLock(        iLocked)
                | 
                | Locks or unlocks the IdeasLibraryName parameter. Role:Locks
                | or unlocks the IdeasLibraryName parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetIdeasLibraryNameLock(i_locked)

    def set_ideas_part_number_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdeasPartNumberLock
                | o Sub SetIdeasPartNumberLock(        iLocked)
                | 
                | Locks or unlocks the IdeasPartNumber parameter. Role:Locks
                | or unlocks the IdeasPartNumber parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetIdeasPartNumberLock(i_locked)

    def set_ideas_project_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdeasProjectNameLock
                | o Sub SetIdeasProjectNameLock(        iLocked)
                | 
                | Locks or unlocks the IdeasProjectName parameter. Role:Locks
                | or unlocks the IdeasProjectName parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetIdeasProjectNameLock(i_locked)

    def set_ideas_rev_number_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdeasRevNumberLock
                | o Sub SetIdeasRevNumberLock(        iLocked)
                | 
                | Locks or unlocks the IdeasRevNumber parameter. Role:Locks or
                | unlocks the IdeasRevNumber parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetIdeasRevNumberLock(i_locked)

    def set_ideas_tess_param_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdeasTessParamLock
                | o Sub SetIdeasTessParamLock(        iLocked)
                | 
                | Locks or unlocks the IdeasTessParam parameter. Role:Locks or
                | unlocks the IdeasTessParam parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetIdeasTessParamLock(i_locked)

    def set_idi3d_annotation_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIdi3dAnnotationModeLock
                | o Sub SetIdi3dAnnotationModeLock(        iLocked)
                | 
                | Locks or unlocks the Idi3dAnnotationMode parameter.
                | Role:Locks or unlocks the Idi3dAnnotationMode parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetIdi3dAnnotationModeLock(i_locked)

    def set_link_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLinkModeLock
                | o Sub SetLinkModeLock(        iLocked)
                | 
                | Locks or unlocks the LinkMode parameter. Role:Locks or
                | unlocks the LinkMode parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetLinkModeLock(i_locked)

    def set_output_path_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOutputPathLock
                | o Sub SetOutputPathLock(        iLocked)
                | 
                | Locks or unlocks the OutputPath parameter. Role:Locks or
                | unlocks the OutputPath parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetOutputPathLock(i_locked)

    def set_parts_parameter_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPartsParameterModeLock
                | o Sub SetPartsParameterModeLock(        iLocked)
                | 
                | Locks or unlocks the PartsParameterMode parameter.
                | Role:Locks or unlocks the PartsParameterMode parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetPartsParameterModeLock(i_locked)

    def set_pro_e_instance_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProEInstanceModeLock
                | o Sub SetProEInstanceModeLock(        iLocked)
                | 
                | Locks or unlocks the ProEInstanceMode parameter. Role:Locks
                | or unlocks the ProEInstanceMode parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetProEInstanceModeLock(i_locked)

    def set_pro_e_instance_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProEInstanceNameLock
                | o Sub SetProEInstanceNameLock(        iLocked)
                | 
                | Locks or unlocks the ProEInstanceName parameter. Role:Locks
                | or unlocks the ProEInstanceName parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetProEInstanceNameLock(i_locked)

    def set_pro_e_quilts_read_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProEQuiltsReadLock
                | o Sub SetProEQuiltsReadLock(        iLocked)
                | 
                | Locks or unlocks the ProEQuiltsRead parameter. Role:Locks or
                | unlocks the ProEQuiltsRead parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetProEQuiltsReadLock(i_locked)

    def set_pro_e_simp_rep_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProESimpRepModeLock
                | o Sub SetProESimpRepModeLock(        iLocked)
                | 
                | Locks or unlocks the ProESimpRepMode parameter. Role:Locks
                | or unlocks the ProESimpRepMode parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetProESimpRepModeLock(i_locked)

    def set_pro_e_simp_rep_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProESimpRepNameLock
                | o Sub SetProESimpRepNameLock(        iLocked)
                | 
                | Locks or unlocks the ProESimpRepName parameter. Role:Locks
                | or unlocks the ProESimpRepName parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetProESimpRepNameLock(i_locked)

    def set_save_coorsys_in_cgr_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSaveCoorsysInCgrLock
                | o Sub SetSaveCoorsysInCgrLock(        iLocked)
                | 
                | Locks or unlocks the SaveCoorsysInCgr parameter. Role:Locks
                | or unlocks the SaveCoorsysInCgr parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetSaveCoorsysInCgrLock(i_locked)

    def set_translator_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTranslatorModeLock
                | o Sub SetTranslatorModeLock(        iLocked)
                | 
                | Locks or unlocks the Translator mode parameter. Role:Locks
                | or unlocks the Translator mode parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetTranslatorModeLock(i_locked)

    def set_ug_active_layers_only_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUGActiveLayersOnlyLock
                | o Sub SetUGActiveLayersOnlyLock(        iLocked)
                | 
                | Locks or unlocks the UGActiveLayersOnly parameter.
                | Role:Locks or unlocks the UGActiveLayersOnly parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetUGActiveLayersOnlyLock(i_locked)

    def set_ug_drawing_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUGDrawingNameLock
                | o Sub SetUGDrawingNameLock(        iLocked)
                | 
                | Locks or unlocks the UGDrawingName parameter. Role:Locks or
                | unlocks the UGDrawingName parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetUGDrawingNameLock(i_locked)

    def set_ug_layer_numbers_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUGLayerNumbersLock
                | o Sub SetUGLayerNumbersLock(        iLocked)
                | 
                | Locks or unlocks the UGLayerNumbers parameter. Role:Locks or
                | unlocks the UGLayerNumbers parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetUGLayerNumbersLock(i_locked)

    def set_ug_open_surfaces_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUGOpenSurfacesLock
                | o Sub SetUGOpenSurfacesLock(        iLocked)
                | 
                | Locks or unlocks the UGOpenSurfaces parameter. Role:Locks or
                | unlocks the UGOpenSurfaces parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetUGOpenSurfacesLock(i_locked)

    def set_ug_reference_set_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUgReferenceSetLock
                | o Sub SetUgReferenceSetLock(        iLocked)
                | 
                | Locks or unlocks the UgReferenceSet parameter. Role:Locks or
                | unlocks the UgReferenceSet parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetUgReferenceSetLock(i_locked)

    def set_visu_format_unit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVisuFormatUnitLock
                | o Sub SetVisuFormatUnitLock(        iLocked)
                | 
                | Locks or unlocks the VisuFormatUnit parameter. Role:Locks or
                | unlocks the VisuFormatUnit parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |   the locking operation to be performed
                |   Legal values:
                |   TRUE :   to lock the parameter.
                |   FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.multi_cad_setting_att.SetVisuFormatUnitLock(i_locked)

    def __repr__(self):
        return f'MultiCADSettingAtt()'
