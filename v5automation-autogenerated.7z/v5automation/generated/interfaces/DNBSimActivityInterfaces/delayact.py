#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DelayAct(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing a DelayAct.Role: This interface is used to
                | retrieve/assign the value of motion targets/attrs  for the move home
                | activity.The following code snippet can be used to obtain a
                | MoveHomeAct from a selected ActivityDim oSelectAct As Activity   Set
                | oSelectAct =
                | CATIA.ActiveDocument.Selection.FindObject("CATIAActivity")   Dim
                | objMoveAct As DelayAct   Set objMoveAct =
                | oSelectAct.GetTechnologicalObject("DelayAct")

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.delay_act = com_object     

    @property
    def delay(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Delay
                | o Property Delay(    ) As
                | 
                | This property returns and sets the delay value of the
                | activity. Example: Dim objDelayAct As DelayAct ....... Dim
                | delay as Double delay=objDelayAct.Delay delay = 30
                | objDelayAct.Delay=delay
                |

        :return:
        """
        return self.delay_act.Delay

    def __repr__(self):
        return f'DelayAct()'
