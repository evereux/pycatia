#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class GrabAct(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing a Grab activity.Role: This interface is used to
                | retrieve/assign the value of attributes  for the Grab activity.The
                | following code snippet can be used to obtain a GrabAct from a selected
                | ActivityDim oSelectAct As Activity   set oSelectAct =
                | CATIA.ActiveDocument.Selection.FindObject("CATIAActivity")   Dim
                | objGrabAct As GrabAct   set objGrabAct =
                | oSelectAct.GetTechnologicalObject("GrabAct")

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.grab_act = com_object     

    @property
    def grabbing_object(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GrabbingObject
                | o Property GrabbingObject(    ) As
                | 
                | Sets and retrieves the grabbing object Returns:
                | oGrabbingObject The grabbing object.
                |

        :return:
        """
        return self.grab_act.GrabbingObject

    def get_grabbed_objects(self, o_grabbed_objects):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGrabbedObjects
                | o Sub GetGrabbedObjects(        oGrabbedObjects)
                | 
                | Sets and retrieves the grabbed objects Returns:
                | oGrabbedObjects The grabbed object.
                |
                | Parameters:
                | iGrabbedObjects
                |      The specified grabbed objects

                |
        :param o_grabbed_objects:
        :return:
        """
        return self.grab_act.GetGrabbedObjects(o_grabbed_objects)

    def put_grabbed_objects(self, i_grabbed_objects):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutGrabbedObjects
                | o Sub PutGrabbedObjects(        iGrabbedObjects)
                | 
                |
                | Parameters:

                |
        :param i_grabbed_objects:
        :return:
        """
        return self.grab_act.PutGrabbedObjects(i_grabbed_objects)

    def __repr__(self):
        return f'GrabAct()'
