#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspAppFactory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the application factory.Role: To create, instanciate,
                | delete and query groups, logical lines, compartments and parts.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_app_factory = com_object     

    def create_group(self, i_current_product, i_group_type, i_group_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateGroup
                | o Func CreateGroup(        iCurrentProduct,
                |                            iGroupType,
                |                            iGroupID) As
                | 
                | Creates a group in the current Product.
                |
                | Parameters:
                | iCurrentProduct
                |    The current Product to query.
                |  
                |  iGroupType
                |    Group Startup type.
                |  
                |  iGroupID
                |    Group ID. A default ID will be generated if input is NULL.
                |  
                | 
                |  Returns:
                |     Created Group instance.

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As Product Dim
                | iStrVar2 As String Dim iStrVar3 As String Dim iObj4 As
                | PspGroup ... Set iObj4=objThisIntf.CreateGroup
                | (iobj1,iStrVar2,iStrVar3 )

        :param i_current_product:
        :param i_group_type:
        :param i_group_id:
        :return:
        """
        return self.psp_app_factory.CreateGroup(i_current_product, i_group_type, i_group_id)

    def delete_compartment(self, i_compartment):
        """
        .. note::
            CAA V5 Visual Basic help

                | DeleteCompartment
                | o Sub DeleteCompartment(        iCompartment)
                | 
                | Delete a compartment instance.
                |
                | Parameters:
                | iCompartment
                |    Compartment to be deleted

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As PspGroup ...
                | objThisIntf.DeleteCompartment iobj1

        :param i_compartment:
        :return:
        """
        return self.psp_app_factory.DeleteCompartment(i_compartment)

    def delete_group(self, i_group):
        """
        .. note::
            CAA V5 Visual Basic help

                | DeleteGroup
                | o Sub DeleteGroup(        iGroup)
                | 
                | Delete a group.
                |
                | Parameters:
                | iGroup
                |    Group to be deleted.

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As PspGroup ...
                | objThisIntf.DeleteGroup iobj1

        :param i_group:
        :return:
        """
        return self.psp_app_factory.DeleteGroup(i_group)

    def delete_logical_line(self, i_logical_line):
        """
        .. note::
            CAA V5 Visual Basic help

                | DeleteLogicalLine
                | o Sub DeleteLogicalLine(        iLogicalLine)
                | 
                | Delete a logical line instance.
                |
                | Parameters:
                | iLogicalLine
                |    Logical Line to be deleted

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As PspLogicalLine
                | ... objThisIntf.DeleteLogicalLine iobj1

        :param i_logical_line:
        :return:
        """
        return self.psp_app_factory.DeleteLogicalLine(i_logical_line)

    def delete_part(self, i_part):
        """
        .. note::
            CAA V5 Visual Basic help

                | DeletePart
                | o Sub DeletePart(        iPart)
                | 
                | Delete a part.
                |
                | Parameters:
                | iProduct
                |    Part to be deleted.

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As Product ...
                | objThisIntf.DeletePart iobj1

        :param i_part:
        :return:
        """
        return self.psp_app_factory.DeletePart(i_part)

    def get_compartment(self, i_current_product, i_compartment_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCompartment
                | o Func GetCompartment(        iCurrentProduct,
                |                               iCompartmentID) As
                | 
                | Instanciate a compartment from the catalog into the current
                | Product.
                |
                | Parameters:
                | iCurrentProduct
                |    The current Product into which a compartment will be instanciated.
                |  
                |  iCompartmentID
                |    Compartment ID to get from the compartment catalog.
                |  
                | 
                |  Returns:
                |     Compartment instance.

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As Product Dim
                | iStrVar2 As String Dim iObj3 As PspGroup ... Set
                | iObj3=objThisIntf.GetCompartment (iobj1,iStrVar2 )

        :param i_current_product:
        :param i_compartment_id:
        :return:
        """
        return self.psp_app_factory.GetCompartment(i_current_product, i_compartment_id)

    def get_logical_line(self, i_current_product, i_logical_line_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLogicalLine
                | o Func GetLogicalLine(        iCurrentProduct,
                |                               iLogicalLineID) As
                | 
                | Returns a PspLogicalLine Logical line Instance.
                |
                | Parameters:
                | iCurrentProduct
                |    The current Product into which a logical line will be instanciated.
                |  
                |  iLogicalLineID
                |    Logical line ID to get from the logical line catalog.
                |  
                | 
                |  Returns:
                |     Logical line instance.

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As Product Dim
                | iStrVar2 As String ... objThisIntf.GetLogicalLine
                | (iobj1,iStrVar2 )

        :param i_current_product:
        :param i_logical_line_id:
        :return:
        """
        return self.psp_app_factory.GetLogicalLine(i_current_product, i_logical_line_id)

    def list_compartments(self, i_current_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListCompartments
                | o Func ListCompartments(        iCurrentProduct) As
                | 
                | Retrieves a list of Compartments in the current Product.
                |
                | Parameters:
                | iCurrentProduct
                |    The current Product to query.
                |  
                | 
                |  Returns:
                |     A list of Compartmemts
                |    ( A list of CATIAPspGroup)

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As Product Dim
                | objArg2 As PspListOfObjects ... Set ObjArg2 =
                | objThisIntf.ListCompartments (iobj1 )

        :param i_current_product:
        :return:
        """
        return self.psp_app_factory.ListCompartments(i_current_product)

    def list_groups(self, i_current_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListGroups
                | o Func ListGroups(        iCurrentProduct) As
                | 
                | Retrieve a list of Groups in the current Product.
                |
                | Parameters:
                | iCurrentProduct
                |    The current Product to query.. 
                |  
                | 
                |  Returns:
                |       A list of Groups
                |    ( A list of CATIAPspGroup)

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As Product Dim
                | objArg2 As ListOfObjects ... Set ObjArg2 =
                | objThisIntf.ListGroups (iobj1)

        :param i_current_product:
        :return:
        """
        return self.psp_app_factory.ListGroups(i_current_product)

    def list_logical_lines(self, i_current_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListLogicalLines
                | o Func ListLogicalLines(        iCurrentProduct) As
                | 
                | Returns a list of logical lines in the current Product.
                |
                | Parameters:
                | iCurrentProduct
                |    The current Product to query.. 
                |  
                | 
                |  Returns:
                |     A list of logical Lines
                |    (A list of PspLogicalLine)

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As Product Dim
                | objArg2 As PspListOfObjects ... Set ObjArg2 =
                | objThisIntf.ListLogicalLines (iobj1 )

        :param i_current_product:
        :return:
        """
        return self.psp_app_factory.ListLogicalLines(i_current_product)

    def list_physicals(self, i_current_product, i_domain_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListPhysicals
                | o Func ListPhysicals(        iCurrentProduct,
                |                              iDomainID) As
                | 
                | Returns a list of Physical objects in the node.
                |
                | Parameters:
                | iCurrentProduct
                |    The current Product to query.
                |  
                |  iDomainID
                |    Physical objects that have this domain ID. To get list of all
                |    in all domains set iDomainID= catPspIDLNone.
                |  
                | 
                |  Returns:
                |     A list of physical objects
                |    (A list of PspPhysical objects)

                |                | Examples:
                | Dim objThisIntf As PspAppFactory Dim iobj1 As Product Dim
                | iobjArg2 As CatPspIDLDomainID Dim objArg3 As
                | PspListOfObjects ... Set ObjArg3 = objThisIntf.ListPhysicals
                | (iobj1, iobjArg2 )

        :param i_current_product:
        :param i_domain_id:
        :return:
        """
        return self.psp_app_factory.ListPhysicals(i_current_product, i_domain_id)

    def __repr__(self):
        return f'PspAppFactory()'
