#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspAttribute(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents Attribute Interface to query Plant Ship objects'
                | attributes.Role: To query and reset attributes.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_attribute = com_object     

    def get_multi_string_attribute_values(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMultiStringAttributeValues
                | o Func GetMultiStringAttributeValues(        iAttributeName) As
                | 
                | Retrieves String values for the input attribute the type
                | catPspIDLMultiString.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                | 
                |  Returns:
                |     List of string values

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | objArg2 As PspListOfBSTRs ... Set objArg2 =
                | objThisIntf.GetMultiStringAttributeValues (strVar1)

        :param i_attribute_name:
        :return:
        """
        return self.psp_attribute.GetMultiStringAttributeValues(i_attribute_name)

    def get_parameter(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetParameter
                | o Func GetParameter(        iAttributeName) As
                | 
                | Retrieve parameter for the input attribute name.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                | 
                |  Returns:
                |     Parameter of the attribute

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | ObjVar2 As Parameter ... Set objArg2 =
                | objThisIntf.GetParameter (strVar1 )

        :param i_attribute_name:
        :return:
        """
        return self.psp_attribute.GetParameter(i_attribute_name)

    def get_type(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetType
                | o Func GetType(        iAttributeName) As
                | 
                | Retrieves type of the input attribute. If the type of the
                | attribute is catPspIDLMultiString use
                | GetMultiStringAttributeValues. for others, use
                | GetParameter().
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                | 
                |  Returns:
                |   Type of the attribute.

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | eType As CatPspIDLAttrDataType ... eType =
                | objThisIntf.GetType (strVar1)

        :param i_attribute_name:
        :return:
        """
        return self.psp_attribute.GetType(i_attribute_name)

    def is_derived(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsDerived
                | o Func IsDerived(        iAttributeName) As
                | 
                | Retrieve Derived status for the input attribute.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                | 
                |  Returns:
                |     TRUE if the attribute is derived

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | bIsDerived As boolean ... bIsDerived = objThisIntf.IsDerived
                | (strVar1)

        :param i_attribute_name:
        :return:
        """
        return self.psp_attribute.IsDerived(i_attribute_name)

    def is_discrete(self, i_attribute_name, ob_status):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsDiscrete
                | o Func IsDiscrete(        iAttributeName,
                |                           obStatus) As
                | 
                | Query whether the input attribute is discrete or not.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                |  obStatus
                |   TRUE if attribute is discrete else FALSE
                |  
                | 
                |  Returns:
                |    Discrete Type value 1-Standard 2-Encoded discrete

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | boolVar2 As Boolean Dim shortVar3 As Short ... shortVar3 =
                | objThisIntf.IsDiscrete (strVar1,boolVar2)

        :param i_attribute_name:
        :param ob_status:
        :return:
        """
        return self.psp_attribute.IsDiscrete(i_attribute_name, ob_status)

    def list_attributes(self, i_domain_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListAttributes
                | o Func ListAttributes(        iDomainID) As
                | 
                | Retrieves a list of Attributes of an object in the the input
                | domain ID.
                |
                | Parameters:
                | iDomainID
                |   Domain ID. If set to catPspIDLNone, then it will return attributes in 
                |   all the domains.
                |  
                | 
                |  Returns:
                |    List of attributes
                |    ( A list of CATIAPspGroupables)

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim objArg1 As
                | CatPspIDLDomainID Dim objArg2 As PspListOfBSTRs ... Set
                | objArg2 = objThisIntf.ListAttributes (objArg1)

        :param i_domain_id:
        :return:
        """
        return self.psp_attribute.ListAttributes(i_domain_id)

    def list_double_discrete_values(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListDoubleDiscreteValues
                | o Func ListDoubleDiscreteValues(        iAttributeName) As
                | 
                | Retrieves double discrete values for the input attribute.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                | 
                |  Returns:
                |     Discrete list of double values

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | objArg2 As PspListOfDoubles ... Set objArg2 =
                | objThisIntf.ListDoubleDiscreteValues (strVar1 )

        :param i_attribute_name:
        :return:
        """
        return self.psp_attribute.ListDoubleDiscreteValues(i_attribute_name)

    def list_encoded_decoded_discrete_values(self, i_attribute_name, o_l_discrete_encoded_values, o_l_discrete_decoded_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListEncodedDecodedDiscreteValues
                | o Sub ListEncodedDecodedDiscreteValues(        iAttributeName,
                |                                                oLDiscreteEncodedValues,
                |                                                oLDiscreteDecodedValue)
                | 
                | Retrieves Encoded-decoded discrete values for the input
                | attribute.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                |  oLDiscreteEncodedValues
                |    Discrete list of encoded string values
                |  
                |  oLDiscreteDecodedValue
                |    Discrete list of decoded string values

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | objArg2 As PspListOfBSTRs Dim objArg3 As PspListOfBSTRs ...
                | objThisIntf.ListEncodedDecodedDiscreteValues strVar1,
                | objArg2, objArg3

        :param i_attribute_name:
        :param o_l_discrete_encoded_values:
        :param o_l_discrete_decoded_value:
        :return:
        """
        return self.psp_attribute.ListEncodedDecodedDiscreteValues(i_attribute_name, o_l_discrete_encoded_values, o_l_discrete_decoded_value)

    def list_integer_discrete_values(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListIntegerDiscreteValues
                | o Func ListIntegerDiscreteValues(        iAttributeName) As
                | 
                | Retrieve integer (long) discrete values for the input
                | attribute.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                | 
                |  Returns:
                |     Discrete list of integer values

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | objArg2 As PspListOfLongs ... Set objArg2 =
                | objThisIntf.ListIntegerDiscreteValues (strVar1)

        :param i_attribute_name:
        :return:
        """
        return self.psp_attribute.ListIntegerDiscreteValues(i_attribute_name)

    def list_string_discrete_values(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListStringDiscreteValues
                | o Func ListStringDiscreteValues(        iAttributeName) As
                | 
                | RetrievesString discrete values for the input attribute.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name
                |  
                | 
                |  Returns:
                |     Discrete list of string values

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR Dim
                | objArg2 As PspListOfBSTRs ... Set objArg2 =
                | objThisIntf.ListStringDiscreteValues (strVar1)

        :param i_attribute_name:
        :return:
        """
        return self.psp_attribute.ListStringDiscreteValues(i_attribute_name)

    def reset_derived_attr(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | ResetDerivedAttr
                | o Sub ResetDerivedAttr(        iAttributeName)
                | 
                | Reset derived status of the attribute to not-derived.
                |
                | Parameters:
                | iAttributeName
                |   Attribute Name

                |                | Examples:
                | Dim objThisIntf As PspAttribute Dim strVar1 As CATBSTR ...
                | objThisIntf.ResetDerivedAttr strVar1

        :param i_attribute_name:
        :return:
        """
        return self.psp_attribute.ResetDerivedAttr(i_attribute_name)

    def __repr__(self):
        return f'PspAttribute()'
