#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspListOfDoubles(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a collection of double values.Role: Collection of double.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_list_of_doubles = com_object     

    @property
    def count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Count
                | o Property Count(    ) As   (Read Only)
                | 
                | Returns the number of doubles in the list. Example: This
                | example retrieves in NumberOfdoubles the number of doubles
                | currently gathered in MyList. NumberOfdoubles = MyList.Count
                |

        :return:
        """
        return self.psp_list_of_doubles.Count

    def append(self, i_double):
        """
        .. note::
            CAA V5 Visual Basic help

                | Append
                | o Sub Append(        iDouble)
                | 
                | Adds a double to the end of the list.
                |
                | Parameters:
                | iDouble
                |    The double to be added to the list.

                |                | Examples:
                | The following example appends an object to the list. Dim
                | MyDouble As Double MyDouble = 0.6789 Dim MyList As
                | PspListOfDoubles MyList.Append(MyDouble)

        :param i_double:
        :return:
        """
        return self.psp_list_of_doubles.Append(i_double)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns a double from its index in the list.
                |
                | Parameters:
                | iIndex
                |    The index of the first double in the collection is 1, and
                |    the index of the last double is Count.
                |  
                | 
                |  Returns:
                |   the retrieved double.

                |                | Examples:
                | The following example returns in the third double in the
                | list. Dim MyDouble As double Dim MyList As PspListOfDoubles
                | MyDouble = PspListOfDoubles.Item(3)

        :param i_index:
        :return:
        """
        return self.psp_list_of_doubles.Item(i_index)

    def remove_by_index(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveByIndex
                | o Sub RemoveByIndex(        iIndex)
                | 
                | Removes a double from the list by specifying its position in
                | the list.
                |
                | Parameters:
                | iIndex
                |    The position of the double to be removed in the list.

                |                | Examples:
                | The following example removes the second entry in the list.
                | Please note that the list index starts with 1. Dim MyList As
                | PspListOfDoubles MyList.RemoveByIndex(2)

        :param i_index:
        :return:
        """
        return self.psp_list_of_doubles.RemoveByIndex(i_index)

    def __repr__(self):
        return f'PspListOfDoubles()'
