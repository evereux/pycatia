#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspFunctional(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents Plant Ship functional object.Role: To access Plant Ship
                | Functional object information.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_functional = com_object     

    @property
    def catalog_part_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CatalogPartName
                | o Property CatalogPartName(    ) As   (Read Only)
                | 
                | Returns catalog part name of physical object that realizes
                | this function. Example: Dim objThisIntf As PspFunctional Dim
                | strVar1 As CATBSTR ... Set strVar1 =
                | objThisIntf.CatalogPartName
                |

        :return:
        """
        return self.psp_functional.CatalogPartName

    @property
    def function_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FunctionStatus
                | o Property FunctionStatus(    ) As   (Read Only)
                | 
                | Returns function object status. Example: Dim objThisIntf As
                | PspPhysical Dim objArg1 As CatPspIDLFunctionStatus ...
                | objArg1 = objThisIntf.FunctionStatus
                |

        :return:
        """
        return self.psp_functional.FunctionStatus

    @property
    def part_catalog_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartCatalogName
                | o Property PartCatalogName(    ) As   (Read Only)
                | 
                | Returns Part catalog name of physical object that realizes
                | this function. Example: Dim objThisIntf As PspFunctional Dim
                | strVar1 As CATBSTR ... strVar1 = objThisIntf.PartCatalogName
                |

        :return:
        """
        return self.psp_functional.PartCatalogName

    @property
    def part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartNumber
                | o Property PartNumber(    ) As   (Read Only)
                | 
                | Returns part number of physical object that realizes this
                | function. Example: Dim objThisIntf As PspFunctional Dim
                | strVar1 As CATBSTR ... strVar1 = objThisIntf.PartNumber
                |

        :return:
        """
        return self.psp_functional.PartNumber

    @property
    def part_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartType
                | o Property PartType(    ) As   (Read Only)
                | 
                | Returns the part type of physical object that realizes this
                | function. Example: Dim objThisIntf As PspFunctional Dim
                | strVar1 As CATBSTR ... strVar1 = objThisIntf.PartType
                |

        :return:
        """
        return self.psp_functional.PartType

    @property
    def physicals(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Physicals
                | o Property Physicals(    ) As   (Read Only)
                | 
                | Returns a list of all associated physical objects. Example:
                | Dim objThisIntf As PspFunctional Dim objArg1 As
                | PspListOfObjects ... Set objArg1 = objThisIntf.Physicals
                |

        :return:
        """
        return self.psp_functional.Physicals

    @property
    def standard(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Standard
                | o Property Standard(    ) As   (Read Only)
                | 
                | Return Standard. Example: Dim objThisIntf As PspFunctional
                | Dim strVar1 As CATBSTR ... strVar1 = objThisIntf.Standard
                |

        :return:
        """
        return self.psp_functional.Standard

    def get_compatible_part_types(self, iu_standard):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCompatiblePartTypes
                | o Func GetCompatiblePartTypes(        iuStandard) As
                | 
                | Retrieves a list of all physical part types that are
                | compatible with this function.
                |
                | Parameters:
                | iuStandard
                |   Standard name
                |  
                | 
                |  Returns:
                |    List of Compatible Part Types.

                |                | Examples:
                | Dim objThisIntf As PspFunctional Dim strVar1 As CATBSTR Dim
                | objArg2 As PspListOfBSTRs ... Set objArg1 =
                | objThisIntf.GetCompatiblePartTypes (strVar1)

        :param iu_standard:
        :return:
        """
        return self.psp_functional.GetCompatiblePartTypes(iu_standard)

    def is_ok_to_integrate(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsOKToIntegrate
                | o Func IsOKToIntegrate(    ) As
                | 
                | Check it is OK to integrate (realize) this function with a
                | physical part. Returns: TRUE if ok to be integrated Example:
                | Dim objThisIntf As PspFunctional Dim objArg1 As boolean ...
                | objArg1 = objThisIntf.IsOKToIntegrate
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_functional.IsOKToIntegrate()

    def is_realized(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsRealized
                | o Func IsRealized(    ) As
                | 
                | Checks if the Function object is realized or not. Returns:
                | TRUE if the object is Realized Example: Dim objThisIntf As
                | PspFunctional Dim objArg1 As boolean ... objArg1 =
                | objThisIntf.IsRealized
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_functional.IsRealized()

    def is_spec_driven(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsSpecDriven
                | o Func IsSpecDriven(    ) As
                | 
                | Checks if the functional object is specification driven or
                | not. Returns: TRUE if this object is specification driven.
                | Example: Dim objThisIntf As PspFunctional Dim objArg1 As
                | boolean ... objArg1 = objThisIntf.IsSpecDriven
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_functional.IsSpecDriven()

    def list_compatible_part_numbers(self, iu_part_type, iu_standard, iu_catalog_name, o_l_part_types, o_l_catalog_part_names):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListCompatiblePartNumbers
                | o Sub ListCompatiblePartNumbers(        iuPartType,
                |                                         iuStandard,
                |                                         iuCatalogName,
                |                                         oLPartTypes,
                |                                         oLCatalogPartNames)
                | 
                | Retrieves a list of compatible Part numbers and part types.
                |
                | Parameters:
                | iuPartType
                |   part type
                |  
                |  iuStandard
                |   Standard name
                |  
                |  iuCatalogName
                |   catalog name  
                |  
                |  oLPartTypes
                |   a list of part types
                |  
                |  oLCatalogPartNames
                |   List of catalog part names

                |                | Examples:
                | Dim objThisIntf As PspFunctional Dim strVar1 As CATBSTR Dim
                | strVar2 As CATBSTR Dim strVar3 As CATBSTR Dim objArg4 As
                | PspListOfBSTRs Dim objArg5 As PspListOfBSTRs .. ..
                | objThisIntf.ListCompatiblePartNumbers
                | strVar1,strVar2,strVar3,objArg4,objArg5

        :param iu_part_type:
        :param iu_standard:
        :param iu_catalog_name:
        :param o_l_part_types:
        :param o_l_catalog_part_names:
        :return:
        """
        return self.psp_functional.ListCompatiblePartNumbers(iu_part_type, iu_standard, iu_catalog_name, o_l_part_types, o_l_catalog_part_names)

    def __repr__(self):
        return f'PspFunctional()'
