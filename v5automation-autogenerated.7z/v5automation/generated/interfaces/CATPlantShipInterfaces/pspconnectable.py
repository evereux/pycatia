#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspConnectable(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents an Interface to manage object behaviors in making
                | connections.Role: To specify object behaviors such as adding a
                | connector and removing a connector.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_connectable = com_object     

    @property
    def connectors(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Connectors
                | o Property Connectors(    ) As   (Read Only)
                | 
                | Returns a list of connectors of the object. Example: Dim
                | objThisIntf As PspConnectable Dim objArg1 As
                | CatPspIDLDomainID Dim objArg2 As PspListOfBSTRs ... Set
                | objArg2 = objThisIntf.Connectors
                |

        :return:
        """
        return self.psp_connectable.Connectors

    @property
    def valid_connector_types(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ValidConnectorTypes
                | o Property ValidConnectorTypes(    ) As   (Read Only)
                | 
                | Returns a list of Valid connector types on this object.
                | Example: Dim objThisIntf As PspConnectable Dim objArg1 As
                | PspListOfBSTRs ... Set objArg1 =
                | objThisIntf.ValidConnectorTypes
                |

        :return:
        """
        return self.psp_connectable.ValidConnectorTypes

    def get_connector_by_name(self, iu_connector_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetConnectorByName
                | o Func GetConnectorByName(        iuConnectorName) As
                | 
                | Retrieves a connector with the given name.
                |
                | Parameters:
                | iConnectorName
                |    Connector name to look for.
                |  
                | 
                |  Returns:
                |      Connector with given name.

                |                | Examples:
                | Dim objThisIntf As PspConnectable Dim strVar1 As
                | PspListOfBSTRs Dim objArg2 As PspConnector ... Set objArg2 =
                | objThisIntf.GetConnectorByName (strVar1)

        :param iu_connector_name:
        :return:
        """
        return self.psp_connectable.GetConnectorByName(iu_connector_name)

    def list_connectables(self, iu_class_filter, o_l_cntbles, o_l_cntrs_on_this_obj, o_l_cntrs_on_connected):
        """
        .. note::
            CAA V5 Visual Basic help

                | ListConnectables
                | o Sub ListConnectables(        iuClassFilter,
                |                                oLCntbles,
                |                                oLCntrsOnThisObj,
                |                                oLCntrsOnConnected)
                | 
                | Retrieve a list of connectors of the object.
                |
                | Parameters:
                | iuClassFilter
                |   Class filter list. If iuClassFilter is an empty list then it will get
                |   connectors for all the application connector types.
                |  
                |  oLCntbles
                |   a list of CATIAPspConnectable  objects that connect this object
                |  
                |  oLCntrsOnThisObj
                |   a list of connectors on "this" object in the connections
                |    ( A list of CATIAPspConnector)
                |  
                |  oLCntrsOnConnected
                |   a list of connectors on the other objects that the member of the 
                |   former list is connected to (positions in oLCntrsOnThisObj and 
                |   oLCntrsOnConnected corresponds to each other)
                |    ( A list of CATIAPspConnector)

                |                | Examples:
                | Dim objThisIntf As PspConnectable Dim objArg1 As
                | PspListOfBSTRs Dim objArg2 As PspListofObjects Dim objArg3
                | As PspListofObjects Dim objArg4 As PspListofObjects ...
                | objThisIntf.ListConnectables objArg1,objArg2,objArg3,objArg4

        :param iu_class_filter:
        :param o_l_cntbles:
        :param o_l_cntrs_on_this_obj:
        :param o_l_cntrs_on_connected:
        :return:
        """
        return self.psp_connectable.ListConnectables(iu_class_filter, o_l_cntbles, o_l_cntrs_on_this_obj, o_l_cntrs_on_connected)

    def __repr__(self):
        return f'PspConnectable()'
