#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspLightConnector(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the light connector.Role: To access light connector data.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_light_connector = com_object     

    def get_alignment_vector(self, i_rel_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAlignmentVector
                | o Func GetAlignmentVector(        iRelAxis) As
                | 
                | Returns the position of the connector.
                |
                | Parameters:
                | iRelAxis
                |    the relative axis object (Nothing means relative to parent)
                |  
                |  oAlignmentDirection
                |    Three double values stand for X,Y,Z components of the alignment vector

                |                | Examples:
                | Dim objThisIntf As PspLightConnector Dim objArg1 As Product
                | Dim objArg2 As PspListOfDoubles ... Set objArg2 =
                | objThisIntf.GetAlignmentVector (objArg1)

        :param i_rel_axis:
        :return:
        """
        return self.psp_light_connector.GetAlignmentVector(i_rel_axis)

    def get_orientation_vector(self, i_rel_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrientationVector
                | o Func GetOrientationVector(        iRelAxis) As
                | 
                | Returns the Orientation Direction of the connector.
                |
                | Parameters:
                | iRelAxis
                |    the relative axis object (Nothing means relative to parent)
                |  
                |  oAlignmentDirection
                |    Three double values stand for X,Y,Z components of the alignment vector

                |                | Examples:
                | Dim objThisIntf As PspLightConnector Dim objArg1 As Product
                | Dim objArg2 As PspListOfDoubles ... Set objArg2 =
                | objThisIntf.GetOrientationVector (objArg1)

        :param i_rel_axis:
        :return:
        """
        return self.psp_light_connector.GetOrientationVector(i_rel_axis)

    def get_origin(self, i_rel_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrigin
                | o Func GetOrigin(        iRelAxis) As
                | 
                | Returns the position of the connector.
                |
                | Parameters:
                | iRelAxis
                |    the relative axis object (Nothing means relative to parent)
                |  
                |  oOrigin
                |    Origin point position-three double values stand for x,y,z

                |                | Examples:
                | Dim objThisIntf As PspLightConnector Dim objArg1 As Product
                | Dim objArg2 As PspListOfDoubles ... Set objArg2 =
                | objThisIntf.GetOrigin (objArg1)

        :param i_rel_axis:
        :return:
        """
        return self.psp_light_connector.GetOrigin(i_rel_axis)

    def set_alignment_vector(self, i_rel_axis, i_alignment_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAlignmentVector
                | o Sub SetAlignmentVector(        iRelAxis,
                |                                  iAlignmentDirection)
                | 
                | Sets the alignment direction of the connector.
                |
                | Parameters:
                | iRelAxis
                |    the relative axis object (Nothing means relative to parent)
                | 
                |  
                |  iAlignmentDirection
                |    Three double values stand for X,Y,Z component of the Alignment vector

                |                | Examples:
                | Dim objThisIntf As PspLightConnector Dim objArg1 As Product
                | Dim dbVar2(2) As CATSafeArrayVariant ...
                | objThisIntf.SetAlignmentVector objArg1, dbVar2

        :param i_rel_axis:
        :param i_alignment_direction:
        :return:
        """
        return self.psp_light_connector.SetAlignmentVector(i_rel_axis, i_alignment_direction)

    def set_orientation_vector(self, i_rel_axis, i_orientation_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOrientationVector
                | o Sub SetOrientationVector(        iRelAxis,
                |                                    iOrientationDirection)
                | 
                | Sets the Orientation Direction of the connector.
                |
                | Parameters:
                | iRelAxis
                |    the relative axis object (Nothing means relative to parent)
                | 
                |  
                |  iAlignmentDirection
                |    Three double values stand for X,Y,Z component of the Alignment vector

                |                | Examples:
                | Dim objThisIntf As PspLightConnector Dim objArg1 As Product
                | Dim dbVar2(2) As CATSafeArrayVariant ...
                | objThisIntf.SetAlignmentVector objArg1, dbVar2

        :param i_rel_axis:
        :param i_orientation_direction:
        :return:
        """
        return self.psp_light_connector.SetOrientationVector(i_rel_axis, i_orientation_direction)

    def set_origin(self, i_rel_axis, i_db_3__positio):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOrigin
                | o Sub SetOrigin(        iRelAxis,
                |                         iDb3Position)
                | 
                | Sets the position of the connector.
                |
                | Parameters:
                | iRelAxis
                |    the relative axis object (Nothing means relative to parent)
                | 
                |  
                |  iDb3Position
                |    absolute X-Y-Z coordinates of the current position of 
                |    the connector to be set

                |                | Examples:
                | Dim objThisIntf As PspLightConnector Dim objArg1 As Product
                | Dim dbVar2(3) As CATSafeArrayVariant ...
                | objThisIntf.SetOrigin objArg1, dbVar2

        :param i_rel_axis:
        :param i_db_3__positio:
        :return:
        """
        return self.psp_light_connector.SetOrigin(i_rel_axis, i_db_3__positio)

    def __repr__(self):
        return f'PspLightConnector()'
