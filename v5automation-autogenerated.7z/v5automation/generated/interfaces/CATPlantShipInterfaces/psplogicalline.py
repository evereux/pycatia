#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspLogicalLine(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the logical line.Role: To query the logical line object's
                | from/to members.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_logical_line = com_object     

    def get_from_to(self, o_list_from_major, o_list_from_minor, o_list_to_major, o_list_to_minor):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFromTo
                | o Sub GetFromTo(        oListFromMajor,
                |                         oListFromMinor,
                |                         oListToMajor,
                |                         oListToMinor)
                | 
                | Retrieves the lists of major and minor from/to members from
                | this line. The members retrieved are all objects.
                |
                | Parameters:
                | oListFromMajor
                |    The list of major from members
                |  
                |  oListFromMinor
                |    The list of minor from members
                |  
                |  oListToMajor
                |    The list of major to members
                |  
                |  oListToMinor
                |    The list of minor to members

                |                | Examples:
                | Dim objThisIntf As PspLogicalLine Dim objArg1 As
                | PspListOfObjects Dim objArg2 As PspListOfObjects Dim objArg3
                | As PspListOfObjects Dim objArg4 As PspListOfObjects ...
                | objThisIntf.GetFromTo objArg1, objArg2, objArg3, objArg4

        :param o_list_from_major:
        :param o_list_from_minor:
        :param o_list_to_major:
        :param o_list_to_minor:
        :return:
        """
        return self.psp_logical_line.GetFromTo(o_list_from_major, o_list_from_minor, o_list_to_major, o_list_to_minor)

    def get_from_to_info_array_max_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFromToInfoArrayMaxSize
                | o Func GetFromToInfoArrayMaxSize(    ) As
                | 
                | Returns the maximum possible size of the from-to
                | information. Returns: The maximum possible size of the array
                | to hold the information returned by Example: Dim objThisIntf
                | As PspLogicalLine Dim intValueMaxSize As Integer ...
                | intValueMaxSize = objThisIntf.GetFromToInfoArrayMaxSize
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_logical_line.GetFromToInfoArrayMaxSize()

    def get_from_to_information(self, o_from_to_label, o_ft_major, o_ft_minor, o_size_of_output):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFromToInformation
                | o Sub GetFromToInformation(        oFromToLabel,
                |                                    oFTMajor,
                |                                    oFTMinor,
                |                                    oSizeOfOutput)
                | 
                | Retrieves the from/to information of a logical line.
                |
                | Parameters:
                | oFromToLabel
                |    The array of labels ("From" or "To")
                |  
                |  oFTMajor
                |    The array of from/to major IDs
                |  
                |  oFTMinor
                |    The array of from/to minor IDs
                |  
                |    The
                |  size of the output arrays

                |                | Examples:
                | Dim objThisIntf As PspLogicalLine Dim strFromToLabel(20) As
                | String Dim strFromToMajor(20) As String Dim
                | strFromToMinor(20) As String Dim intValueMaxSize As Integer
                | intValueMaxSize = objThisIntf.GetFromToInfoArrayMaxSize ...
                | '---- make sure the array size if big enough If
                | (intValueMaxSize ≤ 20) Then objThisIntf.GetFromToInformation
                | _ strFromToLabel, strFromToMajor, strFromToMinor,
                | intValueMaxSize End If The following table can then be
                | filled with the output arrays. From/To | F/T Major | F/T
                | Minor strFromToLabel(i) | strFromToMajor(i) |
                | strFromToMinor(i)

        :param o_from_to_label:
        :param o_ft_major:
        :param o_ft_minor:
        :param o_size_of_output:
        :return:
        """
        return self.psp_logical_line.GetFromToInformation(o_from_to_label, o_ft_major, o_ft_minor, o_size_of_output)

    def __repr__(self):
        return f'PspLogicalLine()'
