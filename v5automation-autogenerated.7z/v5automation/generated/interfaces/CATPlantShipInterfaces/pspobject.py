#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspObject(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents PspObject.Role: To access Plant Ship object information.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_object = com_object     

    @property
    def application_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplicationID
                | o Property ApplicationID(    ) As   (Read Only)
                | 
                | Returns the ApplicationID of the object. Example: Dim
                | objThisIntf As PspObject Dim eApplID As
                | CatPSPIDLApplicationID ... eApplID =
                | objThisIntf.ApplicationID
                |

        :return:
        """
        return self.psp_object.ApplicationID

    @property
    def domain_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DomainID
                | o Property DomainID(    ) As   (Read Only)
                | 
                | Returns the DomainID of the object. Example: Dim objThisIntf
                | As PspObject Dim eDomanID As CatPspIDLDomainID ... eDomanID
                | = objThisIntf.DomainID
                |

        :return:
        """
        return self.psp_object.DomainID

    @property
    def startup_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StartupType
                | o Property StartupType(    ) As   (Read Only)
                | 
                | Returns the Startup type of the object. Example: Dim
                | objThisIntf As PspObject Dim strStartUp As String ...
                | strStartUp = objThisIntf.StartupType
                |

        :return:
        """
        return self.psp_object.StartupType

    def __repr__(self):
        return f'PspObject()'
