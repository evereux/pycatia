#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspResource(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the PspResource.Role: It is used to get application
                | resources.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_resource = com_object     

    def get_resource_path(self, i_resource_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetResourcePath
                | o Func GetResourcePath(        iResourceName) As
                | 
                | Returns the path value defined for a resource.
                |
                | Parameters:
                | iResourceName
                |    Resource Name
                |  
                | 
                |  Returns:
                |      Resource Path

                |                | Examples:
                | Dim objThisIntf As PspResource Dim strResourcePath As String
                | Dim iResourceName As String ... strResourcePath =
                | objThisIntf.GetResourcePath (iResourceName)

        :param i_resource_name:
        :return:
        """
        return self.psp_resource.GetResourcePath(i_resource_name)

    def get_resource_value(self, i_resource_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetResourceValue
                | o Func GetResourceValue(        iResourceName) As
                | 
                | Returns the value defined for a resource.
                |
                | Parameters:
                | iResourceName
                |    Resource Name
                |  
                | 
                |  Returns:
                |      Resource Value

                |                | Examples:
                | Dim objThisIntf As PspResource Dim strResourceVal As String
                | ... strResourceVal = objThisIntf.GetResourceValue
                | (iResourceName)

        :param i_resource_name:
        :return:
        """
        return self.psp_resource.GetResourceValue(i_resource_name)

    def __repr__(self):
        return f'PspResource()'
