#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspID(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the interface to generate and set IDs for the Distributive
                | System Objects.Role: This is the interface for Plant Ship object ID
                | generation.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_id = com_object     

    def gen_and_put_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GenAndPutID
                | o Func GenAndPutID(    ) As
                | 
                | Returns the Generated ID with the sequence number and is
                | stored on the object. Returns: ID generated Example: Dim
                | objThisIntf As PspID Dim iStrVar1 As String ... iStrVar1
                | =objThisIntf.GenAndPutID
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_id.GenAndPutID()

    def gen_and_put_id_no_gen_seq_num(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GenAndPutIDNoGenSeqNum
                | o Func GenAndPutIDNoGenSeqNum(    ) As
                | 
                | Generates ID without the sequence number and is stored on
                | the object. Returns: ID generated Example: Dim objThisIntf
                | As PspID Dim iStrVar1 As String ... iStrVar1
                | =objThisIntf.GenAndPutIDNoGenSeqNum
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_id.GenAndPutIDNoGenSeqNum()

    def gen_id_no_gen_seq_num(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GenIDNoGenSeqNum
                | o Func GenIDNoGenSeqNum(    ) As
                | 
                | Generates ID without the sequence number( if not set
                | previously) and is not stored on the object.
                |
                | Parameters:
                | oGeneratedID
                |    ID generated

                |                | Examples:
                | Dim objThisIntf As PspID Dim iStrVar1 As String ... iStrVar1
                | =objThisIntf.GenIDNoGenSeqNum

        :return:
        """
        return self.psp_id.GenIDNoGenSeqNum()

    def get_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetID
                | o Func GetID(    ) As
                | 
                | Gets ID for the object. Returns: ID of the object. Example:
                | Dim objThisIntf As PspID Dim iStrVar1 As String ... iStrVar1
                | =objThisIntf.GetID
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_id.GetID()

    def get_local_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLocalID
                | o Func GetLocalID(    ) As
                | 
                | Retrieves local ID of the object. Returns: Local ID
                | generated Example: Dim objThisIntf As PspID Dim iStrVar1 As
                | String ... iStrVar1 =objThisIntf.GetLocalID
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_id.GetLocalID()

    def is_id_generated(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsIDGenerated
                | o Func IsIDGenerated(    ) As
                | 
                | Checks if the ID on the object is generated( based on the ID
                | Schema).
                |
                | Parameters:
                | oBIsGenerated
                |    TRUE if ID is generated from the ID schema

                |                | Examples:
                | Dim objThisIntf As PspID Dim bVar1 As boolean ... bVar1
                | =objThisIntf.IsIDGenerated

        :return:
        """
        return self.psp_id.IsIDGenerated()

    def set_id(self, i_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetID
                | o Sub SetID(        iID)
                | 
                | Sets ID for the object.
                |
                | Parameters:
                | oID
                |    ID to be set.

                |                | Examples:
                | Dim objThisIntf As PspID Dim iStrVar1 As String ...
                | objThisIntf.SetID iStrVar1

        :param i_id:
        :return:
        """
        return self.psp_id.SetID(i_id)

    def __repr__(self):
        return f'PspID()'
