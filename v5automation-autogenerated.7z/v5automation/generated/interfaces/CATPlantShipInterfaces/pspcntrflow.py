#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspCntrFlow(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents Interface to manage Connector Flow property.Role: To query
                | and modify Plant-Ship Connector Flow property.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_cntr_flow = com_object     

    @property
    def flow_capability(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlowCapability
                | o Property FlowCapability(    ) As
                | 
                | Returns or sets Flow capability of the connector. Example:
                | Dim objThisIntf As PspCntrFlow Dim ojArg1 As
                | CatPspIDLFlowCapability ... Set ojArg1 =
                | objThisIntf.FlowCapability
                |

        :return:
        """
        return self.psp_cntr_flow.FlowCapability

    @flow_capability.setter
    def flow_capability(self, value):
        """
            :param type value:
        """
        self.psp_cntr_flow.FlowCapability = value 

    @property
    def flow_reality(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlowReality
                | o Property FlowReality(    ) As
                | 
                | Returns or sets Flow reality of the connector. Example: Dim
                | objThisIntf As PspCntrFlow Dim ojArg1 As
                | CatPspIDLFlowReality ... Set ojArg1 =
                | objThisIntf.FlowReality
                |

        :return:
        """
        return self.psp_cntr_flow.FlowReality

    @flow_reality.setter
    def flow_reality(self, value):
        """
            :param type value:
        """
        self.psp_cntr_flow.FlowReality = value 

    def __repr__(self):
        return f'PspCntrFlow()'
