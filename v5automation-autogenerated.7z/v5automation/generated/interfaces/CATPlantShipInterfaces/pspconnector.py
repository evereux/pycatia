#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class PspConnector(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents connector object.Role: To specify connector behaviors such
                | as connect and disconnect.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.psp_connector = com_object     

    @property
    def attr_names(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AttrNames
                | o Property AttrNames(    ) As
                | 
                | Returns or Sets Attribute names of the connector. Example:
                | Dim objThisIntf As PspConnector Dim ojArg1 As
                | CATIAPspListOfBSTRs ... Set ojArg1 = objThisIntf.AttrNames
                |

        :return:
        """
        return self.psp_connector.AttrNames

    @property
    def connector_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorName
                | o Property ConnectorName(    ) As
                | 
                | Returns or sets name of the connector. Example: Dim
                | objThisIntf As PspConnector Dim strVar1 As CATBSTR ... Set
                | strVar1 = objThisIntf.Name Dim strVar1 As CATBSTR ...
                | objThisIntf.ConnectorName = strVar2
                |

        :return:
        """
        return self.psp_connector.ConnectorName

    @connector_name.setter
    def connector_name(self, value):
        """
            :param type value:
        """
        self.psp_connector.ConnectorName = value 

    def connect(self, i_cntr_to_connect):
        """
        .. note::
            CAA V5 Visual Basic help

                | Connect
                | o Sub Connect(        iCntrToConnect)
                | 
                | Connect the connector to another connector.
                |
                | Parameters:
                | iCntrToConnect
                |    the connector to be connected to

                |                | Examples:
                | Dim objThisIntf As PspConnector Dim objArg1 As PspConnector
                | ... objThisIntf.Connect objArg1

        :param i_cntr_to_connect:
        :return:
        """
        return self.psp_connector.Connect(i_cntr_to_connect)

    def disconnect(self, i_cntr_to_disconnect):
        """
        .. note::
            CAA V5 Visual Basic help

                | Disconnect
                | o Sub Disconnect(        iCntrToDisconnect)
                | 
                | DisConnect the connector from another connector.
                |
                | Parameters:
                | iCntrToDisconnect
                |    The connector to be disconnected from

                |                | Examples:
                | Dim objThisIntf As PspConnector Dim objArg1 As PspConnector
                | ... objThisIntf.Disconnect objArg1

        :param i_cntr_to_disconnect:
        :return:
        """
        return self.psp_connector.Disconnect(i_cntr_to_disconnect)

    def get_associated_connectable(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAssociatedConnectable
                | o Func GetAssociatedConnectable(    ) As
                | 
                | Get the connectable-owner of this connector.
                |
                | Parameters:
                | oConnectable
                |    Connectable owner of this connector

                |                | Examples:
                | Dim objThisIntf As PspConnector Dim objArg1 As
                | CATIAPspConnectable ... Set objArg1 =
                | objThisIntf.GetAssociatedConnectable

        :return:
        """
        return self.psp_connector.GetAssociatedConnectable()

    def is_cntr_connected(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsCntrConnected
                | o Func IsCntrConnected(    ) As
                | 
                | Query whether the connector has been connected. Returns:
                | TRUE if this connector is connected. Example: Dim
                | objThisIntf As PspConnector Dim bArg1 As boolean ... bArg1 =
                | objThisIntf.IsCntrConnected
                |
                | Parameters:

                |
        :return:
        """
        return self.psp_connector.IsCntrConnected()

    def __repr__(self):
        return f'PspConnector()'
