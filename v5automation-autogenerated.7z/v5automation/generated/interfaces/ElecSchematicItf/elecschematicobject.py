#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ElecSchematicObject(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the electrical schematic objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.elec_schematic_object = com_object     

    @property
    def connected_elec_sch_objects(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectedElecSchObjects
                | o Property ConnectedElecSchObjects(    ) As   (Read Only)
                | 
                | This method returns the collection of Electrical Schematic
                | Connected Objects.
                |

        :return:
        """
        return self.elec_schematic_object.ConnectedElecSchObjects

    @property
    def elec_schematic_children(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ElecSchematicChildren
                | o Property ElecSchematicChildren(    ) As   (Read Only)
                | 
                | This method returns the collection of Electrical Schematic
                | Object's Children (component in Pipe Line, Assembly).
                |

        :return:
        """
        return self.elec_schematic_object.ElecSchematicChildren

    @property
    def elec_schematic_parent(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ElecSchematicParent
                | o Property ElecSchematicParent(    ) As   (Read Only)
                | 
                | This method returns the electrical schematic parent.
                |

        :return:
        """
        return self.elec_schematic_object.ElecSchematicParent

    @property
    def is_space_reserved(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsSpaceReserved
                | o Property IsSpaceReserved(    ) As   (Read Only)
                | 
                | Defines if the electrical schematic object has a reservation
                | box in 3D world
                |

        :return:
        """
        return self.elec_schematic_object.IsSpaceReserved

    @property
    def root_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RootType
                | o Property RootType(    ) As   (Read Only)
                | 
                | Returns the Electrical Schematic Object's Root Type
                | (Equipment, Signal, Bundle, Wire).
                |

        :return:
        """
        return self.elec_schematic_object.RootType

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the Electrical Schematic Object's Type (Alternator,
                | Signal, Bundle, Wire, ...).
                |

        :return:
        """
        return self.elec_schematic_object.Type

    def get_pin_attribute(self, i_connected_object, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPinAttribute
                | o Func GetPinAttribute(        iConnectedObject,
                |                                iAttrName) As
                | 
                | Get the value of an attribute of the pin which connects this
                | and the specified object.
                |
                | Parameters:

                |
        :param i_connected_object:
        :param i_attr_name:
        :return:
        """
        return self.elec_schematic_object.GetPinAttribute(i_connected_object, i_attr_name)

    def __repr__(self):
        return f'ElecSchematicObject()'
