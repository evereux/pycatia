#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class IgesSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the CATIA IGES setting controller object.Role: The CATIA
                | IGES setting controller object deals with the setting attributes
                | displayed in the IGES property page. To access this property page:The
                | New Elements setting controller object can be retrieved as an item of
                | the setting controller collection using its name
                | "CAACafNewEltSettingCtrl" as follows:Dim settingControllers1 As
                | SettingControllers Set settingControllers1 = CATIA.SettingControllers
                | Dim CATIAIGESSettingAtt1 As SettingController Set CATIAIGESSettingAtt1
                | = settingControllers1.Item("CATIdeIgesSettingCtrl")

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.iges_setting_att = com_object     

    @property
    def angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Angle
                | o Property Angle(    ) As
                | 
                | Returns or sets the Angle setting parameter value. Role: The
                | Angle setting parameter manages the maximal angle of
                | deformation.
                |

        :return:
        """
        return self.iges_setting_att.Angle

    @angle.setter
    def angle(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.Angle = value 

    @property
    def apply_join(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyJoin
                | o Property ApplyJoin(    ) As
                | 
                | Returns or sets the Apply join setting parameter value.
                | Role: The XXX setting parameter manages the Apply Join mode
                |

        :return:
        """
        return self.iges_setting_att.ApplyJoin

    @apply_join.setter
    def apply_join(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.ApplyJoin = value 

    @property
    def author_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AuthorName
                | o Property AuthorName(    ) As
                | 
                | Returns or sets the Author Name setting parameter value.
                | Role: The Author Name setting parameter manages the Author
                | Name.
                |

        :return:
        """
        return self.iges_setting_att.AuthorName

    @author_name.setter
    def author_name(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.AuthorName = value 

    @property
    def author_organization(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AuthorOrganization
                | o Property AuthorOrganization(    ) As
                | 
                | Returns or sets the Author Organization setting parameter
                | value. Role: The Author Organization setting parameter
                | manages the Author Organization.
                |

        :return:
        """
        return self.iges_setting_att.AuthorOrganization

    @author_organization.setter
    def author_organization(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.AuthorOrganization = value 

    @property
    def crv_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CrvMod
                | o Property CrvMod(    ) As
                | 
                | Returns or sets the Export BSpline mode setting parameter
                | value. Role: The Export BSpline mode setting parameter
                | manages the mode to export curves and surfaces
                |

        :return:
        """
        return self.iges_setting_att.CrvMod

    @crv_mod.setter
    def crv_mod(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.CrvMod = value 

    @property
    def export_msbo(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportMSBO
                | o Property ExportMSBO(    ) As
                | 
                | Returns or sets the Export Solid Mode setting parameter
                | value. Role: The Export Solid Mode setting parameter manages
                | the export of solids and shells
                |

        :return:
        """
        return self.iges_setting_att.ExportMSBO

    @export_msbo.setter
    def export_msbo(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.ExportMSBO = value 

    @property
    def export_unit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExportUnit
                | o Property ExportUnit(    ) As
                | 
                | Returns or sets the Export Units setting parameter value.
                | Role: The Export Units setting parameter manages the unit in
                | exported IGES Files.
                |

        :return:
        """
        return self.iges_setting_att.ExportUnit

    @export_unit.setter
    def export_unit(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.ExportUnit = value 

    @property
    def import_group_as_sel_set(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImportGroupAsSelSet
                | o Property ImportGroupAsSelSet(    ) As
                | 
                | Returns or sets the Import Selection Set mode setting
                | parameter value. Role: The Import Selection Set mode setting
                | parameter manages the Import of IGES groups.
                |

        :return:
        """
        return self.iges_setting_att.ImportGroupAsSelSet

    @import_group_as_sel_set.setter
    def import_group_as_sel_set(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.ImportGroupAsSelSet = value 

    @property
    def only_show(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OnlyShow
                | o Property OnlyShow(    ) As
                | 
                | Returns or sets the Export only show setting parameter
                | value. Role: The Export only show setting parameter manages
                | the mode to export entities in No-Show
                |

        :return:
        """
        return self.iges_setting_att.OnlyShow

    @only_show.setter
    def only_show(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.OnlyShow = value 

    @property
    def opt_c2_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptC2Mode
                | o Property OptC2Mode(    ) As
                | 
                | Returns or sets the Continuity Optimization Mode setting
                | parameter value. Role: The Continuity Optimization Mode
                | setting parameter manages the ...
                |

        :return:
        """
        return self.iges_setting_att.OptC2Mode

    @opt_c2_mode.setter
    def opt_c2_mode(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.OptC2Mode = value 

    @property
    def opt_clean_topo_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptCleanTopoMode
                | o Property OptCleanTopoMode(    ) As
                | 
                | Returns or sets the clean topo mode setting parameter value.
                | Role: The clean topo mode setting parameter manages the the
                | Fitting Mode, in Advanced Optimize Continuity Mode.
                |

        :return:
        """
        return self.iges_setting_att.OptCleanTopoMode

    @opt_clean_topo_mode.setter
    def opt_clean_topo_mode(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.OptCleanTopoMode = value 

    @property
    def opt_fitting_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptFittingMode
                | o Property OptFittingMode(    ) As
                | 
                | Returns or sets the Fitting Mode setting parameter value.
                | Role: The Fitting Mode setting parameter manages the Fitting
                | Mode, in Advanced Optimize Continuity Mode.
                |

        :return:
        """
        return self.iges_setting_att.OptFittingMode

    @opt_fitting_mode.setter
    def opt_fitting_mode(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.OptFittingMode = value 

    @property
    def opt_invalid_geom_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptInvalidGeomMode
                | o Property OptInvalidGeomMode(    ) As
                | 
                | Returns or sets the InvalidGeom mode setting parameter
                | value. Role: The InvalidGeom mode setting parameter manages
                | the Invalid Geometry Checks.
                |

        :return:
        """
        return self.iges_setting_att.OptInvalidGeomMode

    @opt_invalid_geom_mode.setter
    def opt_invalid_geom_mode(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.OptInvalidGeomMode = value 

    @property
    def opt_loop_3d_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OptLoop3DMode
                | o Property OptLoop3DMode(    ) As
                | 
                | Returns or sets the Force 3D Loop setting parameter value.
                | Role: The Force 3D Loop setting parameter manages the Import
                | of IGES boundaries, to use only the 3D representation.
                |

        :return:
        """
        return self.iges_setting_att.OptLoop3DMode

    @opt_loop_3d_mode.setter
    def opt_loop_3d_mode(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.OptLoop3DMode = value 

    @property
    def part_prod_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartProdMode
                | o Property PartProdMode(    ) As
                | 
                | Returns or sets the Import Product mode setting parameter
                | value. Role: The Import Product mode setting parameter
                | manages the Product mode for Import of 308/408 IGES
                | entities.
                |

        :return:
        """
        return self.iges_setting_att.PartProdMode

    @part_prod_mode.setter
    def part_prod_mode(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.PartProdMode = value 

    @property
    def rep_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RepMod
                | o Property RepMod(    ) As
                | 
                | Returns or sets the Export representation mode setting
                | parameter value. Role: The Export representation mode
                | setting parameter manages the export of faces as surfaces or
                | as wireframe.
                |

        :return:
        """
        return self.iges_setting_att.RepMod

    @rep_mod.setter
    def rep_mod(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.RepMod = value 

    @property
    def show_completion_dialog_box(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShowCompletionDialogBox
                | o Property ShowCompletionDialogBox(    ) As
                | 
                | Returns or sets the Show/No Show dialog box setting
                | parameter value. Role: The Show/No Show dialog box setting
                | parameter manages the visibility of the Completion dialog
                | box. Legal values: 1 to show, and 0 to hide the Show/No Show
                | dialog box.
                |

        :return:
        """
        return self.iges_setting_att.ShowCompletionDialogBox

    @show_completion_dialog_box.setter
    def show_completion_dialog_box(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.ShowCompletionDialogBox = value 

    @property
    def tol_join(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TolJoin
                | o Property TolJoin(    ) As
                | 
                | Returns or sets the join tolerance setting parameter value.
                | Role: The join tolerance setting parameter manages the
                | Tolerance for Join
                |

        :return:
        """
        return self.iges_setting_att.TolJoin

    @tol_join.setter
    def tol_join(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.TolJoin = value 

    @property
    def tol_opt_invalid_geom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TolOptInvalidGeom
                | o Property TolOptInvalidGeom(    ) As
                | 
                | Returns or sets the InvalidGeom Tolerance setting parameter
                | value. Role: The InvalidGeom Tolerance setting parameter
                | manages the Tolerance for invalid geometry checks.
                |

        :return:
        """
        return self.iges_setting_att.TolOptInvalidGeom

    @tol_opt_invalid_geom.setter
    def tol_opt_invalid_geom(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.TolOptInvalidGeom = value 

    @property
    def tolerance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Tolerance
                | o Property Tolerance(    ) As
                | 
                | Returns or sets the tolerance ( optimize - fitting ) setting
                | parameter value. Role: The tolerance ( optimize - fitting )
                | setting parameter manages the tolerance for Optimize
                | continuity and Fitting.
                |

        :return:
        """
        return self.iges_setting_att.Tolerance

    @tolerance.setter
    def tolerance(self, value):
        """
            :param type value:
        """
        self.iges_setting_att.Tolerance = value 

    def get_angle_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAngleInfo
                | o Func GetAngleInfo(        ioAdminLevel,
                |                             ioLocked) As
                | 
                | Retrieves information about the Angle setting parameter.
                | Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetAngleInfo(io_admin_level, io_locked)

    def get_apply_join_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetApplyJoinInfo
                | o Func GetApplyJoinInfo(        ioAdminLevel,
                |                                 ioLocked) As
                | 
                | Retrieves information about the Apply Join setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetApplyJoinInfo(io_admin_level, io_locked)

    def get_author_name_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAuthorNameInfo
                | o Func GetAuthorNameInfo(        ioAdminLevel,
                |                                  ioLocked) As
                | 
                | Retrieves environment informations for the AuthorName
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetAuthorNameInfo(io_admin_level, io_locked)

    def get_author_organization_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAuthorOrganizationInfo
                | o Func GetAuthorOrganizationInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | AuthorOrganization parameter. Refer to for a detailed
                | description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetAuthorOrganizationInfo(io_admin_level, io_locked)

    def get_crv_mod_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCrvModInfo
                | o Func GetCrvModInfo(        ioAdminLevel,
                |                              ioLocked) As
                | 
                | Retrieves information about the Export BSpline mode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetCrvModInfo(io_admin_level, io_locked)

    def get_export_msbo_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportMSBOInfo
                | o Func GetExportMSBOInfo(        ioAdminLevel,
                |                                  ioLocked) As
                | 
                | Retrieves information about the Export Solid Mode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetExportMSBOInfo(io_admin_level, io_locked)

    def get_export_unit_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetExportUnitInfo
                | o Func GetExportUnitInfo(        ioAdminLevel,
                |                                  ioLocked) As
                | 
                | Retrieves information about the Export Units setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetExportUnitInfo(io_admin_level, io_locked)

    def get_import_group_as_sel_set_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetImportGroupAsSelSetInfo
                | o Func GetImportGroupAsSelSetInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves information about the Import Selection Set mode
                | setting parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetImportGroupAsSelSetInfo(io_admin_level, io_locked)

    def get_only_show_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOnlyShowInfo
                | o Func GetOnlyShowInfo(        ioAdminLevel,
                |                                ioLocked) As
                | 
                | Retrieves information about the Export only show setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetOnlyShowInfo(io_admin_level, io_locked)

    def get_opt_c2_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptC2ModeInfo
                | o Func GetOptC2ModeInfo(        ioAdminLevel,
                |                                 ioLocked) As
                | 
                | Retrieves information about the Continuity Optimization Mode
                | setting parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetOptC2ModeInfo(io_admin_level, io_locked)

    def get_opt_clean_topo_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptCleanTopoModeInfo
                | o Func GetOptCleanTopoModeInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves information about the Clean Topo Mode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetOptCleanTopoModeInfo(io_admin_level, io_locked)

    def get_opt_fitting_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptFittingModeInfo
                | o Func GetOptFittingModeInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves information about the Fitting Mode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetOptFittingModeInfo(io_admin_level, io_locked)

    def get_opt_invalid_geom_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptInvalidGeomModeInfo
                | o Func GetOptInvalidGeomModeInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves information about the InvalidGeom mode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetOptInvalidGeomModeInfo(io_admin_level, io_locked)

    def get_opt_loop_3d_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOptLoop3DModeInfo
                | o Func GetOptLoop3DModeInfo(        ioAdminLevel,
                |                                     ioLocked) As
                | 
                | Retrieves information about the Force 3D Loop setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetOptLoop3DModeInfo(io_admin_level, io_locked)

    def get_part_prod_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPartProdModeInfo
                | o Func GetPartProdModeInfo(        ioAdminLevel,
                |                                    ioLocked) As
                | 
                | Retrieves information about the Import Product mode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetPartProdModeInfo(io_admin_level, io_locked)

    def get_rep_mod_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRepModInfo
                | o Func GetRepModInfo(        ioAdminLevel,
                |                              ioLocked) As
                | 
                | Retrieves information about the Export representation mode
                | setting parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetRepModInfo(io_admin_level, io_locked)

    def get_show_completion_dialog_box_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShowCompletionDialogBoxInfo
                | o Func GetShowCompletionDialogBoxInfo(        ioAdminLevel,
                |                                               ioLocked) As
                | 
                | Retrieves information about the Show/No Show dialog box
                | setting parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetShowCompletionDialogBoxInfo(io_admin_level, io_locked)

    def get_tol_join_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTolJoinInfo
                | o Func GetTolJoinInfo(        ioAdminLevel,
                |                               ioLocked) As
                | 
                | Retrieves information about the join tolerance setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetTolJoinInfo(io_admin_level, io_locked)

    def get_tol_opt_invalid_geom_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTolOptInvalidGeomInfo
                | o Func GetTolOptInvalidGeomInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves information about the InvalidGeom Tolerance
                | setting parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetTolOptInvalidGeomInfo(io_admin_level, io_locked)

    def get_tolerance_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetToleranceInfo
                | o Func GetToleranceInfo(        ioAdminLevel,
                |                                 ioLocked) As
                | 
                | Retrieves information about the Tolerance ( optimize -
                | fitting ) setting parameter. Refer to for a detailed
                | description.
                |
                | Parameters:

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.iges_setting_att.GetToleranceInfo(io_admin_level, io_locked)

    def set_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAngleLock
                | o Sub SetAngleLock(        iLocked)
                | 
                | Locks or unlocks the Angle setting parameter. Refer to for a
                | detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetAngleLock(i_locked)

    def set_apply_join_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetApplyJoinLock
                | o Sub SetApplyJoinLock(        iLocked)
                | 
                | Locks or unlocks the Apply Join setting parameter. Refer to
                | for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetApplyJoinLock(i_locked)

    def set_author_name_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAuthorNameLock
                | o Sub SetAuthorNameLock(        iLocked)
                | 
                | Locks or unlocks the AuthorName parameter. Refer to for a
                | detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetAuthorNameLock(i_locked)

    def set_author_organization_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAuthorOrganizationLock
                | o Sub SetAuthorOrganizationLock(        iLocked)
                | 
                | Locks or unlocks the AuthorOrganization parameter. Refer to
                | for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetAuthorOrganizationLock(i_locked)

    def set_crv_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCrvModLock
                | o Sub SetCrvModLock(        iLocked)
                | 
                | Locks or unlocks the Export BSpline mode setting parameter.
                | Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetCrvModLock(i_locked)

    def set_export_msbo_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportMSBOLock
                | o Sub SetExportMSBOLock(        iLocked)
                | 
                | Locks or unlocks the Export Solid Mode setting parameter.
                | Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetExportMSBOLock(i_locked)

    def set_export_unit_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExportUnitLock
                | o Sub SetExportUnitLock(        iLocked)
                | 
                | Locks or unlocks the Export Units setting parameter. Refer
                | to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetExportUnitLock(i_locked)

    def set_import_group_as_sel_set_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetImportGroupAsSelSetLock
                | o Sub SetImportGroupAsSelSetLock(        iLocked)
                | 
                | Locks or unlocks the Import Selection Set mode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetImportGroupAsSelSetLock(i_locked)

    def set_only_show_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOnlyShowLock
                | o Sub SetOnlyShowLock(        iLocked)
                | 
                | Locks or unlocks the Export only show setting parameter.
                | Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetOnlyShowLock(i_locked)

    def set_opt_c2_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptC2ModeLock
                | o Sub SetOptC2ModeLock(        iLocked)
                | 
                | Locks or unlocks the Continuity Optimizationmode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetOptC2ModeLock(i_locked)

    def set_opt_clean_topo_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptCleanTopoModeLock
                | o Sub SetOptCleanTopoModeLock(        iLocked)
                | 
                | Locks or unlocks the Clean Topo Mode setting parameter.
                | Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetOptCleanTopoModeLock(i_locked)

    def set_opt_fitting_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptFittingModeLock
                | o Sub SetOptFittingModeLock(        iLocked)
                | 
                | Locks or unlocks the Fitting Mode setting parameter. Refer
                | to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetOptFittingModeLock(i_locked)

    def set_opt_invalid_geom_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptInvalidGeomModeLock
                | o Sub SetOptInvalidGeomModeLock(        iLocked)
                | 
                | Locks or unlocks the InvalidGeom mode setting parameter.
                | Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetOptInvalidGeomModeLock(i_locked)

    def set_opt_loop_3d_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOptLoop3DModeLock
                | o Sub SetOptLoop3DModeLock(        iLocked)
                | 
                | Locks or unlocks the Force 3D Loop setting parameter. Refer
                | to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetOptLoop3DModeLock(i_locked)

    def set_part_prod_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPartProdModeLock
                | o Sub SetPartProdModeLock(        iLocked)
                | 
                | Locks or unlocks the Import Product mode setting parameter.
                | Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetPartProdModeLock(i_locked)

    def set_rep_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRepModLock
                | o Sub SetRepModLock(        iLocked)
                | 
                | Locks or unlocks the Export representation mode setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetRepModLock(i_locked)

    def set_show_completion_dialog_box_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShowCompletionDialogBoxLock
                | o Sub SetShowCompletionDialogBoxLock(        iLocked)
                | 
                | Locks or unlocks the Show/No Show dialog box setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetShowCompletionDialogBoxLock(i_locked)

    def set_tol_join_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTolJoinLock
                | o Sub SetTolJoinLock(        iLocked)
                | 
                | Locks or unlocks the join tolerance setting parameter. Refer
                | to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetTolJoinLock(i_locked)

    def set_tol_opt_invalid_geom_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTolOptInvalidGeomLock
                | o Sub SetTolOptInvalidGeomLock(        iLocked)
                | 
                | Locks or unlocks the InvalidGeom Tolerance setting
                | parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetTolOptInvalidGeomLock(i_locked)

    def set_tolerance_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetToleranceLock
                | o Sub SetToleranceLock(        iLocked)
                | 
                | Locks or unlocks the Tolerance ( optimize - fitting )
                | setting parameter. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.iges_setting_att.SetToleranceLock(i_locked)

    def __repr__(self):
        return f'IgesSettingAtt()'
