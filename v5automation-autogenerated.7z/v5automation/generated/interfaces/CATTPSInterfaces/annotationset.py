#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AnnotationSet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for the TPS Set of objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.annotation_set = com_object     

    @property
    def active_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActiveView
                | o Property ActiveView(    ) As
                | 
                | Gets or Sets Annotation Set ActiveView.
                |

        :return:
        """
        return self.annotation_set.ActiveView

    @property
    def an_empty_annotations_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnEmptyAnnotationsList
                | o Property AnEmptyAnnotationsList(    ) As   (Read Only)
                | 
                | Retrieves an empty Annotations'Collection.
                |

        :return:
        """
        return self.annotation_set.AnEmptyAnnotationsList

    @property
    def annotation_factory(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnnotationFactory
                | o Property AnnotationFactory(    ) As   (Read Only)
                | 
                | Obtain the factory to create annotations.
                |

        :return:
        """
        return self.annotation_set.AnnotationFactory

    @property
    def annotations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Annotations
                | o Property Annotations(    ) As   (Read Only)
                | 
                | Retrieves the TPS components of the set.
                |

        :return:
        """
        return self.annotation_set.Annotations

    @property
    def capture_factory(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CaptureFactory
                | o Property CaptureFactory(    ) As   (Read Only)
                | 
                | Obtain the factory to create Capture.
                |

        :return:
        """
        return self.annotation_set.CaptureFactory

    @property
    def captures(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Captures
                | o Property Captures(    ) As   (Read Only)
                | 
                | Retrieves all the Captures that belong to the set.
                |

        :return:
        """
        return self.annotation_set.Captures

    @property
    def kind_of_set(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | KindOfSet
                | o Property KindOfSet(    ) As   (Read Only)
                | 
                | Give the kind of set (Part, Product...).
                |

        :return:
        """
        return self.annotation_set.KindOfSet

    @property
    def standard(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Standard
                | o Property Standard(    ) As   (Read Only)
                | 
                | Retrieves the Parent Standard defined at set creation.
                |

        :return:
        """
        return self.annotation_set.Standard

    @property
    def switch_on(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SwitchOn
                | o Property SwitchOn(    ) As
                | 
                | Gets or Sets Annotation Set Visualization.
                |

        :return:
        """
        return self.annotation_set.SwitchOn

    @property
    def tps_view_factory(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TPSViewFactory
                | o Property TPSViewFactory(    ) As   (Read Only)
                | 
                | Obtain the factory to create TPS Views.
                |

        :return:
        """
        return self.annotation_set.TPSViewFactory

    @property
    def tps_views(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TPSViews
                | o Property TPSViews(    ) As   (Read Only)
                | 
                | Retrieves all the TPSViews that belong to the set.
                |

        :return:
        """
        return self.annotation_set.TPSViews

    def __repr__(self):
        return f'AnnotationSet()'
