#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AnnotationSetTransformIntoAssemblySet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface designed to transform an annotation set into an assembly
                | annotation set.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.annotation_set_transform_into_assembly_set = com_object     

    def transform(self, i_assemblyannotation_set_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | Transform
                | o Sub Transform(        iAssemblyannotationSetName)
                | 
                | Transforms annotation set into an assembly annotation set.
                |
                | Parameters:
                | iAssemblyannotationSetName
                |  [in]   The name of the assembly annotation transformed
                |    If the iAssemblyannotationSetName is an empty string, the assembly annotation set keeps the name
                |    of the annotation set from which it comes.
                | 
                |  returns S_OK when transformation succeeded.
                |  returns S_OK when the annotation set is already an assembly annotation set.
                |  otherwise returns E_FAIL.

                |
        :param i_assemblyannotation_set_name:
        :return:
        """
        return self.annotation_set_transform_into_assembly_set.Transform(i_assemblyannotation_set_name)

    def __repr__(self):
        return f'AnnotationSetTransformIntoAssemblySet()'
