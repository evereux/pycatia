#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class UserSurface(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.user_surface = com_object     

    def add_reference(self, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddReference
                | o Sub AddReference(        iSupport)
                | 
                | Add a surface in a User Surface Support
                |
                | Parameters:
                | iSupport
                |      The surface that you want to add in the User Surface.

                |
        :param i_support:
        :return:
        """
        return self.user_surface.AddReference(i_support)

    def add_reference_in_a_product_ctx(self, i_prod_inst, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddReferenceInAProductCtx
                | o Sub AddReferenceInAProductCtx(        iProdInst,
                |                                         iSupport)
                | 
                | Add a surface in a User Surface Support
                |
                | Parameters:
                | iProdInst
                |      The product instance where there is the geometry.
                |    
                |  iSupport
                |      The surface that you want to add in the User Surface.

                |
        :param i_prod_inst:
        :param i_support:
        :return:
        """
        return self.user_surface.AddReferenceInAProductCtx(i_prod_inst, i_support)

    def add_user_surface(self, i_user_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddUserSurface
                | o Sub AddUserSurface(        iUserSurf)
                | 
                | Add a User Surface Support in a User Surface Node
                |
                | Parameters:
                | iUserSurf
                |      The User Surface Support that you want to add in the User Surface.

                |
        :param i_user_surf:
        :return:
        """
        return self.user_surface.AddUserSurface(i_user_surf)

    def __repr__(self):
        return f'UserSurface()'
