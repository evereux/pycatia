#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ToleranceZone(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for accessing tolerance zone informations of a TPS.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.tolerance_zone = com_object     

    @property
    def form(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Form
                | o Property Form(    ) As
                | 
                | Retrieves tolerance zone form.
                |

        :return:
        """
        return self.tolerance_zone.Form

    @property
    def value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Value
                | o Property Value(    ) As
                | 
                | Retrieves tolerance zone value (in millimeters).
                |

        :return:
        """
        return self.tolerance_zone.Value

    def __repr__(self):
        return f'ToleranceZone()'
