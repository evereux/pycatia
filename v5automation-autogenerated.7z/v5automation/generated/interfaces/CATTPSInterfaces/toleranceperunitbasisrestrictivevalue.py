#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class TolerancePerUnitBasisRestrictiveValue(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for accessing tolerance per unit basis restrictive value on
                | a TPS.(ASME norm only)

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.tolerance_per_unit_basis_restrictive_value = com_object     

    @property
    def value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Value
                | o Property Value(    ) As
                | 
                | Retrieves value (in millimeters).
                |

        :return:
        """
        return self.tolerance_per_unit_basis_restrictive_value.Value

    def __repr__(self):
        return f'TolerancePerUnitBasisRestrictiveValue()'
