#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DatumSimple(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for Simple Datum TPS (datum entity).TPS for Technological
                | Product Specifications.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.datum_simple = com_object     

    @property
    def label(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Label
                | o Property Label(    ) As
                | 
                | Retrieves or sets Label.
                |

        :return:
        """
        return self.datum_simple.Label

    @property
    def targets(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Targets
                | o Property Targets(    ) As   (Read Only)
                | 
                | Retrieves a CATITPSList to read the list of datum target.
                | All objects of the list adhere to CATITPSDatumTarget.
                |

        :return:
        """
        return self.datum_simple.Targets

    def __repr__(self):
        return f'DatumSimple()'
