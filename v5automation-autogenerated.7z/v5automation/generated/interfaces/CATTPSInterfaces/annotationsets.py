#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AnnotationSets(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for collection of Annotations' Set

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.annotation_sets = com_object     

    def add_in_a_product(self, i_product, i_standard):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddInAProduct
                | o Func AddInAProduct(        iProduct,
                |                              iStandard) As
                | 
                | Add a set in the product.
                |
                | Parameters:

                |
        :param i_product:
        :param i_standard:
        :return:
        """
        return self.annotation_sets.AddInAProduct(i_product, i_standard)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Retrieve a set.
                |
                | Parameters:

                |
        :param i_index:
        :return:
        """
        return self.annotation_sets.Item(i_index)

    def load_annotation_sets_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadAnnotationSetsList
                | o Sub LoadAnnotationSetsList(    )
                | 
                | Loads the Annotation Sets list. This method is very useful
                | when a cgr document containing Annotation Set is inserted in
                | the product, because the Annotation Set is not automatically
                | loaded If the Annotation Set is already loaded nothing
                | happens.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation_sets.LoadAnnotationSetsList()

    def __repr__(self):
        return f'AnnotationSets()'
