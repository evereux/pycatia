#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CompositeTolerance(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for accessing composite tolerance on a TPS.(ASME norm only)

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.composite_tolerance = com_object     

    @property
    def box_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BoxCount
                | o Property BoxCount(    ) As   (Read Only)
                | 
                | Retrieves datum count.
                |

        :return:
        """
        return self.composite_tolerance.BoxCount

    @property
    def value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Value
                | o Property Value(    ) As   (Read Only)
                | 
                | Retrieves value (in millimeters).
                |

        :return:
        """
        return self.composite_tolerance.Value

    def __repr__(self):
        return f'CompositeTolerance()'
