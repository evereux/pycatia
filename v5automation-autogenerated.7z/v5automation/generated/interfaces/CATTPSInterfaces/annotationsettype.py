#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AnnotationSetType(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAAnnotationSetType.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.annotation_set_type = com_object     

    @property
    def annotation_set_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnnotationSetType
                | o Property AnnotationSetType(    ) As   (Read Only)
                | 
                | Get the annotation Set type.
                |

        :return:
        """
        return self.annotation_set_type.AnnotationSetType

    def __repr__(self):
        return f'AnnotationSetType()'
