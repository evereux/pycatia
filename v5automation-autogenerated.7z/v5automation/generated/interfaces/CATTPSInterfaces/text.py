#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Text(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for the TPS Text object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.text = com_object     

    @property
    def text(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Text
                | o Property Text(    ) As
                | 
                | Get the annotation's text.
                |

        :return:
        """
        return self.text.Text

    def get2d_annot(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Get2dAnnot
                | o Func Get2dAnnot(    ) As
                | 
                | Retrieves Drafting text.
                |
                | Parameters:

                |
        :return:
        """
        return self.text.Get2dAnnot()

    def __repr__(self):
        return f'Text()'
