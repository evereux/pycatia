#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class FlagNote(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for the TPS Flag Note object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.flag_note = com_object     

    @property
    def flag_note_text(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlagNoteText
                | o Property FlagNoteText(    ) As   (Read Only)
                | 
                | Retrieves flag text.
                |

        :return:
        """
        return self.flag_note.FlagNoteText

    @property
    def text(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Text
                | o Property Text(    ) As   (Read Only)
                | 
                | Retrieves text.
                |

        :return:
        """
        return self.flag_note.Text

    def add_url(self, i_url):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddURL
                | o Sub AddURL(        iUrl)
                | 
                | Sets an URL.
                |
                | Parameters:
                | iUrl
                |    URL to Set

                |
        :param i_url:
        :return:
        """
        return self.flag_note.AddURL(i_url)

    def get_nbr_url(self, o_number_of_url):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNbrURL
                | o Sub GetNbrURL(        oNumberOfURL)
                | 
                | Gets the number of URL.
                |
                | Parameters:
                | oNumberOfURL
                |    returns param oNumberOfURL.

                |
        :param o_number_of_url:
        :return:
        """
        return self.flag_note.GetNbrURL(o_number_of_url)

    def modify_url(self, i_url, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | ModifyURL
                | o Sub ModifyURL(        iUrl,
                |                         iIndex)
                | 
                | Modifies an URL.
                |
                | Parameters:
                | iUrl
                |    URL to Set.
                |   
                |  iIndex
                |    index of the URL to modify.

                |
        :param i_url:
        :param i_index:
        :return:
        """
        return self.flag_note.ModifyURL(i_url, i_index)

    def remove_url(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveURL
                | o Sub RemoveURL(        iIndex)
                | 
                | Remove an URL.
                |
                | Parameters:
                | iIndex
                |    position of the URL to remove.

                |
        :param i_index:
        :return:
        """
        return self.flag_note.RemoveURL(i_index)

    def url(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | URL
                | o Func URL(        iIndex) As
                | 
                | Retrieves URL.
                |
                | Parameters:
                | iIndex
                |    Index of URL.
                |   
                |  oUrl
                |    URL

                |
        :param i_index:
        :return:
        """
        return self.flag_note.URL(i_index)

    def __repr__(self):
        return f'FlagNote()'
