#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DimensionPattern(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to dimension pattern.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.dimension_pattern = com_object     

    @property
    def instance_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InstanceCount
                | o Property InstanceCount(    ) As   (Read Only)
                | 
                | Get count of instances.
                |

        :return:
        """
        return self.dimension_pattern.InstanceCount

    def __repr__(self):
        return f'DimensionPattern()'
