#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class TPSViews(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for collection of TPS Views CATIATPSView.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.tps_views = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Retrieve a TPS View.
                |
                | Parameters:

                |
        :param i_index:
        :return:
        """
        return self.tps_views.Item(i_index)

    def __repr__(self):
        return f'TPSViews()'
