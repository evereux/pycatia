#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ToleranceUnitBasisValue(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for accessing values of the tolerance unit basis on a TPS.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.tolerance_unit_basis_value = com_object     

    def set_values(self, i_value_1, i_value_2):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetValues
                | o Sub SetValues(        iValue1,
                |                         iValue2)
                | 
                | Set tolerance unit basis values (in millimeters).
                |
                | Parameters:
                | oValue1
                |      Positive or equal to -1 which means not valuated.
                |    
                |  oValue2
                |      Positive or equal to -1 which means not valuated.

                |
        :param i_value_1:
        :param i_value_2:
        :return:
        """
        return self.tolerance_unit_basis_value.SetValues(i_value_1, i_value_2)

    def values(self, o_value_1, o_value_2):
        """
        .. note::
            CAA V5 Visual Basic help

                | Values
                | o Sub Values(        oValue1,
                |                      oValue2)
                | 
                | Retrieves tolerance unit basis values (in millimeters).
                |
                | Parameters:
                | oValue1
                |      Positive or equal to -1 which means not valuated.
                |    
                |  oValue2
                |      Positive or equal to -1 which means not valuated.

                |
        :param o_value_1:
        :param o_value_2:
        :return:
        """
        return self.tolerance_unit_basis_value.Values(o_value_1, o_value_2)

    def __repr__(self):
        return f'ToleranceUnitBasisValue()'
