#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ProjectedToleranceZone(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for accessing projected tolerance zone informations of a
                | TPS.========|   Position      Length              /       |||
                | Toleranced     |             |             |  Surface  - - - +------->
                | +=============+      \          |\       \               \        \
                | | Origin Direction       Projected Tolerance Zone         ========|

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.projected_tolerance_zone = com_object     

    @property
    def length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Length
                | o Property Length(    ) As   (Read Only)
                | 
                | Retrieves length of the projected tolerance zone (in
                | millimeters). The length defines the ending point of the
                | tolerance zone. This point can be computed by using Origin
                | and Direction of the axis.
                |

        :return:
        """
        return self.projected_tolerance_zone.Length

    @property
    def position(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Position
                | o Property Position(    ) As   (Read Only)
                | 
                | Retrieves position of the projected tolerance zone (in
                | millimeters). The position defines the starting point of the
                | tolerance zone. This point can be computed by using Origin
                | and Direction of the axis.
                |

        :return:
        """
        return self.projected_tolerance_zone.Position

    def get_projected_tol_zone_reference(self, op_reference):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProjectedTolZoneReference
                | o Sub GetProjectedTolZoneReference(        opReference)
                | 
                | Retrieves reference axis of the projected tolerance zone.
                | The returned point and vector define a axis system that is
                | used to defined the 3D position of the tolerance zone.
                |
                | Parameters:
                | opReference
                |      The first 3 values of opReference correspond to the X,Y and Z
                |      values of the origin point respectively and the next 3 values
                |      correspond to the X,Y and Z values of the direction respectively.

                |                | Examples:
                | This example gets the Projected Tolerance Zone reference in
                | a VB Script Dim oTab(6) As CATSafeArrayVariant Set projTol =
                | annotation.ProjectedToleranceZone
                | projTol.GetProjectedTolZoneReference(oTab) oStream.Write
                | "Projected Tol Zone Reference Point : " & oTab(0) & " " &
                | oTab(1) & " " & oTab(2) & sLF oStream.Write "Projected Tol
                | Zone Reference Vector : " & oTab(3) & " " & oTab(4) & " " &
                | oTab(5) & sLF

        :param op_reference:
        :return:
        """
        return self.projected_tolerance_zone.GetProjectedTolZoneReference(op_reference)

    def __repr__(self):
        return f'ProjectedToleranceZone()'
