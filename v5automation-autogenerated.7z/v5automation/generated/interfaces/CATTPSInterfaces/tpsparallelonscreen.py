#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class TPSParallelOnScreen(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for Parallel On Screen.TPS for Technological Product
                | Specifications.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.tps_parallel_on_screen = com_object     

    @property
    def parallel_on_screen(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ParallelOnScreen
                | o Property ParallelOnScreen(    ) As
                | 
                | Retrieves the Parallel On Screen for the annotation.
                |

        :return:
        """
        return self.tps_parallel_on_screen.ParallelOnScreen

    @property
    def zoomable(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Zoomable
                | o Property Zoomable(    ) As
                | 
                | Retrieves the Zoomable for the annotation.
                |

        :return:
        """
        return self.tps_parallel_on_screen.Zoomable

    def __repr__(self):
        return f'TPSParallelOnScreen()'
