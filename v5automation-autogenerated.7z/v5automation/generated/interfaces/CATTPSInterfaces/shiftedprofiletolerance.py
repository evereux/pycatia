#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ShiftedProfileTolerance(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for accessing shifted tolerance zone informations of a TPS.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.shifted_profile_tolerance = com_object     

    @property
    def shift_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShiftValue
                | o Property ShiftValue(    ) As
                | 
                | Retrieves or sets shift value of tolerance zone (in
                | millimeters). The shift value is the distance between the
                | toleranced surface and the median surface of tolerance zone.
                | The value is always positive because shift side is given by
                | GetShiftSide method.
                |

        :return:
        """
        return self.shifted_profile_tolerance.ShiftValue

    def get_shift_direction(self, op_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShiftDirection
                | o Sub GetShiftDirection(        opDirection)
                | 
                | Retrieves the shift direction by two points.
                |
                | Parameters:
                | opDirection
                |      The first 3 values of opDirection correspond to the X,Y and Z values
                |      of the start point respectively and the next 3 values correspond to the
                |      X, Y and Z values of the end point respectively.

                |                | Examples:
                | This example gets the start and end points in a VB Script
                | Dim oTab(6) As CATSafeArrayVariant Set shiftTol =
                | annotation.ShiftedProfileTolerance
                | shiftTol.GetShiftDirection(oTab) oStream.Write " Shifted
                | Direction Start Point : "& oTab(0) & " " & oTab(1) & " " &
                | oTab(2) & sLF oStream.Write " Shifted Direction End Point :
                | "& oTab(3) & " " & oTab(4) & " " & oTab(5) & sLF

        :param op_direction:
        :return:
        """
        return self.shifted_profile_tolerance.GetShiftDirection(op_direction)

    def get_shift_side(self, op_point):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShiftSide
                | o Sub GetShiftSide(        opPoint)
                | 
                | Retrieves shift side.
                |
                | Parameters:
                | opPoint
                |      a mathematical point located on the shift side of surface.
                |      The 3 values of opPoint correspond to the X,Y and Z values
                |      of the point located on the shift side of surface.

                |                | Examples:
                | This example gets the shift side point in a VB Script Dim
                | oShiftTab(3) As CATSafeArrayVariant Set shiftTol =
                | annotation.ShiftedProfileTolerance
                | shiftTol.GetShiftSide(oShiftTab) oStream.Write " Shifted
                | Side Point : "& oShiftTab(0) & " " & oShiftTab(1) & " " &
                | oShiftTab(2) & sLF

        :param op_point:
        :return:
        """
        return self.shifted_profile_tolerance.GetShiftSide(op_point)

    def __repr__(self):
        return f'ShiftedProfileTolerance()'
