#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Annotation(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for the Technological Product Specification (TPS)
                | objects.Leaf entity in the Design Pattern Composite. TPS modeler
                | enables definition of specification related to surfaces.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.annotation = com_object     

    @property
    def super_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SuperType
                | o Property SuperType(    ) As   (Read Only)
                | 
                | Get the Super Type.
                |

        :return:
        """
        return self.annotation.SuperType

    @property
    def tps_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TPSStatus
                | o Property TPSStatus(    ) As   (Read Only)
                | 
                | Get the TPS Status.
                |

        :return:
        """
        return self.annotation.TPSStatus

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Get the Type.
                |

        :return:
        """
        return self.annotation.Type

    @property
    def z(self, i_z):
        """
        .. note::
            CAA V5 Visual Basic help

                | Z
                | o Property Z(        iZ) (Write Only)
                | 
                | method get_Z will never be exposed Set the offset of the
                | annotation
                |

        :param i_z:
        :return:
        """
        return self.annotation.Z

    def add_leader(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddLeader
                | o Sub AddLeader(    )
                | 
                | Add a leader.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.AddLeader()

    def apply_referenced_geom_color(self, i_releated_r, i_releated_g, i_releated_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyReferencedGeomColor
                | o Sub ApplyReferencedGeomColor(        iReleatedR,
                |                                        iReleatedG,
                |                                        iReleatedB)
                | 
                | Apply a color to referenced geometry.
                |
                | Parameters:

                |
        :param i_releated_r:
        :param i_releated_g:
        :param i_releated_b:
        :return:
        """
        return self.annotation.ApplyReferencedGeomColor(i_releated_r, i_releated_g, i_releated_b)

    def apply_referenced_init_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyReferencedInitColor
                | o Sub ApplyReferencedInitColor(    )
                | 
                | Apply the initial color to referenced geometry.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ApplyReferencedInitColor()

    def associated_ref_frame(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AssociatedRefFrame
                | o Func AssociatedRefFrame(    ) As
                | 
                | Get the annotation on the AssociatedRefFrame interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.AssociatedRefFrame()

    def composite_tolerance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CompositeTolerance
                | o Func CompositeTolerance(    ) As
                | 
                | Get the annotation on the CompositeTolerance interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.CompositeTolerance()

    def controled_radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ControledRadius
                | o Func ControledRadius(    ) As
                | 
                | Get the annotation on the ControledRadius interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ControledRadius()

    def datum_simple(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DatumSimple
                | o Func DatumSimple(    ) As
                | 
                | Get the annotation on the DatumSimple interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.DatumSimple()

    def datum_target(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DatumTarget
                | o Func DatumTarget(    ) As
                | 
                | Get the annotation on the DatumTarget interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.DatumTarget()

    def default_annotation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DefaultAnnotation
                | o Func DefaultAnnotation(    ) As
                | 
                | Get the annotation on the DefaultAnnotation interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.DefaultAnnotation()

    def dimension_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Dimension3D
                | o Func Dimension3D(    ) As
                | 
                | Get the 3D Dimension on the 3D Dimension interface.
                |
                | Parameters:
                | oDim
                |    The 3D Dimension.

                |
        :return:
        """
        return self.annotation.Dimension3D()

    def dimension_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimensionLimit
                | o Func DimensionLimit(    ) As
                | 
                | Get the annotation on the DimensionLimit interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.DimensionLimit()

    def dimension_pattern(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimensionPattern
                | o Func DimensionPattern(    ) As
                | 
                | Get the annotation on the DimensionPattern interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.DimensionPattern()

    def envelop_condition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EnvelopCondition
                | o Func EnvelopCondition(    ) As
                | 
                | Get the annotation on the EnvelopCondition interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.EnvelopCondition()

    def flag_note(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FlagNote
                | o Func FlagNote(    ) As
                | 
                | Get the annotation on the FlagNote interface.
                |
                | Parameters:
                | oFlagNote
                |    The annotation Flag Note.

                |
        :return:
        """
        return self.annotation.FlagNote()

    def free_state(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FreeState
                | o Func FreeState(    ) As
                | 
                | Get the annotation on the FreeState interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.FreeState()

    def get_surfaces(self, o_safe_array):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSurfaces
                | o Sub GetSurfaces(        oSafeArray)
                | 
                | Get the geometry on which the Annotation is applied to.
                |
                | Parameters:

                |
        :param o_safe_array:
        :return:
        """
        return self.annotation.GetSurfaces(o_safe_array)

    def get_surfaces_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSurfacesCount
                | o Func GetSurfacesCount(    ) As
                | 
                | Count the geometry on which the Annotation is applied to.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.GetSurfacesCount()

    def has_a_controled_radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasAControledRadius
                | o Func HasAControledRadius(    ) As
                | 
                | To know if the Annotation has a Controled Radius.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.HasAControledRadius()

    def has_a_free_state(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasAFreeState
                | o Func HasAFreeState(    ) As
                | 
                | To know if the Annotation has a Free State.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.HasAFreeState()

    def has_a_material_condition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasAMaterialCondition
                | o Func HasAMaterialCondition(    ) As
                | 
                | To know if the Annotation has a Material Condition.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.HasAMaterialCondition()

    def has_a_particular_tol_elem(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasAParticularTolElem
                | o Func HasAParticularTolElem(    ) As
                | 
                | To know if the Annotation has a Particuler Element.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.HasAParticularTolElem()

    def has_a_tolerance_per_unit_basis_restrictive_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasATolerancePerUnitBasisRestrictiveValue
                | o Func HasATolerancePerUnitBasisRestrictiveValue(    ) As
                | 
                | To know if the Annotation has a Tolerance Per Unit Basis
                | Restricted Value.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.HasATolerancePerUnitBasisRestrictiveValue()

    def has_an_envelop_condition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasAnEnvelopCondition
                | o Func HasAnEnvelopCondition(    ) As
                | 
                | To know if the Annotation has an Envelop Condition.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.HasAnEnvelopCondition()

    def has_dimension_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HasDimensionLimit
                | o Func HasDimensionLimit(    ) As
                | 
                | To know if the Annotation has a Dimension Limit.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.HasDimensionLimit()

    def is_a_composite_tolerance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsACompositeTolerance
                | o Func IsACompositeTolerance(    ) As
                | 
                | To know if the Annotation is a composite Tolerance.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsACompositeTolerance()

    def is_a_default_annotation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsADefaultAnnotation
                | o Func IsADefaultAnnotation(    ) As
                | 
                | To know if the Annotation is a Default Annotation.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsADefaultAnnotation()

    def is_a_dimension_pattern(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsADimensionPattern
                | o Func IsADimensionPattern(    ) As
                | 
                | To know if the Annotation is a Dimension Pattern.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsADimensionPattern()

    def is_a_projected_tolerance_zone(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsAProjectedToleranceZone
                | o Func IsAProjectedToleranceZone(    ) As
                | 
                | To know if the Annotation is a Projected Zone.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsAProjectedToleranceZone()

    def is_a_shifted_profile_tolerance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsAShiftedProfileTolerance
                | o Func IsAShiftedProfileTolerance(    ) As
                | 
                | To know if the Annotation is a Shifted Profile Tolerance.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsAShiftedProfileTolerance()

    def is_a_tangent_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsATangentPlane
                | o Func IsATangentPlane(    ) As
                | 
                | To know if the Annotation is a Tangent Plane.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsATangentPlane()

    def is_a_tolerance_unit_basis_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsAToleranceUnitBasisValue
                | o Func IsAToleranceUnitBasisValue(    ) As
                | 
                | To know if the Annotation is a Tolerance Unit Basis Value.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsAToleranceUnitBasisValue()

    def is_a_tolerance_zone(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsAToleranceZone
                | o Func IsAToleranceZone(    ) As
                | 
                | Is the a Tolerance Zone.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsAToleranceZone()

    def is_an_associated_ref_frame(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsAnAssociatedRefFrame
                | o Func IsAnAssociatedRefFrame(    ) As
                | 
                | To know if the Annotation is an Associated Reference Frame.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.IsAnAssociatedRefFrame()

    def material_condition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MaterialCondition
                | o Func MaterialCondition(    ) As
                | 
                | Get the annotation on the MaterialCondition interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.MaterialCondition()

    def modify_visu(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ModifyVisu
                | o Sub ModifyVisu(    )
                | 
                | To refresh the 3D visualization.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ModifyVisu()

    def noa(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Noa
                | o Func Noa(    ) As
                | 
                | Get the annotation on the Noa interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.Noa()

    def particular_tol_elem(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ParticularTolElem
                | o Func ParticularTolElem(    ) As
                | 
                | Get the annotation on the ParticularTolElem interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ParticularTolElem()

    def projected_tolerance_zone(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProjectedToleranceZone
                | o Func ProjectedToleranceZone(    ) As
                | 
                | Get the annotation on the ProjectedToleranceZone interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ProjectedToleranceZone()

    def reference_frame(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReferenceFrame
                | o Func ReferenceFrame(    ) As
                | 
                | Get the annotation on the ReferenceFrame interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ReferenceFrame()

    def roughness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Roughness
                | o Func Roughness(    ) As
                | 
                | Get the annotation on the Roughness interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.Roughness()

    def set_xy(self, i_x, i_y):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetXY
                | o Sub SetXY(        iX,
                |                     iY)
                | 
                | method GetXY will never be exposed Set TPS coordinates in
                | the view
                |
                | Parameters:
                | oX
                |    The X coordinate.
                |  
                |  oY
                |    The Y coordinate.

                |
        :param i_x:
        :param i_y:
        :return:
        """
        return self.annotation.SetXY(i_x, i_y)

    def shifted_profile_tolerance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShiftedProfileTolerance
                | o Func ShiftedProfileTolerance(    ) As
                | 
                | Get the annotation on the ShiftedProfileTolerance interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ShiftedProfileTolerance()

    def tangent_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TangentPlane
                | o Func TangentPlane(    ) As
                | 
                | Get the annotation on the TangentPlane interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.TangentPlane()

    def text(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Text
                | o Func Text(    ) As
                | 
                | Get the annotation on the Text interface.
                |
                | Parameters:
                | oText
                |    The annotation Text.

                |
        :return:
        """
        return self.annotation.Text()

    def tolerance_per_unit_basis_restrictive_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TolerancePerUnitBasisRestrictiveValue
                | o Func TolerancePerUnitBasisRestrictiveValue(    ) As
                | 
                | Get the annotation on the
                | TolerancePerUnitBasisRestrictiveValue interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.TolerancePerUnitBasisRestrictiveValue()

    def tolerance_unit_basis_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ToleranceUnitBasisValue
                | o Func ToleranceUnitBasisValue(    ) As
                | 
                | Get the annotation on the ToleranceUnitBasisValue interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ToleranceUnitBasisValue()

    def tolerance_zone(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ToleranceZone
                | o Func ToleranceZone(    ) As
                | 
                | Get the annotation on the ToleranceZone interface.
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation.ToleranceZone()

    def transfert_to_view(self, i_view):
        """
        .. note::
            CAA V5 Visual Basic help

                | TransfertToView
                | o Sub TransfertToView(        iView)
                | 
                | Move the annotation in another view.
                |
                | Parameters:
                | iView
                |    The destination view.

                |
        :param i_view:
        :return:
        """
        return self.annotation.TransfertToView(i_view)

    def __repr__(self):
        return f'Annotation()'
