#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Dimension3D(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.dimension3_d = com_object     

    def get2d_annot(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Get2dAnnot
                | o Func Get2dAnnot(    ) As
                | 
                | Retrieves Drafting Dimension.
                |
                | Parameters:

                |
        :return:
        """
        return self.dimension3_d.Get2dAnnot()

    def move_value(self, x, y, sub_part, dim_angle_behavior):
        """
        .. note::
            CAA V5 Visual Basic help

                | MoveValue
                | o Sub MoveValue(        X,
                |                         Y,
                |                         SubPart,
                |                         DimAngleBehavior)
                | 
                | Moves the dimension value at a given point. Returns: HRESULT
                | error returned code If the modification of the vertical
                | offset value can not be performed because the parameter is
                | locked in the current standard, the method return HRESULT =
                | S_READ_ONLY.
                |
                | Parameters:
                | X
                |   Point abscissa on which the dimension value will be positionned.
                |  
                |  Y
                |   Point ordinate on which the dimension value will be positionned.
                |  
                |  SubPart
                |   Defines which part of the dimension should be moved 
                |    -1 = Value (vertical move is take account according ptPos coordinates)
                |     0 = Both dimension line and value
                |     1 = Value
                |     2 = Dimension line 
                |     3 = Secondary part
                |     4 = Secondary part and value
                |     5 = Secondary part and dimension line
                |     6 = Secondary part, dimension line and value
                |     7 = Value leader (for dimension line with leader one part or two parts)
                |  
                |  DimAngleBehavior
                |   Defines angle dimension line behavior.
                |     0 = Sector angle is switched when ptPos is in opposite sector (Default)
                |     1 =  Sector angle is kept what ever ptPos placement

                |                | Examples:
                | This example move dimension value MyDimension path.
                | MyDimension.MoveValue(X, Y, SubPart, DimAngleBehavior)

        :param x:
        :param y:
        :param sub_part:
        :param dim_angle_behavior:
        :return:
        """
        return self.dimension3_d.MoveValue(x, y, sub_part, dim_angle_behavior)

    def __repr__(self):
        return f'Dimension3D()'
