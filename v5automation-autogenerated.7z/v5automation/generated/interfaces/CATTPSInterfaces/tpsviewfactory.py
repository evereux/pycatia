#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class TPSViewFactory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the TPS view factory object.All the created views are added
                | to the annotation set object from which this  interface is retrieved,
                | thanks to theactivateLinkAnchor('AnnotationSet','TPSFactory','Annotati
                | onSet.TPSFactory')property.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.tps_view_factory = com_object     

    def create_view(self, i_plane, i_view_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateView
                | o Func CreateView(        iPlane,
                |                           iViewType) As
                | 
                | Creates a view.
                |
                | Parameters:
                | iPlane
                |    The plane onto which the view will be created
                |  
                |  iViewType
                |   The view type
                |   Legal values:
                |   
                | 1: Front View
                | 2: Section View
                | 3: Cut View

                |
        :param i_plane:
        :param i_view_type:
        :return:
        """
        return self.tps_view_factory.CreateView(i_plane, i_view_type)

    def __repr__(self):
        return f'TPSViewFactory()'
