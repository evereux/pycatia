#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AnnotationFactory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for the TPS Factory.This factory is implemented on the Set
                | object. All the created specifications are added to the Set from which
                | this  interface is retrieved.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.annotation_factory = com_object     

    def create_datum(self, i_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateDatum
                | o Func CreateDatum(        iSurf) As
                | 
                | Create a Datum Feature.
                |
                | Parameters:
                | iSurf
                |       User surface needed to construct the Datum Feature.
                |    
                |  oDatum
                |       The new created Datum Feature.

                |
        :param i_surf:
        :return:
        """
        return self.annotation_factory.CreateDatum(i_surf)

    def create_datum_reference_frame(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateDatumReferenceFrame
                | o Func CreateDatumReferenceFrame(    ) As
                | 
                | Create a Reference Frame (DRF). iType = 1 : Straightness 2 :
                | AxisStraightness 3 : Flatness 4 : Circularity 5 :
                | Cylindricity 6 : ProfileOfALine 7 : ProfileOfASurface 8 :
                | Position
                |
                | Parameters:

                |
        :return:
        """
        return self.annotation_factory.CreateDatumReferenceFrame()

    def create_datum_target(self, i_surf, i_datum):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateDatumTarget
                | o Func CreateDatumTarget(        iSurf,
                |                                  iDatum) As
                | 
                | Create a Datum Target.
                |
                | Parameters:
                | iSurf
                |       User surface needed to construct the Datum Target.
                |    
                |  iDatum
                |       Datume Feature that is in relatino with the Datum Target.
                |    
                |  oDatum
                |       The new created Datum Target.

                |
        :param i_surf:
        :param i_datum:
        :return:
        """
        return self.annotation_factory.CreateDatumTarget(i_surf, i_datum)

    def create_evoluate_datum(self, i_surf, i_x, i_y, i_z, i_with_leader):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateEvoluateDatum
                | o Func CreateEvoluateDatum(        iSurf,
                |                                    iX,
                |                                    iY,
                |                                    iZ,
                |                                    iWithLeader) As
                | 
                | Create a Datum Feature.
                |
                | Parameters:
                | iSurf
                |       User surface needed to construct the Datum Feature.
                |    
                |  iX
                |       X coordinate.
                |    
                |  iY
                |       Y coordinate.
                |    
                |  iZ
                |       Z coordinate.
                |    
                |  iWithLeader
                |       Create or not a leader on the annotation.
                |       If the leader is requested: The activated TPSView shall not be parallel to the surface pointed by the annotation Datum.
                |       If the activated TPSView is parallel to the surface pointed:
                |                      - The leader will be disconnected
                |                      - The extremity of the leader will be positioned at the origin of the part
                |                      - The annotation Datum is created but its status will be KO.
                |    
                |  oDatum
                |       The new created Datum Feature.

                |
        :param i_surf:
        :param i_x:
        :param i_y:
        :param i_z:
        :param i_with_leader:
        :return:
        """
        return self.annotation_factory.CreateEvoluateDatum(i_surf, i_x, i_y, i_z, i_with_leader)

    def create_evoluate_text(self, i_surf, i_x, i_y, i_z, i_with_leader):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateEvoluateText
                | o Func CreateEvoluateText(        iSurf,
                |                                   iX,
                |                                   iY,
                |                                   iZ,
                |                                   iWithLeader) As
                | 
                | Create a Text.
                |
                | Parameters:
                | iSurf
                |       User surface needed to construct the Text.
                |    
                |  iX
                |       X coordinate.
                |    
                |  iY
                |       Y coordinate.
                |    
                |  iZ
                |       Z coordinate.
                |    
                |  iWithLeader
                |       Create or not a leader on the annotation.
                |       If the leader is requested: The activated TPSView shall not be parallel to the surface pointed by the annotation Text.
                |       If the activated TPSView is parallel to the surface pointed:
                |                      - The leader will be disconnected
                |                      - The extremity of the leader will be positioned at the origin of the part
                |                      - The annotation Text is created but its status will be KO.
                |    
                |  oText
                |       The new created Text.

                |
        :param i_surf:
        :param i_x:
        :param i_y:
        :param i_z:
        :param i_with_leader:
        :return:
        """
        return self.annotation_factory.CreateEvoluateText(i_surf, i_x, i_y, i_z, i_with_leader)

    def create_flag_note(self, i_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateFlagNote
                | o Func CreateFlagNote(        iSurf) As
                | 
                | Create a FlagNote.
                |
                | Parameters:
                | iSurf
                |       User surface needed to construct the Flag Note.
                |    
                |  oFlagNote
                |       The new created Flag Note.

                |
        :param i_surf:
        :return:
        """
        return self.annotation_factory.CreateFlagNote(i_surf)

    def create_non_semantic_dimension(self, i_surf, i_dimension_type, i_linear_dim_sub_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateNonSemanticDimension
                | o Func CreateNonSemanticDimension(        iSurf,
                |                                           iDimensionType,
                |                                           iLinearDimSubType) As
                | 
                | Creates a non semantic Dimension specification.
                |
                | Parameters:
                | iSurf
                |       User surface needed to construct the Dimension.
                |   
                |  iDimensionType
                |       Type of the Dimension
                |                 0 : CATTPSUndefDimension
                |                 1 : CATTPSLinearDimension
                |                 2 : CATTPSAngularDimension
                |                 3 : CATTPSSecondLinearDim
                |                 4 : CATTPSChamferDimension
                |                 5 : CATTPSOrientedLinearDimension
                |                 6 : CATTPSOrientedAngularDimension
                |   
                |  iLinearDimSubType
                |       Sub type of LinearDimension type
                |                 0 : CATTPSDistanceDimension
                |                 1 : CATTPSDiameterDimension
                |                 2 : CATTPSRadiusDimension
                |                 3 : CATTPSThreadDimension
                |                 4 : CATTPSChamfDistDistDimension
                |                 5 : CATTPSChamfDistAngDimension
                |    
                |  oDimension
                |       The new created Dimension.

                |
        :param i_surf:
        :param i_dimension_type:
        :param i_linear_dim_sub_type:
        :return:
        """
        return self.annotation_factory.CreateNonSemanticDimension(i_surf, i_dimension_type, i_linear_dim_sub_type)

    def create_roughness(self, i_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateRoughness
                | o Func CreateRoughness(        iSurf) As
                | 
                | Create a Roughness.
                |
                | Parameters:
                | iSurf
                |       User surface needed to construct the Roughness.
                |    
                |  oRoughness
                |       The new created Roughness.

                |
        :param i_surf:
        :return:
        """
        return self.annotation_factory.CreateRoughness(i_surf)

    def create_semantic_dimension(self, i_surf, i_type, i_sub_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateSemanticDimension
                | o Func CreateSemanticDimension(        iSurf,
                |                                        iType,
                |                                        iSubType) As
                | 
                | Creates a semantic Dimension specification.
                |
                | Parameters:
                | oDimension
                |       The new created Dimension.

                |
        :param i_surf:
        :param i_type:
        :param i_sub_type:
        :return:
        """
        return self.annotation_factory.CreateSemanticDimension(i_surf, i_type, i_sub_type)

    def create_text(self, i_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateText
                | o Func CreateText(        iSurf) As
                | 
                | Create a Text.
                |
                | Parameters:
                | iAnnotation
                |       Annotation on which the Text will be .
                |    
                |  oText
                |       The new created Text.

                |
        :param i_surf:
        :return:
        """
        return self.annotation_factory.CreateText(i_surf)

    def create_text_noa(self, i_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateTextNOA
                | o Func CreateTextNOA(        iSurf) As
                | 
                | Create a "Text" NOA
                |
                | Parameters:
                | iSurf
                |       The user surface on which you apply the created NOA.
                |    
                |  oNoa
                |       The new created NOA.

                |
        :param i_surf:
        :return:
        """
        return self.annotation_factory.CreateTextNOA(i_surf)

    def create_text_on_annot(self, i_text, i_annot):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateTextOnAnnot
                | o Func CreateTextOnAnnot(        iText,
                |                                  iAnnot) As
                | 
                | Create a Text grouped to an annotation.
                |
                | Parameters:
                | iText
                |       Character string that makes up the text.
                |    
                |  iAnnot
                |       Annotation reference needed to group the Text.
                |    
                |  oText
                |       The new created Text.

                |
        :param i_text:
        :param i_annot:
        :return:
        """
        return self.annotation_factory.CreateTextOnAnnot(i_text, i_annot)

    def create_tolerance_with_drf(self, i_index, i_surf, i_drf):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateToleranceWithDRF
                | o Func CreateToleranceWithDRF(        iIndex,
                |                                       iSurf,
                |                                       iDRF) As
                | 
                | Create a Tolerance With a Reference Frame DRF. iType = 1 :
                | Angularity
                |
                | Parameters:

                |
        :param i_index:
        :param i_surf:
        :param i_drf:
        :return:
        """
        return self.annotation_factory.CreateToleranceWithDRF(i_index, i_surf, i_drf)

    def create_tolerance_without_drf(self, i_index, i_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateToleranceWithoutDRF
                | o Func CreateToleranceWithoutDRF(        iIndex,
                |                                          iSurf) As
                | 
                | Create a Tolerance Without a Reference Frame (DRF). iType =
                | 1 : Straightness 2 : AxisStraightness 3 : Flatness 4 :
                | Circularity 5 : Cylindricity 6 : ProfileOfALine 7 :
                | ProfileOfASurface 8 : Position
                |
                | Parameters:

                |
        :param i_index:
        :param i_surf:
        :return:
        """
        return self.annotation_factory.CreateToleranceWithoutDRF(i_index, i_surf)

    def instanciate_noa(self, i_noa, i_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | InstanciateNOA
                | o Func InstanciateNOA(        iNoa,
                |                               iSurf) As
                | 
                | Instanciate an NOA from a Reference NOA.
                |
                | Parameters:
                | iNOA
                |       Reference NOA.
                |    
                |  iSurf
                |       User surface needed to construct the Dimension.
                |    
                |  oNOA
                |       The new instanciated NOA.

                |
        :param i_noa:
        :param i_surf:
        :return:
        """
        return self.annotation_factory.InstanciateNOA(i_noa, i_surf)

    def __repr__(self):
        return f'AnnotationFactory()'
