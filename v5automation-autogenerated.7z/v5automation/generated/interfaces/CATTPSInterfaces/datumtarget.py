#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DatumTarget(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for Datum Target TPS (datum entity).TPS for Technological
                | Product Specifications.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.datum_target = com_object     

    @property
    def datum(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Datum
                | o Property Datum(    ) As   (Read Only)
                | 
                | Retrieves simple datum, the target belongs to.
                |

        :return:
        """
        return self.datum_target.Datum

    @property
    def label(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Label
                | o Property Label(    ) As   (Read Only)
                | 
                | Retrieves Label.
                |

        :return:
        """
        return self.datum_target.Label

    def __repr__(self):
        return f'DatumTarget()'
