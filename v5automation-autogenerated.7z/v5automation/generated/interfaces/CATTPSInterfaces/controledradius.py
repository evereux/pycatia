#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ControledRadius(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for accessing Controled Radius modifier on a linear TPS
                | (ASME norm only).This interface is exposed only by radius linear TPS.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.controled_radius = com_object     

    @property
    def modifier(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Modifier
                | o Property Modifier(    ) As   (Read Only)
                | 
                | Retrieves Controled Radius modifier.
                |

        :return:
        """
        return self.controled_radius.Modifier

    def __repr__(self):
        return f'ControledRadius()'
