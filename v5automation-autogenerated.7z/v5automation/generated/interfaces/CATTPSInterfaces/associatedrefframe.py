#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AssociatedRefFrame(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface dedicated to manage Datum Reference Frame associated to a
                | TPS.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.associated_ref_frame = com_object     

    @property
    def reference_frame(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReferenceFrame
                | o Property ReferenceFrame(    ) As   (Read Only)
                | 
                | Retrieves the Datum Reference Frame associated to a TPS.
                |

        :return:
        """
        return self.associated_ref_frame.ReferenceFrame

    def __repr__(self):
        return f'AssociatedRefFrame()'
