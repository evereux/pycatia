#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DefaultAnnotation(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | This interface is used to get information about default
                | annotation.Ther is two kinds of default annotation :  - with a manual
                | selection  - with a selection automatic

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.default_annotation = com_object     

    @property
    def link_wi_geom_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LinkWiGeomType
                | o Property LinkWiGeomType(    ) As   (Read Only)
                | 
                | Get the type of link between the default annotation and the
                | geometry. Return E_FAIL if the annotation is not a default
                | one.
                |

        :return:
        """
        return self.default_annotation.LinkWiGeomType

    @property
    def search_algo_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SearchAlgoType
                | o Property SearchAlgoType(    ) As   (Read Only)
                | 
                | Get the type of search algo to find geometry on which the
                | annotation apply to. Return E_FAIL if the annotation is not
                | a default one.
                |

        :return:
        """
        return self.default_annotation.SearchAlgoType

    def is_in_automatic_search_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsInAutomaticSearchMode
                | o Func IsInAutomaticSearchMode(    ) As
                | 
                | Get the type of search algo Return E_FAIL if the annotation
                | is not a default one.
                |
                | Parameters:
                | oIsAutoMode
                |      oIsAutoMode = TRUE if Automatic mode

                |
        :return:
        """
        return self.default_annotation.IsInAutomaticSearchMode()

    def __repr__(self):
        return f'DefaultAnnotation()'
