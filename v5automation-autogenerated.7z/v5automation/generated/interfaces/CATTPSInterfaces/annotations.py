#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Annotations(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for collection of TPS objects CATIAAnnotation.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.annotations = com_object     

    def add(self, i_annot):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Sub Add(        iAnnot)
                | 
                | Add an Annotation.
                |
                | Parameters:

                |
        :param i_annot:
        :return:
        """
        return self.annotations.Add(i_annot)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Retrieve an Annotation.
                |
                | Parameters:

                |
        :param i_index:
        :return:
        """
        return self.annotations.Item(i_index)

    def __repr__(self):
        return f'Annotations()'
