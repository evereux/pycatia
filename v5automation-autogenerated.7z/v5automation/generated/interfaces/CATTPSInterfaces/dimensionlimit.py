#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DimensionLimit(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the limit object of tolerance dimensions.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.dimension_limit = com_object     

    @property
    def dimension_limit_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimensionLimitType
                | o Property DimensionLimitType(    ) As
                | 
                | Returns or sets the dimension limit type. Legal values:
                | Valid dimension limit type values are: CATTPSDLNotDefined
                | CATTPSDLNumerical CATTPSDLTabulated CATTPSDLSingleLimit
                |

        :return:
        """
        return self.dimension_limit.DimensionLimitType

    @dimension_limit_type.setter
    def dimension_limit_type(self, value):
        """
            :param type value:
        """
        self.dimension_limit.DimensionLimitType = value 

    @property
    def modifier(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Modifier
                | o Property Modifier(    ) As
                | 
                | Returns or sets the dimension single limit modifier.
                |

        :return:
        """
        return self.dimension_limit.Modifier

    @modifier.setter
    def modifier(self, value):
        """
            :param type value:
        """
        self.dimension_limit.Modifier = value 

    @property
    def nominalvalue(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Nominalvalue
                | o Property Nominalvalue(    ) As   (Read Only)
                | 
                | Returns the dimension limit nominal value. This value is
                | expressed in millimeters.
                |

        :return:
        """
        return self.dimension_limit.Nominalvalue

    @property
    def symetric_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SymetricValue
                | o Property SymetricValue(    ) As
                | 
                | Returns or sets whether the dimension limit is symmetric.
                | TRUE if it is symmetric.
                |

        :return:
        """
        return self.dimension_limit.SymetricValue

    @symetric_value.setter
    def symetric_value(self, value):
        """
            :param type value:
        """
        self.dimension_limit.SymetricValue = value 

    @property
    def tabulated_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TabulatedLimit
                | o Property TabulatedLimit(    ) As
                | 
                | Returns or sets the dimension tabulated limit. This
                | tabulated limit is expressed as a string.
                |

        :return:
        """
        return self.dimension_limit.TabulatedLimit

    @tabulated_limit.setter
    def tabulated_limit(self, value):
        """
            :param type value:
        """
        self.dimension_limit.TabulatedLimit = value 

    def limits(self, o_bottom, o_up):
        """
        .. note::
            CAA V5 Visual Basic help

                | Limits
                | o Sub Limits(        oBottom,
                |                      oUp)
                | 
                | Retrieves dimension limit values. These values are expressed
                | in millimeters.
                |
                | Parameters:
                | oBottom
                |    The dimension limit bottom value
                |  
                |  oUp
                |    The dimension limit up value

                |
        :param o_bottom:
        :param o_up:
        :return:
        """
        return self.dimension_limit.Limits(o_bottom, o_up)

    def put_limits(self, i_bottom, i_up):
        """
        .. note::
            CAA V5 Visual Basic help

                | PutLimits
                | o Sub PutLimits(        iBottom,
                |                         iUp)
                | 
                | Sets dimension limit values. These values are expressed in
                | millimeters.
                |
                | Parameters:
                | iBottom
                |    The dimension limit bottom value
                |  
                |  iUp
                |    The dimension limit up value

                |
        :param i_bottom:
        :param i_up:
        :return:
        """
        return self.dimension_limit.PutLimits(i_bottom, i_up)

    def __repr__(self):
        return f'DimensionLimit()'
