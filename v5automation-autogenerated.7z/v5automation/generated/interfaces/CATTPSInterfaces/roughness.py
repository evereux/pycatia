#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Roughness(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to manage Roughness TPS.TPS for Technological Product
                | Specifications.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.roughness = com_object     

    @property
    def applicability(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Applicability
                | o Property Applicability(    ) As
                | 
                | Retrieves or sets roughness applicability.
                |

        :return:
        """
        return self.roughness.Applicability

    @property
    def obtention(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Obtention
                | o Property Obtention(    ) As
                | 
                | Retrieves or sets roughness obtention mode.
                |

        :return:
        """
        return self.roughness.Obtention

    def field(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Field
                | o Func Field(        iIndex) As
                | 
                | Retrieves roughness field. Field 4 Field 1
                | ------------------ / (Field 9) Field 2 / / (Field 8) Field 5
                | \ / Field 3 \ / Field 7 Field 6 Pour le champs 7 les lettres
                | autorisees sont : M, C, R, P, X, = ,L (symbole
                | perpendicularite de la DSES)
                |
                | Parameters:
                | iIndex
                |      Field index, from 1 to 9 from V5R13 (Fields 8 and 9 added).
                |                   from 1 to 7 before V5R13
                |    
                |  oField
                |      The contain of the iIndex field.

                |
        :param i_index:
        :return:
        """
        return self.roughness.Field(i_index)

    def set_field(self, i_index, i_field):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetField
                | o Sub SetField(        iIndex,
                |                        iField)
                | 
                | Set roughness field. Field 4 Field 1 ------------------ /
                | (Field 9) Field 2 / / (Field 8) Field 5 \ / Field 3 \ /
                | Field 7 Field 6 Pour le champs 7 les lettres autorisees sont
                | : M, C, R, P, X, = ,L (symbole perpendicularite de la DSES)
                |
                | Parameters:
                | iIndex
                |      Field index, from 1 to 9 from V5R13 (Fields 8 and 9 added).
                |                   from 1 to 7 before V5R13
                |    
                |  iField
                |      The contain of the iIndex field.

                |
        :param i_index:
        :param i_field:
        :return:
        """
        return self.roughness.SetField(i_index, i_field)

    def __repr__(self):
        return f'Roughness()'
