#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ReferenceFrame(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface designed to manage reference frame associated to a
                | TPS.Reference frame is composed of three boxes.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.reference_frame = com_object     

    @property
    def all_datums_simple(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AllDatumsSimple
                | o Property AllDatumsSimple(    ) As   (Read Only)
                | 
                | Retrieves all datums simple used in Reference Frame.
                |

        :return:
        """
        return self.reference_frame.AllDatumsSimple

    def frame(self, o_first_box, o_second_box, o_third_box):
        """
        .. note::
            CAA V5 Visual Basic help

                | Frame
                | o Sub Frame(        oFirstBox,
                |                     oSecondBox,
                |                     oThirdBox)
                | 
                | Retrieves Frame of the TPS.
                |
                | Parameters:
                | oFirstBox
                |       
                |      oSecondBox
                |       
                |      oThirdBox
                |         Texts in first, second and third boxes.

                |
        :param o_first_box:
        :param o_second_box:
        :param o_third_box:
        :return:
        """
        return self.reference_frame.Frame(o_first_box, o_second_box, o_third_box)

    def get_axis_system_ttrs(self, op_axis_system_ttrs):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAxisSystemTTRS
                | o Sub GetAxisSystemTTRS(        opAxisSystemTTRS)
                | 
                | Gets the AxisSystem TTRS.
                |
                | Parameters:
                | opAxisSystemTTRS
                |       AxisSystem TTRS
                |   
                | 
                |    Returns: 
                |     HRESULT   S_OK:- the Axis System has been correctly retrieved.
                |    E_FAIL or E_NOIMPL : Axis System cannot be retrieved.

                |
        :param op_axis_system_ttrs:
        :return:
        """
        return self.reference_frame.GetAxisSystemTTRS(op_axis_system_ttrs)

    def get_degrees_of_freedom(self, in_box, o_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDegreesOfFreedom
                | o Sub GetDegreesOfFreedom(        inBox,
                |                                   oValue)
                | 
                | Retrieves the values of Degrees Of Freedom(DOF)
                | [x,y,z,u,v,w]. Is only defined when "Axis System" attribute
                | is valued. Only for ASME 2009 (does not exist in ISO).
                |
                | Parameters:
                | inBox
                |       First, Second or the Third Box of the DRF on which
                |    the Degrees Of Freedom is to be retrieved.
                |   
                |      oValue
                |       oValue begins with the symbol :[ and ends by the symbol ].
                |    and between these symbols [..], value are a a combination of
                |    following legal values:
                |    x,
                |    y,
                |    z,
                |    u,
                |    v,
                |    w
                |   
                | 
                |    Returns: 
                |     HRESULT    S_OK : the Degrees Of Freedom has been correctly retrieved.
                |     E_FAIL or E_NOIMPL : the Degrees Of Freedom cannot be retrieved.

                |
        :param in_box:
        :param o_value:
        :return:
        """
        return self.reference_frame.GetDegreesOfFreedom(in_box, o_value)

    def set_axis_system_ttrs(self, ip_axis_system_ttrs):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAxisSystemTTRS
                | o Sub SetAxisSystemTTRS(        ipAxisSystemTTRS)
                | 
                | Sets the AxisSystem TTRS.
                |
                | Parameters:
                | ipAxisSystemTTRS
                |       AxisSystem TTRS. If it is NULL, the AxisSystem TTRS in the model
                |    will be removed.
                |   
                | 
                |    Returns: 
                |     HRESULT   S_OK:- the Axis System has been correctly set.
                |    E_FAIL or E_NOIMPL : Axis System cannot be set.

                |
        :param ip_axis_system_ttrs:
        :return:
        """
        return self.reference_frame.SetAxisSystemTTRS(ip_axis_system_ttrs)

    def set_degrees_of_freedom(self, in_box, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDegreesOfFreedom
                | o Sub SetDegreesOfFreedom(        inBox,
                |                                   iValue)
                | 
                | Sets the values of Degrees Of Freedom(DOF) [x,y,z,u,v,w]. Is
                | only defined when "Axis System" attribute is valued. Only
                | for ASME 2009 (does not exist in ISO).
                |
                | Parameters:
                | inBox
                |       First, Second or the Third Box of the DRF on which
                |    the Degrees Of Freedom is to be set.
                |   
                |      iValue
                |       iValue must begin by the symbol :[ and must end by the symbol ].
                |    and between these symbols [..], value must be a combination of
                |    following legal values:
                |    x,
                |    y,
                |    z,
                |    u,
                |    v,
                |    w
                |    E.G.1:- To set [x,z] as the DOF:-
                |                   iValue = [x,z];
                |    E.G.2:- To set [y] as the DOF:-
                |                   iValue = [y];
                |   
                | 
                |    Returns: 
                |     HRESULT    S_OK : the Degrees Of Freedom has been correctly set.
                |     E_FAIL or E_NOIMPL : the Degrees Of Freedom cannot be set.

                |
        :param in_box:
        :param i_value:
        :return:
        """
        return self.reference_frame.SetDegreesOfFreedom(in_box, i_value)

    def set_frame(self, i_first_box, i_second_box, i_third_box):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFrame
                | o Sub SetFrame(        iFirstBox,
                |                        iSecondBox,
                |                        iThirdBox)
                | 
                | Set Frame of the TPS.
                |
                | Parameters:
                | oFirstBox
                |       
                |      oSecondBox
                |       
                |      oThirdBox
                |         Texts in first, second and third boxes.

                |
        :param i_first_box:
        :param i_second_box:
        :param i_third_box:
        :return:
        """
        return self.reference_frame.SetFrame(i_first_box, i_second_box, i_third_box)

    def __repr__(self):
        return f'ReferenceFrame()'
