#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class FTASettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAFTASettingAtt.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.fta_setting_att = com_object     

    @property
    def alphabetic_order(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AlphabeticOrder
                | o Property AlphabeticOrder(    ) As
                | 
                | Returns or sets the AlphabeticOrder setting parameter value.
                | True if the AlphabeticOrder setting parameter is checked.
                | Role: When set to True, the FTA 3D Annotation
                | representations are saved in CGR. Otherwise, they are not
                | saved.
                |

        :return:
        """
        return self.fta_setting_att.AlphabeticOrder

    @alphabetic_order.setter
    def alphabetic_order(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.AlphabeticOrder = value 

    @property
    def analysis_display_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnalysisDisplayMode
                | o Property AnalysisDisplayMode(    ) As
                | 
                | Returns the AnalysisDisplayMode parameter.
                |

        :return:
        """
        return self.fta_setting_att.AnalysisDisplayMode

    @property
    def angulaire_general_tol_class(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AngulaireGeneralTolClass
                | o Property AngulaireGeneralTolClass(    ) As
                | 
                | Returns or sets the Dimension general class parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.AngulaireGeneralTolClass

    @angulaire_general_tol_class.setter
    def angulaire_general_tol_class(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.AngulaireGeneralTolClass = value 

    @property
    def annot_dim_invalid(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnnotDimInvalid
                | o Property AnnotDimInvalid(    ) As
                | 
                | Returns the AnnotDimInvalid parameter.
                |

        :return:
        """
        return self.fta_setting_att.AnnotDimInvalid

    @property
    def annot_dim_on_deleted_geom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnnotDimOnDeletedGeom
                | o Property AnnotDimOnDeletedGeom(    ) As
                | 
                | Returns the AnnotDimOnDeletedGeom parameter.
                |

        :return:
        """
        return self.fta_setting_att.AnnotDimOnDeletedGeom

    @property
    def annot_dim_on_unloaded_geom(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnnotDimOnUnloadedGeom
                | o Property AnnotDimOnUnloadedGeom(    ) As
                | 
                | Returns the AnnotDimOnUnloadedGeom parameter.
                |

        :return:
        """
        return self.fta_setting_att.AnnotDimOnUnloadedGeom

    @property
    def annot_on_zero_z_setting(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnnotOnZeroZSetting
                | o Property AnnotOnZeroZSetting(    ) As
                | 
                | Returns the AnnotOnZeroZSetting parameter.
                |

        :return:
        """
        return self.fta_setting_att.AnnotOnZeroZSetting

    @property
    def body_hide_in_capture(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BodyHideInCapture
                | o Property BodyHideInCapture(    ) As
                | 
                | Returns or sets the Visibility of Part instances, bodies and
                | geometrical sets in Capture. Ensure consistency with the C++
                | interface to which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.BodyHideInCapture

    @body_hide_in_capture.setter
    def body_hide_in_capture(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.BodyHideInCapture = value 

    @property
    def catfta_chamfer_general_tol_class(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CATFTAChamferGeneralTolClass
                | o Property CATFTAChamferGeneralTolClass(    ) As
                | 
                | Returns the CATFTAChamferGeneralTolClass parameter.
                |

        :return:
        """
        return self.fta_setting_att.CATFTAChamferGeneralTolClass

    @property
    def catfta_edges_line_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CATFTAEdgesLineType
                | o Property CATFTAEdgesLineType(    ) As
                | 
                | Returns the CATFTAEdgesLineType parameter.
                |

        :return:
        """
        return self.fta_setting_att.CATFTAEdgesLineType

    @property
    def catfta_edges_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CATFTAEdgesThickness
                | o Property CATFTAEdgesThickness(    ) As
                | 
                | Returns the CATFTAEdgesThickness parameter.
                |

        :return:
        """
        return self.fta_setting_att.CATFTAEdgesThickness

    @property
    def catftauf_auto_tolerancing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CATFTAUFAutoTolerancing
                | o Property CATFTAUFAutoTolerancing(    ) As
                | 
                | Returns the CATFTAUFAutoTolerancing parameter.
                |

        :return:
        """
        return self.fta_setting_att.CATFTAUFAutoTolerancing

    @property
    def catfta_use_last_tolerances(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CATFTAUseLastTolerances
                | o Property CATFTAUseLastTolerances(    ) As
                | 
                | Returns the CATFTAUseLastTolerances parameter.
                |

        :return:
        """
        return self.fta_setting_att.CATFTAUseLastTolerances

    @property
    def dim_after_cre(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimAfterCre
                | o Property DimAfterCre(    ) As
                | 
                | Returns or sets the Dimension After Creaation parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimAfterCre

    @dim_after_cre.setter
    def dim_after_cre(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimAfterCre = value 

    @property
    def dim_after_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimAfterMod
                | o Property DimAfterMod(    ) As
                | 
                | Returns or sets the Dimension After Modification parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimAfterMod

    @dim_after_mod.setter
    def dim_after_mod(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimAfterMod = value 

    @property
    def dim_before_cre(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimBeforeCre
                | o Property DimBeforeCre(    ) As
                | 
                | Returns or sets the Dimension Before Creation parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimBeforeCre

    @dim_before_cre.setter
    def dim_before_cre(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimBeforeCre = value 

    @property
    def dim_before_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimBeforeMod
                | o Property DimBeforeMod(    ) As
                | 
                | Returns or sets the Dimension Before Modification parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimBeforeMod

    @dim_before_mod.setter
    def dim_before_mod(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimBeforeMod = value 

    @property
    def dim_blanking_cre(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimBlankingCre
                | o Property DimBlankingCre(    ) As
                | 
                | Returns or sets the Dimension Blanking Creation parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimBlankingCre

    @dim_blanking_cre.setter
    def dim_blanking_cre(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimBlankingCre = value 

    @property
    def dim_blanking_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimBlankingMod
                | o Property DimBlankingMod(    ) As
                | 
                | Returns or sets the Dimension Blanking Modification
                | parameter. Ensure consistency with the C++ interface to
                | which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimBlankingMod

    @dim_blanking_mod.setter
    def dim_blanking_mod(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimBlankingMod = value 

    @property
    def dim_configure_snapping(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimConfigureSnapping
                | o Property DimConfigureSnapping(    ) As
                | 
                | Returns or sets the DimConfigureSnapping parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimConfigureSnapping

    @dim_configure_snapping.setter
    def dim_configure_snapping(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimConfigureSnapping = value 

    @property
    def dim_constant_offset(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimConstantOffset
                | o Property DimConstantOffset(    ) As
                | 
                | Returns or sets the Constant Offset parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimConstantOffset

    @dim_constant_offset.setter
    def dim_constant_offset(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimConstantOffset = value 

    @property
    def dim_create_on(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimCreateOn
                | o Property DimCreateOn(    ) As
                | 
                | Returns or sets the DimCreateOn parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimCreateOn

    @dim_create_on.setter
    def dim_create_on(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimCreateOn = value 

    @property
    def dim_line_pos_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLinePosValue
                | o Property DimLinePosValue(    ) As
                | 
                | Returns or sets the Dimension Line Position Value parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimLinePosValue

    @dim_line_pos_value.setter
    def dim_line_pos_value(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimLinePosValue = value 

    @property
    def dim_line_up_base_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpBaseAngle
                | o Property DimLineUpBaseAngle(    ) As
                | 
                | Returns or sets the Dimension Line Up Base Angle parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpBaseAngle

    @dim_line_up_base_angle.setter
    def dim_line_up_base_angle(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimLineUpBaseAngle = value 

    @property
    def dim_line_up_base_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpBaseLength
                | o Property DimLineUpBaseLength(    ) As
                | 
                | Returns or sets the Dimension Line Up Base Length parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpBaseLength

    @dim_line_up_base_length.setter
    def dim_line_up_base_length(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimLineUpBaseLength = value 

    @property
    def dim_line_up_cumul(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpCumul
                | o Property DimLineUpCumul(    ) As
                | 
                | Returns or sets the Dimension Line Up Cululated parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpCumul

    @dim_line_up_cumul.setter
    def dim_line_up_cumul(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimLineUpCumul = value 

    @property
    def dim_line_up_funnel(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpFunnel
                | o Property DimLineUpFunnel(    ) As
                | 
                | Returns or sets the Dimension Line Up Funnel parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpFunnel

    @dim_line_up_funnel.setter
    def dim_line_up_funnel(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimLineUpFunnel = value 

    @property
    def dim_line_up_offset_bet_dim_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpOffsetBetDimAngle
                | o Property DimLineUpOffsetBetDimAngle(    ) As
                | 
                | Returns gets the DimLineUpOffsetBetDimAngle parameter.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpOffsetBetDimAngle

    @property
    def dim_line_up_offset_bet_dim_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpOffsetBetDimLength
                | o Property DimLineUpOffsetBetDimLength(    ) As
                | 
                | Returns gets the DimLineUpOffsetBetDimLength parameter.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpOffsetBetDimLength

    @property
    def dim_line_up_offset_to_ref_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpOffsetToRefAngle
                | o Property DimLineUpOffsetToRefAngle(    ) As
                | 
                | Returns gets the DimLineUpOffsetToRefAngle parameter.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpOffsetToRefAngle

    @property
    def dim_line_up_offset_to_ref_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpOffsetToRefLength
                | o Property DimLineUpOffsetToRefLength(    ) As
                | 
                | Returns gets the DimLineUpOffsetToRefLength parameter.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpOffsetToRefLength

    @property
    def dim_line_up_stack(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimLineUpStack
                | o Property DimLineUpStack(    ) As
                | 
                | Returns or sets the Dimension Line Up Stack parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimLineUpStack

    @dim_line_up_stack.setter
    def dim_line_up_stack(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimLineUpStack = value 

    @property
    def dim_manual_positionning(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimManualPositionning
                | o Property DimManualPositionning(    ) As
                | 
                | Returns or sets the Manual Positionning parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimManualPositionning

    @dim_manual_positionning.setter
    def dim_manual_positionning(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimManualPositionning = value 

    @property
    def dim_move2d_part_cre(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMove2dPartCre
                | o Property DimMove2dPartCre(    ) As
                | 
                | Returns or sets the Dimension Move 2D Creation parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimMove2dPartCre

    @dim_move2d_part_cre.setter
    def dim_move2d_part_cre(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimMove2dPartCre = value 

    @property
    def dim_move2d_part_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMove2dPartMod
                | o Property DimMove2dPartMod(    ) As
                | 
                | Returns or sets the Dimension Move 2D Modification
                | parameter. Ensure consistency with the C++ interface to
                | which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimMove2dPartMod

    @dim_move2d_part_mod.setter
    def dim_move2d_part_mod(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimMove2dPartMod = value 

    @property
    def dim_move_dim_line_cre(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMoveDimLineCre
                | o Property DimMoveDimLineCre(    ) As
                | 
                | Returns or sets the Dimension Move Dimension Line Creation
                | parameter. Ensure consistency with the C++ interface to
                | which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimMoveDimLineCre

    @dim_move_dim_line_cre.setter
    def dim_move_dim_line_cre(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimMoveDimLineCre = value 

    @property
    def dim_move_dim_line_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMoveDimLineMod
                | o Property DimMoveDimLineMod(    ) As
                | 
                | Returns or sets the Dimension Move Dimension Line
                | Modification parameter. Ensure consistency with the C++
                | interface to which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimMoveDimLineMod

    @dim_move_dim_line_mod.setter
    def dim_move_dim_line_mod(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimMoveDimLineMod = value 

    @property
    def dim_move_leader_cre(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMoveLeaderCre
                | o Property DimMoveLeaderCre(    ) As
                | 
                | Get the Dimension leader Creation parameter.
                |

        :return:
        """
        return self.fta_setting_att.DimMoveLeaderCre

    @property
    def dim_move_leader_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMoveLeaderMod
                | o Property DimMoveLeaderMod(    ) As
                | 
                | Returns gets the Dimension leader modification parameter.
                |

        :return:
        """
        return self.fta_setting_att.DimMoveLeaderMod

    @property
    def dim_move_sub_part(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMoveSubPart
                | o Property DimMoveSubPart(    ) As
                | 
                | Returns or sets the DimMoveSubPart parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimMoveSubPart

    @dim_move_sub_part.setter
    def dim_move_sub_part(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimMoveSubPart = value 

    @property
    def dim_move_value_cre(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMoveValueCre
                | o Property DimMoveValueCre(    ) As
                | 
                | Returns or sets the Dimension Move Value Creation parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimMoveValueCre

    @dim_move_value_cre.setter
    def dim_move_value_cre(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimMoveValueCre = value 

    @property
    def dim_move_value_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimMoveValueMod
                | o Property DimMoveValueMod(    ) As
                | 
                | Returns or sets the Dimension Move Value Modification
                | parameter. Ensure consistency with the C++ interface to
                | which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimMoveValueMod

    @dim_move_value_mod.setter
    def dim_move_value_mod(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimMoveValueMod = value 

    @property
    def dim_o_run_cre(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimORunCre
                | o Property DimORunCre(    ) As
                | 
                | Returns or sets the Dimension Over Run Creation parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimORunCre

    @dim_o_run_cre.setter
    def dim_o_run_cre(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimORunCre = value 

    @property
    def dim_o_run_mod(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimORunMod
                | o Property DimORunMod(    ) As
                | 
                | Returns or sets the Dimension Over Run Modification
                | parameter. Ensure consistency with the C++ interface to
                | which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimORunMod

    @dim_o_run_mod.setter
    def dim_o_run_mod(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimORunMod = value 

    @property
    def dim_ori_default_symb(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimOriDefaultSymb
                | o Property DimOriDefaultSymb(    ) As
                | 
                | Returns or sets the Dimension Orientation Default Symbol
                | parameter. Ensure consistency with the C++ interface to
                | which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimOriDefaultSymb

    @dim_ori_default_symb.setter
    def dim_ori_default_symb(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimOriDefaultSymb = value 

    @property
    def dim_snapping(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DimSnapping
                | o Property DimSnapping(    ) As
                | 
                | Returns or sets the Dimension Snapping parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.DimSnapping

    @dim_snapping.setter
    def dim_snapping(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.DimSnapping = value 

    @property
    def general_tol_class(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GeneralTolClass
                | o Property GeneralTolClass(    ) As
                | 
                | Returns or sets the Dimension general class parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.GeneralTolClass

    @general_tol_class.setter
    def general_tol_class(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.GeneralTolClass = value 

    @property
    def highlight_def_annot(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HighlightDefAnnot
                | o Property HighlightDefAnnot(    ) As
                | 
                | Returns or sets the Highlight Def Annot parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.HighlightDefAnnot

    @highlight_def_annot.setter
    def highlight_def_annot(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.HighlightDefAnnot = value 

    @property
    def noa_creation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NoaCreation
                | o Property NoaCreation(    ) As
                | 
                | Returns or sets the Noa Creation parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.NoaCreation

    @noa_creation.setter
    def noa_creation(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.NoaCreation = value 

    @property
    def non_semantic_allways_upgrade(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NonSemanticAllwaysUpgrade
                | o Property NonSemanticAllwaysUpgrade(    ) As
                | 
                | Returns or sets the Non SemanticAllways Upgrade parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.NonSemanticAllwaysUpgrade

    @non_semantic_allways_upgrade.setter
    def non_semantic_allways_upgrade(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.NonSemanticAllwaysUpgrade = value 

    @property
    def non_semantic_allways_upgrade_general_tol(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NonSemanticAllwaysUpgradeGeneralTol
                | o Property NonSemanticAllwaysUpgradeGeneralTol(    ) As
                | 
                | Returns or sets the Non SemanticAllways Upgrade general
                | tolerance parameter. Ensure consistency with the C++
                | interface to which the work is delegated.
                |

        :return:
        """
        return self.fta_setting_att.NonSemanticAllwaysUpgradeGeneralTol

    @non_semantic_allways_upgrade_general_tol.setter
    def non_semantic_allways_upgrade_general_tol(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.NonSemanticAllwaysUpgradeGeneralTol = value 

    @property
    def non_semantic_dim_allowed(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NonSemanticDimAllowed
                | o Property NonSemanticDimAllowed(    ) As
                | 
                | Returns or sets the Non Semantic Dim Allowed parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.NonSemanticDimAllowed

    @non_semantic_dim_allowed.setter
    def non_semantic_dim_allowed(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.NonSemanticDimAllowed = value 

    @property
    def non_semantic_marked(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NonSemanticMarked
                | o Property NonSemanticMarked(    ) As
                | 
                | Returns or sets the Non Semantic Marked parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.NonSemanticMarked

    @non_semantic_marked.setter
    def non_semantic_marked(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.NonSemanticMarked = value 

    @property
    def non_semantic_tol_allowed(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NonSemanticTolAllowed
                | o Property NonSemanticTolAllowed(    ) As
                | 
                | Returns or sets the Non Semantic Tol Allowed parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.NonSemanticTolAllowed

    @non_semantic_tol_allowed.setter
    def non_semantic_tol_allowed(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.NonSemanticTolAllowed = value 

    @property
    def parameters_in_tree(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ParametersInTree
                | o Property ParametersInTree(    ) As
                | 
                | Returns or sets the Parameters in tree parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.ParametersInTree

    @parameters_in_tree.setter
    def parameters_in_tree(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.ParametersInTree = value 

    @property
    def rotation_snap_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RotationSnapAngle
                | o Property RotationSnapAngle(    ) As
                | 
                | Returns or sets the Rotation Snap Angle parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.RotationSnapAngle

    @rotation_snap_angle.setter
    def rotation_snap_angle(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.RotationSnapAngle = value 

    @property
    def rotation_snap_auto(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RotationSnapAuto
                | o Property RotationSnapAuto(    ) As
                | 
                | Returns or sets the Rotation Snap Auto parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.RotationSnapAuto

    @rotation_snap_auto.setter
    def rotation_snap_auto(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.RotationSnapAuto = value 

    @property
    def sect_pattern(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectPattern
                | o Property SectPattern(    ) As
                | 
                | Returns or sets the Pattern of Visu setting parameter value.
                | True if the Pattern of Visu setting parameter is checked.
                | Role: When set to True, the FTA 3D Annotation
                | representations are saved in CGR. Otherwise, they are not
                | saved.
                |

        :return:
        """
        return self.fta_setting_att.SectPattern

    @sect_pattern.setter
    def sect_pattern(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.SectPattern = value 

    @property
    def select_published_geometry(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SelectPublishedGeometry
                | o Property SelectPublishedGeometry(    ) As
                | 
                | Returns or sets the Slect Published Geometry parameter.
                | Ensure consistency with the C++ interface to which the work
                | is delegated.
                |

        :return:
        """
        return self.fta_setting_att.SelectPublishedGeometry

    @select_published_geometry.setter
    def select_published_geometry(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.SelectPublishedGeometry = value 

    @property
    def shifted_profile(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShiftedProfile
                | o Property ShiftedProfile(    ) As
                | 
                | Returns or sets the Shifted Profile parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.fta_setting_att.ShiftedProfile

    @shifted_profile.setter
    def shifted_profile(self, value):
        """
            :param type value:
        """
        self.fta_setting_att.ShiftedProfile = value 

    @property
    def true_dimension(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TrueDimension
                | o Property TrueDimension(    ) As
                | 
                | Returns the TrueDimension parameter.
                |

        :return:
        """
        return self.fta_setting_att.TrueDimension

    def get_alphabetic_order_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAlphabeticOrderInfo
                | o Func GetAlphabeticOrderInfo(        AdminLevel,
                |                                       oLocked) As
                | 
                | Retrieves informations about the AlphabeticOrder setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetAlphabeticOrderInfo(admin_level, o_locked)

    def get_analysis_display_mode_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnalysisDisplayModeInfo
                | o Func GetAnalysisDisplayModeInfo(        AdminLevel,
                |                                           oLocked) As
                | 
                | Retrieves environment informations for the
                | AnalysisDisplayMode parameter. Role:Retrieves the state of
                | the AnalysisDisplayMode parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetAnalysisDisplayModeInfo(admin_level, o_locked)

    def get_angulaire_general_tol_class_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAngulaireGeneralTolClassInfo
                | o Func GetAngulaireGeneralTolClassInfo(        AdminLevel,
                |                                                oLocked) As
                | 
                | Retrieves informations about the Dimension general class
                | tolerance setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetAngulaireGeneralTolClassInfo(admin_level, o_locked)

    def get_annot_dim_invalid_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimInvalidColor
                | o Sub GetAnnotDimInvalidColor(        oValueR,
                |                                       oValueG,
                |                                       oValueB)
                | 
                | Returns the AnnotDimInvalidColor parameter.
                |
                | Parameters:

                |
        :param o_value_r:
        :param o_value_g:
        :param o_value_b:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimInvalidColor(o_value_r, o_value_g, o_value_b)

    def get_annot_dim_invalid_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimInvalidColorInfo
                | o Sub GetAnnotDimInvalidColorInfo(        ioAdminLevel,
                |                                           ioLocked,
                |                                           oModified)
                | 
                | Retrieves environment informations for the
                | AnnotDimInvalidColor parameter. Role:Retrieves the state of
                | the AnnotDimInvalidColor parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimInvalidColorInfo(io_admin_level, io_locked, o_modified)

    def get_annot_dim_invalid_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimInvalidInfo
                | o Func GetAnnotDimInvalidInfo(        AdminLevel,
                |                                       oLocked) As
                | 
                | Locks or unlocks the AnnotDimInvalid parameter. Role:Locks
                | or unlocks the AnnotDimInvalid parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimInvalidInfo(admin_level, o_locked)

    def get_annot_dim_on_deleted_geom_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimOnDeletedGeomColor
                | o Sub GetAnnotDimOnDeletedGeomColor(        oValueR,
                |                                             oValueG,
                |                                             oValueB)
                | 
                | Returns the AnnotDimOnDeletedGeomColor parameter.
                |
                | Parameters:

                |
        :param o_value_r:
        :param o_value_g:
        :param o_value_b:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimOnDeletedGeomColor(o_value_r, o_value_g, o_value_b)

    def get_annot_dim_on_deleted_geom_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimOnDeletedGeomColorInfo
                | o Sub GetAnnotDimOnDeletedGeomColorInfo(        ioAdminLevel,
                |                                                 ioLocked,
                |                                                 oModified)
                | 
                | Retrieves environment informations for the
                | AnnotDimOnDeletedGeomColor parameter. Role:Retrieves the
                | state of the AnnotDimOnDeletedGeomColor parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimOnDeletedGeomColorInfo(io_admin_level, io_locked, o_modified)

    def get_annot_dim_on_deleted_geom_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimOnDeletedGeomInfo
                | o Func GetAnnotDimOnDeletedGeomInfo(        AdminLevel,
                |                                             oLocked) As
                | 
                | Retrieves environment informations for the
                | AnnotDimOnDeletedGeom parameter. Role:Retrieves the state of
                | the AnnotDimOnDeletedGeom parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimOnDeletedGeomInfo(admin_level, o_locked)

    def get_annot_dim_on_unloaded_geom_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimOnUnloadedGeomColor
                | o Sub GetAnnotDimOnUnloadedGeomColor(        oValueR,
                |                                              oValueG,
                |                                              oValueB)
                | 
                | Returns the AnnotDimOnUnloadedGeomColor parameter.
                |
                | Parameters:

                |
        :param o_value_r:
        :param o_value_g:
        :param o_value_b:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimOnUnloadedGeomColor(o_value_r, o_value_g, o_value_b)

    def get_annot_dim_on_unloaded_geom_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimOnUnloadedGeomColorInfo
                | o Sub GetAnnotDimOnUnloadedGeomColorInfo(        ioAdminLevel,
                |                                                  ioLocked,
                |                                                  oModified)
                | 
                | Retrieves environment informations for the
                | AnnotDimOnUnloadedGeomColor parameter. Role:Retrieves the
                | state of the AnnotDimOnUnloadedGeomColor parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimOnUnloadedGeomColorInfo(io_admin_level, io_locked, o_modified)

    def get_annot_dim_on_unloaded_geom_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotDimOnUnloadedGeomInfo
                | o Func GetAnnotDimOnUnloadedGeomInfo(        AdminLevel,
                |                                              oLocked) As
                | 
                | Retrieves environment informations for the
                | AnnotDimOnUnloadedGeom parameter. Role:Retrieves the state
                | of the AnnotDimOnUnloadedGeom parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetAnnotDimOnUnloadedGeomInfo(admin_level, o_locked)

    def get_annot_on_zero_z_setting_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotOnZeroZSettingInfo
                | o Func GetAnnotOnZeroZSettingInfo(        AdminLevel,
                |                                           oLocked) As
                | 
                | Retrieves environment informations for the
                | AnnotOnZeroZSetting parameter. Role:Retrieves the state of
                | the AnnotOnZeroZSetting parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetAnnotOnZeroZSettingInfo(admin_level, o_locked)

    def get_body_hide_in_capture_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBodyHideInCaptureInfo
                | o Func GetBodyHideInCaptureInfo(        AdminLevel,
                |                                         oLocked) As
                | 
                | Retrieves informations about the Visibility of Part
                | instances, bodies and geometrical sets in Capture. Refer to
                | for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetBodyHideInCaptureInfo(admin_level, o_locked)

    def get_catfta_chamfer_general_tol_class_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCATFTAChamferGeneralTolClassInfo
                | o Func GetCATFTAChamferGeneralTolClassInfo(        AdminLevel,
                |                                                    oLocked) As
                | 
                | Retrieves environment informations for the
                | CATFTAChamferGeneralTolClass parameter. Role:Retrieves the
                | state of the CATFTAChamferGeneralTolClass parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetCATFTAChamferGeneralTolClassInfo(admin_level, o_locked)

    def get_catfta_edges_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCATFTAEdgesColor
                | o Sub GetCATFTAEdgesColor(        oValueR,
                |                                   oValueG,
                |                                   oValueB)
                | 
                | Returns the GetCATFTAEdgesColor parameter.
                |
                | Parameters:

                |
        :param o_value_r:
        :param o_value_g:
        :param o_value_b:
        :return:
        """
        return self.fta_setting_att.GetCATFTAEdgesColor(o_value_r, o_value_g, o_value_b)

    def get_catfta_edges_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCATFTAEdgesColorInfo
                | o Sub GetCATFTAEdgesColorInfo(        ioAdminLevel,
                |                                       ioLocked,
                |                                       oModified)
                | 
                | Retrieves environment informations for the
                | GetCATFTAEdgesColor parameter. Role:Retrieves the state of
                | the GetCATFTAEdgesColor parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.fta_setting_att.GetCATFTAEdgesColorInfo(io_admin_level, io_locked, o_modified)

    def get_catfta_edges_line_type_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCATFTAEdgesLineTypeInfo
                | o Sub GetCATFTAEdgesLineTypeInfo(        ioAdminLevel,
                |                                          ioLocked,
                |                                          oModified)
                | 
                | Retrieves environment informations for the
                | CATFTAEdgesLineType parameter. Role:Retrieves the state of
                | the CATFTAEdgesLineType parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.fta_setting_att.GetCATFTAEdgesLineTypeInfo(io_admin_level, io_locked, o_modified)

    def get_catfta_edges_thickness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCATFTAEdgesThicknessInfo
                | o Sub GetCATFTAEdgesThicknessInfo(        ioAdminLevel,
                |                                           ioLocked,
                |                                           oModified)
                | 
                | Retrieves environment informations for the
                | CATFTAEdgesThickness parameter. Role:Retrieves the state of
                | the CATFTAEdgesThickness parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.fta_setting_att.GetCATFTAEdgesThicknessInfo(io_admin_level, io_locked, o_modified)

    def get_catftauf_auto_tolerancing_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCATFTAUFAutoTolerancingInfo
                | o Sub GetCATFTAUFAutoTolerancingInfo(        ioAdminLevel,
                |                                              ioLocked,
                |                                              oModified)
                | 
                | Retrieves environment informations for the
                | CATFTAUFAutoTolerancing parameter. Role:Retrieves the state
                | of the CATFTAUFAutoTolerancing parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.fta_setting_att.GetCATFTAUFAutoTolerancingInfo(io_admin_level, io_locked, o_modified)

    def get_catfta_use_last_tolerances_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCATFTAUseLastTolerancesInfo
                | o Func GetCATFTAUseLastTolerancesInfo(        AdminLevel,
                |                                               oLocked) As
                | 
                | Retrieves environment informations for the
                | CATFTAUseLastTolerances parameter. Role:Retrieves the state
                | of the CATFTAUseLastTolerances parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetCATFTAUseLastTolerancesInfo(admin_level, o_locked)

    def get_dim_after_cre_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimAfterCreInfo
                | o Func GetDimAfterCreInfo(        AdminLevel,
                |                                   oLocked) As
                | 
                | Retrieves informations about the Dimension After Creation
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimAfterCreInfo(admin_level, o_locked)

    def get_dim_after_mod_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimAfterModInfo
                | o Func GetDimAfterModInfo(        AdminLevel,
                |                                   oLocked) As
                | 
                | Retrieves informations about the Dimension After
                | Modification setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimAfterModInfo(admin_level, o_locked)

    def get_dim_before_cre_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimBeforeCreInfo
                | o Func GetDimBeforeCreInfo(        AdminLevel,
                |                                    oLocked) As
                | 
                | Retrieves informations about the Dimension Before Creation
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimBeforeCreInfo(admin_level, o_locked)

    def get_dim_before_mod_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimBeforeModInfo
                | o Func GetDimBeforeModInfo(        AdminLevel,
                |                                    oLocked) As
                | 
                | Retrieves informations about the Dimension Before
                | Modification setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimBeforeModInfo(admin_level, o_locked)

    def get_dim_blanking_cre_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimBlankingCreInfo
                | o Func GetDimBlankingCreInfo(        AdminLevel,
                |                                      oLocked) As
                | 
                | Retrieves informations about the Dimension Blanking Creation
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimBlankingCreInfo(admin_level, o_locked)

    def get_dim_blanking_mod_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimBlankingModInfo
                | o Func GetDimBlankingModInfo(        AdminLevel,
                |                                      oLocked) As
                | 
                | Retrieves informations about the Dimension Blanking
                | Modification setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimBlankingModInfo(admin_level, o_locked)

    def get_dim_configure_snapping_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimConfigureSnappingInfo
                | o Func GetDimConfigureSnappingInfo(        AdminLevel,
                |                                            oLocked) As
                | 
                | Retrieves informations about the DimMoveSubPart setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimConfigureSnappingInfo(admin_level, o_locked)

    def get_dim_constant_offset_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimConstantOffsetInfo
                | o Func GetDimConstantOffsetInfo(        AdminLevel,
                |                                         oLocked) As
                | 
                | Retrieves informations about the Dimension Constant Offset
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimConstantOffsetInfo(admin_level, o_locked)

    def get_dim_create_on_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimCreateOnInfo
                | o Func GetDimCreateOnInfo(        AdminLevel,
                |                                   oLocked) As
                | 
                | Retrieves informations about the DimCreateOn setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimCreateOnInfo(admin_level, o_locked)

    def get_dim_line_pos_value_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLinePosValueInfo
                | o Func GetDimLinePosValueInfo(        AdminLevel,
                |                                       oLocked) As
                | 
                | Retrieves informations about the Dimension Line Position
                | Value setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLinePosValueInfo(admin_level, o_locked)

    def get_dim_line_up_base_angle_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpBaseAngleInfo
                | o Func GetDimLineUpBaseAngleInfo(        AdminLevel,
                |                                          oLocked) As
                | 
                | Retrieves informations about the Dimension Line Up Base
                | Angle setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpBaseAngleInfo(admin_level, o_locked)

    def get_dim_line_up_base_length_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpBaseLengthInfo
                | o Func GetDimLineUpBaseLengthInfo(        AdminLevel,
                |                                           oLocked) As
                | 
                | Retrieves informations about the Dimension Line Up Base
                | Length setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpBaseLengthInfo(admin_level, o_locked)

    def get_dim_line_up_cumul_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpCumulInfo
                | o Func GetDimLineUpCumulInfo(        AdminLevel,
                |                                      oLocked) As
                | 
                | Retrieves informations about the Dimension Line Up Cululated
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpCumulInfo(admin_level, o_locked)

    def get_dim_line_up_funnel_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpFunnelInfo
                | o Func GetDimLineUpFunnelInfo(        AdminLevel,
                |                                       oLocked) As
                | 
                | Retrieves informations about the Dimension Line Up Funnel
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpFunnelInfo(admin_level, o_locked)

    def get_dim_line_up_offset_bet_dim_angle_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpOffsetBetDimAngleInfo
                | o Func GetDimLineUpOffsetBetDimAngleInfo(        AdminLevel,
                |                                                  oLocked) As
                | 
                | Retrieves informations about the DimLineUpOffsetBetDimAngle
                | setting parameter value.
                |
                | Parameters:
                | AdminLevel
                |    Input/Output parameter, is the administration level.
                |  
                |  oLocked
                |    Input/Output parameter, is the lock status of the check button.
                |  
                |  oModified
                |    Output paramter which gives the status as boolean if the status is modified.
                |  If return code E_FAIL the values are not obtained.
                |  If return code S_OK the values are obtained.
                |  Refer to 
                | 
                |  for a detailled description.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpOffsetBetDimAngleInfo(admin_level, o_locked)

    def get_dim_line_up_offset_bet_dim_length_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpOffsetBetDimLengthInfo
                | o Func GetDimLineUpOffsetBetDimLengthInfo(        AdminLevel,
                |                                                   oLocked) As
                | 
                | Retrieves informations about the DimLineUpOffsetBetDimLength
                | setting parameter value.
                |
                | Parameters:
                | AdminLevel
                |    Input/Output parameter, is the administration level.
                |  
                |  oLocked
                |    Input/Output parameter, is the lock status of the check button.
                |  
                |  oModified
                |    Output paramter which gives the status as boolean if the status is modified.
                |  If return code E_FAIL the values are not obtained.
                |  If return code S_OK the values are obtained.
                |  Refer to 
                | 
                |  for a detailled description.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpOffsetBetDimLengthInfo(admin_level, o_locked)

    def get_dim_line_up_offset_to_ref_angle_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpOffsetToRefAngleInfo
                | o Func GetDimLineUpOffsetToRefAngleInfo(        AdminLevel,
                |                                                 oLocked) As
                | 
                | Retrieves informations about the DimLineUpOffsetToRefAngle
                | setting parameter value.
                |
                | Parameters:
                | AdminLevel
                |    Input/Output parameter, is the administration level.
                |  
                |  oLocked
                |    Input/Output parameter, is the lock status of the check button.
                |  
                |  oModified
                |    Output paramter which gives the status as boolean if the status is modified.
                |  If return code E_FAIL the values are not obtained.
                |  If return code S_OK the values are obtained.
                |  Refer to 
                | 
                |  for a detailled description.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpOffsetToRefAngleInfo(admin_level, o_locked)

    def get_dim_line_up_offset_to_ref_length_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpOffsetToRefLengthInfo
                | o Func GetDimLineUpOffsetToRefLengthInfo(        AdminLevel,
                |                                                  oLocked) As
                | 
                | Retrieves informations about the DimLineUpOffsetToRefLength
                | setting parameter value.
                |
                | Parameters:
                | AdminLevel
                |    Input/Output parameter, is the administration level.
                |  
                |  oLocked
                |    Input/Output parameter, is the lock status of the check button.
                |  
                |  oModified
                |    Output paramter which gives the status as boolean if the status is modified.
                |  If return code E_FAIL the values are not obtained.
                |  If return code S_OK the values are obtained.
                |  Refer to 
                | 
                |  for a detailled description.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpOffsetToRefLengthInfo(admin_level, o_locked)

    def get_dim_line_up_stack_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimLineUpStackInfo
                | o Func GetDimLineUpStackInfo(        AdminLevel,
                |                                      oLocked) As
                | 
                | Retrieves informations about the Dimension Line Up Stack
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimLineUpStackInfo(admin_level, o_locked)

    def get_dim_manual_positionning_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimManualPositionningInfo
                | o Func GetDimManualPositionningInfo(        AdminLevel,
                |                                             oLocked) As
                | 
                | Retrieves informations about the Dimension Manual
                | Positionning setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimManualPositionningInfo(admin_level, o_locked)

    def get_dim_move2d_part_cre_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMove2dPartCreInfo
                | o Func GetDimMove2dPartCreInfo(        AdminLevel,
                |                                        oLocked) As
                | 
                | Retrieves informations about the Dimension Move 2D Creation
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMove2dPartCreInfo(admin_level, o_locked)

    def get_dim_move2d_part_mod_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMove2dPartModInfo
                | o Func GetDimMove2dPartModInfo(        AdminLevel,
                |                                        oLocked) As
                | 
                | Retrieves informations about the Dimension Move 2D
                | Modification setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMove2dPartModInfo(admin_level, o_locked)

    def get_dim_move_dim_line_cre_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMoveDimLineCreInfo
                | o Func GetDimMoveDimLineCreInfo(        AdminLevel,
                |                                         oLocked) As
                | 
                | Retrieves informations about the Dimension Move Dimension
                | Line Creation setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMoveDimLineCreInfo(admin_level, o_locked)

    def get_dim_move_dim_line_mod_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMoveDimLineModInfo
                | o Func GetDimMoveDimLineModInfo(        AdminLevel,
                |                                         oLocked) As
                | 
                | Retrieves informations about the Dimension Move Dimension
                | Line Modification setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMoveDimLineModInfo(admin_level, o_locked)

    def get_dim_move_leader_cre_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMoveLeaderCreInfo
                | o Func GetDimMoveLeaderCreInfo(        AdminLevel,
                |                                        oLocked) As
                | 
                | Retrieves informations about the Dimension leader Creation
                | setting parameter value.
                |
                | Parameters:
                | AdminLevel
                |    Input/Output parameter, is the administration level.
                |  
                |  oLocked
                |    Input/Output parameter, is the lock status of the check button.
                |  
                |  oModified
                |    Output paramter which gives the status as boolean if the status is modified.
                |  If return code E_FAIL the values are not obtained.
                |  If return code S_OK the values are obtained.
                |  Refer to 
                | 
                |  for a detailled description.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMoveLeaderCreInfo(admin_level, o_locked)

    def get_dim_move_leader_mod_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMoveLeaderModInfo
                | o Func GetDimMoveLeaderModInfo(        AdminLevel,
                |                                        oLocked) As
                | 
                | Retrieves informations about the Dimension leader
                | modification setting parameter value.
                |
                | Parameters:
                | AdminLevel
                |    Input/Output parameter, is the administration level.
                |  
                |  oLocked
                |    Input/Output parameter, is the lock status of the check button.
                |  
                |  oModified
                |    Output paramter which gives the status as boolean if the status is modified.
                |  If return code E_FAIL the values are not obtained.
                |  If return code S_OK the values are obtained.
                |  Refer to 
                | 
                |  for a detailled description.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMoveLeaderModInfo(admin_level, o_locked)

    def get_dim_move_sub_part_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMoveSubPartInfo
                | o Func GetDimMoveSubPartInfo(        AdminLevel,
                |                                      oLocked) As
                | 
                | Retrieves informations about the DimMoveSubPart setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMoveSubPartInfo(admin_level, o_locked)

    def get_dim_move_value_cre_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMoveValueCreInfo
                | o Func GetDimMoveValueCreInfo(        AdminLevel,
                |                                       oLocked) As
                | 
                | Retrieves informations about the Dimension Move Value
                | Creation setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMoveValueCreInfo(admin_level, o_locked)

    def get_dim_move_value_mod_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimMoveValueModInfo
                | o Func GetDimMoveValueModInfo(        AdminLevel,
                |                                       oLocked) As
                | 
                | Retrieves informations about the Dimension Move Value
                | Modification setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimMoveValueModInfo(admin_level, o_locked)

    def get_dim_o_run_cre_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimORunCreInfo
                | o Func GetDimORunCreInfo(        AdminLevel,
                |                                  oLocked) As
                | 
                | Retrieves informations about the Dimension Over Run Creation
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimORunCreInfo(admin_level, o_locked)

    def get_dim_o_run_mod_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimORunModInfo
                | o Func GetDimORunModInfo(        AdminLevel,
                |                                  oLocked) As
                | 
                | Retrieves informations about the Dimension Over Run
                | Modification setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimORunModInfo(admin_level, o_locked)

    def get_dim_ori_default_symb_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimOriDefaultSymbInfo
                | o Func GetDimOriDefaultSymbInfo(        AdminLevel,
                |                                         oLocked) As
                | 
                | Retrieves informations about the Dimension Orientation
                | Default Symbol setting parameter value. Refer to for a
                | detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimOriDefaultSymbInfo(admin_level, o_locked)

    def get_dim_snapping_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimSnappingInfo
                | o Func GetDimSnappingInfo(        AdminLevel,
                |                                   oLocked) As
                | 
                | Retrieves informations about the Dimension Snapping setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetDimSnappingInfo(admin_level, o_locked)

    def get_general_tol_class_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGeneralTolClassInfo
                | o Func GetGeneralTolClassInfo(        AdminLevel,
                |                                       oLocked) As
                | 
                | Retrieves informations about the Dimension general class
                | tolerance setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetGeneralTolClassInfo(admin_level, o_locked)

    def get_highlight_def_annot_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHighlightDefAnnotInfo
                | o Func GetHighlightDefAnnotInfo(        AdminLevel,
                |                                         oLocked) As
                | 
                | Retrieves informations about the Highlight Def Annot setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetHighlightDefAnnotInfo(admin_level, o_locked)

    def get_noa_creation_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNoaCreationInfo
                | o Func GetNoaCreationInfo(        AdminLevel,
                |                                   oLocked) As
                | 
                | Retrieves informations about the Noa Creation setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetNoaCreationInfo(admin_level, o_locked)

    def get_non_semantic_allways_upgrade_general_tol_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNonSemanticAllwaysUpgradeGeneralTolInfo
                | o Func GetNonSemanticAllwaysUpgradeGeneralTolInfo(        AdminLevel,
                |                                                           oLocked) As
                | 
                | Retrieves informations about the Non Semantic Allways
                | Upgrade general tolerance setting parameter value. Refer to
                | for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetNonSemanticAllwaysUpgradeGeneralTolInfo(admin_level, o_locked)

    def get_non_semantic_allways_upgrade_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNonSemanticAllwaysUpgradeInfo
                | o Func GetNonSemanticAllwaysUpgradeInfo(        AdminLevel,
                |                                                 oLocked) As
                | 
                | Retrieves informations about the Non Semantic Allways
                | Upgrade setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetNonSemanticAllwaysUpgradeInfo(admin_level, o_locked)

    def get_non_semantic_dim_allowed_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNonSemanticDimAllowedInfo
                | o Func GetNonSemanticDimAllowedInfo(        AdminLevel,
                |                                             oLocked) As
                | 
                | Retrieves informations about the Non Semantic Dim Allowed
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetNonSemanticDimAllowedInfo(admin_level, o_locked)

    def get_non_semantic_marked_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNonSemanticMarkedInfo
                | o Func GetNonSemanticMarkedInfo(        AdminLevel,
                |                                         oLocked) As
                | 
                | Retrieves informations about the Non Semantic Marked setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetNonSemanticMarkedInfo(admin_level, o_locked)

    def get_non_semantic_tol_allowed_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNonSemanticTolAllowedInfo
                | o Func GetNonSemanticTolAllowedInfo(        AdminLevel,
                |                                             oLocked) As
                | 
                | Retrieves informations about the Non Semantic Tol Allowed
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetNonSemanticTolAllowedInfo(admin_level, o_locked)

    def get_parameters_in_tree_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetParametersInTreeInfo
                | o Func GetParametersInTreeInfo(        AdminLevel,
                |                                        oLocked) As
                | 
                | Retrieves informations about the Parameters in tree setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetParametersInTreeInfo(admin_level, o_locked)

    def get_rotation_snap_angle_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRotationSnapAngleInfo
                | o Func GetRotationSnapAngleInfo(        AdminLevel,
                |                                         oLocked) As
                | 
                | Retrieves informations about the Rotation Snap Angle setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetRotationSnapAngleInfo(admin_level, o_locked)

    def get_rotation_snap_auto_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRotationSnapAutoInfo
                | o Func GetRotationSnapAutoInfo(        AdminLevel,
                |                                        oLocked) As
                | 
                | Retrieves informations about the Rotation Snap Auto setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetRotationSnapAutoInfo(admin_level, o_locked)

    def get_sect_pattern_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSectPatternInfo
                | o Func GetSectPatternInfo(        AdminLevel,
                |                                   oLocked) As
                | 
                | Retrieves informations about the Pattern of Visu setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetSectPatternInfo(admin_level, o_locked)

    def get_select_published_geometry_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSelectPublishedGeometryInfo
                | o Func GetSelectPublishedGeometryInfo(        AdminLevel,
                |                                               oLocked) As
                | 
                | Retrieves informations about the Select Published Geometry
                | setting parameter value. Refer to for a detailled
                | description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetSelectPublishedGeometryInfo(admin_level, o_locked)

    def get_shifted_profile_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShiftedProfileInfo
                | o Func GetShiftedProfileInfo(        AdminLevel,
                |                                      oLocked) As
                | 
                | Retrieves informations about the Shifted Profile setting
                | parameter value. Refer to for a detailled description.
                |
                | Parameters:

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetShiftedProfileInfo(admin_level, o_locked)

    def get_true_dimension_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTrueDimensionColor
                | o Sub GetTrueDimensionColor(        oValueR,
                |                                     oValueG,
                |                                     oValueB)
                | 
                | Returns the TrueDimensionColor parameter.
                |
                | Parameters:

                |
        :param o_value_r:
        :param o_value_g:
        :param o_value_b:
        :return:
        """
        return self.fta_setting_att.GetTrueDimensionColor(o_value_r, o_value_g, o_value_b)

    def get_true_dimension_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTrueDimensionColorInfo
                | o Sub GetTrueDimensionColorInfo(        ioAdminLevel,
                |                                         ioLocked,
                |                                         oModified)
                | 
                | Retrieves environment informations for the
                | TrueDimensionColor parameter. Role:Retrieves the state of
                | the TrueDimensionColor parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.fta_setting_att.GetTrueDimensionColorInfo(io_admin_level, io_locked, o_modified)

    def get_true_dimension_info(self, admin_level, o_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTrueDimensionInfo
                | o Func GetTrueDimensionInfo(        AdminLevel,
                |                                     oLocked) As
                | 
                | Retrieves environment informations for the TrueDimension
                | parameter. Role:Retrieves the state of the TrueDimension
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param admin_level:
        :param o_locked:
        :return:
        """
        return self.fta_setting_att.GetTrueDimensionInfo(admin_level, o_locked)

    def set_alphabetic_order_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAlphabeticOrderLock
                | o Sub SetAlphabeticOrderLock(        iLocked)
                | 
                | Locks or unlocks the AlphabeticOrder setting parameter
                | value. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAlphabeticOrderLock(i_locked)

    def set_analysis_display_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnalysisDisplayModeLock
                | o Sub SetAnalysisDisplayModeLock(        iLocked)
                | 
                | Locks or unlocks the AnalysisDisplayMode parameter.
                | Role:Locks or unlocks the AnalysisDisplayMode parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAnalysisDisplayModeLock(i_locked)

    def set_angulaire_general_tol_class_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAngulaireGeneralTolClassLock
                | o Sub SetAngulaireGeneralTolClassLock(        iLocked)
                | 
                | Locks or unlocks the Dimension general class parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAngulaireGeneralTolClassLock(i_locked)

    def set_annot_dim_invalid_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimInvalidColor
                | o Sub SetAnnotDimInvalidColor(        iValueR,
                |                                       iValueG,
                |                                       iValueB)
                | 
                | Sets the AnnotDimInvalidColor parameter.
                |
                | Parameters:

                |
        :param i_value_r:
        :param i_value_g:
        :param i_value_b:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimInvalidColor(i_value_r, i_value_g, i_value_b)

    def set_annot_dim_invalid_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimInvalidColorLock
                | o Sub SetAnnotDimInvalidColorLock(        iLocked)
                | 
                | Locks or unlocks the AnnotDimInvalidColor parameter.
                | Role:Locks or unlocks the AnnotDimInvalidColor parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimInvalidColorLock(i_locked)

    def set_annot_dim_invalid_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimInvalidLock
                | o Sub SetAnnotDimInvalidLock(        iLocked)
                | 
                | Retrieves environment informations for the AnnotDimInvalid
                | parameter. Role:Retrieves the state of the AnnotDimInvalid
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimInvalidLock(i_locked)

    def set_annot_dim_on_deleted_geom_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimOnDeletedGeomColor
                | o Sub SetAnnotDimOnDeletedGeomColor(        iValueR,
                |                                             iValueG,
                |                                             iValueB)
                | 
                | Sets the AnnotDimOnDeletedGeomColor parameter.
                |
                | Parameters:

                |
        :param i_value_r:
        :param i_value_g:
        :param i_value_b:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimOnDeletedGeomColor(i_value_r, i_value_g, i_value_b)

    def set_annot_dim_on_deleted_geom_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimOnDeletedGeomColorLock
                | o Sub SetAnnotDimOnDeletedGeomColorLock(        iLocked)
                | 
                | Locks or unlocks the AnnotDimOnDeletedGeomColor parameter.
                | Role:Locks or unlocks the AnnotDimOnDeletedGeomColor
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimOnDeletedGeomColorLock(i_locked)

    def set_annot_dim_on_deleted_geom_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimOnDeletedGeomLock
                | o Sub SetAnnotDimOnDeletedGeomLock(        iLocked)
                | 
                | Locks or unlocks the AnnotDimOnDeletedGeom parameter.
                | Role:Locks or unlocks the AnnotDimOnDeletedGeom parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimOnDeletedGeomLock(i_locked)

    def set_annot_dim_on_unloaded_geom_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimOnUnloadedGeomColor
                | o Sub SetAnnotDimOnUnloadedGeomColor(        iValueR,
                |                                              iValueG,
                |                                              iValueB)
                | 
                | Sets the AnnotDimOnUnloadedGeomColor parameter.
                |
                | Parameters:

                |
        :param i_value_r:
        :param i_value_g:
        :param i_value_b:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimOnUnloadedGeomColor(i_value_r, i_value_g, i_value_b)

    def set_annot_dim_on_unloaded_geom_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimOnUnloadedGeomColorLock
                | o Sub SetAnnotDimOnUnloadedGeomColorLock(        iLocked)
                | 
                | Locks or unlocks the AnnotDimOnUnloadedGeomColor parameter.
                | Role:Locks or unlocks the AnnotDimOnUnloadedGeomColor
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimOnUnloadedGeomColorLock(i_locked)

    def set_annot_dim_on_unloaded_geom_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotDimOnUnloadedGeomLock
                | o Sub SetAnnotDimOnUnloadedGeomLock(        iLocked)
                | 
                | Locks or unlocks the AnnotDimOnUnloadedGeom parameter.
                | Role:Locks or unlocks the AnnotDimOnUnloadedGeom parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAnnotDimOnUnloadedGeomLock(i_locked)

    def set_annot_on_zero_z_setting_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotOnZeroZSettingLock
                | o Sub SetAnnotOnZeroZSettingLock(        iLocked)
                | 
                | Locks or unlocks the AnnotOnZeroZSetting parameter.
                | Role:Locks or unlocks the AnnotOnZeroZSetting parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetAnnotOnZeroZSettingLock(i_locked)

    def set_body_hide_in_capture_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBodyHideInCaptureLock
                | o Sub SetBodyHideInCaptureLock(        iLocked)
                | 
                | Locks or unlocks the Dimension general class parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetBodyHideInCaptureLock(i_locked)

    def set_catfta_chamfer_general_tol_class_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCATFTAChamferGeneralTolClassLock
                | o Sub SetCATFTAChamferGeneralTolClassLock(        iLocked)
                | 
                | Locks or unlocks the CATFTAChamferGeneralTolClass parameter.
                | Role:Locks or unlocks the CATFTAChamferGeneralTolClass
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetCATFTAChamferGeneralTolClassLock(i_locked)

    def set_catfta_edges_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCATFTAEdgesColor
                | o Sub SetCATFTAEdgesColor(        iValueR,
                |                                   iValueG,
                |                                   iValueB)
                | 
                | Sets the GetCATFTAEdgesColor parameter.
                |
                | Parameters:

                |
        :param i_value_r:
        :param i_value_g:
        :param i_value_b:
        :return:
        """
        return self.fta_setting_att.SetCATFTAEdgesColor(i_value_r, i_value_g, i_value_b)

    def set_catfta_edges_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCATFTAEdgesColorLock
                | o Sub SetCATFTAEdgesColorLock(        iLocked)
                | 
                | Locks or unlocks the GetCATFTAEdgesColor parameter.
                | Role:Locks or unlocks the GetCATFTAEdgesColor parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetCATFTAEdgesColorLock(i_locked)

    def set_catfta_edges_line_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCATFTAEdgesLineTypeLock
                | o Sub SetCATFTAEdgesLineTypeLock(        iLocked)
                | 
                | Locks or unlocks the CATFTAEdgesLineType parameter.
                | Role:Locks or unlocks the CATFTAEdgesLineType parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetCATFTAEdgesLineTypeLock(i_locked)

    def set_catfta_edges_thickness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCATFTAEdgesThicknessLock
                | o Sub SetCATFTAEdgesThicknessLock(        iLocked)
                | 
                | Locks or unlocks the CATFTAEdgesThickness parameter.
                | Role:Locks or unlocks the CATFTAEdgesThickness parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetCATFTAEdgesThicknessLock(i_locked)

    def set_catftauf_auto_tolerancing_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCATFTAUFAutoTolerancingLock
                | o Sub SetCATFTAUFAutoTolerancingLock(        iLocked)
                | 
                | Locks or unlocks the CATFTAUFAutoTolerancing parameter.
                | Role:Locks or unlocks the CATFTAUFAutoTolerancing parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetCATFTAUFAutoTolerancingLock(i_locked)

    def set_catfta_use_last_tolerances_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCATFTAUseLastTolerancesLock
                | o Sub SetCATFTAUseLastTolerancesLock(        iLocked)
                | 
                | Locks or unlocks the CATFTAUseLastTolerances parameter.
                | Role:Locks or unlocks the CATFTAUseLastTolerances parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetCATFTAUseLastTolerancesLock(i_locked)

    def set_dim_after_cre_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimAfterCreLock
                | o Sub SetDimAfterCreLock(        iLocked)
                | 
                | Locks or unlocks the Dimension After Creaation parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimAfterCreLock(i_locked)

    def set_dim_after_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimAfterModLock
                | o Sub SetDimAfterModLock(        iLocked)
                | 
                | Locks or unlocks the Dimension After Modification parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimAfterModLock(i_locked)

    def set_dim_before_cre_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimBeforeCreLock
                | o Sub SetDimBeforeCreLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Before Creation parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimBeforeCreLock(i_locked)

    def set_dim_before_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimBeforeModLock
                | o Sub SetDimBeforeModLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Before Modification
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimBeforeModLock(i_locked)

    def set_dim_blanking_cre_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimBlankingCreLock
                | o Sub SetDimBlankingCreLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Blanking Creation parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimBlankingCreLock(i_locked)

    def set_dim_blanking_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimBlankingModLock
                | o Sub SetDimBlankingModLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Blanking Modification
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimBlankingModLock(i_locked)

    def set_dim_configure_snapping_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimConfigureSnappingLock
                | o Sub SetDimConfigureSnappingLock(        iLocked)
                | 
                | Locks or unlocks the DimConfigureSnapping parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimConfigureSnappingLock(i_locked)

    def set_dim_constant_offset_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimConstantOffsetLock
                | o Sub SetDimConstantOffsetLock(        iLocked)
                | 
                | Locks or unlocks the Constant Offset parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimConstantOffsetLock(i_locked)

    def set_dim_create_on_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimCreateOnLock
                | o Sub SetDimCreateOnLock(        iLocked)
                | 
                | Locks or unlocks the DimCreateOn parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimCreateOnLock(i_locked)

    def set_dim_line_pos_value_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLinePosValueLock
                | o Sub SetDimLinePosValueLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Line Position Value
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLinePosValueLock(i_locked)

    def set_dim_line_up_base_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpBaseAngleLock
                | o Sub SetDimLineUpBaseAngleLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Line Up Base Angle parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpBaseAngleLock(i_locked)

    def set_dim_line_up_base_length_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpBaseLengthLock
                | o Sub SetDimLineUpBaseLengthLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Line Up Base Length
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpBaseLengthLock(i_locked)

    def set_dim_line_up_cumul_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpCumulLock
                | o Sub SetDimLineUpCumulLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Line Up Cululated parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpCumulLock(i_locked)

    def set_dim_line_up_funnel_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpFunnelLock
                | o Sub SetDimLineUpFunnelLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Line Up Funnel parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpFunnelLock(i_locked)

    def set_dim_line_up_offset_bet_dim_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpOffsetBetDimAngleLock
                | o Sub SetDimLineUpOffsetBetDimAngleLock(        iLocked)
                | 
                | Locks or unlocks the DimLineUpOffsetBetDimAngle parameter.
                |
                | Parameters:
                | iLocked
                |    Input value of the DimLineUpOffsetBetDimAngle (lock/unlock).
                |  If return code E_FAIL iLocked is not set.
                |  If return code S_OK iLocked is set.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpOffsetBetDimAngleLock(i_locked)

    def set_dim_line_up_offset_bet_dim_length_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpOffsetBetDimLengthLock
                | o Sub SetDimLineUpOffsetBetDimLengthLock(        iLocked)
                | 
                | Locks or unlocks the DimLineUpOffsetBetDimLength parameter.
                |
                | Parameters:
                | iLocked
                |    Input value of the DimLineUpOffsetBetDimLength (lock/unlock).
                |  If return code E_FAIL iLocked is not set.
                |  If return code S_OK iLocked is set.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpOffsetBetDimLengthLock(i_locked)

    def set_dim_line_up_offset_to_ref_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpOffsetToRefAngleLock
                | o Sub SetDimLineUpOffsetToRefAngleLock(        iLocked)
                | 
                | Locks or unlocks the DimLineUpOffsetToRefAngle parameter.
                |
                | Parameters:
                | iLocked
                |    Input value of the DimLineUpOffsetToRefAngle (lock/unlock).
                |  If return code E_FAIL iLocked is not set.
                |  If return code S_OK iLocked is set.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpOffsetToRefAngleLock(i_locked)

    def set_dim_line_up_offset_to_ref_length_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpOffsetToRefLengthLock
                | o Sub SetDimLineUpOffsetToRefLengthLock(        iLocked)
                | 
                | Locks or unlocks the DimLineUpOffsetToRefLength parameter.
                |
                | Parameters:
                | iLocked
                |    Input value of the DimLineUpOffsetToRefLength (lock/unlock).
                |  If return code E_FAIL iLocked is not set.
                |  If return code S_OK iLocked is set.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpOffsetToRefLengthLock(i_locked)

    def set_dim_line_up_stack_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimLineUpStackLock
                | o Sub SetDimLineUpStackLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Line Up Stack parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimLineUpStackLock(i_locked)

    def set_dim_manual_positionning_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimManualPositionningLock
                | o Sub SetDimManualPositionningLock(        iLocked)
                | 
                | Locks or unlocks the Manual Positionning parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimManualPositionningLock(i_locked)

    def set_dim_move2d_part_cre_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMove2dPartCreLock
                | o Sub SetDimMove2dPartCreLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Move 2D Creation parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMove2dPartCreLock(i_locked)

    def set_dim_move2d_part_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMove2dPartModLock
                | o Sub SetDimMove2dPartModLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Move 2D Modification
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMove2dPartModLock(i_locked)

    def set_dim_move_dim_line_cre_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMoveDimLineCreLock
                | o Sub SetDimMoveDimLineCreLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Move Dimension Line Creation
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMoveDimLineCreLock(i_locked)

    def set_dim_move_dim_line_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMoveDimLineModLock
                | o Sub SetDimMoveDimLineModLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Move Dimension Line
                | Modification parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMoveDimLineModLock(i_locked)

    def set_dim_move_leader_cre_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMoveLeaderCreLock
                | o Sub SetDimMoveLeaderCreLock(        iLocked)
                | 
                | Locks or unlocks the Dimension leader Creation parameter.
                |
                | Parameters:
                | iLocked
                |    Input value of the Dimension leader creation check box lock/unlock status.
                |  If return code E_FAIL iLocked is not set.
                |  If return code S_OK iLocked is set.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMoveLeaderCreLock(i_locked)

    def set_dim_move_leader_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMoveLeaderModLock
                | o Sub SetDimMoveLeaderModLock(        iLocked)
                | 
                | Locks or unlocks the Dimension leader modification
                | parameter.
                |
                | Parameters:
                | iLocked
                |    Input value of the Dimension leader modification check box (lock/unlock).
                |  If return code E_FAIL iLocked is not set.
                |  If return code S_OK iLocked is set.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMoveLeaderModLock(i_locked)

    def set_dim_move_sub_part_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMoveSubPartLock
                | o Sub SetDimMoveSubPartLock(        iLocked)
                | 
                | Locks or unlocks the DimMoveSubPart parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMoveSubPartLock(i_locked)

    def set_dim_move_value_cre_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMoveValueCreLock
                | o Sub SetDimMoveValueCreLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Move Value Creation
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMoveValueCreLock(i_locked)

    def set_dim_move_value_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimMoveValueModLock
                | o Sub SetDimMoveValueModLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Move Value Modification
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimMoveValueModLock(i_locked)

    def set_dim_o_run_cre_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimORunCreLock
                | o Sub SetDimORunCreLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Over Run Creation parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimORunCreLock(i_locked)

    def set_dim_o_run_mod_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimORunModLock
                | o Sub SetDimORunModLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Over Run Modification
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimORunModLock(i_locked)

    def set_dim_ori_default_symb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimOriDefaultSymbLock
                | o Sub SetDimOriDefaultSymbLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Orientation Default Symbol
                | parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimOriDefaultSymbLock(i_locked)

    def set_dim_snapping_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimSnappingLock
                | o Sub SetDimSnappingLock(        iLocked)
                | 
                | Locks or unlocks the Dimension Snapping parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetDimSnappingLock(i_locked)

    def set_general_tol_class_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetGeneralTolClassLock
                | o Sub SetGeneralTolClassLock(        iLocked)
                | 
                | Locks or unlocks the Dimension general class parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetGeneralTolClassLock(i_locked)

    def set_highlight_def_annot_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHighlightDefAnnotLock
                | o Sub SetHighlightDefAnnotLock(        iLocked)
                | 
                | Locks or unlocks the Highlight Def Annot parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetHighlightDefAnnotLock(i_locked)

    def set_noa_creation_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNoaCreationLock
                | o Sub SetNoaCreationLock(        iLocked)
                | 
                | Locks or unlocks the Noa Creation parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetNoaCreationLock(i_locked)

    def set_non_semantic_allways_upgrade_general_tol_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNonSemanticAllwaysUpgradeGeneralTolLock
                | o Sub SetNonSemanticAllwaysUpgradeGeneralTolLock(        iLocked)
                | 
                | Locks or unlocks the Non Semantic Allways Upgrade general
                | tolerance parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetNonSemanticAllwaysUpgradeGeneralTolLock(i_locked)

    def set_non_semantic_allways_upgrade_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNonSemanticAllwaysUpgradeLock
                | o Sub SetNonSemanticAllwaysUpgradeLock(        iLocked)
                | 
                | Locks or unlocks the Non Semantic Allways Upgrade parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetNonSemanticAllwaysUpgradeLock(i_locked)

    def set_non_semantic_dim_allowed_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNonSemanticDimAllowedLock
                | o Sub SetNonSemanticDimAllowedLock(        iLocked)
                | 
                | Locks or unlocks the Non Semantic Dim Allowed parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetNonSemanticDimAllowedLock(i_locked)

    def set_non_semantic_marked_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNonSemanticMarkedLock
                | o Sub SetNonSemanticMarkedLock(        iLocked)
                | 
                | Locks or unlocks the Non Semantic Marked parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetNonSemanticMarkedLock(i_locked)

    def set_non_semantic_tol_allowed_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetNonSemanticTolAllowedLock
                | o Sub SetNonSemanticTolAllowedLock(        iLocked)
                | 
                | Locks or unlocks the Non Semantic Tol Allowed parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetNonSemanticTolAllowedLock(i_locked)

    def set_parameters_in_tree_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetParametersInTreeLock
                | o Sub SetParametersInTreeLock(        iLocked)
                | 
                | Locks or unlocks the Parameters in tree parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetParametersInTreeLock(i_locked)

    def set_rotation_snap_angle_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRotationSnapAngleLock
                | o Sub SetRotationSnapAngleLock(        iLocked)
                | 
                | Locks or unlocks the Rotation Snap Angle parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetRotationSnapAngleLock(i_locked)

    def set_rotation_snap_auto_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRotationSnapAutoLock
                | o Sub SetRotationSnapAutoLock(        iLocked)
                | 
                | Locks or unlocks the Rotation Snap Auto parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetRotationSnapAutoLock(i_locked)

    def set_sect_pattern_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSectPatternLock
                | o Sub SetSectPatternLock(        iLocked)
                | 
                | Locks or unlocks the Pattern of Visu setting parameter
                | value. Refer to for a detailed description.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetSectPatternLock(i_locked)

    def set_select_published_geometry_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSelectPublishedGeometryLock
                | o Sub SetSelectPublishedGeometryLock(        iLocked)
                | 
                | Locks or unlocks the Select Published Geometry parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetSelectPublishedGeometryLock(i_locked)

    def set_shifted_profile_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShiftedProfileLock
                | o Sub SetShiftedProfileLock(        iLocked)
                | 
                | Locks or unlocks the Shifted Profile parameter.
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetShiftedProfileLock(i_locked)

    def set_true_dimension_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTrueDimensionColor
                | o Sub SetTrueDimensionColor(        iValueR,
                |                                     iValueG,
                |                                     iValueB)
                | 
                | Sets the TrueDimensionColor parameter.
                |
                | Parameters:

                |
        :param i_value_r:
        :param i_value_g:
        :param i_value_b:
        :return:
        """
        return self.fta_setting_att.SetTrueDimensionColor(i_value_r, i_value_g, i_value_b)

    def set_true_dimension_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTrueDimensionColorLock
                | o Sub SetTrueDimensionColorLock(        iLocked)
                | 
                | Locks or unlocks the TrueDimensionColor parameter.
                | Role:Locks or unlocks the TrueDimensionColor parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetTrueDimensionColorLock(i_locked)

    def set_true_dimension_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTrueDimensionLock
                | o Sub SetTrueDimensionLock(        iLocked)
                | 
                | Locks or unlocks the TrueDimension parameter. Role:Locks or
                | unlocks the TrueDimension parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.fta_setting_att.SetTrueDimensionLock(i_locked)

    def __repr__(self):
        return f'FTASettingAtt()'
