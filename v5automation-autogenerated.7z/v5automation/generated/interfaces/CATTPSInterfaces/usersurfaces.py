#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class UserSurfaces(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.user_surfaces = com_object     

    def generate(self, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | Generate
                | o Func Generate(        iSupport) As
                | 
                | Use this method in a Part. Creates a new user surface and
                | adds it to the Surfaces collection.
                |
                | Parameters:
                | iSupport
                |    The first reference that will support the user surface
                |  
                | 
                |  Returns:
                |     The created user surface

                |                | Examples:
                | The following example creates a user surface names
                | NewUserSurf from the reference Ref in the Surfaces
                | collection of the rootPart part in the partDoc part
                | document. Set rootPart = partDoc.Part Set NewUserSurf =
                | rootPart.UserSurfaces.Add(Ref)

        :param i_support:
        :return:
        """
        return self.user_surfaces.Generate(i_support)

    def generate_in_a_product_ctx(self, i_product, i_prod_inst, i_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | GenerateInAProductCtx
                | o Func GenerateInAProductCtx(        iProduct,
                |                                      iProdInst,
                |                                      iSupport) As
                | 
                | Use this method in a Product. Creates a new user surface and
                | adds it to the Surfaces collection.
                |
                | Parameters:
                | iProduct
                |    The level on which you want to create annotation (part or product).
                |  
                |  iProdInst
                |    The product instance where there is the geometry.
                |  
                |  iSupport
                |    The first reference that will support the user surface
                |  
                | 
                |  Returns:
                |     The created user surface

                |
        :param i_product:
        :param i_prod_inst:
        :param i_support:
        :return:
        """
        return self.user_surfaces.GenerateInAProductCtx(i_product, i_prod_inst, i_support)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Find a user surface inside the collection.
                |
                | Parameters:
                | iIndex
                |    The position of the users surface in the collection
                |  
                | 
                |  Returns:
                |     The user surface that is in the iIndex position in the collection

                |
        :param i_index:
        :return:
        """
        return self.user_surfaces.Item(i_index)

    def make_user_surface_node(self, i_first_user_surf, i_second_user_surf):
        """
        .. note::
            CAA V5 Visual Basic help

                | MakeUserSurfaceNode
                | o Func MakeUserSurfaceNode(        iFirstUserSurf,
                |                                    iSecondUserSurf) As
                | 
                | Usefull to create a User Surface Node from two others User
                | Surface. Creates a new user surface and adds it to the
                | Surfaces collection.
                |
                | Parameters:
                | iFirstUserSurf
                |    The first User Surface to use.
                |  
                |  iSecondUserSurf
                |    The second User Surface to use.
                |  
                | 
                |  Returns:
                |     The created user surface

                |
        :param i_first_user_surf:
        :param i_second_user_surf:
        :return:
        """
        return self.user_surfaces.MakeUserSurfaceNode(i_first_user_surf, i_second_user_surf)

    def make_user_surface_node2(self, i_list_of_user_surfaces):
        """
        .. note::
            CAA V5 Visual Basic help

                | MakeUserSurfaceNode2
                | o Func MakeUserSurfaceNode2(        iListOfUserSurfaces) As
                | 
                | Usefull to create a User Surface Node from a list of User
                | Surfaces. Creates a new user surface and adds it to the
                | Surfaces collection.
                |
                | Parameters:
                | iListOfUserSurfaces
                |    The list User Surfaces to use.
                |  
                | 
                |  Returns:
                |     The created user surface

                |
        :param i_list_of_user_surfaces:
        :return:
        """
        return self.user_surfaces.MakeUserSurfaceNode2(i_list_of_user_surfaces)

    def __repr__(self):
        return f'UserSurfaces()'
