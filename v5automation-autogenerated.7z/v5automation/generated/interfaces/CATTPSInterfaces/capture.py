#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Capture(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIACapture

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.capture = com_object     

    @property
    def active_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActiveView
                | o Property ActiveView(    ) As
                | 
                | Retrieves the active view for the capture.
                |

        :return:
        """
        return self.capture.ActiveView

    @property
    def active_view_state(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActiveViewState
                | o Property ActiveViewState(    ) As
                | 
                | Retrieves the Active View state, saved or Not. The Active
                | View state describes what happens when Capture is displayed,
                | if TRUE, the active view of the tolerancing set is replaced
                | by the active view of the capture.
                |

        :return:
        """
        return self.capture.ActiveViewState

    @property
    def annotations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Annotations
                | o Property Annotations(    ) As
                | 
                | Retrieves the TPSs that are visualy managed by this Capture.
                |

        :return:
        """
        return self.capture.Annotations

    @property
    def camera(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Camera
                | o Property Camera(    ) As
                | 
                | Retrieves or sets a camera.
                |

        :return:
        """
        return self.capture.Camera

    @property
    def clipping_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingPlane
                | o Property ClippingPlane(    ) As
                | 
                | Retrieves the clipping plane state, activated or Not. The
                | Clipping plane state describes what happens when Capture is
                | displayed, if TRUE, the active view is used to define a
                | clipping plane. If FALSE, there is no clipping plane
                | applied.
                |

        :return:
        """
        return self.capture.ClippingPlane

    @property
    def current(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Current
                | o Property Current(    ) As
                | 
                | Retrieves the Capture state, current or Not.
                |

        :return:
        """
        return self.capture.Current

    @property
    def manage_hide_show_body(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ManageHideShowBody
                | o Property ManageHideShowBody(    ) As
                | 
                | Manage the visibility of Part instances, bodies and
                | geometrical sets across the Capture.
                |

        :return:
        """
        return self.capture.ManageHideShowBody

    @property
    def set(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Set
                | o Property Set(    ) As   (Read Only)
                | 
                | Retrieves tolerancing set the Capture belongs too.
                |

        :return:
        """
        return self.capture.Set

    @property
    def tps_views(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TPSViews
                | o Property TPSViews(    ) As
                | 
                | Retrieves the TPS Views that are visualy managed by this
                | Capture.
                |

        :return:
        """
        return self.capture.TPSViews

    @property
    def view_point(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewPoint
                | o Property ViewPoint(    ) As
                | 
                | Retrieves the ViewPoint state, saved or Not. The ViewPoint
                | state describes what happens when Capture is displayed, if
                | TRUE, the 3D Camera of the Capture is used to change the 3D
                | ViewPoint.
                |

        :return:
        """
        return self.capture.ViewPoint

    def display_capture(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayCapture
                | o Sub DisplayCapture(    )
                | 
                | Displays the Capture.
                |
                | Parameters:

                |
        :return:
        """
        return self.capture.DisplayCapture()

    def display_capture2(self, ib_apply_mirror):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayCapture2
                | o Sub DisplayCapture2(        ibApplyMirror)
                | 
                | Displays the Capture with mirroring annotations management.
                |
                | Parameters:
                | out
                |  boolean ibApplyMirror [out] Annotations mirroring management:
                |     TRUE: The annotations mirroring is activated.
                |     FALSE: The annotations mirroring is desactivated.

                |
        :param ib_apply_mirror:
        :return:
        """
        return self.capture.DisplayCapture2(ib_apply_mirror)

    def __repr__(self):
        return f'Capture()'
