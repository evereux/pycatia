#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CaptureFactory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface for the Capture Factory.This factory is implemented on the
                | Set  object. All the created Captures are added to the Set from which
                | this  interface is retrieved.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.capture_factory = com_object     

    def create_capture(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateCapture
                | o Func CreateCapture(    ) As
                | 
                | Create a Capture.
                |
                | Parameters:
                | oCapture
                |       The new created Capture.

                |
        :return:
        """
        return self.capture_factory.CreateCapture()

    def __repr__(self):
        return f'CaptureFactory()'
