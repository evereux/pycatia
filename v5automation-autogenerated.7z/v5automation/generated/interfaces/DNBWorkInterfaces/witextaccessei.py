#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class WITextAccessEI(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.wi_text_access_ei = com_object     

    def get_geom_refered_by_annotation(self, i_opor_act, i_assigned_ei_index, i_assignment_type, io_point_geom):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGeomReferedByAnnotation
                | o Sub GetGeomReferedByAnnotation(        iOporAct,
                |                                          iAssignedEIIndex,
                |                                          iAssignmentType,
                |                                          ioPointGeom)
                | 
                | Gets the underlying geometry associated to FTA Text
                | Annotation, an Engineering Intent which is added as an item
                | to operation or to a WIText activity.
                |
                | Parameters:
                | iOpOrAcr
                |        Flag to know whether assignment of EI is at operation level or at activity level.
                | 	Legal values:
                | 	1 :  Assignment is done at Operation level.
                |  	0 :  Assignment is done at Activity level.
                |  
                |  iAssignedEIIndex
                |        Index of EIs either assigned to operation or to activity.
                |  
                |  iAssignmentType
                |        Type of the Assignment (Item to the Process)
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_opor_act:
        :param i_assigned_ei_index:
        :param i_assignment_type:
        :param io_point_geom:
        :return:
        """
        return self.wi_text_access_ei.GetGeomReferedByAnnotation(i_opor_act, i_assigned_ei_index, i_assignment_type, io_point_geom)

    def __repr__(self):
        return f'WITextAccessEI()'
