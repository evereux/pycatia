#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class WorkGeneralSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing xxx.Role: Components that implement
                | DNBIAWorkGeneralSettingAtt are ...Do not use the
                | DNBIAWorkGeneralSettingAtt interface for such and such ClassReference,
                | Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.work_general_setting_att = com_object     

    @property
    def annotation_activity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnnotationActivity
                | o Property AnnotationActivity(    ) As
                | 
                | Returns or sets the AnnotationActivity parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.work_general_setting_att.AnnotationActivity

    @annotation_activity.setter
    def annotation_activity(self, value):
        """
            :param type value:
        """
        self.work_general_setting_att.AnnotationActivity = value 

    @property
    def dnbwi_num_column_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DNBWINumColumnList
                | o Property DNBWINumColumnList(    ) As
                | 
                | Returns the DNBWINumColumnList parameter. Ensure consistency
                | with the C++ interface to which the work is delegated.
                |

        :return:
        """
        return self.work_general_setting_att.DNBWINumColumnList

    @property
    def move_activity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MoveActivity
                | o Property MoveActivity(    ) As
                | 
                | Returns or sets the MoveActivity parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.work_general_setting_att.MoveActivity

    @move_activity.setter
    def move_activity(self, value):
        """
            :param type value:
        """
        self.work_general_setting_att.MoveActivity = value 

    @property
    def style_sheet_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | StyleSheetPath
                | o Property StyleSheetPath(    ) As
                | 
                | Returns or sets the StyleSheetPath parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.work_general_setting_att.StyleSheetPath

    @style_sheet_path.setter
    def style_sheet_path(self, value):
        """
            :param type value:
        """
        self.work_general_setting_att.StyleSheetPath = value 

    @property
    def text_activity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TextActivity
                | o Property TextActivity(    ) As
                | 
                | Returns or sets the TextActivity parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.work_general_setting_att.TextActivity

    @text_activity.setter
    def text_activity(self, value):
        """
            :param type value:
        """
        self.work_general_setting_att.TextActivity = value 

    @property
    def view_point_activity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewPointActivity
                | o Property ViewPointActivity(    ) As
                | 
                | Returns or sets the ViewPointActivity parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.work_general_setting_att.ViewPointActivity

    @view_point_activity.setter
    def view_point_activity(self, value):
        """
            :param type value:
        """
        self.work_general_setting_att.ViewPointActivity = value 

    @property
    def visibility_activity(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisibilityActivity
                | o Property VisibilityActivity(    ) As
                | 
                | Returns or sets the VisibilityActivity parameter. Ensure
                | consistency with the C++ interface to which the work is
                | delegated.
                |

        :return:
        """
        return self.work_general_setting_att.VisibilityActivity

    @visibility_activity.setter
    def visibility_activity(self, value):
        """
            :param type value:
        """
        self.work_general_setting_att.VisibilityActivity = value 

    def get_annotation_activity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAnnotationActivityInfo
                | o Func GetAnnotationActivityInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | AnnotationActivity parameter. Role:Retrieves the state of
                | the AnnotationActivity parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.work_general_setting_att.GetAnnotationActivityInfo(io_admin_level, io_locked)

    def get_dnbwi_num_column_list_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDNBWINumColumnListInfo
                | o Func GetDNBWINumColumnListInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | DNBWINumColumnList parameter. Role:Retrieves the state of
                | the DNBWINumColumnList parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.work_general_setting_att.GetDNBWINumColumnListInfo(io_admin_level, io_locked)

    def get_move_activity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMoveActivityInfo
                | o Func GetMoveActivityInfo(        ioAdminLevel,
                |                                    ioLocked) As
                | 
                | Retrieves environment informations for the MoveActivity
                | parameter. Role:Retrieves the state of the MoveActivity
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.work_general_setting_att.GetMoveActivityInfo(io_admin_level, io_locked)

    def get_style_sheet_path_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStyleSheetPathInfo
                | o Func GetStyleSheetPathInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the StyleSheetPath
                | parameter. Role:Retrieves the state of the StyleSheetPath
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.work_general_setting_att.GetStyleSheetPathInfo(io_admin_level, io_locked)

    def get_text_activity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTextActivityInfo
                | o Func GetTextActivityInfo(        ioAdminLevel,
                |                                    ioLocked) As
                | 
                | Retrieves environment informations for the TextActivity
                | parameter. Role:Retrieves the state of the TextActivity
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.work_general_setting_att.GetTextActivityInfo(io_admin_level, io_locked)

    def get_view_point_activity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewPointActivityInfo
                | o Func GetViewPointActivityInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment informations for the ViewPointActivity
                | parameter. Role:Retrieves the state of the ViewPointActivity
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.work_general_setting_att.GetViewPointActivityInfo(io_admin_level, io_locked)

    def get_visibility_activity_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetVisibilityActivityInfo
                | o Func GetVisibilityActivityInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | VisibilityActivity parameter. Role:Retrieves the state of
                | the VisibilityActivity parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.work_general_setting_att.GetVisibilityActivityInfo(io_admin_level, io_locked)

    def set_annotation_activity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAnnotationActivityLock
                | o Sub SetAnnotationActivityLock(        iLocked)
                | 
                | Locks or unlocks the AnnotationActivity parameter.
                | Role:Locks or unlocks the AnnotationActivity parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.work_general_setting_att.SetAnnotationActivityLock(i_locked)

    def set_dnbwi_num_column_list_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDNBWINumColumnListLock
                | o Sub SetDNBWINumColumnListLock(        iLocked)
                | 
                |
                | Parameters:

                |
        :param i_locked:
        :return:
        """
        return self.work_general_setting_att.SetDNBWINumColumnListLock(i_locked)

    def set_move_activity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMoveActivityLock
                | o Sub SetMoveActivityLock(        iLocked)
                | 
                | Locks or unlocks the MoveActivity parameter. Role:Locks or
                | unlocks the MoveActivity parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.work_general_setting_att.SetMoveActivityLock(i_locked)

    def set_style_sheet_path_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetStyleSheetPathLock
                | o Sub SetStyleSheetPathLock(        iLocked)
                | 
                | Locks or unlocks the StyleSheetPath parameter. Role:Locks or
                | unlocks the StyleSheetPath parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.work_general_setting_att.SetStyleSheetPathLock(i_locked)

    def set_text_activity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTextActivityLock
                | o Sub SetTextActivityLock(        iLocked)
                | 
                | Locks or unlocks the TextActivity parameter. Role:Locks or
                | unlocks the TextActivity parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.work_general_setting_att.SetTextActivityLock(i_locked)

    def set_view_point_activity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewPointActivityLock
                | o Sub SetViewPointActivityLock(        iLocked)
                | 
                | Locks or unlocks the ViewPointActivity parameter. Role:Locks
                | or unlocks the ViewPointActivity parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.work_general_setting_att.SetViewPointActivityLock(i_locked)

    def set_visibility_activity_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVisibilityActivityLock
                | o Sub SetVisibilityActivityLock(        iLocked)
                | 
                | Locks or unlocks the VisibilityActivity parameter.
                | Role:Locks or unlocks the VisibilityActivity parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.work_general_setting_att.SetVisibilityActivityLock(i_locked)

    def __repr__(self):
        return f'WorkGeneralSettingAtt()'
