#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class WIBuyOff(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.wi_buy_off = com_object     

    def get_parameters_list(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetParametersList
                | o Func GetParametersList(    ) As
                | 
                | Gets a List of Parameters defined on this activity Role:
                | Gets a List of Parameters defined on this activity
                |
                | Parameters:
                | iPath
                |        a CATSafeArrayVariant of CATBSTR that has the list of Parameters.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :return:
        """
        return self.wi_buy_off.GetParametersList()

    def set_parameters_list(self, i_list_of_parameters):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetParametersList
                | o Sub SetParametersList(        iListOfParameters)
                | 
                | Sets a List of Parameters defined on this activity Role:
                | Sets a List of Parameters defined on this activity
                |
                | Parameters:
                | iPath
                |        a CATSafeArrayVariant of CATBSTR that has the list of Parameters.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_list_of_parameters:
        :return:
        """
        return self.wi_buy_off.SetParametersList(i_list_of_parameters)

    def __repr__(self):
        return f'WIBuyOff()'
