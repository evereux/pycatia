#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class WIText(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.wi_text = com_object     

    @property
    def fixed_text(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FixedText
                | o Property FixedText(    ) As
                | 
                | Returns or sets the value for 'Fixed Text' Role: Returns or
                | sets the value of 'Fixed Text' to the Activity
                |

        :return:
        """
        return self.wi_text.FixedText

    @fixed_text.setter
    def fixed_text(self, value):
        """
            :param type value:
        """
        self.wi_text.FixedText = value 

    @property
    def resolved_text(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ResolvedText
                | o Property ResolvedText(    ) As
                | 
                | Returns or sets the value for 'ResolvedText Text' Role:
                | Returns or sets the value of 'ResolvedText Text' to the
                | Activity
                |

        :return:
        """
        return self.wi_text.ResolvedText

    @resolved_text.setter
    def resolved_text(self, value):
        """
            :param type value:
        """
        self.wi_text.ResolvedText = value 

    @property
    def unresolved_text(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnresolvedText
                | o Property UnresolvedText(    ) As
                | 
                | Returns or sets the value for 'UnresolvedText Text' Role:
                | Returns or sets the value of 'UnresolvedText Text' to the
                | Activity
                |

        :return:
        """
        return self.wi_text.UnresolvedText

    @unresolved_text.setter
    def unresolved_text(self, value):
        """
            :param type value:
        """
        self.wi_text.UnresolvedText = value 

    def get_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAttribute
                | o Func GetAttribute(        iAttrName) As
                | 
                | This gets the value of the Attribute.
                |
                | Parameters:
                | iAttrName
                |     The Attribute Name whose value we need to get
                |  
                |  iAttrValue
                |     CATUnicodeString value of the Attribute

                |
        :param i_attr_name:
        :return:
        """
        return self.wi_text.GetAttribute(i_attr_name)

    def get_geom_associated_to_annotation(self, i_assignment_type, io_point_geom):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetGeomAssociatedToAnnotation
                | o Sub GetGeomAssociatedToAnnotation(        iAssignmentType,
                |                                             ioPointGeom)
                | 
                | Gets the underlying geometry associated to FTA Text
                | Annotation which is added as an item to operation of one
                | WIText Activity or added as item to a WIText activity. This
                | should be used in case when FTA Text Annotation is
                | associated to single geometric entity.
                |
                | Parameters:
                | iAssignmentType
                |        Point geometry associated to FTA text.
                |  
                |  iAssignmentType
                |        Type of the Assignment (Item to the Process)
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_assignment_type:
        :param io_point_geom:
        :return:
        """
        return self.wi_text.GetGeomAssociatedToAnnotation(i_assignment_type, io_point_geom)

    def get_hyper_links(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHyperLinks
                | o Func GetHyperLinks(    ) As
                | 
                | Retrieves the List of Hyperlinks associated to this activity
                | Role: Retrieves the List of Hyperlinks associated to this
                | activity
                |
                | Parameters:
                | ioPath
                |        a CATSafeArrayVariant of CATBSTR that has the list of Hyperlinks
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :return:
        """
        return self.wi_text.GetHyperLinks()

    def set_attribute(self, i_attr_name, i_attr_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAttribute
                | o Sub SetAttribute(        iAttrName,
                |                            iAttrValue)
                | 
                | This sets the value of the Attribute
                |
                | Parameters:
                | iAttrName
                |     The Attribute Name whose value we need to get
                |  
                |  iAttrValue
                |     CATUnicodeString value of the Attribute

                |
        :param i_attr_name:
        :param i_attr_value:
        :return:
        """
        return self.wi_text.SetAttribute(i_attr_name, i_attr_value)

    def set_hyper_links(self, i_hyperlinks):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHyperLinks
                | o Sub SetHyperLinks(        iHyperlinks)
                | 
                | Sets a List of Hyperlinks to this activity Role: Sets the
                | List of Hyperlinks to this activity
                |
                | Parameters:
                | iPath
                |        a CATSafeArrayVariant of CATBSTR that has the list of Hyperlinks.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_hyperlinks:
        :return:
        """
        return self.wi_text.SetHyperLinks(i_hyperlinks)

    def __repr__(self):
        return f'WIText()'
