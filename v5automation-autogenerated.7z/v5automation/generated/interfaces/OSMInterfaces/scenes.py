#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Scenes(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of scenes contained in a given ProductDocument.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.scenes = com_object     

    def add_copy_scene(self, i_name, i_reference_scene):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddCopyScene
                | o Func AddCopyScene(        iName,
                |                             iReferenceScene) As
                | 
                | Creates a scene from another and adds it to the Scenes
                | collection.
                |
                | Parameters:
                | iName
                |     The name of the scene
                |  
                |  iReferenceScene
                |     The scene to be copied
                |  
                | 
                |  Returns:
                |      The created scene

                |                | Examples:
                | This example creates the Engine scene from the SpareWheel
                | scene and adds the scene to the ToolKits collection. Dim
                | Engine As Scene Set Engine = ToolKits.AddNewScene("Engine",
                | SpareWheel)

        :param i_name:
        :param i_reference_scene:
        :return:
        """
        return self.scenes.AddCopyScene(i_name, i_reference_scene)

    def add_new_scene(self, i_name, i_reference_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewScene
                | o Func AddNewScene(        iName,
                |                            iReferenceProduct) As
                | 
                | Creates a scene from a product and adds it to the Scenes
                | collection.
                |
                | Parameters:
                | iName
                |     The name of the scene
                |  
                |  iReferenceProduct
                |     The product used as reference
                |  
                | 
                |  Returns:
                |      The created scene

                |                | Examples:
                | This example creates the SpareWheel scene from the reference
                | product FrontRightWheel and adds the scene to the ToolKits
                | collection. Dim SpareWheel As Scene Set SpareWheel =
                | ToolKits.AddNewScene("SpareWheel", FrontRightWheel)

        :param i_name:
        :param i_reference_product:
        :return:
        """
        return self.scenes.AddNewScene(i_name, i_reference_product)

    def remove(self, i_scene):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iScene)
                | 
                | Removes a scene from the Scenes collection.
                |
                | Parameters:
                | iScene
                |    The scene to remove.

                |                | Examples:
                | This example removes the Engine scene from the ToolKits
                | collection. ToolKits.Remove Engine

        :param i_scene:
        :return:
        """
        return self.scenes.Remove(i_scene)

    def __repr__(self):
        return f'Scenes()'
