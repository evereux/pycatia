#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ProductScenes(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection of ProductScenes contained in a given ProductDocument.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.product_scenes = com_object     

    def add_product_scene_full(self, i_name, i_reference_products):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddProductSceneFull
                | o Func AddProductSceneFull(        iName,
                |                                    iReferenceProducts) As
                | 
                | Creates a new FULL scene from a set of products and adds it
                | to the ProductScenes collection.
                |
                | Parameters:
                | iName
                |     The name of the new scene
                |  
                |  iReferenceProducts
                |     Products used as root nodes of the new scene
                |  
                | 
                |  Returns:
                |      The created new full scene

                |                | Examples:
                | This example creates the SpareWheel new scene from the
                | reference product FrontRightWheel and adds the scene to the
                | ToolKits collection. Dim SpareWheel As ProductScene Set
                | SpareWheel = ToolKits.AddProductSceneFull("SpareWheel",
                | FrontRightWheel)

        :param i_name:
        :param i_reference_products:
        :return:
        """
        return self.product_scenes.AddProductSceneFull(i_name, i_reference_products)

    def add_product_scene_partial(self, i_name, i_reference_products):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddProductScenePartial
                | o Func AddProductScenePartial(        iName,
                |                                       iReferenceProducts) As
                | 
                | Creates a new DELTA scene from a set of products and adds it
                | to the ProductScenes collection.
                |
                | Parameters:
                | iName
                |     The name of the new scene
                |  
                |  iReferenceProducts
                |     Products used as root nodes of the new scene
                |  
                | 
                |  Returns:
                |      The created new delta scene

                |                | Examples:
                | This example creates the SpareWheel new scene from the
                | reference product FrontRightWheel and adds the scene to the
                | ToolKits collection. Dim SpareWheel As ProductScene Set
                | SpareWheel = ToolKits.AddProductScenePartial("SpareWheel",
                | FrontRightWheel)

        :param i_name:
        :param i_reference_products:
        :return:
        """
        return self.product_scenes.AddProductScenePartial(i_name, i_reference_products)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns a scene using its index or its name from the
                | ProductScenes collection.
                |
                | Parameters:
                | iIndex
                |     The index or the name of the ProductScene to retrieve from the collection of ProductScenes.
                |     As a numerics, this index is the rank of the ProductScene in the collection.
                |     The index of the first ProductScene in the collection is 1, and
                |     the index of the last ProductScene is Count.
                |     As a string, it is the name you assigned to the ProductScene.
                |  
                | 
                |  Returns:
                |      The retrieved ProductScene.

                |                | Examples:
                | This example retrieves in ThisProductScene the ninth
                | ProductScene, and in ThatProductScene the ProductScene named
                | ProductScene3 from the TheProductScenes collection. Dim
                | ThisProductScene As ProductScene Set ThisProductScene =
                | TheProductScenes.Item(9) Dim ThatProductScene As
                | ProductScene Set ThatProductScene =
                | TheProductScenes.Item("ProductScene3")

        :param i_index:
        :return:
        """
        return self.product_scenes.Item(i_index)

    def remove(self, i_product_scene):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iProductScene)
                | 
                | Removes a product-scene from the ProductScenes collection.
                |
                | Parameters:
                | iScene
                |    The scene to remove.

                |                | Examples:
                | This example removes the Engine product-scene from the
                | ToolKits collection. ToolKits.Remove Engine

        :param i_product_scene:
        :return:
        """
        return self.product_scenes.Remove(i_product_scene)

    def __repr__(self):
        return f'ProductScenes()'
