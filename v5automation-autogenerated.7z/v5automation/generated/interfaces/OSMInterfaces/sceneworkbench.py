#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class SceneWorkbench(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the access point to scenes management.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.scene_workbench = com_object     

    @property
    def work_scenes(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WorkScenes
                | o Property WorkScenes(    ) As   (Read Only)
                | 
                | Returns the Scenes collection. Example: This example
                | retrieves the WorkScenes collection of the active document.
                | Dim TheWorkSceneWorkbench As Workbench Set
                | TheWorkSceneWorkbench = CATIA.ActiveDocument.GetWorkbench (
                | "SceneWorkbench" ) Dim TheScenesList As WorkScenes Set
                | TheScenesList = TheWorkSceneWorkbench.WorkScenes
                |

        :return:
        """
        return self.scene_workbench.WorkScenes

    def __repr__(self):
        return f'SceneWorkbench()'
