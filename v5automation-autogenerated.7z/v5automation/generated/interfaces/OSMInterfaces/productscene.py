#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ProductScene(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represent the Product-Scene.A Product-Scene stores a state of a
                | product in a given ProductDocument.This state is composed of product
                | properties, graphical attibutes, activation status and position for
                | each component of the product.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.product_scene = com_object     

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the type of the Product-Scene. Example: This example
                | reads the type of NewSceneDelta Product-Scene. Dim type As
                | CatSceneType type = NewSceneDelta.Type
                |

        :return:
        """
        return self.product_scene.Type

    def copy(self, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | Copy
                | o Func Copy(        iType) As
                | 
                | Creates another Product-Scene from the current one with the
                | possibility to have a different mode.
                |
                | Parameters:
                | iType
                |     The Product-Scene type
                |  
                | 
                |  Returns:
                |      The Product-Scene created from the current one.

                |                | Examples:
                | This example returns whether the CopyScene Product-Scene
                | created from the Configuration1 Product-Scene, with the
                | DELTA mode. Dim type As CatSceneType type =
                | CatSceneTypeDelta Dim CopyScene As ProductScene CopyScene =
                | Configuration1.Copy(type)

        :param i_type:
        :return:
        """
        return self.product_scene.Copy(i_type)

    def exists_in_scene(self, i_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExistsInScene
                | o Func ExistsInScene(        iProduct) As
                | 
                | Returns whether the product has overloaded attributes in the
                | Product-Scene.
                |
                | Parameters:
                | iProduct
                |     The product
                |  
                | 
                |  Returns:
                |      True if the Product-Scene overloads some of the product attributes.

                |                | Examples:
                | This example returns whether the Engine product exists in
                | the Configuration1 Product-Scene. ExistsInSc =
                | Configuration1.ExistsInScene(Engine)

        :param i_product:
        :return:
        """
        return self.product_scene.ExistsInScene(i_product)

    def get_scene_product_data(self, i_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSceneProductData
                | o Func GetSceneProductData(        iProduct) As
                | 
                | Returns the SceneProductData associated to the given product
                | in the Product-Scene. If it does not exist yet, it is
                | created.
                |
                | Parameters:
                | iProduct
                |     The product
                |  
                | 
                |  Returns:
                |      The SceneProductData associated to the given product.

                |                | Examples:
                | This example returns SceneProductData associated to Engine
                | in the NewSceneDelta Product-Scene. Dim scenePrd As
                | SceneProductData type =
                | NewSceneDelta.GetSceneProductData(Engine)

        :param i_product:
        :return:
        """
        return self.product_scene.GetSceneProductData(i_product)

    def __repr__(self):
        return f'ProductScene()'
