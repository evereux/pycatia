#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class SceneProductData(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIASceneProduct

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.scene_product_data = com_object     

    @property
    def activation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activation
                | o Property Activation(    ) As
                | 
                | Returns / Set the scene product's activation state. Example:
                | This example retrieves the activation state of the scenePrd
                | SceneProductData. IsActivated = scenePrd.Hidden
                |

        :return:
        """
        return self.scene_product_data.Activation

    @property
    def hidden(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Hidden
                | o Property Hidden(    ) As
                | 
                | Returns / Set the scene product's hide/show mode. Example:
                | This example retrieves the hide/show mode of the scenePrd
                | SceneProductData. IsHidden = scenePrd.Hidden
                |

        :return:
        """
        return self.scene_product_data.Hidden

    @property
    def move(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Move
                | o Property Move(    ) As   (Read Only)
                | 
                | Returns the scene product's move object. It aggregates a
                | movable object to which you can apply a move transformation
                | by means of an isometry matrix. It moves your product shape
                | representation according to this isometry. Example: This
                | example retrieves the EngineMove move in the scenePrd
                | SceneProductData. Dim EngineMove As Move Set EngineMove =
                | scenePrd.GetMove
                |

        :return:
        """
        return self.scene_product_data.Move

    @property
    def position(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Position
                | o Property Position(    ) As   (Read Only)
                | 
                | Returns the scene product's position object. The position
                | object is the object aggregated by the SceneProductData
                | object that holds the position of the master shape
                | representation in the space in scene. Example: This example
                | retrieves the EnginePosition position in the scenePrd
                | SceneProductData. Dim EnginePosition As Position Set
                | EnginePosition = scenePrd.GetPosition
                |

        :return:
        """
        return self.scene_product_data.Position

    def get_real_color(self, o_red, o_green, o_blue, o_inheritance):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRealColor
                | o Sub GetRealColor(        oRed,
                |                            oGreen,
                |                            oBlue,
                |                            oInheritance)
                | 
                | Returns / Set the scene product's color and inheritance.
                |
                | Parameters:
                | iRed
                |   A value between 0 and 255
                |  
                |  iGreen
                |   A value between 0 and 255
                |  
                |  iBlue
                |   A value between 0 and 255
                |  
                |  iInheritance
                |  Legal value:
                | 
                | 0
                | No heritance 
                |  1
                | Heritance

                |                | Examples:
                | This example retrieves the activation state of the scenePrd
                | SceneProductData. Dim r, g, b, inh scenePrd.GetRealColor r,
                | g, b, inh

        :param o_red:
        :param o_green:
        :param o_blue:
        :param o_inheritance:
        :return:
        """
        return self.scene_product_data.GetRealColor(o_red, o_green, o_blue, o_inheritance)

    def set_real_color(self, i_red, i_green, i_blue, i_inheritance):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRealColor
                | o Sub SetRealColor(        iRed,
                |                            iGreen,
                |                            iBlue,
                |                            iInheritance)
                | 
                | Returns / Set the scene product's color and inheritance.
                |
                | Parameters:
                | iRed
                |   A value between 0 and 255
                |  
                |  iGreen
                |   A value between 0 and 255
                |  
                |  iBlue
                |   A value between 0 and 255
                |  
                |  iInheritance
                |  Legal value:
                | 
                | 0
                | No heritance 
                |  1
                | Heritance

                |                | Examples:
                | This example retrieves the activation state of the scenePrd
                | SceneProductData. scenePrd.SetRealColor 255,0,0,1

        :param i_red:
        :param i_green:
        :param i_blue:
        :param i_inheritance:
        :return:
        """
        return self.scene_product_data.SetRealColor(i_red, i_green, i_blue, i_inheritance)

    def __repr__(self):
        return f'SceneProductData()'
