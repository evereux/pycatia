#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class StiDBChildren(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents all the Children of a CATIAStiDBItem.For each Child, we are
                | able to retrieve its associated CATIAStiDBItem and the Link Type
                | (between itself and its father).It should be represented as the
                | following Correspondance Table { Child Number / CATIAStiDBItem / Link
                | Type}.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.sti_db_children = com_object     

    @property
    def count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Count
                | o Property Count(    ) As   (Read Only)
                | 
                | Returns the Number of Children currently gathered in
                | CATIAStiDBChildren. Returns: This output corresponds to the
                | Children Number of a CATIAStiDBItem. Example: This example
                | retrieves in lChildrenNumber the Number of children
                | currently gathered in oStiDBChildren. Dim oStiEngine As
                | StiEngine Set oStiEngine = CATIA.GetItem("CAIEngine") Dim
                | oStiDBItem As StiDBItem Set oStiDBItem = oStiEngine.GetStiDB
                | ItemFromCATBSTR("E:\CATIAFiles\Assembly.CATProduct") Dim
                | oStiDBChildren As StiDBChildren Set oStiDBChildren =
                | oStiDBItem.GetChildren() (...) Dim oNbChildren As long
                | oNbChildren = oStiDBChildren.Count
                |

        :return:
        """
        return self.sti_db_children.Count

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns the CATIAStiDBItem from its index in the
                | CATIAStiDBChildren.
                |
                | Parameters:
                | iIndex
                |    This input corresponds to the Index of the CATIAStiDBItem to retrieve from the CATIAStiDBChildren.
                |    This index is the rank of the CATIAStiDBItem in the CATIAStiDBChildren -list of all the Children of a CATIAStiDBItem.
                |    The index of the first CATIAStiDBItem is '1' and the index of the last CATIAStiDBItem is 'Count'.
                |  
                | 
                |  Returns:
                |      This ouptut corresponds to the retrieved CATIAStiDBItem from its index.

                |                | Examples:
                | The following example returns in oChildStiDBItem the third
                | CATIAStiDBItem gathered in oStiDBChildren. Dim oStiEngine As
                | StiEngine Set oStiEngine = CATIA.GetItem("CAIEngine") Dim
                | oFatherStiDBItem As StiDBItem Set oFatherStiDBItem = oStiEng
                | ine.GetStiDBItemFromCATBSTR("E:\CATIAFiles\Assembly.CATProdu
                | ct") Dim oStiDBChildren As StiDBChildren Set oStiDBChildren
                | = oFatherStiDBItem.GetChildren() (...) Dim oStiDBItem As
                | StiDBItem Set oStiDBItem = oStiDBChildren.Item(3)

        :param i_index:
        :return:
        """
        return self.sti_db_children.Item(i_index)

    def link_type(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | LinkType
                | o Func LinkType(        iIndex) As
                | 
                | Returns the Link Type from its index in the
                | CATIAStiDBChildren.
                |
                | Parameters:
                | iIndex
                |    This input corresponds to the index of the Link Type to retrieve from the CATIAStiDBChildren.
                |    This index is the rank of the Link Type in the CATIAStiDBChildren.
                |    The index of the first Link Type is '1' and the index of the last Link Type is 'Count'.
                |  
                | 
                |  Returns:
                |      This ouptut corresponds to the retrieved Link Type from its index.

                |                | Examples:
                | The following example returns in oLinkType the third Link
                | Type gathered in oStiDBChildren. Dim oStiEngine As StiEngine
                | Set oStiEngine = CATIA.GetItem("CAIEngine") Dim
                | oFatherStiDBItem As StiDBItem Set oFatherStiDBItem = oStiEng
                | ine.GetStiDBItemFromCATBSTR("E:\CATIAFiles\Assembly.CATProdu
                | ct") Dim oStiDBChildren As StiDBChildren Set oStiDBChildren
                | = oFatherStiDBItem.GetChildren() (...) Dim oLinkType As
                | CATBSTR oLinkType = oStiDBChildren.LinkType(3)

        :param i_index:
        :return:
        """
        return self.sti_db_children.LinkType(i_index)

    def __repr__(self):
        return f'StiDBChildren()'
