#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Replay(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAReplay

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.replay = com_object     

    def add_product_motion(self, i_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddProductMotion
                | o Func AddProductMotion(        iProduct) As
                | 
                | Adds a product to be taken into account in the Replay
                | object.
                |
                | Parameters:
                | iProduct
                | 	CATIAProduct. Product to add.
                |  
                |  oChannel
                | 	Channel number.

                |
        :param i_product:
        :return:
        """
        return self.replay.AddProductMotion(i_product)

    def add_sample(self, i_channel, i_current_time, i_position):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddSample
                | o Sub AddSample(        iChannel,
                |                         iCurrentTime,
                |                         iPosition)
                | 
                | Adds a sample(set of values) for a channel at a specific
                | time
                |
                | Parameters:
                | iChannel
                | 	Channel number.
                |  
                |  iCurrentTime
                | 	Time.
                |  
                |  iPosition
                | 	Array of values to consider the the specified channel.

                |
        :param i_channel:
        :param i_current_time:
        :param i_position:
        :return:
        """
        return self.replay.AddSample(i_channel, i_current_time, i_position)

    def get_nb_product_motion(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNbProductMotion
                | o Func GetNbProductMotion(    ) As
                | 
                | Get the number of channel related to products.
                |
                | Parameters:
                | oNbChannel
                | 	Number of channel associated to products.

                |
        :return:
        """
        return self.replay.GetNbProductMotion()

    def get_nb_sample(self, i_channel):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNbSample
                | o Func GetNbSample(        iChannel) As
                | 
                | Get the number of samples for a channel number.
                |
                | Parameters:
                | iChannel
                | 	Channel index.
                |  
                |  oNbSample
                | 	Number of samples.

                |
        :param i_channel:
        :return:
        """
        return self.replay.GetNbSample(i_channel)

    def get_product(self, i_channel):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProduct
                | o Func GetProduct(        iChannel) As
                | 
                | Get the product for a channel.
                |
                | Parameters:
                | iChannel
                | 	Channel index.
                |  
                |  oProduct
                | 	Product.

                |
        :param i_channel:
        :return:
        """
        return self.replay.GetProduct(i_channel)

    def get_sample_position(self, i_channel, i_sample, o_position):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSamplePosition
                | o Sub GetSamplePosition(        iChannel,
                |                                 iSample,
                |                                 oPosition)
                | 
                | Get the sample values.
                |
                | Parameters:
                | iChannel
                | 	Channel index.
                |  
                |  iSample
                | 	Sample index.
                |  
                |  oPosition
                | 	Array of values.

                |
        :param i_channel:
        :param i_sample:
        :param o_position:
        :return:
        """
        return self.replay.GetSamplePosition(i_channel, i_sample, o_position)

    def get_sample_time(self, i_channel, i_sample):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSampleTime
                | o Func GetSampleTime(        iChannel,
                |                              iSample) As
                | 
                | Get the sample time.
                |
                | Parameters:
                | iChannel
                | 	Channel index.
                |  
                |  iSample
                | 	Sample index.
                |  
                |  oTime
                | 	Time value.

                |
        :param i_channel:
        :param i_sample:
        :return:
        """
        return self.replay.GetSampleTime(i_channel, i_sample)

    def remove_sample(self, i_channel, i_sample):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveSample
                | o Sub RemoveSample(        iChannel,
                |                            iSample)
                | 
                | Remove a specific sample.
                |
                | Parameters:
                | iChannel
                | 	Channel index.
                |  
                |  iSample
                | 	Sample index.

                |
        :param i_channel:
        :param i_sample:
        :return:
        """
        return self.replay.RemoveSample(i_channel, i_sample)

    def __repr__(self):
        return f'Replay()'
