#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ProcessDocument(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | This interface is used to access the PPRDocument and to add a new
                | library.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.process_document = com_object     

    @property
    def dnb_3d_state_position_management(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DNB3DStatePositionManagement
                | o Property DNB3DStatePositionManagement(    ) As   (Read Only)
                | 
                | Retrieves the interface which manages the 3D state
                | positions. Returns: The DNBIA3DStatePositionManagement
                | corresponding to the current Process document.
                |

        :return:
        """
        return self.process_document.DNB3DStatePositionManagement

    @property
    def ppr_document(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PPRDocument
                | o Property PPRDocument(    ) As   (Read Only)
                | 
                | Retrieves the interface which manages the PPRDocument.
                | Returns: The PPRDocument corresponding to the current
                | Process document.
                |

        :return:
        """
        return self.process_document.PPRDocument

    def add_library(self, i_file_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddLibrary
                | o Sub AddLibrary(        iFileName)
                | 
                | Adds a new library to the current Process document.
                |
                | Parameters:
                | iFileName
                |  The name of the library to be added.

                |
        :param i_file_name:
        :return:
        """
        return self.process_document.AddLibrary(i_file_name)

    def __repr__(self):
        return f'ProcessDocument()'
