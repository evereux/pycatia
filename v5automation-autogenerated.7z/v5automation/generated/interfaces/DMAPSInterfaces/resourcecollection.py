#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ResourceCollection(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface representing collection of Resources.Role: Components that
                | implement CATIAResourceCollection are ...Do not use the
                | CATIAResourceCollection interface for such and such ClassReference,
                | Class#MethodReference, #InternalMethod...

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.resource_collection = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | This method gets the specified resource from the given
                | resource collection management.
                |
                | Parameters:
                | iIndex
                |  The resource identifier
                |  
                | 
                |  Returns:
                |   oResource The resource

                |
        :param i_index:
        :return:
        """
        return self.resource_collection.Item(i_index)

    def __repr__(self):
        return f'ResourceCollection()'
