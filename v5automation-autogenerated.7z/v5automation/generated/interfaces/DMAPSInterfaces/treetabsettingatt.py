#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class TreeTabSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.tree_tab_setting_att = com_object     

    @property
    def applicative_data_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplicativeDataFilter
                | o Property ApplicativeDataFilter(    ) As
                | 
                | Returns of sets the value to signify Whether "Applicative
                | Data" created by an application is visible in the PPR tree
                | Role: Returns or sets the value of "Applicative Data" option
                | to signify whether the applicative containers are visualized
                | in the PPR tree
                |

        :return:
        """
        return self.tree_tab_setting_att.ApplicativeDataFilter

    @applicative_data_filter.setter
    def applicative_data_filter(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.ApplicativeDataFilter = value 

    @property
    def assigned_viewer(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AssignedViewer
                | o Property AssignedViewer(    ) As
                | 
                | Returns or sets the value to signify whether the 3D Assigned
                | Viewer is default viewer or not Role: Returns or sets the
                | value to signify whether 3D Assigned Viewer is default
                | viewer or not
                |

        :return:
        """
        return self.tree_tab_setting_att.AssignedViewer

    @assigned_viewer.setter
    def assigned_viewer(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.AssignedViewer = value 

    @property
    def attributes_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AttributesFilter
                | o Property AttributesFilter(    ) As
                | 
                | Returns or sets the value for "Attributes" option Role:
                | Returns or sets the value of "Attributes" option to signify
                | whether the 'User Attributes' of an Activity is visualized
                | in the PPR tree
                |

        :return:
        """
        return self.tree_tab_setting_att.AttributesFilter

    @attributes_filter.setter
    def attributes_filter(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.AttributesFilter = value 

    @property
    def collapse_expand_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CollapseExpandFilter
                | o Property CollapseExpandFilter(    ) As
                | 
                | Returns or sets the value to signify Whether the double
                | clicking on an activity expands/collapses a given activity
                | in the PPR tree Role: Returns or sets the value to signify
                | Whether the double clicking on an activity expands/collapses
                | a given activity in the PPR tree
                |

        :return:
        """
        return self.tree_tab_setting_att.CollapseExpandFilter

    @collapse_expand_filter.setter
    def collapse_expand_filter(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.CollapseExpandFilter = value 

    @property
    def display_name_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayNameMode
                | o Property DisplayNameMode(    ) As
                | 
                | Returns or sets the value to signify whether the E5
                | Configured Name is to be displayed Role: Returns or sets the
                | value to signify whether the E5 Configured Name is to be
                | displayed
                |

        :return:
        """
        return self.tree_tab_setting_att.DisplayNameMode

    @display_name_mode.setter
    def display_name_mode(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.DisplayNameMode = value 

    @property
    def display_order(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayOrder
                | o Property DisplayOrder(    ) As
                | 
                | Returns or sets the value for 'Display Order' Role: Returns
                | or sets the value of 'Display Order' to signify which order
                | the product/resource list are in the PPR tree
                |

        :return:
        """
        return self.tree_tab_setting_att.DisplayOrder

    @display_order.setter
    def display_order(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.DisplayOrder = value 

    @property
    def display_process_order(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayProcessOrder
                | o Property DisplayProcessOrder(    ) As
                | 
                | Returns or sets the value for 'Display Order for Processes'
                | Role: Returns or sets the value of 'Display Order for
                | Processes' to signify which order the processes under
                | ProcessList and ResourcesList are listed in the PPR tree.
                | Legal values: 1 : manufacturing hub order 0 : loaded order
                |

        :return:
        """
        return self.tree_tab_setting_att.DisplayProcessOrder

    @display_process_order.setter
    def display_process_order(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.DisplayProcessOrder = value 

    @property
    def items_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ItemsFilter
                | o Property ItemsFilter(    ) As
                | 
                | Returns or sets the value for 'Items Folder' Role: Returns
                | or sets the value of 'Items Folder' to signify whether the
                | 'Assigned Items' are visualized in the PPR tree
                |

        :return:
        """
        return self.tree_tab_setting_att.ItemsFilter

    @items_filter.setter
    def items_filter(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.ItemsFilter = value 

    @property
    def items_per_relation_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ItemsPerRelationFilter
                | o Property ItemsPerRelationFilter(    ) As
                | 
                | Returns or sets the value for 'Items Folder (Per Relation
                | Type)' Role: Returns or sets the value of 'Items Folder(Per
                | Relation Type)' to signify whether the 'Assigned Items'with
                | proper relations ( like First Processes Product) are
                | visualized in the PPR tree
                |

        :return:
        """
        return self.tree_tab_setting_att.ItemsPerRelationFilter

    @items_per_relation_filter.setter
    def items_per_relation_filter(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.ItemsPerRelationFilter = value 

    @property
    def logical_act_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LogicalActFilter
                | o Property LogicalActFilter(    ) As
                | 
                | Returns or sets the value to signify Whether the logical
                | activites are visible in the PPR tree Role: Returns or sets
                | the value of "Logical Activities" option to signify whether
                | the logical activites are visible in the PPR tree
                |

        :return:
        """
        return self.tree_tab_setting_att.LogicalActFilter

    @logical_act_filter.setter
    def logical_act_filter(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.LogicalActFilter = value 

    @property
    def output_product_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OutputProductFilter
                | o Property OutputProductFilter(    ) As
                | 
                | Returns of sets the value to signify Whether "Output
                | Products" assigned to a given activity is visible in the PPR
                | tree Role: Returns or sets the value of "Output Products
                | Folder" option to signify whether the output products
                | associated with an activity are visualized in the PPR tree
                |

        :return:
        """
        return self.tree_tab_setting_att.OutputProductFilter

    @output_product_filter.setter
    def output_product_filter(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.OutputProductFilter = value 

    @property
    def paste_same_instance(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PasteSameInstance
                | o Property PasteSameInstance(    ) As
                | 
                | Returns or sets the value for 'Paste Same Instance' Role:
                | Returns or sets the value of 'Paste Same Instance' to
                | signify whether a same product instance in the target
                | process document should be reused or not. Legal values: 1 :
                | Always paste an instance and do not reuse existing one 0 :
                | Reuse existing instance wherever possible
                |

        :return:
        """
        return self.tree_tab_setting_att.PasteSameInstance

    @paste_same_instance.setter
    def paste_same_instance(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.PasteSameInstance = value 

    @property
    def render_style(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RenderStyle
                | o Property RenderStyle(    ) As
                | 
                | Returns or sets the value to signify whether the 3D Render
                | Style is Parallel or Perspective Role: Returns or sets the
                | value to signify whether the 3D Render Style is Parallel or
                | Perspective
                |

        :return:
        """
        return self.tree_tab_setting_att.RenderStyle

    @render_style.setter
    def render_style(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.RenderStyle = value 

    @property
    def resource_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ResourceFilter
                | o Property ResourceFilter(    ) As
                | 
                | Returns or sets the value for 'Resources Folder' Role:
                | Returns or sets the value of 'Resources Folder' to signify
                | whether the 'Assigned Resources' are visualized in the PPR
                | tree
                |

        :return:
        """
        return self.tree_tab_setting_att.ResourceFilter

    @resource_filter.setter
    def resource_filter(self, value):
        """
            :param type value:
        """
        self.tree_tab_setting_att.ResourceFilter = value 

    def get_applicative_data_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetApplicativeDataFilterInfo
                | o Func GetApplicativeDataFilterInfo(        ioAdminLevel,
                |                                             ioLocked) As
                | 
                | Retrieves environment informations for the "Applicative
                | Data" parameter. Role:Retrieves the state of the
                | "Applicative Data" parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetApplicativeDataFilterInfo(io_admin_level, io_locked)

    def get_assigned_viewer_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAssignedViewerInfo
                | o Func GetAssignedViewerInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the "Assigned Viewer"
                | parameter. Role:Retrieves the state of the "Assigned Viewer"
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetAssignedViewerInfo(io_admin_level, io_locked)

    def get_attributes_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAttributesFilterInfo
                | o Func GetAttributesFilterInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the "Attributes"
                | parameter. Role:Retrieves the state of the "Attributes"
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetAttributesFilterInfo(io_admin_level, io_locked)

    def get_collapse_expand_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCollapseExpandFilterInfo
                | o Func GetCollapseExpandFilterInfo(        ioAdminLevel,
                |                                            ioLocked) As
                | 
                | Retrieves environment informations for the "Disable
                | Collapse/Expand" parameter. Role:Retrieves the state of the
                | "Disable Collapse/Expand" parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetCollapseExpandFilterInfo(io_admin_level, io_locked)

    def get_display_name_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayNameModeInfo
                | o Func GetDisplayNameModeInfo(        ioAdminLevel,
                |                                       ioLocked) As
                | 
                | Retrieves environment informations for the "Display Name
                | Mode" parameter. Role:Retrieves the state of the "Display
                | Name Mode" parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetDisplayNameModeInfo(io_admin_level, io_locked)

    def get_display_order_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayOrderInfo
                | o Func GetDisplayOrderInfo(        ioAdminLevel,
                |                                    ioLocked) As
                | 
                | Retrieves environment informations for the 'Display Order'
                | parameter. Role:Retrieves the state of the 'Display Order'
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetDisplayOrderInfo(io_admin_level, io_locked)

    def get_display_process_order_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayProcessOrderInfo
                | o Func GetDisplayProcessOrderInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves environment informations for the 'Display Order
                | for Processes' parameter. Role:Retrieves the state of the
                | 'Display Order for Processes' parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetDisplayProcessOrderInfo(io_admin_level, io_locked)

    def get_items_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetItemsFilterInfo
                | o Func GetItemsFilterInfo(        ioAdminLevel,
                |                                   ioLocked) As
                | 
                | Retrieves environment informations for the 'Items Folder'
                | parameter. Role:Retrieves the state of the 'Items Folder'
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetItemsFilterInfo(io_admin_level, io_locked)

    def get_items_per_relation_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetItemsPerRelationFilterInfo
                | o Func GetItemsPerRelationFilterInfo(        ioAdminLevel,
                |                                              ioLocked) As
                | 
                | Retrieves environment informations for the 'Items Folder(Per
                | Relation Type)' parameter. Role:Retrieves the state of the
                | 'Items Folder(Per Relation Type)' parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetItemsPerRelationFilterInfo(io_admin_level, io_locked)

    def get_logical_act_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLogicalActFilterInfo
                | o Func GetLogicalActFilterInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the "Logical
                | Activities" parameter. Role:Retrieves the state of the
                | "Logical Activities" parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetLogicalActFilterInfo(io_admin_level, io_locked)

    def get_output_product_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOutputProductFilterInfo
                | o Func GetOutputProductFilterInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves environment informations for the "Output Products
                | Folder" parameter. Role:Retrieves the state of the "Output
                | Products Folder" parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetOutputProductFilterInfo(io_admin_level, io_locked)

    def get_paste_same_instance_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPasteSameInstanceInfo
                | o Func GetPasteSameInstanceInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment information for the 'Paste Same
                | Instance' parameter. Role:Retrieves the state of the 'Paste
                | Same Instance' parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetPasteSameInstanceInfo(io_admin_level, io_locked)

    def get_render_style_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRenderStyleInfo
                | o Func GetRenderStyleInfo(        ioAdminLevel,
                |                                   ioLocked) As
                | 
                | Retrieves environment informations for the "Render Style"
                | parameter. Role:Retrieves the state of the "Render Style"
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetRenderStyleInfo(io_admin_level, io_locked)

    def get_resource_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetResourceFilterInfo
                | o Func GetResourceFilterInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the 'Resource Folder'
                | parameter. Role:Retrieves the state of the 'Resource Folder'
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.tree_tab_setting_att.GetResourceFilterInfo(io_admin_level, io_locked)

    def set_applicative_data_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetApplicativeDataFilterLock
                | o Sub SetApplicativeDataFilterLock(        iLocked)
                | 
                | Locks or unlocks the "Applicative Data" parameter.
                | Role:Locks or unlocks the "Attributes" parameter if it is
                | possible in the current administrative context. In user mode
                | this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetApplicativeDataFilterLock(i_locked)

    def set_assigned_viewer_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAssignedViewerLock
                | o Sub SetAssignedViewerLock(        iLocked)
                | 
                | Locks or unlocks the "Assigned Viewer" parameter. Role:Locks
                | or unlocks the "Assigned Viewer" parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetAssignedViewerLock(i_locked)

    def set_attributes_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAttributesFilterLock
                | o Sub SetAttributesFilterLock(        iLocked)
                | 
                | Locks or unlocks the "Attributes" parameter. Role:Locks or
                | unlocks the "Attributes" parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetAttributesFilterLock(i_locked)

    def set_collapse_expand_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCollapseExpandFilterLock
                | o Sub SetCollapseExpandFilterLock(        iLocked)
                | 
                | Locks or unlocks the "Disable Collapse/Expand" parameter.
                | Role:Locks or unlocks the "Disable Collapse/Expand"
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetCollapseExpandFilterLock(i_locked)

    def set_display_name_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayNameModeLock
                | o Sub SetDisplayNameModeLock(        iLocked)
                | 
                | Locks or unlocks the "Display Name Mode" parameter.
                | Role:Locks or unlocks the "Display Name Mode" parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetDisplayNameModeLock(i_locked)

    def set_display_order_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayOrderLock
                | o Sub SetDisplayOrderLock(        iLocked)
                | 
                | Locks or unlocks the 'Display Order' parameter. Role:Locks
                | or unlocks the 'Display Order' parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetDisplayOrderLock(i_locked)

    def set_display_process_order_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayProcessOrderLock
                | o Sub SetDisplayProcessOrderLock(        iLocked)
                | 
                | Locks or unlocks the 'Display Order for Processes'
                | parameter. Role:Locks or unlocks the 'Display Order for
                | Processes' parameter if it is possible in the current
                | administrative context. In user mode this method will always
                | return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetDisplayProcessOrderLock(i_locked)

    def set_items_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetItemsFilterLock
                | o Sub SetItemsFilterLock(        iLocked)
                | 
                | Locks or unlocks the 'Items Folder' parameter. Role:Locks or
                | unlocks the 'Items Folder' parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetItemsFilterLock(i_locked)

    def set_items_per_relation_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetItemsPerRelationFilterLock
                | o Sub SetItemsPerRelationFilterLock(        iLocked)
                | 
                | Locks or unlocks the 'Items Folde(Per Relation Type)r'
                | parameter. Role:Locks or unlocks the 'Items Folder(Per
                | Relation Type)' parameter if it is possible in the current
                | administrative context. In user mode this method will always
                | return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetItemsPerRelationFilterLock(i_locked)

    def set_logical_act_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLogicalActFilterLock
                | o Sub SetLogicalActFilterLock(        iLocked)
                | 
                | Locks or unlocks the "Logical Activities" parameter.
                | Role:Locks or unlocks the "Logical Activities" parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetLogicalActFilterLock(i_locked)

    def set_output_product_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOutputProductFilterLock
                | o Sub SetOutputProductFilterLock(        iLocked)
                | 
                | Locks or unlocks the "Output Products Folder" parameter.
                | Role:Locks or unlocks the "Output Products Folder" parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetOutputProductFilterLock(i_locked)

    def set_paste_same_instance_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPasteSameInstanceLock
                | o Sub SetPasteSameInstanceLock(        iLocked)
                | 
                | Locks or unlocks the 'Paste Same Instance' parameter.
                | Role:Locks or unlocks the 'Paste Same Instance' parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetPasteSameInstanceLock(i_locked)

    def set_render_style_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRenderStyleLock
                | o Sub SetRenderStyleLock(        iLocked)
                | 
                | Locks or unlocks the "Render Style" parameter. Role:Locks or
                | unlocks the "Render Style" parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetRenderStyleLock(i_locked)

    def set_resource_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetResourceFilterLock
                | o Sub SetResourceFilterLock(        iLocked)
                | 
                | Locks or unlocks the 'Resource Folder' parameter. Role:Locks
                | or unlocks the 'Resource Folder' parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.tree_tab_setting_att.SetResourceFilterLock(i_locked)

    def __repr__(self):
        return f'TreeTabSettingAtt()'
