#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class VerifTabSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.verif_tab_setting_att = com_object     

    @property
    def all_resource_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AllResourceFilter
                | o Property AllResourceFilter(    ) As
                | 
                | Returns or sets the value to signify Whether all the
                | resources will appear during Process Navigation Role:
                | Returns or sets the value to signify Whether all the
                | resources will appear during Process Navigation
                |

        :return:
        """
        return self.verif_tab_setting_att.AllResourceFilter

    @all_resource_filter.setter
    def all_resource_filter(self, value):
        """
            :param type value:
        """
        self.verif_tab_setting_att.AllResourceFilter = value 

    @property
    def auto_reframe_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoReframeFilter
                | o Property AutoReframeFilter(    ) As
                | 
                | Returns or sets the value to signify Whether the 'Auto
                | Reframe' will happen during Process navigation Role: Returns
                | or sets the value to signify Whether all the items/resources
                | will be reframed during Process Navigation
                |

        :return:
        """
        return self.verif_tab_setting_att.AutoReframeFilter

    @auto_reframe_filter.setter
    def auto_reframe_filter(self, value):
        """
            :param type value:
        """
        self.verif_tab_setting_att.AutoReframeFilter = value 

    @property
    def implied_resource_filter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImpliedResourceFilter
                | o Property ImpliedResourceFilter(    ) As
                | 
                | Returns or sets the value to signify Whether the Assigned
                | resource will appear during Process Navigation Role: Returns
                | or sets the value to signify Whether all the Assigned
                | resource will appear during Process Navigation
                |

        :return:
        """
        return self.verif_tab_setting_att.ImpliedResourceFilter

    @implied_resource_filter.setter
    def implied_resource_filter(self, value):
        """
            :param type value:
        """
        self.verif_tab_setting_att.ImpliedResourceFilter = value 

    def get_all_resource_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAllResourceFilterInfo
                | o Func GetAllResourceFilterInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment informations for the "View All
                | Resources" parameter. Role:Retrieves the state of the "View
                | All Resources" parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.verif_tab_setting_att.GetAllResourceFilterInfo(io_admin_level, io_locked)

    def get_auto_reframe_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoReframeFilterInfo
                | o Func GetAutoReframeFilterInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment informations for the "Auto Reframe"
                | parameter. Role:Retrieves the state of the "Auto Reframe"
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.verif_tab_setting_att.GetAutoReframeFilterInfo(io_admin_level, io_locked)

    def get_implied_resource_filter_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetImpliedResourceFilterInfo
                | o Func GetImpliedResourceFilterInfo(        ioAdminLevel,
                |                                             ioLocked) As
                | 
                | Retrieves environment informations for the "View Implied
                | Resource" parameter. Role:Retrieves the state of the "View
                | Implied Resource" parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.verif_tab_setting_att.GetImpliedResourceFilterInfo(io_admin_level, io_locked)

    def set_all_resource_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAllResourceFilterLock
                | o Sub SetAllResourceFilterLock(        iLocked)
                | 
                | Locks or unlocks the "View All Resources" parameter.
                | Role:Locks or unlocks the "View All Resources" parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.verif_tab_setting_att.SetAllResourceFilterLock(i_locked)

    def set_auto_reframe_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoReframeFilterLock
                | o Sub SetAutoReframeFilterLock(        iLocked)
                | 
                | Locks or unlocks the "Auto Reframe" parameter. Role:Locks or
                | unlocks the "Auto Reframe" parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.verif_tab_setting_att.SetAutoReframeFilterLock(i_locked)

    def set_implied_resource_filter_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetImpliedResourceFilterLock
                | o Sub SetImpliedResourceFilterLock(        iLocked)
                | 
                | Locks or unlocks the Xxx parameter. Role:Locks or unlocks
                | the "View Implied Resource" parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.verif_tab_setting_att.SetImpliedResourceFilterLock(i_locked)

    def __repr__(self):
        return f'VerifTabSettingAtt()'
