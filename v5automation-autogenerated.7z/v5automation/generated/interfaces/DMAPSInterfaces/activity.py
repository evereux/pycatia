#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Activity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The object that represents an activity.It groups the most important
                | methods related to an activity and enables to get the management
                | interfaces (hierarchy management, control flow management, * ...).

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.activity = com_object     

    @property
    def attr_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AttrCount
                | o Property AttrCount(    ) As   (Read Only)
                | 
                | This property returns the number of attributes of the
                | current activity. Returns: oNbAttr The number of attributes
                |

        :return:
        """
        return self.activity.AttrCount

    @property
    def beginning_date(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BeginningDate
                | o Property BeginningDate(    ) As
                | 
                | This property returns the beginning date of the current
                | activity. Returns: oBegin The beginning date of the current
                | activity
                |

        :return:
        """
        return self.activity.BeginningDate

    @property
    def calculated_begin_time(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CalculatedBeginTime
                | o Property CalculatedBeginTime(    ) As   (Read Only)
                | 
                | This property returns and calculated time cyle on the
                | current activity. Returns: oCBT The calculated begin time of
                | the current activity
                |

        :return:
        """
        return self.activity.CalculatedBeginTime

    @property
    def calculated_cycle_time(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CalculatedCycleTime
                | o Property CalculatedCycleTime(    ) As   (Read Only)
                | 
                | This property returns and sets the calculated time cyle on
                | the current activity. Returns: oCCT The calculated time
                | cycle of the current activity
                |

        :return:
        """
        return self.activity.CalculatedCycleTime

    @property
    def children_activities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ChildrenActivities
                | o Property ChildrenActivities(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the
                | children hierarchy on the activity. Please note that it used
                | to return all children, but from R20SP4 it returns only
                | exposed children, which could be different from all
                | children.
                |

        :return:
        """
        return self.activity.ChildrenActivities

    @property
    def cycle_time(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CycleTime
                | o Property CycleTime(    ) As
                | 
                | This property returns and set the time cyle on the current
                | activity. Returns: oCT The time cycle of the current
                | activity
                |

        :return:
        """
        return self.activity.CycleTime

    @property
    def description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Description
                | o Property Description(    ) As
                | 
                | This property returns and set the description on the current
                | activity. Returns: oDescriptionBSTR The description of the
                | current activity
                |

        :return:
        """
        return self.activity.Description

    @property
    def end_date(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EndDate
                | o Property EndDate(    ) As   (Read Only)
                | 
                | This property returns the end date of the current activity.
                | Returns: oEnd The end date of the current activity. Till
                | V5R13, this method is returning S_OK even if there is no
                | good implementation. Starting from V5R14 this method will
                | return E_NOIMPL. Hence all the scripts that use this method
                | would have to be updated to accomodate this change.
                |

        :return:
        """
        return self.activity.EndDate

    @property
    def items(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Items
                | o Property Items(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the items
                | or input products/components assigned to the current
                | activity
                |

        :return:
        """
        return self.activity.Items

    @property
    def next_cf_activities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NextCFActivities
                | o Property NextCFActivities(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the
                | downstream control flow hierarchy on the activity.
                |

        :return:
        """
        return self.activity.NextCFActivities

    @property
    def next_prf_activities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NextPRFActivities
                | o Property NextPRFActivities(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the
                | downstream product flow hierarchy on the activity.
                |

        :return:
        """
        return self.activity.NextPRFActivities

    @property
    def outputs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Outputs
                | o Property Outputs(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the output
                | products/components of the current activity
                |

        :return:
        """
        return self.activity.Outputs

    @property
    def parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Parameters
                | o Property Parameters(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the
                | knowlegde parameters of the activity.
                |

        :return:
        """
        return self.activity.Parameters

    @property
    def possible_precedence_activities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PossiblePrecedenceActivities
                | o Property PossiblePrecedenceActivities(    ) As   (Read Only)
                | 
                | This property returns list of Possible Precedence Activities
                | defined on Current Activity.
                |

        :return:
        """
        return self.activity.PossiblePrecedenceActivities

    @property
    def precedence_activities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrecedenceActivities
                | o Property PrecedenceActivities(    ) As   (Read Only)
                | 
                | This property returns list of Precedence Activities defined
                | on Current Activity.
                |

        :return:
        """
        return self.activity.PrecedenceActivities

    @property
    def previous_cf_activities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PreviousCFActivities
                | o Property PreviousCFActivities(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the
                | upstream control flow hierarchy on the activity.
                |

        :return:
        """
        return self.activity.PreviousCFActivities

    @property
    def previous_prf_activities(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PreviousPRFActivities
                | o Property PreviousPRFActivities(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the
                | upstream product flow hierarchy on the activity.
                |

        :return:
        """
        return self.activity.PreviousPRFActivities

    @property
    def process_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProcessID
                | o Property ProcessID(    ) As   (Read Only)
                | 
                | This property returns process identifier on the current
                | activity.
                |

        :return:
        """
        return self.activity.ProcessID

    @property
    def relations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Relations
                | o Property Relations(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the
                | knowlegde relations of the activity.
                |

        :return:
        """
        return self.activity.Relations

    @property
    def resources(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Resources
                | o Property Resources(    ) As   (Read Only)
                | 
                | This property returns the interface which manages the
                | resources hierarchy on the activity.
                |

        :return:
        """
        return self.activity.Resources

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | This method returns the type of the current activity.
                |

        :return:
        """
        return self.activity.Type

    def add_activity_constraint(self, i_activity, i_constraint_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddActivityConstraint
                | o Sub AddActivityConstraint(        iActivity,
                |                                     iConstraintType)
                | 
                | Create a constraint between current activity and input
                | activity
                |
                | Parameters:
                | iActivity
                |         Activity with which the constraint to be created.
                |  
                |  iConstraintType
                |         Type of the Constraint. It may be one of the following:
                |             Precedence_Constraint,
                |             Start_Constraint,
                |             End_Constraint,
                |  
                | 
                |  Returns:
                |  S_OK		On Success
                | 	S_FALSE		If a constraint already exists.
                | 	E_FAIL		If the constraint is NOT created.

                |
        :param i_activity:
        :param i_constraint_type:
        :return:
        """
        return self.activity.AddActivityConstraint(i_activity, i_constraint_type)

    def add_attr(self, i_attribute_name, attr_type, i_attribute_prompt_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddAttr
                | o Sub AddAttr(        iAttributeName,
                |                       AttrType,
                |                       iAttributePromptName)
                | 
                | Adds attribute to an Activity.
                |
                | Parameters:
                | iAttributeName
                |   Name of the attribute to add 
                | 
                |  AttrType
                |   Type of the attribute to add. It may be one of the following:
                |     Integer_Attribute or 0 for integer,
                |     Double_Attribute or 1 for double, or
                |     String_Attribute or 2 for string
                | 
                |  iAttributePromptName
                |   Prompt Name of the attribute to add

                |
        :param i_attribute_name:
        :param attr_type:
        :param i_attribute_prompt_name:
        :return:
        """
        return self.activity.AddAttr(i_attribute_name, attr_type, i_attribute_prompt_name)

    def attr_name(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | AttrName
                | o Func AttrName(        iIndex) As
                | 
                | This method returns the name for the specified attribute.
                |
                | Parameters:
                | iIndex
                |  The attribute index
                |  
                |  oName
                |  The attribute name

                |
        :param i_index:
        :return:
        """
        return self.activity.AttrName(i_index)

    def attr_value(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | AttrValue
                | o Func AttrValue(        iIndex) As
                | 
                | This method returns the value for the specified attribute.
                |
                | Parameters:
                | iIndex
                |  The attribute identifier
                |  
                | 
                |  Returns:
                |   oAttVal The attribute value

                |
        :param i_index:
        :return:
        """
        return self.activity.AttrValue(i_index)

    def create_child(self, i_type_of_child):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateChild
                | o Func CreateChild(        iTypeOfChild) As
                | 
                | This method creates a new child activity of the requested
                | type.
                |
                | Parameters:
                | iTypeOfChild
                |  The type of the child activity to create.
                |  
                |  oCreatedChild
                |  The new created child activity.

                |
        :param i_type_of_child:
        :return:
        """
        return self.activity.CreateChild(i_type_of_child)

    def create_link(self, i_second_activity):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateLink
                | o Sub CreateLink(        iSecondActivity)
                | 
                | This method creates a link from the current activity to
                | another activity.
                |
                | Parameters:
                | iSecondActivity
                |  The activity that will be linked to the current activity.

                |
        :param i_second_activity:
        :return:
        """
        return self.activity.CreateLink(i_second_activity)

    def get_activity_constraints(self, i_constraint_type, o_constrt_list):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetActivityConstraints
                | o Sub GetActivityConstraints(        iConstraintType,
                |                                      oConstrtList)
                | 
                | Get List of constraint activities that exists on the current
                | Activity
                |
                | Parameters:
                | iConstraintType
                |         Type of the Constraints to be returned. It may be one of the following:
                |             Precedence_Constraint,
                |             Start_Constraint,
                |             End_Constraint,
                |             All_Constraints
                | 
                |  
                | 
                |  Returns:
                |   oConstrtList ( Allocate the memory.If not, it allocates internally and you need to clean it after usage)	List of Activities with which the current activity has constraints 
                |  Returns:
                |   oConstraintTypeList (It is an optional output used only if user interested) ( Allocate the memory.If not, it allocates internally and you need to clean it after usage)
                | 	List of constraint types for each actvity that exists in oConstrtList 
                | Current activity has a constraint with first activity in oConstrtList and its constraint type is mentioned in first field of oConstraintTypeList

                |
        :param i_constraint_type:
        :param o_constrt_list:
        :return:
        """
        return self.activity.GetActivityConstraints(i_constraint_type, o_constrt_list)

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(        iApplicationType) As
                | 
                | Returns the process's applicative data which type is the
                | given parameter. The data returned can be either a
                | collection or a simple object.
                |
                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.

                |                | Examples:
                | This example retrieves the GraphEditor position for the
                | Loading1 activity. Dim GEPosition Set GEPosition =
                | Loading1.GetTechnologicalObject("GEPosition")

        :param i_application_type:
        :return:
        """
        return self.activity.GetTechnologicalObject(i_application_type)

    def is_sub_type_of(self, i_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsSubTypeOf
                | o Func IsSubTypeOf(        iName) As
                | 
                | This method allows to test the type of a specific activity.
                |
                | Parameters:
                | iName
                |  The name of the type to test
                |  
                | 
                |  Returns:
                |   oVal The logical value returned by the test

                |
        :param i_name:
        :return:
        """
        return self.activity.IsSubTypeOf(i_name)

    def remove_activity_constraint(self, i_activity, i_constraint_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveActivityConstraint
                | o Sub RemoveActivityConstraint(        iActivity,
                |                                        iConstraintType)
                | 
                | Remove a constraint between current activity and input
                | activity
                |
                | Parameters:
                | iActivity
                |         Activity with which the constraint to be removed.
                |  
                |  iConstraintType
                |         Type of the Constraint to be removed. It may be one of the following:
                |             Precedence_Constraint,
                |             Start_Constraint,
                |             End_Constraint,
                |             All_Constraints
                |  
                | 
                |  Returns:
                |  S_OK		On Success
                | 	S_FALSE		If a constraint does not exists.
                | 	E_FAIL		If the constraint can not be removed or the Function fails because of any reason.

                |
        :param i_activity:
        :param i_constraint_type:
        :return:
        """
        return self.activity.RemoveActivityConstraint(i_activity, i_constraint_type)

    def remove_attr(self, i_attribute_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveAttr
                | o Sub RemoveAttr(        iAttributeName)
                | 
                | Removes attributes to an Activity type.
                |
                | Parameters:
                | iAttributeName
                |   Name of the attribute to remove

                |
        :param i_attribute_name:
        :return:
        """
        return self.activity.RemoveAttr(i_attribute_name)

    def remove_link(self, i_second_activity):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveLink
                | o Sub RemoveLink(        iSecondActivity)
                | 
                | This method removes a link existing on the current activity.
                |
                | Parameters:
                | iSecondActivity
                |  The activity on which the link will be removed.

                |
        :param i_second_activity:
        :return:
        """
        return self.activity.RemoveLink(i_second_activity)

    def set_process_id(self, i_process_id, i_check_unique):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProcessID
                | o Sub SetProcessID(        iProcessID,
                |                            iCheckUnique)
                | 
                | Sets the process ID of the current activity
                |
                | Parameters:
                | iProcessID
                |    Input Process ID string
                |  
                |  iCheckUnique
                |    Option to enable uniqueness check

                |
        :param i_process_id:
        :param i_check_unique:
        :return:
        """
        return self.activity.SetProcessID(i_process_id, i_check_unique)

    def __repr__(self):
        return f'Activity()'
