#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Resources(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of resources related to the current activity.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.resources = com_object     

    def add(self, i_resource):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iResource) As
                | 
                | This method add the specified item in the current list
                |
                | Parameters:
                | iItem
                |  The item to add
                |  
                | 
                |  Returns:
                |   oitem The item

                |
        :param i_resource:
        :return:
        """
        return self.resources.Add(i_resource)

    def add_by_assignment_type(self, i_resource, i_assignment_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddByAssignmentType
                | o Func AddByAssignmentType(        iResource,
                |                                    iAssignmentType) As
                | 
                | This method Assigns/Adds the specified resource with the
                | specified assignment type
                |
                | Parameters:
                | iResource
                |  The resource to be assigned
                |  
                |  iAssignmentType
                |  Type of the Assignment (Resource to the Process). Only the following four types
                |  are supported at the moment:
                |    Process_Uses_Resource, Process_Runs_On_Resource,
                |    Process_Attaches_Resource, Process_Detaches_Resource
                |  
                | 
                |  Returns:
                |   oResource The resource when Add succeeds, unchanged otherwise

                |
        :param i_resource:
        :param i_assignment_type:
        :return:
        """
        return self.resources.AddByAssignmentType(i_resource, i_assignment_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | This method returns the idl object Resource for the
                | specified resource identifier.
                |
                | Parameters:
                | iIndex
                |  The resource identifier
                |  
                | 
                |  Returns:
                |   oResource The idl resource

                |
        :param i_index:
        :return:
        """
        return self.resources.Item(i_index)

    def remove_by_assignment_type(self, i_resource, i_assignment_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveByAssignmentType
                | o Func RemoveByAssignmentType(        iResource,
                |                                       iAssignmentType) As
                | 
                | This method Unassigns/Removes the specified resource if the
                | assignement exists and is of the given type
                |
                | Parameters:
                | iResource
                |  The resource to be Unassigned
                |  
                |  iAssignmentType
                |  Type of the Assignment (Resource to the Process) to be removed
                |  
                | 
                |  Returns:
                |   oResource The resource when Remove succeeds, unchanged otherwise

                |
        :param i_resource:
        :param i_assignment_type:
        :return:
        """
        return self.resources.RemoveByAssignmentType(i_resource, i_assignment_type)

    def __repr__(self):
        return f'Resources()'
