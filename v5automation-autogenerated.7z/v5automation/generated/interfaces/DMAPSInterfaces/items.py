#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Items(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of items related to the current activity.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.items = com_object     

    def add(self, i_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iProduct) As
                | 
                | This method adds the specified item in the current list
                |
                | Parameters:
                | iItem
                |  The item to add
                |  
                | 
                |  Returns:
                |   oitem The item

                |
        :param i_product:
        :return:
        """
        return self.items.Add(i_product)

    def add_by_assignment_type(self, i_item, i_assignment_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddByAssignmentType
                | o Func AddByAssignmentType(        iItem,
                |                                    iAssignmentType) As
                | 
                | This method Assigns the specified item with the specified
                | assignment type
                |
                | Parameters:
                | iItem
                |  The item to be assigned
                |  
                |  iAssignmentType
                |  Type of the Assignment (Item to the Process)
                |  
                | 
                |  Returns:
                |   oitem The item

                |
        :param i_item:
        :param i_assignment_type:
        :return:
        """
        return self.items.AddByAssignmentType(i_item, i_assignment_type)

    def count_by_assignment_type(self, i_assignment_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | CountByAssignmentType
                | o Func CountByAssignmentType(        iAssignmentType) As
                | 
                | This method returns the Number of items that assocated with
                | the activity with given Assignment Type.
                |
                | Parameters:
                | iAssignmentType
                |  Type of the Assignment between items & the activity
                |  
                | 
                |  Returns:
                |   oNbItems No. of Items that are assigned to the activity with the given assignment type.

                |
        :param i_assignment_type:
        :return:
        """
        return self.items.CountByAssignmentType(i_assignment_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | This method returns the idl object Item for the specified
                | item identifier.
                |
                | Parameters:
                | iIndex
                |  The item identifier
                |  
                | 
                |  Returns:
                |   oItem The idl item

                |
        :param i_index:
        :return:
        """
        return self.items.Item(i_index)

    def item_by_assignment_type(self, i_index, i_assignment_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | ItemByAssignmentType
                | o Func ItemByAssignmentType(        iIndex,
                |                                     iAssignmentType) As
                | 
                | This method returns the item assocated with the activity
                | with given Assignment Type.
                |
                | Parameters:
                | iAssignmentType
                |  Type of the Assignment between item & the activity
                |  
                | 
                |  Returns:
                |   oItem idl item to be returned

                |
        :param i_index:
        :param i_assignment_type:
        :return:
        """
        return self.items.ItemByAssignmentType(i_index, i_assignment_type)

    def remove_by_assignment_type(self, i_item, i_assignment_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveByAssignmentType
                | o Func RemoveByAssignmentType(        iItem,
                |                                       iAssignmentType) As
                | 
                | This method used to unassign the specified item (with the
                | given assignment type)
                |
                | Parameters:
                | iItem
                |  The item to be Unassigned
                |  
                |  iAssignmentType
                |  Type of the Assignment (Item to the Process) to be removed
                |  
                | 
                |  Returns:
                |   oitem The item

                |
        :param i_item:
        :param i_assignment_type:
        :return:
        """
        return self.items.RemoveByAssignmentType(i_item, i_assignment_type)

    def __repr__(self):
        return f'Items()'
