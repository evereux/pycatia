#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Outputs(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of outputs related to the current activity.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.outputs = com_object     

    def add(self, i_output):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iOutput) As
                | 
                | This method can be used to assign a given product as an
                | output
                |
                | Parameters:
                | iOutput
                |  The output to add
                |  
                | 
                |  Returns:
                |   oProduct The assigned product

                |
        :param i_output:
        :return:
        """
        return self.outputs.Add(i_output)

    def count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Count
                | o Func Count(    ) As
                | 
                | This method returns the no. of products / features that are
                | assigned to a process as output. Returns: oNbOutputs No. of
                | Outputss that are assigned to the activity.
                |
                | Parameters:

                |
        :return:
        """
        return self.outputs.Count()

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | This method can be used to get the associated output
                | product.
                |
                | Parameters:
                | iIndex
                |  The item identifier (can be the index or the name)
                |  
                | 
                |  Returns:
                |   oProduct The indexed product/MA that is assigned to the process.

                |
        :param i_index:
        :return:
        """
        return self.outputs.Item(i_index)

    def remove(self, i_output):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Func Remove(        iOutput) As
                | 
                | This method can be used to unassign an output product from a
                | process
                |
                | Parameters:
                | iProduct
                |  The product to remove
                |  
                | 
                |  Returns:
                |   oProduct The item

                |
        :param i_output:
        :return:
        """
        return self.outputs.Remove(i_output)

    def __repr__(self):
        return f'Outputs()'
