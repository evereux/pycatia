#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Activities(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of activities related to the current activity.It
                | respectively manages the children hierarchy, the  downstream control
                | flow, the uptream control flow, the downstream product  flow or the
                | upstream product flow.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.activities = com_object     

    def add(self, i_activity):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Sub Add(        iActivity)
                | 
                | This method adds the specified activity as a precedence
                | constraint
                |
                | Parameters:
                | iActivity
                |  The activity Handle

                |
        :param i_activity:
        :return:
        """
        return self.activities.Add(i_activity)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | This method gets the specified activity on the current
                | activities management.
                |
                | Parameters:
                | iIndex
                |  The activity identifier
                |  
                | 
                |  Returns:
                |   oActivity The activity

                |
        :param i_index:
        :return:
        """
        return self.activities.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | This method removes the specified activity on the current
                | activities management.
                |
                | Parameters:
                | iIndex
                |  The activity identifier

                |
        :param i_index:
        :return:
        """
        return self.activities.Remove(i_index)

    def __repr__(self):
        return f'Activities()'
