#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Task(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Task of a resource.Role: Task is the object used to
                | access and manage the attributes of the task.The following code
                | snippet can be used to obtain the Task from the Resource program
                | manager.Dim objResourceProgramManager As ResourceProgramManager   Dim
                | oTask As Task      objResourceProgramManager.GetTask  "RobotTask.1",
                | oTask

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.task = com_object     

    def get_name(self, o_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetName
                | o Sub GetName(        oName)
                | 
                | Get the name of the Task
                |
                | Parameters:
                | oName
                |    The user defined name of the Task.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The name of the task was corrrectly retrieved
                | E_FAIL 
                | The name of the task was not corrrectly retrieved

                |                | Examples:
                | The following example get the name of the task. Dim objTask
                | As Task Dim strTaskName As String .. objTask.GetName
                | strTaskName

        :param o_name:
        :return:
        """
        return self.task.GetName(o_name)

    def get_resource(self, o_res):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetResource
                | o Sub GetResource(        oRes)
                | 
                | Gets the Owning Resource
                |
                | Parameters:
                | oRes
                |    The Owning Resource.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The owning resource was corrrectly retrieved
                | E_FAIL 
                | The owning resource was not corrrectly retrieved

                |                | Examples:
                | The following example retrieves the owning resource of the
                | task. Dim objTask As Task Dim objRobot as Product ..
                | objTask.GetResource objRobot

        :param o_res:
        :return:
        """
        return self.task.GetResource(o_res)

    def set_name(self, i_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetName
                | o Sub SetName(        iName)
                | 
                | Set the name of the task
                |
                | Parameters:
                | iName
                |    The user defined name of the Task.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The name of the task was set corrrectly 
                | E_FAIL 
                | The name of the task was not set corrrectly

                |                | Examples:
                | The following example set the name of the task. Dim objTask
                | As Task .. objTask.SetName("RobotTask.2")

        :param i_name:
        :return:
        """
        return self.task.SetName(i_name)

    def __repr__(self):
        return f'Task()'
