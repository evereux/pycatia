#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ActiveTask(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Active task of the resource in conjunction with a
                | particular activity.Role: Active Task is the object used to access and
                | manage the active task  set for all the resources assigned for the
                | activity.The following code snippet can be used to obtain the Active
                | Task from the activity.Dim objChildActivity As Activity   Dim
                | objActiveActivity As ActiveTask      Set objActiveActivity =
                | objChildActivity.GetTechnologicalObject("ActiveTask")

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.active_task = com_object     

    def get_active_task(self, i_resource, o_task):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetActiveTask
                | o Sub GetActiveTask(        iResource,
                |                             oTask)
                | 
                | Retrieves the Active Task for an activity for a particular
                | Resource.
                |
                | Parameters:
                | iResource
                |    The resources.
                |  
                |  oTask
                |    The Active Task.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The status could be successfully queried from the activity
                | E_FAIL 
                | The query failed.

                |                | Examples:
                | The following example get the active task of the particular
                | resource in the activity. Dim oActiveAct As ActiveTask Dim
                | iResPrgMngr As ResourceProgramManager Dim oTask As Task ..
                | oActiveAct.GetActiveTask iResPrgMngr, oTask

        :param i_resource:
        :param o_task:
        :return:
        """
        return self.active_task.GetActiveTask(i_resource, o_task)

    def set_active_task(self, i_resource, i_task):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetActiveTask
                | o Sub SetActiveTask(        iResource,
                |                             iTask)
                | 
                | Defines the Active Task for an activity for a particular
                | Resource.
                |
                | Parameters:
                | iResource
                |    The resources that owns the Task.
                |  
                |  iTask
                |    The Tasks to be made active.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The Active Task was corrrectly set
                | E_FAIL 
                | The Active Task was not corrrectly set

                |                | Examples:
                | The following example sets Active Task for an activity for a
                | particular Resource. Dim iActiveAct As ActiveTask Dim
                | iResPrgMngr As ResourceProgramManager Dim iTask As Task ..
                | oActiveAct.SetActiveTask iResPrgMngr, iTask

        :param i_resource:
        :param i_task:
        :return:
        """
        return self.active_task.SetActiveTask(i_resource, i_task)

    def __repr__(self):
        return f'ActiveTask()'
