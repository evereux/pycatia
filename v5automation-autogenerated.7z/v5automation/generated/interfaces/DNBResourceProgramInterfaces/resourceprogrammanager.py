#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ResourceProgramManager(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Resource Program manager of a resource.Role: Resource
                | Program manager is the object used to access the tasks associated to
                | the resource.The following code snippet can be used to obtain the
                | Resource Program manager from the robot product.Dim
                | objResourceProgramManager As ResourceProgramManager   Dim objRobot as
                | Product      Set objResourceProgramManager =
                | objRobot.GetTechnologicalObject("ResourceProgramManager" )

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.resource_program_manager = com_object     

    def get_all_tasks(self, o_task_list):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAllTasks
                | o Sub GetAllTasks(        oTaskList)
                | 
                | Retrieves all the Tasks corresponding to this Resource.
                |
                | Parameters:
                | oTaskList
                |    The list of Tasks.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The Tasks were corrrectly retrieved
                | E_FAIL 
                | The Tasks were not corrrectly retrieved

                |                | Examples:
                | The following example retrieves the list of tasks on the
                | resource. Dim objResourceProgramManager As
                | ResourceProgramManager Dim TaskList(3) As Task ..
                | objResourceProgramManager.GetAllTasks TaskList

        :param o_task_list:
        :return:
        """
        return self.resource_program_manager.GetAllTasks(o_task_list)

    def get_task(self, i_task_name, o_task):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTask
                | o Sub GetTask(        iTaskName,
                |                       oTask)
                | 
                | Retrieves the Tasks corresponding to the given Task Name.
                |
                | Parameters:
                | iTaskName
                |    The name of the Task.
                |  
                |  oTask
                |    The output Task.
                |  
                | 
                |  Returns:
                |     An HRESULT.
                |    Legal values:
                |    
                | S_OK
                | The Task was corrrectly retrieved
                | E_FAIL 
                | The Task was not corrrectly retrieved

                |                | Examples:
                | The following example Retrieves the task corresponding the
                | given task name. Dim objResourceProgramManager As
                | ResourceProgramManager Dim oTask As Task ..
                | objResourceProgramManager.GetTask "RobotTask.1", oTask

        :param i_task_name:
        :param o_task:
        :return:
        """
        return self.resource_program_manager.GetTask(i_task_name, o_task)

    def __repr__(self):
        return f'ResourceProgramManager()'
