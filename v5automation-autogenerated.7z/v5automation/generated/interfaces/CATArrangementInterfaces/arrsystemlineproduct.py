#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrSystemLineProduct(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAArrSystemLineProduct

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arr_system_line_product = com_object     

    def get_sub_item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSubItem
                | o Func GetSubItem(        iIndex) As
                | 
                | Allows the user to get the item at a specific index
                | location.
                |
                | Parameters:

                |
        :param i_index:
        :return:
        """
        return self.arr_system_line_product.GetSubItem(i_index)

    def get_sub_products_count(self, i_intf_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSubProductsCount
                | o Func GetSubProductsCount(        iIntfId) As
                | 
                | Returns the count of the sub-products that make up the
                | System-Line Arrangement Product and that match a specifc
                | interface id. If the interface Id is NULL, then it searches
                | for CATIAProduct objects by default.
                |
                | Parameters:

                |
        :param i_intf_id:
        :return:
        """
        return self.arr_system_line_product.GetSubProductsCount(i_intf_id)

    def __repr__(self):
        return f'ArrSystemLineProduct()'
