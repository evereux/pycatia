#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementBoundaries(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection object for ArrangementBoundary objects.Role:This
                | collection object is used to manage (create, retrieve and remove
                | )ArrangementBoundary objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_boundaries = com_object     

    def add_boundary(self, i_rel_axis, i_listof_math_points, i_math_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddBoundary
                | o Func AddBoundary(        iRelAxis,
                |                            iListofMathPoints,
                |                            iMathDirection) As
                | 
                | Creates an ArrangementBoundary and adds it to the
                | collection.
                |
                | Parameters:
                | iRelAxis
                |    Relative Axis to be considered.
                |  
                |  iListofMathPoints
                |    List of points through which to route.
                |  
                |  iMathDirection
                |    Starting routing direction.
                |  
                | 
                |  Returns:
                |     The newly created ArrangementBoundary object.

                |
        :param i_rel_axis:
        :param i_listof_math_points:
        :param i_math_direction:
        :return:
        """
        return self.arrangement_boundaries.AddBoundary(i_rel_axis, i_listof_math_points, i_math_direction)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns the specified ArrangementBoundary item of the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementBoundary to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementBoundary in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementBoundary by name, use name that you assigned using
                |    the 
                | 
                |  property. 
                |    Returns:
                |      The retrieved ArrangementBoundary object.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_boundaries.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes the specified ArrangementBoundary object from the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementBoundary to remove from this collection.
                |    
                |  To remove a specific object by number, use the rank of the ArrangementBoundary in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To remove a specific ArrangementBoundary by name, use name that you assigned using
                |    the 
                | 
                |  property.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_boundaries.Remove(i_index)

    def __repr__(self):
        return f'ArrangementBoundaries()'
