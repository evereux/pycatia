#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrWorkbench(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Returns the Arrangement Workbench.Role:Use this interface to manage
                | the ArrNomenclatureTree object, create Arrangement objects (such as
                | ArrangementArea, ArrangementRun etc).

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arr_workbench = com_object     

    @property
    def arr_nomenclature_tree(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrNomenclatureTree
                | o Property ArrNomenclatureTree(    ) As   (Read Only)
                | 
                | Returns the ArrNomenclatureTree.
                |

        :return:
        """
        return self.arr_workbench.ArrNomenclatureTree

    def add_nomenclature_tree(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNomenclatureTree
                | o Func AddNomenclatureTree(    ) As
                | 
                | This method allows the user to add a nomenclature tree if
                | the get_ArrNomenclatureTree returns a Return code of E_FAIL.
                | Basically, the workbench could not locate the startup
                | instance to generate the necessary NomenclatureTree
                | information.
                |
                | Parameters:

                |
        :return:
        """
        return self.arr_workbench.AddNomenclatureTree()

    def convert_arrangement_product_to_product(self, i_arr_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConvertArrangementProductToProduct
                | o Func ConvertArrangementProductToProduct(        iArrProduct) As
                | 
                | This method converts an ArrangementProduct back to a
                | Product.
                |
                | Parameters:
                | iArrProduct
                |           Input ArrangementProduct to be converted.
                |  
                | 
                |  Returns:
                |    oProduct    As CATIAProduct          Converted Product.
                |  
                |    See also:

                |
        :param i_arr_product:
        :return:
        """
        return self.arr_workbench.ConvertArrangementProductToProduct(i_arr_product)

    def convert_product_to_arrangement_product(self, i_product):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConvertProductToArrangementProduct
                | o Func ConvertProductToArrangementProduct(        iProduct) As
                | 
                | This method converts a Product to an ArrangementProduct.
                |
                | Parameters:
                | iProduct
                |          Input Product to be converted.
                |  
                | 
                |  Returns:
                |   oArrProduct         Converted ArrangementProduct.
                |  
                |    See also:

                |
        :param i_product:
        :return:
        """
        return self.arr_workbench.ConvertProductToArrangementProduct(i_product)

    def find_interface(self, i_interface_name, i_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | FindInterface
                | o Func FindInterface(        iInterfaceName,
                |                              iObject) As
                | 
                | This method returns a interface handle as specified by the
                | input interface name and the input interface handle. Dim
                | interfaceFound As AnyObject Set interfaceFound = CATIAArrWor
                | kbench.FindInterface("InterfaceNameToFind",CATIAProduct_iObj
                | ect)
                |
                | Parameters:
                | iInterfaceName
                |    interface name to search for ("CATIAxxxx")
                |  
                |  iObject
                |    The object to search for the required interface.
                |  
                | 
                |  Returns:
                |   oInterfaceFound   interface handle found

                |
        :param i_interface_name:
        :param i_object:
        :return:
        """
        return self.arr_workbench.FindInterface(i_interface_name, i_object)

    def __repr__(self):
        return f'ArrWorkbench()'
