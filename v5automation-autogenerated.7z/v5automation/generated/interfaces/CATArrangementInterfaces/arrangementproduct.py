#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementProduct(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object as a factory for Arrangement collection
                | objects.Role:Use this interface to get access to the Arrangement
                | collections (Areas, Rectangles, ItemReservations, Runs, Pathways,
                | Boundaries) aggregated a given Product.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_product = com_object     

    @property
    def arrangement_areas(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementAreas
                | o Property ArrangementAreas(    ) As   (Read Only)
                | 
                | Returns the collection of ArrangementAreas under the current
                | ArrangementProduct. Example: This example retrieves the
                | ArrangementAreas collection, oArrAreas , for the objArrProd1
                | ArrangementProduct object. Dim oArrAreas As ArrangementAreas
                | Set oArrAreas = objArrProd1.Areas
                |

        :return:
        """
        return self.arrangement_product.ArrangementAreas

    @property
    def arrangement_boundaries(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementBoundaries
                | o Property ArrangementBoundaries(    ) As   (Read Only)
                | 
                | Returns the collection of ArrangementBoundaries under the
                | current ArrangementProduct. Example: This example retrieves
                | the ArrangementBoundaries collection, oArrBoundaries , for
                | the objArrProd1 ArrangementProduct object. Dim
                | oArrBoundaries As ArrangementBoundaries Set oArrBoundaries =
                | objArrProd1.oArrObjType
                |

        :return:
        """
        return self.arrangement_product.ArrangementBoundaries

    @property
    def arrangement_item_reservations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementItemReservations
                | o Property ArrangementItemReservations(    ) As   (Read Only)
                | 
                | Returns the collection of ArrangementItemReservations under
                | the current ArrangementProduct. Example: This example
                | retrieves the ArrangementItemReservations collection,
                | oArrItemReservations , for the objArrProd1
                | ArrangementProduct object. Dim oArrItemReservations As
                | ArrangementItemReservations Set oArrItemReservations =
                | objArrProd1.ItemReservations
                |

        :return:
        """
        return self.arrangement_product.ArrangementItemReservations

    @property
    def arrangement_pathways(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementPathways
                | o Property ArrangementPathways(    ) As   (Read Only)
                | 
                | Returns the collection of ArrangementPathways under the
                | current ArrangementProduct. Example: This example retrieves
                | the ArrangementPathways collection, oArrPathways , for the
                | objArrProd1 ArrangementProduct object. Dim oArrPathways As
                | ArrangementPathways Set oArrPathways = objArrProd1.Pathways
                |

        :return:
        """
        return self.arrangement_product.ArrangementPathways

    @property
    def arrangement_rectangles(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementRectangles
                | o Property ArrangementRectangles(    ) As   (Read Only)
                | 
                | Returns the collection of ArrangementRectangles under the
                | current ArrangementProduct. Example: This example retrieves
                | the ArrangementRectangles collection, oArrRectangles , for
                | the objArrProd1 ArrangementProduct object. Dim
                | oArrRectangles As ArrangementRectangles Set oArrRectangles =
                | objArrProd1.Rectangles
                |

        :return:
        """
        return self.arrangement_product.ArrangementRectangles

    @property
    def arrangement_runs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementRuns
                | o Property ArrangementRuns(    ) As   (Read Only)
                | 
                | Returns the collection of ArrangementRuns under the current
                | ArrangementProduct. Example: This example retrieves the
                | ArrangementRuns collection, oArrRuns , for the objArrProd1
                | ArrangementProduct object. Dim oArrRuns As ArrangementRuns
                | Set oArrRuns = objArrProd1.Runs
                |

        :return:
        """
        return self.arrangement_product.ArrangementRuns

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As   (Read Only)
                | 
                | Returns the Type of the ArrangementProduct in the form of a
                | String. Example: This example retrieves the type information
                | as a string for the objArrProd1 ArrangementProduct object.
                | Dim oArrObjType As String oArrObjType = objArrProd1.Type
                |

        :return:
        """
        return self.arrangement_product.Type

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(        iApplicationType) As
                | 
                | Returns the product's applicative data which type is the
                | given parameter.
                |
                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.

                |                | Examples:
                | This example retrieves the desired applicative object from
                | the objArrProd1 object. Dim objProd As Product objProd =
                | objArrProd1.GetTechnologicalObject("Product")

        :param i_application_type:
        :return:
        """
        return self.arrangement_product.GetTechnologicalObject(i_application_type)

    def set_arrangement_nomenclature(self, i_nomenclature):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetArrangementNomenclature
                | o Sub SetArrangementNomenclature(        iNomenclature)
                | 
                | Sets the nomenclature of the ArrangementProduct. Returns: An
                | HRESULT value. Legal values: S_OK operation is successful
                | E_FAIL operation failed Example: This example sets the
                | ArrangementNomenclature for objArrProd1 ArrangementProduct
                | object. objArrProd1.SetArrangementNomenclature = "Building"
                |
                | Parameters:

                |
        :param i_nomenclature:
        :return:
        """
        return self.arrangement_product.SetArrangementNomenclature(i_nomenclature)

    def set_auto_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoName
                | o Sub SetAutoName(    )
                | 
                | Causes the name of the ArrangementProduct automatically.
                | Returns: An HRESULT value. Legal values: S_OK operation is
                | successful E_FAIL operation failed Example: This example
                | shows how the automatic naming of the objArrProd1
                | ArrangementProduct object can be done.
                | objArrProd1.SetAutoName
                |
                | Parameters:

                |
        :return:
        """
        return self.arrangement_product.SetAutoName()

    def __repr__(self):
        return f'ArrangementProduct()'
