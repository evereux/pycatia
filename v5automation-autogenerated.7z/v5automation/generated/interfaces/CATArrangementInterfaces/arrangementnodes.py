#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementNodes(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A Collection object for ArrangementNode objects.Use this object to
                | access individual ArrangementNode objects of an ArrangementRun,
                | ArrangementPathway and ArrangementBoundary.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_nodes = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns the specified ArrangementNode item of the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementNode to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementNode in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementNode by name, use name that you assigned using
                |    the 
                | 
                |  property. 
                |    Returns:
                |      The retrieved ArrangementNode object.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_nodes.Item(i_index)

    def __repr__(self):
        return f'ArrangementNodes()'
