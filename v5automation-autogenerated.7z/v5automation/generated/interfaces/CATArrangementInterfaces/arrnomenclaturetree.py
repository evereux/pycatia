#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrNomenclatureTree(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the root User Dictionary object.The user dictionary defines
                | a hierarchy of user object type names  used for dynamically
                | classifying objects. These type names are  defined by the user
                | organization according to the needs of  the disciplines represented in
                | the data. The user type of any  object may be changed as the data
                | becomes more precise.  The hierarchy of type names starts with base
                | names, defined by  the system, for each type of object. The user
                | organization may  define or change the hierarchy of type names under
                | each base name.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arr_nomenclature_tree = com_object     

    @property
    def base_nomenclatures(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BaseNomenclatures
                | o Property BaseNomenclatures(    ) As   (Read Only)
                | 
                | Returns the collection of BaseNomenclatures within this
                | UserDictionary.
                |

        :return:
        """
        return self.arr_nomenclature_tree.BaseNomenclatures

    def get_nomenclature(self, i_type_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetNomenclature
                | o Func GetNomenclature(        iTypeName) As
                | 
                | Finds a UserNomenclature by Name from this UserDictionary.
                |
                | Parameters:

                |
        :param i_type_name:
        :return:
        """
        return self.arr_nomenclature_tree.GetNomenclature(i_type_name)

    def __repr__(self):
        return f'ArrNomenclatureTree()'
