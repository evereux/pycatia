#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementBoundary(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Access properties and functions of an ArrangementBoundary
                | object.Role:Use this interface to control the visualization mode,
                | section parameters, nodes that define the ArrangementBoundary object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_boundary = com_object     

    @property
    def arrangement_nodes(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementNodes
                | o Property ArrangementNodes(    ) As   (Read Only)
                | 
                | Returns the collection of ArrangementNodes that make up the
                | ArrangementBoundary. Example: This example gets the
                | ArrangementNodes for the objBoundary1 object. Dim
                | objArrNodes As ArrangementNodes Set objArrNodes =
                | objBoundary1.ArrangementNodes
                |

        :return:
        """
        return self.arrangement_boundary.ArrangementNodes

    @property
    def length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Length
                | o Property Length(    ) As   (Read Only)
                | 
                | Returns the length of the ArrangementBoundary object.
                | Example: This example retrieves the Length of the
                | objBoundary1 object. Dim dblBoundaryLength As Double
                | dblBoundaryLength = objBoundary1.Length
                |

        :return:
        """
        return self.arrangement_boundary.Length

    @property
    def section_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionHeight
                | o Property SectionHeight(    ) As
                | 
                | Returns or sets the SectionHeight for an ArrangementBoundary
                | object. Example: This example gets the SectionHeight for the
                | objBoundary1 object. Dim dblSectionHeight As Double
                | dblSectionHeight = objBoundary1.SectionHeight
                |

        :return:
        """
        return self.arrangement_boundary.SectionHeight

    @section_height.setter
    def section_height(self, value):
        """
            :param type value:
        """
        self.arrangement_boundary.SectionHeight = value 

    @property
    def section_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionType
                | o Property SectionType(    ) As
                | 
                | Returns or sets the SectionType for an ArrangementBoundary
                | object. Legal values: CatArrangementRouteSectionNone
                | CatArrangementRouteSectionRectangular Example: This example
                | sets the SectionType for the objBoundary1 object to
                | CatArrangementRouteSectionRectangular.
                | objBoundary1.SectionType =
                | CatArrangementRouteSectionRectangular
                |

        :return:
        """
        return self.arrangement_boundary.SectionType

    @section_type.setter
    def section_type(self, value):
        """
            :param type value:
        """
        self.arrangement_boundary.SectionType = value 

    @property
    def section_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionWidth
                | o Property SectionWidth(    ) As
                | 
                | Returns or sets the SectionWidth for an ArrangementBoundary
                | object. Example: This example gets the SectionWidth for the
                | objBoundary1 object. Dim dblSectionWidth As Double
                | dblSectionWidth = objBoundary1.SectionWidth
                |

        :return:
        """
        return self.arrangement_boundary.SectionWidth

    @section_width.setter
    def section_width(self, value):
        """
            :param type value:
        """
        self.arrangement_boundary.SectionWidth = value 

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As
                | 
                | Returns or sets the Visualization Mode for an
                | ArrangementBoundary object. Example: This example sets the
                | Visualization Mode for the objBoundary1 object to
                | CatArrangementRouteVisuModeSolid. objBoundary1.VisuMode =
                | CatArrangementRouteVisuModeSolid
                |

        :return:
        """
        return self.arrangement_boundary.VisuMode

    @visu_mode.setter
    def visu_mode(self, value):
        """
            :param type value:
        """
        self.arrangement_boundary.VisuMode = value 

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(        iApplicationType) As
                | 
                | Returns the applicative data whose type is the given
                | parameter.
                |
                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.

                |                | Examples:
                | This example retrieves the desired applicative object from
                | the objBoundary1 object. Dim objProd As Product objProd =
                | objBoundary1.GetTechnologicalObject("Product")

        :param i_application_type:
        :return:
        """
        return self.arrangement_boundary.GetTechnologicalObject(i_application_type)

    def __repr__(self):
        return f'ArrangementBoundary()'
