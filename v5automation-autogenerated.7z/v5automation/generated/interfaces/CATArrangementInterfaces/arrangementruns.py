#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementRuns(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection object of ArrangementRun objects.Role:Use this collection
                | object to manage ArrangementRun objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_runs = com_object     

    def add_run(self, i_rel_axis, i_listof_math_points, i_math_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddRun
                | o Func AddRun(        iRelAxis,
                |                       iListofMathPoints,
                |                       iMathDirection) As
                | 
                | Creates an ArrangementRun and adds it to the collection.
                |
                | Parameters:
                | iRelAxis
                |    Relative Axis to be considered.
                |  
                |  iListofMathPoints
                |    List of points through which to route.
                |  
                |  iMathDirection
                |    Starting routing direction.
                |  
                | 
                |  Returns:
                |     Returns the newly created ArrangementRun object and adds it to the collection.

                |
        :param i_rel_axis:
        :param i_listof_math_points:
        :param i_math_direction:
        :return:
        """
        return self.arrangement_runs.AddRun(i_rel_axis, i_listof_math_points, i_math_direction)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns the specified ArrangementRun item of the collection
                | object.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementRun to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementRun in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementRun by name, use name that you assigned using
                |    the 
                | 
                |  property. 
                |    Returns:
                |      The retrieved ArrangementRun object.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_runs.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes the specified ArrangementRun object from the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementRun to remove from this collection.
                |    
                |  To remove a specific object by number, use the rank of the ArrangementRun in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To remove a specific ArrangementRun by name, use name that you assigned using
                |    the 
                | 
                |  property.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_runs.Remove(i_index)

    def __repr__(self):
        return f'ArrangementRuns()'
