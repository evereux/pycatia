#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementRectangles(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A Collection object for ArrangementRectangle objects.Role:Use this
                | object to manage (create, retrieve and remove) ArrangementRectangle
                | objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_rectangles = com_object     

    def add_rectangle(self, i_rel_axis, i_position, i_width, i_length):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddRectangle
                | o Func AddRectangle(        iRelAxis,
                |                             iPosition,
                |                             iWidth,
                |                             iLength) As
                | 
                | Creates an ArrangementRectangle and adds it to the
                | collection.
                |
                | Parameters:
                | iRelAxis
                |    Relative Axis to be considered.
                |  
                |  iPosition
                |    Position information for the Rectangle (rotation and location).
                |  
                |  iWidth
                |    Width of the Rectangle. 
                |  
                |  iLength
                |     Length of the Rectangle. 
                |  
                | 
                |  Returns:
                |     Returns the newly created ArrangementRectangle and adds it to the collection.

                |
        :param i_rel_axis:
        :param i_position:
        :param i_width:
        :param i_length:
        :return:
        """
        return self.arrangement_rectangles.AddRectangle(i_rel_axis, i_position, i_width, i_length)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns the specified ArrangementRectangle item of the
                | collection object.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementRectangle to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementRectangle in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementRectangle by name, use name that you assigned using
                |    the 
                | 
                |  property. 
                |    Returns:
                |      The retrieved ArrangementRectangle object.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_rectangles.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes the specified ArrangementRectangle object from the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementRectangle to remove from this collection.
                |    
                |  To remove a specific object by number, use the rank of the ArrangementRectangle in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To remove a specific ArrangementRectangle by name, use name that you assigned using
                |    the 
                | 
                |  property.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_rectangles.Remove(i_index)

    def __repr__(self):
        return f'ArrangementRectangles()'
