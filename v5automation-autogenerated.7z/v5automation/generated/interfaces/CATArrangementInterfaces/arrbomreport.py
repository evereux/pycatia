#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrBOMReport(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIAArrBOMReport

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arr_bom_report = com_object     

    def generate_bom_report(self, i_document_to_extract_data, i_output_file_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GenerateBOMReport
                | o Sub GenerateBOMReport(        iDocumentToExtractData,
                |                                 iOutputFileName)
                | 
                | This method generate a BOM report on the current piping
                | document to an output html file.
                |
                | Parameters:

                |
        :param i_document_to_extract_data:
        :param i_output_file_name:
        :return:
        """
        return self.arr_bom_report.GenerateBOMReport(i_document_to_extract_data, i_output_file_name)

    def __repr__(self):
        return f'ArrBOMReport()'
