#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementItemReservation(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object to access the ArrangementItemReservation properties
                | and methods.Role:Use this object to control the visualization mode,
                | dimensions of the ArrangementItemReservation.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_item_reservation = com_object     

    @property
    def height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Height
                | o Property Height(    ) As
                | 
                | Returns or sets the height of the
                | ArrangementItemReservation. Example: This example retrieves
                | the Height of the objItemRes1 object. Dim dblHeight As
                | Double dblHeight = objItemRes1.Height
                |

        :return:
        """
        return self.arrangement_item_reservation.Height

    @height.setter
    def height(self, value):
        """
            :param type value:
        """
        self.arrangement_item_reservation.Height = value 

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As
                | 
                | Returns or set the Visualization Mode for the
                | ArrangementItemReservation. Example: This example Sets the
                | Visualization Mode of the objItemRes1 object to
                | CatArrangementItemReservationVisuModeBox .
                | objItemRes1.VisuMode =
                | CatArrangementItemReservationVisuModeBox
                |

        :return:
        """
        return self.arrangement_item_reservation.VisuMode

    @property
    def x_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | XLength
                | o Property XLength(    ) As
                | 
                | Returns or sets the XLength of the
                | ArrangementItemReservation. Example: This example retrieves
                | the XLength of the objItemRes1 object. Dim dblXLength As
                | Double dblXLength = objItemRes1.XLength
                |

        :return:
        """
        return self.arrangement_item_reservation.XLength

    @x_length.setter
    def x_length(self, value):
        """
            :param type value:
        """
        self.arrangement_item_reservation.XLength = value 

    @property
    def y_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | YLength
                | o Property YLength(    ) As
                | 
                | Returns or sets the YLength of the
                | ArrangementItemReservation. Example: This example retrieves
                | the YLength of the objItemRes1 object. Dim dblYLength As
                | Double dblYLength = objItemRes1.YLength
                |

        :return:
        """
        return self.arrangement_item_reservation.YLength

    @y_length.setter
    def y_length(self, value):
        """
            :param type value:
        """
        self.arrangement_item_reservation.YLength = value 

    def get_dimension(self, io_item_res_dimensions):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDimension
                | o Sub GetDimension(        ioItemResDimensions)
                | 
                | Returns the Dimensions of the ArrangementItemReservation.
                |
                | Parameters:
                | ioItemResDimensions
                |    The output array initialized with the dimensions that make up the ArrangementItemReservation.
                |    The first three components represent the Minimum XCoord, YCoord and Z Coord while the 
                |    remaining three components represent the Maximum XCoord, YCoord and Z Coord respectively.

                |                | Examples:
                | This example retrieves the coordinate dimensions of the
                | objItemRes1 object. Dim dblDimension(6) As Double
                | objItemRes1.GetDimension(dblDimension)

        :param io_item_res_dimensions:
        :return:
        """
        return self.arrangement_item_reservation.GetDimension(io_item_res_dimensions)

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(        iApplicationType) As
                | 
                | Returns the applicative data whose type is the given
                | parameter.
                |
                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.

                |                | Examples:
                | This example retrieves the desired applicative object from
                | the objItemRes1 object. Dim objProd As Product objProd =
                | objItemRes1.GetTechnologicalObject("Product")

        :param i_application_type:
        :return:
        """
        return self.arrangement_item_reservation.GetTechnologicalObject(i_application_type)

    def set_dimension(self, i_item_res_dimensions):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDimension
                | o Sub SetDimension(        iItemResDimensions)
                | 
                | Sets the Dimensions of the ArrangementItemReservation.
                |
                | Parameters:
                | iItemResDimensions
                |    The input array initialized with the dimensions that make up the ArrangementItemReservation.
                |    The first three components represent the Minimum XCoord, YCoord and Z Coord while the 
                |    remaining three components represent the Maximum XCoord, YCoord and Z Coord respectively.

                |                | Examples:
                | This example sets the coordinate dimensions of the
                | objItemRes1 object. Dim dblDimension(6) As Double
                | dblDimension(0) = 300.0 '//XMin dblDimension(1) = 500.0
                | '//YMin dblDimension(2) = 300.0 '//ZMin dblDimension(3) =
                | 500.0 '//XMax dblDimension(4) = 0.0 '//YMax dblDimension(5)
                | = 300.0 '//ZMax objItemRes1.SetDimension(dblDimension)

        :param i_item_res_dimensions:
        :return:
        """
        return self.arrangement_item_reservation.SetDimension(i_item_res_dimensions)

    def __repr__(self):
        return f'ArrangementItemReservation()'
