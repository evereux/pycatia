#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrNomenclatures(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of UserNomenclature objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arr_nomenclatures = com_object     

    def add_user_nomenclature(self, i_name, i_icon_name, i_class_type, i_super_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddUserNomenclature
                | o Func AddUserNomenclature(        iName,
                |                                    iIconName,
                |                                    iClassType,
                |                                    iSuperType) As
                | 
                | Creates a new UserNomenclature and adds it to this
                | collection. The NomenclatureType of the new UserNomenclature
                | will be "User". The base objects in the UserDictionary are
                | created when the UserDictionary is created.
                |
                | Parameters:
                | iName
                |     The user nomenclature name.
                | 
                |  
                |  iIconName
                |     The icon name associated to this nomenclature name.
                | 
                |  
                | 
                |  Returns:
                |      The new UserNomenclature.

                |
        :param i_name:
        :param i_icon_name:
        :param i_class_type:
        :param i_super_type:
        :return:
        """
        return self.arr_nomenclatures.AddUserNomenclature(i_name, i_icon_name, i_class_type, i_super_type)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns the specified item of the collection
                |
                | Parameters:
                | iItem
                |     The list index (long) or name (CATBSTR) of the member to retrieve.
                | 
                |  
                | 
                |  Returns:
                |      The retrieved member object.

                |
        :param i_index:
        :return:
        """
        return self.arr_nomenclatures.Item(i_index)

    def __repr__(self):
        return f'ArrNomenclatures()'
