#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementPathway(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object to access properties and methods of an
                | ArrangementPathway object.Role:Use this interface to control the
                | visualization mode, section parameters, nodes that define the
                | ArrangementPathway object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_pathway = com_object     

    @property
    def arrangement_nodes(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementNodes
                | o Property ArrangementNodes(    ) As   (Read Only)
                | 
                | Returns the ArrangementNodes that make up the
                | ArrangementPathway. Example: This example gets the
                | ArrangementNodes for the objPathway1 object. Dim objArrNodes
                | As ArrangementNodes Set objArrNodes =
                | objPathway1.ArrangementNodes
                |

        :return:
        """
        return self.arrangement_pathway.ArrangementNodes

    @property
    def length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Length
                | o Property Length(    ) As   (Read Only)
                | 
                | Returns the length of the ArrangementPathway object.
                | Example: This example retrieves the Length of the
                | objPathway1 object. Dim dblLength As Double dblLength =
                | objPathway1.Length
                |

        :return:
        """
        return self.arrangement_pathway.Length

    @property
    def section_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionDiameter
                | o Property SectionDiameter(    ) As
                | 
                | Returns or sets the SectionDiameter for an
                | ArrangementPathway object. Example: This example retrieves
                | the SectionDiameter for the objPathway1 object. Dim
                | dblSectionDia As Double dblSectionDia =
                | objPathway1.SectionDiameter
                |

        :return:
        """
        return self.arrangement_pathway.SectionDiameter

    @section_diameter.setter
    def section_diameter(self, value):
        """
            :param type value:
        """
        self.arrangement_pathway.SectionDiameter = value 

    @property
    def section_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionHeight
                | o Property SectionHeight(    ) As
                | 
                | Returns or sets the SectionHeight for an ArrangementPathway
                | object. Example: This example gets the SectionHeight for the
                | objPathway1 object. Dim dblSectionHeight As Double
                | dblSectionHeight = objPathway1.SectionHeight
                |

        :return:
        """
        return self.arrangement_pathway.SectionHeight

    @section_height.setter
    def section_height(self, value):
        """
            :param type value:
        """
        self.arrangement_pathway.SectionHeight = value 

    @property
    def section_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionType
                | o Property SectionType(    ) As
                | 
                | Returns or sets the Section for an ArrangementPathway
                | object. Example: This example sets the SectionType for the
                | objPathway1 object to CatArrangementRouteSectionRectangular.
                | objPathway1.SectionType =
                | CatArrangementRouteSectionRectangular
                |

        :return:
        """
        return self.arrangement_pathway.SectionType

    @section_type.setter
    def section_type(self, value):
        """
            :param type value:
        """
        self.arrangement_pathway.SectionType = value 

    @property
    def section_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SectionWidth
                | o Property SectionWidth(    ) As
                | 
                | Returns or sets the SectionWidth for an ArrangementPathway
                | object. Example: This example gets the SectionWidth for the
                | objPathway1 object. Dim dblSectionWidth As Double
                | dblSectionWidth = objPathway1.SectionWidth
                |

        :return:
        """
        return self.arrangement_pathway.SectionWidth

    @section_width.setter
    def section_width(self, value):
        """
            :param type value:
        """
        self.arrangement_pathway.SectionWidth = value 

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As
                | 
                | Returns or sets the Visualization Mode for an
                | ArrangementPathway object. Example: This example sets the
                | Visualization Mode for the objPathway1 object to
                | CatArrangementRouteVisuModeSolid. objPathway1.VisuMode =
                | CatArrangementRouteVisuModeSolid
                |

        :return:
        """
        return self.arrangement_pathway.VisuMode

    @visu_mode.setter
    def visu_mode(self, value):
        """
            :param type value:
        """
        self.arrangement_pathway.VisuMode = value 

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(        iApplicationType) As
                | 
                | Returns the applicative data which type is the given
                | parameter.
                |
                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                |  oApplicativeObj
                |    The matched applicative object.

                |                | Examples:
                | This example retrieves the desired applicative object from
                | the objPathway1 object. Dim objProd As Product objProd =
                | objPathway1.GetTechnologicalObject("Product")

        :param i_application_type:
        :return:
        """
        return self.arrangement_pathway.GetTechnologicalObject(i_application_type)

    def __repr__(self):
        return f'ArrangementPathway()'
