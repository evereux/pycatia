#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementItemReservations(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | A collection object for ArrangementItemReservation objects.Role:Use
                | this collection object to manage (create, retrieve and remove)
                | ArrangementItemReservation objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_item_reservations = com_object     

    def add_item_reservation(self, i_rel_axis, i_position, i_x_min, i_y_min, i_z_min, i_x_max, i_y_max, i_z_max):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddItemReservation
                | o Func AddItemReservation(        iRelAxis,
                |                                   iPosition,
                |                                   iXMin,
                |                                   iYMin,
                |                                   iZMin,
                |                                   iXMax,
                |                                   iYMax,
                |                                   iZMax) As
                | 
                | Creates an ArrangementItemReservation and adds it to the
                | collection.
                |
                | Parameters:
                | iRelAxis
                |    Relative Axis to be considered.
                |  
                |  iPosition
                |    Position information for the ItemReservation (rotation and location).
                |  
                |  iXMin
                |    Minium X Coordinate of the bounding box on the Item Reservation.
                |  
                |  iYMin
                |    Minium Y Coordinate of the bounding box on the Item Reservation.
                |  
                |  iZMin
                |    Minium Z Coordinate of the bounding box on the Item Reservation.
                |  
                |  iXMax
                |    Maximum X Coordinate of the bounding box on the Item Reservation.
                |  
                |  iYMax
                |    Maximum Y Coordinate of the bounding box on the Item Reservation.
                |  
                |  iZMax
                |    Maximum Z Coordinate of the bounding box on the Item Reservation.
                |  
                | 
                |  Returns:
                |     Returns the newly created ArrangementItemReservation object and adds it to the collection.

                |
        :param i_rel_axis:
        :param i_position:
        :param i_x_min:
        :param i_y_min:
        :param i_z_min:
        :param i_x_max:
        :param i_y_max:
        :param i_z_max:
        :return:
        """
        return self.arrangement_item_reservations.AddItemReservation(i_rel_axis, i_position, i_x_min, i_y_min, i_z_min, i_x_max, i_y_max, i_z_max)

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns the specified ArrangementItemReservation item of the
                | collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementItemReservation to retrieve from this collection.
                |    
                |  To retrieve a specific object by number, use the rank of the ArrangementItemReservation in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To retrieve a specific ArrangementItemReservation by name, use name that you assigned using
                |    the 
                | 
                |  property. 
                |    Returns:
                |      The retrieved ArrangementItemReservation object.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_item_reservations.Item(i_index)

    def remove(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iIndex)
                | 
                | Removes the specified ArrangementItemReservation object from
                | the collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the ArrangementItemReservation to remove from this collection.
                |    
                |  To remove a specific object by number, use the rank of the ArrangementItemReservation in that collection.
                | 
                |    Note that the index of the first element in the collection is 1, and
                |    the index of the last  element is Count.
                |    
                |    To remove a specific ArrangementItemReservation by name, use name that you assigned using
                |    the 
                | 
                |  property.

                |
        :param i_index:
        :return:
        """
        return self.arrangement_item_reservations.Remove(i_index)

    def __repr__(self):
        return f'ArrangementItemReservations()'
