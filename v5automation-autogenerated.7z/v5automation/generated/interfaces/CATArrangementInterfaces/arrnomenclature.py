#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrNomenclature(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the UserNomenclature object.The UserNomenclature object is
                | used in the CATIAArrNomenclatureTree object to maintain the hierarchy
                | of user type names and associated icons.  CATIAArrNomenclatureTree |
                | |_______ Area - (I_ArrArea) |        |_______ Building     -
                | (I_ArrBuilding) |        |_______ Safety Zone  - (I_ArrSafetyZone) |
                | |-------- Run - (I_ArrRun) |        |_______ Conduit Run
                | |_______ Raceway Run In the diagram shown above, Area (along with its
                | subtypes) and and Run (also along with it's subtypes) are all
                | UserNomenclature objects. Entries such as the Area and Run are called
                | System or SuperClass objects that have to be defined first before the
                | subclasses such as Building and Safety Zone are defined. SuperClasses
                | will not  have a supertype. Each Nomenclature holds the following
                | information... (1) NLSName   - So as to support names in different
                | languages (2) IconName  - So as to allow user's to define their own
                | icons (3) SuperType - For subtypes to fetch their parent names (4)
                | SubTypes  - SubTypes defined under this User Nomenclature

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arr_nomenclature = com_object     

    @property
    def icon_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IconName
                | o Property IconName(    ) As
                | 
                | Gets/Sets the Icon Name associated to the Type Name. The
                | IconName is the file name, without the extension, of the
                | Icon bitmap representing this user type. The icon definition
                | file must be in one of the icon directories defined in the
                | search paths used by CATIA.
                |

        :return:
        """
        return self.arr_nomenclature.IconName

    @property
    def int_sys_class_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IntSysClassName
                | o Property IntSysClassName(    ) As
                | 
                | Gets/Sets the internal class names for System nomenclatures.
                | This value is set only for System nomenclatures
                |

        :return:
        """
        return self.arr_nomenclature.IntSysClassName

    @property
    def nls_instance_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NLSInstanceName
                | o Property NLSInstanceName(    ) As
                | 
                | Gets/Sets the InstanceName
                |

        :return:
        """
        return self.arr_nomenclature.NLSInstanceName

    @property
    def sub_types(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SubTypes
                | o Property SubTypes(    ) As   (Read Only)
                | 
                | Returns the collection of subtype UserNomenclatures within
                | this UserNomenclature.
                |

        :return:
        """
        return self.arr_nomenclature.SubTypes

    @property
    def super_type_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SuperTypeName
                | o Property SuperTypeName(    ) As
                | 
                | Get/Set the Supertype Information This property is used to
                | set the subtypes for system classes
                |

        :return:
        """
        return self.arr_nomenclature.SuperTypeName

    def is_system_nomenclature(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsSystemNomenclature
                | o Func IsSystemNomenclature(    ) As
                | 
                | Returns TRUE if the nomenclature happens to be a system
                | nomenclature. Returns FALSE if it is a user specified
                | nomenclature.
                |
                | Parameters:

                |
        :return:
        """
        return self.arr_nomenclature.IsSystemNomenclature()

    def __repr__(self):
        return f'ArrNomenclature()'
