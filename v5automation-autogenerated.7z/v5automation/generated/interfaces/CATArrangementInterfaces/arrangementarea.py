#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ArrangementArea(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Use this object to access an ArrangementArea object's properties and
                | functions.Role:The ArrangementArea object is a type of Arrangement
                | Object defining an  area containing other objects.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.arrangement_area = com_object     

    @property
    def arrangement_contours(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ArrangementContours
                | o Property ArrangementContours(    ) As   (Read Only)
                | 
                | Returns the ArrangementContours collection object associated
                | with an ArrangementArea object. Example: This example
                | retrieves the ArrangementContours collection object for the
                | objArea1 object. Dim objArrContours As ArrangementContours
                | Set objArrContours = objArea1.ArrangementContours
                |

        :return:
        """
        return self.arrangement_area.ArrangementContours

    @property
    def height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Height
                | o Property Height(    ) As
                | 
                | Returns or sets the Height of an ArrangementArea object.
                | Example: This example retrieves the Height for the objArea1
                | object. Dim dblAreaHeight As Double dblAreaHeight =
                | objArea1.Height
                |

        :return:
        """
        return self.arrangement_area.Height

    @height.setter
    def height(self, value):
        """
            :param type value:
        """
        self.arrangement_area.Height = value 

    @property
    def size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Size
                | o Property Size(    ) As   (Read Only)
                | 
                | Returns the Size of the ArrangementArea. Example: This
                | example retrieves the Size of the objArea1 object. Dim
                | dblAreaSize As Double dblAreaSize = objArea1.Size
                |

        :return:
        """
        return self.arrangement_area.Size

    @property
    def visu_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuMode
                | o Property VisuMode(    ) As
                | 
                | Returns or sets the Visualization Mode for an
                | ArrangementArea object. Example: This example sets the
                | Visualization Mode for the objArea1 object to
                | CatArrangementAreaVisuModeVolume. objArea1.VisuMode =
                | CatArrangementAreaVisuModeVolume
                |

        :return:
        """
        return self.arrangement_area.VisuMode

    @visu_mode.setter
    def visu_mode(self, value):
        """
            :param type value:
        """
        self.arrangement_area.VisuMode = value 

    def get_technological_object(self, i_application_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTechnologicalObject
                | o Func GetTechnologicalObject(        iApplicationType) As
                | 
                | Returns the applicative data whose type is the given
                | parameter.
                |
                | Parameters:
                | iApplicationType
                |    The type of applicative data searched.
                |  
                | 
                |  Returns:
                |   oApplicativeObj   The matched applicative object.

                |                | Examples:
                | This example retrieves the desired applicative object from
                | the objArea1 object. Dim objProd As Product objProd =
                | objArea1.GetTechnologicalObject("Product")

        :param i_application_type:
        :return:
        """
        return self.arrangement_area.GetTechnologicalObject(i_application_type)

    def __repr__(self):
        return f'ArrangementArea()'
