#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5SaveItems(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Collection of items which user is trying to save.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_save_items = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns (gets) an item from the list of items in the current
                | save scope. First item is at index 1. Example: The following
                | example gets a SaveItem at index 1. Dim oSaveItem As
                | CD5SaveItem Set oSaveItem = oSaveItems.Item(1)
                |
                | Parameters:

                |
        :param i_index:
        :return:
        """
        return self.cd5_save_items.Item(i_index)

    def __repr__(self):
        return f'CD5SaveItems()'
