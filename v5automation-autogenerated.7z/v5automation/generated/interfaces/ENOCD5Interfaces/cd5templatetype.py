#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5TemplateType(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Template Type.Properties on the object helps the users to
                | get various templates and there possible ENOVIA Types.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_template_type = com_object     

    @property
    def possible_types(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PossibleTypes
                | o Property PossibleTypes(    ) As   (Read Only)
                | 
                | Returns (gets) the possible Types from a Template type.
                | Example: The following example gets Possible ENOVIA Types
                | from a Template type. Dim oPossibleTypes As Array
                | oPossibleTypes = oTemplateType.PossibleTypes
                |

        :return:
        """
        return self.cd5_template_type.PossibleTypes

    @property
    def template_type_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TemplateTypeName
                | o Property TemplateTypeName(    ) As   (Read Only)
                | 
                | Returns (gets) the name of the Template Type. Example: The
                | following example gets the name of the Template Type. Dim
                | oName As CATBSTR oName = oTemplateType.TemplateTypeName
                |

        :return:
        """
        return self.cd5_template_type.TemplateTypeName

    @property
    def templates(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Templates
                | o Property Templates(    ) As   (Read Only)
                | 
                | Returns (gets) the list of Templates from a Template type.
                | Example: The following example gets Templates. Dim
                | oTemplates As ENOIACD5Templates Set oTemplates =
                | oTemplateType.Templates
                |

        :return:
        """
        return self.cd5_template_type.Templates

    def __repr__(self):
        return f'CD5TemplateType()'
