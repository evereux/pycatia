#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5Template(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Template.Various properties on the object helps to
                | perform operations on the template.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_template = com_object     

    @property
    def template_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TemplateName
                | o Property TemplateName(    ) As   (Read Only)
                | 
                | Returns (gets) the name of the Template. Example: The
                | following example gets the name of the Template. Dim oName
                | As CATBSTR oName = oTemplate.TemplateName
                |

        :return:
        """
        return self.cd5_template.TemplateName

    @property
    def template_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TemplateType
                | o Property TemplateType(    ) As   (Read Only)
                | 
                | Returns (gets) the type of the Template. Example: The
                | following example gets the type of the Template. Dim oType
                | As CATBSTR oType = oTemplate.TemplateType
                |

        :return:
        """
        return self.cd5_template.TemplateType

    def download_file(self, i_target_folder):
        """
        .. note::
            CAA V5 Visual Basic help

                | DownloadFile
                | o Func DownloadFile(        iTargetFolder) As
                | 
                | Downloads the template file to local disk.
                |
                | Parameters:
                | iiTargetFolder
                |  The Folder Path on local disk where the template file will be downloaded.
                |  
                | 
                |  Returns:
                |   Full path of the downloaded file.
                |  
                |    Throws:
                |  
                | -1782306828 : Template object is assigned more than one file.
                | -1774688310 : Template object is not assigned any file.
                | -1866082326 : File of same name as that of file assigned to Template object is present on download directory.

                |                | Examples:
                | The following example downloads the template file to local
                | disk oTemplate: iTargetFolder : "E:\New folder". Dim
                | DownloadedFilePath As CATBSTR DownloadedFilePath =
                | oTemplate.DownloadFile("E:\New folder")

        :param i_target_folder:
        :return:
        """
        return self.cd5_template.DownloadFile(i_target_folder)

    def __repr__(self):
        return f'CD5Template()'
