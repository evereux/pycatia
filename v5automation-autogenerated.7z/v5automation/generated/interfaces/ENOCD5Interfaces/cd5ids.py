#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5IDs(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a list of ENOVIA V6 Integration identifier(CD5ID).

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_i_ds = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns (gets) CD5ID from the list of ids. Example: The
                | following example gets a CD5ID at index 1. Dim oID As
                | ENOIACD5ID Set oID = CD5IDs.Item(1)
                |
                | Parameters:

                |
        :param i_index:
        :return:
        """
        return self.cd5_i_ds.Item(i_index)

    def __repr__(self):
        return f'CD5IDs()'
