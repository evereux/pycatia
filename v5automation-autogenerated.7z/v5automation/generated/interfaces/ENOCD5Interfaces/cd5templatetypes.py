#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5TemplateTypes(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a List of all Template types.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_template_types = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns (gets) an item from the list of items. Example: The
                | following example gets a Template Type at index 1. Dim
                | oTemplateType As ENOIACD5TemplateType Set oTemplateType =
                | oTemplateTypes.Item(1)
                |
                | Parameters:

                |
        :param i_index:
        :return:
        """
        return self.cd5_template_types.Item(i_index)

    def __repr__(self):
        return f'CD5TemplateTypes()'
