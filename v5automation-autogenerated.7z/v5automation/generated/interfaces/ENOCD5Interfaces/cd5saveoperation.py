#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5SaveOperation(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a Save Operation Object.Various properties which are
                | applicable for the complete save operation can be set using this.Also,
                | end-user may either run the Save operation as per customization done
                | so far or open the Advanced Save panel to finalize customization and
                | run the Save manually.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_save_operation = com_object     

    @property
    def allow_disk_save(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AllowDiskSave
                | o Property AllowDiskSave(    ) As
                | 
                | Returns (gets) or sets the value of the Save option "Allow
                | Disk Save". Example: The following example sets the Allow
                | Disk Save option to True. oSaveOperation.AllowDiskSave =
                | True
                |

        :return:
        """
        return self.cd5_save_operation.AllowDiskSave

    @allow_disk_save.setter
    def allow_disk_save(self, value):
        """
            :param type value:
        """
        self.cd5_save_operation.AllowDiskSave = value 

    @property
    def comment(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Comment
                | o Property Comment(    ) As
                | 
                | Returns (gets) or sets the value of the Save Comment.
                | Example: The following example sets the Save Comment to
                | "ABC". oSaveOperation.Comment = "ABC"
                |

        :return:
        """
        return self.cd5_save_operation.Comment

    @comment.setter
    def comment(self, value):
        """
            :param type value:
        """
        self.cd5_save_operation.Comment = value 

    @property
    def create_version(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateVersion
                | o Property CreateVersion(    ) As
                | 
                | Returns (gets) or sets the value of the Save option "Create
                | Version". The default value is picked from the LCO/GCO.
                | Example: The following example sets the Create Version
                | option to True. oSaveOperation.CreateVersion = True
                |

        :return:
        """
        return self.cd5_save_operation.CreateVersion

    @create_version.setter
    def create_version(self, value):
        """
            :param type value:
        """
        self.cd5_save_operation.CreateVersion = value 

    @property
    def items(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Items
                | o Property Items(    ) As   (Read Only)
                | 
                | Returns (gets) the collection of all the items in the scope
                | of the Save. Example: The following example gets all the
                | items in the scope of the Save. Dim oSaveItems As
                | CD5SaveItems Set oSaveItems = oSaveOperation.Items
                |

        :return:
        """
        return self.cd5_save_operation.Items

    @property
    def retain_lock(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RetainLock
                | o Property RetainLock(    ) As
                | 
                | Returns (gets) or sets the value of the Save option "Retain
                | Lock". The default value is picked from the LCO/GCO.
                | Example: The following example sets the Retain Lock option
                | to True. oSaveOperation.RetainLock = True
                |

        :return:
        """
        return self.cd5_save_operation.RetainLock

    @retain_lock.setter
    def retain_lock(self, value):
        """
            :param type value:
        """
        self.cd5_save_operation.RetainLock = value 

    def run(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Run
                | o Sub Run(    )
                | 
                | Runs the Save as per the cusomization done so far. Example:
                | The following example executes the Save operation as per the
                | customization done so far. oSaveOperation.Run
                |
                | Parameters:

                |
        :return:
        """
        return self.cd5_save_operation.Run()

    def show_panel(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShowPanel
                | o Sub ShowPanel(    )
                | 
                | Shows the Save dialog as per the cusomization done so far.
                | Example: The following example shows the Save panel as per
                | the cusomization done so far. oSaveOperation.ShowPanel
                |
                | Parameters:

                |
        :return:
        """
        return self.cd5_save_operation.ShowPanel()

    def __repr__(self):
        return f'CD5SaveOperation()'
