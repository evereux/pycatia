#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5Structure(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the structure of an ENOVIA V6 object.Role: It represents
                | the structure of an ENOVIA V6 root object on which it is possible to
                | include some sub components. Its final purpose is to perform a Partial
                | Open on it, showing only the root and the sub components that were
                | previously included.  It is managed
                | byactivateLinkAnchor('CD5Engine','','CD5Engine').

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_structure = com_object     

    def get_root(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRoot
                | o Func GetRoot(    ) As
                | 
                | Returns the root ENOVIA V6 Identifier of the CD5Structure.
                | Returns: The CD5ID. Example: The following example creates a
                | Structure from "RootProduct" and gets its root identifier.
                | Dim oCD5Engine As CD5Engine Set oCD5Engine =
                | CATIA.GetItem("CD5Engine") Dim iRootCD5ID, oDummyCD5ID As
                | CD5ID Set iRootCD5ID = oCD5Engine.GetIDFromTNR("CATProduct
                | For Team", "RootProduct", "---") Dim oCD5Structure As
                | CD5Structure Set oCD5Structure =
                | oCD5Engine.GetStructure(iRootCD5ID) Set oDummyCD5ID =
                | oCD5Structure.GetRoot()
                |
                | Parameters:

                |
        :return:
        """
        return self.cd5_structure.GetRoot()

    def include(self, i_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | Include
                | o Sub Include(        iID)
                | 
                | Includes an sub component (identified by its ENOVIA V6
                | Identifier) for a future Partial Open operation.
                |
                | Parameters:
                | iID
                |  The ENOIACD5ID of the sub component to include.

                |                | Examples:
                | The following example creates a Structure from "RootProduct"
                | and includes the object "IncludedPart". Dim oCD5Engine As
                | CD5Engine Set oCD5Engine = CATIA.GetItem("CD5Engine") Dim
                | iRootCD5ID, iIncludedCD5ID As CD5ID Set iRootCD5ID =
                | oCD5Engine.GetIDFromTNR("CATProduct For Team",
                | "RootProduct", "---") Set iIncludedCD5ID =
                | oCD5Engine.GetIDFromTNR("CATProduct For Team",
                | "IncludedPart", "---") Dim oCD5Structure As CD5Structure Set
                | oCD5Structure = oCD5Engine.GetStructure(iRootCD5ID)
                | oCD5Structure.Include(iIncludedCD5ID)

        :param i_id:
        :return:
        """
        return self.cd5_structure.Include(i_id)

    def __repr__(self):
        return f'CD5Structure()'
