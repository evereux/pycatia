#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5Property(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a single property of an ENOVIA V6 object.Role: It
                | represents a single property tuple of a given object/document already
                | saved into ENOVIA. The purpose of this interface is to get the
                | information of a given property of an ENOVIA V6 object. The properties
                | are accessible through Edit/Properties menu item after user has
                | clicked the More button

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_property = com_object     

    @property
    def property_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PropertyName
                | o Property PropertyName(    ) As   (Read Only)
                | 
                | Returns (gets) the name of the ENOVIA V6 object property.
                | This is a readonly property. Throws: -1641847650 :
                | Connection to ENOVIA V6 is necessary to intialize this
                | option. Example: The following example retrieves Property
                | Name oCD5Property.PropertyName
                |

        :return:
        """
        return self.cd5_property.PropertyName

    @property
    def property_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PropertyValue
                | o Property PropertyValue(    ) As   (Read Only)
                | 
                | Returns (gets) the value of the ENOVIA V6 object property.
                | This is a readonly property. Throws: -1641847650 :
                | Connection to ENOVIA V6 is necessary to intialize this
                | option. Example: The following example retrieves Property
                | Value oCD5Property.PropertyValue
                |

        :return:
        """
        return self.cd5_property.PropertyValue

    def __repr__(self):
        return f'CD5Property()'
