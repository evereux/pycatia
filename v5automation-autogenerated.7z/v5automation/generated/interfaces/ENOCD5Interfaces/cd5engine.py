#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5Engine(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the ENOVIA V6 Integration Engine, that is to say the entry
                | point to the CATIA/ENOVIA V6 Integration.It allows end user to realize
                | the following operations : connection and disconnection to ENOVIA V6
                | Integration, creation of ENOVIA V6 Integration IDs (CD5ID) and
                | Structures (CD5Strcture), and  opening of the corresponding objects in
                | different modes.Note that all operations performed from this interface
                | are the same as operations available in the   ENOVIA V6 menu in CATIA,
                | unless most of them are executed without panel.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_engine = com_object     

    @property
    def expand_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExpandMode
                | o Property ExpandMode(    ) As
                | 
                | Returns (gets) or sets the value of the Open option "Expand
                | Mode". The default value is set in the user's Preferences.
                | Throws: -1641847650 : Connection to ENOVIA V6 is necessary
                | to intialize this option. Example: The following example
                | sets Expand Mode to LatestVersion, then displays it.
                | oCD5Engine.ExpandMode = "LatestVersion" MsgBox
                | oCD5Engine.ExpandMode
                |

        :return:
        """
        return self.cd5_engine.ExpandMode

    @expand_mode.setter
    def expand_mode(self, value):
        """
            :param type value:
        """
        self.cd5_engine.ExpandMode = value 

    @property
    def include_all_children(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IncludeAllChildren
                | o Property IncludeAllChildren(    ) As
                | 
                | Returns (gets) or sets the value of the Open option "Open
                | With". The default value is False, means Required Children.
                | Example: The following example sets Open With to All
                | Children. oCD5Engine.IncludeAllChildren = True
                |

        :return:
        """
        return self.cd5_engine.IncludeAllChildren

    @include_all_children.setter
    def include_all_children(self, value):
        """
            :param type value:
        """
        self.cd5_engine.IncludeAllChildren = value 

    @property
    def related_designs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RelatedDesigns
                | o Property RelatedDesigns(    ) As
                | 
                | Returns (gets) or sets the value of the Open option "Related
                | Designs". The default value is set in the user's
                | Preferences. Throws: -1641847650 : Connection to ENOVIA V6
                | is necessary to intialize this option. Example: The
                | following example sets Related Designs to Associated
                | Drawings, then displays it. oCD5Engine.RelatedDesigns =
                | "Associated Drawings" MsgBox oCD5Engine.RelatedDesigns
                |

        :return:
        """
        return self.cd5_engine.RelatedDesigns

    @related_designs.setter
    def related_designs(self, value):
        """
            :param type value:
        """
        self.cd5_engine.RelatedDesigns = value 

    def connect(self, i_user_name, i_user_password, i_security_context):
        """
        .. note::
            CAA V5 Visual Basic help

                | Connect
                | o Sub Connect(        iUserName,
                |                       iUserPassword,
                |                       iSecurityContext)
                | 
                | Connects to ENOVIA V6. It is equivalent to launch in CATIA
                | the command ENOVIA V6/Connect and enter the User
                | Name/Password/Security Context.
                |
                | Parameters:
                | iUserName
                |  The Login name of the end user, who wants to connect to ENOVIA V6.
                |  
                |  iUserPassword
                |  The associated Password of this end user.
                |  
                |  iSecurityContext
                |  The security context the end user wants to use (if empty, the API will first try to connect without security context then try again with the default one).
                |  
                | 
                |  Throws:
                |  
                | -1867244384 : The Document Location setting is incorrect.
                | -1878815075 : Invalid Password.
                | -1803748693 : Another user is already logged in.

                |                | Examples:
                | The following example connects end user to ENOVIA V6 on
                | CD5Engine oCD5Engine. The User Login is "xxx" and his
                | associated Password "yyy". Dim iUserName As CATBSTR
                | iUserName = "xxx" Dim iUserPassword As CATBSTR iUserPassword
                | = "yyy" oCD5Engine.Connect iUserName,iUserPassword,""

        :param i_user_name:
        :param i_user_password:
        :param i_security_context:
        :return:
        """
        return self.cd5_engine.Connect(i_user_name, i_user_password, i_security_context)

    def disconnect(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Disconnect
                | o Sub Disconnect(    )
                | 
                | Disconnects from ENOVIA V6. It is equivalent to launch in
                | CATIA the command ENOVIA V6/Disconnect. Example: The
                | following example disconnects end user from ENOVIA V6
                | Integration on CD5Engine oCD5Engine. oCD5Engine.Disconnect
                |
                | Parameters:

                |
        :return:
        """
        return self.cd5_engine.Disconnect()

    def get_id_from_tnr(self, i_type, i_name, i_revision):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIDFromTNR
                | o Func GetIDFromTNR(        iType,
                |                             iName,
                |                             iRevision) As
                | 
                | Creates a ENOVIA V6 Integration ID (CD5ID) from a Major
                | Object thanks to its Type, Name and Revision.
                |
                | Parameters:
                | iType
                |  The type of the ENOVIA V6 Object.
                |  
                |  iName
                |  The name of the ENOVIA V6 Object.
                |  
                |  iRevision
                |  The revision of the ENOVIA V6 Object.
                |  
                | 
                |  Returns:
                |   The created CD5ID.

                |                | Examples:
                | The following example creates a CD5ID from the major object
                | "MyProduct" of Type "CATProduct For Team" and Revision "---"
                | on CD5Engine oCD5Engine. Dim oCD5ID As CD5ID Set oCD5ID =
                | oCD5Engine.GetIDFromTNR("CATProduct For Team", "MyProduct",
                | "---")

        :param i_type:
        :param i_name:
        :param i_revision:
        :return:
        """
        return self.cd5_engine.GetIDFromTNR(i_type, i_name, i_revision)

    def get_id_from_tnrv(self, i_type, i_name, i_revision, i_version):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIDFromTNRV
                | o Func GetIDFromTNRV(        iType,
                |                              iName,
                |                              iRevision,
                |                              iVersion) As
                | 
                | Creates a ENOVIA V6 Integration ID (CD5ID) from a Minor
                | Object thanks to its Type, Name, Revision and Version.
                |
                | Parameters:
                | iType
                |  The type of the ENOVIA V6 Object.
                |  
                |  iName
                |  The name of the ENOVIA V6 Object.
                |  
                |  iRevision
                |  The revision of the ENOVIA V6 Object.
                |  
                |  iVersion
                |  The version of the ENOVIA V6 Object.
                |  
                | 
                |  Returns:
                |   The created CD5ID.

                |                | Examples:
                | The following example creates a CD5ID from the minor object
                | "MyProduct" of Type "CATProduct For Team", Revision "---"
                | and Version "0" on CD5Engine oCD5Engine. Dim oCD5ID As CD5ID
                | Set oCD5ID = oCD5Engine.GetIDFromTNRV("CATProduct For Team",
                | "MyProduct", "---", "0")

        :param i_type:
        :param i_name:
        :param i_revision:
        :param i_version:
        :return:
        """
        return self.cd5_engine.GetIDFromTNRV(i_type, i_name, i_revision, i_version)

    def get_structure(self, i_cd_5__i):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStructure
                | o Func GetStructure(        iCD5ID) As
                | 
                | Creates a Structure from a ENOVIA V6 Object identified by
                | its CD5ID, in the purpose of a future Partial Open.
                |
                | Parameters:
                | iCD5ID
                |  The CD5ID of the ENOVIA V6 Object, candidate for a partial open.
                |  
                | 
                |  Returns:
                |   The created CD5Structure.

                |                | Examples:
                | The following example creates a CD5Structure from the CD5ID
                | of an object on CD5Engine oCD5Engine. Dim iCD5ID As CD5ID
                | Set iCD5ID = oCD5Engine.GetIDFromTNR("CATProduct For Team",
                | "MyProduct", "---") Dim oCD5Structure As CD5Structure Set
                | oCD5Structure = oCD5Engine.GetStructure(iCD5ID)

        :param i_cd_5__i:
        :return:
        """
        return self.cd5_engine.GetStructure(i_cd_5__i)

    def interactive_open(self, i_cd_5__i):
        """
        .. note::
            CAA V5 Visual Basic help

                | InteractiveOpen
                | o Sub InteractiveOpen(        iCD5ID)
                | 
                | Launches the Interactive ENOVIA V6 Open Command and performs
                | the search with the input CD5ID.
                |
                | Parameters:
                | iCD5ID
                |  The ENOVIA V6 ID of the Object to open in CATIA.
                |  
                | 
                |  Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.

                |                | Examples:
                | The following example launches the interactive ENOVIA V6
                | Open Command on CD5Engine oCD5Engine, with the following
                | search criterias: Type : "CATProduct For Team". Name :
                | "MyProduct". Revision : "---". Dim myCD5ID As CD5ID Set
                | myCD5ID = oCD5Engine.GetIDFromTNR("CATProduct For Team",
                | "MyProduct", "---") oCD5Engine.InteractiveOpen(myCD5ID)

        :param i_cd_5__i:
        :return:
        """
        return self.cd5_engine.InteractiveOpen(i_cd_5__i)

    def is_connected(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsConnected
                | o Func IsConnected(    ) As
                | 
                | Returns if end user is connected to ENOVIA V6 (True) or not
                | (False). Example: The following example tests if end user is
                | connected to ENOVIA V6 Integration on CD5Engine oCD5Engine.
                | A MsgBox with the connection status will appear to the end
                | user. If end user is connected, the MsgBox will contain
                | "Connected", else it will contain "Not Connected". If
                | oCD5Engine.IsConnected Then MsgBox "Connected" Else MsgBox
                | "Not Connected" End If
                |
                | Parameters:

                |
        :return:
        """
        return self.cd5_engine.IsConnected()

    def open(self, i_cd_5__i):
        """
        .. note::
            CAA V5 Visual Basic help

                | Open
                | o Func Open(        iCD5ID) As
                | 
                | Opens a ENOVIA V6 Object in CATIA thanks to its previously
                | created CD5ID, and returns the created Document.
                |
                | Parameters:
                | iCD5ID
                |  The ENOVIA V6 ID of the Object to open in CATIA.
                |  
                | 
                |  Returns:
                |   The created Document.
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.
                | -1871171370 : Failed to get details of design objects.

                |                | Examples:
                | The following example opens an ENOVIA V6 Object in CATIA
                | from its CD5ID on CD5Engine oCD5Engine. Dim myCD5ID As CD5ID
                | Set myCD5ID = oCD5Engine.GetIDFromTNRV("CATProduct For
                | Team", "MyProduct", "---", "0") Dim oDocument As Document
                | Set oDocument = oCD5Engine.Open(myCD5ID)

        :param i_cd_5__i:
        :return:
        """
        return self.cd5_engine.Open(i_cd_5__i)

    def partial_open(self, i_cd_5__structur):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartialOpen
                | o Func PartialOpen(        iCD5Structure) As
                | 
                | Opens partially a ENOVIA V6 Object in CATIA thanks to its
                | previously created CD5Structure, and returns the created
                | Document.
                |
                | Parameters:
                | iCD5Structure
                |  The Structure of the Object to open in CATIA.
                |  
                | 
                |  Returns:
                |   The created Document.
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.
                | -1871171370 : Failed to get details of design objects.

                |                | Examples:
                | The following example opens partially the ENOVIA V6 Object
                | "RootProduct" and its subproduct "DummyProduct" in CATIA on
                | CD5Engine oCD5Engine. Dim iRootCD5ID As CD5ID Set iRootCD5ID
                | = oCD5Engine.GetIDFromTNR("CATProduct For Team",
                | "RootProduct", "---") Dim iSubCD5ID As CD5ID Set iSubCD5ID =
                | oCD5Engine.GetIDFromTNR("CATProduct For Team", "SubProduct",
                | "---") Dim iCD5Structure As CD5Structure Set iCD5Structure =
                | oCD5Engine.GetStructure(iRootCD5ID)
                | iCD5Structure.Include(iDummyCD5ID) Dim oDocument As Document
                | Set oDocument = oCD5Engine.PartialOpen(iCD5Structure)

        :param i_cd_5__structur:
        :return:
        """
        return self.cd5_engine.PartialOpen(i_cd_5__structur)

    def __repr__(self):
        return f'CD5Engine()'
