#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5Properties(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents a collection of all the properties of an ENOVIA V6
                | object.Role: It represents all the properties of a given
                | object/document already saved into ENOVIA. The purpose of this
                | interface is to get a collection of an ENOVIA V6 object properties.
                | The properties are accessible through Edit/Properties menu item after
                | user has clicked the More button It is managed
                | byactivateLinkAnchor('CD5Engine','','CD5Engine').

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_properties = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns ENOVIA V6 object property specified by 1 based
                | index. That is, 1th index is the first property ergo last
                | property is (Total Count)th Index Throws: -1641847650 :
                | Connection to ENOVIA V6 is necessary to intialize this
                | option. Example: The following example shows how to retrieve
                | a single property from the collection of all properties. Dim
                | objCD5Property As CD5Property Set objCD5Property =
                | objCD5Properties.Item(1)
                |
                | Parameters:

                |
        :param i_index:
        :return:
        """
        return self.cd5_properties.Item(i_index)

    def __repr__(self):
        return f'CD5Properties()'
