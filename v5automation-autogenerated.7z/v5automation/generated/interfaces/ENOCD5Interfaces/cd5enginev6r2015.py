#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CD5EngineV6R2015(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the ENOVIA V6 Integration Engine, that is to say the entry
                | point to the CATIA/ENOVIA V6 Integration.It allows end user to realize
                | the various operations like ENOVIA NewNote that all operations
                | performed from this interface are the same as operations available in
                | the   ENOVIA V6 menu in CATIA, unless most of them are executed
                | without panel.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cd5_engine_v6_r2015 = com_object     

    @property
    def template_types(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TemplateTypes
                | o Property TemplateTypes(    ) As   (Read Only)
                | 
                | Returns (gets) the list of all "Template Types". Example:
                | The following example gets the list of Template Types. Dim
                | oTemplateTypes As ENOIACD5TemplateTypes Set oTemplateTypes =
                | oCD5Engine.TemplateTypes
                |

        :return:
        """
        return self.cd5_engine_v6_r2015.TemplateTypes

    def get_id_from_physical_id(self, i_physical_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIDFromPhysicalID
                | o Func GetIDFromPhysicalID(        iPhysicalID) As
                | 
                | Returns CD5ID of the object for the given PhysicalID.
                |
                | Parameters:
                | iPhysicalID
                |  Physical ID of the object
                |  
                | 
                |  Returns:
                |   The created CD5ID of the object
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.

                |                | Examples:
                | The following example returns the ENOIACD5ID of the object:
                | iPhysicalID : "6EFB8D2E00008A445257E36100000DF7". Dim ID As
                | CD5ID Set ID = oCD5Engine.GetIDFromPhysicalID("6EFB8D2E00008
                | A445257E36100000DF7")

        :param i_physical_id:
        :return:
        """
        return self.cd5_engine_v6_r2015.GetIDFromPhysicalID(i_physical_id)

    def get_i_ds_from_physical_i_ds(self, i_physical_i_ds):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIDsFromPhysicalIDs
                | o Func GetIDsFromPhysicalIDs(        iPhysicalIDs) As
                | 
                | Returns CD5IDs of the objects for the given PhysicalIDs.
                |
                | Parameters:
                | iPhysicalIDs
                |  Physical IDs of the objects
                |  
                | 
                |  Returns:
                |   The created CD5ID array of the objects
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.

                |                | Examples:
                | The following example returns the ENOIACD5IDs of the object:
                | iPhysicalIDs : "6EFB8D2E00008A445257E36100000DF7,6EFB8D2E000
                | 08A445257E3610000090". Dim IDs As CD5IDs Set IDs =
                | oCD5Engine.GetIDsFromPhysicalIDs(iPhysicalIDs)

        :param i_physical_i_ds:
        :return:
        """
        return self.cd5_engine_v6_r2015.GetIDsFromPhysicalIDs(i_physical_i_ds)

    def get_properties(self, i_enoiacd_5__i):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProperties
                | o Func GetProperties(        iENOIACD5ID) As
                | 
                | Returns a collection of all the ENOVIA V6 properties for a
                | given Object defined by Type, Name, Revision & Version.
                |
                | Parameters:
                | iENOIACD5ID
                |  The ENOIACD5ID object id representing ENOVIA V6 Object which is to be explored.
                |  
                | 
                |  Returns:
                |   The collection of properties of the ENOVIA object passes as iENOIACD5ID
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.
                | -1691273589 : Invalid object type
                | -1857112104 : Name or Type Empty

                |                | Examples:
                | The following example retrieves all the ENOVIA V6 properties
                | from a given ENOIACD5ID. Dim ObjID As CD5ID Set ObjID =
                | oCD5Engine.GetIDFromTNRV("Versioned CATPart", "Part_Name",
                | "A", "0") Dim oCD5Properties As CD5Properties Set
                | oCD5Properties = oCD5Engine.GetProperties(ObjID)

        :param i_enoiacd_5__i:
        :return:
        """
        return self.cd5_engine_v6_r2015.GetProperties(i_enoiacd_5__i)

    def get_properties_of_document(self, i_catia_document):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPropertiesOfDocument
                | o Func GetPropertiesOfDocument(        iCATIADocument) As
                | 
                | Returns a collection of all the ENOVIA V6 properties for a
                | given ENOVIA object.
                |
                | Parameters:
                | iCATIADocument
                |  The document representing ENOVIA V6 Object which is to be explored.
                |  
                | 
                |  Returns:
                |   The collection of properties of the ENOVIA object passes as iCATIADocument
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.

                |                | Examples:
                | The following example retrieves all the ENOVIA V6 properties
                | for a given ENOVIA object. Dim docCD5ID As CD5ID Set
                | docCD5ID = oCD5Engine.GetIDFromTNR("CATProduct For Team",
                | "MyProduct", "---") Dim objDocument As Document Set
                | objDocument = oCD5Engine.Open(docCD5ID) Dim oCD5Properties
                | As CD5Properties Set oCD5Properties =
                | oCD5Engine.GetPropertiesOfDocument(objDocument)

        :param i_catia_document:
        :return:
        """
        return self.cd5_engine_v6_r2015.GetPropertiesOfDocument(i_catia_document)

    def get_properties_of_embedded_component(self, i_catia_document, i_embedded_component_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPropertiesOfEmbeddedComponent
                | o Func GetPropertiesOfEmbeddedComponent(        iCATIADocument,
                |                                                 iEmbeddedComponentName) As
                | 
                | Returns a collection of all the ENOVIA V6 properties for a
                | given Embedded Component.
                |
                | Parameters:
                | iCATIADocument
                |  The document representing ENOVIA V6 Object in which the target embedded component resides.
                |  
                |  iEmbeddedComponentName
                |  Name of the embedded component to be explored.
                |  
                | 
                |  Returns:
                |   The collection of properties of the embedded component passed as input
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.

                |                | Examples:
                | The following example retrieves all the ENOVIA V6 properties
                | for a given Embedded Component. Dim docCD5ID As CD5ID Set
                | docCD5ID = oCD5Engine.GetIDFromTNR("CATProduct For Team",
                | "MyProduct", "---") Dim objDocument As Document Set
                | objDocument = oCD5Engine.Open(docCD5ID) Dim oCD5Properties
                | As CD5Properties Set oCD5Properties =
                | oCD5Engine.GetPropertiesOfEmbeddedComponent(objDocument,
                | "Embedded_Component_Name")

        :param i_catia_document:
        :param i_embedded_component_name:
        :return:
        """
        return self.cd5_engine_v6_r2015.GetPropertiesOfEmbeddedComponent(i_catia_document, i_embedded_component_name)

    def new_from(self, i_cd_5__templat, i_name, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | NewFrom
                | o Func NewFrom(        iCD5Template,
                |                        iName,
                |                        iType) As
                | 
                | Creates a new object from given template.
                |
                | Parameters:
                | iCD5Template
                |  The Template object from which we want to create a new object.
                |  
                |  iName
                |  The name for the new object.
                |  
                |  iType
                |  The ENOVIA type for the new object.
                |  
                | 
                |  Returns:
                |   The created Document.
                |  
                |    Throws:
                |  
                | -1697450280 : CATIA is not connected to ENOVIA V6.
                | -1782306828 : Template object is assigned more than one file.
                | -1774688310 : Template object is not assigned any file.
                | -1866082326 : File of same name as that of file attached to Template object is present on checkout directory.
                | -1739257732 : The name for the new object contains unsupported characters.
                | -1706631745 : An object with the same name as that of new object is already present in ENOVIA.
                | -1844336441 : File of same name as that of new object is already present on checkout directory.

                |                | Examples:
                | The following example creates a new object to be loaded in
                | the CATIA session: iCD5Template : template. iName :
                | "NewPart". Dim types As Array types =
                | oTemplateType.PossibleTypes Dim document As CATIADocument
                | Set document = oCD5Engine.NewFrom(template, "NewPart",
                | types(0))

        :param i_cd_5__templat:
        :param i_name:
        :param i_type:
        :return:
        """
        return self.cd5_engine_v6_r2015.NewFrom(i_cd_5__templat, i_name, i_type)

    def __repr__(self):
        return f'CD5EngineV6R2015()'
