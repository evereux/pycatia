#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Limit(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the limit of a prism or a hole shape.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.limit = com_object     

    @property
    def dimension(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Dimension
                | o Property Dimension(    ) As   (Read Only)
                | 
                | Returns or sets the limit dimension. This property is valid
                | for the offset limit mode only, that is when is set to
                | catOffsetLimit .
                |

        :return:
        """
        return self.limit.Dimension

    @dimension.setter
    def dimension(self, value):
        """
            :param type value:
        """
        self.limit.Dimension = value 

    @property
    def limit_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LimitMode
                | o Property LimitMode(    ) As
                | 
                | Returns or sets the limit mode.
                |

        :return:
        """
        return self.limit.LimitMode

    @limit_mode.setter
    def limit_mode(self, value):
        """
            :param type value:
        """
        self.limit.LimitMode = value 

    @property
    def limiting_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LimitingElement
                | o Property LimitingElement(    ) As
                | 
                | Returns or sets the limiting element. This property is valid
                | when the limiting object is a surface or a plane, that is
                | when is set to catUpToSurfaceLimit and catUpToPlaneLimit. To
                | set the property, you can use the following object: .
                |

        :return:
        """
        return self.limit.LimitingElement

    @limiting_element.setter
    def limiting_element(self, value):
        """
            :param type value:
        """
        self.limit.LimitingElement = value 

    def __repr__(self):
        return f'Limit()'
