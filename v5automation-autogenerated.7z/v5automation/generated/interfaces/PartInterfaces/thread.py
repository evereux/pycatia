#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Thread(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Thread feature.It threads or taps cylindrical surface .

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.thread = com_object     

    @property
    def depth(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Depth
                | o Property Depth(    ) As
                | 
                | Returns the thread/tap depth. Returns: oDepth Value of the
                | thread/tap depth Example: The following example returns in
                | Depth the depth of thread firstthread: Set Depth =
                | firstthread.Depth
                |

        :return:
        """
        return self.thread.Depth

    @property
    def diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Diameter
                | o Property Diameter(    ) As
                | 
                | Returns the thread/tap diameter. Returns: oDiameter Value of
                | the thread/tap diameter Example: The following example
                | returns in ThreadDiameter the diameter of thread
                | firstthread: Set ThreadDiameter = firstthread.Diameter
                |

        :return:
        """
        return self.thread.Diameter

    @property
    def lateral_face_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LateralFaceElement
                | o Property LateralFaceElement(    ) As
                | 
                | Returns or sets the lateral face (must be cylindrical) . To
                | set the property, you can use the following object: .
                |

        :return:
        """
        return self.thread.LateralFaceElement

    @lateral_face_element.setter
    def lateral_face_element(self, value):
        """
            :param type value:
        """
        self.thread.LateralFaceElement = value 

    @property
    def limit_face_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LimitFaceElement
                | o Property LimitFaceElement(    ) As
                | 
                | Returns or sets the limit face (must be planar ) . To set
                | the property, you can use the following object: .
                |

        :return:
        """
        return self.thread.LimitFaceElement

    @limit_face_element.setter
    def limit_face_element(self, value):
        """
            :param type value:
        """
        self.thread.LimitFaceElement = value 

    @property
    def pitch(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Pitch
                | o Property Pitch(    ) As
                | 
                | Returns the thread/tap pitch. Returns: oPitch Value of the
                | thread/tap pitch Example: The following example returns in
                | ThreadPitch the thread pitch of thread firstthread: Set
                | ThreadPitch = firstthread.ThreadPitch
                |

        :return:
        """
        return self.thread.Pitch

    @property
    def side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Side
                | o Property Side(    ) As
                | 
                | Returns the thread or tap side. Returns: oThreadSide The
                | thread/tap side (see for list of possible sides) Example:
                | The following example returns in ThreadSide the thread/tap
                | side of thread firstthread: Set ThreadSide =
                | firstthreadoThreadSide
                |

        :return:
        """
        return self.thread.Side

    @property
    def thread_description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ThreadDescription
                | o Property ThreadDescription(    ) As   (Read Only)
                | 
                | Returns the thread/tap description parameter. This call is
                | valid only when a standard/user design table created
                | Returns: oThreadDescParam A Parameter object controlling the
                | thread/tap description (see for more information) Example:
                | The following example returns in threadDescription the
                | thread description (M12 etc) of thread firstthread: Set
                | threadDescription = firstthread.ThreadDescription
                |

        :return:
        """
        return self.thread.ThreadDescription

    def create_standard_thread_design_table(self, i_standard_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateStandardThreadDesignTable
                | o Sub CreateStandardThreadDesignTable(        iStandardType)
                | 
                | Creates a Standard Thread design table .
                |
                | Parameters:
                | iStandardType
                |    Standard type for thread (see 
                | 
                |  for list of possible types)

                |                | Examples:
                | The following example creates a standard table for
                | MetricThinPitch for thread firstthread:
                | firstthread.CreateStandardThreadDesignTable
                | catMetricThinPitch

        :param i_standard_type:
        :return:
        """
        return self.thread.CreateStandardThreadDesignTable(i_standard_type)

    def create_user_standard_design_table(self, i_standard_name, i_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateUserStandardDesignTable
                | o Sub CreateUserStandardDesignTable(        iStandardName,
                |                                             iPath)
                | 
                | Creates a UserStandard Thread design table .
                |
                | Parameters:
                | iStandardName
                |    Name of the UserStandard thread. iStandardName should be empty if filepath is to be defined.
                |  
                |  iPath
                |    Path of the UserStandard file. iPath is empty if the filepath is already defined through CATReffilesPath.
                |  
                | Example1:
                | The following example creates a standard table for UserStandard for
                |  thread firstThread. The file path is already defined thru CATReffilesPath:
                |  
                |  firstThread.CreateUserStandardDesignTable "UserStandard",""
                | 
                | 
                | Example2:
                | The following example creates a standard table for UserStandard for
                |  thread firstThread when file path is not defined thru CATReffilesPath:
                |  
                |  firstThread.CreateUserStandardDesignTable "","E:\user\standard\UserStandard.txt"

                |
        :param i_standard_name:
        :param i_path:
        :return:
        """
        return self.thread.CreateUserStandardDesignTable(i_standard_name, i_path)

    def reverse_direction(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReverseDirection
                | o Sub ReverseDirection(    )
                | 
                | Swap the direction of the thread or the tap.
                |
                | Parameters:

                |
        :return:
        """
        return self.thread.ReverseDirection()

    def set_explicit_polarity(self, i_thread_polarity):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetExplicitPolarity
                | o Sub SetExplicitPolarity(        iThreadPolarity)
                | 
                | Sets the thread polarity explicit. Thread polarity is no
                | more evaluated implicitly on basis of support face polarity
                |
                | Parameters:
                | iThreadPolarity
                |    Standard type for thread (see 
                | 
                |  for list of possible types)

                |                | Examples:
                | The following example sets the thread polarity to Tap
                | explicitly thread firstthread:
                | firstthread.SetExplicitPolarity catTap

        :param i_thread_polarity:
        :return:
        """
        return self.thread.SetExplicitPolarity(i_thread_polarity)

    def __repr__(self):
        return f'Thread()'
