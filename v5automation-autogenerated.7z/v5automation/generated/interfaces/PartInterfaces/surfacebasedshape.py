#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class SurfaceBasedShape(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the shapes based on Surface.It is the base object for Split
                | , SewSurface , CloseSurface and  ThickSurface shapes.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.surface_based_shape = com_object     

    @property
    def surface(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Surface
                | o Property Surface(    ) As
                | 
                | Returns or sets the surface.
                |

        :return:
        """
        return self.surface_based_shape.Surface

    @surface.setter
    def surface(self, value):
        """
            :param type value:
        """
        self.surface_based_shape.Surface = value 

    def __repr__(self):
        return f'SurfaceBasedShape()'
