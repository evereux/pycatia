#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class RemoveFace(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Remove Face operation.It removes a face or a set of
                | faces.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.remove_face = com_object     

    @property
    def keep_face(self, i_keep_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | KeepFace
                | o Property KeepFace(        iKeepFace) (Write Only)
                | 
                | Adds a new face to be Kept.
                |

        :param i_keep_face:
        :return:
        """
        return self.remove_face.KeepFace

    @property
    def keep_faces(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | KeepFaces
                | o Property KeepFaces(    ) As   (Read Only)
                | 
                | Get the specified faces to be kept.
                |

        :return:
        """
        return self.remove_face.KeepFaces

    @property
    def propagation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Propagation
                | o Property Propagation(    ) As   (Read Only)
                | 
                | Get the faces that will be removed.
                |

        :return:
        """
        return self.remove_face.Propagation

    @property
    def remove_face(self, i_remove_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveFace
                | o Property RemoveFace(        iRemoveFace) (Write Only)
                | 
                | Adds a new face to be removed.
                |

        :param i_remove_face:
        :return:
        """
        return self.remove_face.RemoveFace

    @property
    def remove_faces(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveFaces
                | o Property RemoveFaces(    ) As   (Read Only)
                | 
                | Get the specified faces to be removed.
                |

        :return:
        """
        return self.remove_face.RemoveFaces

    def remove__keep_face(self, i_keep_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | remove_KeepFace
                | o Sub remove_KeepFace(        iKeepFace)
                | 
                | Removes a face to be Kept.
                |
                | Parameters:
                | iKeepFace
                |    The new face to process
                |    The following 
                | 
                |  object is supported:    
                | .

                |
        :param i_keep_face:
        :return:
        """
        return self.remove_face.remove_KeepFace(i_keep_face)

    def remove__remove_face(self, i_remove_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | remove_RemoveFace
                | o Sub remove_RemoveFace(        iRemoveFace)
                | 
                | Removes a face to be removed.
                |
                | Parameters:
                | iRemoveFace
                |    The new face to process
                |    The following 
                | 
                |  object is supported:    
                | .

                |
        :param i_remove_face:
        :return:
        """
        return self.remove_face.remove_RemoveFace(i_remove_face)

    def __repr__(self):
        return f'RemoveFace()'
