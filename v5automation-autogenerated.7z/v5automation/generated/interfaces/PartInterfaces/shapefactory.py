#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ShapeFactory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the factory for shapes to create all kinds of shapes that
                | may be needed for part design.The Shapefactory mission is to build
                | from scratch shapes that  will be used within the design process of
                | parts. Those shapes have a  strong mechanical built-in knowledge, such
                | as chamfer or hole, and in  most cases apply contextually to the part
                | being designed. When created,  they become part of the definition of
                | whicheverbodyorshapethat is current at that time. After they are
                | created, they  become in turn the currentbodyorshape. In most cases,
                | shapes are created from a factory with a minimum number  of
                | parametersr. Other shapes parameters may be set further on by using
                | methods offered by the shape itself.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.shape_factory = com_object     

    def add_new_add(self, i_body_to_add):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewAdd
                | o Func AddNewAdd(        iBodyToAdd) As
                | 
                | Creates and returns a new add operation within the current
                | body.
                |
                | Parameters:
                | iBodyToAdd
                |    The body to add to the current body
                |  
                | 
                |  Returns:
                |   The created add operation

                |
        :param i_body_to_add:
        :return:
        """
        return self.shape_factory.AddNewAdd(i_body_to_add)

    def add_new_affinity2(self, x_ratio, y_ratio, z_ratio):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewAffinity2
                | o Func AddNewAffinity2(        XRatio,
                |                                YRatio,
                |                                ZRatio) As
                | 
                | Creates and returns a Affinity feature.
                |
                | Parameters:
                | XRatio
                | 	Value for the XRatio.
                |  
                |  YRatio
                | 	Value for the YRatio.
                |  
                |  ZRatio
                | 	Value for the ZRatio.
                |  
                | 
                |  Returns:
                |   the created Affinity feature.

                |
        :param x_ratio:
        :param y_ratio:
        :param z_ratio:
        :return:
        """
        return self.shape_factory.AddNewAffinity2(x_ratio, y_ratio, z_ratio)

    def add_new_assemble(self, i_body_to_assemble):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewAssemble
                | o Func AddNewAssemble(        iBodyToAssemble) As
                | 
                | Creates and returns a new assembly operation within the
                | current body.
                |
                | Parameters:
                | iBodyToAssemble
                |    The body to assemble with the current body
                |  
                | 
                |  Returns:
                |   The created assembly operation

                |
        :param i_body_to_assemble:
        :return:
        """
        return self.shape_factory.AddNewAssemble(i_body_to_assemble)

    def add_new_auto_draft(self, i_draft_angle):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewAutoDraft
                | o Func AddNewAutoDraft(        iDraftAngle) As
                | 
                | Creates and returns a new solid autodraft. Use this method
                | to create autodraft by providing draft angle.
                |
                | Parameters:
                | iDraftAngle
                |    The draft angle.
                |  
                | 
                |  Returns:
                |   The created autodraft.

                |
        :param i_draft_angle:
        :return:
        """
        return self.shape_factory.AddNewAutoDraft(i_draft_angle)

    def add_new_auto_fillet(self, i_fillet_radius, i_round_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewAutoFillet
                | o Func AddNewAutoFillet(        iFilletRadius,
                |                                 iRoundRadius) As
                | 
                | Creates and returns a new solid autofillet. Use this method
                | to create autofillet by providing fillet and round radius
                | values.
                |
                | Parameters:
                | iFilletRadius
                |    The fillet radius
                |  
                |  iRoundRadius
                |     The round radius
                |  
                | 
                |  Returns:
                |   The created autofillet

                |
        :param i_fillet_radius:
        :param i_round_radius:
        :return:
        """
        return self.shape_factory.AddNewAutoFillet(i_fillet_radius, i_round_radius)

    def add_new_axis_to_axis2(self, i_reference, i_target):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewAxisToAxis2
                | o Func AddNewAxisToAxis2(        iReference,
                |                                  iTarget) As
                | 
                | Creates and returns an AxisToAxis transformation feature.
                |
                | Parameters:
                | iReference
                | 	The refrence axis.
                |  
                |  iTarget
                | 	The target axis.
                |  
                | 
                |  Returns:
                |   The created AxisToAxis transformation feature.

                |
        :param i_reference:
        :param i_target:
        :return:
        """
        return self.shape_factory.AddNewAxisToAxis2(i_reference, i_target)

    def add_new_blend(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewBlend
                | o Func AddNewBlend(    ) As
                | 
                | Creates and returns a new Blend feature. Returns: The
                | created Blend feature
                |
                | Parameters:

                |
        :return:
        """
        return self.shape_factory.AddNewBlend()

    def add_new_chamfer(self, i_object_to_chamfer, i_propagation, i_mode, i_orientation, i_length_1, i_length_2__or_angl):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewChamfer
                | o Func AddNewChamfer(        iObjectToChamfer,
                |                              iPropagation,
                |                              iMode,
                |                              iOrientation,
                |                              iLength1,
                |                              iLength2OrAngle) As
                | 
                | Creates and returns a new chamfer within the current body.
                |
                | Parameters:
                | iObjectToChamfer
                |    The first edge or face to chamfer
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iPropagation
                |    Controls if and how the chamfering operation should propagate beyond the 
                |    first chamfer element iObjectToChamfer, when it is an edge
                |  
                |  iMode
                |    Controls if the chamfer is defined by two lengthes, or by an angle and a 
                |    length
                |    
                |    The value of this argument changes the way the arguments iLength1
                |    and iLength2OrAngle should be interpreted.
                |  
                |  iOrientation
                |    Defines the relative meaning of arguments iLength1 and 
                |    iLength2OrAngle when defining a chamfer by two lengthes
                |  
                |  iLength1
                |    The first value for chamfer dimensioning. It represents the chamfer 
                |    first length if the chamfer is defined by two lengthes, or the chamfer
                |    length if the chamfer is defined by a length and an angle. 
                |  
                |  iLength2OrAngle
                |    The second value for chamfer dimensioning. It represents the chamfer 
                |    second length if the chamfer is defined by two lengthes, or the chamfer
                |    angle if the chamfer is defined by a length and an angle. 
                |  
                |  Returns:
                |   The created chamfer

                |
        :param i_object_to_chamfer:
        :param i_propagation:
        :param i_mode:
        :param i_orientation:
        :param i_length_1:
        :param i_length_2__or_angl:
        :return:
        """
        return self.shape_factory.AddNewChamfer(i_object_to_chamfer, i_propagation, i_mode, i_orientation, i_length_1, i_length_2__or_angl)

    def add_new_circ_pattern(self, i_shape_to_copy, i_nb_of_copies_in_radial_dir, i_nb_of_copies_in_angular_dir, i_step_in_radial_dir, i_step_in_angular_dir, i_shape_to_copy_position_along_radial_dir, i_shape_to_copy_position_along_angular_dir, i_rotation_center, i_rotation_axis, i_is_reversed_rotation_axis, i_rotation_angle, i_is_radius_aligned):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewCircPattern
                | o Func AddNewCircPattern(        iShapeToCopy,
                |                                  iNbOfCopiesInRadialDir,
                |                                  iNbOfCopiesInAngularDir,
                |                                  iStepInRadialDir,
                |                                  iStepInAngularDir,
                |                                  iShapeToCopyPositionAlongRadialDir,
                |                                  iShapeToCopyPositionAlongAngularDir,
                |                                  iRotationCenter,
                |                                  iRotationAxis,
                |                                  iIsReversedRotationAxis,
                |                                  iRotationAngle,
                |                                  iIsRadiusAligned) As
                | 
                | Creates and returns a new circular pattern within the
                | current body.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the circular pattern
                |  
                |  iNbOfInstancesInRadialDir
                |    The number of times iShapeToCopy will be copied along
                |    pattern radial direction
                |  
                |  iNbOfInstancesInAngularDir
                |    The number of times iShapeToCopy will be copied along
                |    pattern angular direction
                |  
                |  iStepInRadialDir
                |    The distance that will separate two consecutive copies in the pattern
                |    along its radial direction
                |  
                |  iStepInAngularDir
                |    The angle that will separate two consecutive copies in the pattern
                |    along its angular direction
                |  
                |  iShapeToCopyPositionAlongRadialDir
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along the radial direction
                |  
                |  iShapeToCopyPositionAlongAngularDir
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along the angular direction
                |  
                |  iRotationCenter
                |    The point or vertex that specifies the pattern center of rotation
                |  
                |  iRotationAxis
                |    The line or linear edge that specifies the axis around which instances
                |    will be rotated relative to each other
                |  The following 
                | 
                |  objects are supported:  
                |  , 
                |  , 
                |  and 
                | . 
                |      iIsReversedRotationAxis
                |    The boolean flag indicating wether the natural orientation of 
                |    iRotationAxis should be used to orient the pattern operation.
                |    A value 
                |    of true indicates that iItemToDuplicate are copied in the 
                |    direction of the natural orientation of iRotationAxis.
                |  
                |  iRotationAngle
                |    The angle applied to the direction iRotationAxis 
                |    prior to applying the pattern.
                |    The original shape iShapeToCopy is used as the rotation center.
                |    Nevertheless, the copied shapes themselves are not rotated.
                |    This allows the definition of a circular pattern 
                |    relatively to existing geometry, but not necessarily parallel to it.
                |  
                |  iIsRadiusAligned
                |    The boolean flag that specifies whether the instances
                |    of iItemToDuplicate
                |    copied by the pattern should be kept parallel to each other (True)
                |    or if they should 
                |    be aligned with the radial direction they lie upon (False).
                |  
                |  Returns:
                |   The created circular pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies_in_radial_dir:
        :param i_nb_of_copies_in_angular_dir:
        :param i_step_in_radial_dir:
        :param i_step_in_angular_dir:
        :param i_shape_to_copy_position_along_radial_dir:
        :param i_shape_to_copy_position_along_angular_dir:
        :param i_rotation_center:
        :param i_rotation_axis:
        :param i_is_reversed_rotation_axis:
        :param i_rotation_angle:
        :param i_is_radius_aligned:
        :return:
        """
        return self.shape_factory.AddNewCircPattern(i_shape_to_copy, i_nb_of_copies_in_radial_dir, i_nb_of_copies_in_angular_dir, i_step_in_radial_dir, i_step_in_angular_dir, i_shape_to_copy_position_along_radial_dir, i_shape_to_copy_position_along_angular_dir, i_rotation_center, i_rotation_axis, i_is_reversed_rotation_axis, i_rotation_angle, i_is_radius_aligned)

    def add_new_circ_patternof_list(self, i_shape_to_copy, i_nb_of_copies_in_radial_dir, i_nb_of_copies_in_angular_dir, i_step_in_radial_dir, i_step_in_angular_dir, i_shape_to_copy_position_along_radial_dir, i_shape_to_copy_position_along_angular_dir, i_rotation_center, i_rotation_axis, i_is_reversed_rotation_axis, i_rotation_angle, i_is_radius_aligned):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewCircPatternofList
                | o Func AddNewCircPatternofList(        iShapeToCopy,
                |                                        iNbOfCopiesInRadialDir,
                |                                        iNbOfCopiesInAngularDir,
                |                                        iStepInRadialDir,
                |                                        iStepInAngularDir,
                |                                        iShapeToCopyPositionAlongRadialDir,
                |                                        iShapeToCopyPositionAlongAngularDir,
                |                                        iRotationCenter,
                |                                        iRotationAxis,
                |                                        iIsReversedRotationAxis,
                |                                        iRotationAngle,
                |                                        iIsRadiusAligned) As
                | 
                | V5R8 Only: Creates and returns a new circular pattern within
                | the current body using a list of shapes.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the circular pattern.
                |    Others shapes will be add by put_ItemToCopy with CATIAPattern interface
                |  
                |  iNbOfInstancesInRadialDir
                |    The number of times iShapeToCopy will be copied along
                |    pattern radial direction
                |  
                |  iNbOfInstancesInAngularDir
                |    The number of times iShapeToCopy will be copied along
                |    pattern angular direction
                |  
                |  iStepInRadialDir
                |    The distance that will separate two consecutive copies in the pattern
                |    along its radial direction
                |  
                |  iStepInAngularDir
                |    The angle that will separate two consecutive copies in the pattern
                |    along its angular direction
                |  
                |  iShapeToCopyPositionAlongRadialDir
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along the radial direction
                |  
                |  iShapeToCopyPositionAlongAngularDir
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along the angular direction
                |  
                |  iRotationCenter
                |    The point or vertex that specifies the pattern center of rotation
                |  
                |  iRotationAxis
                |    The line or linear edge that specifies the axis around which instances
                |    will be rotated relative to each other
                |  
                |  iIsReversedRotationAxis
                |    The boolean flag indicating wether the natural orientation of 
                |    iRotationAxis should be used to orient the pattern operation.
                |    A value 
                |    of true indicates that iItemToDuplicate are copied in the 
                |    direction of the natural orientation of iRotationAxis.
                |  
                |  iRotationAngle
                |    The angle applied to the direction iRotationAxis 
                |    prior to applying the pattern.
                |    The original shape iShapeToCopy is used as the rotation center.
                |    Nevertheless, the copied shapes themselves are not rotated.
                |    This allows the definition of a circular pattern 
                |    relatively to existing geometry, but not necessarily parallel to it.
                |  
                |  iIsRadiusAligned
                |    The boolean flag that specifies whether the instances
                |    of iItemToDuplicate
                |    copied by the pattern should be kept parallel to each other (True)
                |    or if they should 
                |    be aligned with the radial direction they lie upon (False).
                |  
                | 
                |  Returns:
                |   The created circular pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies_in_radial_dir:
        :param i_nb_of_copies_in_angular_dir:
        :param i_step_in_radial_dir:
        :param i_step_in_angular_dir:
        :param i_shape_to_copy_position_along_radial_dir:
        :param i_shape_to_copy_position_along_angular_dir:
        :param i_rotation_center:
        :param i_rotation_axis:
        :param i_is_reversed_rotation_axis:
        :param i_rotation_angle:
        :param i_is_radius_aligned:
        :return:
        """
        return self.shape_factory.AddNewCircPatternofList(i_shape_to_copy, i_nb_of_copies_in_radial_dir, i_nb_of_copies_in_angular_dir, i_step_in_radial_dir, i_step_in_angular_dir, i_shape_to_copy_position_along_radial_dir, i_shape_to_copy_position_along_angular_dir, i_rotation_center, i_rotation_axis, i_is_reversed_rotation_axis, i_rotation_angle, i_is_radius_aligned)

    def add_new_close_surface(self, i_close_element):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewCloseSurface
                | o Func AddNewCloseSurface(        iCloseElement) As
                | 
                | Creates and returns a new CloseSurface feature.
                |
                | Parameters:
                | iCloseElement
                |    The skin that will be closed and add with the current body
                |  
                | 
                |  Returns:
                |   The created CloseSurface feature

                |
        :param i_close_element:
        :return:
        """
        return self.shape_factory.AddNewCloseSurface(i_close_element)

    def add_new_defeaturing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewDefeaturing
                | o Func AddNewDefeaturing(    ) As
                | 
                | Creates and returns a new defeaturing operation within the
                | current container. Returns: The created defeaturing
                | operation
                |
                | Parameters:

                |
        :return:
        """
        return self.shape_factory.AddNewDefeaturing()

    def add_new_draft(self, i_face_to_draft, i_neutral, i_neutral_mode, i_parting, i_dir_x, i_dir_y, i_dir_z, i_mode, i_angle, i_multiselection_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewDraft
                | o Func AddNewDraft(        iFaceToDraft,
                |                            iNeutral,
                |                            iNeutralMode,
                |                            iParting,
                |                            iDirX,
                |                            iDirY,
                |                            iDirZ,
                |                            iMode,
                |                            iAngle,
                |                            iMultiselectionMode) As
                | 
                | Creates and returns a new draft within the current body. The
                | draft needs a reference face on the body. This face will
                | remain unchanged in the draft operation, while faces
                | adjacent to it and specified for drafting will be rotated by
                | the draft angle.
                |
                | Parameters:
                | iFaceToDraft
                |    The first face to draft in the body. This face should be adjacent to the 
                |    iFaceToDraft face. If several faces are to be drafted, only the 
                |    first one is specified here, the others being inferred by propagating the
                |    draft operation onto faces adjacent to this first face. This is 
                |    controlled by the iNeutralMode argument.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iNeutral
                |    The reference face for the draft. The draft needs a reference face on 
                |    the body, that will remain unchanged in the draft operation, while faces
                |    adjacent to it and specified for drafting will be rotated according 
                |    to the draft angle iAngle.
                |  The following 
                |  object is supported:  
                | . 
                |      iNeutralMode
                |    Controls if and how the drafting operation should be propagated beyond the 
                |    first face to draft iFaceToDraft to other adjacent faces. 
                |  
                |  iParting
                |     The draft parting plane, face or surface.
                |    It specifies the element within the body to draft 
                |    that represents the bottom of the mold. This element can be located either
                |    somewhere in the middle of the body or be one of its boundary faces. 
                |    When located in the middle of the body, it crosses the faces to draft, 
                |    and as a result, those faces are drafted with a positive angle on one 
                |    side of the parting surface, and with a negative angle on the other side.
                |  The following 
                |  object is supported:  
                | . 
                |      iDirX,iDirY,iDirZ
                |    The X, Y, and Z components of the absolute vector representing the drafting
                |    direction (i.e. the mold extraction direction).
                |  
                |  iMode
                |    The draft connecting mode to its reference face iFaceToDraft
                | 
                |  iAngle
                |    The draft angle
                |  
                |  iMultiselectionMode.
                |  The elements to be drafted can be selected explicitly
                |  or can implicitly selected as neighbors of the neutral face
                |  
                |  Returns:
                |   The created draft

                |
        :param i_face_to_draft:
        :param i_neutral:
        :param i_neutral_mode:
        :param i_parting:
        :param i_dir_x:
        :param i_dir_y:
        :param i_dir_z:
        :param i_mode:
        :param i_angle:
        :param i_multiselection_mode:
        :return:
        """
        return self.shape_factory.AddNewDraft(i_face_to_draft, i_neutral, i_neutral_mode, i_parting, i_dir_x, i_dir_y, i_dir_z, i_mode, i_angle, i_multiselection_mode)

    def add_new_edge_fillet_with_constant_radius(self, i_edge_to_fillet, i_propag_mode, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewEdgeFilletWithConstantRadius
                | o Func AddNewEdgeFilletWithConstantRadius(        iEdgeToFillet,
                |                                                   iPropagMode,
                |                                                   iRadius) As
                | 
                | Deprecated: V5R14 #AddNewEdgeFilletWithConstantRadius use
                | AddNewSolidEdgeFilletWithConstantRadius or
                | AddNewSurfaceEdgeFilletWithConstantRadius depending on the
                | type of fillet you want to create
                |
                | Parameters:

                |
        :param i_edge_to_fillet:
        :param i_propag_mode:
        :param i_radius:
        :return:
        """
        return self.shape_factory.AddNewEdgeFilletWithConstantRadius(i_edge_to_fillet, i_propag_mode, i_radius)

    def add_new_edge_fillet_with_varying_radius(self, i_edge_to_fillet, i_propag_mode, i_variation_mode, i_default_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewEdgeFilletWithVaryingRadius
                | o Func AddNewEdgeFilletWithVaryingRadius(        iEdgeToFillet,
                |                                                  iPropagMode,
                |                                                  iVariationMode,
                |                                                  iDefaultRadius) As
                | 
                | Deprecated: V5R14 #AddNewEdgeFilletWithVaryingRadius use
                | AddNewSolidEdgeFilletWithVaryingRadius or
                | AddNewSurfaceEdgeFilletWithVaryingRadius depending on the
                | type of fillet you want to create
                |
                | Parameters:

                |
        :param i_edge_to_fillet:
        :param i_propag_mode:
        :param i_variation_mode:
        :param i_default_radius:
        :return:
        """
        return self.shape_factory.AddNewEdgeFilletWithVaryingRadius(i_edge_to_fillet, i_propag_mode, i_variation_mode, i_default_radius)

    def add_new_face_fillet(self, i_f_1, i_f_2, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewFaceFillet
                | o Func AddNewFaceFillet(        iF1,
                |                                 iF2,
                |                                 iRadius) As
                | 
                | Deprecated: V5R14 #AddNewFaceFillet use
                | AddNewSolidFaceFillet or AddNewSurfaceFaceFillet depending
                | on the type of fillet you want to create
                |
                | Parameters:

                |
        :param i_f_1:
        :param i_f_2:
        :param i_radius:
        :return:
        """
        return self.shape_factory.AddNewFaceFillet(i_f_1, i_f_2, i_radius)

    def add_new_gsd_circ_pattern(self, i_shape_to_copy, i_nb_of_copies_in_radial_dir, i_nb_of_copies_in_angular_dir, i_step_in_radial_dir, i_step_in_angular_dir, i_shape_to_copy_position_along_radial_dir, i_shape_to_copy_position_along_angular_dir, i_rotation_center, i_rotation_axis, i_is_reversed_rotation_axis, i_rotation_angle, i_is_radius_aligned, i_complete_crown, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewGSDCircPattern
                | o Func AddNewGSDCircPattern(        iShapeToCopy,
                |                                     iNbOfCopiesInRadialDir,
                |                                     iNbOfCopiesInAngularDir,
                |                                     iStepInRadialDir,
                |                                     iStepInAngularDir,
                |                                     iShapeToCopyPositionAlongRadialDir,
                |                                     iShapeToCopyPositionAlongAngularDir,
                |                                     iRotationCenter,
                |                                     iRotationAxis,
                |                                     iIsReversedRotationAxis,
                |                                     iRotationAngle,
                |                                     iIsRadiusAligned,
                |                                     iCompleteCrown,
                |                                     iType) As
                | 
                | Deprecated: V5R15 #AddNewSurfacicCircPattern
                |
                | Parameters:

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies_in_radial_dir:
        :param i_nb_of_copies_in_angular_dir:
        :param i_step_in_radial_dir:
        :param i_step_in_angular_dir:
        :param i_shape_to_copy_position_along_radial_dir:
        :param i_shape_to_copy_position_along_angular_dir:
        :param i_rotation_center:
        :param i_rotation_axis:
        :param i_is_reversed_rotation_axis:
        :param i_rotation_angle:
        :param i_is_radius_aligned:
        :param i_complete_crown:
        :param i_type:
        :return:
        """
        return self.shape_factory.AddNewGSDCircPattern(i_shape_to_copy, i_nb_of_copies_in_radial_dir, i_nb_of_copies_in_angular_dir, i_step_in_radial_dir, i_step_in_angular_dir, i_shape_to_copy_position_along_radial_dir, i_shape_to_copy_position_along_angular_dir, i_rotation_center, i_rotation_axis, i_is_reversed_rotation_axis, i_rotation_angle, i_is_radius_aligned, i_complete_crown, i_type)

    def add_new_gsd_rect_pattern(self, i_shape_to_copy, i_nb_of_copies_in_dir_1, i_nb_of_copies_in_dir_2, i_step_in_dir_1, i_step_in_dir_2, i_shape_to_copy_position_along_dir_1, i_shape_to_copy_position_along_dir_2, i_dir_1, i_dir_2, i_is_reversed_dir_1, i_is_reversed_dir_2, i_rotation_angle, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewGSDRectPattern
                | o Func AddNewGSDRectPattern(        iShapeToCopy,
                |                                     iNbOfCopiesInDir1,
                |                                     iNbOfCopiesInDir2,
                |                                     iStepInDir1,
                |                                     iStepInDir2,
                |                                     iShapeToCopyPositionAlongDir1,
                |                                     iShapeToCopyPositionAlongDir2,
                |                                     iDir1,
                |                                     iDir2,
                |                                     iIsReversedDir1,
                |                                     iIsReversedDir2,
                |                                     iRotationAngle,
                |                                     iType) As
                | 
                | Deprecated: V5R15 #AddNewSurfacicRectPattern
                |
                | Parameters:

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies_in_dir_1:
        :param i_nb_of_copies_in_dir_2:
        :param i_step_in_dir_1:
        :param i_step_in_dir_2:
        :param i_shape_to_copy_position_along_dir_1:
        :param i_shape_to_copy_position_along_dir_2:
        :param i_dir_1:
        :param i_dir_2:
        :param i_is_reversed_dir_1:
        :param i_is_reversed_dir_2:
        :param i_rotation_angle:
        :param i_type:
        :return:
        """
        return self.shape_factory.AddNewGSDRectPattern(i_shape_to_copy, i_nb_of_copies_in_dir_1, i_nb_of_copies_in_dir_2, i_step_in_dir_1, i_step_in_dir_2, i_shape_to_copy_position_along_dir_1, i_shape_to_copy_position_along_dir_2, i_dir_1, i_dir_2, i_is_reversed_dir_1, i_is_reversed_dir_2, i_rotation_angle, i_type)

    def add_new_groove(self, i_sketch):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewGroove
                | o Func AddNewGroove(        iSketch) As
                | 
                | Creates and returns a new groove within the current body.
                | The , as a supertype for grooves, provides starting and
                | ending angles for the groove definition.
                |
                | Parameters:
                | iSketch
                |    The sketch defining the groove section.
                |    The sketch must contain
                |    a contour and an axis that will be used to rotate 
                |    the contour in the space, thus defining the groove. The contour has to 
                |    penetrate in 3D space the current shape.
                |  
                | 
                |  Returns:
                |   The created groove

                |
        :param i_sketch:
        :return:
        """
        return self.shape_factory.AddNewGroove(i_sketch)

    def add_new_groove_from_ref(self, i_profile_elt):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewGrooveFromRef
                | o Func AddNewGrooveFromRef(        iProfileElt) As
                | 
                | Creates and returns a new groove within the current body.
                |
                | Parameters:
                | iProfileElt
                |    The reference on the element defining the groove base
                |  
                | 
                |  Returns:
                |   The created groove

                |
        :param i_profile_elt:
        :return:
        """
        return self.shape_factory.AddNewGrooveFromRef(i_profile_elt)

    def add_new_hole(self, i_support, i_depth):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewHole
                | o Func AddNewHole(        iSupport,
                |                           iDepth) As
                | 
                | Creates and returns a new hole within the current shape.
                | Actual hole shape is defined by editing hole properties
                | after its creation.
                |
                | Parameters:
                | iSupport
                |    The support defining the hole reference plane.
                |    
                |    Anchor point is located at the barycenter of the support. 
                |    The hole axis in 3D passes through that point and is normal to the plane.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iDepth
                |    The hole depth.
                |  
                |  Returns:
                |   The created hole

                |
        :param i_support:
        :param i_depth:
        :return:
        """
        return self.shape_factory.AddNewHole(i_support, i_depth)

    def add_new_hole_from_point(self, i_x, i_y, i_z, i_support, i_depth):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewHoleFromPoint
                | o Func AddNewHoleFromPoint(        iX,
                |                                    iY,
                |                                    iZ,
                |                                    iSupport,
                |                                    iDepth) As
                | 
                | Creates and returns a new hole within the current shape.
                | Actual hole shape is defined by editing hole properties
                | after its creation.
                |
                | Parameters:
                | iX
                |    Origin point x absolute coordinate
                |  
                |  iY
                |    Origin point y absolute coordinate
                |  
                |  iZ
                |    Origin point z absolute coordinate
                |    
                |    Sets the origin point which the hole is anchored to. 
                |    If mandatory, the entry point will be projected onto a tangent plane.
                |  
                |  iSupport
                |    The support defining the hole reference plane.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iDepth
                |    The hole depth.
                |  
                |  Returns:
                |   The created hole

                |
        :param i_x:
        :param i_y:
        :param i_z:
        :param i_support:
        :param i_depth:
        :return:
        """
        return self.shape_factory.AddNewHoleFromPoint(i_x, i_y, i_z, i_support, i_depth)

    def add_new_hole_from_ref_point(self, i_origin, i_support, i_depth):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewHoleFromRefPoint
                | o Func AddNewHoleFromRefPoint(        iOrigin,
                |                                       iSupport,
                |                                       iDepth) As
                | 
                | Creates and returns a new hole within the current shape.
                | Actual hole shape is defined by editing hole properties
                | after its creation.
                |
                | Parameters:
                | iOrigin
                |    The origin point which the hole is anchored to.
                |  
                |  iSupport
                |    The support defining the hole reference plane.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iDepth
                |    The hole depth.
                |  
                |  Returns:
                |   The created hole

                |
        :param i_origin:
        :param i_support:
        :param i_depth:
        :return:
        """
        return self.shape_factory.AddNewHoleFromRefPoint(i_origin, i_support, i_depth)

    def add_new_hole_from_sketch(self, i_sketch, i_depth):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewHoleFromSketch
                | o Func AddNewHoleFromSketch(        iSketch,
                |                                     iDepth) As
                | 
                | Creates and returns a new hole within the current shape.
                | Actual hole shape is defined by editing hole properties
                | after its creation.
                |
                | Parameters:
                | iSketch
                |    The sketch defining the hole reference plane and anchor point.
                |    
                |    This sketch must contain a single point that defines the hole axis: 
                |    the hole axis in 3D passes through that point and is normal to the 
                |    sketch plane.
                |  
                |  iDepth
                |    The hole depth.
                |  
                | 
                |  Returns:
                |   The created hole

                |
        :param i_sketch:
        :param i_depth:
        :return:
        """
        return self.shape_factory.AddNewHoleFromSketch(i_sketch, i_depth)

    def add_new_hole_with2_constraints(self, i_x, i_y, i_z, i_edge_1, i_edge_2, i_support, i_depth):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewHoleWith2Constraints
                | o Func AddNewHoleWith2Constraints(        iX,
                |                                           iY,
                |                                           iZ,
                |                                           iEdge1,
                |                                           iEdge2,
                |                                           iSupport,
                |                                           iDepth) As
                | 
                | Creates and returns a new hole within the current shape.
                | Actual hole shape is defined by editing hole properties
                | after its creation.
                |
                | Parameters:
                | iX
                |    Origin point x absolute coordinate
                |  
                |  iY
                |    Origin point y absolute coordinate
                |  
                |  iZ
                |    Origin point z absolute coordinate
                |    
                |    Sets the origin point which the hole is anchored to. 
                |    If mandatory, the entry point will be projected onto a tangent plane.
                |  
                |  iEdge
                |    The edge which the hole is constrained to.
                |    
                |    The origin of the hole will have a length constraint with
                |    each edge.
                |    The following 
                | 
                |  object is supported:    
                | . 
                |      iSupport
                |    The support defining the hole reference plane.
                |    The following 
                |  object is supported:    
                | . 
                |      iDepth
                |    The hole depth.
                |  
                |  Returns:
                |   The created hole

                |
        :param i_x:
        :param i_y:
        :param i_z:
        :param i_edge_1:
        :param i_edge_2:
        :param i_support:
        :param i_depth:
        :return:
        """
        return self.shape_factory.AddNewHoleWith2Constraints(i_x, i_y, i_z, i_edge_1, i_edge_2, i_support, i_depth)

    def add_new_hole_with_constraint(self, i_x, i_y, i_z, i_edge, i_support, i_depth):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewHoleWithConstraint
                | o Func AddNewHoleWithConstraint(        iX,
                |                                         iY,
                |                                         iZ,
                |                                         iEdge,
                |                                         iSupport,
                |                                         iDepth) As
                | 
                | Creates and returns a new hole within the current shape.
                | Actual hole shape is defined by editing hole properties
                | after its creation.
                |
                | Parameters:
                | iX
                |    Origin point x absolute coordinate
                |  
                |  iY
                |    Origin point y absolute coordinate
                |  
                |  iZ
                |    Origin point z absolute coordinate
                |    
                |    Sets the origin point which the hole is anchored to. 
                |    If mandatory, the entry point will be projected onto a tangent plane.
                |  
                |  iEdge
                |    The edge which the hole is constrained to.
                |    
                |    If edge is circular, the origin of the hole will be concentric
                |    to the edge (iX, iY, iZ will be overridden).
                |    if not, the origin of the hole will have a length constraint with
                |    the edge.
                |    The following 
                | 
                |  object is supported:    
                | . 
                |      iSupport
                |    The support defining the hole reference plane.
                |    The following 
                |  object is supported:    
                | . 
                |      iDepth
                |    The hole depth.
                |  
                |  Returns:
                |   The created hole

                |
        :param i_x:
        :param i_y:
        :param i_z:
        :param i_edge:
        :param i_support:
        :param i_depth:
        :return:
        """
        return self.shape_factory.AddNewHoleWithConstraint(i_x, i_y, i_z, i_edge, i_support, i_depth)

    def add_new_intersect(self, i_body_to_intersect):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewIntersect
                | o Func AddNewIntersect(        iBodyToIntersect) As
                | 
                | Creates and returns a new intersect operation within the
                | current body.
                |
                | Parameters:
                | iBodyToIntersect
                |    The body to intersect with the current body
                |  
                | 
                |  Returns:
                |   The created intersect operation

                |
        :param i_body_to_intersect:
        :return:
        """
        return self.shape_factory.AddNewIntersect(i_body_to_intersect)

    def add_new_loft(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewLoft
                | o Func AddNewLoft(    ) As
                | 
                | Creates and returns a new Loft feature. Returns: The created
                | Loft feature
                |
                | Parameters:

                |
        :return:
        """
        return self.shape_factory.AddNewLoft()

    def add_new_mirror(self, i_mirroring_element):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewMirror
                | o Func AddNewMirror(        iMirroringElement) As
                | 
                | Creates and returns a new mirror within the current body. A
                | mirror allows for transforming existing shapes by a symmetry
                | with respect to an existing plane.
                |
                | Parameters:
                | iMirroringElement
                |    The plane used by the mirror as the symmetry plane.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |    Returns:
                |   The created mirror

                |
        :param i_mirroring_element:
        :return:
        """
        return self.shape_factory.AddNewMirror(i_mirroring_element)

    def add_new_pad(self, i_sketch, i_height):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewPad
                | o Func AddNewPad(        iSketch,
                |                          iHeight) As
                | 
                | Creates and returns a new pad within the current body.
                |
                | Parameters:
                | iSketch
                |    The sketch defining the pad base
                |  
                |  iHeight
                |    The pad height
                |  
                | 
                |  Returns:
                |   The created pad

                |
        :param i_sketch:
        :param i_height:
        :return:
        """
        return self.shape_factory.AddNewPad(i_sketch, i_height)

    def add_new_pad_from_ref(self, i_profile_elt, i_height):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewPadFromRef
                | o Func AddNewPadFromRef(        iProfileElt,
                |                                 iHeight) As
                | 
                | Creates and returns a new pad within the current body.
                |
                | Parameters:
                | iProfileElt
                |    The reference on the element defining the pad base
                |  
                |  iHeight
                |    The pad height
                |  
                | 
                |  Returns:
                |   The created pad

                |
        :param i_profile_elt:
        :param i_height:
        :return:
        """
        return self.shape_factory.AddNewPadFromRef(i_profile_elt, i_height)

    def add_new_pocket(self, i_sketch, i_height):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewPocket
                | o Func AddNewPocket(        iSketch,
                |                             iHeight) As
                | 
                | Creates and returns a new pocket within the current shape.
                |
                | Parameters:
                | iSketch
                |    The sketch defining the pocket base
                |  
                |  iDepth
                |    The pocket depth
                |  
                | 
                |  Returns:
                |   The created pocket

                |
        :param i_sketch:
        :param i_height:
        :return:
        """
        return self.shape_factory.AddNewPocket(i_sketch, i_height)

    def add_new_pocket_from_ref(self, i_profile_elt, i_height):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewPocketFromRef
                | o Func AddNewPocketFromRef(        iProfileElt,
                |                                    iHeight) As
                | 
                | Creates and returns a new pocket within the current shape.
                |
                | Parameters:
                | iProfileElt
                |    The reference on the element defining the pocket base
                |  
                |  iDepth
                |    The pocket depth
                |  
                | 
                |  Returns:
                |   The created pocket

                |
        :param i_profile_elt:
        :param i_height:
        :return:
        """
        return self.shape_factory.AddNewPocketFromRef(i_profile_elt, i_height)

    def add_new_rect_pattern(self, i_shape_to_copy, i_nb_of_copies_in_dir_1, i_nb_of_copies_in_dir_2, i_step_in_dir_1, i_step_in_dir_2, i_shape_to_copy_position_along_dir_1, i_shape_to_copy_position_along_dir_2, i_dir_1, i_dir_2, i_is_reversed_dir_1, i_is_reversed_dir_2, i_rotation_angle):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewRectPattern
                | o Func AddNewRectPattern(        iShapeToCopy,
                |                                  iNbOfCopiesInDir1,
                |                                  iNbOfCopiesInDir2,
                |                                  iStepInDir1,
                |                                  iStepInDir2,
                |                                  iShapeToCopyPositionAlongDir1,
                |                                  iShapeToCopyPositionAlongDir2,
                |                                  iDir1,
                |                                  iDir2,
                |                                  iIsReversedDir1,
                |                                  iIsReversedDir2,
                |                                  iRotationAngle) As
                | 
                | Creates and returns a new rectangular pattern within the
                | current body.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the rectangular pattern
                |  
                |  iNbOfCopiesInDir1
                |    The number of times iShapeToCopy will be copied along
                |    the pattern first direction
                |  
                |  iNbOfCopiesInDir2
                |    The number of times iShapeToCopy will be copied along
                |    the pattern second direction
                |  
                |  iStepInDir1
                |    The distance that will separate two consecutive copies in the pattern
                |    along its first direction
                |  
                |  iStepInDir2
                |    The distance that will separate two consecutive copies in the pattern
                |    along its second direction
                |  
                |  iShapeToCopyPositionAlongDir1
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along iDir1
                | 
                |  iShapeToCopyPositionAlongDir2
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along iDir2
                | 
                |  iDir1
                |    The line or linear edge that specifies the pattern first repartition
                |    direction
                |  The following 
                | 
                |  objects are supported:  
                | , 
                | , 
                | . 
                |      iDir2
                |    The line or linear edge that specifies the pattern second repartition
                |    direction
                |  The following 
                |  objects are supported:  
                | , 
                | , 
                | . 
                |      iIsReversedDir1
                |    The boolean flag indicating whether the natural orientation of
                |    iDir1 should be used to orient the pattern operation.
                |    True indicates that iShapeToCopy is copied in the
                |    direction of the natural orientation of iDir1.
                |  
                |  iIsReversedDir2
                |    The boolean flag indicating whether the natural orientation of 
                |    iDir2 should be used to orient the pattern operation.
                |    True indicates that iShapeToCopy is copied in the 
                |    direction of the natural orientation of iDir2.
                |  
                |  iRotationAngle
                |    The angle applied to both directions iDir1 and iDir2
                |    prior to applying the pattern. 
                |    The original shape iShapeToCopy is used as the rotation center.
                |    Nevertheless, the copied shapes themselves are not rotated.
                |    This allows the definition of a rectangular pattern 
                |    relatively to existing geometry, but not necessarily parallel to it.
                |  
                |  Returns:
                |   The created rectangular pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies_in_dir_1:
        :param i_nb_of_copies_in_dir_2:
        :param i_step_in_dir_1:
        :param i_step_in_dir_2:
        :param i_shape_to_copy_position_along_dir_1:
        :param i_shape_to_copy_position_along_dir_2:
        :param i_dir_1:
        :param i_dir_2:
        :param i_is_reversed_dir_1:
        :param i_is_reversed_dir_2:
        :param i_rotation_angle:
        :return:
        """
        return self.shape_factory.AddNewRectPattern(i_shape_to_copy, i_nb_of_copies_in_dir_1, i_nb_of_copies_in_dir_2, i_step_in_dir_1, i_step_in_dir_2, i_shape_to_copy_position_along_dir_1, i_shape_to_copy_position_along_dir_2, i_dir_1, i_dir_2, i_is_reversed_dir_1, i_is_reversed_dir_2, i_rotation_angle)

    def add_new_rect_patternof_list(self, i_shape_to_copy, i_nb_of_copies_in_dir_1, i_nb_of_copies_in_dir_2, i_step_in_dir_1, i_step_in_dir_2, i_shape_to_copy_position_along_dir_1, i_shape_to_copy_position_along_dir_2, i_dir_1, i_dir_2, i_is_reversed_dir_1, i_is_reversed_dir_2, i_rotation_angle):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewRectPatternofList
                | o Func AddNewRectPatternofList(        iShapeToCopy,
                |                                        iNbOfCopiesInDir1,
                |                                        iNbOfCopiesInDir2,
                |                                        iStepInDir1,
                |                                        iStepInDir2,
                |                                        iShapeToCopyPositionAlongDir1,
                |                                        iShapeToCopyPositionAlongDir2,
                |                                        iDir1,
                |                                        iDir2,
                |                                        iIsReversedDir1,
                |                                        iIsReversedDir2,
                |                                        iRotationAngle) As
                | 
                | V5R8 Only: Creates and returns a new rectangular pattern
                | within the current body using a list of shapes.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the rectangular pattern
                |    Others shapes will be add by put_ItemToCopy with CATIAPattern interface
                |  
                |  iNbOfCopiesInDir1
                |    The number of times iShapeToCopy will be copied along
                |    the pattern first direction
                |  
                |  iNbOfCopiesInDir2
                |    The number of times iShapeToCopy will be copied along
                |    the pattern second direction
                |  
                |  iStepInDir1
                |    The distance that will separate two consecutive copies in the pattern
                |    along its first direction
                |  
                |  iStepInDir2
                |    The distance that will separate two consecutive copies in the pattern
                |    along its second direction
                |  
                |  iShapeToCopyPositionAlongDir1
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along iDir1
                | 
                |  iShapeToCopyPositionAlongDir2
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along iDir2
                | 
                |  iDir1
                |    The line or linear edge that specifies the pattern first repartition
                |    direction
                |  
                |  iDir2
                |    The line or linear edge that specifies the pattern second repartition
                |    direction
                |  
                |  iIsReversedDir1
                |    The boolean flag indicating whether the natural orientation of
                |    iDir1 should be used to orient the pattern operation.
                |    True indicates that iShapeToCopy is copied in the
                |    direction of the natural orientation of iDir1.
                |  
                |  iIsReversedDir2
                |    The boolean flag indicating whether the natural orientation of 
                |    iDir2 should be used to orient the pattern operation.
                |    True indicates that iShapeToCopy is copied in the 
                |    direction of the natural orientation of iDir2.
                |  
                |  iRotationAngle
                |    The angle applied to both directions iDir1 and iDir2
                |    prior to applying the pattern. 
                |    The original shape iShapeToCopy is used as the rotation center.
                |    Nevertheless, the copied shapes themselves are not rotated.
                |    This allows the definition of a rectangular pattern 
                |    relatively to existing geometry, but not necessarily parallel to it.
                |  
                | 
                |  Returns:
                |   The created rectangular pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies_in_dir_1:
        :param i_nb_of_copies_in_dir_2:
        :param i_step_in_dir_1:
        :param i_step_in_dir_2:
        :param i_shape_to_copy_position_along_dir_1:
        :param i_shape_to_copy_position_along_dir_2:
        :param i_dir_1:
        :param i_dir_2:
        :param i_is_reversed_dir_1:
        :param i_is_reversed_dir_2:
        :param i_rotation_angle:
        :return:
        """
        return self.shape_factory.AddNewRectPatternofList(i_shape_to_copy, i_nb_of_copies_in_dir_1, i_nb_of_copies_in_dir_2, i_step_in_dir_1, i_step_in_dir_2, i_shape_to_copy_position_along_dir_1, i_shape_to_copy_position_along_dir_2, i_dir_1, i_dir_2, i_is_reversed_dir_1, i_is_reversed_dir_2, i_rotation_angle)

    def add_new_remove(self, i_body_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewRemove
                | o Func AddNewRemove(        iBodyToRemove) As
                | 
                | Creates and returns a new remove operation within the
                | current body.
                |
                | Parameters:
                | iBodyToRemove
                |    The body to remove from the current body
                |  
                | 
                |  Returns:
                |   The created remove operation

                |
        :param i_body_to_remove:
        :return:
        """
        return self.shape_factory.AddNewRemove(i_body_to_remove)

    def add_new_remove_face(self, i_keep_faces, i_remove_faces):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewRemoveFace
                | o Func AddNewRemoveFace(        iKeepFaces,
                |                                 iRemoveFaces) As
                | 
                | Creates and returns a new RemoveFace feature.
                |
                | Parameters:
                | iKeepFaces
                |    The reference of the face to Keep.
                |  
                |  iRemoveFaces
                |    The reference of the face to Remove.
                |  
                | 
                |  Returns:
                |   The created RemoveFace feature.

                |
        :param i_keep_faces:
        :param i_remove_faces:
        :return:
        """
        return self.shape_factory.AddNewRemoveFace(i_keep_faces, i_remove_faces)

    def add_new_removed_blend(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewRemovedBlend
                | o Func AddNewRemovedBlend(    ) As
                | 
                | Creates and returns a new Removed Blend feature. Returns:
                | The created Removed Blend feature
                |
                | Parameters:

                |
        :return:
        """
        return self.shape_factory.AddNewRemovedBlend()

    def add_new_removed_loft(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewRemovedLoft
                | o Func AddNewRemovedLoft(    ) As
                | 
                | Creates and returns a new Removed Loft feature. Returns: The
                | created Removed Loft feature
                |
                | Parameters:

                |
        :return:
        """
        return self.shape_factory.AddNewRemovedLoft()

    def add_new_replace_face(self, i_split_plane, i_remove_face, i_splitting_side):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewReplaceFace
                | o Func AddNewReplaceFace(        iSplitPlane,
                |                                  iRemoveFace,
                |                                  iSplittingSide) As
                | 
                | Creates and returns a new Align/ ReplaceFace feature.
                |
                | Parameters:
                | iSplitPlane
                |    The reference of the element defining the Splitting Plane.
                |  
                |  iRemoveFace
                |    The reference of the Face to Remove.
                |  
                |  iSplittingSide
                |    The specification for which side of the current body should be Align
                |  
                | 
                |  Returns:
                |   The created Align/ ReplaceFace feature.

                |
        :param i_split_plane:
        :param i_remove_face:
        :param i_splitting_side:
        :return:
        """
        return self.shape_factory.AddNewReplaceFace(i_split_plane, i_remove_face, i_splitting_side)

    def add_new_rib(self, i_sketch, i_center_curve):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewRib
                | o Func AddNewRib(        iSketch,
                |                          iCenterCurve) As
                | 
                | Creates and returns a new rib within the current body.
                |
                | Parameters:
                | iSketch
                |    The sketch defining the rib section
                |  
                |  iCenterCurve
                |    The sketched curve that defines the rib center curve. It must cross the 
                |    section definition sketch iSketch within the inner part of 
                |    its contour.
                |  
                | 
                |  Returns:
                |   The created rib

                |
        :param i_sketch:
        :param i_center_curve:
        :return:
        """
        return self.shape_factory.AddNewRib(i_sketch, i_center_curve)

    def add_new_rib_from_ref(self, i_profile, i_center_curve):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewRibFromRef
                | o Func AddNewRibFromRef(        iProfile,
                |                                 iCenterCurve) As
                | 
                | Creates and returns a new rib within the current body.
                |
                | Parameters:
                | iProfile
                |    The Profile defining the rib section
                |  
                |  iCenterCurve
                |    The curve that defines the rib center curve.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |    Returns:
                |   The created rib

                |
        :param i_profile:
        :param i_center_curve:
        :return:
        """
        return self.shape_factory.AddNewRibFromRef(i_profile, i_center_curve)

    def add_new_scaling(self, i_scaling_reference, i_factor):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewScaling
                | o Func AddNewScaling(        iScalingReference,
                |                              iFactor) As
                | 
                | Creates and returns a new scaling within the current body.
                |
                | Parameters:
                | iScalingReference
                |    The point, plane or  face of the current body  that will remain
                |    fixed during the 
                |    scaling process: even if the face itself shrinks or expands during the 
                |    scaling, its supporting plane will remain unchanged after the scaling.
                |    The following 
                | 
                |  objects are supported:    
                |  and 
                | . 
                |      iFactor
                |    The scaling factor
                |  
                |  Returns:
                |   The created scaling

                |
        :param i_scaling_reference:
        :param i_factor:
        :return:
        """
        return self.shape_factory.AddNewScaling(i_scaling_reference, i_factor)

    def add_new_sew_surface(self, i_sewing_element, i_sewing_side):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSewSurface
                | o Func AddNewSewSurface(        iSewingElement,
                |                                 iSewingSide) As
                | 
                | Creates and returns a new sewing operation within the
                | current body.
                |
                | Parameters:
                | iSewingElement
                |    The face or skin or surface that will be sewn on the current body
                |  
                |  iSewingSide
                |    The specification for which side of the current body should be kept
                |    at the end of the sewing operation
                |  
                | 
                |  Returns:
                |   The created sewing operation

                |
        :param i_sewing_element:
        :param i_sewing_side:
        :return:
        """
        return self.shape_factory.AddNewSewSurface(i_sewing_element, i_sewing_side)

    def add_new_shaft(self, i_sketch):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewShaft
                | o Func AddNewShaft(        iSketch) As
                | 
                | Creates and returns a new shaft within the current body. The
                | , as a supertype for shafts, provides starting and ending
                | angles for the shaft definition.
                |
                | Parameters:
                | iSketch
                |    The sketch defining the shaft section. 
                |    
                | If the shaft applies to the current body,
                |           then the sketch must contain
                |           a contour and an axis that will be used to rotate 
                |           the contour in the space, thus defining the shaft.
                |       If the shaft is the first shape defined, there is not current 
                |           body to apply to. In such a case, the sketch must contain a curve
                |           whose end points are linked by an axis. By rotating the 
                |           curve in the space around the axis, the shaft operation will define 
                |           a revolution shape.
                |           This also works if the sketch contains a closed contour and
                |           an axis outside of this contour: in that case a revolution 
                |           shape will be created, for example a torus.
                |    
                | 
                | 
                |  Returns:
                |   The created shaft

                |
        :param i_sketch:
        :return:
        """
        return self.shape_factory.AddNewShaft(i_sketch)

    def add_new_shaft_from_ref(self, i_profile_elt):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewShaftFromRef
                | o Func AddNewShaftFromRef(        iProfileElt) As
                | 
                | Creates and returns a new shaft within the current body.
                |
                | Parameters:
                | iProfileElt
                |    The reference on the element defining the shaft base
                |  
                | 
                |  Returns:
                |   The created shaft

                |
        :param i_profile_elt:
        :return:
        """
        return self.shape_factory.AddNewShaftFromRef(i_profile_elt)

    def add_new_shell(self, i_face_to_remove, i_internal_thickness, i_external_thickness):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewShell
                | o Func AddNewShell(        iFaceToRemove,
                |                            iInternalThickness,
                |                            iExternalThickness) As
                | 
                | Creates and returns a new shell within the current body.
                |
                | Parameters:
                | iFaceToRemove
                |    The first face to be removed in the shell process.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iInternalThickness
                |    The thickness of material to be added on the internal side of all the faces
                |    during the shell process, except for those to be removed
                |  
                |  iExternaThickness
                |    The thickness of material to be added on the external side of all the faces
                |    during the shell process, except for those to be removed
                |  
                |  Returns:
                |   The created shell

                |
        :param i_face_to_remove:
        :param i_internal_thickness:
        :param i_external_thickness:
        :return:
        """
        return self.shape_factory.AddNewShell(i_face_to_remove, i_internal_thickness, i_external_thickness)

    def add_new_slot(self, i_sketch, i_center_curve):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSlot
                | o Func AddNewSlot(        iSketch,
                |                           iCenterCurve) As
                | 
                | Creates and returns a new slot within the current shape.
                |
                | Parameters:
                | iSketch
                |    The sketch defining the slot section 
                |  
                |  iCenterCurve
                |    The sketched curve that defines the slot center curve. It must cross the 
                |    section definition sketch iSketch within the inner part of 
                |    its contour.
                |  
                | 
                |  Returns:
                |   The created slot

                |
        :param i_sketch:
        :param i_center_curve:
        :return:
        """
        return self.shape_factory.AddNewSlot(i_sketch, i_center_curve)

    def add_new_slot_from_ref(self, i_profile, i_center_curve):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSlotFromRef
                | o Func AddNewSlotFromRef(        iProfile,
                |                                  iCenterCurve) As
                | 
                | Creates and returns a new slot within the current shape.
                |
                | Parameters:
                | iProfile
                |    The sketch defining the slot section 
                |  
                |  iCenterCurve
                |    The curve that defines the slot center curve.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |    Returns:
                |   The created slot

                |
        :param i_profile:
        :param i_center_curve:
        :return:
        """
        return self.shape_factory.AddNewSlotFromRef(i_profile, i_center_curve)

    def add_new_solid_combine(self, i_profile_elt_first, i_profile_elt_second):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSolidCombine
                | o Func AddNewSolidCombine(        iProfileEltFirst,
                |                                   iProfileEltSecond) As
                | 
                | Creates and returns a new SolidCombine feature.
                |
                | Parameters:
                | iProfileEltFirst
                |    The reference of the element defining the profile for first component.
                |  
                |  iProfileEltSecond
                |    The reference of the element defining the profile for second component.
                |  
                | 
                |  Returns:
                |   The created SolidCombine feature.

                |
        :param i_profile_elt_first:
        :param i_profile_elt_second:
        :return:
        """
        return self.shape_factory.AddNewSolidCombine(i_profile_elt_first, i_profile_elt_second)

    def add_new_solid_edge_fillet_with_constant_radius(self, i_edge_to_fillet, i_propag_mode, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSolidEdgeFilletWithConstantRadius
                | o Func AddNewSolidEdgeFilletWithConstantRadius(        iEdgeToFillet,
                |                                                        iPropagMode,
                |                                                        iRadius) As
                | 
                | Creates and returns a new solid edge fillet with a constant
                | radius. within the current body.
                |
                | Parameters:
                | iEdgeToFillet
                |    The edge that will be filleted first
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iPropagMode
                |    Controls whether other edges found adjacent to the 
                |    first one should also be filleted in the same operation
                |  
                |  iRadius
                |    The fillet radius
                |  
                |  Returns:
                |   The created edge fillet

                |
        :param i_edge_to_fillet:
        :param i_propag_mode:
        :param i_radius:
        :return:
        """
        return self.shape_factory.AddNewSolidEdgeFilletWithConstantRadius(i_edge_to_fillet, i_propag_mode, i_radius)

    def add_new_solid_edge_fillet_with_varying_radius(self, i_edge_to_fillet, i_propag_mode, i_variation_mode, i_default_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSolidEdgeFilletWithVaryingRadius
                | o Func AddNewSolidEdgeFilletWithVaryingRadius(        iEdgeToFillet,
                |                                                       iPropagMode,
                |                                                       iVariationMode,
                |                                                       iDefaultRadius) As
                | 
                | Creates and returns a new solid edge fillet with a varying
                | radius. within the current body.
                |
                | Parameters:
                | iEdgeToFillet
                |    The edge that will be filleted first
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iPropagMode
                |    Controls whether other edges found adjacent to the 
                |    first one should also be filleted in the same operation
                |  
                |  iVariationMode
                |    Controls the law of evolution for the fillet radius 
                |    between specified control points, such as edges extremities
                |  
                |  iDefaultRadius
                |    The fillet default radius, that will apply when no other radius can 
                |    be inferred from the iVariationMode parameter
                |  
                |  Returns:
                |   The created edge fillet

                |
        :param i_edge_to_fillet:
        :param i_propag_mode:
        :param i_variation_mode:
        :param i_default_radius:
        :return:
        """
        return self.shape_factory.AddNewSolidEdgeFilletWithVaryingRadius(i_edge_to_fillet, i_propag_mode, i_variation_mode, i_default_radius)

    def add_new_solid_face_fillet(self, i_f_1, i_f_2, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSolidFaceFillet
                | o Func AddNewSolidFaceFillet(        iF1,
                |                                      iF2,
                |                                      iRadius) As
                | 
                | Creates and returns a new solid face-to-face fillet. Use
                | this method to created face-to-face fillets with varying
                | fillet radii, by editing fillet attributes driving its
                | radius after its creation.
                |
                | Parameters:
                | iF1
                |    The first face that will support the fillet
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iF2
                |    The second face that will support the fillet
                |  The following 
                |  object is supported:  
                | . 
                |      iRadius
                |    The fillet radius
                |  
                |  Returns:
                |   The created face-to-face fillet

                |
        :param i_f_1:
        :param i_f_2:
        :param i_radius:
        :return:
        """
        return self.shape_factory.AddNewSolidFaceFillet(i_f_1, i_f_2, i_radius)

    def add_new_solid_tritangent_fillet(self, i_f_1, i_f_2, i_removed_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSolidTritangentFillet
                | o Func AddNewSolidTritangentFillet(        iF1,
                |                                            iF2,
                |                                            iRemovedFace) As
                | 
                | Creates and returns a new solid tritangent fillet within the
                | current body. This kind of fillet begins with tangency on a
                | first face iF1, gets tangent to a second one iRemovedFace
                | and ends with tangency to a third one iF2. During the
                | process the second face iRemovedFace is removed.
                |
                | Parameters:
                | iF1
                |     The starting face for the fillet
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iF2
                |     The ending face for the fillet
                |  The following 
                |  object is supported:  
                | . 
                |      iRemovedFace
                |     The face used as an intermediate tangent support for the fillet 
                |     during its course from iF1 to iF2. This face will be 
                |     removed at the end of the filleting operation.
                |  The following 
                |  object is supported:  
                | 
                |  Returns:
                |   The created tritangent fillet

                |
        :param i_f_1:
        :param i_f_2:
        :param i_removed_face:
        :return:
        """
        return self.shape_factory.AddNewSolidTritangentFillet(i_f_1, i_f_2, i_removed_face)

    def add_new_split(self, i_splitting_element, i_split_side):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSplit
                | o Func AddNewSplit(        iSplittingElement,
                |                            iSplitSide) As
                | 
                | Creates and returns a new split operation within the current
                | body.
                |
                | Parameters:
                | iSplittingElement
                |    The face or plane that will split the current body
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iSplitSide
                |    The specification for which side of the current body should be kept
                |    at the end of the split operation
                |  
                |  Returns:
                |   The created split operation

                |
        :param i_splitting_element:
        :param i_split_side:
        :return:
        """
        return self.shape_factory.AddNewSplit(i_splitting_element, i_split_side)

    def add_new_stiffener(self, i_sketch):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewStiffener
                | o Func AddNewStiffener(        iSketch) As
                | 
                | Creates and returns a new stiffener within the current body.
                | A stiffener is made up of a sketch used as the stiffener
                | profile, that is extruded (offset) and that fills the
                | nearest shape.
                |
                | Parameters:
                | iSketch
                |    The sketch defining the stiffener border. It must contain a 
                |    line or a curve that does not cross in 3D space the face(s) to stiffen.
                |  
                | 
                |  Returns:
                |   The created stiffener

                |
        :param i_sketch:
        :return:
        """
        return self.shape_factory.AddNewStiffener(i_sketch)

    def add_new_stiffener_from_ref(self, i_profile_elt):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewStiffenerFromRef
                | o Func AddNewStiffenerFromRef(        iProfileElt) As
                | 
                | Creates and returns a new stiffener within the current body.
                |
                | Parameters:
                | iProfileElt
                |    The reference on the element defining the stiffener profile
                |  
                | 
                |  Returns:
                |   The created stiffener

                |
        :param i_profile_elt:
        :return:
        """
        return self.shape_factory.AddNewStiffenerFromRef(i_profile_elt)

    def add_new_surface_edge_fillet_with_constant_radius(self, i_edge_to_fillet, i_propag_mode, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfaceEdgeFilletWithConstantRadius
                | o Func AddNewSurfaceEdgeFilletWithConstantRadius(        iEdgeToFillet,
                |                                                          iPropagMode,
                |                                                          iRadius) As
                | 
                | Creates and returns a new surface edge fillet with a
                | constant radius. within the current body.
                |
                | Parameters:
                | iEdgeToFillet
                |    The edge that will be filleted first
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iPropagMode
                |    Controls whether other edges found adjacent to the 
                |    first one should also be filleted in the same operation
                |  
                |  iRadius
                |    The fillet radius
                |  
                |  Returns:
                |   The created edge fillet

                |
        :param i_edge_to_fillet:
        :param i_propag_mode:
        :param i_radius:
        :return:
        """
        return self.shape_factory.AddNewSurfaceEdgeFilletWithConstantRadius(i_edge_to_fillet, i_propag_mode, i_radius)

    def add_new_surface_edge_fillet_with_varying_radius(self, i_edge_to_fillet, i_propag_mode, i_variation_mode, i_default_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfaceEdgeFilletWithVaryingRadius
                | o Func AddNewSurfaceEdgeFilletWithVaryingRadius(        iEdgeToFillet,
                |                                                         iPropagMode,
                |                                                         iVariationMode,
                |                                                         iDefaultRadius) As
                | 
                | Creates and returns a new surface edge fillet with a varying
                | radius. within the current body.
                |
                | Parameters:
                | iEdgeToFillet
                |    The edge that will be filleted first
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iPropagMode
                |    Controls whether other edges found adjacent to the 
                |    first one should also be filleted in the same operation
                |  
                |  iVariationMode
                |    Controls the law of evolution for the fillet radius 
                |    between specified control points, such as edges extremities
                |  
                |  iDefaultRadius
                |    The fillet default radius, that will apply when no other radius can 
                |    be inferred from the iVariationMode parameter
                |  
                |  Returns:
                |   The created edge fillet

                |
        :param i_edge_to_fillet:
        :param i_propag_mode:
        :param i_variation_mode:
        :param i_default_radius:
        :return:
        """
        return self.shape_factory.AddNewSurfaceEdgeFilletWithVaryingRadius(i_edge_to_fillet, i_propag_mode, i_variation_mode, i_default_radius)

    def add_new_surface_face_fillet(self, i_f_1, i_f_2, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfaceFaceFillet
                | o Func AddNewSurfaceFaceFillet(        iF1,
                |                                        iF2,
                |                                        iRadius) As
                | 
                | Creates and returns a new surface face-to-face fillet. Use
                | this method to created face-to-face fillets with varying
                | fillet radii, by editing fillet attributes driving its
                | radius after its creation.
                |
                | Parameters:
                | iF1
                |    The first face that will support the fillet
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iF2
                |    The second face that will support the fillet
                |  The following 
                |  object is supported:  
                | . 
                |      iRadius
                |    The fillet radius
                |  
                |  Returns:
                |   The created face-to-face fillet

                |
        :param i_f_1:
        :param i_f_2:
        :param i_radius:
        :return:
        """
        return self.shape_factory.AddNewSurfaceFaceFillet(i_f_1, i_f_2, i_radius)

    def add_new_surface_tritangent_fillet(self, i_f_1, i_f_2, i_removed_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfaceTritangentFillet
                | o Func AddNewSurfaceTritangentFillet(        iF1,
                |                                              iF2,
                |                                              iRemovedFace) As
                | 
                | Creates and returns a new surface tritangent fillet within
                | the current body. This kind of fillet begins with tangency
                | on a first face iF1, gets tangent to a second one
                | iRemovedFace and ends with tangency to a third one iF2.
                | During the process the second face iRemovedFace is removed.
                |
                | Parameters:
                | iF1
                |     The starting face for the fillet
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iF2
                |     The ending face for the fillet
                |  The following 
                |  object is supported:  
                | . 
                |      iRemovedFace
                |     The face used as an intermediate tangent support for the fillet 
                |     during its course from iF1 to iF2. This face will be 
                |     removed at the end of the filleting operation.
                |  The following 
                |  object is supported:  
                | 
                |  Returns:
                |   The created tritangent fillet

                |
        :param i_f_1:
        :param i_f_2:
        :param i_removed_face:
        :return:
        """
        return self.shape_factory.AddNewSurfaceTritangentFillet(i_f_1, i_f_2, i_removed_face)

    def add_new_surfacic_auto_fillet(self, i_fillet_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfacicAutoFillet
                | o Func AddNewSurfacicAutoFillet(        iFilletRadius) As
                | 
                | Creates and returns a new Surfacic autofillet. Use this
                | method to create autofillet by providing fillet radius
                | value.
                |
                | Parameters:
                | iFilletRadius
                |    The fillet radius
                |  
                | 
                |  Returns:
                |   The created autofillet

                |
        :param i_fillet_radius:
        :return:
        """
        return self.shape_factory.AddNewSurfacicAutoFillet(i_fillet_radius)

    def add_new_surfacic_circ_pattern(self, i_shape_to_copy, i_nb_of_copies_in_radial_dir, i_nb_of_copies_in_angular_dir, i_step_in_radial_dir, i_step_in_angular_dir, i_shape_to_copy_position_along_radial_dir, i_shape_to_copy_position_along_angular_dir, i_rotation_center, i_rotation_axis, i_is_reversed_rotation_axis, i_rotation_angle, i_is_radius_aligned, i_complete_crown):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfacicCircPattern
                | o Func AddNewSurfacicCircPattern(        iShapeToCopy,
                |                                          iNbOfCopiesInRadialDir,
                |                                          iNbOfCopiesInAngularDir,
                |                                          iStepInRadialDir,
                |                                          iStepInAngularDir,
                |                                          iShapeToCopyPositionAlongRadialDir,
                |                                          iShapeToCopyPositionAlongAngularDir,
                |                                          iRotationCenter,
                |                                          iRotationAxis,
                |                                          iIsReversedRotationAxis,
                |                                          iRotationAngle,
                |                                          iIsRadiusAligned,
                |                                          iCompleteCrown) As
                | 
                | Creates and returns a new gsd circular pattern within the
                | current body.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the circular pattern
                |  
                |  iNbOfInstancesInRadialDir
                |    The number of times iShapeToCopy will be copied along
                |    pattern radial direction
                |  
                |  iNbOfInstancesInAngularDir
                |    The number of times iShapeToCopy will be copied along
                |    pattern angular direction
                |  
                |  iStepInRadialDir
                |    The distance that will separate two consecutive copies in the pattern
                |    along its radial direction
                |  
                |  iStepInAngularDir
                |    The angle that will separate two consecutive copies in the pattern
                |    along its angular direction
                |  
                |  iShapeToCopyPositionAlongRadialDir
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along the radial direction
                |  
                |  iShapeToCopyPositionAlongAngularDir
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along the angular direction
                |  
                |  iRotationCenter
                |    The point or vertex that specifies the pattern center of rotation
                |  
                |  iRotationAxis
                |    The line or linear edge that specifies the axis around which instances
                |    will be rotated relative to each other
                |  The following 
                | 
                |  objects are supported:  
                |  , 
                |  , 
                |  and 
                | . 
                |      iIsReversedRotationAxis
                |    The boolean flag indicating wether the natural orientation of 
                |    iRotationAxis should be used to orient the pattern operation.
                |    A value 
                |    of true indicates that iItemToDuplicate are copied in the 
                |    direction of the natural orientation of iRotationAxis.
                |  
                |  iRotationAngle
                |    The angle applied to the direction iRotationAxis 
                |    prior to applying the pattern.
                |    The original shape iShapeToCopy is used as the rotation center.
                |    Nevertheless, the copied shapes themselves are not rotated.
                |    This allows the definition of a circular pattern 
                |    relatively to existing geometry, but not necessarily parallel to it.
                |  
                |  iIsRadiusAligned
                |    The boolean flag that specifies whether the instances
                |    of iItemToDuplicate
                |    copied by the pattern should be kept parallel to each other (True)
                |    or if they should 
                |    be aligned with the radial direction they lie upon (False).
                |  
                |  iCompleteCrown
                |    The boolean flag specifies the mode of angular distribution.
                |    True indicates that the angular step will be equal to 360 degrees iNba.
                |  
                |  Returns:
                |   The created circular pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies_in_radial_dir:
        :param i_nb_of_copies_in_angular_dir:
        :param i_step_in_radial_dir:
        :param i_step_in_angular_dir:
        :param i_shape_to_copy_position_along_radial_dir:
        :param i_shape_to_copy_position_along_angular_dir:
        :param i_rotation_center:
        :param i_rotation_axis:
        :param i_is_reversed_rotation_axis:
        :param i_rotation_angle:
        :param i_is_radius_aligned:
        :param i_complete_crown:
        :return:
        """
        return self.shape_factory.AddNewSurfacicCircPattern(i_shape_to_copy, i_nb_of_copies_in_radial_dir, i_nb_of_copies_in_angular_dir, i_step_in_radial_dir, i_step_in_angular_dir, i_shape_to_copy_position_along_radial_dir, i_shape_to_copy_position_along_angular_dir, i_rotation_center, i_rotation_axis, i_is_reversed_rotation_axis, i_rotation_angle, i_is_radius_aligned, i_complete_crown)

    def add_new_surfacic_rect_pattern(self, i_shape_to_copy, i_nb_of_copies_in_dir_1, i_nb_of_copies_in_dir_2, i_step_in_dir_1, i_step_in_dir_2, i_shape_to_copy_position_along_dir_1, i_shape_to_copy_position_along_dir_2, i_dir_1, i_dir_2, i_is_reversed_dir_1, i_is_reversed_dir_2, i_rotation_angle):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfacicRectPattern
                | o Func AddNewSurfacicRectPattern(        iShapeToCopy,
                |                                          iNbOfCopiesInDir1,
                |                                          iNbOfCopiesInDir2,
                |                                          iStepInDir1,
                |                                          iStepInDir2,
                |                                          iShapeToCopyPositionAlongDir1,
                |                                          iShapeToCopyPositionAlongDir2,
                |                                          iDir1,
                |                                          iDir2,
                |                                          iIsReversedDir1,
                |                                          iIsReversedDir2,
                |                                          iRotationAngle) As
                | 
                | Creates and returns a new GSD rectangular pattern within the
                | current body.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the rectangular pattern
                |  
                |  iNbOfCopiesInDir1
                |    The number of times iShapeToCopy will be copied along
                |    the pattern first direction
                |  
                |  iNbOfCopiesInDir2
                |    The number of times iShapeToCopy will be copied along
                |    the pattern second direction
                |  
                |  iStepInDir1
                |    The distance that will separate two consecutive copies in the pattern
                |    along its first direction
                |  
                |  iStepInDir2
                |    The distance that will separate two consecutive copies in the pattern
                |    along its second direction
                |  
                |  iShapeToCopyPositionAlongDir1
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along iDir1
                | 
                |  iShapeToCopyPositionAlongDir2
                |    Specifies the position of the original shape iShapeToCopy
                |    among its copies along iDir2
                | 
                |  iDir1
                |    The line or linear edge that specifies the pattern first repartition
                |    direction
                |  The following 
                | 
                |  objects are supported:  
                | , 
                | , 
                | . 
                |      iDir2
                |    The line or linear edge that specifies the pattern second repartition
                |    direction
                |  The following 
                |  objects are supported:  
                | , 
                | , 
                | . 
                |      iIsReversedDir1
                |    The boolean flag indicating whether the natural orientation of
                |    iDir1 should be used to orient the pattern operation.
                |    True indicates that iShapeToCopy is copied in the
                |    direction of the natural orientation of iDir1.
                |  
                |  iIsReversedDir2
                |    The boolean flag indicating whether the natural orientation of 
                |    iDir2 should be used to orient the pattern operation.
                |    True indicates that iShapeToCopy is copied in the 
                |    direction of the natural orientation of iDir2.
                |  
                |  iRotationAngle
                |    The angle applied to both directions iDir1 and iDir2
                |    prior to applying the pattern. 
                |    The original shape iShapeToCopy is used as the rotation center.
                |    Nevertheless, the copied shapes themselves are not rotated.
                |    This allows the definition of a rectangular pattern 
                |    relatively to existing geometry, but not necessarily parallel to it.
                |  
                |  Returns:
                |   The created rectangular pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies_in_dir_1:
        :param i_nb_of_copies_in_dir_2:
        :param i_step_in_dir_1:
        :param i_step_in_dir_2:
        :param i_shape_to_copy_position_along_dir_1:
        :param i_shape_to_copy_position_along_dir_2:
        :param i_dir_1:
        :param i_dir_2:
        :param i_is_reversed_dir_1:
        :param i_is_reversed_dir_2:
        :param i_rotation_angle:
        :return:
        """
        return self.shape_factory.AddNewSurfacicRectPattern(i_shape_to_copy, i_nb_of_copies_in_dir_1, i_nb_of_copies_in_dir_2, i_step_in_dir_1, i_step_in_dir_2, i_shape_to_copy_position_along_dir_1, i_shape_to_copy_position_along_dir_2, i_dir_1, i_dir_2, i_is_reversed_dir_1, i_is_reversed_dir_2, i_rotation_angle)

    def add_new_surfacic_sew_surface(self, i_type, i_support_surface, i_sewing_element, i_sewing_side):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfacicSewSurface
                | o Func AddNewSurfacicSewSurface(        iType,
                |                                         iSupportSurface,
                |                                         iSewingElement,
                |                                         iSewingSide) As
                | 
                | Creates and returns a new volume sewing operation within the
                | current OGS/GS.
                |
                | Parameters:
                | iType
                |    Parameter to determine the sewing type. For Volume sewing Type = 4
                |  
                |  iSupportSurface
                |    The surfacic support on which sew operation will be performed
                |  
                |  iSewingElement
                |    The face or skin or surface that will be sewn on the current volume support
                |  
                |  iSewingSide
                |    The specification for which side of the current volume should be kept
                |    at the end of the sewing operation
                |  
                | 
                |  Returns:
                |   The created sewing operation

                |
        :param i_type:
        :param i_support_surface:
        :param i_sewing_element:
        :param i_sewing_side:
        :return:
        """
        return self.shape_factory.AddNewSurfacicSewSurface(i_type, i_support_surface, i_sewing_element, i_sewing_side)

    def add_new_surfacic_user_pattern(self, i_shape_to_copy, i_nb_of_copies):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewSurfacicUserPattern
                | o Func AddNewSurfacicUserPattern(        iShapeToCopy,
                |                                          iNbOfCopies) As
                | 
                | Creates and returns a new GSD user pattern within the
                | current body.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the user pattern
                |  
                |  iNbOfCopies
                |    The number of times iShapeToCopy will be copied
                |  
                | 
                |  Returns:
                |   The created user pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies:
        :return:
        """
        return self.shape_factory.AddNewSurfacicUserPattern(i_shape_to_copy, i_nb_of_copies)

    def add_new_thick_surface(self, i_offset_element, i_isens_offset, i_top_offset, i_bot_offset):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewThickSurface
                | o Func AddNewThickSurface(        iOffsetElement,
                |                                   iIsensOffset,
                |                                   iTopOffset,
                |                                   iBotOffset) As
                | 
                | Creates and returns a new ThickSurface feature.
                |
                | Parameters:
                | iOffsetElement
                |    The skin that will be thicken and added with the current body
                |  
                |  iIsensOffset
                |    The direction of the offset in regard to the direction of the normal
                |  
                |  iTopOffset
                |    The Offset between the iOffsetElement and the upper skin of the 
                |    resulting feature
                |  
                |  iBotOffset
                |    The Offset between the iOffsetElement and the lower skin of the 
                |    resulting feature
                |  
                | 
                |  Returns:
                |   The created ThickSurface feature

                |
        :param i_offset_element:
        :param i_isens_offset:
        :param i_top_offset:
        :param i_bot_offset:
        :return:
        """
        return self.shape_factory.AddNewThickSurface(i_offset_element, i_isens_offset, i_top_offset, i_bot_offset)

    def add_new_thickness(self, i_face_to_thicken, i_offset):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewThickness
                | o Func AddNewThickness(        iFaceToThicken,
                |                                iOffset) As
                | 
                | Creates and returns a new thickness within the current body.
                |
                | Parameters:
                | iFaceToThicken
                |    The first face to thicken in the thickening process.   
                |    
                |    New faces to thicken can be added to the thickness afterwards by using 
                |    methods offered by the created thickness
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iOffset
                |    The thickness of material to be added on the external side of the face
                |    iFaceToThicken during the thickening process
                |  
                |  Returns:
                |   The created thickness

                |
        :param i_face_to_thicken:
        :param i_offset:
        :return:
        """
        return self.shape_factory.AddNewThickness(i_face_to_thicken, i_offset)

    def add_new_thread_with_out_ref(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewThreadWithOutRef
                | o Func AddNewThreadWithOutRef(    ) As
                | 
                | Creates and returns a new thread\tap within the current
                | body. Returns: The created Thread
                |
                | Parameters:

                |
        :return:
        """
        return self.shape_factory.AddNewThreadWithOutRef()

    def add_new_thread_with_ref(self, i_lateral_face, i_limit_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewThreadWithRef
                | o Func AddNewThreadWithRef(        iLateralFace,
                |                                    iLimitFace) As
                | 
                | Creates and returns a new thread\tap within the current
                | body.
                |
                | Parameters:
                | iLateralFace
                |    The Face defining the support of thread\tap
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iLimitFacee
                |    The Face defining the origin of the thread.
                |  The following 
                |  object is supported:  
                | . 
                |    Returns:
                |   The created Thread

                |
        :param i_lateral_face:
        :param i_limit_face:
        :return:
        """
        return self.shape_factory.AddNewThreadWithRef(i_lateral_face, i_limit_face)

    def add_new_trim(self, i_body_to_trim):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewTrim
                | o Func AddNewTrim(        iBodyToTrim) As
                | 
                | Creates and returns a new Trim operation within the current
                | body.
                |
                | Parameters:
                | iBodyToTrim
                |    The body to Trim with current body.
                |  
                | 
                |  Returns:
                |   The created Trim operation

                |
        :param i_body_to_trim:
        :return:
        """
        return self.shape_factory.AddNewTrim(i_body_to_trim)

    def add_new_tritangent_fillet(self, i_f_1, i_f_2, i_removed_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewTritangentFillet
                | o Func AddNewTritangentFillet(        iF1,
                |                                       iF2,
                |                                       iRemovedFace) As
                | 
                | Deprecated: V5R14 #AddNewTritangentFillet use
                | AddNewSolidTritangentFillet or AddNewSurfaceTritangentFillet
                | depending on the type of fillet you want to create
                |
                | Parameters:

                |
        :param i_f_1:
        :param i_f_2:
        :param i_removed_face:
        :return:
        """
        return self.shape_factory.AddNewTritangentFillet(i_f_1, i_f_2, i_removed_face)

    def add_new_user_pattern(self, i_shape_to_copy, i_nb_of_copies):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewUserPattern
                | o Func AddNewUserPattern(        iShapeToCopy,
                |                                  iNbOfCopies) As
                | 
                | Creates and returns a new user pattern within the current
                | body.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the user pattern
                |  
                |  iNbOfCopies
                |    The number of times iShapeToCopy will be copied
                |  
                | 
                |  Returns:
                |   The created user pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies:
        :return:
        """
        return self.shape_factory.AddNewUserPattern(i_shape_to_copy, i_nb_of_copies)

    def add_new_user_patternof_list(self, i_shape_to_copy, i_nb_of_copies):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewUserPatternofList
                | o Func AddNewUserPatternofList(        iShapeToCopy,
                |                                        iNbOfCopies) As
                | 
                | V5R8 Only: Creates and returns a new user pattern within the
                | current body using a list of shapes.
                |
                | Parameters:
                | iShapeToCopy
                |    The shape to be copied by the user pattern
                |    Others shapes will be add by put_ItemToCopy with CATIAPattern interface
                |  
                |  iNbOfCopies
                |    The number of times iShapeToCopy will be copied
                |  
                | 
                |  Returns:
                |   The created user pattern

                |
        :param i_shape_to_copy:
        :param i_nb_of_copies:
        :return:
        """
        return self.shape_factory.AddNewUserPatternofList(i_shape_to_copy, i_nb_of_copies)

    def add_new_volume_add(self, i_body_1, i_body_2, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeAdd
                | o Func AddNewVolumeAdd(        iBody1,
                |                                iBody2,
                |                                iType) As
                | 
                | Creates and returns a Volumic Add feature.
                |
                | Parameters:
                | iBody1
                |    The volume or body to be modified.
                |  
                |  iBody2
                |    The volume or body to be operated.
                |  
                |  iType
                |    iType = 0 if Part Design, = 4 if GSD.
                |  
                | 
                |  Returns:
                |   The created Volumic Add feature.

                |
        :param i_body_1:
        :param i_body_2:
        :param i_type:
        :return:
        """
        return self.shape_factory.AddNewVolumeAdd(i_body_1, i_body_2, i_type)

    def add_new_volume_close_surface(self, i_close_element):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeCloseSurface
                | o Func AddNewVolumeCloseSurface(        iCloseElement) As
                | 
                | Creates and returns a new VolumeCloseSurface feature.
                |
                | Parameters:
                | iCloseElement
                |    The skin that will be closed and add with the current body
                |  
                | 
                |  Returns:
                |   The created CloseSurface feature

                |
        :param i_close_element:
        :return:
        """
        return self.shape_factory.AddNewVolumeCloseSurface(i_close_element)

    def add_new_volume_intersect(self, i_body_1, i_body_2, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeIntersect
                | o Func AddNewVolumeIntersect(        iBody1,
                |                                      iBody2,
                |                                      iType) As
                | 
                | Creates and returns a Volumic Intersect feature.
                |
                | Parameters:
                | iBody1
                |    The volume or body to be modified.
                |  
                |  iBody2
                |    The volume or body to be operated.
                |  
                |  iType
                |    iType = 0 if Part Design, = 4 if GSD.
                |  
                | 
                |  Returns:
                |   The created Volumic Intersect feature.

                |
        :param i_body_1:
        :param i_body_2:
        :param i_type:
        :return:
        """
        return self.shape_factory.AddNewVolumeIntersect(i_body_1, i_body_2, i_type)

    def add_new_volume_remove(self, i_body_1, i_body_2, i_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeRemove
                | o Func AddNewVolumeRemove(        iBody1,
                |                                   iBody2,
                |                                   iType) As
                | 
                | Creates and returns a Volumic Remove feature.
                |
                | Parameters:
                | iBody1
                |    The volume or body to be modified.
                |  
                |  iBody2
                |    The volume or body to be operated.
                |  
                |  iType
                |    iType = 0 if Part Design, = 4 if GSD.
                |  
                | 
                |  Returns:
                |   The created Volumic Remove feature.

                |
        :param i_body_1:
        :param i_body_2:
        :param i_type:
        :return:
        """
        return self.shape_factory.AddNewVolumeRemove(i_body_1, i_body_2, i_type)

    def add_new_volume_sew_surface(self, i_type, i_support_volume, i_sewing_element, i_sewing_side):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeSewSurface
                | o Func AddNewVolumeSewSurface(        iType,
                |                                       iSupportVolume,
                |                                       iSewingElement,
                |                                       iSewingSide) As
                | 
                | Creates and returns a new volume sewing operation within the
                | current OGS/GS.
                |
                | Parameters:
                | iType
                |    Parameter to determine the sewing type. For Volume sewing Type = 4
                |  
                |  iSupportVolume
                |    The volume support on which sew operation will be performed
                |  
                |  iSewingElement
                |    The face or skin or surface that will be sewn on the current volume support
                |  
                |  iSewingSide
                |    The specification for which side of the current volume should be kept
                |    at the end of the sewing operation
                |  
                | 
                |  Returns:
                |   The created sewing operation

                |
        :param i_type:
        :param i_support_volume:
        :param i_sewing_element:
        :param i_sewing_side:
        :return:
        """
        return self.shape_factory.AddNewVolumeSewSurface(i_type, i_support_volume, i_sewing_element, i_sewing_side)

    def add_new_volume_shell(self, i_face_to_remove, i_internal_thickness, i_external_thickness, i_volume_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeShell
                | o Func AddNewVolumeShell(        iFaceToRemove,
                |                                  iInternalThickness,
                |                                  iExternalThickness,
                |                                  iVolumeSupport) As
                | 
                | Creates and returns a Volumic Shell feature.
                |
                | Parameters:
                | iFacesToRemove
                |    The Faces of the Volume
                |  
                |  iFacesToThicken
                |    The Faces of the Volume
                |  
                |  iInternalThickness
                |    The thickness of material to be added on the internal side of all the faces
                |    during the shell process, except for those to be removed
                |  
                |  iExternaThickness
                |    The thickness of material to be added on the external side of all the faces
                |    during the shell process, except for those to be removed
                |  
                |  iVolumeSupport
                |    The Volume related the faces to remove and faces to thicken
                |  
                | 
                |  Returns:
                |   The created Volumic Shell.

                |
        :param i_face_to_remove:
        :param i_internal_thickness:
        :param i_external_thickness:
        :param i_volume_support:
        :return:
        """
        return self.shape_factory.AddNewVolumeShell(i_face_to_remove, i_internal_thickness, i_external_thickness, i_volume_support)

    def add_new_volume_thick_surface(self, i_offset_element, i_isens_offset, i_top_offset, i_bot_offset):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeThickSurface
                | o Func AddNewVolumeThickSurface(        iOffsetElement,
                |                                         iIsensOffset,
                |                                         iTopOffset,
                |                                         iBotOffset) As
                | 
                | Creates and returns a new VolumeThickSurface feature.
                |
                | Parameters:
                | iOffsetElement
                |    The skin that will be thicken and added with the current OGS/GS
                |  
                |  iIsensOffset
                |    The direction of the offset in regard to the direction of the normal
                |  
                |  iTopOffset
                |    The Offset between the iOffsetElement and the upper skin of the 
                |    resulting feature
                |  
                |  iBotOffset
                |    The Offset between the iOffsetElement and the lower skin of the 
                |    resulting feature
                |  
                | 
                |  Returns:
                |   The created ThickSurface feature

                |
        :param i_offset_element:
        :param i_isens_offset:
        :param i_top_offset:
        :param i_bot_offset:
        :return:
        """
        return self.shape_factory.AddNewVolumeThickSurface(i_offset_element, i_isens_offset, i_top_offset, i_bot_offset)

    def add_new_volume_thickness(self, i_face_to_thicken, i_offset, i_type, i_volume_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeThickness
                | o Func AddNewVolumeThickness(        iFaceToThicken,
                |                                      iOffset,
                |                                      iType,
                |                                      iVolumeSupport) As
                | 
                | Creates and returns a volume new thickness within the
                | current GS or OGS.
                |
                | Parameters:
                | iFaceToThicken
                |    The first face to thicken in the thickening process.   
                |    
                |    New faces to thicken can be added to the thickness afterwards by using 
                |    methods offered by the created thickness
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iOffset
                |    The thickness of material to be added on the external side of the face
                |    iFaceToThicken during the thickening process
                |  
                |  iType
                |    The mode of thickness creation (4=Volume)
                |  
                |  iVolumeSupport
                |    The support volume for volumic draft
                |  
                |  Returns:
                |   The created thickness

                |
        :param i_face_to_thicken:
        :param i_offset:
        :param i_type:
        :param i_volume_support:
        :return:
        """
        return self.shape_factory.AddNewVolumeThickness(i_face_to_thicken, i_offset, i_type, i_volume_support)

    def add_new_volume_trim(self, i_support_volume, i_cutting_volume):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumeTrim
                | o Func AddNewVolumeTrim(        iSupportVolume,
                |                                 iCuttingVolume) As
                | 
                | Creates and returns a new Volume Trim operation within the
                | GS/OGS.
                |
                | Parameters:
                | iSupportVolume
                |    The Support Volume 
                |  
                |  iCutttingVolume
                |    The trimming Volume 
                |  
                | 
                |  Returns:
                |   The created Trim operation

                |
        :param i_support_volume:
        :param i_cutting_volume:
        :return:
        """
        return self.shape_factory.AddNewVolumeTrim(i_support_volume, i_cutting_volume)

    def add_new_volumic_draft(self, i_face_to_draft, i_neutral, i_neutral_mode, i_parting, i_dir_x, i_dir_y, i_dir_z, i_mode, i_angle, i_multiselection_mode, i_type, i_volume_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddNewVolumicDraft
                | o Func AddNewVolumicDraft(        iFaceToDraft,
                |                                   iNeutral,
                |                                   iNeutralMode,
                |                                   iParting,
                |                                   iDirX,
                |                                   iDirY,
                |                                   iDirZ,
                |                                   iMode,
                |                                   iAngle,
                |                                   iMultiselectionMode,
                |                                   iType,
                |                                   iVolumeSupport) As
                | 
                | Creates and returns a new volume draft within the current
                | body. The draft needs a reference face on the body. This
                | face will remain unchanged in the draft operation, while
                | faces adjacent to it and specified for drafting will be
                | rotated by the draft angle.
                |
                | Parameters:
                | iFaceToDraft
                |    The first face to draft in the body. This face should be adjacent to the 
                |    iFaceToDraft face. If several faces are to be drafted, only the 
                |    first one is specified here, the others being inferred by propagating the
                |    draft operation onto faces adjacent to this first face. This is 
                |    controlled by the iNeutralMode argument.
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iNeutral
                |    The reference face for the draft. The draft needs a reference face on 
                |    the body, that will remain unchanged in the draft operation, while faces
                |    adjacent to it and specified for drafting will be rotated according 
                |    to the draft angle iAngle.
                |  The following 
                |  object is supported:  
                | . 
                |      iNeutralMode
                |    Controls if and how the drafting operation should be propagated beyond the 
                |    first face to draft iFaceToDraft to other adjacent faces. 
                |  
                |  iParting
                |     The draft parting plane, face or surface.
                |    It specifies the element within the body to draft 
                |    that represents the bottom of the mold. This element can be located either
                |    somewhere in the middle of the body or be one of its boundary faces. 
                |    When located in the middle of the body, it crosses the faces to draft, 
                |    and as a result, those faces are drafted with a positive angle on one 
                |    side of the parting surface, and with a negative angle on the other side.
                |  The following 
                |  object is supported:  
                | . 
                |      iDirX,iDirY,iDirZ
                |    The X, Y, and Z components of the absolute vector representing the drafting
                |    direction (i.e. the mold extraction direction).
                |  
                |  iMode
                |    The draft connecting mode to its reference face iFaceToDraft
                | 
                |  iAngle
                |    The draft angle
                |  
                |  iMultiselectionMode.
                |  The elements to be drafted can be selected explicitly
                |  or can implicitly selected as neighbors of the neutral face
                |  
                |  iType
                |    The mode of draft creation (4=Volume)
                |  
                |  iVolumeSupport
                |    The support volume for volumic draft
                |  
                |  Returns:
                |   The created draft

                |
        :param i_face_to_draft:
        :param i_neutral:
        :param i_neutral_mode:
        :param i_parting:
        :param i_dir_x:
        :param i_dir_y:
        :param i_dir_z:
        :param i_mode:
        :param i_angle:
        :param i_multiselection_mode:
        :param i_type:
        :param i_volume_support:
        :return:
        """
        return self.shape_factory.AddNewVolumicDraft(i_face_to_draft, i_neutral, i_neutral_mode, i_parting, i_dir_x, i_dir_y, i_dir_z, i_mode, i_angle, i_multiselection_mode, i_type, i_volume_support)

    def __repr__(self):
        return f'ShapeFactory()'
