#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class SewSurface(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the sewing  operation.It sews a shape using a sewing
                | element, such as a surface or a face

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.sew_surface = com_object     

    @property
    def sewing_intersection_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SewingIntersectionMode
                | o Property SewingIntersectionMode(    ) As
                | 
                | Returns or sets the sewing mode . The sewing side is the
                | side of the body kept after the sewing. A positive side
                | refers to the same orientation than the sewing element
                | normal vector. Example: The following example returns in
                | sptSide the sewing side of the sew shape mySew, and then
                | sets it to catPositiveSide: Set sptSide = mySew.SewingSide
                | mySew.SewingSide = catPositiveSide
                |

        :return:
        """
        return self.sew_surface.SewingIntersectionMode

    @sewing_intersection_mode.setter
    def sewing_intersection_mode(self, value):
        """
            :param type value:
        """
        self.sew_surface.SewingIntersectionMode = value 

    @property
    def sewing_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SewingSide
                | o Property SewingSide(    ) As
                | 
                | Returns or sets the sewing side . The sewing side is the
                | side of the body kept after the sewing. A positive side
                | refers to the same orientation than the sewing element
                | normal vector. Example: The following example returns in
                | sptSide the sewing side of the sew shape mySew, and then
                | sets it to catPositiveSide: Set sptSide = mySew.SewingSide
                | mySew.SewingSide = catPositiveSide
                |

        :return:
        """
        return self.sew_surface.SewingSide

    @sewing_side.setter
    def sewing_side(self, value):
        """
            :param type value:
        """
        self.sew_surface.SewingSide = value 

    def set_surface_support(self, i_support_surface):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSurfaceSupport
                | o Sub SetSurfaceSupport(        iSupportSurface)
                | 
                | Sets the surface support for surfacic sew surface.
                |
                | Parameters:
                | iSupportSurface
                |     A Reference object to a surface (see 
                | 
                |  for more information)

                |
        :param i_support_surface:
        :return:
        """
        return self.sew_surface.SetSurfaceSupport(i_support_surface)

    def set_volume_support(self, i_volume):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVolumeSupport
                | o Sub SetVolumeSupport(        iVolume)
                | 
                | Sets the volume support for volume sew surface.
                |
                | Parameters:
                | iVolume
                |     A Reference object to a volume (see 
                | 
                |  for more information)

                |                | Examples:
                | The following example sets the volume support of SewSurface
                | firstSewSurface to volumeExtrude volume reference :
                | firstSewSurface.SetVolumeSupport volumeExtrudeRef

        :param i_volume:
        :return:
        """
        return self.sew_surface.SetVolumeSupport(i_volume)

    def __repr__(self):
        return f'SewSurface()'
