#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ThickSurface(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the ThickSurface feature.It thicks surface using an offset
                | element (such as a surface or a skin) and two offset values TopOffset
                | and Botoffset.  TopOffset is the offset between the offset element and
                | the  top skin of the feature.   BotOffset is the offset between the
                | offset element and the  bottom skin of the feature.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.thick_surface = com_object     

    @property
    def bot_offset(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BotOffset
                | o Property BotOffset(    ) As   (Read Only)
                | 
                | Returns the value of the bottom offset. Example: The
                | following example returns in botoffset the bottom offset of
                | the thicksurface firstThickSurface: Set botoffset =
                | firstThickSurface.BotOffset
                |

        :return:
        """
        return self.thick_surface.BotOffset

    @property
    def offset_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OffsetSide
                | o Property OffsetSide(    ) As   (Read Only)
                | 
                | Returns the offset direction (defines in regards of the
                | normal direction) . Example: The following example returns
                | in offsetside the side of the ThickSurface
                | firstThickSurface: Set offsetside =
                | firstThickSurface.OffsetSide
                |

        :return:
        """
        return self.thick_surface.OffsetSide

    @offset_side.setter
    def offset_side(self, value):
        """
            :param type value:
        """
        self.thick_surface.OffsetSide = value 

    @property
    def top_offset(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TopOffset
                | o Property TopOffset(    ) As   (Read Only)
                | 
                | Returns the value of the top offset. Example: The following
                | example returns in topoffset the top offset of the
                | ThickSurface firstThickSurface: Set topoffset =
                | firstThickSurface.TopOffset
                |

        :return:
        """
        return self.thick_surface.TopOffset

    def swap__offset_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | swap_OffsetSide
                | o Sub swap_OffsetSide(    )
                | 
                | Swap the side of the offset.
                |
                | Parameters:

                |
        :return:
        """
        return self.thick_surface.swap_OffsetSide()

    def __repr__(self):
        return f'ThickSurface()'
