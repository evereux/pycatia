#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DraftDomain(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the draft domain.A draft domain is a basic object used by a
                | draft shape. It contains objects such as an angle, a pulling
                | direction, and a collection of faces to be drafted.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.draft_domain = com_object     

    @property
    def draft_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DraftAngle
                | o Property DraftAngle(    ) As   (Read Only)
                | 
                | Returns the draft angle. Example: The following example
                | returns in angle the draft angle of the draft domain
                | firstDraftDomain: Set angle = firstDraftDomain.DraftAngle
                |

        :return:
        """
        return self.draft_domain.DraftAngle

    @property
    def faces_to_draft(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FacesToDraft
                | o Property FacesToDraft(    ) As   (Read Only)
                | 
                | Returns the faces to be drafted. They are returned as a
                | collection of reference geometric elements. Example: The
                | following example returns the collection of faces to be
                | drafted of the draft domain firstDraftDomain in list: Set
                | list = firstDraftDomain.FacesToDraft
                |

        :return:
        """
        return self.draft_domain.FacesToDraft

    @property
    def multiselection_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MultiselectionMode
                | o Property MultiselectionMode(    ) As
                | 
                | Changes the multiselection mode.
                |
                | Examples:
                | The following example returns in MultiselMode the
                | multiselection mode of the draft domain firstDraftDomain,
                | and then sets it to CATMultiselectionByNeutralMode Set
                | MultiselMode = firstDraftDomain.MultiselectionMode
                | firstDraftDomain.MultiselectionMode =
                | CATMultiselectionByNeutralMode

        :return:
        """
        return self.draft_domain.MultiselectionMode

    @property
    def neutral_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NeutralElement
                | o Property NeutralElement(    ) As
                | 
                | Returns or sets the draft neutral element. To set the
                | property, you can use the following object: . Example: The
                | following example returns in neutral the neutral element of
                | the draft domain firstDraftDomain, and then sets it to
                | newNeutral: Set neutral = firstDraftDomain.NeutralElement
                | firstDraftDomain.NeutralElement = newNeutral
                |

        :return:
        """
        return self.draft_domain.NeutralElement

    @neutral_element.setter
    def neutral_element(self, value):
        """
            :param type value:
        """
        self.draft_domain.NeutralElement = value 

    @property
    def neutral_propagation_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NeutralPropagationMode
                | o Property NeutralPropagationMode(    ) As
                | 
                | Returns or sets the neutral element propagation mode. This
                | mode is used when computing the needed neutral elements.
                | Example: The following example returns in propMode the
                | neutral propagation mode of the draft domain
                | firstDraftDomain, and then sets it to
                | CATSmoothDraftNeutralPropagationMode so that the neutral
                | propagation will now be smooth: Set propMode =
                | firstDraftDomain.NeutralPropagationMode
                | firstDraftDomain.NeutralPropagationMode =
                | CATSmoothDraftNeutralPropagationMode
                |

        :return:
        """
        return self.draft_domain.NeutralPropagationMode

    @neutral_propagation_mode.setter
    def neutral_propagation_mode(self, value):
        """
            :param type value:
        """
        self.draft_domain.NeutralPropagationMode = value 

    @property
    def pulling_direction_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PullingDirectionElement
                | o Property PullingDirectionElement(    ) As
                | 
                | Returns or sets the draft pulling direction element. To set
                | the property, you can use one of the following objects: or .
                | Example: The following example returns in pullingdirection
                | the pulling direction element of the draft domain
                | firstDraftDomain, and then sets it to newPullingDirection:
                | Set pullingdirection = firstDraftDomain.NeutralElement
                | firstDraftDomain.PullingDirectionElement =
                | newPullingDirection
                |

        :return:
        """
        return self.draft_domain.PullingDirectionElement

    @pulling_direction_element.setter
    def pulling_direction_element(self, value):
        """
            :param type value:
        """
        self.draft_domain.PullingDirectionElement = value 

    def add_face_to_draft(self, i_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceToDraft
                | o Sub AddFaceToDraft(        iFace)
                | 
                | Adds a face to those to be drafted.
                |
                | Parameters:
                | iFace
                |    The face to add to those to be drafted
                |  The following 
                | 
                |  object is supported:  ScFace.

                |                | Examples:
                | The following example adds the face NewFaceToDraft to the
                | draft domain CurrentDraftDomain:
                | CurrentDraftDomain.AddFaceToDraft(NewFaceToDraft)

        :param i_face:
        :return:
        """
        return self.draft_domain.AddFaceToDraft(i_face)

    def get_pulling_direction(self, io_pulling_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPullingDirection
                | o Sub GetPullingDirection(        ioPullingDirection)
                | 
                | Returns the draft pulling direction. The pulling direction
                | is returned as an array containing the pulling direction
                | vector components. Assume this array is PullDir. It
                | contains: PullDir[0],PullDir[1],PullDir[2] The X, Y, and Z
                | pulling direction vector components Example: The following
                | example returns in PullDir the pulling direction vector
                | components of the draft domain firstDraftDomain: Set PullDir
                | = firstDraftDomain.PullingDirection Set x = PullDir[0] Set y
                | = PullDir[1] Set z = PullDir[2]
                |
                | Parameters:

                |
        :param io_pulling_direction:
        :return:
        """
        return self.draft_domain.GetPullingDirection(io_pulling_direction)

    def remove_face_to_draft(self, i_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveFaceToDraft
                | o Sub RemoveFaceToDraft(        iFace)
                | 
                | Removes a face from those to be drafted.
                |
                | Parameters:
                | iFace
                |    The face to be removed from those to be drafted
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example removes the face FaceToRemove from the
                | draft domain CurrentDraftDomain:
                | CurrentDraftDomain.RemoveFaceToDraft(FaceToRemove)

        :param i_face:
        :return:
        """
        return self.draft_domain.RemoveFaceToDraft(i_face)

    def set_pulling_direction(self, i_x, i_y, i_z):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPullingDirection
                | o Sub SetPullingDirection(        iX,
                |                                   iY,
                |                                   iZ)
                | 
                | Sets the draft pulling direction.
                |
                | Parameters:
                | iX,iY,iZ
                |    The X, Y, and Z pulling direction vector components

                |                | Examples:
                | The following example sets the draft pulling direction of
                | the draft domain firstDraftDomain to the direction with the
                | vector components 10, -5, 10:
                | firstDraftDomain.PullingDirection 10, -5, 10

        :param i_x:
        :param i_y:
        :param i_z:
        :return:
        """
        return self.draft_domain.SetPullingDirection(i_x, i_y, i_z)

    def set_volume_support(self, i_volume_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVolumeSupport
                | o Sub SetVolumeSupport(        iVolumeSupport)
                | 
                | Value the support of draft.
                |
                | Parameters:
                | iVolumeSupport

                |
        :param i_volume_support:
        :return:
        """
        return self.draft_domain.SetVolumeSupport(i_volume_support)

    def __repr__(self):
        return f'DraftDomain()'
