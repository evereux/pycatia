#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Defeaturing(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the defeaturing.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.defeaturing = com_object     

    @property
    def filters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Filters
                | o Property Filters(    ) As   (Read Only)
                | 
                | Returns the filter collection of the Defeaturing. The
                | returned object is the filter collection associated to this
                | Defeaturing object. All changes applied to the returned
                | collection will be automatically applied to the Defeaturing
                | object. As a consequence there is no need to affect the
                | collection to the defeaturing after the change to update the
                | property. Returns: oFilters The filter collection (see for
                | list of possible actions) Example: The following example
                | returns in myDefeaturingFiltersCollection the filter
                | collection of the Defeaturing firstDefeaturing: Set
                | myDefeaturingFiltersCollection = firstDefeaturing.Filters
                |

        :return:
        """
        return self.defeaturing.Filters

    def __repr__(self):
        return f'Defeaturing()'
