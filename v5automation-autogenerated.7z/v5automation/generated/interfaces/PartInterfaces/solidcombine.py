#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class SolidCombine(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIASolidCombine.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.solid_combine = com_object     

    @property
    def first_component_direction(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstComponentDirection
                | o Property FirstComponentDirection(    ) As
                | 
                | Returns or sets the direction of first component of
                | SolidCombine. Example: The following example returns in
                | firstDirection the direction of first component of
                | firstSolidCombine SolidCombine feature, and then sets it to
                | the firstDirection2 direction element. Set firstDirection =
                | firstSolidCombine.FirstComponentDirection Set
                | firstSolidCombine.FirstComponentDirection = firstDirection2
                |

        :return:
        """
        return self.solid_combine.FirstComponentDirection

    @first_component_direction.setter
    def first_component_direction(self, value):
        """
            :param type value:
        """
        self.solid_combine.FirstComponentDirection = value 

    @property
    def first_component_profile(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstComponentProfile
                | o Property FirstComponentProfile(    ) As
                | 
                | Returns or sets the profile of first component of
                | SolidCombine. Example: The following example returns in
                | firstProfile the profile of first component of
                | firstSolidCombine SolidCombine feature, and then sets it to
                | the firstProfile2 profile element: Set firstProfile =
                | firstSolidCombine.FirstComponentProfile Set
                | firstSolidCombine.FirstComponentProfile = firstProfile2
                |

        :return:
        """
        return self.solid_combine.FirstComponentProfile

    @first_component_profile.setter
    def first_component_profile(self, value):
        """
            :param type value:
        """
        self.solid_combine.FirstComponentProfile = value 

    @property
    def second_component_direction(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondComponentDirection
                | o Property SecondComponentDirection(    ) As
                | 
                | Returns or sets the direction of second component of
                | SolidCombine. Example: The following example returns in
                | secondDirection the direction of second component of
                | firstSolidCombine SolidCombine feature, and then sets it to
                | the secondDirection2 direction element. Set secondDirection
                | = firstSolidCombine.SecondComponentDirection Set
                | firstSolidCombine.SecondComponentDirection =
                | secondDirection2
                |

        :return:
        """
        return self.solid_combine.SecondComponentDirection

    @second_component_direction.setter
    def second_component_direction(self, value):
        """
            :param type value:
        """
        self.solid_combine.SecondComponentDirection = value 

    @property
    def second_component_profile(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondComponentProfile
                | o Property SecondComponentProfile(    ) As
                | 
                | Returns or sets the profile of second component of
                | SolidCombine. Example: The following example returns in
                | secondProfile the profile of second component of
                | firstSolidCombine SolidCombine feature, and then sets it to
                | the secondProfile2 profile element: Set secondProfile =
                | firstSolidCombine.SecondComponentProfile Set
                | firstSolidCombine.SecondComponentProfile = secondProfile2
                |

        :return:
        """
        return self.solid_combine.SecondComponentProfile

    @second_component_profile.setter
    def second_component_profile(self, value):
        """
            :param type value:
        """
        self.solid_combine.SecondComponentProfile = value 

    def __repr__(self):
        return f'SolidCombine()'
