#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Split(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the split operation.It splits a shape using a splitting
                | element, such as a surface, a face or a plane.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.split = com_object     

    @property
    def splitting_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SplittingSide
                | o Property SplittingSide(    ) As
                | 
                | Returns or sets the splitting side . The splitting side is
                | the side of the splitting element kept after the split. A
                | positive side refers to the same orientation than the
                | splitting element normal vector. Example: The following
                | example returns in sptSide the splitting side of the split
                | shape mySplit, and then sets it to catPositiveSide: Set
                | sptSide = mySplit.SplittingSide mySplit.SplittingSide =
                | catPositiveSide
                |

        :return:
        """
        return self.split.SplittingSide

    @splitting_side.setter
    def splitting_side(self, value):
        """
            :param type value:
        """
        self.split.SplittingSide = value 

    def __repr__(self):
        return f'Split()'
