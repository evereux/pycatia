#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AngularRepartition(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the angular repartition.It is used by the circular pattern.
                | It is made up of a number of times the shape is copied and of an
                | angular spacing between two consecutive copies of the shape along a
                | crown. The number of times the shape is copied is accessible using the
                | activateLinkAnchor('Repartition','InstancesCount','Repartition.Instanc
                | esCount')property.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.angular_repartition = com_object     

    @property
    def angular_spacing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AngularSpacing
                | o Property AngularSpacing(    ) As   (Read Only)
                | 
                | Returns the angle between two consecutive copies of a shape
                | along the repartition crown. Example: The following example
                | returns in AngSpace1 the angular spacing of the angular
                | repartition firstRepartition: Set AngSpace1 =
                | firstRepartition.AngularSpacing
                |

        :return:
        """
        return self.angular_repartition.AngularSpacing

    @property
    def instance_spacing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InstanceSpacing
                | o Property InstanceSpacing(    ) As   (Read Only)
                | 
                | Returns the angle at which the pattern spacing is done for
                | unequal angular spacing mode. Example: The following example
                | returns in AngSpace1 the angular spacing of the angular
                | repartition firstRepartition: Set AngSpace1 =
                | firstRepartition.AngularSpacing
                |

        :return:
        """
        return self.angular_repartition.InstanceSpacing

    def __repr__(self):
        return f'AngularRepartition()'
