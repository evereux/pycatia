#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Affinity(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the hybrid shape Affinity feature object.This solid feature
                | is  created from an underlying HybridShapeAffinity aggregated by the
                | Affinity.Role: To access the data of the hybrid shape Affinity feature
                | object. This data includes:Use the CATIAHybridShapeFactory to create
                | HybridShapeFeature object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.affinity = com_object     

    @property
    def hybrid_shape(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HybridShape
                | o Property HybridShape(    ) As   (Read Only)
                | 
                | Gets the underlying HybridShapeAffinity. Example: The
                | following example explains how to retrieve the underlying
                | HybridShape Affinity Dim oHybridShape as AnyObject Set
                | oHybridShape=oAffinity.HybridShape
                | oHybridShape.ElemToAffinity = reference1
                |

        :return:
        """
        return self.affinity.HybridShape

    def __repr__(self):
        return f'Affinity()'
