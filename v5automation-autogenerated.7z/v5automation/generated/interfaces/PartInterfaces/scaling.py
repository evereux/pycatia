#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Scaling(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the scaling shape.The scaling shape is made up of a scaling
                | reference element, such as a point, and a scaling factor.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.scaling = com_object     

    @property
    def factor(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Factor
                | o Property Factor(    ) As   (Read Only)
                | 
                | Returns the scaling factor. Example: The following example
                | returns in factor the scaling factor of the scaling
                | firstScaling: Set factor = firstScaling.Factor
                |

        :return:
        """
        return self.scaling.Factor

    @property
    def scaling_reference(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ScalingReference
                | o Property ScalingReference(    ) As
                | 
                | Returns or sets the scaling reference element. It can be a
                | point. To set the property, you can use one of the following
                | objects: or . Example: The following example returns in ref
                | the scaling reference element of the scaling firstScaling,
                | and then sets it to the created MyRef: Set ref =
                | firstScaling.ScalingSupport Set MyRef =
                | part.CreateReferenceFromGeometry (Point)
                | firstScaling.ScalingSupport = MyRef
                |

        :return:
        """
        return self.scaling.ScalingReference

    @scaling_reference.setter
    def scaling_reference(self, value):
        """
            :param type value:
        """
        self.scaling.ScalingReference = value 

    def __repr__(self):
        return f'Scaling()'
