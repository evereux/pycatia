#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Stiffener(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the stiffener shape.A stiffener is made up of a sketch used
                | as the stiffener profile, that is extruded (offset) and that fills the
                | nearest shape. This is a "positive" shape: it adds material to the
                | body it belongs to.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.stiffener = com_object     

    @property
    def is_from_top(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsFromTop
                | o Property IsFromTop(    ) As
                | 
                | Returns or sets whether the stiffener is From Side or From
                | Top. True if the stiffener is From Top stiffener with
                | respect to the base sketch. False if the stiffener is From
                | Side stiffener with respect to the base sketch. Example: The
                | following example returns in FromTopFlag whether the
                | firstStiffener stiffener is From Top, and then sets it as
                | From Top stiffener with respect to its base sketch: Set
                | FromTopFlag = firstStiffener.IsFromTop
                | firstStiffener.IsFromTop = True
                |

        :return:
        """
        return self.stiffener.IsFromTop

    @is_from_top.setter
    def is_from_top(self, value):
        """
            :param type value:
        """
        self.stiffener.IsFromTop = value 

    @property
    def is_symmetric(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsSymmetric
                | o Property IsSymmetric(    ) As
                | 
                | Returns or sets whether the stiffener is symmetric. True if
                | the stiffener is symmetric with respect to the base sketch.
                | Example: The following example returns in symFlag whether
                | the firstStiffener stiffener is symmetric, and then sets it
                | as symmetric with respect to its base sketch: Set symFlag =
                | firstStiffener.IsSymmetric firstStiffener.IsSymmetric = True
                |

        :return:
        """
        return self.stiffener.IsSymmetric

    @is_symmetric.setter
    def is_symmetric(self, value):
        """
            :param type value:
        """
        self.stiffener.IsSymmetric = value 

    @property
    def thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Thickness
                | o Property Thickness(    ) As   (Read Only)
                | 
                | Returns the stiffener thickness. This is half of the
                | thickness if the stiffener is symmetrical, and the thickness
                | otherwise. Example: The following example returns in
                | thickness the thickness of the firstStiffener stiffener: Set
                | thickness = firstStiffener.Thickness
                |

        :return:
        """
        return self.stiffener.Thickness

    @property
    def thickness_from_top(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ThicknessFromTop
                | o Property ThicknessFromTop(    ) As   (Read Only)
                | 
                | Returns the stiffener thickness top in case of From Top
                | stiffener. This is equal to first thickness if the stiffener
                | is symmetrical, Example: The following example returns in
                | thicknessfromtop the thickness of the firstStiffener
                | stiffener: Set thicknessfromtop =
                | firstStiffener.ThicknessFromTop
                |

        :return:
        """
        return self.stiffener.ThicknessFromTop

    def reverse_depth(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReverseDepth
                | o Sub ReverseDepth(    )
                | 
                | Reverses the stiffener direction. This is useful for finding
                | the shape to reach. Example: The following example reverses
                | the current direction of the firstStiffener stiffener:
                | firstStiffener.ReverseDepth
                |
                | Parameters:

                |
        :return:
        """
        return self.stiffener.ReverseDepth()

    def reverse_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReverseThickness
                | o Sub ReverseThickness(    )
                | 
                | Reverses the stiffener thickness direction. The stiffener
                | thickness is swapped with respect to the base sketch.
                | Example: The following example reverses the current
                | direction of the firstStiffener stiffener:
                | firstStiffener.ReverseThickness
                |
                | Parameters:

                |
        :return:
        """
        return self.stiffener.ReverseThickness()

    def __repr__(self):
        return f'Stiffener()'
