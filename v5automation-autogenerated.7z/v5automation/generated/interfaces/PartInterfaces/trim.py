#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Trim(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Trim, or union trim boolean operation.It is performed
                | between a body and the current shape.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.trim = com_object     

    def add_face_to_keep(self, i_face_to_keep):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceToKeep
                | o Sub AddFaceToKeep(        iFaceToKeep)
                | 
                | Adds a new face to be kept (if face is not divided by
                | operation).
                |
                | Parameters:
                | iFaceToKeep
                |    The new face to process
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new face face to Keep for the
                | Trim firstTrim: call firstTrim.AddFaceToKeep(face)

        :param i_face_to_keep:
        :return:
        """
        return self.trim.AddFaceToKeep(i_face_to_keep)

    def add_face_to_keep2(self, i_face_to_keep, i_face_adjacent_for_keep):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceToKeep2
                | o Sub AddFaceToKeep2(        iFaceToKeep,
                |                              iFaceAdjacentForKeep)
                | 
                | Adds a new face to be kept (if face is divided by
                | operation).
                |
                | Parameters:
                | iFaceToKeep
                |    The new face to process
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iFaceAdjacentForKeep
                |    An adjacent face of iFaceToKeep belonging to the other operand
                |  The following 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new face face to Keep for the
                | Trim firstTrim: call firstTrim.AddFaceToKeep(face)

        :param i_face_to_keep:
        :param i_face_adjacent_for_keep:
        :return:
        """
        return self.trim.AddFaceToKeep2(i_face_to_keep, i_face_adjacent_for_keep)

    def add_face_to_remove(self, i_face_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceToRemove
                | o Sub AddFaceToRemove(        iFaceToRemove)
                | 
                | Adds a new face to be Removed (if face not divided by
                | operation).
                |
                | Parameters:
                | iFaceToRemove
                |    The new face to process
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new face face to Remove for
                | the Trim firstTrim: call firstTrim.AddFaceToRemove(face)

        :param i_face_to_remove:
        :return:
        """
        return self.trim.AddFaceToRemove(i_face_to_remove)

    def add_face_to_remove2(self, i_face_to_remove, i_face_adjacent_for_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceToRemove2
                | o Sub AddFaceToRemove2(        iFaceToRemove,
                |                                iFaceAdjacentForRemove)
                | 
                | Adds a new face to be Removed (if face is divided by
                | operation).
                |
                | Parameters:
                | iFaceToRemove
                |    The new face to process
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iFaceAdjacentForRemove
                |    An adjacent face of iFaceToRemove belonging to the other operand
                |  The following 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new face face to Remove for
                | the Trim firstTrim: call firstTrim.AddFaceToRemove(face)

        :param i_face_to_remove:
        :param i_face_adjacent_for_remove:
        :return:
        """
        return self.trim.AddFaceToRemove2(i_face_to_remove, i_face_adjacent_for_remove)

    def withdraw_face_to_keep(self, i_face_to_withdraw):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawFaceToKeep
                | o Sub WithdrawFaceToKeep(        iFaceToWithdraw)
                | 
                | Withdraws an existing Kept face (if face is not divided by
                | operation) .
                |
                | Parameters:
                | iFaceToWithdraw
                |    The face to withdraw
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws the existing face Kept face
                | from the Trim firstTrim: call
                | firstTrim.WithdrawFaceToKeep(face)

        :param i_face_to_withdraw:
        :return:
        """
        return self.trim.WithdrawFaceToKeep(i_face_to_withdraw)

    def withdraw_face_to_keep2(self, i_face_to_withdraw, i_face_adjacent_for_keep):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawFaceToKeep2
                | o Sub WithdrawFaceToKeep2(        iFaceToWithdraw,
                |                                   iFaceAdjacentForKeep)
                | 
                | Withdraws an existing Kept face (if face is divided by
                | operation).
                |
                | Parameters:
                | iFaceToWithdraw
                |    The face to withdraw
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iFaceAdjacentForKeep
                |    An adjacent face of iFaceToKeep belonging to the other operand
                |  The following 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws the existing face Kept face
                | from the Trim firstTrim: call
                | firstTrim.WithdrawFaceToKeep(face)

        :param i_face_to_withdraw:
        :param i_face_adjacent_for_keep:
        :return:
        """
        return self.trim.WithdrawFaceToKeep2(i_face_to_withdraw, i_face_adjacent_for_keep)

    def withdraw_face_to_remove(self, i_face_to_withdraw):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawFaceToRemove
                | o Sub WithdrawFaceToRemove(        iFaceToWithdraw)
                | 
                | Withdraws an existing Removed face (if face not divided by
                | operation).
                |
                | Parameters:
                | iFaceToWithdraw
                |    The face to withdraw
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws the existing face Removed
                | face from the Trim firstTrim: call
                | firstTrim.WithdrawFaceToRemove(face)

        :param i_face_to_withdraw:
        :return:
        """
        return self.trim.WithdrawFaceToRemove(i_face_to_withdraw)

    def withdraw_face_to_remove2(self, i_face_to_withdraw, i_face_adjacent_for_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawFaceToRemove2
                | o Sub WithdrawFaceToRemove2(        iFaceToWithdraw,
                |                                     iFaceAdjacentForRemove)
                | 
                | Withdraws an existing Removed face (if face is divided by
                | operation).
                |
                | Parameters:
                | iFaceToWithdraw
                |    The face to withdraw
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iFaceAdjacentForRemove
                |    An adjacent face of iFaceToRemove belonging to the other operand
                |  The following 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws the existing face Removed
                | face from the Trim firstTrim: call
                | firstTrim.WithdrawFaceToRemove(face)

        :param i_face_to_withdraw:
        :param i_face_adjacent_for_remove:
        :return:
        """
        return self.trim.WithdrawFaceToRemove2(i_face_to_withdraw, i_face_adjacent_for_remove)

    def __repr__(self):
        return f'Trim()'
