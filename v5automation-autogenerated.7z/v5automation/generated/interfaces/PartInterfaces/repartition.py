#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Repartition(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the repartition.A repartition is a set of objects used by
                | the pattern shapes. It is the base object for linear and angular
                | repartitions.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.repartition = com_object     

    @property
    def instances_count(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InstancesCount
                | o Property InstancesCount(    ) As   (Read Only)
                | 
                | Returns the total number of copied shapes. Example: The
                | following example returns in Nb the number of shapes of the
                | repartition firstRepartition: Set Nb =
                | firstRepartition.InstancesCount
                |

        :return:
        """
        return self.repartition.InstancesCount

    def __repr__(self):
        return f'Repartition()'
