#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CatFilletBoundaryRelimitation(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Fillet boundary relimitation.Fillets can be created on open body, so
                | you can choose      the relimitation mode on open boundaries.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cat_fillet_boundary_relimitation = com_object     

    def __repr__(self):
        return f'CatFilletBoundaryRelimitation()'
