#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class UserPattern(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the user pattern.The shape is copied along user's
                | positions.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.user_pattern = com_object     

    @property
    def anchor_point(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnchorPoint
                | o Property AnchorPoint(    ) As
                | 
                | Returns the anchor point of the user pattern. Example: The
                | following example returns in anchor the anchor point of the
                | Pattern firstPattern: Set anchor = firstPattern.AnchorPoint
                |

        :return:
        """
        return self.user_pattern.AnchorPoint

    @property
    def feature_to_locate_positions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FeatureToLocatePositions
                | o Property FeatureToLocatePositions(    ) As   (Read Only)
                | 
                | Returns the collection of feature to locate instances.
                | Example: The following example returns in list the list of
                | feature to locate instances of the Pattern firstPattern: Set
                | list = firstPattern.FeatureToLocatePositions
                |

        :return:
        """
        return self.user_pattern.FeatureToLocatePositions

    def add_feature_to_locate_positions(self, i_feature_to_locate_positions):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFeatureToLocatePositions
                | o Sub AddFeatureToLocatePositions(        iFeatureToLocatePositions)
                | 
                | Adds a new feature to locate instances.
                |
                | Parameters:
                | iFeatureToLocatePositions
                |    The new object containing points of positioning

                |                | Examples:
                | The following example adds the new feature feature to locate
                | instances of the Pattern firstPattern: call
                | firstPattern.AddFeatureToLocatePositions(object)

        :param i_feature_to_locate_positions:
        :return:
        """
        return self.user_pattern.AddFeatureToLocatePositions(i_feature_to_locate_positions)

    def __repr__(self):
        return f'UserPattern()'
