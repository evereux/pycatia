#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Hole(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Hole Feature in Part Design.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.hole = com_object     

    @property
    def anchor_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnchorMode
                | o Property AnchorMode(    ) As
                | 
                | Returns the hole anchor mode. This information is pertinent
                | when hole type is Counterbored or Counterdrilled only.
                | Returns: oMode The hole anchor mode (see for list of
                | possible types) Example: The following example returns in
                | holeAnchorMode the anchor mode of hole firstHole: Set
                | holeAnchorMode = firstHole.AnchorMode
                |

        :return:
        """
        return self.hole.AnchorMode

    @property
    def bottom_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BottomAngle
                | o Property BottomAngle(    ) As   (Read Only)
                | 
                | Returns the hole bottom angle. This call is valid when the
                | hole bottom type is : VBottom. Returns: oBottomAngle An
                | Angle object controlling the hole bottom angle (see for more
                | information) Example: The following example returns in
                | holeBottomAngle the bottom angle of hole firstHole: Set
                | holeBottomAngle = firstHole.BottomAngle
                |

        :return:
        """
        return self.hole.BottomAngle

    @property
    def bottom_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BottomLimit
                | o Property BottomLimit(    ) As   (Read Only)
                | 
                | Returns the bottom limit. This call is valid when the hole
                | bottom type is : BlindHole or ThruHole. Returns:
                | oBottomLimit A Limit object controlling the hole bottom
                | limit (see for more information) Example: The following
                | example returns in holeBottomLimit the bottom limit of hole
                | firstHole: Set holeBottomLimit = firstHole.BottomLimit
                |

        :return:
        """
        return self.hole.BottomLimit

    @property
    def bottom_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BottomType
                | o Property BottomType(    ) As
                | 
                | Returns the hole bottom type. Returns: oBottomType The hole
                | bottom type (see for list of possible types) Example: The
                | following example returns in holeBottomType the bottom type
                | of hole firstHole: Set holeBottomType = firstHole.BottomType
                |

        :return:
        """
        return self.hole.BottomType

    @property
    def counter_sunk_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CounterSunkMode
                | o Property CounterSunkMode(    ) As
                | 
                | Returns the mode of a countersunk hole . Returns: CSMode
                | Value of the countersunk mode (see for list of possible
                | types) Example: The following example returns in CSMode the
                | CSMode of hole firsthole: Set CSMode =
                | firsthole.CounterSunkMode
                |

        :return:
        """
        return self.hole.CounterSunkMode

    @property
    def diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Diameter
                | o Property Diameter(    ) As   (Read Only)
                | 
                | Returns the hole diameter. Returns: oDiameter A Length
                | object controlling the hole diameter (see for more
                | information) Example: The following example returns in
                | holeDiam the diameter of hole firstHole: Set holeDiam =
                | firstHole.Diameter
                |

        :return:
        """
        return self.hole.Diameter

    @property
    def head_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HeadAngle
                | o Property HeadAngle(    ) As   (Read Only)
                | 
                | Returns the hole head angle. This call is valid when the
                | hole type is : Tapered or Counterdrilled or Countersunk.
                | Returns: oHeadAngle An Angle object controlling the hole
                | head angle (see for more information) Example: The following
                | example returns in holeHeadAngle the head angle of hole
                | firstHole: Set holeHeadAngle = firstHole.HeadAngle
                |

        :return:
        """
        return self.hole.HeadAngle

    @property
    def head_depth(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HeadDepth
                | o Property HeadDepth(    ) As   (Read Only)
                | 
                | Returns the hole head depth. This call is valid when the
                | hole type is : Counterbored or Counterdrilled or
                | Countersunk. Returns: oHeadDepth A Length object controlling
                | the hole head depth (see for more information) Example: The
                | following example returns in holeHeadDepth the head depth of
                | hole firstHole: Set holeHeadDepth = firstHole.HeadDepth
                |

        :return:
        """
        return self.hole.HeadDepth

    @property
    def head_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HeadDiameter
                | o Property HeadDiameter(    ) As   (Read Only)
                | 
                | Returns the hole head diameter. This call is valid when the
                | hole type is : Counterbored or Counterdrilled. Returns:
                | oHeadDiameter A Length object controlling the hole head
                | diameter (see for more information) Example: The following
                | example returns in holeHeadDiam the head diameter of hole
                | firstHole: Set holeHeadDiam = firstHole.HeadDiameter
                |

        :return:
        """
        return self.hole.HeadDiameter

    @property
    def hole_thread_description(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HoleThreadDescription
                | o Property HoleThreadDescription(    ) As   (Read Only)
                | 
                | Returns the hole thread description parameter. This call is
                | valid when the hole threading mode is :
                | CATThreadedHoleThreading. This call is valid only when a
                | standard/user design table exists Returns: oThreadDescParam
                | A Parameter object controlling the hole thread description
                | (see for more information) Example: The following example
                | returns in holeThreadDescription the thread description (M12
                | etc) of hole firstHole: Set holeThreadDescription =
                | firstHole.HoleThreadDescription
                |

        :return:
        """
        return self.hole.HoleThreadDescription

    @property
    def thread_depth(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ThreadDepth
                | o Property ThreadDepth(    ) As   (Read Only)
                | 
                | Returns the hole thread depth. This call is valid when the
                | hole threading mode is : CATThreadedHoleThreading. Returns:
                | oThreadDepth A Length object controlling the hole thread
                | depth (see for more information) Example: The following
                | example returns in holeThreadDepth the thread depth of hole
                | firstHole: Set holeThreadDepth = firstHole.ThreadDepth
                |

        :return:
        """
        return self.hole.ThreadDepth

    @property
    def thread_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ThreadDiameter
                | o Property ThreadDiameter(    ) As   (Read Only)
                | 
                | Returns the hole thread diameter. This call is valid when
                | the hole threading mode is : CATThreadedHoleThreading.
                | Returns: oThreadDiameter A Length object controlling the
                | hole thread diameter (see for more information) Example: The
                | following example returns in holeThreadDiameter the thread
                | diameter of hole firstHole: Set holeThreadDiameter =
                | firstHole.ThreadDiameter
                |

        :return:
        """
        return self.hole.ThreadDiameter

    @property
    def thread_pitch(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ThreadPitch
                | o Property ThreadPitch(    ) As   (Read Only)
                | 
                | Returns the hole thread pitch. This call is valid when the
                | hole threading mode is : CATThreadedHoleThreading. Returns:
                | oThreadPitch A Length object controlling the hole thread
                | pitch (see for more information) Example: The following
                | example returns in holeThreadPitch the thread pitch of hole
                | firstHole: Set holeThreadPitch = firstHole.ThreadPitch
                |

        :return:
        """
        return self.hole.ThreadPitch

    @property
    def thread_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ThreadSide
                | o Property ThreadSide(    ) As
                | 
                | Returns the hole thread side. Returns: oThreadSide The hole
                | thread side (see for list of possible sides) Example: The
                | following example returns in holeThreadSide the thread side
                | of hole firstHole: Set holeThreadSide = firstHole.ThreadSide
                |

        :return:
        """
        return self.hole.ThreadSide

    @property
    def threading_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ThreadingMode
                | o Property ThreadingMode(    ) As
                | 
                | Returns the hole threading mode. Returns: oThreadingMode The
                | hole threading mode (see for list of possible types)
                | Example: The following example returns in holeThreadingMode
                | the threading mode of hole firstHole: Set holeThreadingMode
                | = firstHole.ThreadingMode
                |

        :return:
        """
        return self.hole.ThreadingMode

    @property
    def type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Type
                | o Property Type(    ) As
                | 
                | Returns the hole type. Returns: oType The hole type (see for
                | list of possible types) Example: The following example
                | returns in holeType the type of hole firstHole: Set holeType
                | = firstHole.Type
                |

        :return:
        """
        return self.hole.Type

    def create_standard_thread_design_table(self, i_standard_type):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateStandardThreadDesignTable
                | o Sub CreateStandardThreadDesignTable(        iStandardType)
                | 
                | Creates a Standard Thread design table . This call is valid
                | when the hole threading mode is : CATThreadedHoleThreading.
                |
                | Parameters:
                | iStandardType
                |    Standard type for thread (see 
                | 
                |  for list of possible types)

                |                | Examples:
                | The following example creates a standard table for
                | MetricThinPitch for hole firstHole:
                | firstHole.CreateStandardThreadDesignTable
                | catHoleMetricThinPitch

        :param i_standard_type:
        :return:
        """
        return self.hole.CreateStandardThreadDesignTable(i_standard_type)

    def create_user_standard_design_table(self, i_standard_name, i_path):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateUserStandardDesignTable
                | o Sub CreateUserStandardDesignTable(        iStandardName,
                |                                             iPath)
                | 
                | Creates a UserStandard Thread design table . This call is
                | valid when the hole threading mode is :
                | CATThreadedHoleThreading.
                |
                | Parameters:
                | iStandardName
                |    Name of the UserStandard thread. iStandardName should be empty if filepath is to be defined.
                |  
                |  iPath
                |    Path of the UserStandard file. iPath is empty if the filepath is already defined through CATReffilesPath.
                |  
                | Example1:
                | The following example creates a standard table for UserStandard for
                |  hole firstHole. The file path is already defined thru CATReffilesPath:
                |  
                |  firstHole.CreateUserStandardDesignTable "UserStandard",""
                | 
                | 
                | Example2:
                | The following example creates a standard table for UserStandard for
                |  hole firstHole when file path is not defined thru CATReffilesPath:
                |  
                |  firstHole.CreateUserStandardDesignTable "","E:\user\standard\UserStandard.txt"

                |
        :param i_standard_name:
        :param i_path:
        :return:
        """
        return self.hole.CreateUserStandardDesignTable(i_standard_name, i_path)

    def get_direction(self, io_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDirection
                | o Sub GetDirection(        ioDirection)
                | 
                | Returns the hole direction with absolute coordinates. It
                | provides a safe array with 3 elements : X, Y, Z direction
                | coordinates Returns: oDirection The direction coordinates
                | Example: The following example returns in dirArray the
                | direction coordinates of hole firstHole: Call
                | firstHole.GetDirection dirArray Set x = dirArray[1] Set y =
                | dirArray[2] Set z = dirArray[3]
                |
                | Parameters:

                |
        :param io_direction:
        :return:
        """
        return self.hole.GetDirection(io_direction)

    def get_origin(self, io_origin):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOrigin
                | o Sub GetOrigin(        ioOrigin)
                | 
                | Returns the origin point which the hole is anchored to. This
                | point belongs to a tangent plane. Returns: oOrigin A Safe
                | Array made up of 3 doubles : X, Y, Z - Hole origin point
                | coordinates Example: The following example returns in
                | coordArray the coordinates of hole firstHole: Call
                | firstHole.GetOrigin coordArray Set x = coordArray[1] Set y =
                | coordArray[2] Set z = coordArray[3]
                |
                | Parameters:

                |
        :param io_origin:
        :return:
        """
        return self.hole.GetOrigin(io_origin)

    def reverse(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Reverse
                | o Sub Reverse(    )
                | 
                | Reverses the hole direction . Example: The following example
                | reverses the current direction of hole firstHole:
                | firstHole.Reverse()
                |
                | Parameters:

                |
        :return:
        """
        return self.hole.Reverse()

    def set_direction(self, i_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDirection
                | o Sub SetDirection(        iDirection)
                | 
                | Sets the hole associative direction.
                |
                | Parameters:
                | iDirection
                |     A Reference object to an edge or a line (see 
                | 
                |  for more information) The following 
                |  objects are supported:  
                | , 
                |  and 
                | .

                |                | Examples:
                | The following example sets the support direction of hole
                | firstHole with holeDirRef direction reference :
                | firstHole.SetDirection holeDirref

        :param i_direction:
        :return:
        """
        return self.hole.SetDirection(i_direction)

    def set_origin(self, i_x, i_y, i_z):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOrigin
                | o Sub SetOrigin(        iX,
                |                         iY,
                |                         iZ)
                | 
                | Sets the origin point which the hole is anchored to. If
                | mandatory, the entry point will be projected onto a tangent
                | plane.
                |
                | Parameters:
                | iX
                |    Origin point x absolute coordinate
                |  
                |  iY
                |    Origin point y absolute coordinate
                |  
                |  iZ
                |    Origin point z absolute coordinate

                |                | Examples:
                | The following example sets the coordinates of hole firstHole
                | to 10., 20., -5. : firstHole.SetOrigin 10., 20., 5.

        :param i_x:
        :param i_y:
        :param i_z:
        :return:
        """
        return self.hole.SetOrigin(i_x, i_y, i_z)

    def __repr__(self):
        return f'Hole()'
