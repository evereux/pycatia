#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DefeaturingFilters(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the filter collection of a defeaturing object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.defeaturing_filters = com_object     

    def add(self, i_filter_type_to_add):
        """
        .. note::
            CAA V5 Visual Basic help

                | Add
                | o Func Add(        iFilterTypeToAdd) As
                | 
                | Creates a new filter and adds it to the Defeaturing filters
                | collection.
                |
                | Parameters:
                | iFilterTypeToAdd
                |    The type of the new filter to add among :
                |      - "DefeaturingFilletFilter"
                |      - "DefeaturingHoleFilter" 
                |      - or any user-defined filter's type
                |  
                | 
                |  Returns:
                |   oAddedFilterIndex   The added filter's index - equals to 0 if FAILED

                |                | Examples:
                | The following example adds a new filter of type
                | theFilterType to defeaturing colelction
                | firstDefeaturingFilters and returns the index theIndex of
                | the new filter Set theIndex =
                | firstDefeaturingFilters.Add(theFilterType)

        :param i_filter_type_to_add:
        :return:
        """
        return self.defeaturing_filters.Add(i_filter_type_to_add)

    def item(self, i_filter_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iFilterId) As
                | 
                | Returns the filter of the Defeaturing filters collection
                | using its index or its name.
                |
                | Parameters:
                | iFilterId
                |    The index or the name of the filter to retrieve 
                |    As a numerics, must be in [1;Count])
                |  
                | 
                |  Returns:
                |   oFilter   The filter (see 
                |  for list of possible actions)

                |                | Examples:
                | The following example returns in myFilter the filter number
                | theIndex of Defeaturing collection firstDefeaturingFilters:
                | Set myFilter = firstDefeaturingFilters.Item(theIndex)

        :param i_filter_id:
        :return:
        """
        return self.defeaturing_filters.Item(i_filter_id)

    def remove(self, i_filter_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | Remove
                | o Sub Remove(        iFilterId)
                | 
                | Removes a filter from the Defeaturing filters collection and
                | deletes it, using its index or its name.
                |
                | Parameters:
                | iFilterId
                |    The index or the name of the filter to retrieve 
                |    As a numerics, must be in [1;Count])

                |                | Examples:
                | The two following examples remove the filter number theIndex
                | from Defeaturing collection firstDefeaturingFilters: Call
                | firstDefeaturingFilters.Remove(theIndex)
                | firstDefeaturingFilters.Remove theIndex

        :param i_filter_id:
        :return:
        """
        return self.defeaturing_filters.Remove(i_filter_id)

    def __repr__(self):
        return f'DefeaturingFilters()'
