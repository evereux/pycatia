#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Revolution(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the revolution-based shapes.It is the base objects for
                | shaft and grooves.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.revolution = com_object     

    @property
    def first_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstAngle
                | o Property FirstAngle(    ) As   (Read Only)
                | 
                | Returns the revolution first angle. This angle is computed
                | around the revolution axis, starting from the sketch plane
                | trace on the plane perpendicular to the revolution axis, and
                | is counted positive clockwise when looking at this plane in
                | the revolution axis direction. Example: The following
                | example returns in firstAngle the first angle of the
                | MyRevolution revolution object: Set firstAngle =
                | MyRevolution.FirstAngle
                |

        :return:
        """
        return self.revolution.FirstAngle

    @property
    def is_thin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsThin
                | o Property IsThin(    ) As
                | 
                | Returns the Revol thin flag. It returns TRUE if the Revol is
                | a thin Revol , FALSE if not. Returns: oIsThin The thin flag
                | as a boolean Example: The following example saves in
                | thinFlag the thin flag of Revol firstRevol, and then sets it
                | so that it will be now thin : Set thinFlag =
                | firstRevol.IsThin firstRevol.IsThin = TRUE
                |

        :return:
        """
        return self.revolution.IsThin

    @property
    def merge_end(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MergeEnd
                | o Property MergeEnd(    ) As
                | 
                | Returns the Revol merge end flag (for thin Revol only). It
                | returns TRUE if merge ends is required , FALSE if not.
                | Returns: oIsMergeEnd The merge end flag as a boolean
                | Example: The following example saves in MergeEndFlag the
                | merge end flag of Revol firstRevol, and then sets it so that
                | merge end will be required : Set MergeEndFlag =
                | firstRevol.IsMergeEnd firstRevol.IsMergeEnd = TRUE
                |

        :return:
        """
        return self.revolution.MergeEnd

    @merge_end.setter
    def merge_end(self, value):
        """
            :param type value:
        """
        self.revolution.MergeEnd = value 

    @property
    def neutral_fiber(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NeutralFiber
                | o Property NeutralFiber(    ) As
                | 
                | Returns the Revol neutral fiber flag (for thin Revol only).
                | It returns TRUE if the Revol is a neutral fiber Revol ,
                | FALSE if not. Returns: oIsNeutralFiber The neutral fiber
                | flag as a boolean Example: The following example saves in
                | NeutralFiberFlag the neutral fiber flag of Revol firstRevol,
                | and then sets it so that it will be now neutral fiber : Set
                | NeutralFiberFlag = firstRevol.IsNeutralFiber
                | firstRevol.IsNeutralFiber = TRUE
                |

        :return:
        """
        return self.revolution.NeutralFiber

    @neutral_fiber.setter
    def neutral_fiber(self, value):
        """
            :param type value:
        """
        self.revolution.NeutralFiber = value 

    @property
    def revolute_axis(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RevoluteAxis
                | o Property RevoluteAxis(    ) As
                | 
                | Returns or sets the rotation axis for Revol. To set the
                | property, you can use one of the following objects: , or .
                | Example: This example retrieves in RevoluteAxis the rotation
                | axis for the Rotate axis of the Revol feature Dim
                | RevoluteAxis As Reference Set RevoluteAxis = Rotate.Axis
                |

        :return:
        """
        return self.revolution.RevoluteAxis

    @revolute_axis.setter
    def revolute_axis(self, value):
        """
            :param type value:
        """
        self.revolution.RevoluteAxis = value 

    @property
    def second_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondAngle
                | o Property SecondAngle(    ) As   (Read Only)
                | 
                | Returns the revolution second angle. This angle is computed
                | around the revolution axis, starting from the sketch plane
                | trace on the plane perpendicular to the revolution axis, and
                | is counted positive counterclockwise when looking at this
                | plane in the revolution axis direction. Its default value is
                | 0. Example: The following example returns in secondAngle the
                | second angle of the MyRevolution revolution object: Set
                | secondAngle = MyRevolution.SecondAngle
                |

        :return:
        """
        return self.revolution.SecondAngle

    def __repr__(self):
        return f'Revolution()'
