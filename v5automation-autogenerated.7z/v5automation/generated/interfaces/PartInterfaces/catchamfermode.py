#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CatChamferMode(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Chamfer definition mode.A chamfer between two faces can be defined
                | using two lengthes, or a length and an angle. The first length, or the
                | single length, depending on the way the chamfer is defined, is
                | measured on the reference face from the edge to chamfer  to determine
                | the first edge the chamfer creates on the reference face. This
                | reference face is either the face selected or the face determined by
                | CATIA if the edge to be chamfered was selected. The second length, or
                | the angle, determines the second edge that the chamfer creates on the
                | second face.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cat_chamfer_mode = com_object     

    def __repr__(self):
        return f'CatChamferMode()'
