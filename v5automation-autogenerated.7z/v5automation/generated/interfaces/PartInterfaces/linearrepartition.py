#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class LinearRepartition(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the linear repartition.It is used by the rectangular and
                | circular patterns. It is made up of a number of times the shape is
                | copied and of a spacing distance between two consecutive copies of
                | this shape along a direction. The number of times the shape is copied
                | is accessible using theactivateLinkAnchor('Repartition','InstancesCoun
                | t','Repartition.InstancesCount')property.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.linear_repartition = com_object     

    @property
    def spacing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Spacing
                | o Property Spacing(    ) As   (Read Only)
                | 
                | Returns the distance between two consecutive shapes along
                | the repartition direction. Example: The following example
                | returns in space1 the spacing distance of the linear
                | repartition firstRepartition: Set space1 =
                | firstRepartition.Spacing
                |

        :return:
        """
        return self.linear_repartition.Spacing

    def __repr__(self):
        return f'LinearRepartition()'
