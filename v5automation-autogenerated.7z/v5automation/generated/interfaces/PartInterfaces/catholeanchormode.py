#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CatHoleAnchorMode(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Hole anchoring mode.It specifies the way the hole is anchored to its
                | support. This is valid
                | withcatCounterboredHoleandcatCounterdrilledHoleholes only. Otherwise,
                | holes are considered as anchored with the top of their head.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cat_hole_anchor_mode = com_object     

    def __repr__(self):
        return f'CatHoleAnchorMode()'
