#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class SketchBasedShape(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the shapes based on sketched 2D geometry.It is the base
                | object for prisms, holes, revolutions, stiffeners, and sweeps.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.sketch_based_shape = com_object     

    @property
    def sketch(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Sketch
                | o Property Sketch(    ) As   (Read Only)
                | 
                | Returns the sketch the shape is based on. Example: The
                | following example returns the sketch a pad named firstPad is
                | based on: Set sketchPad = firstPad.Sketch
                |

        :return:
        """
        return self.sketch_based_shape.Sketch

    def set_profile_element(self, i_profile_element):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProfileElement
                | o Sub SetProfileElement(        iProfileElement)
                | 
                | Returns or sets a profile element.
                |
                | Parameters:

                |
        :param i_profile_element:
        :return:
        """
        return self.sketch_based_shape.SetProfileElement(i_profile_element)

    def __repr__(self):
        return f'SketchBasedShape()'
