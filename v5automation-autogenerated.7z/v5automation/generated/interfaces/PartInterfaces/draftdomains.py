#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DraftDomains(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The collection of draft domains used by the draft shape.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.draft_domains = com_object     

    def item(self, i_index):
        """
        .. note::
            CAA V5 Visual Basic help

                | Item
                | o Func Item(        iIndex) As
                | 
                | Returns a draft domain using its index or its name from the
                | DraftDomains collection.
                |
                | Parameters:
                | iIndex
                |    The index or the name of the draft domain to retrieve from
                |    the collection of draft domains.
                |    As a numerics, this index is the rank of the draft domain
                |    in the collection.
                |    The index of the first draft domain in the collection is 1, and
                |    the index of the last draft domain is Count.
                |    As a string, it is the name you assigned to the draft domain using
                |    the 
                | 
                |  property. 
                |    Returns:
                |   The retrieved draft domain

                |                | Examples:
                | The following example returns in domain the third draft
                | domain of the firstDraftDomains collection: Set domain =
                | firstDraftDomains.Item(3)

        :param i_index:
        :return:
        """
        return self.draft_domains.Item(i_index)

    def __repr__(self):
        return f'DraftDomains()'
