#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class TritangentFillet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.tritangent_fillet = com_object     

    @property
    def face_to_remove(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FaceToRemove
                | o Property FaceToRemove(    ) As
                | 
                | Returns the face to be removed by the tritangent fillet.
                | Returns: oFaceToRemove The face to be removed by the fillet
                | (@see CATIAReference for more information) Example: The
                | following example returns in removedFace the face to be
                | removed of tritangent fillet firstTritangentFillet: Set
                | removedFace = firstTritangentFillet.FaceToRemove
                |

        :return:
        """
        return self.tritangent_fillet.FaceToRemove

    @property
    def first_face(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstFace
                | o Property FirstFace(    ) As
                | 
                | Returns the first face limiting the tritangent fillet.
                | Returns: oFirstFace The limiting face (@see CATIAReference
                | for more information) Example: The following example returns
                | in face1 the first limiting face of tritangent fillet
                | firstTritangentFillet: Set face1 =
                | firstTritangentFillet.FirstFace
                |

        :return:
        """
        return self.tritangent_fillet.FirstFace

    @property
    def second_face(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondFace
                | o Property SecondFace(    ) As
                | 
                | Returns the second face limiting the tritangent fillet.
                | Returns: oSecondFace The limiting face (@see CATIAReference
                | for more information) Example: The following example returns
                | in face2 the second limiting face of tritangent fillet
                | firstTritangentFillet: Set face2 =
                | firstTritangentFillet.SecondFace
                |

        :return:
        """
        return self.tritangent_fillet.SecondFace

    def __repr__(self):
        return f'TritangentFillet()'
