#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Sweep(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the sweep shape.It is the base object for ribs and slots.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.sweep = com_object     

    @property
    def anchor_dir_reverse(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AnchorDirReverse
                | o Property AnchorDirReverse(    ) As
                | 
                | Returns the Sweep AnchorDirReverse flag (for Sweep Move
                | Profile only). It returns TRUE if Anchor direction is
                | reversed , FALSE if not. Returns: oAnchorDirReverse The
                | oAnchorDirReverse flag as a boolean Example:
                |

        :return:
        """
        return self.sweep.AnchorDirReverse

    @property
    def center_curve(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CenterCurve
                | o Property CenterCurve(    ) As   (Read Only)
                | 
                | Returns the sketch used as the sweep center curve. The sweep
                | is built along this sketch. Example: The following example
                | returns in centerCurve the sketch used as center curve by
                | the firstSweep sweep object: Set centerCurve =
                | firstSweep.CenterCurve
                |

        :return:
        """
        return self.sweep.CenterCurve

    @property
    def center_curve_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CenterCurveElement
                | o Property CenterCurveElement(    ) As
                | 
                | Returns or sets the center curve . To set the property, you
                | can use the following object: .
                |

        :return:
        """
        return self.sweep.CenterCurveElement

    @center_curve_element.setter
    def center_curve_element(self, value):
        """
            :param type value:
        """
        self.sweep.CenterCurveElement = value 

    @property
    def is_thin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsThin
                | o Property IsThin(    ) As
                | 
                | Returns the Sweep thin flag. It returns TRUE if the Sweep is
                | a thin Sweep , FALSE if not. Returns: oIsThin The thin flag
                | as a boolean Example: The following example saves in
                | thinFlag the thin flag of Sweep firstSweep, and then sets it
                | so that it will be now thin : Set thinFlag =
                | firstSweep.IsThin firstSweep.IsThin = TRUE
                |

        :return:
        """
        return self.sweep.IsThin

    @property
    def merge_end(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MergeEnd
                | o Property MergeEnd(    ) As
                | 
                | Returns the Sweep merge end flag (for thin Sweep only). It
                | returns TRUE if merge ends is required , FALSE if not.
                | Returns: oIsMergeEnd The merge end flag as a boolean
                | Example: The following example saves in MergeEndFlag the
                | merge end flag of Sweep firstSweep, and then sets it so that
                | merge end will be required : Set MergeEndFlag =
                | firstSweep.IsMergeEnd firstSweep.IsMergeEnd = TRUE
                |

        :return:
        """
        return self.sweep.MergeEnd

    @merge_end.setter
    def merge_end(self, value):
        """
            :param type value:
        """
        self.sweep.MergeEnd = value 

    @property
    def merge_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MergeMode
                | o Property MergeMode(    ) As
                | 
                | Returns or sets the end mode .
                |

        :return:
        """
        return self.sweep.MergeMode

    @merge_mode.setter
    def merge_mode(self, value):
        """
            :param type value:
        """
        self.sweep.MergeMode = value 

    @property
    def move_profile_to_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MoveProfileToPath
                | o Property MoveProfileToPath(    ) As
                | 
                | Returns the Sweep MoveProfileToPath flag (for Sweep Move
                | Profile only). It returns TRUE if move profile is required ,
                | FALSE if not. Returns: oIsMoveProfileToPath The
                | MoveProfileToPath flag as a boolean Example:
                |

        :return:
        """
        return self.sweep.MoveProfileToPath

    @property
    def neutral_fiber(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NeutralFiber
                | o Property NeutralFiber(    ) As
                | 
                | Returns the Sweep neutral fiber flag (for thin Sweep only).
                | It returns TRUE if the Sweep is a neutral fiber Sweep ,
                | FALSE if not. Returns: oIsNeutralFiber The neutral fiber
                | flag as a boolean Example: The following example saves in
                | NeutralFiberFlag the neutral fiber flag of Sweep firstSweep,
                | and then sets it so that it will be now neutral fiber : Set
                | NeutralFiberFlag = firstSweep.IsNeutralFiber
                | firstSweep.IsNeutralFiber = TRUE
                |

        :return:
        """
        return self.sweep.NeutralFiber

    @neutral_fiber.setter
    def neutral_fiber(self, value):
        """
            :param type value:
        """
        self.sweep.NeutralFiber = value 

    @property
    def normal_axis_dir_reverse(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NormalAxisDirReverse
                | o Property NormalAxisDirReverse(    ) As
                | 
                | Returns the Sweep NormalAxisDirReverse flag (for Sweep Move
                | Profile only). It returns TRUE if Normal Axis direction is
                | reversed , FALSE if not. Returns: oNormalAxisDirReverse The
                | oNormalAxisDirReverse flag as a boolean Example:
                |

        :return:
        """
        return self.sweep.NormalAxisDirReverse

    @property
    def pulling_dir_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PullingDirElement
                | o Property PullingDirElement(    ) As
                | 
                | Returns or sets the pulling direction . To set the property,
                | you can use one of the following objects: , , , .
                |

        :return:
        """
        return self.sweep.PullingDirElement

    @pulling_dir_element.setter
    def pulling_dir_element(self, value):
        """
            :param type value:
        """
        self.sweep.PullingDirElement = value 

    @property
    def reference_surface_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReferenceSurfaceElement
                | o Property ReferenceSurfaceElement(    ) As
                | 
                | Returns or sets the reference surface . To set the property,
                | you can use the following object: .
                |

        :return:
        """
        return self.sweep.ReferenceSurfaceElement

    @reference_surface_element.setter
    def reference_surface_element(self, value):
        """
            :param type value:
        """
        self.sweep.ReferenceSurfaceElement = value 

    def set_keep_angle_option(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetKeepAngleOption
                | o Sub SetKeepAngleOption(    )
                | 
                | Actives KeepAngleOption.
                |
                | Parameters:

                |
        :return:
        """
        return self.sweep.SetKeepAngleOption()

    def __repr__(self):
        return f'Sweep()'
