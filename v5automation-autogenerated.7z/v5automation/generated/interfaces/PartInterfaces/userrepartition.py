#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class UserRepartition(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the User Pattern  repartition.It is made up of a number of
                | times the shape is copied and  the location of instances. The number
                | of times the shape is copied is accessible using theactivateLinkAnchor
                | ('Repartition','InstancesCount','Repartition.InstancesCount')property.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.user_repartition = com_object     

    @property
    def feature_to_locate_positions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FeatureToLocatePositions
                | o Property FeatureToLocatePositions(    ) As   (Read Only)
                | 
                | Returns the collection of feature to locate instances.
                | Example: The following example returns in list the list of
                | feature to locate instances of the Pattern firstPattern: Set
                | list = firstPattern.FeatureToLocatePositions
                |

        :return:
        """
        return self.user_repartition.FeatureToLocatePositions

    def add_feature_to_locate_positions(self, i_feature_to_locate_positions):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFeatureToLocatePositions
                | o Sub AddFeatureToLocatePositions(        iFeatureToLocatePositions)
                | 
                | Adds a new feature to locate instances.
                |
                | Parameters:
                | iFeatureToLocatePositions
                |    The new face to process

                |                | Examples:
                | The following example adds the new feature feature to locate
                | instances of the Pattern firstPattern: call
                | firstPattern.AddFeatureToLocatePositions(face)

        :param i_feature_to_locate_positions:
        :return:
        """
        return self.user_repartition.AddFeatureToLocatePositions(i_feature_to_locate_positions)

    def __repr__(self):
        return f'UserRepartition()'
