#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Fillet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the fillet shape.It is the base object for face fillets and
                | edge fillets.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.fillet = com_object     

    @property
    def fillet_boundary_relimitation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FilletBoundaryRelimitation
                | o Property FilletBoundaryRelimitation(    ) As
                | 
                | Returns or sets the fillet boundary relimitation mode. This
                | boundary relimitation mode is used when computing the
                | fillet. Example: The following example returns in mode the
                | fillet boundary relimitation mode of the firstFillet fillet,
                | and then sets it to catMinimumFilletBoundaryRelimitation, so
                | that the fillet expands up to the limits of the smallest
                | shell: Set mode = firstFillet.FilletBoundaryRelimitation Set
                | FirstFillet.FilletBoundaryRelimitation =
                | catMinimumFilletBoundaryRelimitation
                |

        :return:
        """
        return self.fillet.FilletBoundaryRelimitation

    @fillet_boundary_relimitation.setter
    def fillet_boundary_relimitation(self, value):
        """
            :param type value:
        """
        self.fillet.FilletBoundaryRelimitation = value 

    @property
    def fillet_trim_support(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FilletTrimSupport
                | o Property FilletTrimSupport(    ) As
                | 
                | Returns or sets the fillet Trim Support mode. This Trim
                | Support mode is used when computing the fillet. Example: The
                | following example returns in mode the fillet Trim Support
                | mode of the firstFillet fillet, and then sets it to
                | catMinimumFilletTrimSupport, so that the fillet expands up
                | to the limits of the smallest shell: Set mode =
                | firstFillet.FilletTrimSupport Set
                | FirstFillet.FilletTrimSupport = catNoTrimFilletSupport
                |

        :return:
        """
        return self.fillet.FilletTrimSupport

    @fillet_trim_support.setter
    def fillet_trim_support(self, value):
        """
            :param type value:
        """
        self.fillet.FilletTrimSupport = value 

    def __repr__(self):
        return f'Fillet()'
