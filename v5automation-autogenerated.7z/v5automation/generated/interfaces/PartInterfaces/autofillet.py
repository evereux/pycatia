#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AutoFillet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the AutoFillet shape.A AutoFillet fillets all the edges of
                | Solid

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.auto_fillet = com_object     

    @property
    def curvature_radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CurvatureRadius
                | o Property CurvatureRadius(    ) As   (Read Only)
                | 
                | Returns the Curvature radius. Example: The following example
                | returns in Curvature radius the Curvature radius of the
                | AutoFillet Autofillet: Set Curvatureradius =
                | Autofillet.Radius
                |

        :return:
        """
        return self.auto_fillet.CurvatureRadius

    @property
    def faces_to_fillet(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FacesToFillet
                | o Property FacesToFillet(    ) As   (Read Only)
                | 
                | Returns or sets the faces to fillet. Example: The following
                | example returns in facestofillet the faces required for
                | autofillet autoFillet, and then sets it to NewFacestofillet:
                | Set Facestofillet = autoFillet.Facestofillet
                | autofillet.Facestofillet = NewFacestofillet
                |

        :return:
        """
        return self.auto_fillet.FacesToFillet

    @faces_to_fillet.setter
    def faces_to_fillet(self, value):
        """
            :param type value:
        """
        self.auto_fillet.FacesToFillet = value 

    @property
    def faces_to_fillets(self, i_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | FacesToFillets
                | o Property FacesToFillets(        iFace) (Write Only)
                | 
                |

        :param i_face:
        :return:
        """
        return self.auto_fillet.FacesToFillets

    @property
    def fillet_radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FilletRadius
                | o Property FilletRadius(    ) As   (Read Only)
                | 
                | Returns the Fillet radius. Example: The following example
                | returns in fillet radius the fillet radius of the AutoFillet
                | Autofillet: Set Filletradius = Autofillet.Radius
                |

        :return:
        """
        return self.auto_fillet.FilletRadius

    @property
    def functional_face(self, i_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | FunctionalFace
                | o Property FunctionalFace(        iFace) (Write Only)
                | 
                |

        :param i_face:
        :return:
        """
        return self.auto_fillet.FunctionalFace

    @property
    def functional_faces(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FunctionalFaces
                | o Property FunctionalFaces(    ) As   (Read Only)
                | 
                | Returns or sets the functional face. Example: The following
                | example returns in functionalface the functional face of the
                | autofillet autoFillet, and then sets it to
                | NewfunctionalFace: Set functionalFace =
                | autoFillet.FunctionalFace autofillet.FunctionalFace =
                | NewfunctionalFace
                |

        :return:
        """
        return self.auto_fillet.FunctionalFaces

    @functional_faces.setter
    def functional_faces(self, value):
        """
            :param type value:
        """
        self.auto_fillet.FunctionalFaces = value 

    @property
    def parting_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartingElement
                | o Property PartingElement(    ) As
                | 
                | Returns or sets the parting element. Example: The following
                | example returns in partingelement the parting element of the
                | autofillet autoFillet, and then sets it to Newparting
                | element: Set Parting element = autoFillet.PartingElement
                | autofillet.PartingElement = NewPartingElement
                |

        :return:
        """
        return self.auto_fillet.PartingElement

    @parting_element.setter
    def parting_element(self, value):
        """
            :param type value:
        """
        self.auto_fillet.PartingElement = value 

    @property
    def round_radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RoundRadius
                | o Property RoundRadius(    ) As   (Read Only)
                | 
                | Returns the Round radius. Example: The following example
                | returns in round radius the round radius of the AutoFillet
                | Autofillet: Set roundradius = Autofillet.Radius
                |

        :return:
        """
        return self.auto_fillet.RoundRadius

    @property
    def round_radius_activation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RoundRadiusActivation
                | o Property RoundRadiusActivation(    ) As
                | 
                | Returns the AutoFillet RoundRadiusActivation flag (for
                | AutoFillet only). It returns 1 if RoundRadius is activated,
                | 0 if not. Returns: oRoundRadActivation The
                | RoundRadActivation flag as an int Example:
                |

        :return:
        """
        return self.auto_fillet.RoundRadiusActivation

    @property
    def slivers_and_crack(self, i_slivers):
        """
        .. note::
            CAA V5 Visual Basic help

                | SliversAndCrack
                | o Property SliversAndCrack(        iSlivers) (Write Only)
                | 
                |

        :param i_slivers:
        :return:
        """
        return self.auto_fillet.SliversAndCrack

    @property
    def slivers_and_cracks(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SliversAndCracks
                | o Property SliversAndCracks(    ) As   (Read Only)
                | 
                | Returns or sets the slivers face. Example: The following
                | example returns in slivers the sliver face of the autofillet
                | autoFillet, and then sets it to Newsliver: Set sliversFace =
                | autoFillet.SliversFace autofillet.SliversFace =
                | NewsliversFace
                |

        :return:
        """
        return self.auto_fillet.SliversAndCracks

    @slivers_and_cracks.setter
    def slivers_and_cracks(self, value):
        """
            :param type value:
        """
        self.auto_fillet.SliversAndCracks = value 

    @property
    def support_surface(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SupportSurface
                | o Property SupportSurface(    ) As
                | 
                | Returns or sets the support surface. Example: The following
                | example returns in SupportSurface the support surface
                | required for autofillet autoFillet, and then sets it to
                | NewSupportSurface: Set SupportSurface =
                | autoFillet.SupportSurface autofillet.SupportSurface =
                | NewSupportSurface
                |

        :return:
        """
        return self.auto_fillet.SupportSurface

    @support_surface.setter
    def support_surface(self, value):
        """
            :param type value:
        """
        self.auto_fillet.SupportSurface = value 

    def __repr__(self):
        return f'AutoFillet()'
