#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class FaceFillet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the face fillet shape.A face fillet shape is built between
                | two faces with a fillet radius.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.face_fillet = com_object     

    @property
    def first_face(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstFace
                | o Property FirstFace(    ) As
                | 
                | Returns or sets the first limiting face. To set the
                | property, you can use the following object: . Example: The
                | following example returns in face1 the first limiting face
                | of the face fillet firstFaceFillet, and then sets it to
                | NewFace1: Set face1 = firstFaceFillet.FirstFace
                | firstFaceFillet.FirstFace = NewFace1
                |

        :return:
        """
        return self.face_fillet.FirstFace

    @first_face.setter
    def first_face(self, value):
        """
            :param type value:
        """
        self.face_fillet.FirstFace = value 

    @property
    def radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Radius
                | o Property Radius(    ) As   (Read Only)
                | 
                | Returns the face fillet radius. Example: The following
                | example returns in radius the fillet radius of the face
                | fillet firstFaceFillet: Set radius = firstFaceFillet.Radius
                |

        :return:
        """
        return self.face_fillet.Radius

    @property
    def second_face(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondFace
                | o Property SecondFace(    ) As
                | 
                | Returns or sets the second limiting face. To set the
                | property, you can use the following object: . Example: The
                | following example returns in face2 the second limiting face
                | of the face fillet firstFaceFillet, and then sets it to
                | NewFace2: Set face2 = firstFaceFillet.SecondFace
                | firstFaceFillet.SecondFace = NewFace2
                |

        :return:
        """
        return self.face_fillet.SecondFace

    @second_face.setter
    def second_face(self, value):
        """
            :param type value:
        """
        self.face_fillet.SecondFace = value 

    def __repr__(self):
        return f'FaceFillet()'
