#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Thickness(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the thickness shape.The thickness shape is made up of a
                | collection of faces to process and an offset parameter.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.thickness = com_object     

    @property
    def faces_to_thicken(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FacesToThicken
                | o Property FacesToThicken(    ) As   (Read Only)
                | 
                | Returns the collection of faces to be thickened. Example:
                | The following example returns in list the list of faces of
                | the thickness firstThickness: Set list =
                | firstThickness.FacesToThicken
                |

        :return:
        """
        return self.thickness.FacesToThicken

    @property
    def offset(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Offset
                | o Property Offset(    ) As   (Read Only)
                | 
                | Returns the thickness offset. Example: The following example
                | returns in offset the offset of the thickness
                | firstThickness: Set offset = firstThickness.Offset
                |

        :return:
        """
        return self.thickness.Offset

    def add_face_to_thicken(self, i_face_to_thicken):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceToThicken
                | o Sub AddFaceToThicken(        iFaceToThicken)
                | 
                | Adds a new face to be thickened.
                |
                | Parameters:
                | iFaceToThicken
                |    The new face to process
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new face face to thicken for
                | the thickness firstThickness: call
                | firstThickness.AddFaceToThicken(face)

        :param i_face_to_thicken:
        :return:
        """
        return self.thickness.AddFaceToThicken(i_face_to_thicken)

    def add_face_with_different_thickness(self, i_face_to_thicken):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceWithDifferentThickness
                | o Sub AddFaceWithDifferentThickness(        iFaceToThicken)
                | 
                | Adds a new face to thicken with a different offset value.
                |
                | Parameters:
                | iFaceToThicken
                |    The new face to process
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new face face to thicken with
                | a different offset value for the thickness firstThickness:
                | call firstThickness.AddFaceWithDifferentThickness(face)

        :param i_face_to_thicken:
        :return:
        """
        return self.thickness.AddFaceWithDifferentThickness(i_face_to_thicken)

    def remove_face_with_different_thickness(self, i_face_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveFaceWithDifferentThickness
                | o Sub RemoveFaceWithDifferentThickness(        iFaceToRemove)
                | 
                | Removes an existing thickened face.
                |
                | Parameters:
                | iFaceToRemove
                |    The face to remove
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example removes the existing face thickened
                | face from the thickness firstThickness: call
                | firstThickness.RemoveFaceWithDifferentThickness(face)(face)

        :param i_face_to_remove:
        :return:
        """
        return self.thickness.RemoveFaceWithDifferentThickness(i_face_to_remove)

    def set_volume_support(self, i_volume_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVolumeSupport
                | o Sub SetVolumeSupport(        iVolumeSupport)
                | 
                | Set support of Thickness feature.
                |
                | Parameters:

                |
        :param i_volume_support:
        :return:
        """
        return self.thickness.SetVolumeSupport(i_volume_support)

    def withdraw_face_to_thicken(self, i_face_to_withdraw):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawFaceToThicken
                | o Sub WithdrawFaceToThicken(        iFaceToWithdraw)
                | 
                | Withdraws an existing thickened face.
                |
                | Parameters:
                | iFaceToWithdraw
                |    The face to withdraw
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws the existing face thickened
                | face from the thickness firstThickness: call
                | firstThickness.WithdrawFaceToThicken(face)

        :param i_face_to_withdraw:
        :return:
        """
        return self.thickness.WithdrawFaceToThicken(i_face_to_withdraw)

    def __repr__(self):
        return f'Thickness()'
