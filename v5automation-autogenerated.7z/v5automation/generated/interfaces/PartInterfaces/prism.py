#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Prism(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Prism-based features in Part Design : base for pad or pocket.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.prism = com_object     

    @property
    def direction_orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DirectionOrientation
                | o Property DirectionOrientation(    ) As
                | 
                | Returns the prism direction orientation. Returns:
                | oOrientation The direction orientation (see for list of
                | possible types) Example: The following example saves in
                | dirOrientation the direction orientation of prism
                | firstPrism, and then sets it so that the direction will be
                | now inversed : Set dirOrientation =
                | firstPrism.DirectionOrientation
                | firstPrism.DirectionOrientation = catInverseOrientation
                |

        :return:
        """
        return self.prism.DirectionOrientation

    @direction_orientation.setter
    def direction_orientation(self, value):
        """
            :param type value:
        """
        self.prism.DirectionOrientation = value 

    @property
    def direction_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DirectionType
                | o Property DirectionType(    ) As
                | 
                | Returns the prism direction type. Returns: oDirType The
                | direction type (see for list of possible types) Example: The
                | following example saves in dirType the direction type of
                | prism firstPrism, and then sets it so that the direction
                | will be now normal to the sketch : Set dirType =
                | firstPrism.DirectionType firstPrism.DirectionType =
                | catNormalToSketchDirection
                |

        :return:
        """
        return self.prism.DirectionType

    @direction_type.setter
    def direction_type(self, value):
        """
            :param type value:
        """
        self.prism.DirectionType = value 

    @property
    def first_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstLimit
                | o Property FirstLimit(    ) As   (Read Only)
                | 
                | Returns the first prism limit (one of the two). This limit
                | manages the way the prism is ended. Returns: oFirstLimit The
                | first limit (see for more information) Example: The
                | following example returns in firstLimit the first limit of
                | prism firstPrism: Set firstLimit = firstPrism.FirstLimit
                |

        :return:
        """
        return self.prism.FirstLimit

    @property
    def is_symmetric(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsSymmetric
                | o Property IsSymmetric(    ) As
                | 
                | Returns the prism symmetry flag. It returns TRUE if the
                | prism is symmetric (from the base sketch), FALSE if not.
                | Returns: oIsSymmetric The symmetry flag as a boolean
                | Example: The following example saves in symFlag the symmetry
                | flag of prism firstPrism, and then sets it so that it will
                | be now symmetric (from the base sketch) : Set symFlag =
                | firstPrism.IsSymmetric firstPrism.IsSymmetric = TRUE
                |

        :return:
        """
        return self.prism.IsSymmetric

    @property
    def is_thin(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsThin
                | o Property IsThin(    ) As
                | 
                | Returns the prism thin flag. It returns TRUE if the prism is
                | a thin prism , FALSE if not. Returns: oIsThin The thin flag
                | as a boolean Example: The following example saves in
                | thinFlag the thin flag of prism firstPrism, and then sets it
                | so that it will be now thin : Set thinFlag =
                | firstPrism.IsThin firstPrism.IsThin = TRUE
                |

        :return:
        """
        return self.prism.IsThin

    @property
    def merge_end(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MergeEnd
                | o Property MergeEnd(    ) As
                | 
                | Returns the prism merge end flag (for thin prism only). It
                | returns TRUE if merge ends is required , FALSE if not.
                | Returns: oIsMergeEnd The merge end flag as a boolean
                | Example: The following example saves in MergeEndFlag the
                | merge end flag of prism firstPrism, and then sets it so that
                | merge end will be required : Set MergeEndFlag =
                | firstPrism.IsMergeEnd firstPrism.IsMergeEnd = TRUE
                |

        :return:
        """
        return self.prism.MergeEnd

    @merge_end.setter
    def merge_end(self, value):
        """
            :param type value:
        """
        self.prism.MergeEnd = value 

    @property
    def neutral_fiber(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NeutralFiber
                | o Property NeutralFiber(    ) As
                | 
                | Returns the prism neutral fiber flag (for thin prism only).
                | It returns TRUE if the prism is a neutral fiber prism ,
                | FALSE if not. Returns: oIsNeutralFiber The neutral fiber
                | flag as a boolean Example: The following example saves in
                | NeutralFiberFlag the neutral fiber flag of prism firstPrism,
                | and then sets it so that it will be now neutral fiber : Set
                | NeutralFiberFlag = firstPrism.IsNeutralFiber
                | firstPrism.IsNeutralFiber = TRUE
                |

        :return:
        """
        return self.prism.NeutralFiber

    @neutral_fiber.setter
    def neutral_fiber(self, value):
        """
            :param type value:
        """
        self.prism.NeutralFiber = value 

    @property
    def second_limit(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondLimit
                | o Property SecondLimit(    ) As   (Read Only)
                | 
                | Returns the second prism limit (one of the two). This limit
                | manages the way the prism is ended. Returns: oSecondLimit
                | The second limit (see for more information) Example: The
                | following example returns in secondLimit the second limit of
                | prism firstPrism: Set secondLimit = firstPrism.SecondLimit
                |

        :return:
        """
        return self.prism.SecondLimit

    def get_direction(self, io_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDirection
                | o Sub GetDirection(        ioDirection)
                | 
                | Returns the prism direction with absolute coordinates. It
                | needs a safe array with 3 elements : X, Y, Z direction
                | coordinates The array must be previously initialized
                | Returns: ioDirection The direction coordinates Example: The
                | following example returns in dirArray the direction
                | coordinates of prism firstPrism: Dim dirArray(2) Call
                | firstPrism.GetDirection(dirArray) Set x = dirArray[1] Set y
                | = dirArray[2] Set z = dirArray[3]
                |
                | Parameters:

                |
        :param io_direction:
        :return:
        """
        return self.prism.GetDirection(io_direction)

    def reverse_inner_side(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReverseInnerSide
                | o Sub ReverseInnerSide(    )
                | 
                | Reverses the prism inner side when the profile is open. This
                | is useful for finding the shape to reach. Example: The
                | following example reverses the current inner side of prism
                | firstPrism : firstPrism.ReverseInnerSide
                |
                | Parameters:

                |
        :return:
        """
        return self.prism.ReverseInnerSide()

    def set_direction(self, i_line):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDirection
                | o Sub SetDirection(        iLine)
                | 
                | Sets the prism associative direction.
                |
                | Parameters:
                | iLine
                |   The support direction reference (see 
                | 
                |  for more information)  This reference can be valuated with a reference to a line or an edge.
                |  The following 
                |  objects are supported:  
                | , 
                |  and 
                | .

                |                | Examples:
                | The following example sets the prism direction reference of
                | prism firstPrism with prismDirRef line :
                | firstPrism.SetDirection prismDirRef

        :param i_line:
        :return:
        """
        return self.prism.SetDirection(i_line)

    def __repr__(self):
        return f'Prism()'
