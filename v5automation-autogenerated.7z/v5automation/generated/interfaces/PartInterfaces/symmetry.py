#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Symmetry(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the shape symmetry feature object.This solid feature is
                | created from  an underlying HybridShapeSymmetry aggregated by the
                | Symmetry.Role: To access the data of the symmetry shape feature
                | object. The data includes:Use the CATIAShapeFactory to create
                | ShapeFeature object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.symmetry = com_object     

    @property
    def hybrid_shape(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HybridShape
                | o Property HybridShape(    ) As   (Read Only)
                | 
                | Gets the underlying HybridShapeSymmetry. Example: The
                | following example explains how to retrieve the underlying
                | HybridShape Symmetry Dim oHybridShape as AnyObject Set
                | oHybridShape=oSymmetry.HybridShape
                | oHybridShape.SectionCoupling = 2
                |

        :return:
        """
        return self.symmetry.HybridShape

    def __repr__(self):
        return f'Symmetry()'
