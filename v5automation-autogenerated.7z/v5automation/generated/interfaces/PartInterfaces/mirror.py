#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Mirror(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the mirror shape.It duplicates a shape with respect  to a
                | planar mirroring element, such as a planar face or a plane.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.mirror = com_object     

    @property
    def mirroring_object(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MirroringObject
                | o Property MirroringObject(    ) As   (Read Only)
                | 
                | Returns the mirroring Object.
                |

        :return:
        """
        return self.mirror.MirroringObject

    @property
    def mirroring_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MirroringPlane
                | o Property MirroringPlane(    ) As
                | 
                | Returns or sets the mirroring reference plane. It can be a
                | plane, or a plane face. To set the property, you can use the
                | following object: . Example: The following example returns
                | in ref the mirroring reference plane of the mirroring
                | firstMirroring, and then sets it to the created MyRef: Set
                | ref = firstMirroring.MirroringPlane Set MyRef =
                | part.CreateReferenceFromGeometry (plane)
                | firstMirroring.MirroringPlane = MyRef
                |

        :return:
        """
        return self.mirror.MirroringPlane

    @mirroring_plane.setter
    def mirroring_plane(self, value):
        """
            :param type value:
        """
        self.mirror.MirroringPlane = value 

    def __repr__(self):
        return f'Mirror()'
