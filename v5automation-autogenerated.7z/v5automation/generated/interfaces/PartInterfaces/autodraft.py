#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class AutoDraft(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the AutoDraft shape.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.auto_draft = com_object     

    @property
    def functional_face(self, i_face):
        """
        .. note::
            CAA V5 Visual Basic help

                | FunctionalFace
                | o Property FunctionalFace(        iFace) (Write Only)
                | 
                |

        :param i_face:
        :return:
        """
        return self.auto_draft.FunctionalFace

    @property
    def functional_faces(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FunctionalFaces
                | o Property FunctionalFaces(    ) As   (Read Only)
                | 
                | Returns or sets the functional faces. Example: The following
                | example returns in FunctionalFaces the list functional faces
                | of the AutoDraft AutoDraft, and then sets NewFunctionalFace
                | as a functional face: Set FunctionalFaces =
                | AutoDraft.FunctionalFace AutoDraft.FunctionalFace =
                | NewFunctionalFace
                |

        :return:
        """
        return self.auto_draft.FunctionalFaces

    @functional_faces.setter
    def functional_faces(self, value):
        """
            :param type value:
        """
        self.auto_draft.FunctionalFaces = value 

    @property
    def main_draft_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MainDraftAngle
                | o Property MainDraftAngle(    ) As
                | 
                | Returns or sets the main draft angle. Example: The following
                | example returns in MainDraftAngle the main draft angle of
                | the AutoDraft AutoDraft, and then sets it to
                | NewMainDraftAngle.: Set MainDraftAngle =
                | AutoDraft.MainDraftAngle AutoDraft.MainDraftAngle =
                | NewMainDraftAngle
                |

        :return:
        """
        return self.auto_draft.MainDraftAngle

    @main_draft_angle.setter
    def main_draft_angle(self, value):
        """
            :param type value:
        """
        self.auto_draft.MainDraftAngle = value 

    @property
    def mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Mode
                | o Property Mode(    ) As
                | 
                | Returns or sets the draft mode. Example: The following
                | example returns in Mode the mode of the draft AutoDraft
                | AutoDraft, and then sets it to NewMode: Set Mode =
                | AutoDraft.Mode AutoDraft.Mode = NewMode
                |

        :return:
        """
        return self.auto_draft.Mode

    @mode.setter
    def mode(self, value):
        """
            :param type value:
        """
        self.auto_draft.Mode = value 

    @property
    def parting_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartingElement
                | o Property PartingElement(    ) As
                | 
                | Returns or sets the parting element. Example: The following
                | example returns in PartingElement the parting element of the
                | AutoDraft AutoDraft, and then sets it to NewpartingElement:
                | Set PartingElement = AutoDraft.PartingElement
                | AutoDraft.PartingElement = NewPartingElement
                |

        :return:
        """
        return self.auto_draft.PartingElement

    @parting_element.setter
    def parting_element(self, value):
        """
            :param type value:
        """
        self.auto_draft.PartingElement = value 

    @property
    def pulling_direction(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PullingDirection
                | o Property PullingDirection(    ) As
                | 
                | Returns or sets the pulling direction. Example: The
                | following example returns in PullingDirection the pulling
                | direction of the AutoDraft AutoDraft, and then sets it to
                | NewPullingDirection.: Set PullingDirection =
                | AutoDraft.PullingDirection AutoDraft.PullingDirection =
                | NewPullingDirection
                |

        :return:
        """
        return self.auto_draft.PullingDirection

    @pulling_direction.setter
    def pulling_direction(self, value):
        """
            :param type value:
        """
        self.auto_draft.PullingDirection = value 

    def __repr__(self):
        return f'AutoDraft()'
