#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class EdgeFillet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the edges-based fillet shape.It is the base object for
                | constant radius edge fillets and variable radius edge fillets.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.edge_fillet = com_object     

    @property
    def edge_propagation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EdgePropagation
                | o Property EdgePropagation(    ) As
                | 
                | Returns or sets the edge fillet propagation mode. This
                | propagation mode is used when computing the edges to be
                | filleted. Example: The following example returns in mode the
                | edge fillet propagation mode of the firstEdgeFillet edge
                | fillet, and then sets it to CATMinimalFilletEdgePropagation,
                | so that a minimum numbers of edges will be filleted: Set
                | mode = firstEdgeFillet.EdgePropagation Set
                | firstEdgeFillet.EdgePropagation =
                | CATMinimalFilletEdgePropagation
                |

        :return:
        """
        return self.edge_fillet.EdgePropagation

    @edge_propagation.setter
    def edge_propagation(self, value):
        """
            :param type value:
        """
        self.edge_fillet.EdgePropagation = value 

    @property
    def edges_to_keep(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EdgesToKeep
                | o Property EdgesToKeep(    ) As   (Read Only)
                | 
                | Returns the collection of edges to keep by the edge fillet.
                | Example: The following example returns in edges the edges to
                | keep of the constant radius edge fillet firstCstEdgeFillet:
                | Set edges = firstCstEdgeFillet.EdgesToKeep
                |

        :return:
        """
        return self.edge_fillet.EdgesToKeep

    def add_edge_to_keep(self, i_edge_to_keep):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddEdgeToKeep
                | o Sub AddEdgeToKeep(        iEdgeToKeep)
                | 
                | Adds a new edge to keep by the filleting operation. The edge
                | to keep is not modified by the fillet.
                |
                | Parameters:
                | iEdgeToKeep
                |    The edge to keep by the filleting operation
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new edge edge to be kept from
                | filleting by the constant radius edge fillet
                | firstCstEdgeFillet: firstCstEdgeFillet.AddEdgeToKeep(edge)

        :param i_edge_to_keep:
        :return:
        """
        return self.edge_fillet.AddEdgeToKeep(i_edge_to_keep)

    def withdraw_edge_to_keep(self, i_edge_to_withdraw):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawEdgeToKeep
                | o Sub WithdrawEdgeToKeep(        iEdgeToWithdraw)
                | 
                | Withdraws an edge from those kept by a filleting operation.
                |
                | Parameters:
                | iEdgeToWithdraw
                |    The edge to withdraw
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws the edge edge from those
                | kept from filleting by the constant radius edge fillet
                | firstCstEdgeFillet:
                | firstCstEdgeFillet.WithdrawEdgeToKeep(edge)

        :param i_edge_to_withdraw:
        :return:
        """
        return self.edge_fillet.WithdrawEdgeToKeep(i_edge_to_withdraw)

    def __repr__(self):
        return f'EdgeFillet()'
