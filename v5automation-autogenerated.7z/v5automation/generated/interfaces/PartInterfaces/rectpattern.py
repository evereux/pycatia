#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class RectPattern(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the rectangular pattern.The shape is copied along two
                | directions. Two linear repartitions control the shape copy.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.rect_pattern = com_object     

    @property
    def first_direction_repartition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstDirectionRepartition
                | o Property FirstDirectionRepartition(    ) As   (Read Only)
                | 
                | Returns the linear repartition along the first direction.
                | Example: The following example returns in repart1 the first
                | linear repartition of the rectangular pattern firstPattern:
                | Set repart1 = firstPattern.FirstDirectionRepartition
                |

        :return:
        """
        return self.rect_pattern.FirstDirectionRepartition

    @property
    def first_direction_row(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstDirectionRow
                | o Property FirstDirectionRow(    ) As   (Read Only)
                | 
                | Returns the position of the shape to be copied along the
                | first linear direction. Example: The following example
                | returns in FirstDirPos the position of the shape to be
                | copied along the first linear direction in the rectangular
                | pattern firstPattern: Set FirstDirPos =
                | firstPattern.FirstDirectionRow
                |

        :return:
        """
        return self.rect_pattern.FirstDirectionRow

    @property
    def first_orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstOrientation
                | o Property FirstOrientation(    ) As
                | 
                | Returns or sets whether the pattern is built towards the
                | first direction orientation. True if the pattern is built
                | towards the first direction orientation. Example: The
                | following example returns in aligned1 whether the
                | rectangular pattern firstPattern is built towards the first
                | direction orientation, and then sets its to True: Set
                | aligned1 = firstPattern.FirstOrientation
                | firstPattern.FirstOrientation = True
                |

        :return:
        """
        return self.rect_pattern.FirstOrientation

    @first_orientation.setter
    def first_orientation(self, value):
        """
            :param type value:
        """
        self.rect_pattern.FirstOrientation = value 

    @property
    def first_rectangular_pattern_parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FirstRectangularPatternParameters
                | o Property FirstRectangularPatternParameters(    ) As
                | 
                | Returns or sets the rectangular pattern parameters required
                | to define the pattern. These parameters are used when
                | reading the CATIALinearRepartition properties. Example: The
                | following example returns in parameters the rectangular
                | pattern parameters of the firstPattern rectangular pattern,
                | and then sets it to catUnequalSpacing, so that the unqual
                | spacing will be defined in first direction: Set parameters =
                | firstPattern.FirstCircularPatternParameters Set
                | firstPattern.FirstCircularPatternParameters =
                | catUnequalSpacing
                |

        :return:
        """
        return self.rect_pattern.FirstRectangularPatternParameters

    @first_rectangular_pattern_parameters.setter
    def first_rectangular_pattern_parameters(self, value):
        """
            :param type value:
        """
        self.rect_pattern.FirstRectangularPatternParameters = value 

    @property
    def second_direction_repartition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondDirectionRepartition
                | o Property SecondDirectionRepartition(    ) As   (Read Only)
                | 
                | Returns the linear repartition along the second direction.
                | Example: The following example returns in repart2 the second
                | linear repartition of the rectangular pattern firstPattern:
                | Set repart2 = firstPattern.SecondDirectionRepartition
                |

        :return:
        """
        return self.rect_pattern.SecondDirectionRepartition

    @property
    def second_direction_row(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondDirectionRow
                | o Property SecondDirectionRow(    ) As   (Read Only)
                | 
                | Returns the position of the shape to be copied along the
                | second linear direction. Example: The following example
                | returns in SecondDirPos the position of the shape to be
                | copied along the second linear direction in the rectangular
                | pattern firstPattern: Set SecondDirPos =
                | firstPattern.SecondDirectionRow
                |

        :return:
        """
        return self.rect_pattern.SecondDirectionRow

    @property
    def second_orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondOrientation
                | o Property SecondOrientation(    ) As
                | 
                | Returns or sets whether the pattern is built towards the
                | second direction orientation. True if the pattern is built
                | towards the second direction orientation. Example: The
                | following example returns in aligned2 whether the
                | rectangular pattern firstPattern is built towards the second
                | direction orientation, and then sets its to False, meaning
                | the pattern is built in the opposite direction: Set aligned2
                | = firstPattern.SecondOrientation
                | firstPattern.SecondOrientation = False
                |

        :return:
        """
        return self.rect_pattern.SecondOrientation

    @second_orientation.setter
    def second_orientation(self, value):
        """
            :param type value:
        """
        self.rect_pattern.SecondOrientation = value 

    @property
    def second_rectangular_pattern_parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SecondRectangularPatternParameters
                | o Property SecondRectangularPatternParameters(    ) As
                | 
                | Returns or sets the rectangular pattern parameters required
                | to define the pattern. These parameters are used when
                | reading the CATIALinearRepartition properties. Example: The
                | following example returns in parameters the rectangular
                | pattern parameters of the secondPattern rectangular pattern,
                | and then sets it to catUnequalSpacing, so that the unqual
                | spacing will be defined in second direction: Set parameters
                | = secondPattern.SecondCircularPatternParameters Set
                | secondPattern.SecondCircularPatternParameters =
                | catUnequalSpacing
                |

        :return:
        """
        return self.rect_pattern.SecondRectangularPatternParameters

    @second_rectangular_pattern_parameters.setter
    def second_rectangular_pattern_parameters(self, value):
        """
            :param type value:
        """
        self.rect_pattern.SecondRectangularPatternParameters = value 

    def get_first_direction(self, io_first_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFirstDirection
                | o Sub GetFirstDirection(        ioFirstDirection)
                | 
                | Returns the first repartition direction. The first
                | repartition direction is returned as an array containing the
                | direction vector components. Assume this array is
                | o1stDirRep. It contains:
                | o1stDirRep[0],o1stDirRep[1],o1stDirRep[2] The X, Y, and Z
                | direction vector components Example: The following example
                | returns in FirstDir the first repartition direction vector
                | components of the rectangular pattern firstPattern and saves
                | them in variables: Dim FirstDir() Call
                | firstPattern.GetFirstDirection(FirstDir) x = FirstDir(0) y =
                | FirstDir(1) z = FirstDir(2)
                |
                | Parameters:

                |
        :param io_first_direction:
        :return:
        """
        return self.rect_pattern.GetFirstDirection(io_first_direction)

    def get_second_direction(self, io_second_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSecondDirection
                | o Sub GetSecondDirection(        ioSecondDirection)
                | 
                | Returns the second repartition direction. The second
                | repartition direction is returned as an array containing the
                | direction vector components. Assume this array is
                | o2ndDirRep. It contains:
                | o2ndDirRep[0],o2ndDirRep[1],o2ndDirRep[2] The X, Y, and Z
                | direction vector components Example: The following example
                | returns in SecondDir the second repartition direction vector
                | components of the rectangular pattern firstPattern and saves
                | them in variables: Call
                | firstPattern.GetSecondDirection(SecondDir) x = SecondDir[0]
                | y = SecondDir[1] z = SecondDir[2]
                |
                | Parameters:

                |
        :param io_second_direction:
        :return:
        """
        return self.rect_pattern.GetSecondDirection(io_second_direction)

    def set_first_direction(self, i_first_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFirstDirection
                | o Sub SetFirstDirection(        iFirstDirection)
                | 
                | Sets the first repartition direction.
                |
                | Parameters:
                | iFirstDirection
                |    The first repartition direction.
                |    It is passed as a 
                | 
                |  and can be valuated   with a reference to a line or an edge.
                |  The following 
                |  objects are supported:  
                | , 
                |  and 
                | .

                |                | Examples:
                | The following example sets the first repartition direction
                | of the rectangular pattern firstPattern with the refToLine1
                | reference : firstPattern.SetFirstDirection refToLine1

        :param i_first_direction:
        :return:
        """
        return self.rect_pattern.SetFirstDirection(i_first_direction)

    def set_instance_spacing(self, i_instance_number, i_spacing, i_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInstanceSpacing
                | o Sub SetInstanceSpacing(        iInstanceNumber,
                |                                  iSpacing,
                |                                  iDirection)
                | 
                | Sets the InstanceSpacing.
                |
                | Parameters:
                | iInstanceNumber
                |    The Instance Number
                |  
                |  iSpacing
                |    The Spacing 
                |  
                |  iDirection
                |    The Instance direction

                |                | Examples:
                | The following example sets the InstanceSpacing in a
                | direction for unequal spacing

        :param i_instance_number:
        :param i_spacing:
        :param i_direction:
        :return:
        """
        return self.rect_pattern.SetInstanceSpacing(i_instance_number, i_spacing, i_direction)

    def set_second_direction(self, i_second_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSecondDirection
                | o Sub SetSecondDirection(        iSecondDirection)
                | 
                | Sets the second repartition direction.
                |
                | Parameters:
                | iSecondDirection
                |    The second repartition direction.
                |    It is passed as a 
                | 
                |  and can be valuated   with a reference to a line or an edge.
                |  The following 
                |  objects are supported:  
                | , 
                |  and 
                | .

                |                | Examples:
                | The following example sets the second repartition direction
                | of the rectangular pattern firstPattern with the refToLine2
                | reference : firstPattern.SetSecondDirection refToLine2

        :param i_second_direction:
        :return:
        """
        return self.rect_pattern.SetSecondDirection(i_second_direction)

    def set_unequal_instance_number(self, i_instance_number, i_direction):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUnequalInstanceNumber
                | o Sub SetUnequalInstanceNumber(        iInstanceNumber,
                |                                        iDirection)
                | 
                | Sets the Instance Number.
                |
                | Parameters:
                | iInstanceNumber
                |    The Instance Number
                |  
                |  iDirection
                |    The Instance direction

                |                | Examples:
                | The following example modifies the instance number for
                | unequal spacing

        :param i_instance_number:
        :param i_direction:
        :return:
        """
        return self.rect_pattern.SetUnequalInstanceNumber(i_instance_number, i_direction)

    def __repr__(self):
        return f'RectPattern()'
