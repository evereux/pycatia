#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Pattern(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the pattern shape.It is the base object for rectangular and
                | circular patterns. A pattern shape is a set of copies of the same
                | shape. The copy is done according to linear and angular repartitions.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.pattern = com_object     

    @property
    def item_to_copy(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ItemToCopy
                | o Property ItemToCopy(    ) As
                | 
                | Returns or sets the shape to be copied. Example: The
                | following example returns in shape the copied shape of the
                | pattern firstPattern, and then sets it to pad1: Set shape =
                | firstPattern.ItemToCopy firstPattern.ItemToCopy = pad1
                |

        :return:
        """
        return self.pattern.ItemToCopy

    @item_to_copy.setter
    def item_to_copy(self, value):
        """
            :param type value:
        """
        self.pattern.ItemToCopy = value 

    @property
    def rotation_angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RotationAngle
                | o Property RotationAngle(    ) As   (Read Only)
                | 
                | Returns the pattern global rotation angle. The rotation is
                | applied to the whole pattern, but not to the shapes
                | themselves. The shape to be copied is used as the rotation
                | center. Example: The following example returns in globAng
                | the rotation of pattern firstPattern: Set globAng =
                | firstPattern.RotationAngle
                |

        :return:
        """
        return self.pattern.RotationAngle

    def activate_position(self, i_pos_u, i_pos_v):
        """
        .. note::
            CAA V5 Visual Basic help

                | ActivatePosition
                | o Sub ActivatePosition(        iPosU,
                |                                iPosV)
                | 
                | Allows user to activate an instance of the pattern.
                |
                | Parameters:
                | iPosU
                |    The position of the instance in the U direction
                |  
                |  iPosV
                |    The position of the instance in the V direction

                |
        :param i_pos_u:
        :param i_pos_v:
        :return:
        """
        return self.pattern.ActivatePosition(i_pos_u, i_pos_v)

    def desactivate_position(self, i_pos_u, i_pos_v):
        """
        .. note::
            CAA V5 Visual Basic help

                | DesactivatePosition
                | o Sub DesactivatePosition(        iPosU,
                |                                   iPosV)
                | 
                | Allows user to desactivate an instance of the pattern.
                |
                | Parameters:
                | iPosU
                |    The position of the instance in the U direction
                |  
                |  iPosV
                |    The position of the instance in the V direction

                |
        :param i_pos_u:
        :param i_pos_v:
        :return:
        """
        return self.pattern.DesactivatePosition(i_pos_u, i_pos_v)

    def __repr__(self):
        return f'Pattern()'
