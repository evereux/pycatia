#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Scaling2(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Scaling2 feature object.This solid feature is created
                | from  an underlying HybridShapeScaling  aggregated by the
                | Scaling.Role: To access the data of the feature object. This data
                | includes:Use the CATIAShapeFactory to create Part object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.scaling2 = com_object     

    @property
    def center(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Center
                | o Property Center(    ) As
                | 
                | Returns or sets the reference element.This element can be a
                | point or a plane. To set the property, you can use one of
                | the following objects: or . Example: This example retrieves
                | in RefElem the reference element for the Scaling2 hybrid
                | shape feature. Dim RefElem As Reference Set RefElem =
                | Scaling2.Center
                |

        :return:
        """
        return self.scaling2.Center

    @center.setter
    def center(self, value):
        """
            :param type value:
        """
        self.scaling2.Center = value 

    @property
    def ratio(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Ratio
                | o Property Ratio(    ) As   (Read Only)
                | 
                | Returns the scaling ratio.
                |

        :return:
        """
        return self.scaling2.Ratio

    @property
    def ratio_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RatioValue
                | o Property RatioValue(    ) As
                | 
                | Returns or sets the scaling ratio value. Example: This
                | example retrieves in Value the ratio value for the Scaling
                | hybrid shape feature. Dim Value As double Set Value =
                | Scaling2.RatioValue
                |

        :return:
        """
        return self.scaling2.RatioValue

    @ratio_value.setter
    def ratio_value(self, value):
        """
            :param type value:
        """
        self.scaling2.RatioValue = value 

    def __repr__(self):
        return f'Scaling2()'
