#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class VarRadEdgeFillet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the edge fillet shape with a variable radius.The resulting
                | shape is made up of edges fillets controlled by couples of
                | radius/vertex.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.var_rad_edge_fillet = com_object     

    @property
    def bitangency_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BitangencyType
                | o Property BitangencyType(    ) As
                | 
                | Returns or set the fillet bitangency type.
                |

        :return:
        """
        return self.var_rad_edge_fillet.BitangencyType

    @property
    def edges_to_fillet(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EdgesToFillet
                | o Property EdgesToFillet(    ) As   (Read Only)
                | 
                | Returns the collection of edges to be filleted. Example: The
                | following example returns in edges the edges to fillet of
                | variable radius edge filletfirstVarEdgeFillet: Set edges =
                | firstVarEdgeFillet.EdgesToFillet
                |

        :return:
        """
        return self.var_rad_edge_fillet.EdgesToFillet

    @property
    def fillet_spine(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FilletSpine
                | o Property FilletSpine(    ) As
                | 
                | Returns or set the spine for circle bitangency fillet.
                |

        :return:
        """
        return self.var_rad_edge_fillet.FilletSpine

    @property
    def fillet_variation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FilletVariation
                | o Property FilletVariation(    ) As
                | 
                | Returns or sets the edge fillet radius variation mode.
                | Example: The following example returns in mode the radius
                | variation mode of the variable radius edge
                | filletfirstVarEdgeFillet, and then sets it to
                | CATLinearFilletVariation so that the radius variation is
                | linear between two control vertices: mode =
                | firstVarEdgeFillet.FilletVariation
                | firstVarEdgeFillet.FilletVariation =
                | CATLinearFilletVariation
                |

        :return:
        """
        return self.var_rad_edge_fillet.FilletVariation

    @fillet_variation.setter
    def fillet_variation(self, value):
        """
            :param type value:
        """
        self.var_rad_edge_fillet.FilletVariation = value 

    @property
    def imposed_vertices(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImposedVertices
                | o Property ImposedVertices(    ) As   (Read Only)
                | 
                | Returns the collection of vertices where a radius has been
                | imposed. Example: The following example returns in vertices
                | the collection of imposed vertices of the variable radius
                | edge filletfirstVarEdgeFillet: Set vertices =
                | firstVarEdgeFillet.ImposedVertices
                |

        :return:
        """
        return self.var_rad_edge_fillet.ImposedVertices

    def add_edge_to_fillet(self, i_edge, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddEdgeToFillet
                | o Sub AddEdgeToFillet(        iEdge,
                |                               iRadius)
                | 
                | Adds a new edge to the variable radius edge fillet.
                |
                | Parameters:
                | iEdge
                |    The edge to be filleted
                |  The following 
                | 
                |  object is supported:  
                | . 
                |      iRadius
                |    The radius to impose along the edge.
                |    This radius is imposed at both end points of the edge.

                |                | Examples:
                | The following example adds the new edge edge to be filleted
                | to the variable radius edge fillet firstVarEdgeFillet: call
                | firstVarEdgeFillet.AddEdgeToFillet(edge, 5.)

        :param i_edge:
        :param i_radius:
        :return:
        """
        return self.var_rad_edge_fillet.AddEdgeToFillet(i_edge, i_radius)

    def add_imposed_vertex(self, i_vertex, i_radius):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddImposedVertex
                | o Sub AddImposedVertex(        iVertex,
                |                                iRadius)
                | 
                | Adds a new control couple. A control couple is made up of a
                | vertex and a radius.
                |
                | Parameters:
                | iVertex
                |    The vertex where to impose the radius
                |  
                |  iRadius
                |    The radius to impose at the given vertex

                |                | Examples:
                | The following example adds a new control couple (vertex,
                | radius) to the variable radius edge fillet
                | firstVarEdgeFillet set with the vertex vertex and a radius
                | of 50. call firstVarEdgeFillet.AddImposedVertex(vertex, 50.)

        :param i_vertex:
        :param i_radius:
        :return:
        """
        return self.var_rad_edge_fillet.AddImposedVertex(i_vertex, i_radius)

    def imposed_vertex_radius(self, i_imposed_vertex):
        """
        .. note::
            CAA V5 Visual Basic help

                | ImposedVertexRadius
                | o Func ImposedVertexRadius(        iImposedVertex) As
                | 
                | Returns the fillet radius on an imposed vertex.
                |
                | Parameters:
                | iImposedVertex
                |    The vertex where to retrieve the fillet radius
                |  
                | 
                |  Returns:
                |    The fillet radius

                |                | Examples:
                | The following example returns in radius the fillet radius of
                | the variable radius edge fillet firstVarEdgeFillet at the
                | vertex vertex: Set radius =
                | firstVarEdgeFillet.ImposedVertexRadius(vertex)

        :param i_imposed_vertex:
        :return:
        """
        return self.var_rad_edge_fillet.ImposedVertexRadius(i_imposed_vertex)

    def withdraw_edge_to_fillet(self, i_edge):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawEdgeToFillet
                | o Sub WithdrawEdgeToFillet(        iEdge)
                | 
                | Withdraws an edge from the variable radius edge fillet.
                |
                | Parameters:
                | iEdge
                |    The edge to be withdrawn
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws the edge edge from those to
                | be filleted of the variable radius edge fillet
                | firstVarEdgeFillet: call
                | firstVarEdgeFillet.WithdrawEdgeToFillet(edge)

        :param i_edge:
        :return:
        """
        return self.var_rad_edge_fillet.WithdrawEdgeToFillet(i_edge)

    def withdraw_imposed_vertex(self, i_vertex):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawImposedVertex
                | o Sub WithdrawImposedVertex(        iVertex)
                | 
                | Withdraws a control couple.
                |
                | Parameters:
                | iVertex
                |    The vertex where the radius is imposed

                |                | Examples:
                | The following example withdraws the imposed radius on the
                | vertex vertex for the variable radius edge fillet
                | firstVarEdgeFillet: call
                | firstVarEdgeFillet.WithdrawImposedVertex(vertex)

        :param i_vertex:
        :return:
        """
        return self.var_rad_edge_fillet.WithdrawImposedVertex(i_vertex)

    def __repr__(self):
        return f'VarRadEdgeFillet()'
