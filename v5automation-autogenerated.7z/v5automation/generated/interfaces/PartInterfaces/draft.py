#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Draft(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the draft shape.A draft shape is made up of draft domains
                | (at least one) and of a parting element.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.draft = com_object     

    @property
    def draft_domains(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DraftDomains
                | o Property DraftDomains(    ) As   (Read Only)
                | 
                | Returns the collection of draft domains. Example: The
                | following example returns in list the collection of draft
                | domains of the firstDraft draft: Set list =
                | firstDraft.DraftDomains
                |

        :return:
        """
        return self.draft.DraftDomains

    @property
    def mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Mode
                | o Property Mode(    ) As
                | 
                | Returns or sets the draft mode. Example: The following
                | example returns in mode the draft mode of the firstDraft
                | draft, and then sets it to CatReflectKeepFaceDraftMode: Set
                | mode = firstDraft.Mode Set firstDraft.Mode =
                | CatReflectKeepFaceDraftMode
                |

        :return:
        """
        return self.draft.Mode

    @mode.setter
    def mode(self, value):
        """
            :param type value:
        """
        self.draft.Mode = value 

    @property
    def parting_element(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PartingElement
                | o Property PartingElement(    ) As
                | 
                | Returns or sets the draft parting element. To set the
                | property, you can use the following object: . Example: The
                | following example returns in element the parting element of
                | the firstDraft draft, and then sets it to the element2
                | geometrical element: Set element = firstDraft.PartingElement
                | Set firstDraft.PartingElement = element2
                |

        :return:
        """
        return self.draft.PartingElement

    @parting_element.setter
    def parting_element(self, value):
        """
            :param type value:
        """
        self.draft.PartingElement = value 

    def __repr__(self):
        return f'Draft()'
