#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class DefeaturingFilterWithRange(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the base object for defeaturing filters which uses range(s)
                | of values

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.defeaturing_filter_with_range = com_object     

    def get_maximum_activity(self, i_range_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | getMaximumActivity
                | o Func getMaximumActivity(        iRangeId) As
                | 
                |
                | Parameters:

                |
        :param i_range_id:
        :return:
        """
        return self.defeaturing_filter_with_range.getMaximumActivity(i_range_id)

    def get_maximum_angle(self, i_range_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | getMaximumAngle
                | o Func getMaximumAngle(        iRangeId) As
                | 
                |
                | Parameters:

                |
        :param i_range_id:
        :return:
        """
        return self.defeaturing_filter_with_range.getMaximumAngle(i_range_id)

    def get_maximum_length(self, i_range_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | getMaximumLength
                | o Func getMaximumLength(        iRangeId) As
                | 
                |
                | Parameters:

                |
        :param i_range_id:
        :return:
        """
        return self.defeaturing_filter_with_range.getMaximumLength(i_range_id)

    def get_maximum_value(self, i_range_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | getMaximumValue
                | o Func getMaximumValue(        iRangeId) As
                | 
                |
                | Parameters:

                |
        :param i_range_id:
        :return:
        """
        return self.defeaturing_filter_with_range.getMaximumValue(i_range_id)

    def get_minimum_activity(self, i_range_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | getMinimumActivity
                | o Func getMinimumActivity(        iRangeId) As
                | 
                | Returns the minimum or maximum value activity of the filter
                | for the given range id.
                |
                | Parameters:
                | iRangeId
                |    The identificator of the range on which the minimum/maximum should be read
                |      - if iRangeId is empty or equal to "Default", takes the default range as defined by the filter ("RibbonRadius" for FilletFilter, "MainDiameter" for HoleFilter)
                |      - else iRangeId should be chosen among:
                |            * {"RibbonRadius","RibbonAngle","RibbonLength"} for FilletFilter
                |            * {"MainDiameter"} for HoleFilter
                |            * any defined and supported range id in case of a user-defined filter
                |  
                | 
                |  Returns:
                |   oValue   The filter minimum/maximum activity for the specified range

                |                | Examples:
                | The following example returns in theMinActivity the minimum
                | value activity of filter myFilter for the range myRange: Set
                | theMinActivity = myFilter.getMinimumActivity(myRange)

        :param i_range_id:
        :return:
        """
        return self.defeaturing_filter_with_range.getMinimumActivity(i_range_id)

    def get_minimum_angle(self, i_range_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | getMinimumAngle
                | o Func getMinimumAngle(        iRangeId) As
                | 
                |
                | Parameters:

                |
        :param i_range_id:
        :return:
        """
        return self.defeaturing_filter_with_range.getMinimumAngle(i_range_id)

    def get_minimum_length(self, i_range_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | getMinimumLength
                | o Func getMinimumLength(        iRangeId) As
                | 
                |
                | Parameters:

                |
        :param i_range_id:
        :return:
        """
        return self.defeaturing_filter_with_range.getMinimumLength(i_range_id)

    def get_minimum_value(self, i_range_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | getMinimumValue
                | o Func getMinimumValue(        iRangeId) As
                | 
                | Returns the minimum or maximum value of the filter for the
                | given range id, if defined and active.
                |
                | Parameters:
                | iRangeId
                |    The identificator of the range on which the minimum/maximum should be read
                |      - if iRangeId is empty or equal to "Default", takes the default range as defined by the filter ("RibbonRadius" for FilletFilter, "MainDiameter" for HoleFilter)
                |      - else iRangeId should be chosen among:
                |            * {"RibbonRadius","RibbonAngle","RibbonLength"} for FilletFilter
                |            * {"MainDiameter"} for HoleFilter
                |            * any defined and supported range id in case of a user-defined filter
                |  
                | 
                |  Returns:
                |   oValue   The filter minimum/maximum value for the specified range if defined and active
                |    ELSE the method FAILS (to avoid this, getMinimumValueActivity/getMaximumValueActivity can be called prior to calling getMinimumValue/getMaximumValue)
                |    Signature with double works for angles as well as for lengthes / EXPRESSED in MODEL UNIT (mm/deg)
                |    Signatures with CATIALength or CATIAAngle must be used with care and will fail if the range nature and the expected type are incompatible

                |                | Examples:
                | The following example returns in theMinValue the minimum
                | value of filter myFilter for the range myRange: theMinValue
                | = myFilter.getMinimumValue(myRange) The following example
                | returns in theMinAngle the minimum value as an angle of
                | filter myFilter for the range myRange: Set theMinAngle =
                | myFilter.getMinimumAngle(myRange) The following example
                | returns in theMaxLength the maximum value as a length of
                | filter myFilter for the range myRange: Set theMaxLength =
                | myFilter.getMaximumLength(myRange)

        :param i_range_id:
        :return:
        """
        return self.defeaturing_filter_with_range.getMinimumValue(i_range_id)

    def set_maximum_activity(self, i_range_id, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | setMaximumActivity
                | o Sub setMaximumActivity(        iRangeId,
                |                                  iValue)
                | 
                |
                | Parameters:

                |
        :param i_range_id:
        :param i_value:
        :return:
        """
        return self.defeaturing_filter_with_range.setMaximumActivity(i_range_id, i_value)

    def set_maximum_value(self, i_range_id, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | setMaximumValue
                | o Sub setMaximumValue(        iRangeId,
                |                               iValue)
                | 
                |
                | Parameters:

                |
        :param i_range_id:
        :param i_value:
        :return:
        """
        return self.defeaturing_filter_with_range.setMaximumValue(i_range_id, i_value)

    def set_minimum_activity(self, i_range_id, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | setMinimumActivity
                | o Sub setMinimumActivity(        iRangeId,
                |                                  iValue)
                | 
                | Sets the defeaturing minimum or maximum value activity of
                | the filter for the given range id.
                |
                | Parameters:
                | iRangeId
                |    The identificator of the range on which the minimum/maximum should be read
                |      - if iRangeId is empty or equal to "Default", takes the default range as defined by the filter ("RibbonRadius" for FilletFilter, "MainDiameter" for HoleFilter)
                |      - else iRangeId should be chosen among:
                |            * {"RibbonRadius","RibbonAngle","RibbonLength"} for FilletFilter
                |            * {"MainDiameter"} for HoleFilter
                |            * any defined and supported range id in case of a user-defined filter
                |  
                |  iValue
                |    The filter minimum/maximum activity for the specified range

                |                | Examples:
                | The two following examples set theMaxActivity as the maximum
                | value activity of filter myFilter for the range myRange:
                | Call myFilter.setMaximumActivity(myRange,theMaxActivity)
                | myFilter.setMaximumActivity myRange theMaxActivity

        :param i_range_id:
        :param i_value:
        :return:
        """
        return self.defeaturing_filter_with_range.setMinimumActivity(i_range_id, i_value)

    def set_minimum_value(self, i_range_id, i_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | setMinimumValue
                | o Sub setMinimumValue(        iRangeId,
                |                               iValue)
                | 
                | Sets the minimum or maximum value of the filter for the
                | given range id. Forces the activation of the minimum or
                | maximum value if not the case yet.
                |
                | Parameters:
                | iRangeId
                |    The identificator of the range on which the minimum/maximum should be read
                |      - if iRangeId is empty or equal to "Default", takes the default range as defined by the filter ("RibbonRadius" for FilletFilter, "MainDiameter" for HoleFilter)
                |      - else iRangeId should be chosen among:
                |            * {"RibbonRadius","RibbonAngle","RibbonLength"} for FilletFilter
                |            * {"MainDiameter"} for HoleFilter
                |            * any defined and supported range id in case of a user-defined filter
                |  
                |  iValue
                |    The filter minimum/maximum value for the specified range / MUST BE EXPRESSED in MODEL UNIT (mm/deg)
                |    iValue must be consistent with the other value if defined and active
                |        - new minimum iValue must be smaller than existing active maximum value if any 
                |        - new maximum iValue must be larger than existing active minimum value if any 
                |    ELSE the method FAILS

                |                | Examples:
                | The two following examples set theMaxValue as the maximum
                | value of filter myFilter for the range myRange: Call
                | myFilter.setMaximumValue(myRange,theMaxValue)
                | myFilter.setMaximumValue myRange theMaxValue

        :param i_range_id:
        :param i_value:
        :return:
        """
        return self.defeaturing_filter_with_range.setMinimumValue(i_range_id, i_value)

    def __repr__(self):
        return f'DefeaturingFilterWithRange()'
