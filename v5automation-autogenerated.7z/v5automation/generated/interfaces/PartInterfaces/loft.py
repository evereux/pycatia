#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Loft(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Loft feature.Manipulation of solid Loft feature. Allows to access data
                | of the Loft feature created by the CATIAShapeFactory. This solid
                | feature is created from an underlying HybridShapeLoft aggregated by
                | the Loft.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.loft = com_object     

    @property
    def hybrid_shape(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HybridShape
                | o Property HybridShape(    ) As   (Read Only)
                | 
                | Gets the underlying HybridShapeLoft. Example: The following
                | example explains how to retrieve the underlying HybridShape
                | Loft Dim oHybridShape as AnyObject Set
                | oHybridShape=oLoft.HybridShape oHybridShape.SectionCoupling
                | = 2
                |

        :return:
        """
        return self.loft.HybridShape

    def __repr__(self):
        return f'Loft()'
