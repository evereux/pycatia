#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Shell(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the shell shape.A shell shape is made up of a list of faces
                | to process and two thickness parameters.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.shell = com_object     

    @property
    def external_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ExternalThickness
                | o Property ExternalThickness(    ) As   (Read Only)
                | 
                | Returns the shell external thickness. Example: The following
                | example returns in extThick the external thickness of the
                | shell firstShell: Set extThick =
                | firstShell.ExternalThickness
                |

        :return:
        """
        return self.shell.ExternalThickness

    @property
    def faces_to_remove(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FacesToRemove
                | o Property FacesToRemove(    ) As   (Read Only)
                | 
                | Returns the collection of faces to be removed by the shell
                | process. Example: The following example returns in list the
                | faces to be removed from the shell firstShell: Set list =
                | firstShell.FacesToRemove
                |

        :return:
        """
        return self.shell.FacesToRemove

    @property
    def internal_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InternalThickness
                | o Property InternalThickness(    ) As   (Read Only)
                | 
                | Returns the shell internal thickness. Example: The following
                | example returns in intThick the internal thickness of the
                | shell firstShell: Set intThick =
                | firstShell.InternalThickness
                |

        :return:
        """
        return self.shell.InternalThickness

    def add_face_to_remove(self, i_face_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceToRemove
                | o Sub AddFaceToRemove(        iFaceToRemove)
                | 
                | Adds a new face to those to be removed by the shell process.
                |
                | Parameters:
                | iFaceToRemove
                |    The face to be removed
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new face face to be removed
                | in the shell firstShell: call
                | firstShell.AddFaceToRemove(face)

        :param i_face_to_remove:
        :return:
        """
        return self.shell.AddFaceToRemove(i_face_to_remove)

    def add_face_with_different_thickness(self, i_face_to_thicken):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddFaceWithDifferentThickness
                | o Sub AddFaceWithDifferentThickness(        iFaceToThicken)
                | 
                | Adds a new face to be thicken with different offset values.
                |
                | Parameters:
                | iFaceToThicken
                |    The face to be thicken with different offset values
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new face face to be thicken
                | with different offset values in the shell firstShell: call
                | firstShell.AddFaceWithDifferentThickness(face)

        :param i_face_to_thicken:
        :return:
        """
        return self.shell.AddFaceWithDifferentThickness(i_face_to_thicken)

    def remove_face_with_different_thickness(self, i_face_to_remove):
        """
        .. note::
            CAA V5 Visual Basic help

                | RemoveFaceWithDifferentThickness
                | o Sub RemoveFaceWithDifferentThickness(        iFaceToRemove)
                | 
                | Removes an existing face from those to be thicken with
                | different offset values by the shell process.
                |
                | Parameters:
                | iFaceToRemove
                |    The face to be removed from the shell specifications
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example removes the face face from the list of
                | faces in the shell firstShell: call
                | firstShell.RemoveFaceWithDifferentThickness(face)

        :param i_face_to_remove:
        :return:
        """
        return self.shell.RemoveFaceWithDifferentThickness(i_face_to_remove)

    def set_volume_support(self, i_volume_support):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetVolumeSupport
                | o Sub SetVolumeSupport(        iVolumeSupport)
                | 
                | Set the Support Volume of the faces to modify during Shell
                | operation.
                |
                | Parameters:

                |
        :param i_volume_support:
        :return:
        """
        return self.shell.SetVolumeSupport(i_volume_support)

    def withdraw_face_to_remove(self, i_face_to_withdraw):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawFaceToRemove
                | o Sub WithdrawFaceToRemove(        iFaceToWithdraw)
                | 
                | Withdraws an existing face from those to be removed by the
                | shell process.
                |
                | Parameters:
                | iFaceToWithdraw
                |    The face to be withdrawn from the shell
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example removes the face face from the list of
                | faces in the shell firstShell: call
                | firstShell.WithdrawFaceToRemove(face)

        :param i_face_to_withdraw:
        :return:
        """
        return self.shell.WithdrawFaceToRemove(i_face_to_withdraw)

    def __repr__(self):
        return f'Shell()'
