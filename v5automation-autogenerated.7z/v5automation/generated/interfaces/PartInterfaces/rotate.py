#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Rotate(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the shape rotate feature object.This solid feature is
                | created from  an underlying HybridShapeRotate aggregated by the
                | Rotate.Role: To access the data of the hybrid shape rotate feature
                | object. This data includes:Use the CATIAShapeFactory to create
                | ShapeFeature object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.rotate = com_object     

    @property
    def angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Angle
                | o Property Angle(    ) As   (Read Only)
                | 
                | Returns the rotation angle.
                |

        :return:
        """
        return self.rotate.Angle

    @property
    def angle_value(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AngleValue
                | o Property AngleValue(    ) As
                | 
                | Returns or sets the rotation angle value. Example: This
                | example retrieves in AngleValue the angle value for the
                | Rotate hybrid shape feature. Dim AngleValue As double Set
                | AngleValue = Rotate.AngleValue
                |

        :return:
        """
        return self.rotate.AngleValue

    @angle_value.setter
    def angle_value(self, value):
        """
            :param type value:
        """
        self.rotate.AngleValue = value 

    @property
    def axis(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Axis
                | o Property Axis(    ) As
                | 
                | Returns or sets the rotation axis. To set the property, you
                | can use one of the following objects: , or . Example: This
                | example retrieves in RotationAxis the rotation axis for the
                | Rotate hybrid shape feature. Dim RotationAxis As Reference
                | Set RotationAxis = Rotate.Axis
                |

        :return:
        """
        return self.rotate.Axis

    @axis.setter
    def axis(self, value):
        """
            :param type value:
        """
        self.rotate.Axis = value 

    @property
    def hybrid_shape(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HybridShape
                | o Property HybridShape(    ) As   (Read Only)
                | 
                | Gets the underlying HybridShapeRotate. Example: The
                | following example explains how to retrieve the underlying
                | HybridShape Rotate Dim oHybridShape as AnyObject Set
                | oHybridShape=oRotate.HybridShape
                | oHybridShape.SectionCoupling = 2
                |

        :return:
        """
        return self.rotate.HybridShape

    def __repr__(self):
        return f'Rotate()'
