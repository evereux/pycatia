#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class ConstRadEdgeFillet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the edge fillet shape with a constant radius.The resulting
                | shape is made up of edge fillets built with a constant radius.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.const_rad_edge_fillet = com_object     

    @property
    def objects_to_fillet(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ObjectsToFillet
                | o Property ObjectsToFillet(    ) As   (Read Only)
                | 
                | Returns the collection of reference elements to be filleted.
                | Example: The following example returns in elements the
                | reference elements to be filleted of the constant radius
                | edge fillet firstCstEdgeFillet: Set elements =
                | firstCstEdgeFillet.ObjectsToFillet
                |

        :return:
        """
        return self.const_rad_edge_fillet.ObjectsToFillet

    @property
    def radius(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Radius
                | o Property Radius(    ) As   (Read Only)
                | 
                | Returns the edge fillet constant radius. Example: The
                | following example returns in radius the radius of the
                | constant radius edge fillet firstCstEdgeFillet: Set radius =
                | firstCstEdgeFillet.Radius
                |

        :return:
        """
        return self.const_rad_edge_fillet.Radius

    def add_object_to_fillet(self, i_object_to_fillet):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddObjectToFillet
                | o Sub AddObjectToFillet(        iObjectToFillet)
                | 
                | Adds a new sub-element to be filleted. This sub-element is
                | usually an edge.
                |
                | Parameters:
                | iObjectToFillet
                |    The sub-element to be filleted
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds a new geometrical element element
                | to be filleted by the constant radius edge fillet
                | firstCstEdgeFillet:
                | firstCstEdgeFillet.AddObjectToFillet(element)

        :param i_object_to_fillet:
        :return:
        """
        return self.const_rad_edge_fillet.AddObjectToFillet(i_object_to_fillet)

    def withdraw_object_to_fillet(self, i_object_to_withdraw):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawObjectToFillet
                | o Sub WithdrawObjectToFillet(        iObjectToWithdraw)
                | 
                | Withdraws a sub-element from those to be filleted. This sub-
                | element is usually an edge.
                |
                | Parameters:
                | iObjectToWithdraw
                |    The sub-element to withdraw
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws the geometrical element
                | element from those to be filleted by the constant radius
                | edge fillet firstCstEdgeFillet:
                | firstCstEdgeFillet.WithdrawObjectToFillet(element)

        :param i_object_to_withdraw:
        :return:
        """
        return self.const_rad_edge_fillet.WithdrawObjectToFillet(i_object_to_withdraw)

    def __repr__(self):
        return f'ConstRadEdgeFillet()'
