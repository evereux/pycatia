#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CircPattern(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the circular pattern.The shape is duplicated along
                | concentric circles to build crowns. A linear repartition object
                | defines the duplication along radial directions, thus determining the
                | number of crowns. An angular repartition object defines the
                | duplication on the crowns.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.circ_pattern = com_object     

    @property
    def angular_direction_row(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AngularDirectionRow
                | o Property AngularDirectionRow(    ) As   (Read Only)
                | 
                | Returns the position of the shape to be copied along the
                | angular direction. Example: The following example returns in
                | AngularDirPos the position of the shape to be copied along
                | the angular direction. Set AngularDirPos =
                | firstPattern.AngularDirectionRow
                |

        :return:
        """
        return self.circ_pattern.AngularDirectionRow

    @property
    def angular_repartition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AngularRepartition
                | o Property AngularRepartition(    ) As   (Read Only)
                | 
                | Returns the angular repartition. The angular repartition is
                | the repartition on a crown. Example: The following example
                | returns in repartA the angular repartition of the circular
                | pattern firstPattern: Set repartA =
                | firstPattern.AngularRepartition
                |

        :return:
        """
        return self.circ_pattern.AngularRepartition

    @property
    def circular_pattern_parameters(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CircularPatternParameters
                | o Property CircularPatternParameters(    ) As
                | 
                | Returns or sets the circular pattern parameters required to
                | define the pattern. These parameters are used when reading
                | the CATIAAngularRepartition properties. Example: The
                | following example returns in parameters the circular pattern
                | parameters of the firstPattern circular pattern, and then
                | sets it to catCompleteCrown, so that only the number of
                | instances is used to define the Pattern: Set parameters =
                | firstPattern.CircularPatternParameters Set
                | firstPattern.CircularPatternParameters = catCompleteCrown
                |

        :return:
        """
        return self.circ_pattern.CircularPatternParameters

    @circular_pattern_parameters.setter
    def circular_pattern_parameters(self, value):
        """
            :param type value:
        """
        self.circ_pattern.CircularPatternParameters = value 

    @property
    def radial_alignment(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RadialAlignment
                | o Property RadialAlignment(    ) As
                | 
                | Returns or sets whether the copied shapes should be rotated
                | or radial aligned with respect to the original one. True if
                | the copied shapes are rotated. Example: The following
                | example returns in alignedR the radial alignment of the
                | circular pattern firstPattern, and then sets it to False:
                | Set alignedR = firstPattern.RadialAlignment
                | firstPattern.RadialAlignment = False
                |

        :return:
        """
        return self.circ_pattern.RadialAlignment

    @radial_alignment.setter
    def radial_alignment(self, value):
        """
            :param type value:
        """
        self.circ_pattern.RadialAlignment = value 

    @property
    def radial_direction_row(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RadialDirectionRow
                | o Property RadialDirectionRow(    ) As   (Read Only)
                | 
                | Returns the position of the shape to be copied along the
                | radial direction. Example: The following example returns in
                | RadialDirPos the position of the shape to be copied along
                | the radial direction. Set RadialDirPos =
                | firstPattern.RadialDirectionRow
                |

        :return:
        """
        return self.circ_pattern.RadialDirectionRow

    @property
    def radial_repartition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RadialRepartition
                | o Property RadialRepartition(    ) As   (Read Only)
                | 
                | Returns the radial repartition. The radial repartition is
                | the repartition along a radius. Example: The following
                | example returns in repartR the radial repartition of the
                | circular pattern firstPattern: Set repartR =
                | firstPattern.RadialRepartition
                |

        :return:
        """
        return self.circ_pattern.RadialRepartition

    @property
    def rotation_orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RotationOrientation
                | o Property RotationOrientation(    ) As
                | 
                | Returns or sets whether the shapes are copied clockwise on
                | the crowns with respect to the rotation axis direction. True
                | if the shapes are copied counterclockwise when the rotation
                | axis direction goes towards you when you look at the crown.
                | Example: The following example returns in alignedAxis
                | whether the circular pattern firstPattern is built
                | clockwise, and then sets it to True: alignedAxis =
                | firstPattern.RotationOrientation
                | firstPattern.RotationOrientation = True
                |

        :return:
        """
        return self.circ_pattern.RotationOrientation

    @rotation_orientation.setter
    def rotation_orientation(self, value):
        """
            :param type value:
        """
        self.circ_pattern.RotationOrientation = value 

    def get_rotation_axis(self, io_rotation_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRotationAxis
                | o Sub GetRotationAxis(        ioRotationAxis)
                | 
                | Returns the rotation axis. The rotation axis is returned as
                | an array containing the rotation axis vector components.
                | Assume this array is oRotationAxis. It contains:
                | oRotationAxis[0],oRotationAxis[1],oRotationAxis[2] The X, Y,
                | and Z rotation axis vector components Example: The following
                | example returns in axisArray the rotation axis components of
                | the circular pattern firstPattern: Call
                | firstPattern.GetRotationAxis(axisArray) Set x = axisArray[0]
                | Set y = axisArray[1] Set z = axisArray[2]
                |
                | Parameters:

                |
        :param io_rotation_axis:
        :return:
        """
        return self.circ_pattern.GetRotationAxis(io_rotation_axis)

    def get_rotation_center(self, io_rotation_center):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRotationCenter
                | o Sub GetRotationCenter(        ioRotationCenter)
                | 
                | Returns the rotation center if the user defined it. Returns
                | E_FAIL if no rotation center has been defined The rotation
                | center is returned as an array containing the rotation
                | center coordinates. Assume this array is oRotationCenter. It
                | contains:
                | oRotationCenter[0],oRotationCenter[1],oRotationCenter[2] The
                | X, Y, and Z rotation center coordinates Example: The
                | following example returns in centerArray the rotation center
                | coordinates of the circular pattern firstPattern, and saves
                | them in variables: Call
                | firstPattern.GetRotationCenter(centerArray) x =
                | centerArray[0] y = centerArray[1] z = centerArray[2]
                |
                | Parameters:

                |
        :param io_rotation_center:
        :return:
        """
        return self.circ_pattern.GetRotationCenter(io_rotation_center)

    def set_instance_angular_spacing(self, i_instance_number, i_angular_spacing):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInstanceAngularSpacing
                | o Sub SetInstanceAngularSpacing(        iInstanceNumber,
                |                                         iAngularSpacing)
                | 
                | Sets the InstanceAngularSpacing.
                |
                | Parameters:
                | iInstanceNumber
                |    The Instance Number
                |  
                |  iAngularSpacing
                |    The Angular Spacing

                |                | Examples:
                | The following example sets the InstanceAngularSpacing of the
                | circular pattern

        :param i_instance_number:
        :param i_angular_spacing:
        :return:
        """
        return self.circ_pattern.SetInstanceAngularSpacing(i_instance_number, i_angular_spacing)

    def set_rotation_axis(self, i_rotation_axis):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRotationAxis
                | o Sub SetRotationAxis(        iRotationAxis)
                | 
                | Sets the rotation axis.
                |
                | Parameters:
                | iRotationAxis
                |    The rotation axis.
                |    It is passed as reference and can
                |    be valuated with a line, an edge or a plane reference: in this
                |    case the plane normal is taken into account.
                |  The following 
                | 
                |  objects are supported:  
                | , 
                | 
                |  and 
                | .

                |                | Examples:
                | The following example sets the rotation axis of the circular
                | pattern firstPattern with the refLine1 reference:
                | firstPattern.SetRotationAxis refLine1

        :param i_rotation_axis:
        :return:
        """
        return self.circ_pattern.SetRotationAxis(i_rotation_axis)

    def set_rotation_center(self, i_rotation_center):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRotationCenter
                | o Sub SetRotationCenter(        iRotationCenter)
                | 
                | Sets the rotation center.
                |
                | Parameters:
                | iRotationCenter
                |    The rotation center

                |                | Examples:
                | The following example sets the rotation center of the
                | circular pattern firstPattern with point1Ref point:
                | firstPattern.SetRotationCenter point1Ref

        :param i_rotation_center:
        :return:
        """
        return self.circ_pattern.SetRotationCenter(i_rotation_center)

    def set_unequal_instance_number(self, i_instance_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUnequalInstanceNumber
                | o Sub SetUnequalInstanceNumber(        iInstanceNumber)
                | 
                | Sets the Instance Number.
                |
                | Parameters:
                | iInstanceNumber
                |    The Instance Number

                |                | Examples:
                | The following example modifies the instance number for
                | unequal angular spacing

        :param i_instance_number:
        :return:
        """
        return self.circ_pattern.SetUnequalInstanceNumber(i_instance_number)

    def set_unequal_step(self, i_instance_number):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetUnequalStep
                | o Sub SetUnequalStep(        iInstanceNumber)
                | 
                | This method is deprecated Sets the UnequalStep.
                |
                | Parameters:
                | iInstanceNumber
                |    The Instance Number

                |                | Examples:
                | The following example creates the number of pattern spacing
                | objects in pattern object

        :param i_instance_number:
        :return:
        """
        return self.circ_pattern.SetUnequalStep(i_instance_number)

    def __repr__(self):
        return f'CircPattern()'
