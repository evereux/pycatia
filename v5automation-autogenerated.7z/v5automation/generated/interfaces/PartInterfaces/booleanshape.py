#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class BooleanShape(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the shapes based on boolean operations on other shapes.It
                | is the base object for add, assemble, intersect, remove, and split
                | shapes.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.boolean_shape = com_object     

    @property
    def body(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Body
                | o Property Body(    ) As   (Read Only)
                | 
                | Returns the inserted body.
                |

        :return:
        """
        return self.boolean_shape.Body

    def set_operated_object(self, i_reference_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOperatedObject
                | o Sub SetOperatedObject(        iReferenceObject)
                | 
                | Modifies the Second Operand. input object to replace with
                | Body or Volume
                |
                | Parameters:

                |
        :param i_reference_object:
        :return:
        """
        return self.boolean_shape.SetOperatedObject(i_reference_object)

    def set_operating_volume(self, i_reference_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOperatingVolume
                | o Sub SetOperatingVolume(        iReferenceObject)
                | 
                | Swaps the operands. Both the Operands must be Volume. This
                | is available only for Volume Add and Volume UnionTrim
                | Operations
                |
                | Parameters:

                |
        :param i_reference_object:
        :return:
        """
        return self.boolean_shape.SetOperatingVolume(i_reference_object)

    def __repr__(self):
        return f'BooleanShape()'
