#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Chamfer(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the chamfer shape.A chamfer is made up of a list of
                | geometrical elements to process, such as faces, and is defined using a
                | couple of parameters, such as two lengthes, or a length and an angle.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.chamfer = com_object     

    @property
    def angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Angle
                | o Property Angle(    ) As   (Read Only)
                | 
                | Returns the chamfer angle. This is valid only if the chamfer
                | is defined using a length and an angle, that is if the
                | chamfer definition mode is set to catLengthAngleChamfer.
                | Example: The following example returns in angle the angle of
                | the firstChamfer chamfer: Set angle = firstChamfer.Angle
                |

        :return:
        """
        return self.chamfer.Angle

    @property
    def elements_to_chamfer(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ElementsToChamfer
                | o Property ElementsToChamfer(    ) As   (Read Only)
                | 
                | Returns the collection of geometrical elements to be
                | chamfered. Example: The following example returns in list
                | the list of elements of the firstChamfer chamfer: Set list =
                | firstChamfer.ElementsToChamfer
                |

        :return:
        """
        return self.chamfer.ElementsToChamfer

    @property
    def length1(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Length1
                | o Property Length1(    ) As   (Read Only)
                | 
                | Returns the chamfer first length. This is the first length
                | if the chamfer is defined by two lengthes, or the chamfer if
                | the chamfer is defined by a length and an angle. Example:
                | The following example returns in length1 the first length of
                | the firstChamfer chamfer: Set length1 = firstChamfer.Length1
                |

        :return:
        """
        return self.chamfer.Length1

    @property
    def length2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Length2
                | o Property Length2(    ) As   (Read Only)
                | 
                | Returns the chamfer second length. This is valid only if the
                | chamfer is defined using two lengthes, that is if the
                | chamfer definition mode is set to catTwoLengthChamfer.
                | Example: The following example returns in length2 the second
                | length of the firstChamfer chamfer: Set length2 =
                | firstChamfer.Length2
                |

        :return:
        """
        return self.chamfer.Length2

    @property
    def mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Mode
                | o Property Mode(    ) As
                | 
                | Returns or sets the chamfer definition mode. The chamfer
                | definition mode enables the chamfer to be defined using
                | either two lengthes or a length and an angle. Example: The
                | following example returns in mode how the parameters of the
                | firstChamfer chamfer are defined, and then sets it to
                | catTwoLengthChamfer: Set mode = firstChamfer.Mode
                | firstChamfer.Mode = catTwoLengthChamfer
                |

        :return:
        """
        return self.chamfer.Mode

    @mode.setter
    def mode(self, value):
        """
            :param type value:
        """
        self.chamfer.Mode = value 

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property Orientation(    ) As
                | 
                | Returns or sets the chamfer orientation. Example: The
                | following example returns in orient the orientation mode of
                | the firstChamfer chamfer, and then sets it to
                | catReverseChamfer: Set orient = firstChamfer.Orientation
                | firstChamfer.Orientation = catReverseChamfer
                |

        :return:
        """
        return self.chamfer.Orientation

    @orientation.setter
    def orientation(self, value):
        """
            :param type value:
        """
        self.chamfer.Orientation = value 

    @property
    def propagation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Propagation
                | o Property Propagation(    ) As
                | 
                | Returns or sets the propagation mode of the geometrical
                | elements to be chamfered. Example: The following example
                | returns in prop the propagation mode of the firstChamfer
                | chamfer, and then sets it to catMinimalChamfer: Set prop =
                | firstChamfer.Propagation firstChamfer.Propagation =
                | catMinimalChamfer
                |

        :return:
        """
        return self.chamfer.Propagation

    @propagation.setter
    def propagation(self, value):
        """
            :param type value:
        """
        self.chamfer.Propagation = value 

    def add_element_to_chamfer(self, i_element_to_chamfer):
        """
        .. note::
            CAA V5 Visual Basic help

                | AddElementToChamfer
                | o Sub AddElementToChamfer(        iElementToChamfer)
                | 
                | Adds a new geometrical element to be chamfered.
                |
                | Parameters:
                | iElementToChamfer
                |    The new element to be chamfered
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example adds the new element element to be
                | chamfered for the firstChamfer chamfer:
                | firstChamfer.AddElementToChamfer(element)

        :param i_element_to_chamfer:
        :return:
        """
        return self.chamfer.AddElementToChamfer(i_element_to_chamfer)

    def withdraw_element_to_chamfer(self, i_element_to_withdraw):
        """
        .. note::
            CAA V5 Visual Basic help

                | WithdrawElementToChamfer
                | o Sub WithdrawElementToChamfer(        iElementToWithdraw)
                | 
                | Withdraws a geometrical element from those to be chamfered.
                |
                | Parameters:
                | iElementToWithdraw
                |    The existing element to withdraw
                |  The following 
                | 
                |  object is supported:  
                | .

                |                | Examples:
                | The following example withdraws an existing element element
                | to be chamfered from the firstChamfer chamfer:
                | firstChamfer.WithdrawElementToChamfer(element)

        :param i_element_to_withdraw:
        :return:
        """
        return self.chamfer.WithdrawElementToChamfer(i_element_to_withdraw)

    def __repr__(self):
        return f'Chamfer()'
