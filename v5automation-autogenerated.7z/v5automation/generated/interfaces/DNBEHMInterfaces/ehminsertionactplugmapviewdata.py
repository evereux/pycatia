#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class EHMInsertionActPlugMapViewData(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access Plug Map view data associated to an Insertion
                | activity.Role: Component that implement
                | DNBIAEHMInsertionActPlugMapViewData is DNBEHMModel.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.ehm_insertion_act_plug_map_view_data = com_object     

    @property
    def connector_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorName
                | o Property ConnectorName(    ) As   (Read Only)
                | 
                | Gets ConnectorName.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ConnectorName

    @property
    def connector_part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorPartNumber
                | o Property ConnectorPartNumber(    ) As   (Read Only)
                | 
                | Gets Connector Part Number.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ConnectorPartNumber

    @property
    def connector_ref_designator(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorRefDesignator
                | o Property ConnectorRefDesignator(    ) As   (Read Only)
                | 
                | Gets Connector Reference Designator.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ConnectorRefDesignator

    @property
    def connector_sub_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorSubType
                | o Property ConnectorSubType(    ) As   (Read Only)
                | 
                | Gets Connector Sub Type.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ConnectorSubType

    @property
    def connector_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ConnectorType
                | o Property ConnectorType(    ) As   (Read Only)
                | 
                | Gets Connector Type.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ConnectorType

    @property
    def contact_elec_barrel_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactElecBarrelDiameter
                | o Property ContactElecBarrelDiameter(    ) As   (Read Only)
                | 
                | Gets Contact Elec Barrel Diameter.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ContactElecBarrelDiameter

    @property
    def contact_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactName
                | o Property ContactName(    ) As   (Read Only)
                | 
                | Gets Contact Name.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ContactName

    @property
    def contact_part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactPartNumber
                | o Property ContactPartNumber(    ) As   (Read Only)
                | 
                | Gets Contact Part Number.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ContactPartNumber

    @property
    def contact_ref_designator(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactRefDesignator
                | o Property ContactRefDesignator(    ) As   (Read Only)
                | 
                | Gets Contact Reference Designator.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ContactRefDesignator

    @property
    def contact_sub_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactSubType
                | o Property ContactSubType(    ) As   (Read Only)
                | 
                | Gets Contact Sub Type.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ContactSubType

    @property
    def contact_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ContactType
                | o Property ContactType(    ) As   (Read Only)
                | 
                | Gets Contact Type.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.ContactType

    @property
    def num_inserted_wires(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | NumInsertedWires
                | o Property NumInsertedWires(    ) As   (Read Only)
                | 
                | Gets the number of inserted wires.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.NumInsertedWires

    @property
    def termination_id_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationIDNumber
                | o Property TerminationIDNumber(    ) As   (Read Only)
                | 
                | Gets Termination ID Number.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.TerminationIDNumber

    @property
    def termination_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationName
                | o Property TerminationName(    ) As   (Read Only)
                | 
                | Gets Termination Name.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.TerminationName

    @property
    def termination_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationNumber
                | o Property TerminationNumber(    ) As   (Read Only)
                | 
                | Gets Termination Number.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.TerminationNumber

    @property
    def termination_ref_designator(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationRefDesignator
                | o Property TerminationRefDesignator(    ) As   (Read Only)
                | 
                | Gets Termination Reference Designator.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.TerminationRefDesignator

    @property
    def termination_sub_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationSubType
                | o Property TerminationSubType(    ) As   (Read Only)
                | 
                | Gets Termination Sub Type.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.TerminationSubType

    @property
    def termination_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TerminationType
                | o Property TerminationType(    ) As   (Read Only)
                | 
                | Gets Termination Type.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.TerminationType

    @property
    def wire_color(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireColor
                | o Property WireColor(    ) As   (Read Only)
                | 
                | Gets Wire Color.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireColor

    @property
    def wire_diameter(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireDiameter
                | o Property WireDiameter(    ) As   (Read Only)
                | 
                | Gets Wire Diameter.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireDiameter

    @property
    def wire_id(self, i_wire_id):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireID
                | o Property WireID(        iWireID) (Write Only)
                | 
                | Sets the index of wire.
                |

        :param i_wire_id:
        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireID

    @property
    def wire_length(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireLength
                | o Property WireLength(    ) As   (Read Only)
                | 
                | Gets Wire Length.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireLength

    @property
    def wire_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireName
                | o Property WireName(    ) As   (Read Only)
                | 
                | Gets Wire Name.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireName

    @property
    def wire_part_number(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WirePartNumber
                | o Property WirePartNumber(    ) As   (Read Only)
                | 
                | Gets Wire Part Number.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WirePartNumber

    @property
    def wire_ref_designator(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireRefDesignator
                | o Property WireRefDesignator(    ) As   (Read Only)
                | 
                | Gets Wire Reference Designator.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireRefDesignator

    @property
    def wire_separation_code(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireSeparationCode
                | o Property WireSeparationCode(    ) As   (Read Only)
                | 
                | Gets Wire Separation Code.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireSeparationCode

    @property
    def wire_signal_id(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireSignalID
                | o Property WireSignalID(    ) As   (Read Only)
                | 
                | Gets Wire Signal ID.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireSignalID

    @property
    def wire_sub_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireSubType
                | o Property WireSubType(    ) As   (Read Only)
                | 
                | Gets Wire Sub Type.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireSubType

    @property
    def wire_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | WireType
                | o Property WireType(    ) As   (Read Only)
                | 
                | Gets Wire Type.
                |

        :return:
        """
        return self.ehm_insertion_act_plug_map_view_data.WireType

    def __repr__(self):
        return f'EHMInsertionActPlugMapViewData()'
