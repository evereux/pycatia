#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Layout2DView(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Layout2D View.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.layout2_d_view = com_object     

    @property
    def angle(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Angle
                | o Property Angle(    ) As
                | 
                | Returns or sets the angle of the Layout2D view. The angle is
                | measured between the axis system of the Layout2D view and
                | the axis system of the Layout2D sheet where the Layout2D
                | view lies. The angle is measured in radians and is counted
                | counterclockwise. Example: This example sets the angle of
                | the MyView Layout2D view to 90 degrees clockwise. You first
                | need to compute the angle in radians and set the minus sign
                | to indicate the rotation is clockwise. PI = 3.1415926535
                | Angle90Clockwise = -PI/2 MyView.Angle = Angle90Clockwise
                |

        :return:
        """
        return self.layout2_d_view.Angle

    @angle.setter
    def angle(self, value):
        """
            :param type value:
        """
        self.layout2_d_view.Angle = value 

    @property
    def arrows(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Arrows
                | o Property Arrows(    ) As   (Read Only)
                | 
                | Returns the drawing arrow collection of the Layout2D view.
                | Example: This example retrieves in ArrowCollection the
                | collection of arrows of the MyView Layout2D view. Dim
                | ArrowCollection As DrawingArrows Set ArrowCollection =
                | MyView.Arrows
                |

        :return:
        """
        return self.layout2_d_view.Arrows

    @property
    def components(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Components
                | o Property Components(    ) As   (Read Only)
                | 
                | Returns the Layout2D component instances collection (i.e.
                | ditto collection) of the Layout2D view. Example: This
                | example retrieves in ComponentCollection the collection of
                | component instances of the MyView Layout2D view. Dim
                | ComponentCollection As DrawingComponents Set
                | ComponentCollection = MyView.Components
                |

        :return:
        """
        return self.layout2_d_view.Components

    @property
    def dimensions(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Dimensions
                | o Property Dimensions(    ) As   (Read Only)
                | 
                | Returns the drawing dimension collection of the Layout2D
                | view. Example: This example retrieves in DimensionCollection
                | the collection of dimensions of the MyView Layout2D view.
                | Dim DimensionCollection As DrawingDimensions Set
                | DimensionCollection = MyView.Dimensions
                |

        :return:
        """
        return self.layout2_d_view.Dimensions

    @property
    def factory2_d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Factory2D
                | o Property Factory2D(    ) As   (Read Only)
                | 
                | Returns the 2D factory of the Layout2D view. Take care that
                | you must open edition on a sketch before adding or modifying
                | elements in it. Take care that you must close edition on a
                | sketch to keep all modifications before saving document. To
                | get Sketch from factory2D: Set mySketch =
                | my2DFactory.GetParent Example: The following example returns
                | in my2DFactory the 2D factory of the view myView: Set
                | my2DFactory = myView.Factory2D
                |

        :return:
        """
        return self.layout2_d_view.Factory2D

    @property
    def frame_visualization(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FrameVisualization
                | o Property FrameVisualization(    ) As
                | 
                | Returns or sets the Layout2D view frame visualization state.
                | True if the Layout2D view frame is visible. Example: This
                | example shows the frame of the MyView Layout2D view.
                | MyView.FrameVisualization = True
                |

        :return:
        """
        return self.layout2_d_view.FrameVisualization

    @frame_visualization.setter
    def frame_visualization(self, value):
        """
            :param type value:
        """
        self.layout2_d_view.FrameVisualization = value 

    @property
    def geometric_elements(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GeometricElements
                | o Property GeometricElements(    ) As   (Read Only)
                | 
                | Returns the collection of geometric elements included in the
                | Layout2D view sketch. Example: The following example returns
                | in colGeometry the list of geometric elements in the view
                | myView: Dim colGeometry As GeometricElements Set colGeometry
                | = MyView.GeometricElements
                |

        :return:
        """
        return self.layout2_d_view.GeometricElements

    @property
    def lock_status(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LockStatus
                | o Property LockStatus(    ) As
                | 
                | Returns or sets the lock status of a Layout2D view.
                | precondition: This property does not exist for the detail
                | view. In this case, the method returns failed. Example: This
                | example locks the ViewToWorkOn Layout2D view.
                | ViewToWorkOn.LockStatus = True
                |

        :return:
        """
        return self.layout2_d_view.LockStatus

    @lock_status.setter
    def lock_status(self, value):
        """
            :param type value:
        """
        self.layout2_d_view.LockStatus = value 

    @property
    def pictures(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Pictures
                | o Property Pictures(    ) As   (Read Only)
                | 
                | Returns the drawing picture collection of the Layout2D view.
                | Example: This example retrieves in PictureCollection the
                | collection of pictures of the MyView Layout2D view. Dim
                | PictureCollection As DrawingPictures Set PictureCollection =
                | MyView.Pictures
                |

        :return:
        """
        return self.layout2_d_view.Pictures

    @property
    def reference_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ReferenceView
                | o Property ReferenceView(    ) As
                | 
                | Returns or sets the reference view. The reference view is
                | also the parent view to which the current Layout2D view is
                | linked and which is used as reference for alignment.
                | Generally, the reference view is the front view, and the
                | other views, such as the top, bottom, left, and right views,
                | are linked to it. This reference Layout2D view is used: When
                | moving the current Layout2D view. Its location remains
                | constrained to the reference view, depending on its type.
                | For example, a left view can move horizontally and a top
                | view can move vertically. To update the scale of the current
                | Layout2D view according to the modification performed to the
                | one of the reference Layout2D view. Example: This example
                | retrieves in ReferenceView the view used as reference by the
                | MyView Layout2D view. Dim ReferenceView As Layout2DView Set
                | ReferenceView = MyView.RefView
                |

        :return:
        """
        return self.layout2_d_view.ReferenceView

    @reference_view.setter
    def reference_view(self, value):
        """
            :param type value:
        """
        self.layout2_d_view.ReferenceView = value 

    @property
    def tables(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Tables
                | o Property Tables(    ) As   (Read Only)
                | 
                | Returns the drawing table collection of the drawing view.
                | Example: This example retrieves in TextCollection the
                | collection of texts of the MyView Layout2D view. Dim
                | TableCollection As DrawingTables Set TableCollection =
                | MyView.Tables
                |

        :return:
        """
        return self.layout2_d_view.Tables

    @property
    def texts(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Texts
                | o Property Texts(    ) As   (Read Only)
                | 
                | Returns the drawing text collection of the Layout2D view.
                | Example: This example retrieves in TextCollection the
                | collection of texts of the MyView Layout2D view. Dim
                | TextCollection As DrawingTexts Set TextCollection =
                | MyView.Texts
                |

        :return:
        """
        return self.layout2_d_view.Texts

    @property
    def threads(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Threads
                | o Property Threads(    ) As   (Read Only)
                | 
                | Returns the drawing thread collection of the Layout2D view.
                | Example: This example retrieves in ThreadCollection the
                | collection of threads of the MyView Layout2D view. Dim
                | ThreadCollection As DrawingThreads Set ThreadCollection =
                | MyView.Threads
                |

        :return:
        """
        return self.layout2_d_view.Threads

    @property
    def view_scale(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewScale
                | o Property ViewScale(    ) As
                | 
                | Returns or sets the scale of the Layout2D view. Example:
                | This example sets the scale of the MyView Layout2D view to
                | 0.5. MyView.Scale = 0.5
                |

        :return:
        """
        return self.layout2_d_view.ViewScale

    @view_scale.setter
    def view_scale(self, value):
        """
            :param type value:
        """
        self.layout2_d_view.ViewScale = value 

    @property
    def visu2_d_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Visu2DMode
                | o Property Visu2DMode(    ) As
                | 
                | Sets/Gets the 2D mode for background visualization of the
                | view. See also: Example: This example shows how to switch on
                | the background 2D mode View1.Visu2DMode =
                | catView2DModeNoShow
                |

        :return:
        """
        return self.layout2_d_view.Visu2DMode

    @property
    def visu_background(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuBackground
                | o Property VisuBackground(    ) As
                | 
                | Sets/Gets the 2D-3D background visu mode of the view ie in
                | the 3D windows and in the background of each view in every
                | 2D context. See also: Example: This example shows how to set
                | the background to LowInt View1.VisuBackground =
                | catLowIntPick
                |

        :return:
        """
        return self.layout2_d_view.VisuBackground

    @property
    def visu_in_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuIn3D
                | o Property VisuIn3D(    ) As
                | 
                | Sets/Gets the 3D visualization mode of the view in the 3D
                | Viewer ie in the 3D windows and in the background of each
                | view in every 2D context. See also: Example: This example
                | shows how to make the View1 Layout2D view visible in 3D
                | View1.HideIn3DSize = catShowAll
                |

        :return:
        """
        return self.layout2_d_view.VisuIn3D

    @property
    def weldings(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Weldings
                | o Property Weldings(    ) As   (Read Only)
                | 
                | Returns the drawing welding collection of the Layout2D view.
                | Example: This example retrieves in weldingCollection the
                | collection of weldings of the MyView Layout2D view. Dim
                | weldingCollection As DrawingWeldings Set weldingCollection =
                | MyView.Weldings
                |

        :return:
        """
        return self.layout2_d_view.Weldings

    @property
    def x(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | x
                | o Property x(    ) As
                | 
                | Returns or sets the x coordinate of the Layout2D view
                | coordinate system origin. It is expressed with respect to
                | the sheet coordinate system. This coordinate, like any
                | length, is measured in millimeters. Example: This example
                | retrieves the x coordinate of the coordinate system origin
                | of the MyView. X = MyView.x
                |

        :return:
        """
        return self.layout2_d_view.x

    @x.setter
    def x(self, value):
        """
            :param type value:
        """
        self.layout2_d_view.x = value 

    @property
    def y(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | y
                | o Property y(    ) As
                | 
                | Returns or sets the y coordinate of the Layout2D view
                | coordinate system origin. It is expressed with respect to
                | the sheet coordinate system. This coordinate, like any
                | length, is measured in millimeters. Example: This example
                | sets the y coordinate of the coordinate system origin of the
                | MyView to 5 inches. You need first to convert the 5 inches
                | into millimeters. NewYCoordinate = 5*25.4 MyView.y =
                | NewYCoordinate
                |

        :return:
        """
        return self.layout2_d_view.y

    @y.setter
    def y(self, value):
        """
            :param type value:
        """
        self.layout2_d_view.y = value 

    def activate(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activate
                | o Sub Activate(    )
                | 
                | Activates the Layout2D view. Activating a Layout2D view
                | means that this Layout2D view is the one on which the end-
                | user is now working. Example: This example activates the
                | ViewToWorkOn Layout2D view. ViewToWorkOn.Activate()
                |
                | Parameters:

                |
        :return:
        """
        return self.layout2_d_view.Activate()

    def aligned_with_reference_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AlignedWithReferenceView
                | o Sub AlignedWithReferenceView(    )
                | 
                | Activates the alignment with the reference view. Activating
                | the alignment with the reference view restores the
                | constraints that the reference view imposes to the current
                | Layout2D view. Example: This example activates the alignment
                | from the MyView Layout2D view to its reference view.
                | MyView.AlignedWithReferenceView()
                |
                | Parameters:

                |
        :return:
        """
        return self.layout2_d_view.AlignedWithReferenceView()

    def get_view_name(self, i_view_name_prefix, i_view_name_ident, i_view_name_suffix):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewName
                | o Sub GetViewName(        iViewNamePrefix,
                |                           iViewNameIdent,
                |                           iViewNameSuffix)
                | 
                | Returns the prefix, the ident and the suffix of the name of
                | the Layout2D view. The method returns an error in case of 2D
                | component reference. Do not confuse with the method Name
                | which can be different. Example: This example gets the
                | prefix, the ident, and the suffix of the name of the MyView
                | Layout2D view Dim MyPrefix, MyIdent, MySuffix As CATBSTR
                | MyView.GetViewName (MyPrefix, MyIdent, MySuffix)
                |
                | Parameters:

                |
        :param i_view_name_prefix:
        :param i_view_name_ident:
        :param i_view_name_suffix:
        :return:
        """
        return self.layout2_d_view.GetViewName(i_view_name_prefix, i_view_name_ident, i_view_name_suffix)

    def save_edition(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveEdition
                | o Sub SaveEdition(    )
                | 
                | Saves the Sketch Edition. Once you have finished working
                | with the Layout2D view, you must save its edition in order
                | to register modification for UNDO/REDO. Indeed when
                | activating a view, this view is open in edition while the
                | previous active view is closed in edition. So calling
                | SaveEdition() before exiting a macro without changing active
                | view will allow a correct UNDO/REDO behavior. Example: The
                | following example saves the edition of the Layout2D view
                | MyView: MyView.SaveEdition
                |
                | Parameters:

                |
        :return:
        """
        return self.layout2_d_view.SaveEdition()

    def set_view_name(self, i_view_name_prefix, i_view_name_ident, i_view_name_suffix):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewName
                | o Sub SetViewName(        iViewNamePrefix,
                |                           iViewNameIdent,
                |                           iViewNameSuffix)
                | 
                | Sets the prefix, the ident and the suffix of the name of the
                | Layout2D view. The method returns an error in case of 2D
                | component reference. Do not confuse with the method Name
                | which can be different. Example: This example sets the
                | prefix, the ident, and the suffix of the name of the MyView
                | Layout2D view respectively to "MyPrefix", "MyIdent", and
                | "MySuffix". MyView.SetViewName ("MyPrefix", "MyIdent",
                | "MySuffix")
                |
                | Parameters:

                |
        :param i_view_name_prefix:
        :param i_view_name_ident:
        :param i_view_name_suffix:
        :return:
        """
        return self.layout2_d_view.SetViewName(i_view_name_prefix, i_view_name_ident, i_view_name_suffix)

    def size(self, o_values):
        """
        .. note::
            CAA V5 Visual Basic help

                | Size
                | o Sub Size(        oValues)
                | 
                | Returns the bounding box of the Layout2D view. Warning: This
                | method is not implemented.
                |
                | Parameters:
                | oValues
                |    The values of the view bounding box: Xmin, Xmax, Ymin, Ymax

                |                | Examples:
                | This example gets the bounding box of the ViewToWorkOn
                | Layout2D view. Dim oXY(4) As Double ViewToWorkOn.Size oXY
                | Xmin = oXY(0) Xmax = oXY(1) Ymin = oXY(2) Ymax = oXY(3)

        :param o_values:
        :return:
        """
        return self.layout2_d_view.Size(o_values)

    def un_aligned_with_reference_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | UnAlignedWithReferenceView
                | o Sub UnAlignedWithReferenceView(    )
                | 
                | Deactivates the alignment with the reference view.
                | Deactivating the alignment to the reference view removes the
                | constraints that the reference view imposes to the current
                | Layout2D view. You can then, for example, move and position
                | it freely. Example: This example deactivates the alignment
                | from the MyView Layout2D view to its reference view.
                | MyView.UnAlignedWithReferenceView()
                |
                | Parameters:

                |
        :return:
        """
        return self.layout2_d_view.UnAlignedWithReferenceView()

    def __repr__(self):
        return f'Layout2DView()'
