#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Layout2DSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a CATIA2DLSettingAtt.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.layout2_d_setting_att = com_object     

    @property
    def activate2_d_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activate2DMode
                | o Property Activate2DMode(    ) As
                | 
                | Returns the Activate2DMode parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.Activate2DMode

    @property
    def back_clipping_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | BackClippingPlane
                | o Property BackClippingPlane(    ) As
                | 
                | Returns the BackClippingPlane parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.BackClippingPlane

    @property
    def boundaries2_dl_display(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Boundaries2DLDisplay
                | o Property Boundaries2DLDisplay(    ) As
                | 
                | Returns the Boundaries2DLDisplay parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.Boundaries2DLDisplay

    @property
    def boundaries2_dl_line_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Boundaries2DLLineType
                | o Property Boundaries2DLLineType(    ) As
                | 
                | Returns the Boundaries2DLLineType parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.Boundaries2DLLineType

    @property
    def boundaries2_dl_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Boundaries2DLThickness
                | o Property Boundaries2DLThickness(    ) As
                | 
                | Returns the Boundaries2DLThickness parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.Boundaries2DLThickness

    @property
    def callout_creation_dialog_box(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CalloutCreationDialogBox
                | o Property CalloutCreationDialogBox(    ) As
                | 
                | Returns the CalloutCreationDialogBox parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.CalloutCreationDialogBox

    @property
    def callout_creation_in_active_view(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CalloutCreationInActiveView
                | o Property CalloutCreationInActiveView(    ) As
                | 
                | Returns the CalloutCreationInActiveView parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.CalloutCreationInActiveView

    @property
    def clipping_frame(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingFrame
                | o Property ClippingFrame(    ) As
                | 
                | Returns the ClippingFrame parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.ClippingFrame

    @property
    def clipping_frame_reframe_on_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingFrameReframeOnMode
                | o Property ClippingFrameReframeOnMode(    ) As
                | 
                | Returns the ClippingFrameReframeOnMode parameter.
                | Deprecated: V5R18
                |

        :return:
        """
        return self.layout2_d_setting_att.ClippingFrameReframeOnMode

    @property
    def clipping_view_outline_linetype(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingViewOutlineLinetype
                | o Property ClippingViewOutlineLinetype(    ) As
                | 
                | Returns the ClippingViewOutlineLinetype parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.ClippingViewOutlineLinetype

    @property
    def clipping_view_outline_thickness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ClippingViewOutlineThickness
                | o Property ClippingViewOutlineThickness(    ) As
                | 
                | Returns the ClippingViewOutlineThickness parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.ClippingViewOutlineThickness

    @property
    def create_associative_use_edges(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | CreateAssociativeUseEdges
                | o Property CreateAssociativeUseEdges(    ) As
                | 
                | Returns the CreateAssociativeUseEdges parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.CreateAssociativeUseEdges

    @property
    def dedicated_filter_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DedicatedFilterType
                | o Property DedicatedFilterType(    ) As
                | 
                | Returns the DedicatedFilterType parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.DedicatedFilterType

    @property
    def display_back_and_cutting_plane(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayBackAndCuttingPlane
                | o Property DisplayBackAndCuttingPlane(    ) As
                | 
                | Returns the DisplayBackAndCuttingPlane parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.DisplayBackAndCuttingPlane

    @property
    def display_clipping_outline(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisplayClippingOutline
                | o Property DisplayClippingOutline(    ) As
                | 
                | Returns the DisplayClippingOutline parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.DisplayClippingOutline

    @property
    def edit_dedicated_filter_dialog_box(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | EditDedicatedFilterDialogBox
                | o Property EditDedicatedFilterDialogBox(    ) As
                | 
                | Returns the EditDedicatedFilterDialogBox parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.EditDedicatedFilterDialogBox

    @property
    def fit_all_in_sheet_format(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | FitAllInSheetFormat
                | o Property FitAllInSheetFormat(    ) As
                | 
                | Returns the FitAllInSheetFormat parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.FitAllInSheetFormat

    @property
    def hide_in_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | HideIn3D
                | o Property HideIn3D(    ) As
                | 
                | Returns the HideIn3D parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.HideIn3D

    @property
    def insure_filter_names_uniqueness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InsureFilterNamesUniqueness
                | o Property InsureFilterNamesUniqueness(    ) As
                | 
                | Returns the InsureFilterNamesUniqueness attribute value to
                | apply to a Layout at its creation parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.InsureFilterNamesUniqueness

    @property
    def insure_sheet_names_uniqueness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InsureSheetNamesUniqueness
                | o Property InsureSheetNamesUniqueness(    ) As
                | 
                | Returns the InsureSheetNamesUniqueness attribute value to
                | apply to a Layout at its creation parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.InsureSheetNamesUniqueness

    @property
    def insure_view_names_uniqueness(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InsureViewNamesUniqueness
                | o Property InsureViewNamesUniqueness(    ) As
                | 
                | Returns the InsureViewNamesUniqueness attribute value to
                | apply to a Layout at its creation parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.InsureViewNamesUniqueness

    @property
    def insure_view_names_uniqueness_scope(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | InsureViewNamesUniquenessScope
                | o Property InsureViewNamesUniquenessScope(    ) As
                | 
                | Returns the InsureViewNamesUniquenessScope parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.InsureViewNamesUniquenessScope

    @property
    def layout_default_render_style(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LayoutDefaultRenderStyle
                | o Property LayoutDefaultRenderStyle(    ) As
                | 
                | Returns the default render style attribute value to apply to
                | a Layout at its creation parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.LayoutDefaultRenderStyle

    @property
    def propagate_highlight(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PropagateHighlight
                | o Property PropagateHighlight(    ) As
                | 
                | Returns the PropagateHighlight parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.PropagateHighlight

    @property
    def tile_layout_window(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | TileLayoutWindow
                | o Property TileLayoutWindow(    ) As
                | 
                | Returns the tile of Layout window parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.TileLayoutWindow

    @property
    def view_background_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewBackgroundMode
                | o Property ViewBackgroundMode(    ) As
                | 
                | Returns the ViewBackgroundMode parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.ViewBackgroundMode

    @property
    def view_filter_creation_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ViewFilterCreationMode
                | o Property ViewFilterCreationMode(    ) As
                | 
                | Returns the ViewFilterCreationMode parameter.
                |

        :return:
        """
        return self.layout2_d_setting_att.ViewFilterCreationMode

    def get_activate2_d_mode_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetActivate2DModeInfo
                | o Sub GetActivate2DModeInfo(        ioAdminLevel,
                |                                     ioLocked,
                |                                     oModified)
                | 
                | Retrieves environment informations for the Activate2DMode
                | parameter. Role:Retrieves the state of the Activate2DMode
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetActivate2DModeInfo(io_admin_level, io_locked, o_modified)

    def get_back_clipping_plane_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBackClippingPlaneInfo
                | o Sub GetBackClippingPlaneInfo(        ioAdminLevel,
                |                                        ioLocked,
                |                                        oModified)
                | 
                | Retrieves environment informations for the BackClippingPlane
                | parameter. Role:Retrieves the state of the BackClippingPlane
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetBackClippingPlaneInfo(io_admin_level, io_locked, o_modified)

    def get_boundaries2_dl_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLColor
                | o Sub GetBoundaries2DLColor(        oValueR,
                |                                     oValueG,
                |                                     oValueB)
                | 
                | Returns the Boundaries2DLColor parameter.
                |
                | Parameters:

                |
        :param o_value_r:
        :param o_value_g:
        :param o_value_b:
        :return:
        """
        return self.layout2_d_setting_att.GetBoundaries2DLColor(o_value_r, o_value_g, o_value_b)

    def get_boundaries2_dl_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLColorInfo
                | o Sub GetBoundaries2DLColorInfo(        ioAdminLevel,
                |                                         ioLocked,
                |                                         oModified)
                | 
                | Retrieves environment informations for the
                | Boundaries2DLColor parameter. Role:Retrieves the state of
                | the Boundaries2DLColor parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetBoundaries2DLColorInfo(io_admin_level, io_locked, o_modified)

    def get_boundaries2_dl_display_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLDisplayInfo
                | o Sub GetBoundaries2DLDisplayInfo(        ioAdminLevel,
                |                                           ioLocked,
                |                                           oModified)
                | 
                | Retrieves environment informations for the
                | Boundaries2DLDisplay parameter. Role:Retrieves the state of
                | the Boundaries2DLDisplay parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetBoundaries2DLDisplayInfo(io_admin_level, io_locked, o_modified)

    def get_boundaries2_dl_line_type_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLLineTypeInfo
                | o Sub GetBoundaries2DLLineTypeInfo(        ioAdminLevel,
                |                                            ioLocked,
                |                                            oModified)
                | 
                | Retrieves environment informations for the
                | Boundaries2DLLineType parameter. Role:Retrieves the state of
                | the Boundaries2DLLineType parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetBoundaries2DLLineTypeInfo(io_admin_level, io_locked, o_modified)

    def get_boundaries2_dl_thickness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBoundaries2DLThicknessInfo
                | o Sub GetBoundaries2DLThicknessInfo(        ioAdminLevel,
                |                                             ioLocked,
                |                                             oModified)
                | 
                | Retrieves environment informations for the
                | Boundaries2DLThickness parameter. Role:Retrieves the state
                | of the Boundaries2DLThickness parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetBoundaries2DLThicknessInfo(io_admin_level, io_locked, o_modified)

    def get_callout_creation_dialog_box_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCalloutCreationDialogBoxInfo
                | o Sub GetCalloutCreationDialogBoxInfo(        ioAdminLevel,
                |                                               ioLocked,
                |                                               oModified)
                | 
                | Retrieves environment informations for the
                | CalloutCreationDialogBox parameter. Role:Retrieves the state
                | of the CalloutCreationDialogBox parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetCalloutCreationDialogBoxInfo(io_admin_level, io_locked, o_modified)

    def get_callout_creation_in_active_view_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCalloutCreationInActiveViewInfo
                | o Sub GetCalloutCreationInActiveViewInfo(        ioAdminLevel,
                |                                                  ioLocked,
                |                                                  oModified)
                | 
                | Retrieves environment informations for the
                | CalloutCreationInActiveView parameter. Role:Retrieves the
                | state of the CalloutCreationInActiveView parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetCalloutCreationInActiveViewInfo(io_admin_level, io_locked, o_modified)

    def get_clipping_frame_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingFrameInfo
                | o Sub GetClippingFrameInfo(        ioAdminLevel,
                |                                    ioLocked,
                |                                    oModified)
                | 
                | Retrieves environment informations for the ClippingFrame
                | parameter. Role:Retrieves the state of the ClippingFrame
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetClippingFrameInfo(io_admin_level, io_locked, o_modified)

    def get_clipping_frame_reframe_on_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingFrameReframeOnModeInfo
                | o Func GetClippingFrameReframeOnModeInfo(        ioAdminLevel,
                |                                                  ioLocked) As
                | 
                | Deprecated: V5R18 Retrieves environment informations for the
                | ClippingFrameReframeOnMode parameter. Role:Retrieves the
                | state of the ClippingFrameReframeOnMode parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.layout2_d_setting_att.GetClippingFrameReframeOnModeInfo(io_admin_level, io_locked)

    def get_clipping_view_outline_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingViewOutlineColor
                | o Sub GetClippingViewOutlineColor(        oValueR,
                |                                           oValueG,
                |                                           oValueB)
                | 
                | Returns the ClippingViewOutlineColor parameter.
                |
                | Parameters:

                |
        :param o_value_r:
        :param o_value_g:
        :param o_value_b:
        :return:
        """
        return self.layout2_d_setting_att.GetClippingViewOutlineColor(o_value_r, o_value_g, o_value_b)

    def get_clipping_view_outline_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingViewOutlineColorInfo
                | o Sub GetClippingViewOutlineColorInfo(        ioAdminLevel,
                |                                               ioLocked,
                |                                               oModified)
                | 
                | Retrieves environment informations for the
                | ClippingViewOutlineColor parameter. Role:Retrieves the state
                | of the ClippingViewOutlineColor parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetClippingViewOutlineColorInfo(io_admin_level, io_locked, o_modified)

    def get_clipping_view_outline_linetype_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingViewOutlineLinetypeInfo
                | o Sub GetClippingViewOutlineLinetypeInfo(        ioAdminLevel,
                |                                                  ioLocked,
                |                                                  oModified)
                | 
                | Retrieves environment informations for the
                | ClippingViewOutlineLinetype parameter. Role:Retrieves the
                | state of the ClippingViewOutlineLinetype parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetClippingViewOutlineLinetypeInfo(io_admin_level, io_locked, o_modified)

    def get_clipping_view_outline_thickness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetClippingViewOutlineThicknessInfo
                | o Sub GetClippingViewOutlineThicknessInfo(        ioAdminLevel,
                |                                                   ioLocked,
                |                                                   oModified)
                | 
                | Retrieves environment informations for the
                | ClippingViewOutlineThickness parameter. Role:Retrieves the
                | state of the ClippingViewOutlineThickness parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetClippingViewOutlineThicknessInfo(io_admin_level, io_locked, o_modified)

    def get_create_associative_use_edges_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetCreateAssociativeUseEdgesInfo
                | o Sub GetCreateAssociativeUseEdgesInfo(        ioAdminLevel,
                |                                                ioLocked,
                |                                                oModified)
                | 
                | Retrieves environment informations for the
                | CreateAssociativeUseEdges parameter. Role:Retrieves the
                | state of the CreateAssociativeUseEdges parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetCreateAssociativeUseEdgesInfo(io_admin_level, io_locked, o_modified)

    def get_dedicated_filter_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDedicatedFilterTypeInfo
                | o Func GetDedicatedFilterTypeInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves environment informations for the
                | DedicatedFilterType parameter. Role:Retrieves the state of
                | the DedicatedFilterType parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.layout2_d_setting_att.GetDedicatedFilterTypeInfo(io_admin_level, io_locked)

    def get_display_back_and_cutting_plane_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayBackAndCuttingPlaneInfo
                | o Sub GetDisplayBackAndCuttingPlaneInfo(        ioAdminLevel,
                |                                                 ioLocked,
                |                                                 oModified)
                | 
                | Retrieves environment informations for the
                | DisplayBackAndCuttingPlane parameter. Role:Retrieves the
                | state of the DisplayBackAndCuttingPlane parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetDisplayBackAndCuttingPlaneInfo(io_admin_level, io_locked, o_modified)

    def get_display_clipping_outline_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisplayClippingOutlineInfo
                | o Sub GetDisplayClippingOutlineInfo(        ioAdminLevel,
                |                                             ioLocked,
                |                                             oModified)
                | 
                | Retrieves environment informations for the
                | DisplayClippingOutline parameter. Role:Retrieves the state
                | of the DisplayClippingOutline parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetDisplayClippingOutlineInfo(io_admin_level, io_locked, o_modified)

    def get_edit_dedicated_filter_dialog_box_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetEditDedicatedFilterDialogBoxInfo
                | o Sub GetEditDedicatedFilterDialogBoxInfo(        ioAdminLevel,
                |                                                   ioLocked,
                |                                                   oModified)
                | 
                | Retrieves environment informations for the
                | EditDedicatedFilterDialogBox parameter. Role:Retrieves the
                | state of the EditDedicatedFilterDialogBox parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetEditDedicatedFilterDialogBoxInfo(io_admin_level, io_locked, o_modified)

    def get_fit_all_in_sheet_format_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetFitAllInSheetFormatInfo
                | o Sub GetFitAllInSheetFormatInfo(        ioAdminLevel,
                |                                          ioLocked,
                |                                          oModified)
                | 
                | Retrieves environment informations for the
                | FitAllInSheetFormat parameter. Role:Retrieves the state of
                | the FitAllInSheetFormat parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetFitAllInSheetFormatInfo(io_admin_level, io_locked, o_modified)

    def get_hide_in_3d_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetHideIn3DInfo
                | o Sub GetHideIn3DInfo(        ioAdminLevel,
                |                               ioLocked,
                |                               oModified)
                | 
                | Retrieves environment informations for the HideIn3D
                | parameter. Role:Retrieves the state of the HideIn3D
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetHideIn3DInfo(io_admin_level, io_locked, o_modified)

    def get_insure_filter_names_uniqueness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetInsureFilterNamesUniquenessInfo
                | o Sub GetInsureFilterNamesUniquenessInfo(        ioAdminLevel,
                |                                                  ioLocked,
                |                                                  oModified)
                | 
                | Retrieves environment informations for the
                | InsureFilterNamesUniqueness parameter. Role:Retrieves the
                | state of the InsureFilterNamesUniqueness parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetInsureFilterNamesUniquenessInfo(io_admin_level, io_locked, o_modified)

    def get_insure_sheet_names_uniqueness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetInsureSheetNamesUniquenessInfo
                | o Sub GetInsureSheetNamesUniquenessInfo(        ioAdminLevel,
                |                                                 ioLocked,
                |                                                 oModified)
                | 
                | Retrieves environment informations for the
                | InsureSheetNamesUniqueness parameter. Role:Retrieves the
                | state of the InsureSheetNamesUniqueness parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetInsureSheetNamesUniquenessInfo(io_admin_level, io_locked, o_modified)

    def get_insure_view_names_uniqueness_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetInsureViewNamesUniquenessInfo
                | o Sub GetInsureViewNamesUniquenessInfo(        ioAdminLevel,
                |                                                ioLocked,
                |                                                oModified)
                | 
                | Retrieves environment informations for the
                | InsureViewNamesUniqueness parameter. Role:Retrieves the
                | state of the InsureViewNamesUniqueness parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetInsureViewNamesUniquenessInfo(io_admin_level, io_locked, o_modified)

    def get_insure_view_names_uniqueness_scope_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetInsureViewNamesUniquenessScopeInfo
                | o Func GetInsureViewNamesUniquenessScopeInfo(        ioAdminLevel,
                |                                                      ioLocked) As
                | 
                | Retrieves environment informations for the
                | InsureViewNamesUniquenessScope parameter. Role:Retrieves the
                | state of the InsureViewNamesUniquenessScope parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.layout2_d_setting_att.GetInsureViewNamesUniquenessScopeInfo(io_admin_level, io_locked)

    def get_layout_default_render_style_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLayoutDefaultRenderStyleInfo
                | o Sub GetLayoutDefaultRenderStyleInfo(        ioAdminLevel,
                |                                               ioLocked,
                |                                               oModified)
                | 
                | Retrieves environment informations for the default render
                | style parameter. Role:Retrieves the state of the default
                | render style parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetLayoutDefaultRenderStyleInfo(io_admin_level, io_locked, o_modified)

    def get_propagate_highlight_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPropagateHighlightInfo
                | o Sub GetPropagateHighlightInfo(        ioAdminLevel,
                |                                         ioLocked,
                |                                         oModified)
                | 
                | Retrieves environment informations for the
                | PropagateHighlight parameter. Role:Retrieves the state of
                | the PropagateHighlight parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetPropagateHighlightInfo(io_admin_level, io_locked, o_modified)

    def get_protected_elements_color(self, o_value_r, o_value_g, o_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProtectedElementsColor
                | o Sub GetProtectedElementsColor(        oValueR,
                |                                         oValueG,
                |                                         oValueB)
                | 
                | Returns the ProtectedElementsColor parameter.
                |
                | Parameters:

                |
        :param o_value_r:
        :param o_value_g:
        :param o_value_b:
        :return:
        """
        return self.layout2_d_setting_att.GetProtectedElementsColor(o_value_r, o_value_g, o_value_b)

    def get_protected_elements_color_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProtectedElementsColorInfo
                | o Sub GetProtectedElementsColorInfo(        ioAdminLevel,
                |                                             ioLocked,
                |                                             oModified)
                | 
                | Retrieves environment informations for the
                | ProtectedElementsColor parameter. Role:Retrieves the state
                | of the ProtectedElementsColor parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetProtectedElementsColorInfo(io_admin_level, io_locked, o_modified)

    def get_tile_layout_window_info(self, io_admin_level, io_locked, o_modified):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTileLayoutWindowInfo
                | o Sub GetTileLayoutWindowInfo(        ioAdminLevel,
                |                                       ioLocked,
                |                                       oModified)
                | 
                | Retrieves environment informations for the tile of Layout
                | window parameter. Role:Retrieves the state of the tile of
                | Layout window parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :param o_modified:
        :return:
        """
        return self.layout2_d_setting_att.GetTileLayoutWindowInfo(io_admin_level, io_locked, o_modified)

    def get_view_background_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewBackgroundModeInfo
                | o Func GetViewBackgroundModeInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | ViewBackgroundMode parameter. Role:Retrieves the state of
                | the ViewBackgroundMode parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.layout2_d_setting_att.GetViewBackgroundModeInfo(io_admin_level, io_locked)

    def get_view_filter_creation_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetViewFilterCreationModeInfo
                | o Func GetViewFilterCreationModeInfo(        ioAdminLevel,
                |                                              ioLocked) As
                | 
                | Retrieves environment informations for the
                | ViewFilterCreationMode parameter. Role:Retrieves the state
                | of the ViewFilterCreationMode parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.layout2_d_setting_att.GetViewFilterCreationModeInfo(io_admin_level, io_locked)

    def set_activate2_d_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetActivate2DModeLock
                | o Sub SetActivate2DModeLock(        iLocked)
                | 
                | Locks or unlocks the Activate2DMode parameter. Role:Locks or
                | unlocks the Activate2DMode parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetActivate2DModeLock(i_locked)

    def set_back_clipping_plane_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBackClippingPlaneLock
                | o Sub SetBackClippingPlaneLock(        iLocked)
                | 
                | Locks or unlocks the BackClippingPlane parameter. Role:Locks
                | or unlocks the BackClippingPlane parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetBackClippingPlaneLock(i_locked)

    def set_boundaries2_dl_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLColor
                | o Sub SetBoundaries2DLColor(        iValueR,
                |                                     iValueG,
                |                                     iValueB)
                | 
                | Sets the Boundaries2DLColor parameter.
                |
                | Parameters:

                |
        :param i_value_r:
        :param i_value_g:
        :param i_value_b:
        :return:
        """
        return self.layout2_d_setting_att.SetBoundaries2DLColor(i_value_r, i_value_g, i_value_b)

    def set_boundaries2_dl_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLColorLock
                | o Sub SetBoundaries2DLColorLock(        iLocked)
                | 
                | Locks or unlocks the Boundaries2DLColor parameter.
                | Role:Locks or unlocks the Boundaries2DLColor parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetBoundaries2DLColorLock(i_locked)

    def set_boundaries2_dl_display_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLDisplayLock
                | o Sub SetBoundaries2DLDisplayLock(        iLocked)
                | 
                | Locks or unlocks the Boundaries2DLDisplay parameter.
                | Role:Locks or unlocks the Boundaries2DLDisplay parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetBoundaries2DLDisplayLock(i_locked)

    def set_boundaries2_dl_line_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLLineTypeLock
                | o Sub SetBoundaries2DLLineTypeLock(        iLocked)
                | 
                | Locks or unlocks the Boundaries2DLLineType parameter.
                | Role:Locks or unlocks the Boundaries2DLLineType parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetBoundaries2DLLineTypeLock(i_locked)

    def set_boundaries2_dl_thickness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBoundaries2DLThicknessLock
                | o Sub SetBoundaries2DLThicknessLock(        iLocked)
                | 
                | Locks or unlocks the Boundaries2DLThickness parameter.
                | Role:Locks or unlocks the Boundaries2DLThickness parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetBoundaries2DLThicknessLock(i_locked)

    def set_callout_creation_dialog_box_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCalloutCreationDialogBoxLock
                | o Sub SetCalloutCreationDialogBoxLock(        iLocked)
                | 
                | Locks or unlocks the CalloutCreationDialogBox parameter.
                | Role:Locks or unlocks the CalloutCreationDialogBox parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetCalloutCreationDialogBoxLock(i_locked)

    def set_callout_creation_in_active_view_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCalloutCreationInActiveViewLock
                | o Sub SetCalloutCreationInActiveViewLock(        iLocked)
                | 
                | Locks or unlocks the CalloutCreationInActiveView parameter.
                | Role:Locks or unlocks the CalloutCreationInActiveView
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetCalloutCreationInActiveViewLock(i_locked)

    def set_clipping_frame_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingFrameLock
                | o Sub SetClippingFrameLock(        iLocked)
                | 
                | Locks or unlocks the ClippingFrame parameter. Role:Locks or
                | unlocks the ClippingFrame parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetClippingFrameLock(i_locked)

    def set_clipping_frame_reframe_on_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingFrameReframeOnModeLock
                | o Sub SetClippingFrameReframeOnModeLock(        iLocked)
                | 
                | Deprecated: V5R18 Locks or unlocks the
                | ClippingFrameReframeOnMode parameter. Role:Locks or unlocks
                | the ClippingFrameReframeOnMode parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetClippingFrameReframeOnModeLock(i_locked)

    def set_clipping_view_outline_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingViewOutlineColor
                | o Sub SetClippingViewOutlineColor(        iValueR,
                |                                           iValueG,
                |                                           iValueB)
                | 
                | Sets the ClippingViewOutlineColor parameter.
                |
                | Parameters:

                |
        :param i_value_r:
        :param i_value_g:
        :param i_value_b:
        :return:
        """
        return self.layout2_d_setting_att.SetClippingViewOutlineColor(i_value_r, i_value_g, i_value_b)

    def set_clipping_view_outline_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingViewOutlineColorLock
                | o Sub SetClippingViewOutlineColorLock(        iLocked)
                | 
                | Locks or unlocks the ClippingViewOutlineColor parameter.
                | Role:Locks or unlocks the ClippingViewOutlineColor parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetClippingViewOutlineColorLock(i_locked)

    def set_clipping_view_outline_linetype_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingViewOutlineLinetypeLock
                | o Sub SetClippingViewOutlineLinetypeLock(        iLocked)
                | 
                | Locks or unlocks the ClippingViewOutlineLinetype parameter.
                | Role:Locks or unlocks the ClippingViewOutlineLinetype
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetClippingViewOutlineLinetypeLock(i_locked)

    def set_clipping_view_outline_thickness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetClippingViewOutlineThicknessLock
                | o Sub SetClippingViewOutlineThicknessLock(        iLocked)
                | 
                | Locks or unlocks the ClippingViewOutlineThickness parameter.
                | Role:Locks or unlocks the ClippingViewOutlineThickness
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetClippingViewOutlineThicknessLock(i_locked)

    def set_create_associative_use_edges_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetCreateAssociativeUseEdgesLock
                | o Sub SetCreateAssociativeUseEdgesLock(        iLocked)
                | 
                | Locks or unlocks the CreateAssociativeUseEdges parameter.
                | Role:Locks or unlocks the CreateAssociativeUseEdges
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetCreateAssociativeUseEdgesLock(i_locked)

    def set_dedicated_filter_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDedicatedFilterTypeLock
                | o Sub SetDedicatedFilterTypeLock(        iLocked)
                | 
                | Locks or unlocks the DedicatedFilterType parameter.
                | Role:Locks or unlocks the DedicatedFilterType parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetDedicatedFilterTypeLock(i_locked)

    def set_display_back_and_cutting_plane_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayBackAndCuttingPlaneLock
                | o Sub SetDisplayBackAndCuttingPlaneLock(        iLocked)
                | 
                | Locks or unlocks the DisplayBackAndCuttingPlane parameter.
                | Role:Locks or unlocks the DisplayBackAndCuttingPlane
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetDisplayBackAndCuttingPlaneLock(i_locked)

    def set_display_clipping_outline_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisplayClippingOutlineLock
                | o Sub SetDisplayClippingOutlineLock(        iLocked)
                | 
                | Locks or unlocks the DisplayClippingOutline parameter.
                | Role:Locks or unlocks the DisplayClippingOutline parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetDisplayClippingOutlineLock(i_locked)

    def set_edit_dedicated_filter_dialog_box_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetEditDedicatedFilterDialogBoxLock
                | o Sub SetEditDedicatedFilterDialogBoxLock(        iLocked)
                | 
                | Locks or unlocks the EditDedicatedFilterDialogBox parameter.
                | Role:Locks or unlocks the EditDedicatedFilterDialogBox
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetEditDedicatedFilterDialogBoxLock(i_locked)

    def set_fit_all_in_sheet_format_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetFitAllInSheetFormatLock
                | o Sub SetFitAllInSheetFormatLock(        iLocked)
                | 
                | Locks or unlocks the FitAllInSheetFormat parameter.
                | Role:Locks or unlocks the FitAllInSheetFormat parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetFitAllInSheetFormatLock(i_locked)

    def set_hide_in_3d_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetHideIn3DLock
                | o Sub SetHideIn3DLock(        iLocked)
                | 
                | Locks or unlocks the HideIn3D parameter. Role:Locks or
                | unlocks the HideIn3D parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetHideIn3DLock(i_locked)

    def set_insure_filter_names_uniqueness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInsureFilterNamesUniquenessLock
                | o Sub SetInsureFilterNamesUniquenessLock(        iLocked)
                | 
                | Locks or unlocks the InsureFilterNamesUniqueness parameter.
                | Role:Locks or unlocks the InsureFilterNamesUniqueness if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetInsureFilterNamesUniquenessLock(i_locked)

    def set_insure_sheet_names_uniqueness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInsureSheetNamesUniquenessLock
                | o Sub SetInsureSheetNamesUniquenessLock(        iLocked)
                | 
                | Locks or unlocks the InsureSheetNamesUniqueness parameter.
                | Role:Locks or unlocks the InsureSheetNamesUniqueness
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetInsureSheetNamesUniquenessLock(i_locked)

    def set_insure_view_names_uniqueness_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInsureViewNamesUniquenessLock
                | o Sub SetInsureViewNamesUniquenessLock(        iLocked)
                | 
                | Locks or unlocks InsureViewNamesUniqueness parameter.
                | Role:Locks or unlocks the InsureViewNamesUniqueness
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetInsureViewNamesUniquenessLock(i_locked)

    def set_insure_view_names_uniqueness_scope_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetInsureViewNamesUniquenessScopeLock
                | o Sub SetInsureViewNamesUniquenessScopeLock(        iLocked)
                | 
                | Locks or unlocks the InsureViewNamesUniquenessScope
                | parameter. Role:Locks or unlocks the
                | InsureViewNamesUniquenessScope parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetInsureViewNamesUniquenessScopeLock(i_locked)

    def set_layout_default_render_style_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLayoutDefaultRenderStyleLock
                | o Sub SetLayoutDefaultRenderStyleLock(        iLocked)
                | 
                | Locks or unlocks the default render style parameter.
                | Role:Locks or unlocks the default render style parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetLayoutDefaultRenderStyleLock(i_locked)

    def set_propagate_highlight_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPropagateHighlightLock
                | o Sub SetPropagateHighlightLock(        iLocked)
                | 
                | Locks or unlocks the PropagateHighlight parameter.
                | Role:Locks or unlocks the PropagateHighlight parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetPropagateHighlightLock(i_locked)

    def set_protected_elements_color(self, i_value_r, i_value_g, i_value_b):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProtectedElementsColor
                | o Sub SetProtectedElementsColor(        iValueR,
                |                                         iValueG,
                |                                         iValueB)
                | 
                | Sets the ProtectedElementsColor parameter.
                |
                | Parameters:

                |
        :param i_value_r:
        :param i_value_g:
        :param i_value_b:
        :return:
        """
        return self.layout2_d_setting_att.SetProtectedElementsColor(i_value_r, i_value_g, i_value_b)

    def set_protected_elements_color_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProtectedElementsColorLock
                | o Sub SetProtectedElementsColorLock(        iLocked)
                | 
                | Locks or unlocks the ProtectedElementsColor parameter.
                | Role:Locks or unlocks the ProtectedElementsColor parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetProtectedElementsColorLock(i_locked)

    def set_tile_layout_window_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetTileLayoutWindowLock
                | o Sub SetTileLayoutWindowLock(        iLocked)
                | 
                | Locks or unlocks the tile of Layout window parameter.
                | Role:Locks or unlocks the tile of Layout window parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetTileLayoutWindowLock(i_locked)

    def set_view_background_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewBackgroundModeLock
                | o Sub SetViewBackgroundModeLock(        iLocked)
                | 
                | Locks or unlocks the ViewBackgroundMode parameter.
                | Role:Locks or unlocks the ViewBackgroundMode parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetViewBackgroundModeLock(i_locked)

    def set_view_filter_creation_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetViewFilterCreationModeLock
                | o Sub SetViewFilterCreationModeLock(        iLocked)
                | 
                | Locks or unlocks the ViewFilterCreationMode parameter.
                | Role:Locks or unlocks the ViewFilterCreationMode parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.layout2_d_setting_att.SetViewFilterCreationModeLock(i_locked)

    def __repr__(self):
        return f'Layout2DSettingAtt()'
