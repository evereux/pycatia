#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Layout2DSheet(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | The interface to access a Layout2D Sheet.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.layout2_d_sheet = com_object     

    @property
    def orientation(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Orientation
                | o Property Orientation(    ) As
                | 
                | Returns or sets the paper orientation. Example: This example
                | sets the paper orientation for the MySheet Layout2D sheet to
                | catPaperLandscape. MySheet.Orientation = catPaperLandscape
                |

        :return:
        """
        return self.layout2_d_sheet.Orientation

    @orientation.setter
    def orientation(self, value):
        """
            :param type value:
        """
        self.layout2_d_sheet.Orientation = value 

    @property
    def page_setup(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PageSetup
                | o Property PageSetup(    ) As   (Read Only)
                | 
                | Returns the page setup. Example: This example returns the
                | page setup for the MySheet Layout2D sheet. Dim
                | MySheetPageSetup As DrawingPageSetup Set MySheetPageSetup =
                | MySheet.PageSetup
                |

        :return:
        """
        return self.layout2_d_sheet.PageSetup

    @property
    def paper_height(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperHeight
                | o Property PaperHeight(    ) As
                | 
                | Gets or Sets the paper width of the layout sheet.
                |
                | Examples:
                | This example get the height of the Layout2DSheet1.
                | Layout2DSheet1.GetPaperHeight oPaperHeight

        :return:
        """
        return self.layout2_d_sheet.PaperHeight

    @property
    def paper_name(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperName
                | o Property PaperName(    ) As
                | 
                | Returns or sets the paper format name. Example: This example
                | sets the paper format name for the MySheet Layout2D sheet to
                | DSFormat1. MySheet.PaperName = DSFormat1
                |

        :return:
        """
        return self.layout2_d_sheet.PaperName

    @paper_name.setter
    def paper_name(self, value):
        """
            :param type value:
        """
        self.layout2_d_sheet.PaperName = value 

    @property
    def paper_size(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperSize
                | o Property PaperSize(    ) As
                | 
                | Returns or sets the paper size. Example: This example sets
                | the page size for the MySheet Layout2D sheet to catPaperA4.
                | MySheet.PaperSize = catPaperA4
                |

        :return:
        """
        return self.layout2_d_sheet.PaperSize

    @paper_size.setter
    def paper_size(self, value):
        """
            :param type value:
        """
        self.layout2_d_sheet.PaperSize = value 

    @property
    def paper_width(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PaperWidth
                | o Property PaperWidth(    ) As
                | 
                | Gets or Sets the paper width of the layout sheet.
                |
                | Examples:
                | This example get the width of the Sheet1.
                | Sheet1.GetPaperWidth oPaperWidth

        :return:
        """
        return self.layout2_d_sheet.PaperWidth

    @property
    def print_area(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintArea
                | o Property PrintArea(    ) As   (Read Only)
                | 
                | Returns the print area definition object. Example: This
                | example returns the print area for the MySheet Layout2D
                | sheet 2DL. Dim MyPrintArea As PrintArea Set MyPrintArea =
                | MySheet.PrintArea
                |

        :return:
        """
        return self.layout2_d_sheet.PrintArea

    @property
    def projection_method(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProjectionMethod
                | o Property ProjectionMethod(    ) As
                | 
                | Returns or sets the sheet projection mode . Example: This
                | example sets the projection mode of the MySheet Layout2D
                | sheet to catFirstAngle. MySheet.ProjectionMethod =
                | catFirstAngle
                |

        :return:
        """
        return self.layout2_d_sheet.ProjectionMethod

    @projection_method.setter
    def projection_method(self, value):
        """
            :param type value:
        """
        self.layout2_d_sheet.ProjectionMethod = value 

    @property
    def sheet_scale(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SheetScale
                | o Property SheetScale(    ) As
                | 
                | Returns or sets the scale of the Layout2D sheet. Example:
                | This example sets the scale of the MySheet Layout2D sheet to
                | 0.5. MySheet.SheetScale = 0.5
                |

        :return:
        """
        return self.layout2_d_sheet.SheetScale

    @sheet_scale.setter
    def sheet_scale(self, value):
        """
            :param type value:
        """
        self.layout2_d_sheet.SheetScale = value 

    @property
    def views(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Views
                | o Property Views(    ) As   (Read Only)
                | 
                | Returns the Layout2D view collection of the Layout2D sheet.
                | Example: This example retrieves in ViewCollection the
                | collection of views 2DL of the MySheet Layout2D sheet. Dim
                | ViewCollection As Layout2DViews Set ViewCollection =
                | MySheet.Views.
                |

        :return:
        """
        return self.layout2_d_sheet.Views

    @property
    def visu_in_3d(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | VisuIn3D
                | o Property VisuIn3D(    ) As
                | 
                | Set/Get the 3D visualization mode of the sheet in the 3D
                | Viewer ie in the 3D windows and in the background of each
                | view in every 2D context. See also:
                |

        :return:
        """
        return self.layout2_d_sheet.VisuIn3D

    def activate(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Activate
                | o Sub Activate(    )
                | 
                | Activates the Layout2D sheet. Activating a Layout2D sheet
                | means that this Layout2D sheet is the one on which the end
                | user is now working. The window in the application's window
                | collection which contains this Layout2D sheet becomes the
                | active one. Example: This example activates the MySheet
                | layout2dsheet. MySheet.Activate
                |
                | Parameters:

                |
        :return:
        """
        return self.layout2_d_sheet.Activate()

    def is_detail(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IsDetail
                | o Func IsDetail(    ) As
                | 
                | Checks whether the sheet is a detail sheet. TRUE if the
                | sheet is a detail sheet. Example: This example checks
                | whether MySheet is a detail sheet. IsDetail =
                | MySheet.IsDetail
                |
                | Parameters:

                |
        :return:
        """
        return self.layout2_d_sheet.IsDetail()

    def print_out(self, i_rendering_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintOut
                | o Sub PrintOut(        iRenderingMode)
                | 
                | Prints the Layout2D sheet according to its page setup on the
                | default printer.
                |
                | Parameters:
                | iRenderingMode
                |    The rendering mode to use for the backgrounds of the views in the sheet.

                |                | Examples:
                | This example prints the Layout2DSheet1 on the default
                | printer. Layout2DSheet1.PrintOut catRenderShadingWithEdges

        :param i_rendering_mode:
        :return:
        """
        return self.layout2_d_sheet.PrintOut(i_rendering_mode)

    def print_out2(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintOut2
                | o Sub PrintOut2(    )
                | 
                | Prints the Layout2D sheet according to its page setup on the
                | default printer. If a rendering mode has been stored on the
                | 2D Layout, it is used during print process for the
                | backgrounds. Otherwise, "Shading with edges" rendering mode
                | is used. Example: This example prints the Layout2DSheet1 on
                | the default printer. Layout2DSheet1.PrintOut2
                |
                | Parameters:

                |
        :return:
        """
        return self.layout2_d_sheet.PrintOut2()

    def print_to_file(self, file_name, i_rendering_mode):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintToFile
                | o Sub PrintToFile(        fileName,
                |                           iRenderingMode)
                | 
                | Prints the Layout2D sheet according its page setup in a file
                | instead of being sent to a printer.
                |
                | Parameters:
                | fileName
                |    The full pathname of the file receiving the data.
                |  
                |  iRenderingMode
                |    The rendering mode to use for the backgrounds of the views in the sheet.

                |                | Examples:
                | This example prints the Layout2DSheet1 in a file.
                | Layout2DSheet1.PrintToFile
                | "e:\temp\sheet1.prn",catRenderShadingWithEdges

        :param file_name:
        :param i_rendering_mode:
        :return:
        """
        return self.layout2_d_sheet.PrintToFile(file_name, i_rendering_mode)

    def print_to_file2(self, file_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrintToFile2
                | o Sub PrintToFile2(        fileName)
                | 
                | Prints the Layout2D sheet according its page setup in a file
                | instead of being sent to a printer. If a rendering mode has
                | been stored on the 2D Layout, it is used during print
                | process for the backgrounds. Otherwise, "Shading with edges"
                | rendering mode is used.
                |
                | Parameters:
                | fileName
                |  The full pathname of the file receiving the data.

                |                | Examples:
                | This example prints the Layout2DSheet1 in a file.
                | Layout2DSheet1.PrintToFile2 "e:\temp\sheet1.prn"

        :param file_name:
        :return:
        """
        return self.layout2_d_sheet.PrintToFile2(file_name)

    def reorder__views(self, i_ordered_views):
        """
        .. note::
            CAA V5 Visual Basic help

                | reorder_Views
                | o Sub reorder_Views(        iOrderedViews)
                | 
                | Changes the positions of the views in this sheet according
                | to the given ordered list. iOrderedViews is the result of a
                | permutation applied to the list of all the views of this
                | sheet with the following constraint: the two first elements
                | of the list must be respectively the sheet's mainview and
                | background view. Example: This example modifies the views
                | order of a sheet made of a mainview, a backgroundview and
                | two user-created views. (user-created views are inverted).
                | Set drw = CATIA.ActiveDocument.Part.GetItem("CATLayoutRoot")
                | Set drwviewsorder = drwsheetsorder.Sheets.ActiveSheet Set
                | drwviews = drwviewsorder.Views Set mainview =
                | drwviews.item(1) Set backview = drwviews.item(2) Set view1 =
                | drwviews.item(3) Set view2 = drwviews.item(4) newvieworder =
                | Array(mainview, backview, view2, view1)
                | drwviewsorder.reorder_Views(newvieworder)
                |
                | Parameters:

                |
        :param i_ordered_views:
        :return:
        """
        return self.layout2_d_sheet.reorder_Views(i_ordered_views)

    def __repr__(self):
        return f'Layout2DSheet()'
