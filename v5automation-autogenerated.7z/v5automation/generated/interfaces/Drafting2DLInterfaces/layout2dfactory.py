#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class Layout2DFactory(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help


    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.layout2_d_factory = com_object     

    def create2_d_layout(self, i_standard_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | Create2DLayout
                | o Func Create2DLayout(        iStandardName) As
                | 
                | Create the 2DLayout associated to the 3D mechanical feature
                | tha implement this interface. E.g. a Mechanical Part.
                |
                | Parameters:
                | CATBSTR
                |  iStandardName The standard name to apply to the new layout.
                |  
                |  oLayout
                |  The created 2DLayout. This feature is unique for a given 3D context feature. Consequently
                |  requesting this interface on a 3D feature that is already associated to a 2DLayout
                |  feature will fail. You must first request for any existing 2DLayout via 
                |  
                | 
                |  method using CATLayoutRoot key parameter to check for 2DLayout pre-existing feature as follow :
                | 
                |  Dim MyRoot As Layout2DRoot
                |  Set MyRoot = CATIA.ActiveDocument.Part.GetItem("CATLayoutRoot")
                |  if MyRoot Is Nothing then
                |    Dim MyRootFact As Layout2DFactory
                |    Set MyRootFact = CATIA.ActiveDocument.Part.GetItem("CATLayoutRootFactory")
                |    Set MyRoot = MyRootFact.Create2DLayout("ISO_3D")
                |  end if

                |
        :param i_standard_name:
        :return:
        """
        return self.layout2_d_factory.Create2DLayout(i_standard_name)

    def __repr__(self):
        return f'Layout2DFactory()'
