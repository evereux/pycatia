#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class CatViewSide(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | CatViewSide is used in conjonction with a reference View2DL and a
                | ViewBox.It then determines precisely a View2DL type in the ViewBox.
                | example: with the default ViewBox:  - Front + TopSide  = Top.  - Right
                | + LeftSide = Front.  - Front + TRCorner = isometric on the corner near
                | Front, Right, Top.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.cat_view_side = com_object     

    def __repr__(self):
        return f'CatViewSide()'
