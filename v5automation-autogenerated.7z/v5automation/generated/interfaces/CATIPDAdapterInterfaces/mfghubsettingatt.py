#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class MfgHubSettingAtt(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Represents the Manufacturing Hub setting controller object.Role: The
                | HubSettingAtt1 setting controller object deals with the setting
                | attributes displayed in the PPR Hub property page. To access this
                | property page:The New Elements setting controller object can be
                | retrieved as an item of the setting controller collection using its
                | name "HubSettingAtt1" as follows:Dim settingControllers1 As
                | SettingControllers Set settingControllers1 = CATIA.SettingControllers
                | Dim HubSettingAtt1 as DNBMHIMfgHubSettingCtrl set HubSettingAtt1 =
                | settingControllers1.Item( "DNBMHIMfgHubSettingCtrl" )

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.mfg_hub_setting_att = com_object     

    @property
    def append_context_chk_b(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AppendContextChkB
                | o Property AppendContextChkB(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | AppendContextChkB attribute. A TRUE value indicates that the
                | loaded context will be appended to the existing context in
                | the V5 process document
                |

        :return:
        """
        return self.mfg_hub_setting_att.AppendContextChkB

    @property
    def apply_label_eff_to_alt_child(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ApplyLabelEffToAltChild
                | o Property ApplyLabelEffToAltChild(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | ApplyLabelEffToAltChild attribute. A TRUE value indicates
                | that the label effectivity will be applied to all components
                | associated with the Alternative
                |

        :return:
        """
        return self.mfg_hub_setting_att.ApplyLabelEffToAltChild

    @property
    def auto_load_mfg_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoLoadMfgCtx
                | o Property AutoLoadMfgCtx(    ) As
                | 
                | Retrieves (or sets, if not initialized) the AutoLoadMfgCtx
                | parameter. A TRUE value indicates that the manufacturing
                | context is automatically (computed and) loaded into the V5
                | process document during load
                |

        :return:
        """
        return self.mfg_hub_setting_att.AutoLoadMfgCtx

    @property
    def auto_load_srv_mfg_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoLoadSrvMfgCtx
                | o Property AutoLoadSrvMfgCtx(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | AutoLoadSrvMfgCtx parameter. A TRUE value indicates that the
                | existing volumetric context is to be automatically loaded
                | into the V5 process document during load
                |

        :return:
        """
        return self.mfg_hub_setting_att.AutoLoadSrvMfgCtx

    @property
    def auto_load_vol_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | AutoLoadVolCtx
                | o Property AutoLoadVolCtx(    ) As
                | 
                | Retrieves (or sets, if not initialized) the AutoLoadVolCtx
                | parameter. A TRUE value indicates that the existing
                | volumetric context is to be automatically loaded into the V5
                | process document during load
                |

        :return:
        """
        return self.mfg_hub_setting_att.AutoLoadVolCtx

    @property
    def disable_shape_roll_up(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | DisableShapeRollUp
                | o Property DisableShapeRollUp(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | DisableShapeRollUp attribute. A TRUE value indicates that
                | the Shape Rollup won't be added during load
                |

        :return:
        """
        return self.mfg_hub_setting_att.DisableShapeRollUp

    @property
    def issue_repository_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | IssueRepositoryPath
                | o Property IssueRepositoryPath(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | IssueRepositoryPath attribute.
                |

        :return:
        """
        return self.mfg_hub_setting_att.IssueRepositoryPath

    @property
    def link_send_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LinkSendMode
                | o Property LinkSendMode(    ) As
                | 
                | Retrieves (or sets, if not initialized) the LinkSendMode
                | attribute.
                |

        :return:
        """
        return self.mfg_hub_setting_att.LinkSendMode

    @property
    def load3d_state_and_pos(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | Load3dStateAndPos
                | o Property Load3dStateAndPos(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | Load3dStateAndPos parameter. A TRUE value indicates that the
                | ENOVIA product geometry will be loaded from ENOVIA database.
                |

        :return:
        """
        return self.mfg_hub_setting_att.Load3dStateAndPos

    @property
    def load_all_child_proc_mfg_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadAllChildProcMfgCtx
                | o Property LoadAllChildProcMfgCtx(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadAllChildProcMfgCtx parameter. If set to TRUE than during
                | load of manufacturing context the child processes of the
                | previous processes will also be considered
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadAllChildProcMfgCtx

    @property
    def load_assoc_prd_res_child(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadAssocPrdResChild
                | o Property LoadAssocPrdResChild(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadAssocPrdResChild parameter. A TRUE value indicates that
                | the associated prdres children will be loaded from the
                | database.
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadAssocPrdResChild

    @property
    def load_child_proc_mfg_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadChildProcMfgCtx
                | o Property LoadChildProcMfgCtx(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadChildProcMfgCtx parameter. If set to TRUE than during
                | load of manufacturing context the child processes of the
                | previous processes will also be considered
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadChildProcMfgCtx

    @property
    def load_ctx_with_file_geometry(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadCtxWithFileGeometry
                | o Property LoadCtxWithFileGeometry(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadCtxWithFileGeometry parameter. A TRUE value indicates
                | that the existing volumetric context is to be automatically
                | loaded into the V5 process document during load
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadCtxWithFileGeometry

    @property
    def load_disp_mfg_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadDispMfgCtx
                | o Property LoadDispMfgCtx(    ) As
                | 
                | Retrieves (or sets, if not initialized) the LoadDispMfgCtx
                | parameter. A TRUE value indicates that the manufacturing
                | context is display in the V5 process document
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadDispMfgCtx

    @property
    def load_duplicates_in_context_tree_chk_b(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadDuplicatesInContextTreeChkB
                | o Property LoadDuplicatesInContextTreeChkB(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadDuplicatesChkB attribute. A TRUE value indicates that
                | the duplicate objects will be loaded in the context in the
                | V5 process document
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadDuplicatesInContextTreeChkB

    @property
    def load_env_geom_from_en_vdb(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadENVGeomFromENVdb
                | o Property LoadENVGeomFromENVdb(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadENVGeomFromENVdb parameter. A TRUE value indicates that
                | the ENOVIA product geometry will be loaded from ENOVIA
                | database.
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadENVGeomFromENVdb

    @property
    def load_feed_proc_mfg_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadFeedProcMfgCtx
                | o Property LoadFeedProcMfgCtx(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadFeedProcMfgCtx parameter. A TRUE value indicates that
                | during load the manufacturing context will also include
                | products / resource of the feeder process of the previous
                | processes in process graph
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadFeedProcMfgCtx

    @property
    def load_mfg_assmbly(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadMfgAssmbly
                | o Property LoadMfgAssmbly(    ) As
                | 
                | Retrieves (or sets, if not initialized) the LoadMfgAssmbly
                | parameter. A TRUE value indicates that the Manufacturing
                | Assemblies related to process will be loaded when a PPRHub
                | project is opened in V5
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadMfgAssmbly

    @property
    def load_mfg_kits(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadMfgKits
                | o Property LoadMfgKits(    ) As
                | 
                | Retrieves (or sets, if not initialized) the LoadMfgKits
                | parameter. A TRUE value indicates tthat the Manufacturing
                | Kits related to process will be loaded when a PPRHub project
                | is opened in V5
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadMfgKits

    @property
    def load_pss_data(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadPSSData
                | o Property LoadPSSData(    ) As
                | 
                | Retrieves (or sets, if not initialized) the LoadPSSData
                | attribute. A TRUE value indicates that the PSS data will be
                | loaded from the database.
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadPSSData

    @property
    def load_prd_res_user_attribs(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadPrdResUserAttribs
                | o Property LoadPrdResUserAttribs(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadPrdResUserAttribs parameter.
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadPrdResUserAttribs

    @property
    def load_res_geo(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadResGeo
                | o Property LoadResGeo(    ) As
                | 
                | Retrieves (or sets, if not initialized) the LoadResGeo
                | parameter. A TRUE value indicates tthat the Geometries
                | related to Resource will be loaded when a PPRHub project is
                | opened in V5
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadResGeo

    @property
    def load_unconstrained_mfg_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LoadUnconstrainedMfgCtx
                | o Property LoadUnconstrainedMfgCtx(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LoadUnconstrainedMfgCtx parameter. A TRUE value indicates
                | that on load the manufacturing context will also include
                | products / resource of the processes not linked in the
                | process graph containing loaded process
                |

        :return:
        """
        return self.mfg_hub_setting_att.LoadUnconstrainedMfgCtx

    @property
    def lock_assigned_prd_on_load(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | LockAssignedPrdOnLoad
                | o Property LockAssignedPrdOnLoad(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | LockAssignedPrdOnLoad parameter. If set to TRUE than on load
                | all the products assigned to process(es) will be locked in
                | WRITE mode
                |

        :return:
        """
        return self.mfg_hub_setting_att.LockAssignedPrdOnLoad

    @property
    def mail_client_launch_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MailClientLaunchMode
                | o Property MailClientLaunchMode(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | MailClientLaunchMode attribute.
                |

        :return:
        """
        return self.mfg_hub_setting_att.MailClientLaunchMode

    @property
    def mfg_ctx_prev_proc_relation_type(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | MfgCtxPrevProcRelationType
                | o Property MfgCtxPrevProcRelationType(    ) As
                | 
                | Retrieves the MfgCtxPrevProcRelationType parameter The valid
                | integer values (0,1) define the type of Process Traversal
                | Relations to consider while computing Manufacturing Context
                |

        :return:
        """
        return self.mfg_hub_setting_att.MfgCtxPrevProcRelationType

    @property
    def only_load_ctx_with_geometry(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OnlyLoadCtxWithGeometry
                | o Property OnlyLoadCtxWithGeometry(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | OnlyLoadCtxWithGeometry parameter. A TRUE value indicates
                | that the existing volumetric context is to be automatically
                | loaded into the V5 process document during load
                |

        :return:
        """
        return self.mfg_hub_setting_att.OnlyLoadCtxWithGeometry

    @property
    def open_mode_for_load(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | OpenModeForLoad
                | o Property OpenModeForLoad(    ) As
                | 
                | Retrieves (or sets, if not initialized) the OpenModeForLoad
                | attribute.
                |

        :return:
        """
        return self.mfg_hub_setting_att.OpenModeForLoad

    @property
    def pack_and_go_repository_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PackAndGoRepositoryPath
                | o Property PackAndGoRepositoryPath(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | PackAndGoRepositoryPath attribute.
                |

        :return:
        """
        return self.mfg_hub_setting_att.PackAndGoRepositoryPath

    @property
    def post_load_script_option(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PostLoadScriptOption
                | o Property PostLoadScriptOption(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | PostLoadScriptOption attribute. A TRUE value indicates that
                | the provided script in the editor will be executed post Load
                |

        :return:
        """
        return self.mfg_hub_setting_att.PostLoadScriptOption

    @property
    def post_load_script_path(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PostLoadScriptPath
                | o Property PostLoadScriptPath(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | PostLoadScriptPath attribute.
                |

        :return:
        """
        return self.mfg_hub_setting_att.PostLoadScriptPath

    @property
    def post_load_vba_module(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PostLoadVBAModule
                | o Property PostLoadVBAModule(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | PostLoadVBAModule attribute.
                |

        :return:
        """
        return self.mfg_hub_setting_att.PostLoadVBAModule

    @property
    def prev_proc_parse_type_for_mfg_ctx(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | PrevProcParseTypeForMfgCtx
                | o Property PrevProcParseTypeForMfgCtx(    ) As
                | 
                | Retrieves or sets the PrevProcParseTypeForMfgCtx parameter.
                | The valid integer values (0,1,2) define extent of parsing
                | previous process in the loaded process' parent process
                | structure
                |

        :return:
        """
        return self.mfg_hub_setting_att.PrevProcParseTypeForMfgCtx

    @property
    def proc_prod_relations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProcProdRelations
                | o Property ProcProdRelations(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | ProcProdRelations attribute. A safe array of process -
                | product relations to be loaded
                |

        :return:
        """
        return self.mfg_hub_setting_att.ProcProdRelations

    @property
    def proc_res_relations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ProcResRelations
                | o Property ProcResRelations(    ) As
                | 
                | Retrieves (or sets, if not initialized) the ProcResRelations
                | attribute. A safe array of process - resource relations to
                | be loaded
                |

        :return:
        """
        return self.mfg_hub_setting_att.ProcResRelations

    @property
    def rmv_not_assgn_prd_res_on_sync(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | RmvNotAssgnPrdResOnSync
                | o Property RmvNotAssgnPrdResOnSync(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | RmvNotAssgnPrdResOnSync parameter. If set to TRUE than on
                | synchronization during load the products or resources that
                | are not assigned to any loaded processes will be removed
                | from the V5 document.
                |

        :return:
        """
        return self.mfg_hub_setting_att.RmvNotAssgnPrdResOnSync

    @property
    def save_control_flow_in_pro_mode(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveControlFlowInPROMode
                | o Property SaveControlFlowInPROMode(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | SaveControlFlowInPROMode attribute. A TRUE value indicates
                | that the Control flow will be saved to the database in
                | Partial Read only mode
                |

        :return:
        """
        return self.mfg_hub_setting_att.SaveControlFlowInPROMode

    @property
    def save_ppr_no_detailing(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SavePPRNoDetailing
                | o Property SavePPRNoDetailing(    ) As
                | 
                | Returns (or sets, if not initialized) the SavePPRNoDetailing
                | parameter. A TRUE value indicates that simulation detailing
                | data is NOT saved in PPR hub during save.
                |

        :return:
        """
        return self.mfg_hub_setting_att.SavePPRNoDetailing

    @save_ppr_no_detailing.setter
    def save_ppr_no_detailing(self, value):
        """
            :param type value:
        """
        self.mfg_hub_setting_att.SavePPRNoDetailing = value 

    @property
    def save_relation_to_un_exposed_part(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveRelationToUnExposedPart
                | o Property SaveRelationToUnExposedPart(    ) As
                | 
                | Returns (or sets, if not initialized) the
                | SaveRelationToUnExposedPart parameter. A TRUE value
                | indicates that the relation to unexposed part will be saved
                | in the database
                |

        :return:
        """
        return self.mfg_hub_setting_att.SaveRelationToUnExposedPart

    @save_relation_to_un_exposed_part.setter
    def save_relation_to_un_exposed_part(self, value):
        """
            :param type value:
        """
        self.mfg_hub_setting_att.SaveRelationToUnExposedPart = value 

    @property
    def save_show_effctvt_panel(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveShowEffctvtPanel
                | o Property SaveShowEffctvtPanel(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | SaveShowEffctvtPanel parameter. If set to TRUE (and
                | SavePPRNoDetailing is TRUE) a panel is displayed showing
                | effectivity filter information
                |

        :return:
        """
        return self.mfg_hub_setting_att.SaveShowEffctvtPanel

    @property
    def save_v5_calc_time(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | SaveV5CalcTime
                | o Property SaveV5CalcTime(    ) As
                | 
                | Returns (or sets, if not initialized) the SaveV5CalcTime
                | parameter. A TRUE value indicates that the calculated cycle
                | time for V5 process should be assigned to corresponding E5
                | process attribure on save
                |

        :return:
        """
        return self.mfg_hub_setting_att.SaveV5CalcTime

    @save_v5_calc_time.setter
    def save_v5_calc_time(self, value):
        """
            :param type value:
        """
        self.mfg_hub_setting_att.SaveV5CalcTime = value 

    @property
    def show_only_filtered_objects(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | ShowOnlyFilteredObjects
                | o Property ShowOnlyFilteredObjects(    ) As
                | 
                | Retrieves (or sets, if not initialized) the
                | ShowOnlyFilteredObjects attribute. A TRUE value indicates
                | that the Only Filtered objects will be shown in Search
                | Results
                |

        :return:
        """
        return self.mfg_hub_setting_att.ShowOnlyFilteredObjects

    def get_append_context_chk_b_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAppendContextChkBInfo
                | o Func GetAppendContextChkBInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment informations for the AppendContextChkB
                | parameter. Role:Retrieves the state of the AppendContextChkB
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetAppendContextChkBInfo(io_admin_level, io_locked)

    def get_apply_label_eff_to_alt_child_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetApplyLabelEffToAltChildInfo
                | o Func GetApplyLabelEffToAltChildInfo(        ioAdminLevel,
                |                                               ioLocked) As
                | 
                | Retrieves environment informations for the
                | ApplyLabelEffToAltChild parameter. Role:Retrieves the state
                | of the ApplyLabelEffToAltChild parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetApplyLabelEffToAltChildInfo(io_admin_level, io_locked)

    def get_auto_load_mfg_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoLoadMfgCtxInfo
                | o Func GetAutoLoadMfgCtxInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the AutoLoadMfgCtx
                | parameter. Role:Retrieves the state of the AutoLoadMfgCtx
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetAutoLoadMfgCtxInfo(io_admin_level, io_locked)

    def get_auto_load_srv_mfg_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoLoadSrvMfgCtxInfo
                | o Func GetAutoLoadSrvMfgCtxInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment informations for the AutoLoadSrvMfgCtx
                | parameter. Role:Retrieves the state of the AutoLoadSrvMfgCtx
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetAutoLoadSrvMfgCtxInfo(io_admin_level, io_locked)

    def get_auto_load_vol_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetAutoLoadVolCtxInfo
                | o Func GetAutoLoadVolCtxInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the AutoLoadVolCtx
                | parameter. Role:Retrieves the state of the AutoLoadVolCtx
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetAutoLoadVolCtxInfo(io_admin_level, io_locked)

    def get_disable_shape_roll_up_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDisableShapeRollUpInfo
                | o Func GetDisableShapeRollUpInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | DisableShapeRollUp parameter. Role:Retrieves the state of
                | the DisableShapeRollUp parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetDisableShapeRollUpInfo(io_admin_level, io_locked)

    def get_issue_repository_path_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetIssueRepositoryPathInfo
                | o Func GetIssueRepositoryPathInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves the state of the IssueRepositoryPath parameter.
                |
                | Parameters:
                | oInfo
                |                	Address of an object CATSettingInfo.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetIssueRepositoryPathInfo(io_admin_level, io_locked)

    def get_link_send_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLinkSendModeInfo
                | o Func GetLinkSendModeInfo(        ioAdminLevel,
                |                                    ioLocked) As
                | 
                | Retrieves the state of the LinkSendMode parameter.
                |
                | Parameters:
                | oInfo
                |                	Address of an object CATSettingInfo.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLinkSendModeInfo(io_admin_level, io_locked)

    def get_load3d_state_and_pos_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoad3dStateAndPosInfo
                | o Func GetLoad3dStateAndPosInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment informations for the Load3dStateAndPos
                | parameter. Role:Retrieves the state of the Load3dStateAndPos
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoad3dStateAndPosInfo(io_admin_level, io_locked)

    def get_load_all_child_proc_mfg_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadAllChildProcMfgCtxInfo
                | o Func GetLoadAllChildProcMfgCtxInfo(        ioAdminLevel,
                |                                              ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadAllChildProcMfgCtx parameter. Role:Retrieves the state
                | of the LoadAllChildProcMfgCtx parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadAllChildProcMfgCtxInfo(io_admin_level, io_locked)

    def get_load_assoc_prd_res_child_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadAssocPrdResChildInfo
                | o Func GetLoadAssocPrdResChildInfo(        ioAdminLevel,
                |                                            ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadAssocPrdResChild parameter. Role:Retrieves the state of
                | the LoadAssocPrdResChild parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadAssocPrdResChildInfo(io_admin_level, io_locked)

    def get_load_child_proc_mfg_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadChildProcMfgCtxInfo
                | o Func GetLoadChildProcMfgCtxInfo(        ioAdminLevel,
                |                                           ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadChildProcMfgCtx parameter. Role:Retrieves the state of
                | the LoadChildProcMfgCtx parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadChildProcMfgCtxInfo(io_admin_level, io_locked)

    def get_load_ctx_with_file_geometry_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadCtxWithFileGeometryInfo
                | o Func GetLoadCtxWithFileGeometryInfo(        ioAdminLevel,
                |                                               ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadCtxWithFileGeometry parameter. Role:Retrieves the state
                | of the LoadCtxWithFileGeometry parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadCtxWithFileGeometryInfo(io_admin_level, io_locked)

    def get_load_disp_mfg_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadDispMfgCtxInfo
                | o Func GetLoadDispMfgCtxInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the LoadDispMfgCtx
                | parameter. Role:Retrieves the state of the LoadDispMfgCtx
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadDispMfgCtxInfo(io_admin_level, io_locked)

    def get_load_duplicates_in_context_tree_chk_b_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadDuplicatesInContextTreeChkBInfo
                | o Func GetLoadDuplicatesInContextTreeChkBInfo(        ioAdminLevel,
                |                                                       ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadDuplicatesChkB parameter. Role:Retrieves the state of
                | the LoadDuplicatesChkB parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadDuplicatesInContextTreeChkBInfo(io_admin_level, io_locked)

    def get_load_env_geom_from_en_vdb_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadENVGeomFromENVdbInfo
                | o Func GetLoadENVGeomFromENVdbInfo(        ioAdminLevel,
                |                                            ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadENVGeomFromENVdb parameter. Role:Retrieves the state of
                | the LoadENVGeomFromENVdb parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadENVGeomFromENVdbInfo(io_admin_level, io_locked)

    def get_load_feed_proc_mfg_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadFeedProcMfgCtxInfo
                | o Func GetLoadFeedProcMfgCtxInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadFeedProcMfgCtx parameter. Role:Retrieves the state of
                | the LoadFeedProcMfgCtx parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadFeedProcMfgCtxInfo(io_admin_level, io_locked)

    def get_load_mfg_assmbly_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadMfgAssmblyInfo
                | o Func GetLoadMfgAssmblyInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the LoadMfgAssmbly
                | parameter. Role:Retrieves the state of the LoadMfgAssmbly
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadMfgAssmblyInfo(io_admin_level, io_locked)

    def get_load_mfg_kits_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadMfgKitsInfo
                | o Func GetLoadMfgKitsInfo(        ioAdminLevel,
                |                                   ioLocked) As
                | 
                | Retrieves environment informations for the LoadMfgKits
                | parameter. Role:Retrieves the state of the LoadMfgKits
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadMfgKitsInfo(io_admin_level, io_locked)

    def get_load_pss_data_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadPSSDataInfo
                | o Func GetLoadPSSDataInfo(        ioAdminLevel,
                |                                   ioLocked) As
                | 
                | Retrieves environment informations for the LoadPSSData
                | parameter. Role:Retrieves the state of the LoadPSSData
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadPSSDataInfo(io_admin_level, io_locked)

    def get_load_prd_res_user_attribs_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadPrdResUserAttribsInfo
                | o Func GetLoadPrdResUserAttribsInfo(        ioAdminLevel,
                |                                             ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadPrdResUserAttribs parameter. Role:Retrieves the state of
                | the LoadPrdResUserAttribs parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadPrdResUserAttribsInfo(io_admin_level, io_locked)

    def get_load_res_geo_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadResGeoInfo
                | o Func GetLoadResGeoInfo(        ioAdminLevel,
                |                                  ioLocked) As
                | 
                | Retrieves environment informations for the LoadResGeo
                | parameter. Role:Retrieves the state of the LoadResGeo
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadResGeoInfo(io_admin_level, io_locked)

    def get_load_unconstrained_mfg_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLoadUnconstrainedMfgCtxInfo
                | o Func GetLoadUnconstrainedMfgCtxInfo(        ioAdminLevel,
                |                                               ioLocked) As
                | 
                | Retrieves environment informations for the
                | LoadUnconstrainedMfgCtx parameter. Role:Retrieves the state
                | of the LoadUnconstrainedMfgCtx parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLoadUnconstrainedMfgCtxInfo(io_admin_level, io_locked)

    def get_lock_assigned_prd_on_load_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLockAssignedPrdOnLoadInfo
                | o Func GetLockAssignedPrdOnLoadInfo(        ioAdminLevel,
                |                                             ioLocked) As
                | 
                | Retrieves environment informations for the
                | LockAssignedPrdOnLoad parameter. Role:Retrieves the state of
                | the LockAssignedPrdOnLoad parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetLockAssignedPrdOnLoadInfo(io_admin_level, io_locked)

    def get_mail_client_launch_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMailClientLaunchModeInfo
                | o Func GetMailClientLaunchModeInfo(        ioAdminLevel,
                |                                            ioLocked) As
                | 
                | Retrieves the state of the MailClientLaunchMode parameter.
                |
                | Parameters:
                | oInfo
                |                	Address of an object CATSettingInfo.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetMailClientLaunchModeInfo(io_admin_level, io_locked)

    def get_mfg_ctx_prev_proc_relation_type_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetMfgCtxPrevProcRelationTypeInfo
                | o Func GetMfgCtxPrevProcRelationTypeInfo(        ioAdminLevel,
                |                                                  ioLocked) As
                | 
                | Retrieves environment information for the
                | MfgCtxPrevProcRelationType parameter Role:Retrieves the
                | state of the MfgCtxPrevProcRelationType parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetMfgCtxPrevProcRelationTypeInfo(io_admin_level, io_locked)

    def get_only_load_ctx_with_geometry_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOnlyLoadCtxWithGeometryInfo
                | o Func GetOnlyLoadCtxWithGeometryInfo(        ioAdminLevel,
                |                                               ioLocked) As
                | 
                | Retrieves environment informations for the
                | OnlyLoadCtxWithGeometry parameter. Role:Retrieves the state
                | of the OnlyLoadCtxWithGeometry parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetOnlyLoadCtxWithGeometryInfo(io_admin_level, io_locked)

    def get_open_mode_for_load_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetOpenModeForLoadInfo
                | o Func GetOpenModeForLoadInfo(        ioAdminLevel,
                |                                       ioLocked) As
                | 
                | Retrieves environment informations for the OpenModeForLoad
                | parameter. Role:Retrieves the value of the OpenModeForLoad
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetOpenModeForLoadInfo(io_admin_level, io_locked)

    def get_pack_and_go_repository_path_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPackAndGoRepositoryPathInfo
                | o Func GetPackAndGoRepositoryPathInfo(        ioAdminLevel,
                |                                               ioLocked) As
                | 
                | Retrieves the state of the PackAndGoRepositoryPath
                | parameter.
                |
                | Parameters:
                | oInfo
                |                	Address of an object CATSettingInfo.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetPackAndGoRepositoryPathInfo(io_admin_level, io_locked)

    def get_post_load_script_option_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPostLoadScriptOptionInfo
                | o Func GetPostLoadScriptOptionInfo(        ioAdminLevel,
                |                                            ioLocked) As
                | 
                | Retrieves environment informations for the
                | PostLoadScriptOption parameter. Role:Retrieves the state of
                | the PostLoadScriptOption parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetPostLoadScriptOptionInfo(io_admin_level, io_locked)

    def get_post_load_script_path_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPostLoadScriptPathInfo
                | o Func GetPostLoadScriptPathInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves the state of the PostLoadScriptPath parameter.
                |
                | Parameters:
                | oInfo
                |                	Address of an object CATSettingInfo.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetPostLoadScriptPathInfo(io_admin_level, io_locked)

    def get_post_load_vba_module_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPostLoadVBAModuleInfo
                | o Func GetPostLoadVBAModuleInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves the state of the PostLoadVBAModule parameter.
                |
                | Parameters:
                | oInfo
                |                	Address of an object CATSettingInfo.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetPostLoadVBAModuleInfo(io_admin_level, io_locked)

    def get_prev_proc_parse_type_for_mfg_ctx_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetPrevProcParseTypeForMfgCtxInfo
                | o Func GetPrevProcParseTypeForMfgCtxInfo(        ioAdminLevel,
                |                                                  ioLocked) As
                | 
                | Retrieves environment informations for the
                | PrevProcParseTypeForMfgCtx parameter. Role:Retrieves the
                | state of the PrevProcParseTypeForMfgCtx parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetPrevProcParseTypeForMfgCtxInfo(io_admin_level, io_locked)

    def get_proc_prod_relations_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProcProdRelationsInfo
                | o Func GetProcProdRelationsInfo(        ioAdminLevel,
                |                                         ioLocked) As
                | 
                | Retrieves environment informations for the ProcProdRelations
                | parameter. Role:Retrieves the state of the ProcProdRelations
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetProcProdRelationsInfo(io_admin_level, io_locked)

    def get_proc_res_relations_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetProcResRelationsInfo
                | o Func GetProcResRelationsInfo(        ioAdminLevel,
                |                                        ioLocked) As
                | 
                | Retrieves environment informations for the ProcResRelations
                | parameter. Role:Retrieves the state of the ProcResRelations
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetProcResRelationsInfo(io_admin_level, io_locked)

    def get_rmv_not_assgn_prd_res_on_sync_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRmvNotAssgnPrdResOnSyncInfo
                | o Func GetRmvNotAssgnPrdResOnSyncInfo(        ioAdminLevel,
                |                                               ioLocked) As
                | 
                | Retrieves environment informations for the
                | RmvNotAssgnPrdResOnSync parameter. Role:Retrieves the state
                | of the RmvNotAssgnPrdResOnSync parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetRmvNotAssgnPrdResOnSyncInfo(io_admin_level, io_locked)

    def get_save_control_flow_in_pro_mode_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSaveControlFlowInPROModeInfo
                | o Func GetSaveControlFlowInPROModeInfo(        ioAdminLevel,
                |                                                ioLocked) As
                | 
                | Retrieves environment informations for the
                | SaveControlFlowInPROMode parameter. Role:Retrieves the state
                | of the SaveControlFlowInPROMode parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetSaveControlFlowInPROModeInfo(io_admin_level, io_locked)

    def get_save_ppr_no_detailing_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSavePPRNoDetailingInfo
                | o Func GetSavePPRNoDetailingInfo(        ioAdminLevel,
                |                                          ioLocked) As
                | 
                | Retrieves environment informations for the
                | SavePPRNoDetailing parameter. Role:Retrieves the state of
                | the SavePPRNoDetailing parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetSavePPRNoDetailingInfo(io_admin_level, io_locked)

    def get_save_relation_to_un_exposed_part_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSaveRelationToUnExposedPartInfo
                | o Func GetSaveRelationToUnExposedPartInfo(        ioAdminLevel,
                |                                                   ioLocked) As
                | 
                | Retrieves environment informations for the
                | SaveRelationToUnExposedPart parameter. Role:Retrieves the
                | state of the SaveRelationToUnExposedPart parameter in the
                | current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetSaveRelationToUnExposedPartInfo(io_admin_level, io_locked)

    def get_save_show_effctvt_panel_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSaveShowEffctvtPanelInfo
                | o Func GetSaveShowEffctvtPanelInfo(        ioAdminLevel,
                |                                            ioLocked) As
                | 
                | Retrieves environment informations for the
                | SaveShowEffctvtPanel parameter. Role:Retrieves the state of
                | the SaveShowEffctvtPanel parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetSaveShowEffctvtPanelInfo(io_admin_level, io_locked)

    def get_save_v5_calc_time_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSaveV5CalcTimeInfo
                | o Func GetSaveV5CalcTimeInfo(        ioAdminLevel,
                |                                      ioLocked) As
                | 
                | Retrieves environment informations for the SaveV5CalcTime
                | parameter. Role:Retrieves the state of the SaveV5CalcTime
                | parameter in the current environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetSaveV5CalcTimeInfo(io_admin_level, io_locked)

    def get_show_only_filtered_objects_info(self, io_admin_level, io_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetShowOnlyFilteredObjectsInfo
                | o Func GetShowOnlyFilteredObjectsInfo(        ioAdminLevel,
                |                                               ioLocked) As
                | 
                | Retrieves environment informations for the
                | ShowOnlyFilteredObjects parameter. Role:Retrieves the state
                | of the ShowOnlyFilteredObjects parameter in the current
                | environment.
                |
                | Parameters:
                | ioAdminLevel
                |  If the parameter is locked, AdminLevel gives the administration
                |        level that imposes the value of the parameter.
                | 	 If the parameter is not locked, AdminLevel gives the administration
                |        level that will give the value of the parameter after a reset.
                |  
                |  ioLocked
                |       Indicates if the parameter has been locked.
                |  
                | 
                |  Returns:
                |         Indicates if the parameter has been explicitly modified or remain
                |       to the administrated value.

                |
        :param io_admin_level:
        :param io_locked:
        :return:
        """
        return self.mfg_hub_setting_att.GetShowOnlyFilteredObjectsInfo(io_admin_level, io_locked)

    def set_append_context_chk_b_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAppendContextChkBLock
                | o Sub SetAppendContextChkBLock(        iLocked)
                | 
                | Locks or unlocks the AppendContextChkB parameter. Role:Locks
                | or unlocks the AppendContextChkB parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetAppendContextChkBLock(i_locked)

    def set_apply_label_eff_to_alt_child_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetApplyLabelEffToAltChildLock
                | o Sub SetApplyLabelEffToAltChildLock(        iLocked)
                | 
                | Locks or unlocks the ApplyLabelEffToAltChild parameter.
                | Role:Locks or unlocks the ApplyLabelEffToAltChild parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetApplyLabelEffToAltChildLock(i_locked)

    def set_auto_load_mfg_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoLoadMfgCtxLock
                | o Sub SetAutoLoadMfgCtxLock(        iLocked)
                | 
                | Locks or unlocks the AutoLoadMfgCtx parameter. Role:Locks or
                | unlocks the AutoLoadMfgCtx parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetAutoLoadMfgCtxLock(i_locked)

    def set_auto_load_srv_mfg_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoLoadSrvMfgCtxLock
                | o Sub SetAutoLoadSrvMfgCtxLock(        iLocked)
                | 
                | Locks or unlocks the AutoLoadSrvMfgCtx parameter. Role:Locks
                | or unlocks the AutoLoadSrvMfgCtx parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetAutoLoadSrvMfgCtxLock(i_locked)

    def set_auto_load_vol_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetAutoLoadVolCtxLock
                | o Sub SetAutoLoadVolCtxLock(        iLocked)
                | 
                | Locks or unlocks the AutoLoadVolCtx parameter. Role:Locks or
                | unlocks the AutoLoadVolCtx parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetAutoLoadVolCtxLock(i_locked)

    def set_disable_shape_roll_up_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDisableShapeRollUpLock
                | o Sub SetDisableShapeRollUpLock(        iLocked)
                | 
                | Locks or unlocks the DisableShapeRollUp parameter.
                | Role:Locks or unlocks the DisableShapeRollUp parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetDisableShapeRollUpLock(i_locked)

    def set_issue_repository_path_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetIssueRepositoryPathLock
                | o Sub SetIssueRepositoryPathLock(        iLocked)
                | 
                | Locks or unlocks the IssueRepositoryPath parameter. Role:
                | Locks or unlocks the IssueRepositoryPath parameter if the
                | operation is allowed in the current administrated
                | environment. In user mode this method will always return
                | E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	1 :   to lock the parameter.
                |  	0:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetIssueRepositoryPathLock(i_locked)

    def set_link_send_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLinkSendModeLock
                | o Sub SetLinkSendModeLock(        iLocked)
                | 
                | Locks or unlocks the LinkSendMode parameter. Role: Locks or
                | unlocks the LinkSendMode parameter if the operation is
                | allowed in the current administrated environment. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	1 :   to lock the parameter.
                |  	0:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLinkSendModeLock(i_locked)

    def set_load3d_state_and_pos_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoad3dStateAndPosLock
                | o Sub SetLoad3dStateAndPosLock(        iLocked)
                | 
                | Locks or unlocks the Load3dStateAndPos parameter. Role:Locks
                | or unlocks the Load3dStateAndPos parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoad3dStateAndPosLock(i_locked)

    def set_load_all_child_proc_mfg_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadAllChildProcMfgCtxLock
                | o Sub SetLoadAllChildProcMfgCtxLock(        iLocked)
                | 
                | Locks or unlocks the LoadAllChildProcMfgCtx parameter.
                | Role:Locks or unlocks the LoadAllChildProcMfgCtx parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadAllChildProcMfgCtxLock(i_locked)

    def set_load_assoc_prd_res_child_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadAssocPrdResChildLock
                | o Sub SetLoadAssocPrdResChildLock(        iLocked)
                | 
                | Locks or unlocks the LoadAssocPrdResChild parameter.
                | Role:Locks or unlocks the LoadAssocPrdResChild parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadAssocPrdResChildLock(i_locked)

    def set_load_child_proc_mfg_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadChildProcMfgCtxLock
                | o Sub SetLoadChildProcMfgCtxLock(        iLocked)
                | 
                | Locks or unlocks the LoadChildProcMfgCtx parameter.
                | Role:Locks or unlocks the LoadChildProcMfgCtx parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadChildProcMfgCtxLock(i_locked)

    def set_load_ctx_with_file_geometry_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadCtxWithFileGeometryLock
                | o Sub SetLoadCtxWithFileGeometryLock(        iLocked)
                | 
                | Locks or unlocks the LoadCtxWithFileGeometry parameter.
                | Role:Locks or unlocks the LoadCtxWithFileGeometry parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadCtxWithFileGeometryLock(i_locked)

    def set_load_disp_mfg_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadDispMfgCtxLock
                | o Sub SetLoadDispMfgCtxLock(        iLocked)
                | 
                | Locks or unlocks the LoadDispMfgCtx parameter. Role:Locks or
                | unlocks the LoadDispMfgCtx parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadDispMfgCtxLock(i_locked)

    def set_load_duplicates_in_context_tree_chk_b_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadDuplicatesInContextTreeChkBLock
                | o Sub SetLoadDuplicatesInContextTreeChkBLock(        iLocked)
                | 
                | Locks or unlocks the LoadDuplicatesChkB parameter.
                | Role:Locks or unlocks the LoadDuplicatesChkB parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadDuplicatesInContextTreeChkBLock(i_locked)

    def set_load_env_geom_from_en_vdb_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadENVGeomFromENVdbLock
                | o Sub SetLoadENVGeomFromENVdbLock(        iLocked)
                | 
                | Locks or unlocks the LoadENVGeomFromENVdb parameter.
                | Role:Locks or unlocks the LoadENVGeomFromENVdb parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadENVGeomFromENVdbLock(i_locked)

    def set_load_feed_proc_mfg_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadFeedProcMfgCtxLock
                | o Sub SetLoadFeedProcMfgCtxLock(        iLocked)
                | 
                | Locks or unlocks the SaveV5CalcTime parameter. Role:Locks or
                | unlocks the SaveV5CalcTime parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadFeedProcMfgCtxLock(i_locked)

    def set_load_mfg_assmbly_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadMfgAssmblyLock
                | o Sub SetLoadMfgAssmblyLock(        iLocked)
                | 
                | Locks or unlocks the LoadMfgAssmbly parameter. Role:Locks or
                | unlocks the LoadMfgAssmbly parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadMfgAssmblyLock(i_locked)

    def set_load_mfg_kits_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadMfgKitsLock
                | o Sub SetLoadMfgKitsLock(        iLocked)
                | 
                | Locks or unlocks the LoadMfgKits parameter. Role:Locks or
                | unlocks the LoadMfgKits parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadMfgKitsLock(i_locked)

    def set_load_pss_data_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadPSSDataLock
                | o Sub SetLoadPSSDataLock(        iLocked)
                | 
                | Locks or unlocks the LoadPSSData parameter. Role:Locks or
                | unlocks the LoadPSSData parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadPSSDataLock(i_locked)

    def set_load_prd_res_user_attribs_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadPrdResUserAttribsLock
                | o Sub SetLoadPrdResUserAttribsLock(        iLocked)
                | 
                | Locks or unlocks the LoadPrdResUserAttribs parameter.
                | Role:Locks or unlocks the LoadPrdResUserAttribs parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadPrdResUserAttribsLock(i_locked)

    def set_load_res_geo_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadResGeoLock
                | o Sub SetLoadResGeoLock(        iLocked)
                | 
                | Locks or unlocks the LoadResGeo parameter. Role:Locks or
                | unlocks the LoadResGeo parameter if it is possible in the
                | current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadResGeoLock(i_locked)

    def set_load_unconstrained_mfg_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLoadUnconstrainedMfgCtxLock
                | o Sub SetLoadUnconstrainedMfgCtxLock(        iLocked)
                | 
                | Locks or unlocks the LoadUnconstrainedMfgCtx parameter.
                | Role:Locks or unlocks the LoadUnconstrainedMfgCtx parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLoadUnconstrainedMfgCtxLock(i_locked)

    def set_lock_assigned_prd_on_load_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLockAssignedPrdOnLoadLock
                | o Sub SetLockAssignedPrdOnLoadLock(        iLocked)
                | 
                | Locks or unlocks the LockAssignedPrdOnLoad parameter.
                | Role:Locks or unlocks the LockAssignedPrdOnLoad parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetLockAssignedPrdOnLoadLock(i_locked)

    def set_mail_client_launch_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMailClientLaunchModeLock
                | o Sub SetMailClientLaunchModeLock(        iLocked)
                | 
                | Locks or unlocks the MailClientLaunchMode parameter. Role:
                | Locks or unlocks the MailClientLaunchMode parameter if the
                | operation is allowed in the current administrated
                | environment. In user mode this method will always return
                | E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	1 :   to lock the parameter.
                |  	0:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetMailClientLaunchModeLock(i_locked)

    def set_mfg_ctx_prev_proc_relation_type_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetMfgCtxPrevProcRelationTypeLock
                | o Sub SetMfgCtxPrevProcRelationTypeLock(        iLocked)
                | 
                | Locks or unlocks the GetMfgCtxPrevProcRelationType
                | parameter. Role:Locks or unlocks the
                | GetMfgCtxPrevProcRelationType parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |  the locking operation to be performed
                |  Legal values:
                |  TRUE :   to lock the parameter.
                |  FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetMfgCtxPrevProcRelationTypeLock(i_locked)

    def set_only_load_ctx_with_geometry_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOnlyLoadCtxWithGeometryLock
                | o Sub SetOnlyLoadCtxWithGeometryLock(        iLocked)
                | 
                | Locks or unlocks the OnlyLoadCtxWithGeometry parameter.
                | Role:Locks or unlocks the OnlyLoadCtxWithGeometry parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetOnlyLoadCtxWithGeometryLock(i_locked)

    def set_open_mode_for_load_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetOpenModeForLoadLock
                | o Sub SetOpenModeForLoadLock(        iLocked)
                | 
                | Locks or unlocks the OpenModeForLoad parameter. Role:Locks
                | or unlocks the OpenModeForLoad parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetOpenModeForLoadLock(i_locked)

    def set_pack_and_go_repository_path_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPackAndGoRepositoryPathLock
                | o Sub SetPackAndGoRepositoryPathLock(        iLocked)
                | 
                | Locks or unlocks the PackAndGoRepositoryPath parameter.
                | Role: Locks or unlocks the PackAndGoRepositoryPath parameter
                | if the operation is allowed in the current administrated
                | environment. In user mode this method will always return
                | E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	1 :   to lock the parameter.
                |  	0:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetPackAndGoRepositoryPathLock(i_locked)

    def set_post_load_script_option_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPostLoadScriptOptionLock
                | o Sub SetPostLoadScriptOptionLock(        iLocked)
                | 
                | Locks or unlocks the PostLoadScriptOption parameter.
                | Role:Locks or unlocks the PostLoadScriptOption parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetPostLoadScriptOptionLock(i_locked)

    def set_post_load_script_path_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPostLoadScriptPathLock
                | o Sub SetPostLoadScriptPathLock(        iLocked)
                | 
                | Locks or unlocks the PostLoadScriptPath parameter. Role:
                | Locks or unlocks the PostLoadScriptPath parameter if the
                | operation is allowed in the current administrated
                | environment. In user mode this method will always return
                | E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	1 :   to lock the parameter.
                |  	0:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetPostLoadScriptPathLock(i_locked)

    def set_post_load_vba_module_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPostLoadVBAModuleLock
                | o Sub SetPostLoadVBAModuleLock(        iLocked)
                | 
                | Locks or unlocks the PostLoadVBAModule parameter. Role:
                | Locks or unlocks the PostLoadVBAModule parameter if the
                | operation is allowed in the current administrated
                | environment. In user mode this method will always return
                | E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	1 :   to lock the parameter.
                |  	0:   to unlock the parameter.
                |  
                | 
                |  Returns:
                |  Legal values:
                | 	S_OK :   on Success
                |  	E_FAIL:  on failure

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetPostLoadVBAModuleLock(i_locked)

    def set_prev_proc_parse_type_for_mfg_ctx_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetPrevProcParseTypeForMfgCtxLock
                | o Sub SetPrevProcParseTypeForMfgCtxLock(        iLocked)
                | 
                | Locks or unlocks the PrevProcParseTypeForMfgCtx parameter.
                | Role:Locks or unlocks the PrevProcParseTypeForMfgCtx
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                |  the locking operation to be performed
                |  Legal values:
                |  TRUE :   to lock the parameter.
                |  FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetPrevProcParseTypeForMfgCtxLock(i_locked)

    def set_proc_prod_relations_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProcProdRelationsLock
                | o Sub SetProcProdRelationsLock(        iLocked)
                | 
                | Locks or unlocks the ProcProdRelations parameter. Role:Locks
                | or unlocks the ProcProdRelations parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetProcProdRelationsLock(i_locked)

    def set_proc_res_relations_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetProcResRelationsLock
                | o Sub SetProcResRelationsLock(        iLocked)
                | 
                | Locks or unlocks the ProcResRelations parameter. Role:Locks
                | or unlocks the ProcResRelations parameter if it is possible
                | in the current administrative context. In user mode this
                | method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetProcResRelationsLock(i_locked)

    def set_rmv_not_assgn_prd_res_on_sync_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetRmvNotAssgnPrdResOnSyncLock
                | o Sub SetRmvNotAssgnPrdResOnSyncLock(        iLocked)
                | 
                | Locks or unlocks the RmvNotAssgnPrdResOnSync parameter.
                | Role:Locks or unlocks the RmvNotAssgnPrdResOnSync parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetRmvNotAssgnPrdResOnSyncLock(i_locked)

    def set_save_control_flow_in_pro_mode_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSaveControlFlowInPROModeLock
                | o Sub SetSaveControlFlowInPROModeLock(        iLocked)
                | 
                | Locks or unlocks the SaveControlFlowInPROMode parameter.
                | Role:Locks or unlocks the SaveControlFlowInPROMode parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetSaveControlFlowInPROModeLock(i_locked)

    def set_save_ppr_no_detailing_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSavePPRNoDetailingLock
                | o Sub SetSavePPRNoDetailingLock(        iLocked)
                | 
                | Locks or unlocks the SavePPRNoDetailing parameter.
                | Role:Locks or unlocks the SavePPRNoDetailing parameter if it
                | is possible in the current administrative context. In user
                | mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetSavePPRNoDetailingLock(i_locked)

    def set_save_relation_to_un_exposed_part_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSaveRelationToUnExposedPartLock
                | o Sub SetSaveRelationToUnExposedPartLock(        iLocked)
                | 
                | Locks or unlocks the SaveRelationToUnExposedPart parameter.
                | Role:Locks or unlocks the SaveRelationToUnExposedPart
                | parameter if it is possible in the current administrative
                | context. In user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetSaveRelationToUnExposedPartLock(i_locked)

    def set_save_show_effctvt_panel_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSaveShowEffctvtPanelLock
                | o Sub SetSaveShowEffctvtPanelLock(        iLocked)
                | 
                | Locks or unlocks the SaveShowEffctvtPanel parameter.
                | Role:Locks or unlocks the SaveShowEffctvtPanel parameter if
                | it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetSaveShowEffctvtPanelLock(i_locked)

    def set_save_v5_calc_time_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetSaveV5CalcTimeLock
                | o Sub SetSaveV5CalcTimeLock(        iLocked)
                | 
                | Locks or unlocks the SaveV5CalcTime parameter. Role:Locks or
                | unlocks the SaveV5CalcTime parameter if it is possible in
                | the current administrative context. In user mode this method
                | will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetSaveV5CalcTimeLock(i_locked)

    def set_show_only_filtered_objects_lock(self, i_locked):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetShowOnlyFilteredObjectsLock
                | o Sub SetShowOnlyFilteredObjectsLock(        iLocked)
                | 
                | Locks or unlocks the ShowOnlyFilteredObjects parameter.
                | Role:Locks or unlocks the ShowOnlyFilteredObjects parameter
                | if it is possible in the current administrative context. In
                | user mode this method will always return E_FAIL.
                |
                | Parameters:
                | iLocked
                | 	the locking operation to be performed
                | 	Legal values:
                | 	TRUE :   to lock the parameter.
                |  	FALSE:   to unlock the parameter.

                |
        :param i_locked:
        :return:
        """
        return self.mfg_hub_setting_att.SetShowOnlyFilteredObjectsLock(i_locked)

    def __repr__(self):
        return f'MfgHubSettingAtt()'
