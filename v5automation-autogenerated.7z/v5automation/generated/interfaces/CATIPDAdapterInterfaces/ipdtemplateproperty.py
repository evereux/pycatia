#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class IPDTemplateProperty(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access template object (being pointed by the given V5
                | object) properties.Role: This interface given a V5 object, will get
                | the handle to the template object using the pointer attribute
                | referring in it and allows to access the properties of the template
                | object.This interface expect caller to use attribute name define in
                | PPPR server for example caller should use "note" to access Description
                | .

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.ipd_template_property = com_object     

    def get_template_boolean_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTemplateBooleanAttribute
                | o Func GetTemplateBooleanAttribute(        iAttrName) As
                | 
                | This gets a String Attribute value of an input Object
                |
                | Parameters:
                | iAttrName
                |     The name of the Attribute whose value we need
                |  
                |  oAttrValue
                |     The value of the attribute
                |  
                | 
                |  Returns:
                |      S_OK

                |
        :param i_attr_name:
        :return:
        """
        return self.ipd_template_property.GetTemplateBooleanAttribute(i_attr_name)

    def get_template_double_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTemplateDoubleAttribute
                | o Func GetTemplateDoubleAttribute(        iAttrName) As
                | 
                | This gets a String Attribute value of an input Object
                |
                | Parameters:
                | iAttrName
                |     The name of the Attribute whose value we need
                |  
                |  oAttrValue
                |     The value of the attribute
                |  
                | 
                |  Returns:
                |      S_OK

                |
        :param i_attr_name:
        :return:
        """
        return self.ipd_template_property.GetTemplateDoubleAttribute(i_attr_name)

    def get_template_long_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTemplateLongAttribute
                | o Func GetTemplateLongAttribute(        iAttrName) As
                | 
                | This gets a String Attribute value of an input Object
                |
                | Parameters:
                | iAttrName
                |     The name of the Attribute whose value we need
                |  
                |  oAttrValue
                |     The value of the attribute
                |  
                | 
                |  Returns:
                |      S_OK

                |
        :param i_attr_name:
        :return:
        """
        return self.ipd_template_property.GetTemplateLongAttribute(i_attr_name)

    def get_template_string_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetTemplateStringAttribute
                | o Func GetTemplateStringAttribute(        iAttrName) As
                | 
                | This gets a String Attribute value of an input Object
                |
                | Parameters:
                | iAttrName
                |     The name of the Attribute whose value we need
                |  
                |  oAttrValue
                |     The value of the attribute
                |  
                | 
                |  Returns:
                |      S_OK

                |
        :param i_attr_name:
        :return:
        """
        return self.ipd_template_property.GetTemplateStringAttribute(i_attr_name)

    def __repr__(self):
        return f'IPDTemplateProperty()'
