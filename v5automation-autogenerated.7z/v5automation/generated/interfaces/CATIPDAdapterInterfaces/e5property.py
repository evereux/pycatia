#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class E5Property(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | Interface to access object properties.Role: This interface allow user
                | to access and edit properties for those V5 objects who were loaded
                | from E5.NoteWhile getting or setting the value for any attribute the
                | implementation  attempts to access attribute value from V5 object
                | first & then from Manufacturing Hub. If attribute happens to be one of
                | the mapped attribute or if attribute with same name (user attribute,
                | CATIA attribute ...) exists on V5 object, then value will be returned
                | from V5 object. If V5 object doesn't have that attribute, then value
                | will be directly returned from Manufacturing Hub database. When we try
                | to get attribute from V5 object, if required object will be loaded in
                | memory and this may result in populating of cache (CGR, Selective
                | loading...)This interface expect caller to use attribute name define
                | in PPPR server for example caller should use "note" to access
                | Description .Set calls will succeed only if user has editing
                | privileges for that object.

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.e5_property = com_object     

    def get_boolean_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetBooleanAttribute
                | o Func GetBooleanAttribute(        iAttrName) As
                | 
                | This gets an CATBoolean Attribute value of an input Object
                |
                | Parameters:
                | iAttrName
                |     The name of the Attribute whose value we need
                |  
                |  oAttrValue
                |     CATBoolean value of the Attribute

                |
        :param i_attr_name:
        :return:
        """
        return self.e5_property.GetBooleanAttribute(i_attr_name)

    def get_double_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetDoubleAttribute
                | o Func GetDoubleAttribute(        iAttrName) As
                | 
                | This gets a Double Attribute value of an input Object
                |
                | Parameters:
                | iAttrName
                |     The name of the Attribute whose value we need
                |  
                |  oAttrValue
                |     Double value of the Attribute

                |
        :param i_attr_name:
        :return:
        """
        return self.e5_property.GetDoubleAttribute(i_attr_name)

    def get_long_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetLongAttribute
                | o Func GetLongAttribute(        iAttrName) As
                | 
                | This gets a Long Attribute value of an input Object
                |
                | Parameters:
                | iAttrName
                |     The name of the Attribute whose value we need
                |  
                |  oAttrValue
                |     Long value of the Attribute

                |
        :param i_attr_name:
        :return:
        """
        return self.e5_property.GetLongAttribute(i_attr_name)

    def get_string_attribute(self, i_attr_name):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetStringAttribute
                | o Func GetStringAttribute(        iAttrName) As
                | 
                | This gets a String Attribute value of an input Object
                |
                | Parameters:
                | iAttrName
                |     The name of the Attribute whose value we need
                |  
                | 
                |  Returns:
                |      CATUnicodeString value of the Attribute

                |
        :param i_attr_name:
        :return:
        """
        return self.e5_property.GetStringAttribute(i_attr_name)

    def set_boolean_attribute(self, i_attr_name, i_attr_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetBooleanAttribute
                | o Sub SetBooleanAttribute(        iAttrName,
                |                                   iAttrValue)
                | 
                | This sets an CATBoolean Attribute value to an input Object
                |
                | Parameters:
                | iAttrName
                |     The Attribute Name whose value we need to set
                |  
                |  iAttrValue
                |     CATBoolean value of the Attribute
                |  
                | 
                |  Returns:
                |      Value of iAttrName

                |
        :param i_attr_name:
        :param i_attr_value:
        :return:
        """
        return self.e5_property.SetBooleanAttribute(i_attr_name, i_attr_value)

    def set_double_attribute(self, i_attr_name, i_attr_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetDoubleAttribute
                | o Sub SetDoubleAttribute(        iAttrName,
                |                                  iAttrValue)
                | 
                | This sets a Double Attribute value to an input Object
                |
                | Parameters:
                | iAttrName
                |     The Attribute Name whose value we need to set
                |  
                |  iAttrValue
                |     Double value of the Attribute
                |  
                | 
                |  Returns:
                |      Value of iAttrName

                |
        :param i_attr_name:
        :param i_attr_value:
        :return:
        """
        return self.e5_property.SetDoubleAttribute(i_attr_name, i_attr_value)

    def set_long_attribute(self, i_attr_name, i_attr_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetLongAttribute
                | o Sub SetLongAttribute(        iAttrName,
                |                                iAttrValue)
                | 
                | This sets a Long Attribute value to an input Object
                |
                | Parameters:
                | iAttrName
                |     The Attribute Name whose value we need to set
                |  
                | 
                |  Returns:
                |      Value of iAttrName

                |
        :param i_attr_name:
        :param i_attr_value:
        :return:
        """
        return self.e5_property.SetLongAttribute(i_attr_name, i_attr_value)

    def set_string_attribute(self, i_attr_name, i_attr_value):
        """
        .. note::
            CAA V5 Visual Basic help

                | SetStringAttribute
                | o Sub SetStringAttribute(        iAttrName,
                |                                  iAttrValue)
                | 
                | This sets a String Attribute value to an input Object
                |
                | Parameters:
                | iAttrName
                |     The Attribute Name whose value we need to set
                |  
                |  iAttrValue
                |     CATUnicodeString value of the Attribute

                |
        :param i_attr_name:
        :param i_attr_value:
        :return:
        """
        return self.e5_property.SetStringAttribute(i_attr_name, i_attr_value)

    def __repr__(self):
        return f'E5Property()'
