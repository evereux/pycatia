#! /usr/bin/python3.6
# module initially auto generated using V5Automation.chm from CATIA R25 on 2020-05-18 10:56:40.651039

from pycatia.system_interfaces.base_object import AnyObject
from pycatia.system_interfaces.collection import Collection


class MHIRelationManagement(inherited_from):
    """
        .. note::
            CAA V5 Visual Basic help

                | This interface expect caller to use relation types defined in PPR
                | Server which can be obtained by the GetSupportedRelations method

    """

    def __init__(self, com_object):
        super().__init__(com_object)
        self.mhi_relation_management = com_object     

    def get_relation_object(self, i_relation_name, i_assigned_object):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetRelationObject
                | o Func GetRelationObject(        iRelationName,
                |                                  iAssignedObject) As
                | 
                | This method provides handle to the E5 provider on the
                | relation object that exists between selected activity and an
                | item/resource
                |
                | Parameters:
                | iRelationName
                |     Name of the relation existing between the selected activity and the item/resource
                |     The possible values for relation name can be obtained through a call to DNBIAMHIRelationManagement#GetSupportedRelations method
                |  
                |  iAssignedObject
                |     The item/resource that is related to the selected activity
                |  
                |  oRelationObjAttrProvider
                |    E5 provider on the relation object that exists between selected activity and an item/resource
                |  
                | 
                |  Returns:
                |      S_OK or E_FAIL

                |
        :param i_relation_name:
        :param i_assigned_object:
        :return:
        """
        return self.mhi_relation_management.GetRelationObject(i_relation_name, i_assigned_object)

    def get_supported_relations(self):
        """
        .. note::
            CAA V5 Visual Basic help

                | GetSupportedRelations
                | o Func GetSupportedRelations(    ) As
                | 
                | This method lists all the possible values that can passed as
                | the relation name for
                | DNBIAMHIRelationManagement#GetRelationObject method.
                |
                | Parameters:
                | oListSupportedRelations
                |     The possible relation names can that are supported by the method GetRelationObject
                |  
                | 
                |  Returns:
                |      S_OK or E_FAIL

                |
        :return:
        """
        return self.mhi_relation_management.GetSupportedRelations()

    def __repr__(self):
        return f'MHIRelationManagement()'
